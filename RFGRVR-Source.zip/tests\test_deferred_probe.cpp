#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "../src/vr_deferred_probe.h"
#include <cassert>
using Microsoft::WRL::ComPtr;
static unsigned finishedNotices=0;static void finished(ID3D11DeviceContext* c){assert(c);++finishedNotices;}
int main(int argc,char** argv){
 RFGRVRDeferredProbe::finishNotice.store(&finished);
 assert(argc==2);ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c,deferred;
 assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));auto* original=*(void***)d.Get();assert(RFGRVRDeferredProbe::attachDevice(d.Get()));auto* deviceEntry=RFGRVRDeferredProbe::find(RFGRVRDeferredProbe::devices,d.Get());assert(deviceEntry&&deviceEntry->copyCount>69&&deviceEntry->shadow[69]==original[69]);
 const unsigned char accessor[]={0x8b,0x81,0,2,0,0,0xc3};if(!memcmp(original[69],accessor,sizeof(accessor))){using Accessor=uintptr_t(__thiscall*)(ID3D11Device*);assert(((Accessor)original[69])(d.Get())==((Accessor)deviceEntry->shadow[69])(d.Get()));}assert(SUCCEEDED(d->CreateDeferredContext(0,&deferred)));assert(RFGRVRDeferredProbe::find(RFGRVRDeferredProbe::contexts,deferred.Get()));
 ComPtr<ID3D11Device3> d3;if(SUCCEEDED(d.As(&d3))&&(void*)d3.Get()==(void*)d.Get()){ComPtr<ID3D11DeviceContext3> context3;assert(SUCCEEDED(d3->CreateDeferredContext3(0,&context3)));assert(RFGRVRDeferredProbe::find(RFGRVRDeferredProbe::contexts,context3.Get()));}
 D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=64;td.MipLevels=td.ArraySize=1;td.Format=DXGI_FORMAT_R8G8B8A8_TYPELESS;td.SampleDesc.Count=1;td.BindFlags=D3D11_BIND_RENDER_TARGET;
 ComPtr<ID3D11Texture2D> t;ComPtr<ID3D11RenderTargetView> v;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&t)));D3D11_RENDER_TARGET_VIEW_DESC vd{};vd.Format=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;vd.ViewDimension=D3D11_RTV_DIMENSION_TEXTURE2D;assert(SUCCEEDED(d->CreateRenderTargetView(t.Get(),&vd,&v)));
 assert(RFGRVRPixelProbe::begin(c.Get()));
 RFGRVRPixelProbe::instancedSite(deferred.Get(),6);
 RFGRVRPixelProbe::instancedSite(deferred.Get(),18);
 assert(RFGRVRPixelProbe::notes.size()==1&&RFGRVRPixelProbe::notes[0].kind==420);
 RFGRVRPixelProbe::eye=1;RFGRVRPixelProbe::instancedSite(deferred.Get(),6);
 assert(RFGRVRPixelProbe::notes.size()==2);RFGRVRPixelProbe::notes.clear();RFGRVRPixelProbe::eye=0;
 for(unsigned eye=0;eye<2;++eye){RFGRVRPixelProbe::eye=eye;ID3D11RenderTargetView* raw=v.Get();deferred->OMSetRenderTargets(1,&raw,nullptr);const float color[4]={eye?0.f:1.f,0,eye?1.f:0.f,1};deferred->ClearRenderTargetView(v.Get(),color);ComPtr<ID3D11CommandList> list;assert(SUCCEEDED(deferred->FinishCommandList(FALSE,&list)));assert(list);c->ExecuteCommandList(list.Get(),FALSE);}
 assert(finishedNotices==2);
 assert(RFGRVRPixelProbe::events.size()==2&&RFGRVRPixelProbe::sources.size()==1&&RFGRVRPixelProbe::notes.size()==2);assert(RFGRVRPixelProbe::notes[0].kind==114&&RFGRVRPixelProbe::notes[1].kind==114);assert(RFGRVRPixelProbe::finish(argv[1]));
 char path[MAX_PATH]{};sprintf_s(path,"%s-target-0.bin",argv[1]);FILE* f=nullptr;assert(!fopen_s(&f,path,"rb")&&f);unsigned char pixels[128]{};assert(fread(pixels,1,sizeof(pixels),f)==sizeof(pixels));fclose(f);for(unsigned i=0;i<32;++i){assert(pixels[i*4+(i<16?0:2)]==255&&pixels[i*4+(i<16?2:0)]==0&&pixels[i*4+1]==0&&pixels[i*4+3]==255);}
}

