#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <cstdint>
#include "ipc.h"
#include "vr_eye_projection.h"
// Call exclusively on the game D3D11 render thread. The engine callback MUST
// render scene geometry using these different per-eye views; a desktop copy is
// intentionally not accepted. This component only owns GPU transport and state.
struct RFGRVREyeRenderContext {
    unsigned eye;
    const RFGREye* trackedEye;
    ID3D11DeviceContext* deviceContext;
    ID3D11RenderTargetView* target;
    ID3D11DepthStencilView* depth;
    unsigned width, height;
    // Derived from the exact OpenXR per-eye asymmetrical FOV. Never substitute
    // a symmetric 110-degree camera projection for this matrix.
    RFGRVREyeProjection d3dProjection;
};
using RFGRVRRenderEngineEye = bool (*)(void* user, const RFGRVREyeRenderContext* args);
extern "C" {
// Pass headset-recommended dimensions and the XR bridge's selected DXGI format.
// Never initialize with a non-shareable or multisampled DXGI format.
__declspec(dllexport) BOOL __stdcall RFGRVR_StereoProducer_Init(ID3D11Device* device, UINT width, UINT height, DXGI_FORMAT format);
// The callback must execute a COMPLETE camera-specific game scene pass per eye.
// It is deliberately not implemented with a second call to sceneRenderPart2.
__declspec(dllexport) BOOL __stdcall RFGRVR_StereoProducer_Render(ID3D11DeviceContext* immediate, RFGRVRRenderEngineEye callback, void* user);
__declspec(dllexport) void __stdcall RFGRVR_StereoProducer_Shutdown();
}
