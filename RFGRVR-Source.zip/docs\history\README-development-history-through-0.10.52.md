# Historical development notes - not current instructions

Read the current README.md and MAINTAINING.md at the source root. This archive includes abandoned experiments.

# Red Faction Guerrilla VR

Native OpenXR VR mod for Red Faction Guerrilla Re-MARS-tered (Steam app 667720).

Users: extract `RFGRVR-Setup.zip`, run `RFGRVR-Setup.exe`, and follow the wizard.
Close the game, companion and Steam for the first installation. Steam Play then
offers VR or Standard game. Updates preserve personal settings and placements.

Developers: see [MAINTAINING.md](MAINTAINING.md). `BUILD-RELEASE.ps1` builds the
installer from the same editable sources used for local development.
`BUILD-TESTS.ps1` runs native, GPU, settings and installer transaction checks.

GitHub updates remain disabled until `distribution/release.json` contains the
repository. Publish the versioned installer ZIP and SHA-256 file together.

No game executable, assets, saves, personal calibration or tracking recordings
belong in this repository or release. Keep `bin/openxr_loader.dll`: this is the
redistributable OpenXR loader, not a game file. Third-party notices are included
in `distribution/THIRD-PARTY-NOTICES.txt`.

## Startup calibration

A locally extracted Mason model appears in a small VR space before the game
starts. T-pose and hold both triggers for one second. Mason holds a fixed T-pose, then lowers his arms and follows head-calibration dots moved only by the player�s head. He does not mirror the player�s arms. After the dot sequence the scene fades into the game videos.
Videos, loading screens and the main menu share the upright floor-anchored screen.
The local cache under `RFGRVR/cache` is generated from the user's own installed
archives and is excluded from releases and source bundles.

On-foot scale uses the authored standing eye reference, independent of idle,
crouch or captured arm poses. Legacy vehicle eye-height trims are separate.

Normal Play in VR always starts a fresh Mason calibration sequence, including
when a companion from an earlier session is present. The launch session owns the
companion through a Windows kill-on-close job; cancellation, game exit/crash and
launcher termination clean it up. The developer-only `--resume-vr` entry preserves
an already resumed session for inspection; Steam Play never selects it.

Pause UI is also composited on the desktop mirror. VR Settings opens a visible,
focused desktop window using the same settings model; arrows/Enter/Escape,
click/right-click and the mouse wheel work there. Closing it restores focus to
the game. The headset's world-space menu rendering is unchanged.

### 0.10.20 — character-owned shoulders
Supersedes the 0.10.19 shoulder retarget: native rig shoulder/clavicle transforms follow the character torso only. No head-relative or overhead-controller shoulder translation remains. Calibration fits total reach and segment lengths against the actual preview rig shoulders; the neutral-wrist elbow pose solves the rigid triangle. Overhead capture cannot change shoulder roots or fitted lengths. Wrist pivot, mirrored elbow heuristic, independent arm lengths and room layout remain. Shoulder landmark spheres follow rig joints while resizing. ArmReach version 2 records CharacterRig ownership; old shoulder metadata is diagnostic only. Native player ownership and NPC isolation gates are unchanged. Regression coverage includes body scales, head turns, arbitrary hand movement and deliberately asymmetric overhead capture.

### 0.10.21 — room/gameplay fit and scale reference
Keeps 0.10.20 character-owned shoulders and fixed measured arm lengths. On-foot eyes now use the calibration room centered reference and saved physical eye offsets, excluding legacy vehicle/native forward trim; stance motion applies only its delta. Vehicle camera paths remain separate. Free-hand/arm radial dimensions match room sizing; occupied hands retain authored weapon geometry and attachment frames. Distal forearm helper receives up to 50% wrist roll; elbow root stays unrolled and wrist/finger tracking remains complete. New body-fit/reset default is 110%; existing manual settings are preserved. A static textured Mason scale reference stands beside the Scout; no gameplay NPC changes. Tests cover half-roll, stable elbow, zero extra eye offset, fixed weapon-local wrists across body sizes and GPU reference rendering.

### 0.10.22 — restore confirmed arms
Reverts 0.10.21 free-hand geometry/finger scaling, on-foot eye-reference rewrite, 110% automatic/reset fit and added scale mannequin. Keeps 0.10.20 rig-owned shoulders/arm fitting, and retains the requested 50% glove-cuff roll. Personal eye/body/world tuning files are preserved. Upper-arm and forearm measurements are averaged across both sides after capture and while loading an older valid profile; invalid bilateral profiles use the prior span fallback on both sides. Wrist pivot offsets remain controller-specific. Occupied hands retain exact authored weapon-local grips, with scale regression coverage. No NPC, vehicle or weapon placement changes.

### 0.10.23 — calibrated eyes, shaft grip, native power impact and lens ghosts
Only on-foot eye reference is changed: the room and game share a centered neutral eye with saved physical eye-height/depth offsets. Removes extra native eye X/Z and general vehicle-forward trim from that on-foot reference; crouch/landing adds only animated deltas. No arm/shoulder sizing changes. Tests compare physical camera/body coordinates across scale and height combinations. Shaft support attachment now starts at its saved position/orientation; later controller span/roll changes are relative to acquisition, preserving sliding without rebasing the saved grip. Read-only live capture confirmed substantial slider displacement. A qualifying two-hand right-trigger sledge strike uses the complete native profile (live profile radius0.4, structure damage1500) rather than kinetic-strength reduction. Existing swing-intent gate and NPC/structure contact limits remain; no animation is triggered. Separately identified native lens-ghost renderer13F8C0 is signature-checked and suppressed in VR with exact thiscall/two-argument ABI. Existing sun-sprite/composite guards remain. No bloom, world lighting, NPC skeleton, vehicle seat or saved grip changes. Tests include actual sweep execution/full power at submaximum speed, off-centre shaft acquisition, relative roll, both-eye lens skipping and full eye/menu/native regression.

### 0.10.24 — six-step saved calibration and facing-on-open panels
Includes the pending 0.10.23 eye/grip/power-sledge/lens corrections. T-pose acceptance allows moderate height/hand asymmetry and motion; flat wrists still cannot satisfy wrist-up capture. Bent-forearm fitting uses the full tracked finger direction and is tested with palm-forward axial rotation. Four arm poses are followed by automatic horizontal and vertical head-target sweeps (no triggers). The bounded 40Hz pose recording solves eye-minus-rotated-local-pivot using both rotation axes and per-phase centering; observable fits with <=25mm residual and plausible offset are accepted. Body drift rejects/repeats the sweeps. The measured pivot feeds room body translation, native room-scale translation and mounted-body tracking; idle torso yaw no longer follows head-only turns. Stick turning/movement are retained. All six stages must succeed before a Complete/version6 profile is committed. Later launches perform one T-pose alignment using saved symmetric arm lengths/wrist offsets/head pivot. B/right secondary or F2 selects Advanced T-pose in the room, including after quick alignment. Existing body/eye scale controls and explicit continue/fade remain. Menus/popups/loading/video mode transitions reacquire an upright stage anchor from the current HMD yaw, then remain world anchored. Head sweep ball uses the same eye-tuning coordinate shift as the room camera. Tests cover known-pivot recovery, drift rejection, guided-sweep completion, saved/incomplete profile round trip, palm-forward lengths, head-only torso stability, menu facing changes, native weapon grips and unchanged stereo/NPC ownership.

### 0.10.25 — positional elbow arc and shared cleaned torso/view motion
Elbow fitting uses the equal-radius centre of wrist positions from straight-arm and bent-arm captures, constrained to the first T-pose horizontal arm line. Both positions are projected into the vertical plane through the initial head/left/right axis, excluding forward/back drift and palm orientation from the fit. Fixed character shoulders remain authoritative; segment lengths remain bilateral averages. ArmFitMethod2 requires one corrected arm recapture; the already-valid measured head pivot is retained automatically. Explicit B/F2 Advanced still performs all six stages; subsequent completed profiles use one T-pose.

Live capture found camera and arm scale0.94017 with steady torso joints restored at native scale. Cleaned spine/head joints and the lean pivot now use the same actor scale as shoulders. The camera consumes the actual cleaned torso's head-motion delta, retaining the rendered root and saved eye offsets, instead of independently recreating lean. Physical-crouch eye handling retains its existing path to avoid applying the crouch twice. No native leg gait, NPC ownership, or vehicle-camera rewrite.

Live glove basis matched the room, but its palm centre differed by4–5cm because the native handprop tag was animated. Anatomical palm centre now uses verified mesh bind positions. Sledge/Gutter support sliding preserves saved radial offsets and slides/rolls on the authored Y shaft, with acquisition-relative movement retained. Saved grip files are not changed.

Live inspection confirmed the sprite, lens and composite hooks were active while SunGlare01 was zero. The named DwnsmpldSunShafts resource is self+AAC and bound independently by the final composite. The signature-checked scoped suppression now nulls that source as well as978, restoring both engine-owned pointers after the pass; ordinary bloom/exposure/lighting remain enabled. Tests cover palm/depth-invariant elbow centres, bind-centre stability despite animated tags, radial shaft sliding, scale0.94017 torso fitting, cleaned torso/camera offsets, dual-source suppression/restoration and full stereo/menu/native regressions. Headset results remain pending.

## 0.10.32 calibration, settings and sledge

Restores the standalone headset/desktop VR Settings panel with controller navigation and saved on-foot eye height. Calibration Mason uses fixed arm poses and follows player-driven head-calibration targets. Sledge support sliding follows the native weapon mesh axis, stops at the shaft bottom, and retains the saved local grip rotation. Existing placements and scales are retained.

## 0.10.34 sledge rollback and crouch attachment
Restores the pre-rail sledge distance-based sliding and axial grip roll. The saved grip is the maximum distance from the primary grip, and sliding can return upward to that limit. Crouched movement uses the final player-owned rendered eye pose, as jump/landing attachment does. Large Map captures its complete native terrain beneath UI icons, then uses the ordinary paused-world stereo renderer behind the same world-anchored panel. This map-specific fallback retains only heap renderer/scene identifiers, not scene-worker stack arguments.


## 0.10.35 map lifecycle correction
Removes the 0.10.34 late renderer reentry. Map world geometry is enabled only at the signature-verified native renderWorld argument gate with a live command writer; Present performs pixel capture/composition only. Existing sledge rollback, saved grips, crouch/landing eye attachment and player-driven head dots are retained.

## 0.10.36 grounded movement and animation attachment
Upright torso stabilization no longer rewrites root/pelvis/leg/foot animation, and is bypassed during jump, fall, crouch and landing recovery. Tracked arms retain their measured lengths and saved weapon grips while shoulders follow the native animated torso in those modes. Crouch/landing eye displacement uses the established standing palette reference, preserving saved eye trim and preventing a reference switch. Landing settlement uses that same reference. Working large-map scheduling and the pre-rail sledge behavior are unchanged.

## 0.10.37 fixed eye reference
Replaces transient standing-eye capture with the immutable local rig reference. This prevents jump anticipation or crouch blend frames from becoming a false standing baseline and keeping landing recovery active. Animated on-foot eyes read the current unhidden native model palette, while stabilized upright/vehicle poses retain their owned cached pose. Existing saved eye offsets, foot physics, map lifecycle correction and sledge behavior are unchanged. Tests reproduce a 1.43m transient versus 1.68m reference, verify recovery exits, and verify live animated eyes advance independently of old controller commands.

## 0.10.38 floor/animation camera continuity
The animation-owned eye anchor now includes the same calibrated player-scale floor correction used by standing temporal rendering. Previously this was omitted whenever center-HMD vertical travel was suppressed, producing a roughly 26cm switch at the saved 118% player reference. Actual GetFrame regressions compare final standing, jump and crouch camera positions at 100/118/140%, including the saved +29cm trim. Map, sledge, native foot physics, saved settings and stereo eye offsets are unchanged.

## 0.10.39 continuous crouch pose
Adds a short, frame-rate-independent blend of the local avatar torso/pelvis toward tracked physical crouch height, including partial dips before the native crouch threshold. Render-only leg fitting retains native foot/toe poses and leaves physics/capsule/root movement untouched. Full/half physical modes keep direct HMD floor tracking; button crouching blends the visual native height and camera-owned pose together. Tracked wrists and weapon grips remain world locked. Jump/landing and seated/turret paths bypass the fitter. Tests cover threshold continuity, recovery, planted feet/toes and unfiltered physical-crouch camera tracking.


### 0.10.40 movement return blending
Keeps the physical crouch fitter through delayed native stand-up, with a slower upward transition. Upright torso recovery uses rigid pose interpolation at the actual recovery weight; shoulder recovery uses a fixed exit snapshot to preserve tracked-arm stability. Grounded camera translation follows rendered head X/Z once rather than applying an additional lean. Saved eye, scale, weapon and vehicle settings are retained. Live verification remains required.


### 0.10.41 menu aspect, firing ownership and performance pass
Popup panels use their native dimensions. Equipped firearms retain VR body ownership through native action timers, with native finger animation. Bounded memory-cache replacement, inactive diagnostic fast paths, opt-in full GPU survey and effect-cache improvements reduce avoidable work. A slower shader-cache experiment was rejected. See `docs/PERFORMANCE-0.10.41.md` for measured evidence, limits and validation. Live results remain pending.


### 0.10.42 native stance yaw and head-pivot following
Removes native upper-body stance yaw while retaining crouch/jump/landing vertical movement and native foot contacts. Both rendered body and current eye samples use the same yaw correction. The saved calibrated head pivot remains active; tighter room-follow thresholds reduce physical translation separation while combined head rotations remain excluded from follow requests. Vehicles, turrets, saved heights/grips and the optimization pass are retained. Both builds and 24 native regression checks pass; headset behavior remains unverified.


### 0.10.43 sprint modifier, inherited throws and Standard isolation
Sprint requires movement intent on foot and preserves vehicle/menu bumper controls. Release velocity is composed as inherited rigid-body motion at the grip plus boosted, smoothed hand-relative motion. Running/platform translation and rotation are inherited once without throw boosting; propane speed normalization applies only to hand motion. Tests include positive/reverse/35 m/s carrier motion, rotation and multiple player scales. Standard launch (and direct launch without explicit VR mode) starts no VR worker/hooks and forwards native DirectInput. Both builds, 26 native tests, installer checks and the built Standard-mode proxy smoke pass. Live headset behavior remains pending; saved settings and previous body/menu/performance corrections are retained.


### 0.10.44 firing/partial-crouch stability, XR pacing and glove/reload feedback
The captured firing failure kept the partial physical-crouch fitter active, bypassing upright stabilization. That path now uses the calibrated upper-body shape at its blended height, with intentional movement lean retained and native finger poses separate. Real crouch/jump/landing paths remain native. Outer rendering receives a runtime XR frame clock and waits before eye resources; frame-period changes are followed without a fixed refresh setting. Gloves Only supports the actual player triangle strips, preserving material ranges and winding with private index buffers. The hip magazine zone is wider, with a short left pulse on eligible pickup-zone entry, independently mixed with native rumble. Both builds, 27 native regression executables, installer checks and the Standard proxy smoke pass. Saved settings are retained; headset verification remains pending.


### 0.10.45 complete gloves and lower-body isolation
Gloves Only retains the complete hand-seeded connected glove components, including cuffs and small enclosed decorations, through private index buffers. Oversize components cannot promote an entire body mesh. Gameplay crouch fitting no longer solves or changes lower-body bones: native crouch/walking/jump/landing legs are preserved, and idle standing uses calibrated neutral legs. Torso fitting and eye goals remain independent of foot placement. Tests include cuff retention, body exclusion, strip winding, unchanged native leg transforms and invariant eye height under foot perturbations. Saved settings and tracking are preserved; headset results remain pending.


### 0.10.46 saved player elevation and glove default
On-foot gameplay Numpad multiply/subtract raises/lowers local avatar and both eyes together by 1 cm, with held repeat and a saved +/-1 metre limit. This is a shared render translation independent of scale, calibrated anatomy, foot fitting and all vehicle offsets. Keys no longer resize scoped weapons. Gloves Only is the default for new settings; existing explicit Full Body preferences are respected. Live elevation controls require verification.


### 0.10.47 retire adjustment shortcuts
Removes runtime player-elevation keyboard adjustment, weapon/grip/scope setup key handling and legacy camera-offset edit shortcuts. Existing saved placements, scales and elevation values remain applied. Ordinary VR Settings, controller input and tracking remain available. Ground-contact/clipping investigation remains open: the inspected native player/render roots matched and authored sole geometry reached root level, so no arbitrary eye or ground offset was introduced.

The idle-leg reference now uses authored inverse-bind positions and identity skin rotations, rather than a captured gameplay stance with unequal ankle heights. Upper-body and camera references are unchanged. Native animated leg chains remain active while moving/crouching/jumping. Walkway/ground clipping still requires live validation.

The independent fitted torso is also retained after entering native grounded crouch, rather than handing its spine back to pelvis/foot corrections. Jump/landing ownership is unchanged.


### 0.10.48 launch updates and head-locked ragdoll
The launch selector always exposes Check for updates and the installed mod version; unconfigured GitHub reports its setup requirement without a network request. Existing release download/checksum/install behavior and install/uninstall wizard are retained. Ragdoll rendering samples only the owned player's native eye positions and head orientation, bypasses ordinary head-tracked offsets, and preserves binocular separation aligned with that head. Standing/crouch/jump and vehicle paths are unchanged. Ragdoll headset response remains unverified.


### 0.10.49 approved clean-install defaults
Approved eye/world-scale, vehicle heights, weapon/hand/magazine/scope placement, focus distances, APC layout and notification settings are versioned in distribution/defaults and included in the checksummed payload. Seed-only records create missing files without overwriting existing choices, and remain after uninstall. Gloves Only is the packaged visibility default. Per-user tracked head/elbow recordings and diagnostics are excluded; fresh calibration remains mandatory.


### 0.10.50 Quest-specific controls
Quest gameplay maps A jump, B reload, X C4-only detonation, Y release-tap to contextual interaction or quick switch, and a 0.5-second Y hold to gesture weapon selection. Context decisions use fresh nontransparent native use prompts and stay latched for the whole tap. LS click sprints on foot/resets view in vehicles; RS click crouches on foot/toggles vehicle aim. Left grip + Menu opens Map; Menu pauses. Pushing RS down accepts missions except during right-grip vehicle height adjustment. Menus retain A/B confirm/back; VR Settings uses X/Y for tabs. Frame/Index profiles, tracking and approved seeded placement defaults are preserved. Hardware testing on Quest remains necessary.


### 0.10.51 Index trackpad layout
Index binds native trackpad vector, touch and force inputs. Left pad upper/lower pressure selects Pause/Map with hysteresis and per-contact latching. Right-pad touch opens weapon selection immediately. LS click sprints/reset vehicle view; RS click crouches/toggles vehicle aim. Left A interacts, Right B reloads, Right A jumps and Left B sends a C4-only detonation command. Right-stick down accepts missions except during vehicle height adjustment. Menu confirm/back, Quest/Frame controls and approved release defaults are retained. Index hardware verification remains pending.


### 0.10.52 Index pad tap/hold
Right-pad touch now quick-switches on release after a short tap; holding contact for half a second opens gesture selection. Long holds do not emit a release-tap switch, and the short-switch pulse cannot start the selector timer. All other Index/Quest/Frame controls and approved installer defaults are retained.
