#include "../src/vr_render_anchor.h"
#include <cassert>
using namespace vrarm;
int main(){M identity{{1,0,0},{0,1,0},{0,0,1}};
 Pose sim{identity,{10,2,30}},rendered{turnAround(identity,{0,1,0},.2f),{10.1f,2.01f,30.2f}};
 Pose anchor{turnAround(identity,{0,0,1},.1f),{10,3.5f,30}},before=anchor;
 assert(RFGRVR_RenderAnchor(sim,rendered,anchor));
 assert(length(sub(local(sim.b,sub(before.p,sim.p)),local(rendered.b,sub(anchor.p,rendered.p))))<.00001f);
 M oldLocal=relative(sim.b,before.b),newLocal=relative(rendered.b,anchor.b);assert(length(sub(oldLocal.u,newLocal.u))<.00001f);
 // Native suspension roll/pitch remain inherited rather than flattened.
 rendered.b=turnAround(rendered.b,{1,0,0},.3f);anchor=before;assert(RFGRVR_RenderAnchor(sim,rendered,anchor));assert(length(sub(anchor.b.u,before.b.u))>.1f);
 rendered.p.x+=100;before=anchor;assert(!RFGRVR_RenderAnchor(sim,rendered,anchor));assert(length(sub(before.p,anchor.p))==0);
 // A valid fast-moving occupied seat can cross the on-foot two-metre limit.
 rendered=sim;rendered.p.x+=8;anchor=sim;assert(!RFGRVR_RenderAnchor(sim,rendered,anchor));assert(RFGRVR_RenderAnchor(sim,rendered,anchor,32));assert(length(sub(anchor.p,rendered.p))<.0001f);
 rendered.p.x+=40;assert(!RFGRVR_RenderAnchor(sim,rendered,anchor,32));assert(!RFGRVR_RenderAnchor(sim,rendered,anchor,100));
}
