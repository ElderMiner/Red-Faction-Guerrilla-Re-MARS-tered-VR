#include "../src/vr_turn_clock.h"
#include "../src/vr_rig_math.h"
#include <cassert>
#include <cmath>
int main(){
 RFGRVRTurnClock clock;constexpr int64_t frequency=10000000;int64_t now=10000000;
 assert(clock.step(now,frequency,true)==0);float degrees=0;
 for(int i=0;i<90;++i){now+=111111;float dt=clock.step(now,frequency,true);
  assert(std::fabs(dt-.0111111f)<.00000001f);degrees+=RFGRVR_SmoothTurn(1,dt);
  assert(clock.step(now+50000,frequency,false)==0); // second eye cannot advance clock
 }
 assert(std::fabs(degrees-75)<.001f);
 assert(clock.step(now+frequency,frequency,true)==.05f); // pause safety retained
 assert(clock.step(now,frequency,true)==0);
}
