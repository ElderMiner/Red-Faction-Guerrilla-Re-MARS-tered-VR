#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <cassert>
#include <vector>
#include "../src/vr_fsr1.h"
using Microsoft::WRL::ComPtr;
int main(){ComPtr<ID3D11Device>d;ComPtr<ID3D11DeviceContext>c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));vrfsr::Upscaler f;assert(f.init(d.Get()));
 unsigned pixels[64*64];for(unsigned y=0;y<64;++y)for(unsigned x=0;x<64;++x)pixels[y*64+x]=x<32?0xff0000ff:0xff00ff00;D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=64;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R8G8B8A8_UNORM;td.Usage=D3D11_USAGE_DEFAULT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;D3D11_SUBRESOURCE_DATA init{pixels,64*4,0};ComPtr<ID3D11Texture2D>input,out;assert(SUCCEEDED(d->CreateTexture2D(&td,&init,&input)));td.Width=td.Height=128;td.BindFlags=D3D11_BIND_RENDER_TARGET;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&out)));float uv[4]={0,0,1,1};assert(f.render(d.Get(),c.Get(),input.Get(),out.Get(),uv,.8f));
 auto read=[&](unsigned x,unsigned y){D3D11_TEXTURE2D_DESC s=td;s.BindFlags=0;s.Usage=D3D11_USAGE_STAGING;s.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D>staging;assert(SUCCEEDED(d->CreateTexture2D(&s,nullptr,&staging)));c->CopyResource(staging.Get(),out.Get());D3D11_MAPPED_SUBRESOURCE mapped{};assert(SUCCEEDED(c->Map(staging.Get(),0,D3D11_MAP_READ,0,&mapped)));unsigned v=*(unsigned*)((char*)mapped.pData+y*mapped.RowPitch+x*4);c->Unmap(staging.Get(),0);return v;};assert(read(16,64)==0xff0000ff&&read(112,64)==0xff00ff00);auto* cached=f.cache[0].middle.Get();assert(f.render(d.Get(),c.Get(),input.Get(),out.Get(),uv,.8f));assert(f.cache[0].middle.Get()==cached);
 // Distinct eye crops must not reuse the opposite eye's image or UV offset.
 float left[4]={0,0,.45f,1},right[4]={.55f,0,1,1};assert(f.render(d.Get(),c.Get(),input.Get(),out.Get(),left,.8f));assert(read(64,64)==0xff0000ff);assert(f.render(d.Get(),c.Get(),input.Get(),out.Get(),right,.8f));assert(read(64,64)==0xff00ff00);
 assert(SUCCEEDED(d->GetDeviceRemovedReason()));puts("PASS: FSR1 shaders, full-image resize, separate eye crops and cached texture reuse");}
