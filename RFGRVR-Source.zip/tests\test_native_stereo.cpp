#include "../src/native_stereo.h"
#include <cassert>
#include <cmath>
using namespace rfgrvr;
struct Renderer:FrameSink {int calls=0;Matrix4 v[2]{},p[2]{}; bool renderEye(unsigned i,const Matrix4& a,const Matrix4& b)override{v[i]=a;p[i]=b;calls++;return true;}};
int main(){
 StereoFrame f{};for(int i=0;i<2;i++){f.eyes[i].tracked.q.w=1;f.eyes[i].tracked.p.x=i?0.032f:-0.032f;f.eyes[i].fovLeft=-0.8f;f.eyes[i].fovRight=0.8f;f.eyes[i].fovUp=0.8f;f.eyes[i].fovDown=-0.8f;}
 Renderer r;assert(renderStereo(f,r));assert(r.calls==2);assert(r.v[0].m[12]!=r.v[1].m[12]);assert(std::isfinite(r.p[0].m[0]));
 f.eyes[0].tracked.q.w=0;Renderer bad;assert(!renderStereo(f,bad));assert(bad.calls==0);
}
