#include "../src/vr_weapon_motion.h"
#include <cassert>
#include "../src/vr_charge_grip.h"
using namespace vrweapon;
int main(){
 // Boost only hand motion. Running/platform velocity is inherited once,
 // independent of player scale or a stationary hand's model orientation.
 {M id{{1,0,0},{0,1,0},{0,0,1}};for(float scale:{1.f,1.18f,2.f})for(float speed:{-8.f,0.f,6.f,35.f})for(float swing:{0.f,2.f}){MotionEstimator e;MotionSample a{1,7,1,1,Pose{id,{0,1,1}},Pose{id,{}},scale,true,false};a.grip=a.physicalGrip=a.pose;a.gripValid=true;e.update(a);a.sample++;a.seconds+=.01;V carrier{speed,0,speed*.4f},hand{0,swing,swing*.5f};a.body.p=mul(carrier,.01f);a.grip.p=add(a.grip.p,add(mul(carrier,.01f),mul(hand,.01f*scale)));a.physicalGrip.p=add(a.physicalGrip.p,mul(hand,.01f));a.pose.p=a.grip.p;auto m=e.update(a);assert(m.valid);V result=add(m.carrierVelocity(scale),m.handThrowVelocity(scale,1.75f));assert(length(sub(result,add(carrier,mul(hand,scale*1.75f))))<.0005f);}}
 // A rotating carrier contributes the actual tangential grip velocity once.
 {M id{{1,0,0},{0,1,0},{0,0,1}};MotionEstimator e;MotionSample a{1,7,1,1,Pose{id,{0,1,1}},Pose{id,{}},1,true,false};a.grip=a.physicalGrip=a.pose;a.gripValid=true;e.update(a);V before=a.grip.p;a.sample++;a.seconds+=.01;a.body.b=turnAround(id,{0,1,0},.04f);a.grip.p=world(a.body.b,before);a.pose=a.grip;auto m=e.update(a);assert(m.valid);V expected=mul(sub(a.grip.p,before),100);assert(length(sub(add(m.carrierVelocity(1),m.handThrowVelocity(1,1.75f)),expected))<.0001f);}
ThrowArming arm;assert(!arm.release(0));arm.begin(1000,2000);assert(!arm.release(2999));arm.begin(3000,2000);assert(arm.release(5000));assert(!arm.release(5001));arm.begin(6000,2000);arm.cancel();assert(!arm.release(9000));M identity{{1,0,0},{0,1,0},{0,0,1}};MotionEstimator estimate;MotionSample s{1,7,1,1,Pose{identity,{0,1,0}},Pose{identity,{}},1,true,false};assert(!estimate.update(s).valid);
 s.sample=2;s.seconds+=.01;s.pose.p.x=.03f;auto m=estimate.update(s);assert(m.valid&&fabsf(m.relativeLinear.x-3)<.001f);auto duplicate=estimate.update(s);assert(fabsf(duplicate.linear.x-m.linear.x)<.0001f);
 estimate.reset();s={1,7,1,1,Pose{identity,{0,1,0}},Pose{identity,{}},1,true,false};estimate.update(s);s.sample=2;s.seconds+=.01;s.pose.p.x=.1f;s.body.p.x=.1f;m=estimate.update(s);assert(m.valid&&m.pointSpeed({0,0,.4f})<.001f&&m.linear.x>9.9f);
 estimate.reset();s={1,7,1,1,Pose{identity,{0,1,0}},Pose{identity,{}},1,true,false};estimate.update(s);s.sample=2;s.seconds+=.01;s.pose.b=turnAround(identity,{0,1,0},.05f);m=estimate.update(s);assert(m.valid&&fabsf(m.angular.y-5)<.01f&&m.pointSpeed({0,0,.4f})>1.99f);
 s.sample=3;s.seconds+=.01;s.pose.p.x=10;assert(!estimate.update(s).valid);s.tracked=false;assert(!estimate.update(s).valid);
 // Artificial body/view turning must never count as a physical swing.
 estimate.reset();s={1,7,1,1,Pose{identity,{0,1,0}},Pose{identity,{}},1,true,false};s.physical={identity,{0,1,0}};s.physicalValid=true;estimate.update(s);s.sample=2;s.seconds+=.01;s.pose.b=turnAround(identity,{0,1,0},.1f);s.pose.p.x=.05f;m=estimate.update(s);assert(m.valid&&m.pointSpeed({0,0,.5f})<.001f);
 s.sample=3;s.seconds+=.01;s.physical.p.x+=.03f;s.pose.p.x+=.03f;m=estimate.update(s);assert(m.valid&&m.pointSpeed({})>1);
 Strike strike;assert(strike.update(1,7,4,true)==0);assert(strike.update(1,7,4,true)==1);assert(strike.contact(55)&&!strike.contact(55)&&strike.contact(56));strike.update(1,7,.2f,true);assert(!strike.contact(57));strike.update(1,7,4,true);assert(strike.contact(55));assert(strike.update(2,8,4,true)==0);
 ThrowLatch latch;assert(latch.update(1,7,0,true)==ThrowEvent::None);assert(latch.update(1,7,1,true)==ThrowEvent::Prime);assert(latch.update(1,7,1,true)==ThrowEvent::None);assert(latch.update(1,7,0,true)==ThrowEvent::Release);assert(latch.update(1,7,0,true)==ThrowEvent::None);
 latch.update(1,7,1,true);assert(latch.update(2,8,1,true)==ThrowEvent::Cancel);assert(latch.update(2,8,1,true)==ThrowEvent::None);latch.update(2,8,0,true);assert(latch.update(2,8,1,true)==ThrowEvent::Prime);assert(latch.update(2,8,0,false)==ThrowEvent::Cancel);
 // A rotating model origin can move down while the actual throwing grip
 // moves up. The launch vector follows the controller, not that lever arm.
 estimate.reset();s={1,7,1,1,Pose{identity,{0,1,0}},Pose{identity,{}},1,true,false};s.grip=s.physicalGrip={identity,{0,1,0}};s.gripValid=true;estimate.update(s);s.sample=2;s.seconds+=.01;s.pose.p.y-=.03f;s.grip.p.y+=.01f;s.physicalGrip.p.y+=.01f;s.grip.p.z+=.04f;s.physicalGrip.p.z+=.04f;m=estimate.update(s);assert(m.valid&&m.linear.y<0&&fabsf(m.throwVelocity().y-1)<.001f&&fabsf(m.throwVelocity().z-4)<.001f);
 estimate.reset();s={1,7,1,1,Pose{identity,{0,1,0}},Pose{identity,{}},1,true,false};s.grip=s.physicalGrip={identity,{0,1,0}};s.gripValid=true;estimate.update(s);s.sample=2;s.seconds+=.01;s.pose.p.x+=.02f;s.body.p.x+=.02f;s.grip.p.x+=.02f;m=estimate.update(s);assert(m.valid&&fabsf(m.throwVelocity().x-2)<.001f);
 // Rotating a model about a stationary controller must not redirect a throw.
 // Real arm swing is already measured at the moving controller.
 estimate.reset();s={1,7,1,1,Pose{identity,{0,1,.15f}},Pose{identity,{}},1,true,false};s.grip=s.physicalGrip={identity,{0,1,0}};s.gripValid=true;estimate.update(s);
 s.sample=2;s.seconds+=.01;s.grip.b=s.physicalGrip.b=turnAround(identity,{1,0,0},-.05f);s.pose.b=s.grip.b;s.pose.p=add(s.grip.p,world(s.pose.b,{0,0,.15f}));m=estimate.update(s);
 assert(m.valid&&m.gripAngular.x< -4.9f&&length(m.throwVelocity())<.0001f&&length(m.gripLinear)<.0001f&&length(m.physicalGripLinear)<.0001f);
 ThrowLatch early;early.update(1,7,0,true);assert(early.update(1,7,1,true)==ThrowEvent::Prime);assert(early.update(1,7,.6f,true)==ThrowEvent::None);assert(early.update(1,7,.5f,true)==ThrowEvent::Release);
 V anchor{1,2,3},localGrip{.03f,.1f,.05f};Pose charge=RFGRVR_ChargeGrip(identity,localGrip,anchor);assert(valid(charge.b)&&length(sub(add(charge.p,world(charge.b,localGrip)),anchor))<.00001f);assert(dot(charge.b.f,V{0,1,0})>.9999f);
 {M id{{1,0,0},{0,1,0},{0,0,1}};V grip{.1f,0,0};Pose pose{id,{1,2,3}};V before=add(pose.p,world(pose.b,grip));auto lifted=RFGRVR_ChargeLift(pose,grip,id.r);assert(lifted.b.f.y>.34f&&length(sub(add(lifted.p,world(lifted.b,grip)),before))<.0001f);}
 // A noisy release sample must not reverse an established forward throw.
 {ThrowVelocityWindow history;V v{},spin{};for(int i=1;i<=9;++i)history.addSample(i*.01,.01f,{0,2,5},{1,0,0});history.addSample(.1,.01f,{0,-6,-8},{-9,0,0});history.estimate(.1,v,spin);assert(v.y>0&&v.z>3&&v.z<5);history.reset();history.estimate(.1,v,spin);assert(length(v)==0&&length(spin)==0);}
 // A stopped hand sheds old momentum after the history window.
 {ThrowVelocityWindow history;V v{},spin{};history.addSample(1,.01f,{0,0,8},{});history.addSample(1.2,.01f,{},{});history.estimate(1.2,v,spin);assert(length(v)==0);}}

