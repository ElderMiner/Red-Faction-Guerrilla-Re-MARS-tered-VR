#pragma once
#include "vr_arm_math.h"
#include <cstdint>
#include <algorithm>
struct RFGRVRTwoHand {
 uintptr_t weapon=0;unsigned handle=0;bool active=false,down=false,releaseRequired=false;
 void cancel(){active=false;}
 bool update(uintptr_t identity,unsigned generation,bool allowed,float squeeze,float radius,const vrarm::Pose single,vrarm::V mainLocal,const vrarm::Pose& supportLocal,vrarm::V primary,const vrarm::Pose& other,vrarm::Pose& output,vrarm::Pose& support,bool slideSupport=false,bool steer=true,bool savedUpperLimit=false){
  using namespace vrarm;output=single;
  bool held=std::isfinite(squeeze)&&(down?squeeze>.35f:squeeze>.65f),pressed=held&&!down;down=held;
  bool changed=weapon!=identity||handle!=generation;if(changed&&weapon&&held)releaseRequired=true;weapon=identity;handle=generation;if(changed)active=false;
  if(!held)releaseRequired=false;if(releaseRequired){active=false;return false;}
  if(!allowed||!held||!identity||!valid(single.b)||!finite(primary)||!finite(other.p)){active=false;return false;}
  V grabPoint=supportLocal.p;
  if(slideSupport){V line=sub(supportLocal.p,mainLocal);float upper=savedUpperLimit?length(line):(std::max)(length(line),.65f);float travel=(std::clamp)(dot(local(single.b,sub(other.p,single.p)),unit(line))-dot(mainLocal,unit(line)),.08f,(std::max)(.08f,upper));grabPoint=add(mainLocal,mul(unit(line),travel));}
  V anchor=add(single.p,world(single.b,grabPoint));
  if(!active&&pressed&&length(sub(other.p,anchor))<=radius){active=true;}
  if(!active)return false;
  if(!steer){support={compose(single.b,supportLocal.b),anchor};return valid(support.b)&&finite(support.p);}
  V localSupport=supportLocal.p;V localSpan=sub(localSupport,mainLocal),trackedSpan=sub(other.p,primary);float span=length(trackedSpan);
  if(length(localSpan)<.025f||span<.04f||span>1.5f){active=false;return false;}
  if(slideSupport){float distance=(std::max)(.08f,(std::min)((savedUpperLimit?length(localSpan):(std::max)(length(localSpan),.65f)),span));localSupport=add(mainLocal,mul(unit(localSpan),distance));localSpan=sub(localSupport,mainLocal);}
  // Rear grip is the pivot. The line between controllers steers pitch/yaw;
  // the main controller supplies roll. The support hand stays on the saved
  // weapon-local grip frame, independent of its angle when grabbing.
  output.b=rotateTo(single.b,world(single.b,localSpan),trackedSpan);
  output.p=sub(primary,world(output.b,mainLocal));
  M supportBasis=supportLocal.b;if(slideSupport){M actual=relative(output.b,other.b);supportBasis=turnAround(supportBasis,unit(localSpan),axialRoll(supportBasis,actual,unit(localSpan)));}
  support={compose(output.b,supportBasis),add(output.p,world(output.b,localSupport))};
  return valid(output.b)&&valid(support.b)&&finite(output.p)&&finite(support.p);
 }
};

