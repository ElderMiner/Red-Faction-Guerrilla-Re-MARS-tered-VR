#include "../src/vr_arm_math.h"
#include <cassert>
using namespace vrarm;
int main(){V elbow{},wrist{};assert(solve({0,0,0},{.3f,0,0},{.6f,0,0},{.3f,.2f,.1f},{0,-1,0},elbow,wrist));assert(fabsf(length(elbow)-.3f)<.0001f);assert(fabsf(length(sub(wrist,elbow))-.3f)<.0001f);assert(length(sub(wrist,{.3f,.2f,.1f}))<.0001f);
 assert(solve({0,0,0},{.3f,0,0},{.6f,0,0},{5,0,0},{0,-1,0},elbow,wrist));assert(length(wrist)<.6f);
 V rotated=rotateTo(V{1,0,0},V{1,0,0},V{-1,0,0});assert(length(sub(rotated,{-1,0,0}))<.0001f);
 M quarter{{0,0,-1},{0,1,0},{1,0,0}};V p{.2f,.4f,.7f};assert(length(sub(local(quarter,world(quarter,p)),p))<.0001f);
 assert(solveTracked({0,0,0},{.3f,0,0},{.6f,0,0},{1.2f,.1f,0},{0,-1,0},elbow,wrist));assert(length(sub(wrist,{1.2f,.1f,0}))<.00001f);
 M identity{{1,0,0},{0,1,0},{0,0,1}};Pose start{identity,{0,0,0}},end{identity,{0,0,1}},helper{identity,{0,0,.5f}};
 Pose stretchedEnd{turnAround(identity,{0,0,1},1.5707963268f),{0,0,2}};Pose middle=segmentHelper(start,end,helper,start,stretchedEnd,true);
 assert(length(sub(middle.p,V{0,0,1}))<.0001f&&fabsf(middle.b.r.x-sqrtf(.5f))<.0001f&&fabsf(middle.b.r.y-sqrtf(.5f))<.0001f&&valid(middle.b));
 Pose upperMiddle=segmentHelper(start,end,helper,start,stretchedEnd,false);assert(length(sub(upperMiddle.p,V{0,0,1}))<.0001f&&length(sub(upperMiddle.b.r,identity.r))<.0001f);
}
