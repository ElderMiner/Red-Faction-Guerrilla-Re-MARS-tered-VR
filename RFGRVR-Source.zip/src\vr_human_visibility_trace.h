#pragma once
#include <windows.h>
#include <cstdio>
#include <cstring>
#include <vector>
namespace RFGRVRHumanVisibility {
struct Row {unsigned pair,phase,human,handle,state,humanFlags,character,characterHandle,render,renderFlags,stamp90,stamp128,bones;float x,y,z,alpha;};
inline std::vector<Row> rows;inline bool active=false;inline unsigned pairs=0;inline ULONGLONG nextCheck=0;
inline bool readable(const void* p,size_t n){MEMORY_BASIC_INFORMATION m{};if(!p||!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;return (uintptr_t)p>=(uintptr_t)m.BaseAddress&&n<=m.RegionSize&&(uintptr_t)p-(uintptr_t)m.BaseAddress<=m.RegionSize-n;}
inline unsigned word(const void* p,unsigned off){unsigned v=0;if(readable((const char*)p+off,4))memcpy(&v,(const char*)p+off,4);return v;}
inline bool path(wchar_t (&out)[MAX_PATH],const wchar_t* name){if(!GetModuleFileNameW(nullptr,out,MAX_PATH))return false;auto* slash=wcsrchr(out,92);if(!slash)return false;wcscpy_s(slash+1,MAX_PATH-(slash+1-out),name);return true;}
inline void sample(unsigned phase){
 if(!active){if(phase||GetTickCount64()<nextCheck)return;nextCheck=GetTickCount64()+500;wchar_t request[MAX_PATH]{};if(!path(request,L"RFGRVR-human-visibility.enable")||GetFileAttributesW(request)==INVALID_FILE_ATTRIBUTES)return;DeleteFileW(request);rows.clear();rows.reserve(4000);pairs=0;active=true;}
 if(!phase)++pairs;auto* base=(char*)GetModuleHandleW(nullptr);unsigned count=word(base,0x2b9887c);auto* ids=(unsigned short*)(uintptr_t)word(base,0x2b98874);auto* pool=(unsigned*)(uintptr_t)word(base,0x2b984f4);
 if(count<=1024&&readable(ids,count*2))for(unsigned i=0;i<count&&i<64&&rows.size()<6000;++i){unsigned short id=ids[i];if(!readable(pool+id,4))continue;auto* human=(char*)(uintptr_t)pool[id];if(!readable(human,0x340))continue;auto* character=(char*)(uintptr_t)word(human,0x32c);auto* render=(char*)(uintptr_t)word(character,0x30);if(!readable(render,0x134))continue;
  Row row{};row.pair=pairs;row.phase=phase;row.human=(unsigned)(uintptr_t)human;row.handle=word(human,0x6c);row.state=word(human,0x2f4);row.humanFlags=word(human,0xb8);row.character=(unsigned)(uintptr_t)character;row.characterHandle=word(character,0);row.render=(unsigned)(uintptr_t)render;row.renderFlags=word(render,0x40);row.stamp90=word(render,0x90);row.stamp128=word(render,0x128);row.bones=word(render,0x120);memcpy(&row.x,human+4,12);memcpy(&row.alpha,render+0xd0,4);rows.push_back(row);
 }
 if(phase!=2||pairs<20)return;active=false;wchar_t file[MAX_PATH]{},name[100]{};swprintf_s(name,L"vr-research\\output\\NPC-Visibility-%lu.csv",GetCurrentProcessId());if(!path(file,name))return;FILE* out=nullptr;if(_wfopen_s(&out,file,L"w")||!out)return;
 fputs("pair,phase,human,handle,state,human_flags,character,char_handle,render,render_flags,stamp90,stamp128,bones,x,y,z,alpha\n",out);
 for(const auto& r:rows)fprintf(out,"%u,%u,%08X,%08X,%u,%08X,%08X,%08X,%08X,%08X,%u,%u,%u,%.5f,%.5f,%.5f,%.5f\n",r.pair,r.phase,r.human,r.handle,r.state,r.humanFlags,r.character,r.characterHandle,r.render,r.renderFlags,r.stamp90,r.stamp128,r.bones,r.x,r.y,r.z,r.alpha);fclose(out);
}
}
