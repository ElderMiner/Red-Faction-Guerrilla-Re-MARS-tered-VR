#include "../src/vr_eye_projection.h"
#include <cassert>
#include <initializer_list>
static bool close(float a,float b){return std::fabs(a-b)<.00001f;}
int main(){
 float fov[4]={-.9f,.7f,.8f,-.6f};RFGRVREyeProjection p{};
 const float n=.1f,z=475.f;
 assert(RFGRVR_BuildEngineProjection(fov,n,z,&p));const auto&m=p.columnMajor;
 const float l=std::tan(fov[0]),r=std::tan(fov[1]),u=std::tan(fov[2]),d=std::tan(fov[3]);
 // All asymmetric frustum bounds map to the D3D clip cube; depth is positive-Z.
 assert(close(m[0]*l+m[8],-1));assert(close(m[0]*r+m[8],1));
 assert(close(m[5]*d+m[9],-1));assert(close(m[5]*u+m[9],1));
 assert(close((m[10]*n+m[14])/n,0));assert(close((m[10]*z+m[14])/z,1));
 assert(m[11]==1);
 // Reproduce the independently captured 85-degree, 16:9 game projection.
 float v=85.f*3.14159265358979323846f/360.f;
 float h=std::atan(std::tan(v)*(16.f/9.f));float symmetric[4]={-h,h,v,-v};
 assert(RFGRVR_BuildEngineProjection(symmetric,n,z,&p));
 // Game degree/radian conversion has a small approximation error.
 assert(std::fabs(p.columnMajor[0]-.6138986945f)<.0001f);
 assert(std::fabs(p.columnMajor[5]-1.0913357735f)<.0001f);
 assert(close(p.columnMajor[10],1.0002105236f));
 assert(close(p.columnMajor[14],-.1000210568f));
 // The compatibility source must cover the headset's off-center frusta
 // without changing the rays submitted to OpenXR. Check both source aspects.
 float eyes[2][4]={{-1.032144f,.879444f,.860424f,-1.050902f},{-.879748f,1.030862f,.87438f,-1.035417f}};
 for(float aspect:{16.f/9.f,9.f/16.f}){
  float degrees=0;assert(RFGRVR_CenteredSourceFov(eyes,unsigned(2160*aspect),2160,&degrees));
  float ty=std::tan(degrees*3.14159265358979323846f/360.f),tx=ty*(unsigned(2160*aspect)/2160.f);
  float centered[4]={-std::atan(tx),std::atan(tx),std::atan(ty),-std::atan(ty)};
  assert(RFGRVR_BuildEngineProjection(centered,n,z,&p));
  for(auto& eye:eyes){for(unsigned axis=0;axis<4;++axis){
   float tangent=std::tan(eye[axis]);float scale=axis<2?p.columnMajor[0]:p.columnMajor[5];
   float uv=axis<2?.5f+.5f*tangent*scale:.5f-.5f*tangent*scale;
   assert(uv>0&&uv<1);float reconstructed=axis<2?(uv-.5f)*2/scale:(.5f-uv)*2/scale;
   assert(close(reconstructed,tangent));
  }}
 }
 float degrees=0;assert(!RFGRVR_CenteredSourceFov(eyes,0,2160,&degrees));eyes[0][0]=0;assert(!RFGRVR_CenteredSourceFov(eyes,3840,2160,&degrees));
}
