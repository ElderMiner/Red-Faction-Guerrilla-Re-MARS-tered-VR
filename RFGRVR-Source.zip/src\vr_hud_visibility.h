#pragma once
#include <cstring>
#include <cmath>
// Native vint_apply_draw_state (77FC0) multiplies object+160 and state+50;
// vint_group_draw (78520) tests object+16C. Borrow only those display fields.
struct RFGRHudVisibility {
 unsigned char* object=nullptr;unsigned char visible=0;float alpha=0;unsigned char state[0x94]{};const void* input=nullptr;
 RFGRHudVisibility(void* node,const void* original,bool force):input(original){if(!force||!node||!original)return;auto* bytes=(unsigned char*)node;memcpy(&alpha,bytes+0x160,4);if(!std::isfinite(alpha)||alpha<0||alpha>1.01f)return;object=bytes;visible=bytes[0x16c];memcpy(state,original,sizeof(state));float one=1;memcpy(state+0x50,&one,4);memcpy(bytes+0x160,&one,4);bytes[0x16c]=1;input=state;}
 ~RFGRHudVisibility(){if(object){memcpy(object+0x160,&alpha,4);object[0x16c]=visible;}}
};
