// RFGR-VR v1.8.2: experimental per-object COM interception.
// Never touches the global/shared DXGI vtable. x86 only.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include "com_method_count.h"
#include "render_window_profile.h"
#include "vr_deferred_probe.h"
extern "C" bool RFGRVR_GameplayProjection_Enabled();
extern "C" bool RFGRVR_HeadCam_MenuScene();
static bool highResolutionScene(){return RFGRVR_GameplayProjection_Enabled()&&!RFGRVR_HeadCam_MenuScene();}
extern "C" bool RFGRVR_ResizeRenderBuffersOnOwner(unsigned,unsigned);
extern "C" bool RFGRVR_Temporal_PPDSize(int,unsigned*,unsigned*);
extern "C" bool RFGRVR_RenderWindow_Ready(unsigned w,unsigned h){return RFGRVRRenderWindow::ready(w,h);}
extern "C" bool RFGRVR_RenderWindow_Requested(unsigned* w,unsigned* h){*w=RFGRVRRenderWindow::width.load();*h=RFGRVRRenderWindow::height.load();return *w&&*h;}
extern "C" void RFGRVR_APC_BeforeResize();
extern "C" void RFGRVR_Temporal_Present(IDXGISwapChain*);
extern "C" void RFGRVR_DesktopPresent(IDXGISwapChain*);
extern "C" void RFGRVR_DesktopMenu(IDXGISwapChain*);
extern "C" void RFGRVR_MapWorld_Present(IDXGISwapChain*);
extern "C" void RFGRVR_WristMap_Present(IDXGISwapChain*);
extern "C" void RFGRVR_WristMap_EndCommandList(ID3D11DeviceContext*);
extern "C" void RFGRVR_EngineProbe_Present();
extern "C" void RFGRVR_EngineProbe_CorrelationPresent();
extern "C" void RFGRVR_CameraDiff_Present();
#include <wrl/client.h>
#include <cstring>
#include <cstdio>
#include <atomic>
#include <algorithm>
static std::atomic<long long> frameOuterTicks{0};
extern "C" void RFGRVR_FrameTiming_Outer(long long ticks){frameOuterTicks.fetch_add(ticks,std::memory_order_relaxed);}
static void frameTiming(LARGE_INTEGER start,LARGE_INTEGER beforePresent,LARGE_INTEGER end,UINT interval,bool gameplay){
 static LARGE_INTEGER frequency{};static long long previous=0;static unsigned count=0,minSync=~0u,maxSync=0;
 static double intervals[120]{},hookMs=0,presentMs=0,outerMs=0;
 const auto outer=frameOuterTicks.exchange(0,std::memory_order_relaxed);
 if(!gameplay){previous=0;count=0;hookMs=presentMs=outerMs=0;minSync=~0u;maxSync=0;return;}
 if(!frequency.QuadPart)QueryPerformanceFrequency(&frequency);
 const double scale=1000./frequency.QuadPart;
 const auto prior=previous;previous=start.QuadPart;
 if(!prior||start.QuadPart-prior>frequency.QuadPart/4){count=0;hookMs=presentMs=outerMs=0;minSync=~0u;maxSync=0;return;}
 intervals[count++]=(start.QuadPart-prior)*scale;hookMs+=(beforePresent.QuadPart-start.QuadPart)*scale;
 presentMs+=(end.QuadPart-beforePresent.QuadPart)*scale;outerMs+=outer*scale;minSync=(std::min)(minSync,interval);maxSync=(std::max)(maxSync,interval);
 if(count<120)return;
 double total=0;for(double d:intervals)total+=d;std::sort(intervals,intervals+120);
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');
 if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Frame-Cost.log");FILE* file=nullptr;
  if(!_wfopen_s(&file,path,L"a")&&file){fprintf(file,"tick=%llu presents=120 intervalAvgMs=%.3f intervalP95Ms=%.3f intervalMaxMs=%.3f hookCpuMs=%.3f dxgiPresentMs=%.3f outerRenderCpuMs=%.3f syncInterval=%u..%u\n",GetTickCount64(),total/120,intervals[113],intervals[119],hookMs/120,presentMs/120,outerMs/120,minSync,maxSync);fclose(file);}}
 count=0;hookMs=presentMs=outerMs=0;minSync=~0u;maxSync=0;
}
using Microsoft::WRL::ComPtr;
extern "C" void RFGRVR_StereoTrace_Present();
extern "C" void RFGRVR_GPUCapture_Present();
extern "C" bool RFGRVR_GPUCapture_Attach(ID3D11DeviceContext*);
extern "C" BOOL __stdcall RFGRVR_OnGameRenderFrame(IDXGISwapChain*);
extern "C" void RFGRVR_DrawInGameCameraLab(IDXGISwapChain*);
namespace {
using DeviceCreate = HRESULT (WINAPI*)(IDXGIAdapter*, D3D_DRIVER_TYPE, HMODULE, UINT, const D3D_FEATURE_LEVEL*,UINT,UINT,ID3D11Device**,D3D_FEATURE_LEVEL*,ID3D11DeviceContext**);
using FactoryCreateSwap = HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory*,IUnknown*,DXGI_SWAP_CHAIN_DESC*,IDXGISwapChain**);
using FactoryCreateHwnd = HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory2*,IUnknown*,HWND,const DXGI_SWAP_CHAIN_DESC1*,const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*,IDXGIOutput*,IDXGISwapChain1**);
using PresentFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT);
static DeviceCreate originalCreate = nullptr;
static FactoryCreateSwap originalFactorySwap = nullptr;
static FactoryCreateHwnd originalFactoryHwnd = nullptr;
static std::atomic<long> factories{0},chains{0},presentCalls{0},installErrors{0};
static thread_local bool inPresent=false;
// Internal linkage: declare and define before HookPresent uses it.
static PresentFn gOriginalPresent=nullptr;
using ResizeFn=HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT,UINT,DXGI_FORMAT,UINT);static ResizeFn originalResize=nullptr;
using FullscreenFn=HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*,BOOL,IDXGIOutput*);static FullscreenFn originalFullscreen=nullptr;
static HRESULT STDMETHODCALLTYPE HookFullscreen(IDXGISwapChain* chain,BOOL,IDXGIOutput*){return originalFullscreen?originalFullscreen(chain,FALSE,nullptr):E_FAIL;}
static HRESULT STDMETHODCALLTYPE HookResize(IDXGISwapChain* chain,UINT count,UINT width,UINT height,DXGI_FORMAT format,UINT flags){RFGRVR_APC_BeforeResize();return originalResize?originalResize(chain,count,width,height,format,flags):E_FAIL;}
struct Shadow { void** entries; void** original; size_t count; };
static bool MakeShadow(void* object,size_t count,size_t slot,void* replacement,void** prior) {
 if(!object || slot>=count)return false;
 void*** obj = reinterpret_cast<void***>(object);
 void** old = *obj;
 if(!old)return false;
 MEMORY_BASIC_INFORMATION info{};
 if(!VirtualQuery(old,&info,sizeof(info)) || info.State!=MEM_COMMIT || (info.Protect&PAGE_NOACCESS))return false;
 // Limit copy to the current committed region to avoid reading past the page.
 if(reinterpret_cast<uintptr_t>(old)+count*sizeof(void*) > reinterpret_cast<uintptr_t>(info.BaseAddress)+info.RegionSize)return false;
 void** copy=(void**)VirtualAlloc(nullptr,count*sizeof(void*),MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
 if(!copy)return false;
 memcpy(copy,old,count*sizeof(void*));
 if(prior)*prior=old[slot];
 copy[slot]=replacement;
 void* prev=InterlockedCompareExchangePointer(reinterpret_cast<PVOID volatile*>(obj),copy,old);
 if(prev!=old){VirtualFree(copy,0,MEM_RELEASE);return false;}
 // Do not free until process exit; game COM lifetime is not ours to control.
 return true;
}
static HRESULT STDMETHODCALLTYPE HookPresent(IDXGISwapChain* self,UINT interval,UINT flags) {
 // Original obtained from the live chain before its vptr was replaced.
 // Never publish test frames and never change arguments or graphics state intentionally.
 auto orig=gOriginalPresent;
 if(!orig)return E_FAIL;
 if(inPresent||(flags&DXGI_PRESENT_TEST))return orig(self,interval,flags);
 LARGE_INTEGER timingStart{},timingPresent{},timingEnd{};QueryPerformanceCounter(&timingStart);
 presentCalls.fetch_add(1,std::memory_order_relaxed);
 if(!inPresent && !(flags & DXGI_PRESENT_TEST)) {
   inPresent=true;
   RFGRVRRenderWindow::poll();
   RFGRVR_StereoTrace_Present();
   RFGRVR_GPUCapture_Present();
   RFGRVR_OnGameRenderFrame(self);
   RFGRVR_MapWorld_Present(self);
   RFGRVR_WristMap_Present(self);
   RFGRVR_Temporal_Present(self);
   RFGRVR_EngineProbe_Present();
    RFGRVR_EngineProbe_CorrelationPresent();
   RFGRVR_CameraDiff_Present();
   RFGRVR_DrawInGameCameraLab(self);
   RFGRVR_DesktopPresent(self);
   RFGRVR_DesktopMenu(self);
   inPresent=false;
 }
 QueryPerformanceCounter(&timingPresent);HRESULT result=orig(self,interval,flags);QueryPerformanceCounter(&timingEnd);
 frameTiming(timingStart,timingPresent,timingEnd,interval,RFGRVR_GameplayProjection_Enabled());return result;
}
static void WatchChain(IDXGISwapChain* chain) {
 if(!chain)return;
 if(gOriginalPresent)return; // single swap chain; avoid mixing originals
 void* prior=nullptr;
 gOriginalPresent=reinterpret_cast<PresentFn>((*reinterpret_cast<void***>(chain))[8]);
 if(MakeShadow(chain,RFGRVR_SwapMethods(chain),8,(void*)&HookPresent,&prior)){
    chains.fetch_add(1,std::memory_order_relaxed);
    // This is the private table just allocated by MakeShadow, never DXGI's.
    auto* privateTable=*(void***)chain;originalResize=(ResizeFn)privateTable[13];privateTable[13]=(void*)&HookResize;originalFullscreen=(FullscreenFn)privateTable[10];privateTable[10]=(void*)&HookFullscreen;
    DXGI_SWAP_CHAIN_DESC desc{};
    if(SUCCEEDED(chain->GetDesc(&desc))){RFGRVRRenderWindow::ppdSize=&RFGRVR_Temporal_PPDSize;RFGRVRRenderWindow::gameplayActive=&highResolutionScene;RFGRVRRenderWindow::resizeBuffers=&RFGRVR_ResizeRenderBuffersOnOwner;RFGRVRRenderWindow::attach(desc.OutputWindow);}
 } else installErrors.fetch_add(1,std::memory_order_relaxed);
}
static HRESULT STDMETHODCALLTYPE HookCreateSwap(IDXGIFactory* self,IUnknown* device,DXGI_SWAP_CHAIN_DESC* desc,IDXGISwapChain** chain){
 DXGI_SWAP_CHAIN_DESC windowed{};if(desc){windowed=*desc;windowed.Windowed=TRUE;desc=&windowed;}
 HRESULT hr=originalFactorySwap(self,device,desc,chain);
 if(SUCCEEDED(hr) && chain && *chain) WatchChain(*chain);
 return hr;
}
static HRESULT STDMETHODCALLTYPE HookCreateHwnd(IDXGIFactory2* self,IUnknown* device,HWND hwnd,const DXGI_SWAP_CHAIN_DESC1* desc,const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* full,IDXGIOutput* output,IDXGISwapChain1** chain){
 HRESULT hr=originalFactoryHwnd(self,device,hwnd,desc,nullptr,output,chain);
 if(SUCCEEDED(hr) && chain && *chain) WatchChain(*chain);
 return hr;
}
static void WatchFactory(ID3D11Device* device){
 if(!device)return;
 ComPtr<IDXGIDevice> dxgi;
 if(FAILED(device->QueryInterface(__uuidof(IDXGIDevice),(void**)dxgi.GetAddressOf())))return;
 ComPtr<IDXGIAdapter> adapter;
 if(FAILED(dxgi->GetAdapter(adapter.GetAddressOf())))return;
 ComPtr<IDXGIFactory> factory;
 if(FAILED(adapter->GetParent(__uuidof(IDXGIFactory),(void**)factory.GetAddressOf())))return;
 void* old=nullptr;
 originalFactorySwap=reinterpret_cast<FactoryCreateSwap>((*reinterpret_cast<void***>(factory.Get()))[10]);
 if(MakeShadow(factory.Get(),RFGRVR_FactoryMethods(factory.Get(),12),10,(void*)&HookCreateSwap,&old)){
   factories.fetch_add(1,std::memory_order_relaxed);
 }
 // Factory2 is the same COM identity but often a different interface pointer/vtable.
 ComPtr<IDXGIFactory2> factory2;
 if(SUCCEEDED(factory.As(&factory2))){
   old=nullptr;
   originalFactoryHwnd=reinterpret_cast<FactoryCreateHwnd>((*reinterpret_cast<void***>(factory2.Get()))[15]);
   if(MakeShadow(factory2.Get(),RFGRVR_FactoryMethods(factory2.Get(),25),15,(void*)&HookCreateHwnd,&old)){
     factories.fetch_add(1,std::memory_order_relaxed);
   }
 }
}
static HRESULT WINAPI HookCreateDevice(IDXGIAdapter* a,D3D_DRIVER_TYPE t,HMODULE m,UINT flags,const D3D_FEATURE_LEVEL* levels,UINT count,UINT sdk,ID3D11Device** device,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** ctx){
 HRESULT hr=originalCreate(a,t,m,flags,levels,count,sdk,device,level,ctx);
 if(SUCCEEDED(hr) && device && *device){
   RFGRVRDeferredProbe::attachDevice(*device);
   if(ctx && *ctx)RFGRVR_GPUCapture_Attach(*ctx);
   else { ID3D11DeviceContext* immediate=nullptr;(*device)->GetImmediateContext(&immediate);if(immediate){RFGRVR_GPUCapture_Attach(immediate);immediate->Release();} }
   WatchFactory(*device);
 }
 return hr;
}
}
extern "C" __declspec(dllexport) BOOL __stdcall RFGRVR_AttachRenderer(){
 RFGRVRDeferredProbe::finishNotice.store(&RFGRVR_WristMap_EndCommandList);
 HMODULE exe=GetModuleHandleW(nullptr);
 if(!exe)return FALSE;
 auto base=reinterpret_cast<BYTE*>(exe);
 auto dos=reinterpret_cast<IMAGE_DOS_HEADER*>(base);
 if(dos->e_magic!=IMAGE_DOS_SIGNATURE)return FALSE;
 auto nt=reinterpret_cast<IMAGE_NT_HEADERS32*>(base+dos->e_lfanew);
 if(nt->Signature!=IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR32_MAGIC)return FALSE;
 auto directory=nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
 if(!directory.VirtualAddress)return FALSE;
 auto imp=reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base+directory.VirtualAddress);
 for(;imp->Name;++imp){
   const char* dll=reinterpret_cast<const char*>(base+imp->Name);
   if(_stricmp(dll,"d3d11.dll")!=0 || !imp->OriginalFirstThunk)continue;
   auto names=reinterpret_cast<IMAGE_THUNK_DATA32*>(base+imp->OriginalFirstThunk);
   auto slots=reinterpret_cast<IMAGE_THUNK_DATA32*>(base+imp->FirstThunk);
   for(size_t i=0;names[i].u1.AddressOfData;++i){
     if(names[i].u1.Ordinal & IMAGE_ORDINAL_FLAG32)continue;
     auto name=reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base+names[i].u1.AddressOfData);
     if(strcmp(reinterpret_cast<const char*>(name->Name),"D3D11CreateDevice")!=0)continue;
     HMODULE d3d=GetModuleHandleW(L"d3d11.dll");if(!d3d)d3d=LoadLibraryW(L"d3d11.dll");
     auto actual=reinterpret_cast<DeviceCreate>(GetProcAddress(d3d,"D3D11CreateDevice"));
     if(!actual)return FALSE;
     DWORD oldProt=0;
     if(!VirtualProtect(&slots[i].u1.Function,sizeof(void*),PAGE_READWRITE,&oldProt))return FALSE;
     originalCreate=actual;
     auto prev=InterlockedCompareExchange(reinterpret_cast<volatile LONG*>(&slots[i].u1.Function),reinterpret_cast<LONG>(&HookCreateDevice),reinterpret_cast<LONG>(actual));
     DWORD ignored=0;VirtualProtect(&slots[i].u1.Function,sizeof(void*),oldProt,&ignored);
     return prev==reinterpret_cast<LONG>(actual);
   }
 }
 return FALSE;
}
extern "C" __declspec(dllexport) void __stdcall RFGRVR_GetRenderHookStats(LONG* factoriesOut,LONG* chainsOut,LONG* presentOut,LONG* errorsOut){
 if(factoriesOut)*factoriesOut=factories.load();if(chainsOut)*chainsOut=chains.load();
 if(presentOut)*presentOut=presentCalls.load();if(errorsOut)*errorsOut=installErrors.load();
}
