#define RFGR_TEST_USER_SETTINGS
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#define RFGR_TEST_HUD_CHANNELS
#include "../src/wrist_map_render.h"
#include <d3dcompiler.h>
#include <cassert>
static bool popup=false;static bool auxiliary=false;extern "C" bool RFGRVR_HeadCam_IsAuxiliary(){return auxiliary;}
static unsigned uiTraversals=0;static void __fastcall fakeUiDraw(void*,void*,const void*,void*,unsigned){++uiTraversals;}
using namespace RFGRVRWristMap;
static ComPtr<ID3D11DeviceContext> context;static ComPtr<ID3D11Buffer> vb;static unsigned calls=0;
static void __fastcall nativeEmit(void*,void*,unsigned type,unsigned primitives,const void* data,unsigned stride){++calls;D3D11_MAPPED_SUBRESOURCE m{};assert(SUCCEEDED(context->Map(vb.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&m)));memcpy(m.pData,data,vrwrist::vertexCount(type,primitives)*stride);context->Unmap(vb.Get(),0);UINT offset=0;auto* b=vb.Get();context->IASetVertexBuffers(0,1,&b,&stride,&offset);context->IASetPrimitiveTopology(type==3?D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST:D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);context->Draw(vrwrist::vertexCount(type,primitives),0);}
static unsigned pixel(ID3D11Device* device,ID3D11Texture2D* texture,bool corner=false,float sampleX=.5f){D3D11_TEXTURE2D_DESC d{};texture->GetDesc(&d);d.BindFlags=d.MiscFlags=0;d.Usage=D3D11_USAGE_STAGING;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> stage;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&stage)));context->CopyResource(stage.Get(),texture);D3D11_MAPPED_SUBRESOURCE m{};assert(SUCCEEDED(context->Map(stage.Get(),0,D3D11_MAP_READ,0,&m)));unsigned out=*(unsigned*)((char*)m.pData+(corner?0:d.Height/2)*m.RowPitch+(corner?0:unsigned(d.Width*sampleX))*4);context->Unmap(stage.Get(),0);return out;}
int main(){originalDraw=(Draw)&fakeUiDraw;auxiliary=true;draw(nullptr,nullptr,nullptr,nullptr,0);assert(!uiTraversals);auxiliary=false;draw(nullptr,nullptr,nullptr,nullptr,0);assert(uiTraversals==1);ComPtr<ID3D11Device> device;D3D_FEATURE_LEVEL level;HRESULT hr=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,&level,&context);assert(SUCCEEDED(hr));
 const char* shader="struct O{float4 p:SV_POSITION;float4 c:COLOR0;};O VS(float2 p:POSITION,float4 c:COLOR0){O o;o.p=float4(p,0,1);o.c=c;return o;}float4 PS(O i):SV_Target{return i.c;}";ComPtr<ID3DBlob> vsb,psb;assert(SUCCEEDED(D3DCompile(shader,strlen(shader),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&vsb,nullptr)));assert(SUCCEEDED(D3DCompile(shader,strlen(shader),nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&psb,nullptr)));ComPtr<ID3D11VertexShader> vs;ComPtr<ID3D11PixelShader> ps;device->CreateVertexShader(vsb->GetBufferPointer(),vsb->GetBufferSize(),nullptr,&vs);device->CreatePixelShader(psb->GetBufferPointer(),psb->GetBufferSize(),nullptr,&ps);context->VSSetShader(vs.Get(),nullptr,0);context->PSSetShader(ps.Get(),nullptr,0);D3D11_INPUT_ELEMENT_DESC fields[2]={{"POSITION",0,DXGI_FORMAT_R32G32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0},{"COLOR",0,DXGI_FORMAT_R8G8B8A8_UNORM,0,24,D3D11_INPUT_PER_VERTEX_DATA,0}};ComPtr<ID3D11InputLayout> layout;assert(SUCCEEDED(device->CreateInputLayout(fields,2,vsb->GetBufferPointer(),vsb->GetBufferSize(),&layout)));context->IASetInputLayout(layout.Get());
 D3D11_BUFFER_DESC bd{};bd.ByteWidth=4096;bd.Usage=D3D11_USAGE_DYNAMIC;bd.BindFlags=D3D11_BIND_VERTEX_BUFFER;bd.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;assert(SUCCEEDED(device->CreateBuffer(&bd,nullptr,&vb)));
 D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=512;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> desktop;ComPtr<ID3D11RenderTargetView> desktopView;device->CreateTexture2D(&td,nullptr,&desktop);device->CreateRenderTargetView(desktop.Get(),nullptr,&desktopView);auto* rt=desktopView.Get();context->OMSetRenderTargets(1,&rt,nullptr);D3D11_VIEWPORT viewport{0,0,512,512,0,1};context->RSSetViewports(1,&viewport);
 unsigned char renderer[0x500]{};void* commands[1]={context.Get()};void* writer[1]={commands};*(void**)(renderer+0x440)=writer;Meta meta{7,{128,128,384,384},512,512};metadata[7]=meta;Vertex q[4]{};for(int i=0;i<4;++i){q[i].x=(i&1)?384.f:128.f;q[i].y=(i&2)?384.f:128.f;q[i].color=0xff0000ff;vrwrist::mark(q[i],7);q[i].x=q[i].x*2/512-1;q[i].y=1-q[i].y*2/512;}originalEmit=(Emit)&nativeEmit;
 emit(renderer,nullptr,0,2,q,28);assert(calls==1&&channel&&drawnEpoch==7);assert(pixel(device.Get(),canvas.Get())==0xffff0000);assert(pixel(device.Get(),desktop.Get())==0xffff0000);ComPtr<ID3D11RenderTargetView> restored;context->OMGetRenderTargets(1,&restored,nullptr);assert(restored==desktopView);UINT count=1;D3D11_VIEWPORT actual{};context->RSGetViewports(&count,&actual);assert(actual.Width==512&&actual.Height==512);
 // A live wrist consumer suppresses the original HUD without dropping its map.
 channel->acknowledged=1;FLOAT black[4]{};context->ClearRenderTargetView(desktopView.Get(),black);meta.epoch=8;metadata[8]=meta;for(auto& v:q)v.z=vrwrist::Marker+8;emit(renderer,nullptr,0,2,q,28);assert(pixel(device.Get(),desktop.Get())==0&&pixel(device.Get(),canvas.Get())==0xffff0000);
 RFGRVRFactionHud::originalEmit=(RFGRVRFactionHud::Emit)&nativeEmit;RFGRVRFactionHud::Meta factionMeta{240285,{128,128,384,384},512,512};RFGRVRFactionHud::metadata[240285%16]=factionMeta;for(auto& v:q){v.z=vrwrist::Marker+240285;v.color=0xff00ff00;}RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRFactionHud::drawnEpoch==240285&&pixel(device.Get(),RFGRVRFactionHud::canvas.Get())==0xff00ff00);for(auto& v:q){v.z=vrwrist::Marker+8;v.color=0xff0000ff;}
 // Producer and independent consumer follow 0 -> 1 -> 0 without stealing.
 assert(mutex->AcquireSync(0,0)==S_OK);context->CopyResource(sharedTexture.Get(),canvas.Get());context->Flush();assert(SUCCEEDED(mutex->ReleaseSync(1)));ComPtr<ID3D11Texture2D> received;assert(SUCCEEDED(device->OpenSharedResource((HANDLE)(uintptr_t)channel->legacyShareHandle,IID_PPV_ARGS(&received))));ComPtr<IDXGIKeyedMutex> receiver;received.As(&receiver);assert(receiver->AcquireSync(1,0)==S_OK);assert(pixel(device.Get(),received.Get())==0xffff0000);assert(SUCCEEDED(receiver->ReleaseSync(0)));
 // Missing/stale wrist submission restores the ordinary HUD map.
 lastAck=channel->acknowledged;ackTick=GetTickCount()-1000;meta.epoch=9;metadata[9]=meta;for(auto& v:q)v.z=vrwrist::Marker+9;context->ClearRenderTargetView(desktopView.Get(),black);emit(renderer,nullptr,0,2,q,28);assert(pixel(device.Get(),desktop.Get())==0xffff0000);
 // The real game records UI on deferred contexts. Each wrist draw owns its
 // buffer and leaves the native allocator/IA state untouched across recording.
 ComPtr<ID3D11DeviceContext> immediate=context,deferred;assert(SUCCEEDED(device->CreateDeferredContext(0,&deferred)));context=deferred;commands[0]=context.Get();context->VSSetShader(vs.Get(),nullptr,0);context->PSSetShader(ps.Get(),nullptr,0);context->IASetInputLayout(layout.Get());context->OMSetRenderTargets(1,&rt,nullptr);context->RSSetViewports(1,&viewport);context->ClearRenderTargetView(desktopView.Get(),black);
 meta.epoch=10;metadata[10]=meta;for(auto& v:q)v.z=vrwrist::Marker+10;unsigned before=calls;emit(renderer,nullptr,0,2,q,28);assert(calls==before+1);ComPtr<ID3D11Buffer> restoredVertices;UINT restoredStride=0,restoredOffset=0;context->IAGetVertexBuffers(0,1,&restoredVertices,&restoredStride,&restoredOffset);assert(restoredVertices==vb&&restoredStride==28);
 // Many map elements share one discard; subsequent writes append safely.
 for(unsigned element=0;element<31;++element)emit(renderer,nullptr,0,2,q,28);
 PrivateVertices* uploads=nullptr;for(auto& entry:privateVertices)if(entry.context==context.Get())uploads=&entry;assert(uploads&&uploads->discards==1&&uploads->noOverwrite==31&&uploads->writeOffset==32*6*28);
 ComPtr<ID3D11CommandList> list;assert(SUCCEEDED(context->FinishCommandList(FALSE,&list)));endCommandList(context.Get());immediate->ExecuteCommandList(list.Get(),FALSE);
 // Same UI epoch in a new command list must still start with DISCARD.
 context->VSSetShader(vs.Get(),nullptr,0);context->PSSetShader(ps.Get(),nullptr,0);context->IASetInputLayout(layout.Get());context->OMSetRenderTargets(1,&rt,nullptr);context->RSSetViewports(1,&viewport);emit(renderer,nullptr,0,2,q,28);assert(uploads->discards==2&&uploads->noOverwrite==31);list.Reset();assert(SUCCEEDED(context->FinishCommandList(FALSE,&list)));endCommandList(context.Get());immediate->ExecuteCommandList(list.Get(),FALSE);context=immediate;commands[0]=context.Get();assert(pixel(device.Get(),canvas.Get())==0xffff0000&&pixel(device.Get(),desktop.Get())==0xffff0000);assert(SUCCEEDED(device->GetDeviceRemovedReason()));
 // Ammo and charge surfaces are independent, including marker ranges.
 context->VSSetShader(vs.Get(),nullptr,0);context->PSSetShader(ps.Get(),nullptr,0);context->IASetInputLayout(layout.Get());context->OMSetRenderTargets(1,&rt,nullptr);context->RSSetViewports(1,&viewport);
 RFGRVRAmmoHud::originalEmit=(RFGRVRAmmoHud::Emit)&nativeEmit;RFGRVRChargeHud::originalEmit=(RFGRVRChargeHud::Emit)&nativeEmit;
 RFGRVRAmmoHud::Meta ammoMeta{21845,{128,128,384,384},512,512};RFGRVRAmmoHud::metadata[21845%16]=ammoMeta;
 for(auto& v:q)v.z=vrwrist::Marker+21845;RFGRVRAmmoHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRAmmoHud::channel&&RFGRVRAmmoHud::drawnEpoch==21845&&pixel(device.Get(),RFGRVRAmmoHud::canvas.Get())==0xffff0000);assert(drawnEpoch==10);
 RFGRVRChargeHud::Meta chargeMeta{43689,{128,128,384,384},512,512};RFGRVRChargeHud::metadata[43689%16]=chargeMeta;
 for(auto& v:q){v.z=vrwrist::Marker+43689;v.color=0xff00ff00;}RFGRVRChargeHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRChargeHud::drawnEpoch==43689&&pixel(device.Get(),RFGRVRChargeHud::canvas.Get())==0xff00ff00);assert(pixel(device.Get(),RFGRVRAmmoHud::canvas.Get())==0xffff0000);
 // Native help notifications own an independent fourth surface.
 RFGRVRNoticeHud::originalEmit=(RFGRVRNoticeHud::Emit)&nativeEmit;
 RFGRVRNoticeHud::Meta noticeMeta{65533,{128,128,384,384},512,512};RFGRVRNoticeHud::metadata[65533%16]=noticeMeta;
 for(auto& v:q){v.z=vrwrist::Marker+65533;v.color=0xffff0000;}assert(vrwrist::epoch(q[0])==65533);
 RFGRVRWorldHud::nativeEmit=(Emit)&nativeEmit;RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);
 assert(RFGRVRNoticeHud::drawnEpoch==65533&&pixel(device.Get(),RFGRVRNoticeHud::canvas.Get())==0xff0000ff);
 assert(pixel(device.Get(),RFGRVRChargeHud::canvas.Get())==0xff00ff00&&pixel(device.Get(),RFGRVRAmmoHud::canvas.Get())==0xffff0000);
 RFGRVRMissionHud::originalEmit=(RFGRVRMissionHud::Emit)&nativeEmit;RFGRVRMissionHud::Meta meta87377{87377,{128,128,384,384},512,512};RFGRVRMissionHud::metadata[87377%16]=meta87377;
 for(auto& v:q){v.z=vrwrist::Marker+87377;v.color=0xff00ffff;}assert(vrwrist::epoch(q[0])==87377);RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRMissionHud::drawnEpoch==87377&&pixel(device.Get(),RFGRVRMissionHud::canvas.Get())==0xffffff00);
 RFGRVRHealthHud::originalEmit=(RFGRVRHealthHud::Emit)&nativeEmit;RFGRVRHealthHud::Meta meta109221{109221,{128,128,384,384},512,512};RFGRVRHealthHud::metadata[109221%16]=meta109221;
 for(auto& v:q){v.z=vrwrist::Marker+109221;v.color=0xffff00ff;}assert(vrwrist::epoch(q[0])==109221);RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRHealthHud::drawnEpoch==109221&&pixel(device.Get(),RFGRVRHealthHud::canvas.Get())==0xffff00ff);
 RFGRVRSelectionHud::originalEmit=(RFGRVRSelectionHud::Emit)&nativeEmit;RFGRVRSelectionHud::Meta selectionMeta{131065,{128,128,384,384},512,512};RFGRVRSelectionHud::metadata[131065%16]=selectionMeta;
 for(auto& v:q){v.z=vrwrist::Marker+131065;v.color=0xff00ffff;}assert(vrwrist::epoch(q[0])==131065);RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRSelectionHud::drawnEpoch==131065&&pixel(device.Get(),RFGRVRSelectionHud::canvas.Get())==0xffffff00);assert(RFGRVRHealthHud::drawnEpoch==109221);
 // Available C4 slots must survive a native blend that squares alpha.
 D3D11_BLEND_DESC blendDesc{};auto& blendRt=blendDesc.RenderTarget[0];blendRt.BlendEnable=TRUE;blendRt.SrcBlend=D3D11_BLEND_SRC_ALPHA;blendRt.DestBlend=D3D11_BLEND_INV_SRC_ALPHA;blendRt.BlendOp=D3D11_BLEND_OP_ADD;blendRt.SrcBlendAlpha=D3D11_BLEND_SRC_ALPHA;blendRt.DestBlendAlpha=D3D11_BLEND_INV_SRC_ALPHA;blendRt.BlendOpAlpha=D3D11_BLEND_OP_ADD;blendRt.RenderTargetWriteMask=15;ComPtr<ID3D11BlendState> nativeBlend;assert(SUCCEEDED(device->CreateBlendState(&blendDesc,&nativeBlend)));context->OMSetBlendState(nativeBlend.Get(),nullptr,~0u);
 chargeMeta.epoch=43690;RFGRVRChargeHud::metadata[43690%16]=chargeMeta;for(auto& v:q){v.z=vrwrist::Marker+43690;v.color=0x2600ff00;}RFGRVRChargeHud::emit(renderer,nullptr,0,2,q,28);unsigned slotPixel=pixel(device.Get(),RFGRVRChargeHud::canvas.Get());assert((slotPixel>>24)>=89&&(slotPixel>>24)<=91);RFGRVRHealthHud::Meta healthAlpha{109222,{128,128,384,384},512,512};RFGRVRHealthHud::metadata[109222%16]=healthAlpha;for(auto& v:q){v.z=vrwrist::Marker+109222;v.color=0x8000ff00;}RFGRVRHealthHud::emit(renderer,nullptr,0,2,q,28);unsigned healthPixel=pixel(device.Get(),RFGRVRHealthHud::canvas.Get());assert((healthPixel>>24)>=127&&(healthPixel>>24)<=129);
 ComPtr<ID3D11BlendState> restoredBlend;context->OMGetBlendState(&restoredBlend,nullptr,nullptr);assert(restoredBlend==nativeBlend);context->OMSetBlendState(nullptr,nullptr,~0u);
 // The highest marker range routes native overheat independently of menu/health.
 RFGRVROverheatHud::originalEmit=(RFGRVROverheatHud::Emit)&nativeEmit;RFGRVROverheatHud::Meta heat{174753,{128,128,384,384},512,512};RFGRVROverheatHud::metadata[174753%16]=heat;context->OMSetBlendState(nativeBlend.Get(),nullptr,~0u);for(auto& v:q){v.z=vrwrist::Marker+174753;v.color=0x8000ff00;}RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVROverheatHud::drawnEpoch==174753);unsigned hp=pixel(device.Get(),RFGRVROverheatHud::canvas.Get());assert((hp>>24)>=127&&(hp>>24)<=129);context->OMSetBlendState(nullptr,nullptr,~0u);
 // Menu capture contains only foreground UI: uncovered pixels remain transparent.
 RFGRVRMenuHud::originalEmit=(RFGRVRMenuHud::Emit)&nativeEmit;RFGRVRMenuHud::Meta menuMeta{152909,{0,0,512,512},512,512};RFGRVRMenuHud::metadata[152909%16]=menuMeta;
 context->OMSetBlendState(nativeBlend.Get(),nullptr,~0u);for(auto& v:q){v.z=vrwrist::Marker+152909;v.color=0x80ff0000;}RFGRVRMenuHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRMenuHud::channel&&RFGRVRMenuHud::drawnEpoch==152909);unsigned menuPixel=pixel(device.Get(),RFGRVRMenuHud::canvas.Get());assert((menuPixel>>24)>=127&&(menuPixel>>24)<=129&&pixel(device.Get(),RFGRVRMenuHud::canvas.Get(),true)==0);D3D11_TEXTURE2D_DESC menuDesc{};RFGRVRMenuHud::canvas->GetDesc(&menuDesc);assert(menuDesc.Width==1024&&menuDesc.Height==1024);context->OMSetBlendState(nullptr,nullptr,~0u);
 // Distant menu video and foreground UI own separate complete transparent canvases.
 RFGRVRMainVideo::originalEmit=(RFGRVRMainVideo::Emit)&nativeEmit;RFGRVRMainUI::originalEmit=(RFGRVRMainUI::Emit)&nativeEmit;RFGRVRMainVideo::Meta videoMeta{196597,{0,0,512,512},512,512};RFGRVRMainVideo::metadata[196597%16]=videoMeta;RFGRVRMainUI::Meta uiMeta{218441,{0,0,512,512},512,512};RFGRVRMainUI::metadata[218441%16]=uiMeta;for(auto& v:q){v.z=vrwrist::Marker+196597;v.color=0xff0000ff;}RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRMainVideo::drawnEpoch==196597);context->OMSetBlendState(nativeBlend.Get(),nullptr,~0u);for(auto& v:q){v.z=vrwrist::Marker+218441;v.color=0x8000ff00;}RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRMainUI::drawnEpoch==218441);assert((pixel(device.Get(),RFGRVRMainUI::canvas.Get())>>24)>=127);assert(pixel(device.Get(),RFGRVRMainUI::canvas.Get(),true)==0);assert(RFGRVRMainVideo::drawnEpoch==196597);context->OMSetBlendState(nullptr,nullptr,~0u);
 // A live world-space locker panel replaces the screen-space copy. Its
 // private transparent canvas remains populated, and consumer loss restores
 // the complete native menu instead of leaving an invisible interface.
 RFGRVRMenuLayout::popupActive=true;popup=true;RFGRVRMainUI::channel->acknowledged=1;uiMeta.epoch=218442;RFGRVRMainUI::metadata[218442%16]=uiMeta;
 context->ClearRenderTargetView(desktopView.Get(),black);
 for(auto& v:q){v.z=vrwrist::Marker+218442;v.color=0xff00ff00;}
 RFGRVRMainUI::emit(renderer,nullptr,0,2,q,28);
 assert(pixel(device.Get(),desktop.Get())==0&&pixel(device.Get(),RFGRVRMainUI::canvas.Get())==0xff00ff00);
 RFGRVRMainUI::lastAck=1;RFGRVRMainUI::ackTick=GetTickCount()-1000;
 RFGRVRMainUI::emit(renderer,nullptr,0,2,q,28);assert(pixel(device.Get(),desktop.Get())==0xff00ff00);
 RFGRVRMainUI::channel->acknowledged=2;RFGRVRMenuLayout::popupActive=false;popup=false;context->ClearRenderTargetView(desktopView.Get(),black);
 RFGRVRMainUI::emit(renderer,nullptr,0,2,q,28);assert(pixel(device.Get(),desktop.Get())==0xff00ff00);
 // Multiple foreground groups in one UI frame must accumulate, not erase earlier groups.
 menuMeta.epoch=152910;RFGRVRMenuHud::metadata[152910%16]=menuMeta;
 auto menuBatch=[&](float lo,float hi,unsigned color){Vertex v[4]{};for(unsigned n=0;n<4;++n){v[n].x=(n&1)?hi:lo;v[n].y=(n&2)?384.f:128.f;v[n].color=color;vrwrist::mark(v[n],152910);v[n].x=v[n].x*2/512-1;v[n].y=1-v[n].y*2/512;}RFGRVRMenuHud::emit(renderer,nullptr,0,2,v,28);};menuBatch(32,224,0xff0000ff);menuBatch(288,480,0xff00ff00);assert(pixel(device.Get(),RFGRVRMenuHud::canvas.Get(),false,.25f)==0xffff0000&&pixel(device.Get(),RFGRVRMenuHud::canvas.Get(),false,.75f)==0xff00ff00);
 // A text-heavy menu batch can exceed the wrist's 64KB upload budget.
 menuMeta.epoch=152911;RFGRVRMenuHud::metadata[152911%16]=menuMeta;std::vector<Vertex> largeMenu;for(unsigned n=0;n<1000;++n){Vertex triangle[3]{};for(unsigned j=0;j<3;++j){triangle[j].x=j==1?400.f:112.f;triangle[j].y=j==2?400.f:112.f;triangle[j].color=0xffffffff;vrwrist::mark(triangle[j],152911);triangle[j].x=triangle[j].x*2/512-1;triangle[j].y=1-triangle[j].y*2/512;}largeMenu.insert(largeMenu.end(),triangle,triangle+3);}assert(largeMenu.size()*sizeof(Vertex)>65536);RFGRVRMenuHud::emit(renderer,nullptr,3,1000,largeMenu.data(),28);assert(RFGRVRMenuHud::drawnEpoch==152911&&pixel(device.Get(),RFGRVRMenuHud::canvas.Get(),false,.4f)==0xffffffff);
 // The native optic export preserves rifle identity and owns a reference;
 // a Rail Driver request must never reuse a Sniper HUD texture.
 menuMeta.nativeKind=0;RFGRVRMenuHud::metadata[152911%16]=menuMeta;RFGRVRMenuHud::emit(renderer,nullptr,3,1000,largeMenu.data(),28);
 {ComPtr<ID3D11ShaderResourceView> nativeOptic;nativeOptic.Attach(RFGRVRMenuHud::scopeOverlay(0));assert(nativeOptic&&RFGRVRMenuHud::scopeOverlay(1)==nullptr);}
 RFGRVRMenuHud::scopeDrawTick=GetTickCount()-1000;assert(RFGRVRMenuHud::scopeOverlay(0)==nullptr);
 // Foreign markers pass untouched to the next capture, never unmarked early.
 RFGRVRWorldHud::nativeEmit=(Emit)&nativeEmit;unsigned foreignBefore=calls;RFGRVRWorldHud::emit(renderer,nullptr,0,2,q,28);assert(calls==foreignBefore+1);
 // A pending allocation is marked before its native batch can consume it.
 Vertex pendingQuad[4]{};for(int i=0;i<4;++i){pendingQuad[i].color=0xffffffff;pendingQuad[i].x=(i&1)?500.f:200.f;pendingQuad[i].y=(i&2)?500.f:200.f;}inside=true;activeGroup=false;pending={pendingQuad,4,0x80000202};pendingValid=true;completePending();assert(boundsReady&&!vrwrist::epoch(pendingQuad[0]));activeGroup=true;currentMeta.epoch=12;pendingValid=true;completePending();assert(vrwrist::epoch(pendingQuad[0])==12);inside=false;

 // Invisible full-screen geometry must never expand a visible meter's crop.
 {Vertex invisible[4]{};for(unsigned i=0;i<4;++i){invisible[i].x=(i&1)?3328.f:0;invisible[i].y=(i&2)?3472.f:0;}
 RFGRVRHealthHud::inside=true;RFGRVRHealthHud::activeGroup=false;RFGRVRHealthHud::groupBoundsReady=false;RFGRVRHealthHud::pending={invisible,4,0x202};RFGRVRHealthHud::pendingValid=true;RFGRVRHealthHud::completePending();assert(!RFGRVRHealthHud::groupBoundsReady);
 RFGRVRHealthHud::currentMeta.width=3328;RFGRVRHealthHud::currentMeta.height=3472;for(auto& v:invisible)v.color=0xffffffff;RFGRVRHealthHud::pendingValid=true;RFGRVRHealthHud::completePending();assert(!RFGRVRHealthHud::groupBoundsReady);
 for(auto& v:invisible){v.color=0xffffffff;v.x=200+v.x*.01f;v.y=100+v.y*.01f;}RFGRVRHealthHud::pendingValid=true;RFGRVRHealthHud::completePending();assert(RFGRVRHealthHud::groupBoundsReady&&RFGRVRHealthHud::groupBounds.right<250);RFGRVRHealthHud::inside=false;}
 // Red Faction and EDF notifications have independent marker ranges/textures.
 {RFGRVRMoraleHud::originalEmit=(RFGRVRMoraleHud::Emit)&nativeEmit;RFGRVRMoraleHud::Meta morale{262130,{128,128,384,384},512,512};RFGRVRMoraleHud::metadata[262130%16]=morale;for(auto& v:q){v.z=vrwrist::Marker+262130;v.color=0xff0000ff;}assert(vrwrist::epoch(q[0])==262130);RFGRVRMoraleHud::emit(renderer,nullptr,0,2,q,28);assert(RFGRVRMoraleHud::drawnEpoch==262130&&RFGRVRMoraleHud::canvas.Get()!=RFGRVRFactionHud::canvas.Get());}
 puts("PASS: map isolation, fallback HUD, wrist suppression, render-target restoration and keyed handoff");
}

extern "C" bool RFGRVR_HeadCam_MenuScene(){return false;}

extern "C" bool RFGRVR_HeadCam_PopupMenu(){return popup;}
