#include <cassert>
#include <cmath>
#include "../src/native_stereo.h"
using namespace rfgrvr;
struct Sink:FrameSink {int n=0;bool renderEye(unsigned eye,const Matrix4&,const Matrix4&){assert(eye==(unsigned)n);++n;return true;}};
int main(){StereoFrame f{};for(int i=0;i<2;i++){f.eyes[i].tracked.q={0,0,0,1};f.eyes[i].tracked.p={i?0.032f:-0.032f,0,0};f.eyes[i].fovLeft=-0.8f;f.eyes[i].fovRight=0.8f;f.eyes[i].fovUp=0.8f;f.eyes[i].fovDown=-0.8f;}Sink s;assert(renderStereo(f,s));assert(s.n==2);assert(view(f.eyes[0]).m[12]!=view(f.eyes[1]).m[12]);f.eyes[1].tracked.q={0,0,0,0};assert(!renderStereo(f,s));assert(s.n==2);return 0;}
