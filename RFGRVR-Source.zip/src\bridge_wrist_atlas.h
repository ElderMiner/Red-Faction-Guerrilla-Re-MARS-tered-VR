#pragma once
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
struct WristAtlas {
 template<class T> using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Texture2D> texture;Ptr<ID3D11RenderTargetView> target;Ptr<ID3D11VertexShader> vs;Ptr<ID3D11PixelShader> ps;Ptr<ID3D11SamplerState> sampler;Ptr<ID3D11RasterizerState> raster;Ptr<ID3D11DepthStencilState> depth;
 struct View{Ptr<ID3D11Texture2D> texture;Ptr<ID3D11ShaderResourceView> view;};View views[7];
 bool init(ID3D11Device* d){if(texture)return true;const char shader[]=R"(Texture2D t:register(t0);SamplerState s:register(s0);struct O{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};O VS(uint id:SV_VertexID){O o;o.uv=float2((id<<1)&2,id&2);o.p=float4(o.uv*float2(2,-2)+float2(-1,1),0,1);return o;}float4 PS(O i):SV_Target{return t.Sample(s,i.uv);})";
 Ptr<ID3DBlob> v,p;if(FAILED(D3DCompile(shader,sizeof(shader),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&v,nullptr))||FAILED(D3DCompile(shader,sizeof(shader),nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&p,nullptr)))return false;
 if(FAILED(d->CreateVertexShader(v->GetBufferPointer(),v->GetBufferSize(),nullptr,&vs))||FAILED(d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,&ps)))return false;
 D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.MaxLOD=D3D11_FLOAT32_MAX;if(FAILED(d->CreateSamplerState(&sd,&sampler)))return false;
 D3D11_RASTERIZER_DESC rd{};rd.FillMode=D3D11_FILL_SOLID;rd.CullMode=D3D11_CULL_NONE;rd.DepthClipEnable=TRUE;if(FAILED(d->CreateRasterizerState(&rd,&raster)))return false;
 D3D11_DEPTH_STENCIL_DESC ds{};if(FAILED(d->CreateDepthStencilState(&ds,&depth)))return false;
 D3D11_TEXTURE2D_DESC td{};td.Width=768;td.Height=944;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;Ptr<ID3D11Texture2D> next;if(FAILED(d->CreateTexture2D(&td,nullptr,&next))||FAILED(d->CreateRenderTargetView(next.Get(),nullptr,&target)))return false;texture=next;return true;}
 void draw(ID3D11Device* d,ID3D11DeviceContext* c,unsigned slot,ID3D11Texture2D* source,float x,float y,float w,float h){if(!source||slot>=7)return;auto& v=views[slot];if(v.texture.Get()!=source){v={};if(FAILED(d->CreateShaderResourceView(source,nullptr,&v.view)))return;v.texture=source;}D3D11_VIEWPORT vp{x,y,w,h,0,1};c->RSSetViewports(1,&vp);auto* r=target.Get();c->OMSetRenderTargets(1,&r,nullptr);c->OMSetBlendState(nullptr,nullptr,~0u);c->OMSetDepthStencilState(depth.Get(),0);c->RSSetState(raster.Get());c->IASetInputLayout(nullptr);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);c->VSSetShader(vs.Get(),nullptr,0);c->PSSetShader(ps.Get(),nullptr,0);auto* view=v.view.Get();auto* sample=sampler.Get();c->PSSetShaderResources(0,1,&view);c->PSSetSamplers(0,1,&sample);c->Draw(3,0);view=nullptr;c->PSSetShaderResources(0,1,&view);}
};
