#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include "vr_arm_math.h"
namespace vrfoveation {
inline vrarm::V rotate(const float q[4],vrarm::V v){using namespace vrarm;V a{q[0],q[1],q[2]};return add(v,add(mul(cross(a,v),2*q[3]),mul(cross(a,cross(a,v)),2)));}
inline bool direction(const float eye[4],const float gaze[4],vrarm::V& out){float n=0,m=0;for(int i=0;i<4;++i){if(!std::isfinite(eye[i])||!std::isfinite(gaze[i]))return false;n+=eye[i]*eye[i];m+=gaze[i]*gaze[i];}if(fabsf(n-1)>.05f||fabsf(m-1)>.05f)return false;float inverse[4]={-eye[0],-eye[1],-eye[2],eye[3]};auto local=rotate(inverse,rotate(gaze,{0,0,-1}));out={local.x,local.y,-local.z};return out.z>.1f;}
inline bool pattern(unsigned width,unsigned height,const float projection[4],vrarm::V gaze,std::vector<unsigned char>& pixels){
 if(width<16||height<16||width>8192||height>8192||!vrarm::finite(gaze)||gaze.z<=0)return false;
 for(unsigned i=0;i<4;++i)if(!std::isfinite(projection[i]))return false;if(projection[0]<=0||projection[1]<=0)return false;
 unsigned w=(width+15)/16,h=(height+15)/16;pixels.resize(w*h);gaze=vrarm::unit(gaze);constexpr float inner=.970295726f,outer=.882947593f; // 14 and 28 degrees.
 for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x){float px=(std::min)(float(width)-.5f,x*16.f+8),py=(std::min)(float(height)-.5f,y*16.f+8);vrarm::V ray{(2*px/width-1-projection[2])/projection[0],(1-2*py/height-projection[3])/projection[1],1};float c=vrarm::dot(vrarm::unit(ray),gaze);pixels[y*w+x]=c>=inner?0:c>=outer?1:2;}
 return true;
}
inline bool eligible(bool frame,bool auxiliary,bool color,bool depth,bool depthEnabled,bool worldDepthTest,float vw,float vh,unsigned w,unsigned h){return frame&&!auxiliary&&color&&depth&&depthEnabled&&worldDepthTest&&fabsf(vw-w)<1&&fabsf(vh-h)<1;}
}
