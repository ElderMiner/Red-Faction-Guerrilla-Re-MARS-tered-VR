#pragma once
#include "vr_arm_math.h"
#include <algorithm>
struct RFGRVRChargeTrim {float rotation[3]{},position[3]{};
 void adjust(unsigned axis,bool rotate,int direction){if(axis>=3)return;if(rotate)rotation[axis]=std::remainder(rotation[axis]+direction*2.f,360.f);else position[axis]=(std::max)(-1.f,(std::min)(1.f,position[axis]+direction*.01f));}
 vrarm::Pose apply(vrarm::Pose pose,vrarm::M frame,vrarm::V grip,vrarm::V hand)const{using namespace vrarm;M basis=pose.b;for(unsigned a=0;a<3;++a)basis=turnAround(basis,a==0?basis.r:a==1?basis.u:basis.f,rotation[a]*.01745329252f);return {basis,add(sub(hand,world(basis,grip)),world(frame,{position[0],position[1],position[2]}))};}
};

