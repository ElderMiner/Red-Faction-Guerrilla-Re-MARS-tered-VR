#pragma once
#include <cmath>
namespace vrarm {
struct V {float x,y,z;};struct M {V r,u,f;};struct Pose {M b;V p;};
inline V add(V a,V b){return {a.x+b.x,a.y+b.y,a.z+b.z};}inline V sub(V a,V b){return {a.x-b.x,a.y-b.y,a.z-b.z};}inline V mul(V a,float s){return {a.x*s,a.y*s,a.z*s};}
inline float dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}inline V cross(V a,V b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}inline float length(V a){return sqrtf(dot(a,a));}
inline bool finite(V a){return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z);}
inline V unit(V a,V fallback={1,0,0}){float n=length(a);return n>1e-6f&&std::isfinite(n)?mul(a,1/n):fallback;}
inline V world(M m,V v){return add(add(mul(m.r,v.x),mul(m.u,v.y)),mul(m.f,v.z));}
inline V local(M m,V v){return {dot(m.r,v),dot(m.u,v),dot(m.f,v)};}
inline M compose(M frame,M b){return {world(frame,b.r),world(frame,b.u),world(frame,b.f)};}
inline M relative(M frame,M b){return {local(frame,b.r),local(frame,b.u),local(frame,b.f)};}
inline bool valid(M m){return finite(m.r)&&finite(m.u)&&finite(m.f)&&fabsf(dot(m.r,m.r)-1)<.12f&&fabsf(dot(m.u,m.u)-1)<.12f&&fabsf(dot(m.f,m.f)-1)<.12f&&fabsf(dot(m.r,m.u))<.08f&&fabsf(dot(m.r,m.f))<.08f&&fabsf(dot(m.u,m.f))<.08f;}
inline V rotateTo(V v,V from,V to){from=unit(from);to=unit(to);float c=dot(from,to);if(c>.99999f)return v;
 V axis=cross(from,to);float s=length(axis);if(s<1e-5f){axis=unit(cross(from,fabsf(from.y)<.8f?V{0,1,0}:V{1,0,0}));return sub(mul(axis,2*dot(axis,v)),v);}axis=mul(axis,1/s);return add(add(mul(v,c),mul(cross(axis,v),s)),mul(axis,dot(axis,v)*(1-c)));}
inline M rotateTo(M m,V from,V to){return {rotateTo(m.r,from,to),rotateTo(m.u,from,to),rotateTo(m.f,from,to)};}
inline V turnAround(V v,V axis,float angle){axis=unit(axis);float c=cosf(angle),s=sinf(angle);return add(add(mul(v,c),mul(cross(axis,v),s)),mul(axis,dot(axis,v)*(1-c)));}
inline M turnAround(M b,V axis,float angle){return {turnAround(b.r,axis,angle),turnAround(b.u,axis,angle),turnAround(b.f,axis,angle)};}
inline float axialRoll(M from,M to,V axis){
 axis=unit(axis);V candidates[3]={from.r,from.u,from.f},targets[3]={to.r,to.u,to.f};int best=0;float score=-1;
 for(int i=0;i<3;++i){float n=1-dot(candidates[i],axis)*dot(candidates[i],axis);if(n>score){score=n;best=i;}}
 V a=sub(candidates[best],mul(axis,dot(candidates[best],axis))),b=sub(targets[best],mul(axis,dot(targets[best],axis)));
 if(length(a)<.001f||length(b)<.001f)return 0;a=unit(a);b=unit(b);return atan2f(dot(axis,cross(a,b)),dot(a,b));
}
inline Pose segmentHelper(const Pose& oldStart,const Pose& oldEnd,const Pose& helper,const Pose& newStart,const Pose& newEnd,bool distributeRoll){
 V oldSegment=sub(oldEnd.p,oldStart.p),newSegment=sub(newEnd.p,newStart.p);float n=dot(oldSegment,oldSegment);if(n<.0001f)return helper;
 float t=dot(sub(helper.p,oldStart.p),oldSegment)/n;if(t<0)t=0;if(t>1)t=1;
 V radial=sub(sub(helper.p,oldStart.p),mul(oldSegment,t));Pose out{compose(newStart.b,relative(oldStart.b,helper.b)),add(add(newStart.p,mul(newSegment,t)),world(newStart.b,local(oldStart.b,radial)))};
 if(distributeRoll){M predictedEnd=compose(newStart.b,relative(oldStart.b,oldEnd.b));out.b=turnAround(out.b,newSegment,axialRoll(predictedEnd,newEnd.b,newSegment)*t);}
 return out;
}
inline float calibratedReachScale(float span,float shoulderWidth,float upper,float lower){
 const float native=upper+lower;
 if(!std::isfinite(span)||!std::isfinite(shoulderWidth)||span<.6f||span>4.f||shoulderWidth<.1f||shoulderWidth>1.f||native<.16f||native>2.f)return 1;
 const float ratio=(span-shoulderWidth)*.5f/native;
 return ratio<.7f?.7f:(ratio>1.6f?1.6f:ratio);
}
inline bool solve(V shoulder,V elbow,V wrist,V target,V pole,V& newElbow,V& newWrist){
 float upper=length(sub(elbow,shoulder)),lower=length(sub(wrist,elbow));if(upper<.08f||lower<.08f||upper>1||lower>1||!finite(target))return false;
 V delta=sub(target,shoulder);float reach=length(delta);if(reach<.01f)return false;V direction=mul(delta,1/reach);
 float hi=upper+lower-.002f,lo=fabsf(upper-lower)+.002f;float d=reach<lo?lo:(reach>hi?hi:reach);
 V bend=sub(pole,mul(direction,dot(pole,direction)));if(length(bend)<.001f)bend=cross(direction,fabsf(direction.y)<.8f?V{0,1,0}:V{1,0,0});bend=unit(bend);
 float along=(upper*upper-lower*lower+d*d)/(2*d),height2=upper*upper-along*along;if(height2<0)height2=0;
 newElbow=add(shoulder,add(mul(direction,along),mul(bend,sqrtf(height2))));newWrist=add(shoulder,mul(direction,d));return finite(newElbow)&&finite(newWrist);
}
inline bool solveTracked(V shoulder,V elbow,V wrist,V target,V pole,V& newElbow,V& newWrist){
 float upper=length(sub(elbow,shoulder)),lower=length(sub(wrist,elbow)),distance=length(sub(target,shoulder));
 if(!finite(target)||upper<.08f||lower<.08f||distance<.01f||distance>3.5f)return false;
 float extension=(distance+.004f)/(upper+lower);if(extension<1)extension=1;
 V fittedElbow=add(shoulder,mul(sub(elbow,shoulder),extension)),fittedWrist=add(fittedElbow,mul(sub(wrist,elbow),extension));
 // Tracked hands are constraints. Extend the visual chain instead of pulling
 // a controller back to the original character's reach limit.
 if(!solve(shoulder,fittedElbow,fittedWrist,target,pole,newElbow,newWrist))return false;
 newWrist=target;return true;
}

inline Pose cuffHelper(const Pose& oldStart,const Pose& oldEnd,const Pose& helper,const Pose& newStart,const Pose& newEnd){
 Pose out=segmentHelper(oldStart,oldEnd,helper,newStart,newEnd,false);
 V oldAxis=sub(oldEnd.p,oldStart.p),axis=sub(newEnd.p,newStart.p);float n=dot(oldAxis,oldAxis);if(n<.0001f)return out;
 float t=dot(sub(helper.p,oldStart.p),oldAxis)/n;float blend=fmaxf(0.f,fminf(.5f,t));
 M expected=compose(newStart.b,relative(oldStart.b,oldEnd.b));float angle=axialRoll(expected,newEnd.b,axis)*blend;
 out.b=turnAround(out.b,axis,angle);V center=add(newStart.p,mul(axis,t));out.p=add(center,turnAround(sub(out.p,center),axis,angle));return out;
}
}
