#pragma once
#include "vr_arm_math.h"
#include <cstdio>
struct RFGRVRElbowProfile {
 struct Node {float feature[10]{},weight[2]{};};Node nodes[48]{};unsigned count=0,version=1;
 bool load(const char* path){
  FILE* file=nullptr;if(fopen_s(&file,path,"r")||!file)return false;
  RFGRVRElbowProfile next;unsigned version=0;
  bool ok=fscanf_s(file,"RFGRVR_ELBOW_PROFILE %u %u",&version,&next.count)==2&&(version==1||version==2)&&next.count>0&&next.count<=48;
  if(ok)for(unsigned i=0;i<next.count&&ok;++i){for(float& value:next.nodes[i].feature)if(fscanf_s(file,"%f",&value)!=1||!std::isfinite(value)||fabsf(value)>4){ok=false;break;}
   for(float& value:next.nodes[i].weight)if(fscanf_s(file,"%f",&value)!=1||!std::isfinite(value)||fabsf(value)>32){ok=false;break;}}
  fclose(file);next.version=version;if(ok)*this=next;return ok;
 }
 bool infer(bool positiveSide,vrarm::V axis,float distance,vrarm::M controller,vrarm::V& bend)const{
  using namespace vrarm;if(!count||count>48||!finite(axis)||!valid(controller)||!std::isfinite(distance))return false;
  if(!positiveSide){axis.x=-axis.x;controller.r={controller.r.x,-controller.r.y,-controller.r.z};controller.f.x=-controller.f.x;}
  float feature[10]={axis.x,axis.y,axis.z,distance,controller.r.x,controller.r.y,controller.r.z,controller.f.x,controller.f.y,controller.f.z};
  float prediction[2]{},nearest=1e9f,distances[48]{};
  for(unsigned i=0;i<count;++i){float d=0;for(unsigned j=0;j<10;++j){float scale=j==3?2.f:j>=4?(version==2?0.f:.35f):1.f;float delta=(feature[j]-nodes[i].feature[j])*scale;d+=delta*delta;}distances[i]=d;if(d<nearest)nearest=d;}
  // Keep the recorded swivel's reference frame, but do not average distant arm poses.
  for(unsigned i=0;i<count;++i){float d=distances[i];if(version==2&&d>nearest+.06f)continue;float kernel=expf(version==2?-(d-nearest)/.025f:-d/.25f);for(unsigned j=0;j<2;++j)prediction[j]+=kernel*nodes[i].weight[j];}
  V reference{.65f,-1.f,-.15f};reference=unit(sub(reference,mul(axis,dot(reference,axis))),{1,0,0});
  float confidence=std::fmax(0.f,1.f-nearest/.6f),angle=atan2f(prediction[1],prediction[0]);if(version==1)angle=std::fmax(-1.4f,std::fmin(1.4f,angle))*confidence;
  bend=turnAround(reference,axis,angle);
  if(version==2){V relaxed=unit(sub(V{.15f,-1,-.15f},mul(axis,dot(V{.15f,-1,-.15f},axis))),reference);bend=unit(add(mul(relaxed,1-confidence),mul(bend,confidence)),relaxed);}
  if(!positiveSide)bend.x=-bend.x;return finite(bend);
 }
};
