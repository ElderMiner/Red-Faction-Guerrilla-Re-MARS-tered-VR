#pragma once
#include "vr_arm_math.h"
#include <cstdint>
#include <algorithm>
// Filter animation-space targets, never the world/player root or tracked hands.
// Both eyes reuse the same result for a published tracking sample.
struct RFGRVRLegStability {
 uintptr_t owner=0;uint32_t sample=0;double seconds=0;bool ready=false;vrarm::V foot[2]{};
 void reset(){*this={};}
 void update(uintptr_t id,uint32_t frame,double now,vrarm::V targets[2]){
  using namespace vrarm;if(!id||!finite(targets[0])||!finite(targets[1])||!std::isfinite(now)){reset();return;}
  if(ready&&id==owner&&frame==sample){targets[0]=foot[0];targets[1]=foot[1];return;}
  double dt=now-seconds;bool continuous=ready&&id==owner&&dt>0&&dt<=.1&&length(sub(targets[0],foot[0]))<.5f&&length(sub(targets[1],foot[1]))<.5f;
  float alpha=continuous?1-expf(-float(dt)/.025f):1;
  for(int i=0;i<2;++i){foot[i]=continuous?add(foot[i],mul(sub(targets[i],foot[i]),alpha)):targets[i];targets[i]=foot[i];}
  ready=true;owner=id;sample=frame;seconds=now;
 }
};

// One locomotion phase per player/sample; rig-specific goals are never cached.
struct RFGRVRStableGait {
 uintptr_t owner=0;uint32_t sample=0;double seconds=0;vrarm::V previous{},velocity{};float phase=0,weight=0;bool ready=false,moving=false;
 void reset(){*this={};}
 void update(uintptr_t id,uint32_t frame,double now,vrarm::V position,float scale){
  using namespace vrarm;if(!id||!finite(position)||!std::isfinite(now)||!std::isfinite(scale)||scale<.1f){reset();return;}
  if(ready&&id==owner&&frame==sample)return;
  double dt=now-seconds;V delta=sub(position,previous);delta.y=0;
  bool continuous=ready&&id==owner&&dt>0&&dt<.15&&length(delta)<.75f*scale;
  if(!continuous){velocity={};phase=weight=0;moving=false;}
  else{float alpha=1-expf(-float(dt)/.085f);V v=mul(delta,1.f/float(dt));velocity=add(velocity,mul(sub(v,velocity),alpha));float speed=length(velocity)/scale;
   moving=speed>(moving?.08f:.16f);float target=moving?(std::min)(1.f,speed/.8f):0;weight+=(target-weight)*(1-expf(-float(dt)/.12f));
   if(moving)phase=std::remainder(phase+length(delta)/scale*7.f,6.283185307f);
  }
  owner=id;sample=frame;seconds=now;previous=position;ready=true;
 }
 vrarm::V offset(unsigned side,vrarm::M facing,float scale)const{
  using namespace vrarm;V direction=local(facing,unit(velocity,{0,0,1}));direction.y=0;direction=unit(direction,{0,0,1});float swing=phase+(side?3.141592654f:0),stride=.18f*scale*weight;
  V out=mul(direction,sinf(swing)*stride);out.y=(std::max)(0.f,cosf(swing))*.055f*scale*weight;return out;
 }
};
