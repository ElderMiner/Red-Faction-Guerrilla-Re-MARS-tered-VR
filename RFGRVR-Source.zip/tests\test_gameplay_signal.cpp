#include "../src/vr_gameplay_signal.h"
#include <cassert>
int main(){RFGRVRGameplaySignal signal;
 assert(!signal.update(false,100));assert(signal.update(true,200));
 assert(signal.update(false,550));assert(signal.update(false,1600)); // short head-update gaps don't resize
 assert(signal.update(true,1650));assert(signal.update(false,3000));assert(!signal.update(false,3150)); // real menu settles
 assert(signal.update(true,3200));assert(!signal.update(false,10)); // clock reset safe
}
