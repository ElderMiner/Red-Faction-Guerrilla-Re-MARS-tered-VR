#include "../src/vr_elbow_estimator.h"
#include <cassert>
using namespace vrarm;
int main(){
 M identity{{1,0,0},{0,1,0},{0,0,1}};
 RFGRVRElbowEstimator left,right;V ls{-.2f,1.4f,0},rs{.2f,1.4f,0};Pose lh{identity,{-.3f,1.1f,.4f}},rh{identity,{.3f,1.1f,.4f}};
 V l=left.update(0,ls,lh,1.f/90),r=right.update(1,rs,rh,1.f/90);
 assert(l.x<0&&r.x>0&&l.y<0&&r.y<0);
 assert(fabsf(dot(l,unit(sub(lh.p,ls))))<.0001f);
 V previous=r;rh.b=turnAround(identity,{0,0,1},3.14159265f);r=right.update(1,rs,rh,1.f/90);
 assert(length(sub(r,previous))<.15f); // wrist roll cannot snap the elbow
 for(int i=0;i<200;++i){float t=i/199.f;rh.p={.3f-.4f*t,.9f+.9f*t,.4f};V pole=right.update(1,rs,rh,1.f/90),elbow{},wrist{};
  assert(finite(pole)&&fabsf(length(pole)-1)<.001f);
  assert(solveTracked(rs,{.5f,1.4f,0},{.8f,1.4f,0},rh.p,pole,elbow,wrist));
  assert(length(sub(wrist,rh.p))<.00001f); // filtering never delays the hand
 }
 // Reacquisition starts from the current anatomical solution.
 rh.p={.6f,1.4f,.3f};assert(finite(right.update(1,rs,rh,1)));
 RFGRVRElbowProfile profile;assert(profile.load("build-check/RFGRVR-elbow-profile.txt")&&profile.count==48);
 // Mirrored left pose produces the mirrored right elbow, and distant unseen
 // input falls back to the anatomical bend instead of extrapolating weights.
 V axis=unit(V{.2f,-.3f,.5f}),rb{},lb{};M mirrored{{1,0,0},{0,1,0},{0,0,1}};
 M leftController{{1,0,0},{0,1,0},{0,0,1}}; // -reflect(right X), reflect(right Z)
 assert(profile.infer(true,axis,.5f,identity,rb));
 V leftAxis{-axis.x,axis.y,axis.z};assert(profile.infer(false,leftAxis,.5f,leftController,lb));
 assert(length(sub(lb,V{-rb.x,rb.y,rb.z}))<.0001f);
 assert(profile.infer(true,axis,3.5f,identity,rb));V base{.65f,-1,-.15f};base=unit(sub(base,mul(axis,dot(base,axis))));assert(length(sub(rb,base))<.0001f);
 right.profile=&profile;V learned=right.update(1,rs,rh,1.f/90,&identity),elbow{},wrist{};
 assert(solveTracked(rs,{.5f,1.4f,0},{.8f,1.4f,0},rh.p,learned,elbow,wrist)&&length(sub(wrist,rh.p))<.00001f);
 unsigned before=profile.count;assert(!profile.load("missing-elbow-profile.txt")&&profile.count==before);
 // Pure wrist rotation at a fixed target cannot create elbow flare, even without a profile.
 RFGRVRElbowEstimator wristOnly;Pose fixed{identity,{.2f,-.1f,.4f}};
 V fixedBend=wristOnly.update(1,{},fixed,.016f,&identity);
 for(int i=0;i<100;++i){M spin=turnAround(identity,{0,0,1},i*.06f);fixed.b=spin;V result=wristOnly.update(1,{},fixed,.016f,&spin);assert(length(sub(result,fixedBend))<.00001f);}
 // A measured inward/down swivel is legal: do not force it outward or alter the triangle.
 RFGRVRElbowProfile inward;inward.version=2;inward.count=1;V forward{0,0,1},ref=unit(V{.65f,-1,0}),goal=unit(V{-.35f,-1,0});
 inward.nodes[0].feature[2]=1;inward.nodes[0].feature[3]=.4f;
 float angle=atan2f(dot(goal,cross(forward,ref)),dot(goal,ref));inward.nodes[0].weight[0]=cosf(angle);inward.nodes[0].weight[1]=sinf(angle);
 RFGRVRElbowEstimator inwardSolver;inwardSolver.profile=&inward;Pose front{identity,{0,0,.4f}};V inwardPole=inwardSolver.update(1,{},front,.016f,&identity);
 assert(inwardPole.x<-.2f);V actualElbow{},actualWrist{};assert(solveTracked({},{.3f,0,0},{.6f,0,0},front.p,inwardPole,actualElbow,actualWrist));
 assert(fabsf(length(actualElbow)-.3f)<.00001f&&fabsf(length(sub(actualWrist,actualElbow))-.3f)<.00001f);
 // Distinguishable rotation around a fixed elbow/shoulder selects that pivot;
 // no assumption that controller roll always represents shoulder rotation.
 for(unsigned expected=1;expected<=2;++expected){RFGRVRElbowEstimator motion;Pose h{identity,{.1f,-.1f,.4f}};V pole=motion.update(1,{},h,.016f,&identity),e{},w{};assert(solveTracked({},{.3f,0,0},{.6f,0,0},h.p,pole,e,w));V center=expected==1?e:V{},initial=h.p;bool detected=false;
  for(int i=1;i<=4;++i){M rotation=turnAround(identity,{1,0,0},i*.12f);h={rotation,add(center,world(rotation,sub(initial,center)))};motion.update(1,{},h,.016f,&rotation);detected=detected||motion.pivot==expected;}assert(detected);
 }
 // Small tracking translations during wrist bends cannot select shoulder motion.
 {RFGRVRElbowEstimator noise;Pose h{identity,{.1f,-.1f,.4f}};noise.update(1,{},h,.016f,&identity);for(int i=1;i<30;++i){M rotation=turnAround(identity,{0,0,1},i*.1f);h.b=rotation;h.p.x=.1f+.006f*sinf(i*.7f);noise.update(1,{},h,.016f,&rotation);assert(noise.pivot==0);}}
 // A high/outward learned swivel gets a soft downward preference, not a clamp.
 {RFGRVRElbowProfile wing;wing.version=2;wing.count=1;wing.nodes[0].feature[2]=1;wing.nodes[0].feature[3]=.4f;V ref=unit(V{.65f,-1,0}),goal{1,0,0},axis{0,0,1};float angle=atan2f(dot(goal,cross(axis,ref)),dot(goal,ref));wing.nodes[0].weight[0]=cosf(angle);wing.nodes[0].weight[1]=sinf(angle);RFGRVRElbowEstimator solver;solver.profile=&wing;Pose h{identity,{0,0,.4f}};V pole=solver.update(1,{},h,.016f,&identity),e{},w{};assert(pole.y<-.35f);assert(solveTracked({},{.3f,0,0},{.6f,0,0},h.p,pole,e,w)&&length(sub(w,h.p))<.00001f);}
 puts("PASS: wrist isolation, inward recorded poses, rigid arm lengths and elbow/shoulder pivot discrimination");

}
