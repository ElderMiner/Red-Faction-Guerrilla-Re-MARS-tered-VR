#define NOMINMAX
#define RFGR_TEST_ARM_TRAINING
#include "../src/vr_arm_training.h"
#include "../src/vr_elbow_estimator.h"
#include <cassert>
using namespace vrtraining;
int main(){
 const M identity{{1,0,0},{0,1,0},{0,0,1}};
 Coverage c;for(int i=0;i<100;++i)c.observe(1,{},identity,{});assert(!c.armGood());c.observe(1,{1,0,0},identity,{});c.observe(1,{-1,0,0},identity,{});assert(c.armGood());
 for(int i=0;i<40;++i)c.observe(2,{},identity,{});assert(!c.wristGood());c.observe(2,{},turnAround(identity,{0,0,1},.8f),{});c.observe(2,{},turnAround(identity,{1,0,0},.6f),{});assert(c.wristGood());Coverage moved;for(int i=0;i<50;++i)moved.observe(2,{},turnAround(identity,{1,0,0},i*.04f),{float(i)*.05f,0,0});assert(!moved.wristGood());
 Session s;GetFullPathNameA("build-check\\",MAX_PATH,s.directory,nullptr);char temp[MAX_PATH];sprintf_s(temp,"%sRFGRVR-arm-profile-%lu.txt",s.directory,GetCurrentProcessId());strcpy_s(s.profilePath,temp);DeleteFileA(temp);assert(s.begin()&&active);V shoulder{},hand{0,-.1f,.4f},elbow{.15f,-.25f,.2f};unsigned sample=1;ULONGLONG now=1000;
 // Even a non-handshake orientation and inside-elbow marker starts recording immediately.
 M mounted=turnAround(identity,{0,0,1},2.f);
 s.observe(sample++,now,shoulder,hand,elbow,mounted,{mounted,hand},{mounted,elbow},identity,1);
 assert(s.anchored&&s.rows==1);
 assert(!s.observe(sample-1,now,shoulder,hand,elbow,mounted,{mounted,hand},{mounted,elbow},identity,1)&&s.rows==1);
 // Implausible fit samples are still retained for offline diagnosis.
 now+=16;s.observe(sample++,now,shoulder,{0,2,0},elbow,mounted,{mounted,{0,2,0}},{mounted,elbow},identity,1);assert(s.rows==2);
 auto sampleAt=[&](unsigned target,unsigned n,bool wrist){if(!n)now+=300;hand=s.target[target];hand.x+=(n&1)?.003f:-.003f;V axis=unit(hand),reference{.65f,-1,-.15f};V normal=unit(sub(reference,mul(axis,dot(reference,axis))));elbow=add(mul(hand,.5f),mul(normal,.19f));M rotation=identity;if(wrist&&n%3==1)rotation=turnAround(identity,{0,0,1},.85f);if(wrist&&n%3==2)rotation=turnAround(identity,{1,0,0},.65f);now+=16;assert(s.observe(sample++,now,shoulder,hand,elbow,rotation,{rotation,hand},{identity,elbow},identity,1));};
 for(unsigned target=0;target<12;++target)for(unsigned n=0;n<30;++n)sampleAt(target,n,false);assert(s.complete(false)>=8);
 s.phase=2;for(unsigned target=0;target<12;++target)for(unsigned n=0;n<45;++n)sampleAt(target,n,true);assert(s.complete(true)>=8&&s.fitted.count>=8);
 s.packet({identity,{}},{identity,{}},1);Reader reader;Markers markers;assert(reader.read(GetCurrentProcessId(),markers)&&markers.count==16&&markers.state[0]==2);
 assert(s.finish()&&!active&&s.installedProfile);RFGRVRElbowProfile fitted;assert(fitted.load(temp)&&fitted.version==2);
 V a{},b{},axis=unit(V{.1f,-.1f,.4f});assert(fitted.infer(true,axis,.43f,identity,a));assert(fitted.infer(true,axis,.43f,turnAround(identity,{0,0,1},2.f),b));assert(length(sub(a,b))<.000001f);
 RFGRVRElbowEstimator est;est.profile=&fitted;Pose held{identity,{.1f,-.1f,.4f}};auto before=est.update(1,{},held,1.f/90,&identity);held.b=turnAround(identity,{0,0,1},2.f);M turned=held.b;auto after=est.update(1,{},held,1.f/90,&turned);assert(length(sub(before,after))<.00001f);
 FILE* csv=nullptr;assert(!fopen_s(&csv,s.dataPath,"r")&&csv);unsigned lines=0;char row[2048];while(fgets(row,sizeof(row),csv))++lines;fclose(csv);assert(lines==s.rows+1);
 DeleteFileA(s.dataPath);char summary[MAX_PATH];sprintf_s(summary,"%s.summary.txt",s.dataPath);DeleteFileA(summary);
 // An incomplete second capture preserves the last valid fitted profile.
 Session partial;strcpy_s(partial.directory,s.directory);strcpy_s(partial.profilePath,temp);assert(partial.begin());assert(!partial.finish());assert(fitted.load(temp)&&fitted.version==2);DeleteFileA(partial.dataPath);sprintf_s(summary,"%s.summary.txt",partial.dataPath);DeleteFileA(summary);DeleteFileA(temp);
 puts("PASS: immediate capture without pose gate, directional coverage, wrist isolation, stereo targets, raw-data persistence and position-only elbow fit");
}


