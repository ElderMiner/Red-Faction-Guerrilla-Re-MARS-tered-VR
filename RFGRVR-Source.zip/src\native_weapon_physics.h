#include "vr_hit_reactions.h"
#include "vr_haptics.h"
#include "vr_user_settings.h"
#pragma once
#include "vr_memory_access.h"
#include <windows.h>
#include <atomic>
#include <cstdio>
#include <cstring>
#include "vr_weapon_motion.h"
#include "gutter_collision.h"
#include "vr_prop_grab.h"
#include "vehicle_resource_overflow.h"
#include "vehicle_type_catalog.h"
#include "vr_vehicle_controls.h"
#include "vr_wrist_status.h"
#include "weapon_physics_input.h"
#include "vr_auto_focus.h"
#include "weapon_scope.h"
#include "vr_charge_sound.h"
#include "vr_manual_reload.h"
#include "../vendor/MinHook.h"
extern "C" void RFGRVR_APC_Created(void*);
namespace RFGRVRWeaponPhysics {
using namespace vrarm;
struct Target {void* player=nullptr;void* weapon=nullptr;unsigned handle=~0u,playerHandle=~0u,weaponClass=~0u;int primary=-1,secondary=-1;V extentA{},extentB{};float radius=.05f;unsigned pointCount=0;V points[24]{};vrweapon::MotionSample motion{};DWORD tick=0;Pose grip{};unsigned physicalHand=1;bool focusEligible=true;float attackTrigger=0;void* magazine=nullptr;unsigned magazineHandle=~0u;Pose magazinePose{},hand[2]{},aim[2]{},magazineGrip{M{{1,0,0},{0,1,0},{0,0,1}},V{}};V magazineCenter{},magazineExtent{.05f,.12f,.04f};float squeeze[2]{};unsigned occupiedMask=0;bool nativePropCarry=false,rocketMountValid=false;Pose rocketMount{};};
inline void updateSpatialSound(const Target&);
inline SRWLOCK lock=SRWLOCK_INIT;inline Target target{};inline bool installed=false;inline unsigned char* base=nullptr;
inline bool memory(const void*,size_t);inline unsigned word(const void*,unsigned);
inline void log(const char*);
using Update=void(__cdecl*)(void*);inline Update originalUpdate=nullptr;
using Focus=void(__cdecl*)(void*,unsigned,bool);inline Focus nativeFocus=nullptr;
inline vrfocus::Control autoFocus;
using ScopeVisual=void(__cdecl*)(bool);using HighlightHuman=void(__thiscall*)(void*,unsigned);
inline ScopeVisual nativeSniperScope=nullptr,nativeRailScope=nullptr;inline HighlightHuman nativeScopeHighlight=nullptr;inline int activeNativeScope=-1;
inline void setNativeScope(int kind){
 if(kind==activeNativeScope)return;
 if(activeNativeScope==0&&nativeSniperScope)nativeSniperScope(false);if(activeNativeScope==1&&nativeRailScope)nativeRailScope(false);activeNativeScope=-1;vrscope::nativeVisualKind.store(-1);
 if(kind<0||!nativeSniperScope||!nativeRailScope)return;
 if(kind==1&&nativeScopeHighlight&&base){unsigned count=word(base,0x2b9850c);auto* indices=(unsigned short*)(uintptr_t)word(base,0x2b98504);auto** humans=(void**)(uintptr_t)word(base,0x2b984f4);
  if(count<=2048&&memory(indices,count*2))for(unsigned i=0;i<count;++i){unsigned index=indices[i];if(memory(humans+index,4)&&memory(humans[index],0x80))nativeScopeHighlight(humans[index],8);}}
 (kind==0?nativeSniperScope:nativeRailScope)(true);activeNativeScope=kind;vrscope::nativeVisualKind.store(kind);
}

inline bool largeSledgeImpact(const Target& t){return t.weaponClass==7&&t.motion.twoHand&&t.attackTrigger>.65f;}
inline void updateFocus(const Target& t,bool allowed){
 const bool powerSledge=allowed&&largeSledgeImpact(t);
 if(!nativeFocus||!memory(t.player,0xd60)){setNativeScope(-1);vrstatus::focus(powerSledge);return;}
 void* info=(void*)(uintptr_t)word(t.weapon,0x148);
 const int scopeKind=vrscope::index(memory(info,4)?(const char*)(uintptr_t)word(info,0):nullptr);
 bool scopeEditing=false;{AcquireSRWLockShared(&vrscope::lock);scopeEditing=scopeKind>=0&&vrscope::editing&&vrscope::editKind==scopeKind;ReleaseSRWLockShared(&vrscope::lock);}
 allowed=allowed&&(t.motion.twoHand||scopeEditing)&&t.focusEligible&&memory(info,0x14)&&(word(info,0xc)&6)!=0&&t.weaponClass!=3&&t.weaponClass!=4&&t.weaponClass!=7;
 int focusGroup=vrfocus::distanceGroup(memory(info,4)?(const char*)(uintptr_t)word(info,0):nullptr,t.weaponClass);int capture=vrfocus::distanceRequest.exchange(-1);if(capture>=0)vrfocus::distanceCapture.arm(capture);
 auto* source=RFGRVRWeaponInput::source.load();bool inside=false;
 if((allowed||vrfocus::distanceCapture.group>=0)&&source&&source->version==RFGR_PROTOCOL)for(int attempt=0;attempt<3;++attempt){
  LONG sequence=source->poseSequence;if(sequence&1)continue;MemoryBarrier();RFGRPose head=source->hmd,grip=t.physicalHand==0?source->left:source->right,aim=t.physicalHand==0?source->leftAim:source->rightAim;bool active=source->calibrationReady&&source->gameplayActive&&!source->theaterMode;MemoryBarrier();if(sequence!=source->poseSequence)continue;
  auto convert=[](const RFGRPose& p){auto axis=[&](V v){V q{p.orientation[0],p.orientation[1],p.orientation[2]};return add(v,mul(cross(q,add(cross(q,v),mul(v,p.orientation[3]))),2));};return Pose{M{axis({1,0,0}),axis({0,1,0}),axis({0,0,1})},{p.position[0],p.position[1],p.position[2]}};};
  // OpenXR forward is -Z; rotate the head frame so its forward axis faces -Z.
  Pose h=convert(head),g=convert(grip),a=convert(aim);h.b.f=mul(h.b.f,-1);h.b.r=mul(h.b.r,-1);
  if(active&&(head.validFlags&3)==3&&(grip.validFlags&3)==3){float measured=length(sub(g.p,h.p)),value=0;if(vrfocus::distanceCapture.step(t.squeeze[1],measured,value)){int group=vrfocus::distanceCapture.group;bool saved=vrfocus::saveDistance(group,value);if(saved)vrfocus::distanceCapture.group=-1;char note[140];sprintf_s(note,"%s focus distance %s: %.1f cm",vrfocus::distanceKeys[group],saved?"SAVED":"SAVE FAILED",value*100);vrstatus::notify(note);}}
  inside=active&&(head.validFlags&3)==3&&(grip.validFlags&3)==3&&grip.active&&vrfocus::firingHandNearEyes(h,g,autoFocus.engaged,vrfocus::focusDistance(focusGroup));break;
 }
 inside=inside||scopeEditing;const unsigned desiredScope=2u;
 int request=autoFocus.update((uintptr_t)t.player,word(t.player,0xd58),allowed,inside,desiredScope);
 if(request>=0){nativeFocus(t.player,unsigned(request),false);static DWORD lastLog=0;DWORD now=GetTickCount();if(word(t.player,0xd58)==unsigned(request)||!lastLog||DWORD(now-lastLog)>10000){lastLog=now;char line[100];sprintf_s(line,"Near-face focus: requested=%d actual=%u",request,word(t.player,0xd58));log(line);}}
 bool focused=allowed&&inside&&word(t.player,0xd58)==desiredScope;setNativeScope(focused?scopeKind:-1);vrstatus::focus(focused||powerSledge);
}
using StartMelee=bool(__cdecl*)(void*,void*,uintptr_t,uintptr_t);inline StartMelee originalStartMelee=nullptr;
using Prime=bool(__cdecl*)(void*,void*,uintptr_t,uintptr_t);inline Prime originalPrime=nullptr;
using Release=void*(__thiscall*)(void*,const V*,const M*,const V*);
using Melee=void(__cdecl*)(void*,const V*,unsigned);inline Melee originalMelee=nullptr;
using Contact=void(__cdecl*)(void*,void*,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);inline Contact originalContact=nullptr;
using Counts=void(__cdecl*)(unsigned,int*,int*,int*);inline Counts countProjectiles=nullptr;
using Maximum=int(__cdecl*)();inline Maximum maximumCharges=nullptr;
using Modifier=void*(__thiscall*)(void*);inline Modifier chargeModifier=nullptr;
inline bool capacity(const Target& t){if(!countProjectiles||!maximumCharges)return true;bool multiplayer=(word(base,0x2beb588)&255)!=0;if(t.weaponClass!=3&&!(t.weaponClass==4&&multiplayer))return true;int maximum=maximumCharges();void* modifier=(void*)(uintptr_t)word(t.player,0x1170);if(modifier&&chargeModifier){void* value=chargeModifier(modifier);if(memory((char*)value+0x14,4)){float factor=0;memcpy(&factor,(char*)value+0x14,4);if(std::isfinite(factor)&&factor>0&&factor<100)maximum=int(maximum*factor);}}int remote=0,attached=0,mines=0;countProjectiles(t.playerHandle,&remote,&attached,&mines);return maximum>0&&remote>=0&&mines>=0&&remote+(multiplayer?mines:0)<maximum;}
using Finish=void(__thiscall*)(void*,float,bool);inline Finish finish=nullptr;
using Spin=void(__cdecl*)(unsigned,const V*);inline Spin spin=nullptr,linearVelocity=nullptr;
using Move=void(__thiscall*)(void*,const V*,const M*,bool);using Movable=void(__cdecl*)(unsigned,bool);inline Movable movable=nullptr;
using Plant=bool(__cdecl*)(const V*,const V*,void*);inline Plant originalPlant=nullptr;inline thread_local void* physicalReleaseInfo=nullptr;
inline bool __cdecl onPlant(const V* from,const V* to,void* projectile){if(physicalReleaseInfo&&(void*)(uintptr_t)word(projectile,0x140)==physicalReleaseInfo)return false;return originalPlant(from,to,projectile);}
inline vrweapon::Strike strike;inline vrweapon::StrikeIntent strikeIntent;inline unsigned consumedSample=0;inline vrweapon::MotionSample previousPhysics{};inline bool previousReady=false;inline thread_local bool physicalContact=false;inline thread_local void* physicalAttacker=nullptr;alignas(16) inline unsigned char physicalProfile[0x50]{};inline std::atomic<unsigned> contacts{0};inline thread_local float contactStrength=0;inline thread_local bool physicalLargeArea=false;inline thread_local V physicalImpactPoint{};inline vrweapon::ImpactRegions structuralContacts;inline float structuralContactSeparation=.2f;
inline void* profileFor(int id){unsigned count=word(base,0x2c2f054);if(id<0||unsigned(id)>=count||count>512)return nullptr;void* table=(void*)(uintptr_t)word(base,(word(base,0x2c2f05c)>>24)&255?0x2c2f050:0x2c2f04c);void* entry=(char*)table+unsigned(id)*0xdc;if(!memory(entry,0xdc))return nullptr;
 for(unsigned slot=0;slot<5;++slot){const char* name=(const char*)entry+0x3c+slot*32;if(!memcmp(name,"Player\0",7)){void* value=(void*)(uintptr_t)word(entry,0x28+slot*4);if(memory(value,0x50)&&word(value,4)==unsigned(id))return value;}}return nullptr;}
inline int smallSledge(){unsigned count=word(base,0x2c2f054);void* table=(void*)(uintptr_t)word(base,0x2c2f04c);if(count>512)return -1;for(unsigned id=0;id<count;++id){const char* name=(const char*)(uintptr_t)word((char*)table+id*0xdc,0);if(memory(name,25)&&!strcmp(name,"sledgehammer_melee_small"))return int(id);}return -1;}
inline void __cdecl onContact(void* victim,void* attacker,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h){if(physicalContact&&attacker==physicalAttacker){unsigned handle=word(victim,0x6c);bool structure=physicalLargeArea&&((word(victim,0x7c)>>16)&255)==2;V point=physicalImpactPoint;if(structure&&memory((void*)a,sizeof(V)))memcpy(&point,(void*)a,sizeof(V));if(structure?!structuralContacts.contact(handle,point,structuralContactSeparation):!strike.contact(handle))return;++contacts;vrstatus::force(contactStrength,true);}originalContact(victim,attacker,a,b,c,d,e,f,g,h);}
// Native melee mutates a complete 0x30-byte world-sweep request, not two vectors.
struct SweepRequest {V from{},to{};float radius=0;void* context=nullptr;void* filter=nullptr;unsigned mask=0,mode=0,reserved=0;};
static_assert(sizeof(SweepRequest)==0x30,"Native sphere sweep ABI");
using CueId=int(__cdecl*)(const char*,int*);inline CueId cueId=nullptr;
using PlayCue=int(__cdecl*)(int,V*,V*,V*,int*);inline PlayCue playCue=nullptr;
inline void playSwing(const Target& t){if(!cueId||!playCue)return;int cue=-1;const char* name=t.weaponClass==7&&t.motion.twoHand?"WEP_MELEE_SWING_MODERATE_PC":"WEP_MELEE_SWING_FAST_PC";cueId(name,&cue);if(cue>=0){V pos=t.motion.pose.p;int error=0;playCue(cue,&pos,nullptr,nullptr,&error);}}
inline std::atomic<float> primeWorldScale{1};inline RFGRVRChargeSound chargeSound;inline std::atomic<bool> primeSoundActive{false};inline ULONGLONG primeTailUntil=0;inline std::atomic<void*> primeFollow{nullptr};inline unsigned primeFollowHandle=~0u;
inline void stopPrimeSound(){if(GetTickCount64()<primeTailUntil)return;if(primeSoundActive){chargeSound.stop();primeSoundActive=false;}primeFollow=nullptr;}
inline void primeSound(unsigned milliseconds){primeTailUntil=0;stopPrimeSound();primeSoundActive=chargeSound.play(milliseconds);}
inline void primeSpatialListener(const float p[3],const float b[9]){chargeSound.hear(p,b,primeWorldScale.load());}
inline void(*primeAudio)(unsigned)=primeSound;
inline vrweapon::ThrowArming throwArming;
inline uint64_t(*armingClock)()=[]()->uint64_t{return GetTickCount64();};
inline unsigned armingDuration(const Target&){return 1000u;}

inline unsigned physicalHitCount=0;inline unsigned char physicalHitEffect=0;
inline unsigned sweepCount=0,missingProfile=0,nativeMoveBusy=0;inline float peakStrikeSpeed=0;
inline void scaledProfile(void* output,const void* native,float radius,float strength,bool nativeArea=false){memcpy(output,native,0x50);float originalRadius=0;memcpy(&originalRadius,(const char*)native+0x14,4);if(!nativeArea||!std::isfinite(originalRadius)||originalRadius<=0||originalRadius>2)memcpy((char*)output+0x14,&radius,4);if(strength>=1)return;strength=(std::max)(0.f,strength);for(unsigned off=0x28;off<=0x48;off+=4){if(off==0x30)continue;float value=0;memcpy(&value,(char*)output+off,4);if(std::isfinite(value)&&value>=0){value*=strength;memcpy((char*)output+off,&value,4);}}}
struct ContactPoints {V value[24]{};unsigned count=0;V* begin(){return value;}V* end(){return value+count;}};
inline ContactPoints contactPoints(const Target& t){ContactPoints points;if(t.pointCount&&t.pointCount<=24){points.count=t.pointCount;memcpy(points.value,t.points,t.pointCount*sizeof(V));}else{points.count=3;points.value[0]=t.extentA;points.value[1]=mul(add(t.extentA,t.extentB),.5f);points.value[2]=t.extentB;}return points;}
inline void simulateStrike(const Target& t,const vrweapon::Motion& motion){
 if(consumedSample==t.motion.sample)return;consumedSample=t.motion.sample;auto prior=previousPhysics;bool havePrior=previousReady&&prior.weapon==t.motion.weapon&&prior.handle==t.handle;previousPhysics=t.motion;previousReady=true;
 V center=mul(add(t.extentA,t.extentB),.5f);float speed=motion.valid?(std::max)({motion.pointSpeed(mul(t.extentA,1/t.motion.scale)),motion.pointSpeed(mul(t.extentB,1/t.motion.scale)),motion.pointSpeed(mul(center,1/t.motion.scale))}):0;
 peakStrikeSpeed=(std::max)(peakStrikeSpeed,speed);bool wasSwinging=strike.swinging;float strength=strike.update((uintptr_t)t.weapon,t.handle,speed,strikeIntent.update((uintptr_t)t.weapon,t.handle,t.motion.seconds,speed,motion.valid&&vrweapon::Strike::damageAllowed(t.weaponClass==7,t.motion.twoHand),t.weaponClass==7),t.weaponClass==7?3.2f:3.5f,t.weaponClass==7?1.8f:2.1f,t.weaponClass==7?5.5f:6.f);vrstatus::force(strength);if(!wasSwinging&&strike.swinging){physicalHitCount=0;physicalHitEffect=0;structuralContacts.reset();playSwing(t);}if(!havePrior||strength<=0)return;if(word(t.player,0x97c)){++nativeMoveBusy;return;}
 int move=t.primary;void* profile=profileFor(move);if(!profile){++missingProfile;return;}scaledProfile(physicalProfile,profile,t.radius,largeSledgeImpact(t)?1.f:strength,t.weaponClass==7||t.weaponClass==8);
 // Native melee performs the Havok sweeps and its normal material, damage,
 // structure and impulse handling. One contact per object per physical swing.
 if(largeSledgeImpact(t))physicalHitCount=0;
 unsigned savedCount=word(t.player,0x980);unsigned char savedEffect=*((unsigned char*)t.player+0x99c);memcpy((char*)t.player+0x980,&physicalHitCount,4);*((unsigned char*)t.player+0x99c)=physicalHitEffect;
 void* saved=(void*)(uintptr_t)word(t.player,0x97c);void* ownedProfile=physicalProfile;memcpy((char*)t.player+0x97c,&ownedProfile,sizeof(void*));physicalContact=true;physicalAttacker=t.player;contactStrength=strength;physicalLargeArea=largeSledgeImpact(t);structuralContactSeparation=.2f*t.motion.scale;
 for(V point:contactPoints(t)){SweepRequest sweep{};sweep.from=add(prior.pose.p,world(prior.pose.b,point));sweep.to=add(t.motion.pose.p,world(t.motion.pose.b,point));sweep.mask=word(base,0x125fe84);physicalImpactPoint=sweep.to;++sweepCount;originalMelee(t.player,&sweep.from,1);}
 physicalHitCount=word(t.player,0x980);physicalHitEffect=*((unsigned char*)t.player+0x99c);memcpy((char*)t.player+0x980,&savedCount,4);*((unsigned char*)t.player+0x99c)=savedEffect;
 physicalContact=false;physicalLargeArea=false;physicalAttacker=nullptr;memcpy((char*)t.player+0x97c,&saved,sizeof(void*));
}
// World queries execute only in native simulation. Render callbacks consume
// contact planes, and project the newest goal without delaying free hand motion.
using ResolveObject=void*(__thiscall*)(void*,unsigned);inline ResolveObject resolveObject=nullptr;
using SkeletalHit=int(__cdecl*)(void*,const V*,const V*,V*,float,int*,V*);inline SkeletalHit skeletalHit=nullptr;
using Query=bool(__cdecl*)(SweepRequest*,void*);inline Query worldQuery=nullptr;
using FreeHits=void(__thiscall*)(void*);inline FreeHits freeHits=nullptr;
struct HitArray {void* data=nullptr;int count=0;unsigned capacity=0x80000000;};
struct Plane {V normal{},point{};float distance=0;};
struct Constraint {uintptr_t weapon=0;unsigned handle=~0u;DWORD tick=0;unsigned count=0;Plane planes[3]{};Pose gripRelative{};unsigned physicalHand=1;};
inline SRWLOCK constraintLock=SRWLOCK_INIT;inline Constraint constraint{};inline Pose resolved{};inline uintptr_t resolvedWeapon=0;inline unsigned resolvedHandle=~0u;inline DWORD resolvedTick=0;
inline bool __cdecl collisionFilter(void* object,void* context){auto* t=(Target*)context;if(!object)return true;if(object==t->player||object==t->weapon)return false;unsigned type=word(object,0x7c)>>16&255;if((type==1||type==6)&&(word(object,0x70)==t->playerHandle||word(object,0x13c)==t->playerHandle))return false;return true;}
inline V constrain(const Constraint& c,Pose goal){V delta{};for(unsigned pass=0;pass<3;++pass)for(unsigned i=0;i<c.count;++i){const auto& p=c.planes[i];V point=add(add(goal.p,delta),world(goal.b,p.point));float depth=p.distance-dot(point,p.normal);if(depth>0)delta=add(delta,mul(p.normal,depth));}return delta;}
inline V blockingOffset(void* weapon,unsigned handle,Pose goal){Constraint c{};AcquireSRWLockShared(&constraintLock);c=constraint;ReleaseSRWLockShared(&constraintLock);if(c.weapon!=(uintptr_t)weapon||c.handle!=handle||DWORD(GetTickCount()-c.tick)>100)return {};return constrain(c,goal);}
inline V blockingForGrip(void* weapon,unsigned handle,Pose grip,unsigned hand){Constraint c{};AcquireSRWLockShared(&constraintLock);c=constraint;ReleaseSRWLockShared(&constraintLock);if(c.weapon!=(uintptr_t)weapon||c.handle!=handle||c.physicalHand!=hand||DWORD(GetTickCount()-c.tick)>100)return {};Pose goal{compose(grip.b,c.gripRelative.b),add(grip.p,world(grip.b,c.gripRelative.p))};return constrain(c,goal);}
inline void simulateBlocking(const Target& t,bool allowed){Constraint c{};c.weapon=(uintptr_t)t.weapon;c.handle=t.handle;c.tick=GetTickCount();c.physicalHand=t.physicalHand;c.gripRelative={relative(t.grip.b,t.motion.pose.b),local(t.grip.b,sub(t.motion.pose.p,t.grip.p))};
 if(allowed&&worldQuery&&freeHits){bool same=resolvedWeapon==c.weapon&&resolvedHandle==t.handle&&DWORD(c.tick-resolvedTick)<150&&length(sub(resolved.p,t.motion.pose.p))<2*t.motion.scale;Pose before=same?resolved:t.motion.pose;
 // On equip, start at the body rather than accepting an already embedded goal.
 if(!same)before.p=add(t.motion.body.p,V{0,1.3f*t.motion.scale,0});
 for(V point:contactPoints(t)){SweepRequest request{};request.from=add(before.p,world(before.b,point));request.to=add(t.motion.pose.p,world(t.motion.pose.b,point));request.radius=t.radius;request.context=(void*)&t;request.filter=(void*)collisionFilter;request.mask=word(base,0x125fe84);request.mode=1;HitArray hits{};
 if(length(sub(request.to,request.from))>.0001f&&worldQuery(&request,&hits)&&hits.count>0&&hits.count<4096&&memory(hits.data,size_t(hits.count)*0x38)){
  float closest=1;Plane plane{};V travel=sub(request.to,request.from);float distance2=dot(travel,travel);
  for(int i=0;i<hits.count;++i){auto* hit=(char*)hits.data+i*0x38;V normal{};float fraction=1;memcpy(&normal,hit+0x18,12);memcpy(&fraction,hit+0x24,4);
   void* object=resolveObject?resolveObject(base+0x2b98490,word(hit,0x28)):nullptr;
   if(object&&!collisionFilter(object,(void*)&t))continue;
   if(object&&memory((char*)object+0x7e,1)&&*((unsigned char*)object+0x7e)==0){if(!skeletalHit)continue;V direction=unit(travel),surface{},skeletalNormal{};int bone=-1;if(skeletalHit(object,&request.from,&direction,&surface,request.radius,&bone,&skeletalNormal)<0)continue;normal=unit(skeletalNormal,mul(direction,-1));if(dot(normal,travel)>0)normal=mul(normal,-1);V center=add(surface,mul(normal,request.radius));fraction=dot(sub(center,request.from),travel)/distance2;}
   float n=length(normal);if(!finite(normal)||n<.5f||!std::isfinite(fraction)||fraction<0||fraction>=closest)continue;normal=mul(normal,1/n);if(dot(normal,travel)>0)normal=mul(normal,-1);V contact=add(request.from,mul(travel,fraction));closest=fraction;plane={normal,point,dot(contact,normal)+.002f*t.motion.scale};
  }if(closest<1)c.planes[c.count++]=plane;
 }freeHits(&hits);if(c.count>=3)break;}
 resolved=t.motion.pose;resolved.p=add(resolved.p,constrain(c,resolved));resolvedWeapon=c.weapon;resolvedHandle=t.handle;resolvedTick=c.tick;
 }else{resolvedWeapon=0;resolvedTick=0;}
 AcquireSRWLockExclusive(&constraintLock);constraint=c;ReleaseSRWLockExclusive(&constraintLock);
}
inline vrweapon::MotionEstimator estimator;inline vrweapon::ThrowLatch throwLatch;inline std::atomic<unsigned> releases{0},primes{0},nativeMelees{0},simulationUpdates{0};
inline bool memory(const void* p,size_t n){return vrmemory::check(p,n); }
inline unsigned word(const void* p,unsigned offset){unsigned v=0;if(memory((char*)p+offset,4))memcpy(&v,(char*)p+offset,4);return v;}
inline void log(const char* message){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,92);if(!slash)return;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-WeaponPhysics.log");FILE* f=nullptr;if(!fopen_s(&f,path,"a")&&f){fprintf(f,"%lu %s\n",GetTickCount(),message);fclose(f);}}
inline bool requested(){static DWORD checked=0;static bool enabled=true;DWORD now=GetTickCount();if(!checked||DWORD(now-checked)>500){checked=now;char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,92);if(slash){strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-physical-weapons.disable");enabled=GetFileAttributesA(path)==INVALID_FILE_ATTRIBUTES;}}return enabled;}
inline void publish(const Target& value){AcquireSRWLockExclusive(&lock);target=value;ReleaseSRWLockExclusive(&lock);primeWorldScale=value.motion.scale;updateSpatialSound(value);if(primeSoundActive&&!primeFollow)chargeSound.position(&value.motion.pose.p.x);void* table=(void*)(uintptr_t)word(value.weapon,0);bool canThrow=installed&&requested()&&value.motion.tracked&&((value.weaponClass==7||value.weaponClass==8)||!vrsettings::get().value[vrsettings::Throw])&&((value.weaponClass==7||value.weaponClass==8)||value.nativePropCarry||((value.weaponClass==3||value.weaponClass==4)&&word(table,0x94)==(unsigned)(uintptr_t)(base+0x7e79a0)));RFGRVRWeaponInput::nativePropane=value.nativePropCarry;RFGRVRWeaponInput::c4Controlled=canThrow&&value.weaponClass==3&&!value.nativePropCarry;RFGRVRWeaponInput::sledgeControlled=canThrow&&(value.weaponClass==7||value.weaponClass==8);RFGRVRWeaponInput::throwControlled=canThrow;RFGRVRWeaponInput::lease=value.tick;}
inline bool snapshot(Target& out){AcquireSRWLockShared(&lock);out=target;ReleaseSRWLockShared(&lock);return out.tick&&DWORD(GetTickCount()-out.tick)<150;}
inline Release originalButtonRelease=nullptr;
inline void* __fastcall onButtonRelease(void* weapon,void*,const V* position,const M* orientation,const V* velocity){
 Target t{};if(vrsettings::get().value[vrsettings::Throw]&&snapshot(t)&&t.weapon==weapon&&t.motion.tracked&&t.physicalHand<2&&word(weapon,0x6c)==t.handle&&word(weapon,0x13c)==t.playerHandle&&velocity){
  Pose aim=t.aim[t.physicalHand];V p=t.hand[t.physicalHand].p,v=mul(aim.b.f,length(*velocity));if(valid(aim.b)&&finite(p)&&finite(v)){void* result=originalButtonRelease(weapon,&p,&aim.b,&v);if(result&&t.nativePropCarry)RFGRVRWeaponInput::propaneRestoreUntil=GetTickCount64()+1500;return result;}}
 return originalButtonRelease(weapon,position,orientation,velocity);
}

inline bool owned(const Target& t,void* player){if(t.player!=player||!memory(player,0xc94)||!memory(t.weapon,0x258))return false;return word(player,0x6c)==t.playerHandle&&word(t.weapon,0x6c)==t.handle&&word(t.weapon,0x13c)==t.playerHandle&&word((void*)(uintptr_t)word(player,0xc90),24)==t.handle;}
inline bool __cdecl onPrime(void* player,void* weapon,uintptr_t a,uintptr_t b){Target t{};if(installed&&requested()&&!vrsettings::get().value[vrsettings::Throw]&&snapshot(t)&&t.player==player&&word(player,0x2f4)<=2&&!word(player,0x33c)&&!(word(player,0x338)&(1u<<13))&&word(weapon,0x13c)==word(player,0x6c)){void* info=(void*)(uintptr_t)word(weapon,0x148);unsigned type=word(info,0x10);float trigger=0;if((type==2||type==3||type==4)&&RFGRVRWeaponInput::trigger(trigger))return false;}return originalPrime(player,weapon,a,b);}
inline bool __cdecl onStartMelee(void* player,void* profile,uintptr_t a,uintptr_t b){Target t{};if(installed&&requested()&&snapshot(t)&&owned(t,player)&&t.motion.tracked&&word(player,0x2f4)<=2&&!word(player,0x33c)&&!(word(player,0x338)&(1u<<13)))return false;return originalStartMelee(player,profile,a,b);}
inline void __cdecl onMelee(void* player,const V* sweep,unsigned continuous){Target t{};if(requested()&&snapshot(t)&&owned(t,player))return;originalMelee(player,sweep,continuous);}
struct VehicleRequest {alignas(4) unsigned char bytes[0x5c]{};};
using InitVehicle=void(__thiscall*)(void*);inline InitVehicle initVehicle=nullptr;
using SpawnVehicle=bool(__cdecl*)(void*);inline SpawnVehicle spawnVehicle=nullptr;using CheckedSpawnVehicle=int(__cdecl*)(void*);inline CheckedSpawnVehicle checkedSpawnVehicle=nullptr;
struct SpawnPhases{bool clearance=false,clear=false,create=false,created=false;};inline thread_local bool tracingSpawn=false;inline thread_local SpawnPhases spawnPhases{};
using VehicleClearance=bool(__cdecl*)(void*,void*,const V*,const M*,bool);inline VehicleClearance originalVehicleClearance=nullptr;
inline bool __cdecl traceVehicleClearance(void* info,void* list,const V* position,const M* orientation,bool include){bool ok=originalVehicleClearance(info,list,position,orientation,include);if(tracingSpawn){spawnPhases.clearance=true;spawnPhases.clear=ok;}return ok;}
using VehicleCreate=void*(__thiscall*)(void*,void*,void*,bool,unsigned);inline VehicleCreate originalVehicleCreate=nullptr;
inline void* __fastcall traceVehicleCreate(void* registry,void*,void* manager,void* descriptor,bool saved,unsigned id){void* object=originalVehicleCreate(registry,manager,descriptor,saved,id);if(tracingSpawn){spawnPhases.create=true;spawnPhases.created=object!=nullptr;}if(object)RFGRVR_APC_Created(object);return object;}
inline void installSpawnTrace(){const unsigned char clearanceSig[]={0x81,0xec,0xd0,8,0,0,0x53};if(!memcmp(base+0x756000,clearanceSig,sizeof(clearanceSig))&&MH_CreateHook(base+0x756000,(void*)traceVehicleClearance,(void**)&originalVehicleClearance)==MH_OK){if(MH_EnableHook(base+0x756000)!=MH_OK)MH_RemoveHook(base+0x756000);}const unsigned char createTail[]={0x83,0xec,0x48,0x53};if(base[0x53e6b0]==0xa1&&!memcmp(base+0x53e6b5,createTail,sizeof(createTail))&&MH_CreateHook(base+0x53e6b0,(void*)traceVehicleCreate,(void**)&originalVehicleCreate)==MH_OK){if(MH_EnableHook(base+0x53e6b0)!=MH_OK)MH_RemoveHook(base+0x53e6b0);}}
inline void* findVehicle(const char* name){void* list=base+0x12ba5f8;unsigned count=word(list,12);void* data=(void*)(uintptr_t)word(list,4);if(!count||count>1024||!memory(data,4))return nullptr;for(unsigned i=0;i<count;++i){void* info=(char*)data+i*0x4bc;if(!memory(info,0x20))continue;const char* candidate=(const char*)(uintptr_t)word(info,0);if(memory(candidate,strlen(name)+1)&&!strcmp(candidate,name))return info;}return nullptr;}
inline std::atomic<unsigned> vehicleRequests{0};inline std::atomic<DWORD> vehicleRequestTick{0};

#include "native_test_turret_spawn.h"
inline SRWLOCK vehicleMenuLock=SRWLOCK_INIT;inline bool vehicleMenuOpen=false;inline int vehicleMenuSelected=0,vehicleMenuCount=0;inline char vehicleMenuNames[1024][96]{},requestedVehicleName[96]{},vehicleMenuResult[96]{};inline unsigned vehicleMenuKinds[1024]{};inline DWORD menuDrawTick=0;inline bool menuKeys[5]{};
inline void toggleVehicleMenu(){AcquireSRWLockExclusive(&vehicleMenuLock);vehicleMenuOpen=!vehicleMenuOpen;if(vehicleMenuOpen){vehicleMenuCount=0;vehicleMenuSelected=0;memset(menuKeys,0,sizeof(menuKeys));for(const auto& e:vrtestspawn::entries)if(e.turret?TestTurretSpawn::ready()&&TestTurretSpawn::find(e.name)!=nullptr:findVehicle(e.name)!=nullptr){vehicleMenuKinds[vehicleMenuCount]=e.turret?3:0;strcpy_s(vehicleMenuNames[vehicleMenuCount++],e.name);}strcpy_s(vehicleMenuResult,vehicleMenuCount?"Choose a raider vehicle or standing turret":"Test definitions are not ready");}bool open=vehicleMenuOpen;ReleaseSRWLockExclusive(&vehicleMenuLock);if(!open)vrstatus::vehicleMenu("",false);}

using VehicleResourceAcquire=bool(__cdecl*)(void*);using VehicleResourceRelease=void(__cdecl*)(void*);
inline VehicleResourceAcquire acquireVehicleResource=nullptr;inline VehicleResourceRelease releaseVehicleResource=nullptr;
using VehicleAssetRequest=bool(__thiscall*)(void*,void*,unsigned);using VehicleAssetEnd=void(__thiscall*)(void*,unsigned);inline VehicleAssetRequest requestVehicleAssets=nullptr;inline VehicleAssetEnd endVehicleAssets=nullptr,markVehicleAssets=nullptr;
struct VehicleResourceLease{void* resource=nullptr;ULONGLONG until=0;void* entry=nullptr;bool directRelease=false;};inline VehicleResourceLease vehicleResourceLeases[16]{};
struct SpawnedVehicleLease{void* resource=nullptr;void* object=nullptr;unsigned handle=~0u;};inline SpawnedVehicleLease spawnedVehicleLeases[128]{};
inline void retireVehicleResources(){auto now=GetTickCount64();for(auto& lease:vehicleResourceLeases)if(lease.resource){bool alive=false;for(auto& spawned:spawnedVehicleLeases)if(spawned.resource==lease.resource){if(memory(spawned.object,0x70)&&word(spawned.object,0x6c)==spawned.handle)alive=true;else spawned={};}if(alive){lease.until=now+2000;continue;}if(now<lease.until)continue;if(lease.entry){if(endVehicleAssets&&word(lease.entry,8)==(unsigned)(uintptr_t)lease.resource)endVehicleAssets(lease.entry,3);if(lease.directRelease&&releaseVehicleResource)releaseVehicleResource(lease.resource);}else if(releaseVehicleResource)releaseVehicleResource(lease.resource);lease={};}}
// Mirrors the native7492F0 admission check without bypassing streaming safety.
inline bool vehicleFamilyConflict(void* info){void* manager=base+0x12b8ad0;unsigned family=word(info,0x38),srid=word(info,0x34);if(word(manager,0)!=3||!family||family==word(base,0x337002c))return false;unsigned loaded=word(manager,0x20),count=word(base+0x12ba5f8,12);void* list=(void*)(uintptr_t)word(manager,0x18);void* definitions=(void*)(uintptr_t)word(base+0x12ba5f8,4);if(loaded>4096||count>1024||!memory(list,loaded*4))return false;for(unsigned n=0;n<loaded;++n){void* entry=(void*)(uintptr_t)word(list,n*4);unsigned other=word(entry,8);if(other==srid)continue;for(unsigned d=0;d<count;++d){void* candidate=(char*)definitions+d*0x4bc;if(word(candidate,0x34)==other){if(word(candidate,0x38)==family)return true;break;}}}return false;}
inline bool prepareVehicleResource(void* info){if(!checkedSpawnVehicle)return true;if(!acquireVehicleResource||!releaseVehicleResource)return false;unsigned index=word(info,0x30),count=word(base,0x12b8ae0);void* entries=(void*)(uintptr_t)word(base,0x12b8ad8);if(index>=count||count>4096)return false;void* resource=(void*)(uintptr_t)word(entries,index*24+8);if(!memory(resource,0x24))return false;retireVehicleResources();for(auto& prior:vehicleResourceLeases)if(prior.resource&&prior.resource!=resource)prior.until=(std::min)(prior.until,GetTickCount64()+2000);for(auto& lease:vehicleResourceLeases)if(lease.resource==resource){lease.until=GetTickCount64()+30000;return true;}for(auto& lease:vehicleResourceLeases)if(!lease.resource){void* entry=(char*)entries+index*24;if(requestVehicleAssets&&endVehicleAssets){if(word(entry,0xc)&8)return true;if(requestVehicleAssets(base+0x12b8ad0,entry,3)){lease={resource,GetTickCount64()+30000,entry};return true;}
 // The ambient manager has a fixed seven-entry list and a family policy.
 // A test spawn instead owns a balanced native streamer reference; the checked
 // constructor still validates residency, placement and the vehicle profile.
 if(!markVehicleAssets||!endVehicleAssets||!acquireVehicleResource(resource))return false;markVehicleAssets(entry,3);lease={resource,GetTickCount64()+30000,entry,true};log("Vehicle test spawn: native streamer lease used outside ambient list");return true;}if(!acquireVehicleResource(resource))return false;lease={resource,GetTickCount64()+30000};return true;}return false;}
inline void completeVehicleResource(void* info,void* spawned=nullptr){unsigned index=word(info,0x30);void* entries=(void*)(uintptr_t)word(base,0x12b8ad8);void* resource=(void*)(uintptr_t)word(entries,index*24+8);for(auto& lease:vehicleResourceLeases)if(lease.resource==resource){lease.until=GetTickCount64()+2000;if(spawned&&memory(spawned,0x70)){bool retained=false;for(auto& hold:spawnedVehicleLeases)if(!hold.resource){hold={resource,spawned,word(spawned,0x6c)};retained=true;break;}if(!retained)lease.until=~ULONGLONG(0);}}}
#include "native_reload_engine.h"
#include "native_vehicle_calibration.h"
inline bool pollVehicleMenu(bool foreground){AcquireSRWLockExclusive(&vehicleMenuLock);bool open=vehicleMenuOpen;if(open){int keys[5]={VK_NUMPAD8,VK_NUMPAD2,VK_NUMPAD4,VK_NUMPAD6,VK_NUMPAD5};for(unsigned i=0;i<5;++i){bool down=foreground&&(GetAsyncKeyState(keys[i])&0x8000)!=0;if(down&&!menuKeys[i]&&vehicleMenuCount){if(i<4){int step=i==0?-1:i==1?1:i==2?-10:10;vehicleMenuSelected=(vehicleMenuSelected+step+vehicleMenuCount*10)%vehicleMenuCount;}else{strcpy_s(requestedVehicleName,vehicleMenuNames[vehicleMenuSelected]);vehicleRequestTick=GetTickCount();vehicleRequests.fetch_or(4);strcpy_s(vehicleMenuResult,"Spawn requested near you");}}menuKeys[i]=down;}
 if(DWORD(GetTickCount()-menuDrawTick)>100){menuDrawTick=GetTickCount();char text[768]{};sprintf_s(text,"Raiders / standing turrets %d of %d\n",vehicleMenuCount?vehicleMenuSelected+1:0,vehicleMenuCount);for(int offset=-1;offset<=1&&vehicleMenuCount;++offset){int index=(vehicleMenuSelected+offset+vehicleMenuCount)%vehicleMenuCount;char line[140];sprintf_s(line,"%s %s %.42s\n",offset==0?">":" ",vehicleMenuKinds[index]==3?"TURRET":"VEHICLE",vrtestspawn::find(vehicleMenuNames[index])?vrtestspawn::find(vehicleMenuNames[index])->label:vehicleMenuNames[index]);strcat_s(text,line);}strcat_s(text,vehicleMenuResult);vrstatus::vehicleMenu(text,true);}}
 ReleaseSRWLockExclusive(&vehicleMenuLock);return open;}
struct ParkedVehicle {void* object=nullptr;unsigned handle=~0u,body=~0u;Pose pose{};};inline ParkedVehicle parked[16]{};inline unsigned parkedNext=0;
inline void updateParked(const Target& t){for(auto& p:parked)if(p.object){if(word(p.object,0x6c)!=p.handle){p={};continue;}p.body=word(p.object,0x4c);if(word(t.player,0xac4)==p.handle){if(movable&&p.body<65536)movable(p.body,true);p={};continue;}if(p.body<65536&&word(base,0x236e980+p.body*4)&&movable){movable(p.body,false);auto move=(Move)(uintptr_t)word((void*)(uintptr_t)word(p.object,0),0x30);if(move)move(p.object,&p.pose.p,&p.pose.b,true);}}}
inline void consumeVehicleTestRequest(){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);char* slash=strrchr(path,92);if(!slash)return;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-spawn-request.txt");if(GetFileAttributesA(path)==INVALID_FILE_ATTRIBUTES)return;FILE* f=nullptr;char name[96]{};if(fopen_s(&f,path,"r")||!f)return;char* readName=fgets(name,sizeof(name),f);fclose(f);if(!DeleteFileA(path))return;if(!readName)return;name[strcspn(name,"\r\n")]=0;if(!findVehicle(name)){log("Vehicle diagnostic request rejected: unknown definition");return;}AcquireSRWLockExclusive(&vehicleMenuLock);strcpy_s(requestedVehicleName,name);ReleaseSRWLockExclusive(&vehicleMenuLock);vehicleRequestTick=GetTickCount();vehicleRequests.fetch_or(4);log("Vehicle diagnostic file request accepted");}
inline void pollVehicles(const Target& t){static DWORD checked=0;if(!initVehicle||!spawnVehicle||DWORD(GetTickCount()-checked)<500)return;checked=GetTickCount();consumeVehicleTestRequest();if(!vehicleRequests.load())return;if(DWORD(GetTickCount()-vehicleRequestTick.load())>30000){vehicleRequests=0;log("Vehicle keypad request expired outside active gameplay.");return;}
 char selectedName[96]{};AcquireSRWLockShared(&vehicleMenuLock);strcpy_s(selectedName,requestedVehicleName);ReleaseSRWLockShared(&vehicleMenuLock);const char* names[3]={"EDF_HeavyTank-A_1","EDF_AAXAir_1",selectedName};unsigned requested=vehicleRequests.exchange(0);static VehicleRequest params[16];static unsigned next=0;
 for(unsigned i=0;i<3;++i)if(requested&(1u<<i)){const auto* testEntry=vrtestspawn::find(names[i]);if(testEntry&&testEntry->turret){void* created=TestTurretSpawn::spawn(names[i],t.motion.body);AcquireSRWLockExclusive(&vehicleMenuLock);sprintf_s(vehicleMenuResult,"%s: %.50s",created?"Spawned":"Native turret creation rejected",testEntry->label);ReleaseSRWLockExclusive(&vehicleMenuLock);vrstatus::notify(created?"Standing turret created":"Standing turret unavailable here");continue;}void* info=findVehicle(names[i]);if(!info){log("Vehicle spawn: selected definition unavailable");vrstatus::notify("Vehicle definition unavailable");continue;}if(!prepareVehicleResource(info)){char diagnostic[350];sprintf_s(diagnostic,"Vehicle resource request failed: name=%s thread=%lu nativeThread=%u checked=%d request=%d release=%d resourceIndex=%u resourceCount=%u familyConflict=%d managerKind=%u active=%u limit=%u",names[i],GetCurrentThreadId(),word(base,0x16c3b4c),checkedSpawnVehicle?1:0,requestVehicleAssets?1:0,endVehicleAssets?1:0,word(info,0x30),word(base,0x12b8ae0),vehicleFamilyConflict(info)?1:0,word(base,0x12b8ad0),word(base,0x12b8af0),word(base,0x12b8aec));log(diagnostic);vehicleRequests.fetch_or(1u<<i);AcquireSRWLockExclusive(&vehicleMenuLock);strcpy_s(vehicleMenuResult,word(info,0x30)>=word(base,0x12b8ae0)?"Unavailable: definition has no stream resource":vehicleFamilyConflict(info)?"Blocked: another variant of this vehicle family is loaded":(word(base,0x12b8af0)>=word(base,0x12b8aec)?"Vehicle resource pool full; try another area":"Waiting for vehicle resources"));ReleaseSRWLockExclusive(&vehicleMenuLock);continue;}float nativeSize=0;memcpy(&nativeSize,(char*)info+16,4);float spacing=std::isfinite(nativeSize)?(std::max)(12.f,(std::min)(40.f,nativeSize+5.f)):12.f;bool flyer=word(info,12)==1;bool queued=false,streaming=false;void* object=nullptr;V position{};for(unsigned attempt=0;attempt<(flyer?1u:4u)&&!queued&&!streaming;++attempt){auto* p=params[next++%16].bytes;initVehicle(p);memcpy(p,&info,4);V offsets[4]={{0,1.5f,spacing},{-spacing,1.5f,0},{spacing,1.5f,0},{0,1.5f,-spacing}};position=add(t.motion.body.p,world(t.motion.body.b,flyer?V{spacing*.5f,.35f,spacing}:offsets[attempt]));memcpy(p+4,&position,12);memcpy(p+0x18,&t.motion.body.b,36);unsigned invalid=~0u,priority=2,flags=flyer?0x4b:0x43,vehicleFlags=(1u<<23)|(1u<<17),playerOwned=1u<<25;memcpy(p+0x40,&invalid,4);memcpy(p+0x44,&invalid,4);memcpy(p+0x48,&priority,4);memcpy(p+0x4c,&playerOwned,4);memcpy(p+0x50,&vehicleFlags,4);memcpy(p+0x54,&flags,4);spawnPhases={};tracingSpawn=true;int spawnStatus=checkedSpawnVehicle?checkedSpawnVehicle(p):(spawnVehicle(p)?0:2);tracingSpawn=false;if(spawnStatus==2){unsigned slot=word(info,0x30);void* entry=(char*)(uintptr_t)word(base,0x12b8ad8)+slot*24;void* resource=(void*)(uintptr_t)word(entry,8);using State=int(__cdecl*)(void*);int residency=resource?((State)(base+0xac250))(resource):-1;char diagnostic[300];sprintf_s(diagnostic,"Vehicle rejection phase: name=%s slot=%u timer=%d flags=%08x resourceState=%d clearance=%d/%d create=%d/%d",names[i],slot,(int)word(entry,0),word(entry,0x14),residency,spawnPhases.clearance?1:0,spawnPhases.clear?1:0,spawnPhases.create?1:0,spawnPhases.created?1:0);log(diagnostic);}queued=spawnStatus==0;streaming=spawnStatus==1;if(streaming)vehicleRequests.fetch_or(1u<<i);object=(void*)(uintptr_t)word(p,0x58);// Let native spawn placement and physics finish; never freeze/reposition an incompletely streamed vehicle.
}
 if(!streaming)completeVehicleResource(info,queued?object:nullptr);if(queued)VehicleCalibration::spawned(object,names[i]);else if(!streaming)VehicleCalibration::rejected();
 char line[300];sprintf_s(line,"Keypad vehicle spawn: name=%s accepted=%d object=%p at=%.2f/%.2f/%.2f",names[i],queued?1:0,object,position.x,position.y,position.z);log(line);AcquireSRWLockExclusive(&vehicleMenuLock);sprintf_s(vehicleMenuResult,"%s: %.50s",streaming?"Waiting for native vehicle resources":queued?"Spawn accepted":"Spawn rejected",names[i]);ReleaseSRWLockExclusive(&vehicleMenuLock);if(!streaming)vrstatus::notify(queued?"Vehicle created; native placement active":"Spawn rejected: resource unavailable or placement blocked");}

}

#include "native_spatial_audio.h"
#include "native_propane_collision.h"
#include "native_propane.h"
#include "native_vehicle_audio_pool.h"
#include "native_gear_unlock.h"

// This is the yaw consumer in walker locomotion, not the weapon update.
// Only the occupied local mech substitutes its chassis basis; AI keeps its source.
namespace MechMovement {
using Yaw=float(__thiscall*)(const M*);
inline Yaw nativeYaw=nullptr;
inline std::atomic<unsigned> corrected{0};
inline float __fastcall heading(const M* source,void* car){
 void* player=(void*)(uintptr_t)word(base,0x2c23874);
 if(memory(player,0xac8)&&word(player,0x2f4)==9&&resolveObject&&car&&
    resolveObject(base+0x2b98490,word(player,0xac4))==car&&memory(car,13600)){
  void* info=(void*)(uintptr_t)word(car,13588);
  const char* name=(const char*)(uintptr_t)word(info,0);
  if(memory(info,16)&&RFGRVRVehicleIsMech(memory(name,80)?name:nullptr,word(info,12))){
   const M* chassis=(const M*)((char*)car+16);
   if(valid(*chassis)){++corrected;return nativeYaw(chassis);}
  }
 }
 return nativeYaw(source);
}
inline void* turnOriginal=nullptr;inline std::atomic<unsigned> turnCorrected{0};
inline bool __fastcall turnTarget(void* car,unsigned char* stack){
 void* player=(void*)(uintptr_t)word(base,0x2c23874);
 if(!memory(player,0xac8)||word(player,0x2f4)!=9||!resolveObject||!car||
    resolveObject(base+0x2b98490,word(player,0xac4))!=car||!memory(car,13600))return false;
 void* info=(void*)(uintptr_t)word(car,13588);const char* name=(const char*)(uintptr_t)word(info,0);
 if(!memory(info,16)||!RFGRVRVehicleIsMech(memory(name,80)?name:nullptr,word(info,12)))return false;
 const M* chassis=(const M*)((char*)car+16);if(!valid(*chassis))return false;
 float dt=0;memcpy(&dt,base+0x1119560,4);if(!std::isfinite(dt)||dt<=0||dt>.1f)dt=0;
 float step=RFGRVRMechInput::rate()*dt,yaw=nativeYaw(chassis)+step,limit=fabsf(step);
 memcpy(stack+0x10,&yaw,4);memcpy(stack+0x24,&limit,4);++turnCorrected;return true;
}
__declspec(naked) inline void turnThunk(){
 __asm {pushfd} __asm {pushad} __asm {lea edx,[esp+36]} __asm {mov ecx,edi}
 __asm {call turnTarget} __asm {test al,al} __asm {jz nativeTarget}
 __asm {mov byte ptr [esp+16],1}
 __asm {nativeTarget:} __asm {popad} __asm {popfd} __asm {jmp turnOriginal}
}
inline bool installTurn(){
 const unsigned char sig[]={0xf7,0x87,0x24,0x3f,0,0,0,0,0,0x20};
 auto* entry=base+0x7b921b;if(memcmp(entry,sig,sizeof(sig)))return false;
 if(MH_CreateHook(entry,(void*)&turnThunk,&turnOriginal)!=MH_OK)return false;
 if(MH_EnableHook(entry)!=MH_OK){MH_RemoveHook(entry);return false;}return true;
}
__declspec(naked) inline void thunk(){__asm {mov edx,esi} __asm {jmp heading}}
inline bool install(){
 auto* call=base+0x785d59;nativeYaw=(Yaw)(base+0x176190);
 const unsigned char before[]={0x8d,0x4c,0x24,0x24,0xe9};
 if(call[0]!=0xe8||call+5+*(int*)(call+1)!=(unsigned char*)nativeYaw||
    memcmp(base+0x785b79,before,5))return false;
 DWORD old=0;if(!VirtualProtect(call,5,PAGE_EXECUTE_READWRITE,&old))return false;
 *(int*)(call+1)=(int)((unsigned char*)&thunk-call-5);
 FlushInstructionCache(GetCurrentProcess(),call,5);DWORD ignored=0;
 VirtualProtect(call,5,old,&ignored);return true;
}
}
// Native mech/tank steering must read the vehicle heading during simulation,
// not the previous HMD-render camera. Restore the camera before rendering.
struct DriverHeadingScope {
 unsigned char* camera=nullptr;M saved[2]{};
 DriverHeadingScope(void* player){if(player!=(void*)(uintptr_t)word(base,0x2c23874)||word(player,0x2f4)!=9||!resolveObject)return;void* car=resolveObject(base+0x2b98490,word(player,0xac4));if(!memory(car,13600))return;void* info=(void*)(uintptr_t)word(car,13588);const char* name=(const char*)(uintptr_t)word(info,0);if(!memory(name,80))return;auto* type=RFGRVRVehicleTypeFor(name);if(!(type&&type->tank)&&!RFGRVRVehicleIsMech(name,word(info,12)))return;M basis{};memcpy(&basis,(char*)car+0x10,36);if(!valid(basis))return;camera=(unsigned char*)(uintptr_t)word(base,0x23394c);if(!memory(camera,316)){camera=nullptr;return;}memcpy(&saved[0],camera+80,36);memcpy(&saved[1],camera+280,36);memcpy(camera+80,&basis,36);memcpy(camera+280,&basis,36);}
 ~DriverHeadingScope(){if(camera){memcpy(camera+80,&saved[0],36);memcpy(camera+280,&saved[1],36);}}
};
// Native pickup stays authoritative. Keep the attached object's actual physics
// transform at the published hand pose, not only its render entities.
using CarryBodyPose=void(__cdecl*)(unsigned,const V*,const M*);inline CarryBodyPose carryBodyPose=nullptr;
inline bool syncNativeCarry(const Target& t){
 if(!t.nativePropCarry||!t.motion.tracked||!memory(t.weapon,0x150)||!memory(t.player,0xac8)||word(t.player,0x2f4)>2||word(t.weapon,0x70)!=t.playerHandle||word(t.weapon,0x6c)!=t.handle||!valid(t.motion.pose.b)||!finite(t.motion.pose.p))return false;
 void* table=(void*)(uintptr_t)word(t.weapon,0);auto move=(Move)(uintptr_t)word(table,0x30);if(!memory((void*)move,1))return false;
 move(t.weapon,&t.motion.pose.p,&t.motion.pose.b,true);unsigned body=word(t.weapon,0x4c);if(carryBodyPose&&body<65536&&word(base,0x236e980+body*4))carryBodyPose(body,&t.motion.pose.p,&t.motion.pose.b);PropaneCollision::publish(t,t.weapon);return true;
}
// Native attachment updates run before the next render-pose publication.
// Correct their first physical move, including the pickup frame.
inline Move originalObjectMove=nullptr;inline std::atomic<unsigned> carryMoveCorrections{0};
inline bool carryMoveTarget(void* object,Target& t,Pose& desired){
 if(!requested()||!snapshot(t)||!t.motion.tracked||!memory(object,0x150)||!memory(t.player,0xac8)||word(t.player,0x2f4)>2||word(object,0x70)!=t.playerHandle||!word(object,0x48))return false;
 void* def=(void*)(uintptr_t)word(object,0xa4);const char* name=(const char*)(uintptr_t)word(def,0);if(!memory(name,13)||memcmp(name,"propane_tank",13))return false;
 if(t.nativePropCarry&&t.weapon==object&&valid(t.motion.pose.b)&&finite(t.motion.pose.p))desired=t.motion.pose;
 else{Pose identity{M{{1,0,0},{0,1,0},{0,0,1}},V{}},grip{};void* attachment=(void*)(uintptr_t)word(object,0x48);int childTag=(int)word(attachment,8);void* table=(void*)(uintptr_t)word(object,0);using Tag=bool(__thiscall*)(void*,int,V*,M*,const V*,const M*);auto getTag=(Tag)(uintptr_t)word(table,0x38);if(!getTag||childTag<0||childTag>4096||!getTag(object,childTag,&grip.p,&grip.b,&identity.p,&identity.b)||!valid(grip.b)||!finite(grip.p)||length(grip.p)>2||!valid(t.hand[1].b)||!finite(t.hand[1].p))return false;desired.b=compose(t.hand[1].b,relative(grip.b,identity.b));desired.p=sub(t.hand[1].p,world(desired.b,grip.p));}
 t.weapon=object;t.handle=word(object,0x6c);t.nativePropCarry=true;return true;
}
inline void __fastcall onObjectMove(void* object,void*,const V* position,const M* rotation,bool physics){Target t{};Pose desired{};bool attachedItem=object&&*((unsigned char*)object+0x7e)==1&&*(unsigned*)((char*)object+0x70)!=~0u&&*(unsigned*)((char*)object+0x70)!=0;if(attachedItem&&carryMoveTarget(object,t,desired)){PropaneCollision::publish(t,object);++carryMoveCorrections;originalObjectMove(object,&desired.p,&desired.b,true);}else originalObjectMove(object,position,rotation,physics);}
inline bool installCarryMove(){const unsigned char signature[]={0x8b,0x44,0x24,0x04,0xf3,0x0f,0x7e,0x00};if(memcmp(base+0x68c310,signature,sizeof(signature)))return false;if(MH_CreateHook(base+0x68c310,(void*)&onObjectMove,(void**)&originalObjectMove)!=MH_OK)return false;if(MH_EnableHook(base+0x68c310)==MH_OK)return true;MH_RemoveHook(base+0x68c310);return false;}
struct NativeCarryScope{Target t;bool active=false;NativeCarryScope(const Target& value,bool fresh):t(value){if(fresh)active=syncNativeCarry(t);}~NativeCarryScope(){if(active&&!syncNativeCarry(t))PropaneCollision::clear();}};
inline void __cdecl onUpdate(void* player){
 vrmemory::Scope memoryScope;

 // Testing-only gear grants are disabled. Native progression owns unlocks.
 void* soundObject=primeFollow.load();if(soundObject&&memory(soundObject,0x80)&&word(soundObject,0x6c)==primeFollowHandle){V point{};memcpy(&point,(char*)soundObject+4,12);if(finite(point))chargeSound.position(&point.x);}
 DriverHeadingScope driverHeading(player);Target t{};bool fresh=snapshot(t);if(t.player!=player){originalUpdate(player);return;}PropaneCollision::localPlayer=(uintptr_t)player;PropaneCollision::heldWeapon=t.nativePropCarry?0:(uintptr_t)t.weapon;PropaneCollision::heldWeaponHandle=t.handle;if(!t.nativePropCarry)PropaneCollision::clear();PropaneCollision::PlayerScope nativeCarryQueries(player);NativeCarryScope nativeCarry(t,fresh);retireVehicleResources();VehicleCalibration::update(player);if(fresh&&RFGRVRVehicleCalibrationActive&&word(player,0x2f4)==0)pollVehicles(t);if(memory(player,0xac8)&&word(player,0x6c)==t.playerHandle)updateParked(t);if(!requested()||!fresh||!owned(t,player)){Reload::suspend(t);updateFocus(t,false);throwLatch.update(0,0,0,false);throwArming.cancel();stopPrimeSound();estimator.reset();strike.reset();strikeIntent.reset();previousReady=false;originalUpdate(player);return;}
 if(t.motion.tracked&&word(player,0x2f4)==0&&!word(player,0x33c))pollVehicles(t);
 ++simulationUpdates;auto motion=estimator.update(t.motion);DWORD foregroundPid=0;GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
 using Expired=bool(__thiscall*)(void*);int timer=(int)word(player,0xa4c);bool allowed=t.motion.tracked&&foregroundPid==GetCurrentProcessId()&&word(player,0x2f4)<=2&&!word(player,0x33c)&&(!(word(player,0x338)&(1u<<13))||t.nativePropCarry)&&(timer<0||((Expired)(base+0x18e720))((char*)player+0xa4c));
 updateFocus(t,allowed&&word(player,0x2f4)==0);
 Reload::update(t,allowed&&word(player,0x2f4)==0);

 if(simulationUpdates.load()%300==0){char line[400];sprintf_s(line,"Physics update: sample=%u valid=%d class=%u twoHand=%d contacts=%u releases=%u speed=%.3f peak=%.3f sweeps=%u noProfile=%u nativeBusy=%u",t.motion.sample,motion.valid?1:0,t.weaponClass,t.motion.twoHand?1:0,contacts.load(),releases.load(),motion.valid?motion.pointSpeed({}):0,peakStrikeSpeed,sweepCount,missingProfile,nativeMoveBusy);log(line);peakStrikeSpeed=0;}
 const bool throwable=t.nativePropCarry||t.weaponClass==3||t.weaponClass==4;float trigger=0;bool input=RFGRVRWeaponInput::trigger(trigger);
 void* table=(void*)(uintptr_t)word(t.weapon,0);auto release=(Release)(uintptr_t)word(table,0x94);bool factory=release==(Release)(base+0x7e79a0);
 auto event=throwLatch.update((uintptr_t)t.weapon,t.handle,trigger,allowed&&input&&throwable&&factory&&!vrsettings::get().value[vrsettings::Throw]);
 if(event==vrweapon::ThrowEvent::Cancel){throwArming.cancel();stopPrimeSound();}
 if(event!=vrweapon::ThrowEvent::None&&!t.nativePropCarry&&!capacity(t)){throwLatch.update((uintptr_t)t.weapon,t.handle,trigger,false);throwArming.cancel();stopPrimeSound();event=vrweapon::ThrowEvent::None;log("Physical release blocked by native placed-charge limit.");}
 simulateBlocking(t,t.motion.tracked&&foregroundPid==GetCurrentProcessId()&&word(player,0x2f4)<=2&&!word(player,0x33c)&&!(word(player,0x338)&(1u<<13)));
 if(allowed&&input&&!t.nativePropCarry)simulateStrike(t,motion);else{strike.reset();strikeIntent.reset();previousReady=false;}
 if(vrsettings::get().value[vrsettings::Throw]||!throwable||!allowed||!input||!factory){originalUpdate(player);return;}
 // This callback belongs to native human simulation, and runs independently
 // of the two eye draws. Never spawn or apply damage from a render callback.
 if(event==vrweapon::ThrowEvent::Prime){++primes;unsigned duration=armingDuration(t);throwArming.begin(armingClock(),(duration*2+2)/3);chargeSound.position(&t.motion.pose.p.x);if(primeAudio)primeAudio(duration);log("Physical throw arming; hold trigger until full charge sound completes.");}
 if(event==vrweapon::ThrowEvent::Release){bool ready=throwArming.release(armingClock());if(ready)primeTailUntil=GetTickCount64()+334;if(!ready){stopPrimeSound();event=vrweapon::ThrowEvent::Cancel;log("Physical throw cancelled: arming sound incomplete.");}}

 if(event==vrweapon::ThrowEvent::Release){V velocity=motion.valid?motion.handThrowVelocity(t.motion.scale,t.weaponClass==3?1.75f:1.f):V{};if(t.nativePropCarry){void* info=(void*)(uintptr_t)word(t.weapon,0x148);float nativeSpeed=0;if(memory((char*)info+0x1d0,4))memcpy(&nativeSpeed,(char*)info+0x1d0,4);float speed=length(velocity);if(std::isfinite(nativeSpeed)&&nativeSpeed>0&&nativeSpeed<=100&&speed>.1f)velocity=mul(velocity,nativeSpeed*.5f/speed);else if(speed<=.1f)velocity={};}if(motion.valid)velocity=add(velocity,motion.carrierVelocity(t.motion.scale));V position=t.motion.pose.p;M orientation=t.motion.pose.b;
  physicalReleaseInfo=(void*)(uintptr_t)word(t.weapon,0x148);void* projectile=release(t.weapon,&position,&orientation,&velocity);physicalReleaseInfo=nullptr;if(t.nativePropCarry&&!projectile&&memory(t.weapon,0x150)&&word(t.weapon,0x70)!=t.playerHandle)projectile=t.weapon;if(projectile&&memory(projectile,0x150)){if(!t.nativePropCarry){void* table=(void*)(uintptr_t)word(projectile,0);auto move=(Move)(uintptr_t)word(table,0x30);if(move)move(projectile,&position,&orientation,true);if(finish)finish(projectile,0,true);}unsigned body=word(projectile,0x4c);if(motion.valid&&body<65536&&word(base,0x236e980+body*4)){if(movable)movable(body,true);if(linearVelocity)linearVelocity(body,&velocity);if(!t.nativePropCarry&&spin){V angular=motion.throwSpin();spin(body,&angular);}}}char line[220];sprintf_s(line,"Physical release: weapon=%p projectile=%p velocity=%.3f/%.3f/%.3f",t.weapon,projectile,velocity.x,velocity.y,velocity.z);log(line);if(projectile){primeFollow=projectile;primeFollowHandle=word(projectile,0x6c);++releases;if(t.nativePropCarry)RFGRVRWeaponInput::propaneRestoreUntil=GetTickCount64()+1500;}
 }
 originalUpdate(player);
}
inline bool install(){
 base=(unsigned char*)GetModuleHandleW(nullptr);
 TestTurretSpawn::install(base);
 log(vrhit::install(base)?"Local VR hit reactions suppressed; damage path retained":"Local hit reaction signature unavailable");
 // Verified native player zoom setter (cdecl player,state,transition flag).
 // Its state 2 selects info+174/+178 fine-aim spread in 6836FA.
 const unsigned char focusSig[]={0x53,0x8b,0x5c,0x24,0x08,0x57,0x8b,0x7c,0x24,0x10};
 if(!memcmp(base+0x685570,focusSig,sizeof(focusSig)))nativeFocus=(Focus)(base+0x685570);
 const unsigned char sniperScopeSig[]={0x53,0x8a,0x5c,0x24,0x08},railScopeSig[]={0x53,0x8a,0x5c,0x24,0x08},highlightSig[]={0x51,0x56,0x8b,0xf1,0x8a,0x46,0x7e};
 if(!memcmp(base+0x4988f0,sniperScopeSig,sizeof(sniperScopeSig))&&!memcmp(base+0x498740,railScopeSig,sizeof(railScopeSig))&&!memcmp(base+0x65fca0,highlightSig,sizeof(highlightSig))){nativeSniperScope=(ScopeVisual)(base+0x4988f0);nativeRailScope=(ScopeVisual)(base+0x498740);nativeScopeHighlight=(HighlightHuman)(base+0x65fca0);}

 if(MechMovement::install())log("Occupied mech locomotion heading override installed");else log("Mech locomotion heading signature unavailable; native path retained");
 if(MechMovement::installTurn())log("Occupied mech independent native turn target installed");else log("Mech native turn target unavailable");
 const unsigned offsets[6]={0x6cb320,0x6d1930,0x6d13b0,0x7e77d0,0x6cb520,0x67ecf0};
 const unsigned char signatures[6][8]={{0x51,0x55,0x57,0x8b,0x7c,0x24,0x10},{0x81,0xec,0xf0,0,0,0,0x55,0x56},{0x83,0xec,0x28,0x53,0x55,0x57},{0x83,0xec,0x60,0x8b,0x44,0x24,0x64},{0x81,0xec,0xac,0,0,0,0x53,0x56},{0x83,0xec,0x4c,0x53,0x56}};
 const unsigned lengths[6]={7,8,6,7,8,5};const unsigned char releaseSig[]={0x83,0xec,0x54,0x53,0x55,0x56,0x8b,0xf1};
 if(memcmp(base+0x7e79a0,releaseSig,sizeof(releaseSig)))return false;
 if(MH_CreateHook(base+0x7e79a0,(void*)onButtonRelease,(void**)&originalButtonRelease)==MH_OK){if(MH_EnableHook(base+0x7e79a0)!=MH_OK){MH_RemoveHook(base+0x7e79a0);originalButtonRelease=nullptr;}}
 for(unsigned i=0;i<6;++i)if(memcmp(base+offsets[i],signatures[i],lengths[i])){log("Native physics signatures differ; physics controls remain disabled.");return false;}
 void* hooks[6]={(void*)onUpdate,(void*)onMelee,(void*)onContact,(void*)onPlant,(void*)onPrime,(void*)onStartMelee};void** originals[6]={(void**)&originalUpdate,(void**)&originalMelee,(void**)&originalContact,(void**)&originalPlant,(void**)&originalPrime,(void**)&originalStartMelee};
 for(unsigned i=0;i<6;++i)if(MH_CreateHook(base+offsets[i],hooks[i],originals[i])!=MH_OK){for(unsigned j=0;j<i;++j)MH_RemoveHook(base+offsets[j]);return false;}
 initVehicle=(InitVehicle)(base+0x743c50);spawnVehicle=(SpawnVehicle)(base+0x756420);const unsigned char checkedSig[]={0x56,0x57,0x8b,0x7c,0x24,0x0c};if(!memcmp(base+0x757f40,checkedSig,sizeof(checkedSig)))checkedSpawnVehicle=(CheckedSpawnVehicle)(base+0x757f40);
 const unsigned char resourceAcquireSig[]={0xe8,0xcb,0xd3,0x0d,0,0x39,0x05},resourceReleaseSig[]={0xe8,0x6b,0xc0,0x0d,0,0x39,0x05};if(!memcmp(base+0xaef40,resourceAcquireSig,7)&&!memcmp(base+0xb02a0,resourceReleaseSig,7)){acquireVehicleResource=(VehicleResourceAcquire)(base+0xaef40);releaseVehicleResource=(VehicleResourceRelease)(base+0xb02a0);}
 const unsigned char assetRequestSig[]={0x55,0x56,0x8b,0x74,0x24,0x0c,0x8b,0xe9},assetEndSig[]={0x8b,0xc1,0x8b,0x4c,0x24,0x04,0xba,0x01};if(!memcmp(base+0x7524c0,assetRequestSig,8)&&!memcmp(base+0x744070,assetEndSig,8)){requestVehicleAssets=(VehicleAssetRequest)(base+0x7524c0);endVehicleAssets=(VehicleAssetEnd)(base+0x744070);}
 const unsigned char markSig[]={0x56,0x8b,0xf1,0x8b,0x4c,0x24,0x08};if(!memcmp(base+0x744030,markSig,sizeof(markSig)))markVehicleAssets=(VehicleAssetEnd)(base+0x744030);
 cueId=(CueId)(base+0x8dc50);playCue=(PlayCue)(base+0x9fd60);resolveObject=(ResolveObject)(base+0x53c050);skeletalHit=(SkeletalHit)(base+0x67d740);
 worldQuery=(Query)(base+0x436aa0);freeHits=(FreeHits)(base+0x2758a0);
 countProjectiles=(Counts)(base+0x6719c0);maximumCharges=(Maximum)(base+0x375f70);chargeModifier=(Modifier)(base+0x2c3f10);
 finish=(Finish)(base+0x664c30);spin=(Spin)(base+0x423910);linearVelocity=(Spin)(base+0x4237e0);movable=(Movable)(base+0x423da0);
 for(unsigned i=0;i<6;++i)if(MH_EnableHook(base+offsets[i])!=MH_OK){for(unsigned offset:offsets){MH_DisableHook(base+offset);MH_RemoveHook(base+offset);}return false;}
 carryBodyPose=(CarryBodyPose)(base+0x423700);PropaneCollision::install();log(installCarryMove()?"Native carried-object first-move correction installed":"Native carried-object first-move correction unavailable");Reload::install();installSpawnTrace();VehicleAudioPool::install();VehicleCalibration::init();

 log(SpatialAudio::install()?"VR spatial weapon audio and tracked-center listener installed":"VR spatial audio signatures unavailable; native audio retained");installed=true;log("Native simulation collision sweeps and physical charge/mine release installed; live verification pending.");return true;
}
}








