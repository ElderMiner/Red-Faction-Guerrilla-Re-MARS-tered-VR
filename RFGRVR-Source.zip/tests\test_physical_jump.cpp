#include "../src/vr_physical_jump.h"
#include <cassert>
int main(){RFGRVRPhysicalJump j;float height=1.6f;for(int i=0;i<100;++i)assert(!j.update(height,1.6f,.01f,true));
 // Looking/nodding within a few cm must not arm a jump.
 for(int i=0;i<100;++i)assert(!j.update(1.6f+.03f*std::sin(i*.2f),1.6f,.01f,true));
 for(int i=0;i<30;++i)assert(!j.update(1.6f-.006f*i,1.6f,.01f,true));assert(j.armed);
 bool fired=false;for(int i=0;i<40;++i)fired=j.update(1.42f+.007f*i,1.6f,.01f,true)||fired;assert(fired);
 for(int i=0;i<100;++i)j.update(1.6f,1.6f,.01f,true);assert(!j.armed&&j.pulse<=0);
 // A slow stand-up without rising above calibration does not jump.
 j.reset();for(int i=0;i<30;++i)j.update(1.4f,1.6f,.01f,true);
 for(int i=0;i<200;++i)assert(!j.update(1.4f+.001f*i,1.6f,.01f,true));
 j.reset();for(int i=0;i<30;++i)j.update(1.4f,1.6f,.01f,true);assert(j.armed);assert(!j.update(1.7f,1.6f,.01f,false));assert(!j.armed);
}
