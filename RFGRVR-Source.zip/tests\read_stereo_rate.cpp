#define NOMINMAX
#include <windows.h>
#include <cstdio>
#include "../src/stereo_gpu_protocol.h"
int main(){auto h=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_STEREO_GPU_MAP);if(!h)return 2;auto* g=(RFGRStereoGpuShared*)MapViewOfFile(h,FILE_MAP_READ,0,0,sizeof(RFGRStereoGpuShared));if(!g)return 3;auto tick=GetTickCount64();auto a=g->sceneFrame;auto ack=g->eyeAcknowledged[0];Sleep(1000);auto elapsed=GetTickCount64()-tick;printf("mode=%u ready=%ld pairs_per_sec=%.1f consumed_per_sec=%.1f frame=%llu pairSequence=%ld eyes=%ld/%ld\n",g->renderMode,g->ready,1000.*(g->sceneFrame-a)/elapsed,1000.*(g->eyeAcknowledged[0]-ack)/elapsed,g->sceneFrame,g->pairSequence,g->eyeFrames[0],g->eyeFrames[1]);for(int e=0;e<2;++e)printf("eye%d pos=%.4f %.4f %.4f fov=%.4f %.4f %.4f %.4f\n",e,g->eyePosition[e][0],g->eyePosition[e][1],g->eyePosition[e][2],g->eyeFov[e][0],g->eyeFov[e][1],g->eyeFov[e][2],g->eyeFov[e][3]);}

