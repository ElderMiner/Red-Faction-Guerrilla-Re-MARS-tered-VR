#pragma once
struct RFGRVRAdjustDirection {bool negative=false,wasDown=false;
 bool update(bool down,bool focused){bool changed=down&&!wasDown&&focused;wasDown=down;if(changed)negative=!negative;return changed;}
 int sign()const{return negative?-1:1;}
};
