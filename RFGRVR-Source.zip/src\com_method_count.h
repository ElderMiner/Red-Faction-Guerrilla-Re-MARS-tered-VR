#pragma once
#include <d3d11_4.h>
#include <dxgi1_6.h>
#include <wrl/client.h>
template<class T> inline bool RFGRVR_SameInterface(IUnknown* object){
 Microsoft::WRL::ComPtr<T> next;
 return SUCCEEDED(object->QueryInterface(__uuidof(T),(void**)next.GetAddressOf()))&&(void*)next.Get()==(void*)object;
}
inline size_t RFGRVR_ContextMethods(ID3D11DeviceContext* c){
 if(RFGRVR_SameInterface<ID3D11DeviceContext4>(c))return 149;
 if(RFGRVR_SameInterface<ID3D11DeviceContext3>(c))return 147;
 if(RFGRVR_SameInterface<ID3D11DeviceContext2>(c))return 144;
 if(RFGRVR_SameInterface<ID3D11DeviceContext1>(c))return 134;
 return 115;
}
inline size_t RFGRVR_SwapMethods(IDXGISwapChain* c){
 if(RFGRVR_SameInterface<IDXGISwapChain4>(c))return 41;
 if(RFGRVR_SameInterface<IDXGISwapChain3>(c))return 40;
 if(RFGRVR_SameInterface<IDXGISwapChain2>(c))return 36;
 if(RFGRVR_SameInterface<IDXGISwapChain1>(c))return 29;
 return 18;
}
inline size_t RFGRVR_FactoryMethods(IUnknown* c,size_t baseline){
 if(RFGRVR_SameInterface<IDXGIFactory7>(c))return 32;
 if(RFGRVR_SameInterface<IDXGIFactory6>(c))return 30;
 if(RFGRVR_SameInterface<IDXGIFactory5>(c))return 29;
 if(RFGRVR_SameInterface<IDXGIFactory4>(c))return 28;
 if(RFGRVR_SameInterface<IDXGIFactory3>(c))return 26;
 if(RFGRVR_SameInterface<IDXGIFactory2>(c))return 25;
 if(RFGRVR_SameInterface<IDXGIFactory1>(c))return 14;
 return baseline;
}
