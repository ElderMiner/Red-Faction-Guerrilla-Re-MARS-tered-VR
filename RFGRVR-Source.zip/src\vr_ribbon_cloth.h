#pragma once
#include <algorithm>
#include "vr_arm_math.h"
namespace vrribbon {
using namespace vrarm;
struct Cloth {
 V rest[12]{},point[12]{},previous[12]{};Pose lastRoot{};bool ready=false;
 void reset(const Pose& root){for(unsigned i=0;i<12;++i)point[i]=previous[i]=add(root.p,world(root.b,rest[i]));lastRoot=root;ready=true;}
 void pin(const Pose& root){for(unsigned i=0;i<2;++i)point[i]=add(root.p,world(root.b,rest[i]));}
 void distance(unsigned a,unsigned b,float strength=1){V d=sub(point[b],point[a]);float n=length(d),target=length(sub(rest[b],rest[a]));if(n<1e-6f)return;float wa=a<2?0.f:1.f,wb=b<2?0.f:1.f;if(wa+wb==0)return;V correction=mul(d,strength*(n-target)/(n*(wa+wb)));point[a]=add(point[a],mul(correction,wa));point[b]=sub(point[b],mul(correction,wb));}
 void update(const Pose& root,float seconds){
  if(!valid(root.b)||!finite(root.p))return;
  if(!ready||length(sub(root.p,lastRoot.p))>2||!std::isfinite(seconds)||seconds>.15f){reset(root);return;}
  unsigned steps=(std::clamp)(unsigned(ceilf((std::max)(0.f,seconds)*120)),1u,8u);float dt=(std::clamp)(seconds/steps,0.f,1.f/120);
  float damping=expf(-3.2f*dt);
  for(unsigned step=0;step<steps;++step){pin(root);for(unsigned i=2;i<12;++i){V p=point[i];point[i]=add(add(p,mul(sub(p,previous[i]),damping)),V{0,-9.81f*dt*dt,0});previous[i]=p;}
   for(unsigned pass=0;pass<16;++pass){pin(root);for(unsigned i=2;i<12;++i)distance(i-2,i);for(unsigned i=0;i<12;i+=2)distance(i,i+1,.75f);for(unsigned i=2;i<12;i+=2){distance(i-2,i+1,.25f);distance(i-1,i,.25f);}}
  }
  pin(root);lastRoot=root;
 }
};
}
