#pragma once
#include "vr_desktop_menu.h"
struct RFGRVRMapPanel {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;Ptr<ID3D11Device> owner;Ptr<ID3D11Texture2D> background,overlay;RFGRVRDesktopMenu copy;
 bool compose(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* back,ID3D11Texture2D* panel,ID3D11RenderTargetView* target){
  if(!d||!c||!back||!panel||!target)return false;
  if(owner.Get()!=d){background.Reset();overlay.Reset();copy={};owner=d;}
  D3D11_TEXTURE2D_DESC desc{},old{};back->GetDesc(&desc);if(background)background->GetDesc(&old);
  if(!background||old.Width!=desc.Width||old.Height!=desc.Height||old.Format!=desc.Format){background.Reset();desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;desc.MiscFlags=0;if(FAILED(d->CreateTexture2D(&desc,nullptr,&background)))return false;}
  panel->GetDesc(&desc);if(overlay)overlay->GetDesc(&old);if(!overlay||old.Width!=desc.Width||old.Height!=desc.Height||old.Format!=desc.Format){overlay.Reset();desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;desc.MiscFlags=0;if(FAILED(d->CreateTexture2D(&desc,nullptr,&overlay)))return false;}
  c->CopyResource(background.Get(),back);c->CopyResource(overlay.Get(),panel);float opaque[4]={0,0,0,1};c->ClearRenderTargetView(target,opaque);
  return copy.draw(d,c,panel,background.Get())&&copy.draw(d,c,panel,overlay.Get());
 }
};
