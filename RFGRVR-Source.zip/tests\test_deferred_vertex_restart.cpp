#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <wrl/client.h>
#include <cassert>
#include <cstdio>
#include "../src/vr_vertex_cursor.h"
using Microsoft::WRL::ComPtr;
struct CursorChecks {CursorChecks(){
 unsigned pool[4]={0,123,8192,0x180000};assert(RFGRVR_VertexPoolReady(pool));
 RFGRVR_VertexPoolRestart(pool);assert(pool[0]==0&&pool[1]==123&&pool[2]==0&&pool[3]==0x180000);
 pool[0]=1;assert(!RFGRVR_VertexPoolReady(pool));pool[0]=0;pool[2]=pool[3]+1;assert(!RFGRVR_VertexPoolReady(pool));
 }} cursorChecks;
int main(){ComPtr<ID3D11Device>d;ComPtr<ID3D11DeviceContext>c,x;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));assert(SUCCEEDED(d->CreateDeferredContext(0,&x)));D3D11_BUFFER_DESC bd{};bd.ByteWidth=0x180000;bd.Usage=D3D11_USAGE_DYNAMIC;bd.BindFlags=D3D11_BIND_VERTEX_BUFFER;bd.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;ComPtr<ID3D11Buffer>b;assert(SUCCEEDED(d->CreateBuffer(&bd,nullptr,&b)));D3D11_MAPPED_SUBRESOURCE m{};assert(SUCCEEDED(x->Map(b.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&m)));x->Unmap(b.Get(),0);ComPtr<ID3D11CommandList>list;assert(SUCCEEDED(x->FinishCommandList(FALSE,&list)));c->ExecuteCommandList(list.Get(),FALSE);HRESULT stale=x->Map(b.Get(),0,D3D11_MAP_WRITE_NO_OVERWRITE,0,&m);printf("new-list NO_OVERWRITE=0x%08lX\n",(unsigned long)stale);if(SUCCEEDED(stale))x->Unmap(b.Get(),0);assert(FAILED(stale));assert(SUCCEEDED(x->Map(b.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&m)));x->Unmap(b.Get(),0);puts("fresh-list DISCARD succeeded");}
