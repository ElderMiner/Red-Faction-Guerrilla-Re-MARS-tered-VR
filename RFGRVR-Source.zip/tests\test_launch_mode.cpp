#include "../src/vr_launch_mode.h"
#include <cassert>
#include <initializer_list>
int main(){wchar_t previous[32768]{};DWORD length=GetEnvironmentVariableW(L"RFGRVR_LAUNCH_MODE",previous,32768);SetEnvironmentVariableW(L"RFGRVR_LAUNCH_MODE",nullptr);assert(!RFGRVR_IsVRLaunch());for(const wchar_t* mode:{L"standard",L"STANDARD",L"",L"vr-extra",L"unknown"}){SetEnvironmentVariableW(L"RFGRVR_LAUNCH_MODE",mode);assert(!RFGRVR_IsVRLaunch());}SetEnvironmentVariableW(L"RFGRVR_LAUNCH_MODE",L"vr");assert(RFGRVR_IsVRLaunch());SetEnvironmentVariableW(L"RFGRVR_LAUNCH_MODE",L"VR");assert(RFGRVR_IsVRLaunch());SetEnvironmentVariableW(L"RFGRVR_LAUNCH_MODE",length?previous:nullptr);}

