using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
namespace RFGRVR {
 public class UpdateInfo { public string Version,Url,ChecksumUrl; }
 public static class Updates {
  public static ReleaseConfig Config(string root){string p=Path.Combine(root,@"RFGRVR\release.json");return File.Exists(p)?Core.Json.Deserialize<ReleaseConfig>(File.ReadAllText(p)):new ReleaseConfig{version="0.10.0",repository=""};}
  public static async Task<string> Text(string url){var r=(HttpWebRequest)WebRequest.Create(url);r.UserAgent="RFGRVR-Updater";r.Timeout=5000;r.ReadWriteTimeout=5000;r.AutomaticDecompression=DecompressionMethods.GZip;var responseTask=r.GetResponseAsync();if(await Task.WhenAny(responseTask,Task.Delay(5000))!=responseTask){r.Abort();throw new TimeoutException("Update server did not respond");}using(var response=await responseTask)using(var stream=response.GetResponseStream())using(var reader=new StreamReader(stream)){var text=await reader.ReadToEndAsync();if(text.Length>2*1024*1024)throw new IOException("Update response too large");return text;}}
  public static async Task<UpdateInfo> Check(ReleaseConfig config){if(String.IsNullOrEmpty(config.repository))return null;if(!Regex.IsMatch(config.repository,@"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$"))throw new IOException("Invalid release repository");return Parse(config,await Text("https://api.github.com/repos/"+config.repository+"/releases/latest"));}
  public static UpdateInfo Parse(ReleaseConfig config,string json){if(String.IsNullOrEmpty(config.repository))return null;if(!Regex.IsMatch(config.repository,@"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$"))throw new IOException("Invalid release repository");var data=Core.Json.Deserialize<Dictionary<string,object>>(json);string tag=(string)data["tag_name"];Version remote,local;if(!Version.TryParse(tag.TrimStart('v'),out remote)||!Version.TryParse(config.version.TrimStart('v'),out local)||remote<=local)return null;var result=new UpdateInfo{Version=tag};foreach(var value in (System.Collections.IEnumerable)data["assets"]){var asset=(Dictionary<string,object>)value;string name=(string)asset["name"],url=(string)asset["browser_download_url"];if(!url.StartsWith("https://github.com/"+config.repository+"/releases/download/",StringComparison.OrdinalIgnoreCase))continue;if(name==config.asset)result.Url=url;else if(name==config.asset+".sha256")result.ChecksumUrl=url;}if(result.Url==null||result.ChecksumUrl==null)throw new IOException("Release needs the installer ZIP and its SHA-256 file");return result;}
  public static async Task Install(UpdateInfo info,string root){string checksum=(await Text(info.ChecksumUrl)).Trim().Split((char[])null,StringSplitOptions.RemoveEmptyEntries)[0];if(!Regex.IsMatch(checksum,"^[a-fA-F0-9]{64}$"))throw new IOException("Invalid update checksum");string temp=Path.Combine(Path.GetTempPath(),"RFGRVR-update-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temp);string archive=Path.Combine(temp,"update.zip");var request=(HttpWebRequest)WebRequest.Create(info.Url);request.UserAgent="RFGRVR-Updater";request.Timeout=15000;using(var response=await request.GetResponseAsync())using(var stream=response.GetResponseStream())using(var file=File.Create(archive)){byte[] bytes=new byte[65536];int n;long total=0;while((n=await stream.ReadAsync(bytes,0,bytes.Length))>0){if((total+=n)>256*1024*1024)throw new IOException("Update package too large");await file.WriteAsync(bytes,0,n);}}if(!String.Equals(Core.Hash(archive),checksum,StringComparison.OrdinalIgnoreCase))throw new IOException("Update checksum mismatch; nothing installed");string setup=Path.Combine(temp,"RFGRVR-Setup.exe");using(var zip=ZipFile.OpenRead(archive)){var entry=zip.GetEntry("RFGRVR-Setup.exe");if(entry==null||entry.Length>128*1024*1024)throw new IOException("Installer missing from update");entry.ExtractToFile(setup);}Process.Start(new ProcessStartInfo(setup,"--update \""+root+"\""){UseShellExecute=true});}
 }
 // A launch session owns the companion, including cancellation/launcher failure.
 public sealed class CompanionLifetime:IDisposable {
  [StructLayout(LayoutKind.Sequential)]struct Basic {public long processTime,jobTime;public uint flags;public UIntPtr minWorking,maxWorking;public uint activeProcesses;public UIntPtr affinity;public uint priority,scheduling;}
  [StructLayout(LayoutKind.Sequential)]struct Io {public ulong readOps,writeOps,otherOps,readBytes,writeBytes,otherBytes;}
  [StructLayout(LayoutKind.Sequential)]struct Extended {public Basic basic;public Io io;public UIntPtr processMemory,jobMemory,peakProcess,peakJob;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateJobObject(IntPtr attributes,string name);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetInformationJobObject(IntPtr job,int kind,ref Extended info,uint size);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
  [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr handle);
  IntPtr job;
  public CompanionLifetime(){job=CreateJobObject(IntPtr.Zero,null);if(job==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());var info=new Extended();info.basic.flags=0x2000;if(!SetInformationJobObject(job,9,ref info,(uint)Marshal.SizeOf(info))){int error=Marshal.GetLastWin32Error();Dispose();throw new System.ComponentModel.Win32Exception(error);}}
  public void Attach(Process process){if(job==IntPtr.Zero||!AssignProcessToJobObject(job,process.Handle))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());}
  public void Dispose(){if(job!=IntPtr.Zero){CloseHandle(job);job=IntPtr.Zero;}}
 }
 // Focus only the process we launched, once its visible game window exists.
 public static class LaunchFocus {
  [DllImport("user32.dll")]static extern bool SetWindowPos(IntPtr window,IntPtr after,int x,int y,int width,int height,uint flags);
  [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr window);
  [DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
  [DllImport("user32.dll")]static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")]static extern bool SetForegroundWindow(IntPtr window);
  [DllImport("user32.dll")]static extern bool BringWindowToTop(IntPtr window);
  [DllImport("user32.dll")]static extern IntPtr SetFocus(IntPtr window);
  [DllImport("user32.dll")]static extern bool ShowWindowAsync(IntPtr window,int command);
  [DllImport("user32.dll")]static extern bool IsIconic(IntPtr window);
  [DllImport("user32.dll")]static extern bool AttachThreadInput(uint current,uint target,bool attach);
  [DllImport("user32.dll")]static extern bool AllowSetForegroundWindow(uint process);
  [DllImport("kernel32.dll")]static extern uint GetCurrentThreadId();
  public static bool Activate(IntPtr window,uint expectedProcess){uint process;if(window==IntPtr.Zero||!IsWindowVisible(window))return false;uint target=GetWindowThreadProcessId(window,out process);if(process!=expectedProcess)return false;uint ignored,current=GetCurrentThreadId(),foreground=GetWindowThreadProcessId(GetForegroundWindow(),out ignored);bool linkedTarget=false,linkedForeground=false;
   try{AllowSetForegroundWindow(process);if(IsIconic(window))ShowWindowAsync(window,9);if(target!=current)linkedTarget=AttachThreadInput(current,target,true);if(foreground!=current&&foreground!=target)linkedForeground=AttachThreadInput(current,foreground,true);BringWindowToTop(window);SetForegroundWindow(window);SetFocus(window);return GetForegroundWindow()==window;}
   finally{if(linkedForeground)AttachThreadInput(current,foreground,false);if(linkedTarget)AttachThreadInput(current,target,false);}
  }
  public static bool Reveal(IntPtr window,uint process){if(window==IntPtr.Zero)return false;ShowWindowAsync(window,1);SetWindowPos(window,IntPtr.Zero,0,0,0,0,0x43);return Activate(window,process);}
  public static async Task Game(Process game){try{await Task.Run(()=>{try{game.WaitForInputIdle(10000);}catch{}});for(int i=0;i<100&&!game.HasExited;++i){game.Refresh();if(Activate(game.MainWindowHandle,(uint)game.Id))return;await Task.Delay(100);}}catch(InvalidOperationException){}catch(System.ComponentModel.Win32Exception){}}
 }
 public class Launcher:Form {
  string root;ReleaseConfig config;UpdateInfo update;Label status=new Label();Button vr=new Button(),standard=new Button(),install=new Button();Process companion;CompanionLifetime companionLifetime;bool ownCompanion=false,starting=false,skipNextUpdateCheck=false;
  public Launcher(){root=Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\')).FullName;config=Updates.Config(root);Text="Red Faction Guerrilla Re-MARS-tered";ClientSize=new Size(530,330);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;StartPosition=FormStartPosition.CenterScreen;Font=new Font("Segoe UI",11);Controls.Add(new Label{Text="How would you like to play?",Font=new Font("Segoe UI",19,FontStyle.Bold),Location=new Point(25,25),Size=new Size(480,50)});vr.Text="Play in VR";vr.SetBounds(25,95,230,60);vr.Click+=async(s,e)=>await StartVR();Controls.Add(vr);standard.Text="Standard game";standard.SetBounds(275,95,230,60);standard.Click+=(s,e)=>StartGame(false);Controls.Add(standard);status.Text="VR requires an active OpenXR runtime and controllers.";status.SetBounds(25,175,480,60);Controls.Add(status);install.Text="Check for updates";install.Visible=true;install.SetBounds(25,245,200,35);install.Click+=async(s,e)=>await UpdateButton();Controls.Add(install);Controls.Add(new Label{Text="Installed VR mod: v"+config.version,Location=new Point(25,293),Size=new Size(480,25)});Shown+=async(s,e)=>{if(Environment.GetCommandLineArgs().Skip(1).Any(a=>a=="--vr"||a=="--resume-vr"))await StartVR();};FormClosed+=(s,e)=>{if(companionLifetime!=null)companionLifetime.Dispose();};FormClosing+=(s,e)=>{if(starting&&ownCompanion&&companion!=null)try{if(!companion.HasExited)companion.Kill();}catch{}};}
  async Task UpdateButton(){if(starting)return;vr.Enabled=standard.Enabled=install.Enabled=false;try{if(Core.Running("rfg",root))throw new IOException("Close the game before updating.");config=Updates.Config(root);if(update!=null){await Updates.Install(update,root);Close();return;}if(String.IsNullOrWhiteSpace(config.repository)){status.Text="GitHub updates are not configured yet. Set repository in RFGRVR/release.json to owner/repository.";return;}status.Text="Checking GitHub releases�";update=await Updates.Check(config);status.Text=update==null?"You have the latest version (v"+config.version+").":"Update "+update.Version+" is ready. Press Install to update.";install.Text=update==null?"Check for updates":"Install "+update.Version;}catch(Exception ex){status.Text="Update unavailable: "+ex.Message;}finally{vr.Enabled=standard.Enabled=install.Enabled=true;}}
  async Task StartVR(){if(starting)return;if(Core.Running("rfg",root)){status.Text="The game is already running.";return;}vr.Enabled=false;standard.Enabled=false;status.Text="Checking for updates…";try{if(skipNextUpdateCheck){skipNextUpdateCheck=false;await CalibrateAndLaunch();return;}update=await Updates.Check(config);if(update!=null){status.Text="Update "+update.Version+" is available. Install it, or press Play in VR again to use this version.";install.Visible=true;install.Text="Install "+update.Version;vr.Enabled=standard.Enabled=true;skipNextUpdateCheck=true;return;}}catch(Exception){status.Text="Update check unavailable. Launching your installed version.";}await CalibrateAndLaunch();}
  async Task CalibrateAndLaunch(){
   starting=true;
   try{
    string bridge=Path.Combine(root,@"vr-research\project\bin\RFGRVR_OpenXR.exe");
    if(!File.Exists(bridge))throw new IOException("VR companion missing. Run the installer to repair the mod.");
    companion=Process.GetProcessesByName("RFGRVR_OpenXR").FirstOrDefault(p=>{try{return String.Equals(p.MainModule.FileName,bridge,StringComparison.OrdinalIgnoreCase);}catch{return false;}});
    bool fresh=NeedsFreshCalibration(Environment.GetCommandLineArgs().Skip(1).ToArray());
    if(companion!=null&&fresh){companion.Kill();while(!companion.HasExited){if(IsDisposed)return;await Task.Delay(100);}companion.Dispose();companion=null;await Task.Delay(250);}
    if(companionLifetime==null)companionLifetime=new CompanionLifetime();
    if(companion==null){
     status.Text="Preparing Mason calibration scene�";await Task.Run(()=>{GameAssets.Prepare(root);});if(IsDisposed)return;
     Directory.CreateDirectory(Path.Combine(root,@"vr-research\output"));
     companion=Process.Start(new ProcessStartInfo(bridge,"86400"){WorkingDirectory=Path.GetDirectoryName(bridge),UseShellExecute=false,CreateNoWindow=true});
    }
    ownCompanion=true;companionLifetime.Attach(companion);
    status.Text="T-pose and hold both triggers, then follow the left/right/up/down head guide. Mason keeps his size. The game starts after calibration. Close this window to cancel.";LaunchFocus.Reveal(Handle,(uint)Process.GetCurrentProcess().Id);
    string calibration=Path.Combine(root,@"vr-research\output\calibration-ready.json");bool ready=false;
    while(!IsDisposed&&!companion.HasExited){
     try{if(File.Exists(calibration)){var data=Core.Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(calibration));ready=Convert.ToInt32(data["bridgePid"])==companion.Id;}}catch{}
     if(ready)break;await Task.Delay(250);
    }
    if(IsDisposed)return;if(!ready)throw new IOException("The VR companion exited before calibration completed.");StartGame(true);
   }catch(Exception ex){if(ownCompanion&&companion!=null)try{if(!companion.HasExited)companion.Kill();}catch{}starting=false;vr.Enabled=standard.Enabled=true;status.Text=ex.Message;}
  }

  async void StartGame(bool virtualReality){try{if(Core.Running("rfg",root))throw new IOException("The game is already running.");if(!virtualReality)foreach(var p in Process.GetProcessesByName("RFGRVR_OpenXR")){using(p){try{if(String.Equals(p.MainModule.FileName,Path.Combine(root,@"vr-research\project\bin\RFGRVR_OpenXR.exe"),StringComparison.OrdinalIgnoreCase))p.Kill();}catch{}}}string exe=Path.Combine(root,"rfg.exe");var info=new ProcessStartInfo(exe){WorkingDirectory=root,UseShellExecute=false};info.EnvironmentVariables["RFGRVR_LAUNCH_MODE"]=virtualReality?"vr":"standard";info.EnvironmentVariables["SteamAppId"]="667720";info.EnvironmentVariables["SteamGameId"]="667720";string[] args=Environment.GetCommandLineArgs().Skip(1).ToArray();if(args.Length>0&&String.Equals(Path.GetFileName(args[0]),"rfg.exe",StringComparison.OrdinalIgnoreCase))info.Arguments=String.Join(" ",args.Skip(1).Select(Quote));using(var game=Process.Start(info)){starting=false;Hide();await LaunchFocus.Game(game);await Task.Run(()=>game.WaitForExit());}if(ownCompanion&&companion!=null&&!companion.HasExited)companion.Kill();Close();}catch(Exception ex){starting=false;Show();status.Text=ex.Message;vr.Enabled=standard.Enabled=true;}}
  public static bool NeedsFreshCalibration(string[] args){return !args.Any(a=>a=="--resume-vr");}
  public static string Quote(string s){return "\""+Regex.Replace(s,@"(\\*)""","$1$1\\\"").TrimEnd('\\')+new string('\\',s.Reverse().TakeWhile(c=>c=='\\').Count()*2)+"\"";}
  [STAThread]public static void Main(){ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;Application.EnableVisualStyles();using(var mutex=new System.Threading.Mutex(true,"Local\\RFGRVR_LaunchSelector",out owned)){if(!owned)return;Application.Run(new Launcher());}}static bool owned;
 }
}
