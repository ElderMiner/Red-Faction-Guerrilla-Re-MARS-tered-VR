#pragma once
#include <cstdint>
// One high-resolution integration step per heading update, never per eye.
struct RFGRVRTurnClock {
 int64_t previous=0;
 float step(int64_t counter,int64_t frequency,bool update){
  if(!update)return 0;
  const int64_t old=previous;previous=counter;
  if(!old||counter<=old||frequency<=0)return 0;
  double seconds=double(counter-old)/double(frequency);
  return float(seconds>.05?.05:seconds);
 }
};
