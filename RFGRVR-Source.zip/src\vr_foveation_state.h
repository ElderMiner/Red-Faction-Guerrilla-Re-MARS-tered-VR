#pragma once
#include <windows.h>
#include <cstdint>
#include <cstring>
namespace vrfoveation {
struct Gaze {DWORD bridge=0,tick=0;unsigned valid=0;float orientation[4]{0,0,0,1};};
struct Bus {DWORD magic=0x46565231;volatile LONG sequence=0;Gaze gaze{};volatile LONG gamePid=0,supported=0,active=0,error=0;volatile LONG draws=0,changes=0;};
#ifdef RFGR_TEST_USER_SETTINGS
inline constexpr wchar_t busName[]=L"Local\\RFGRVR_TEST_Foveation_v1";
#else
inline constexpr wchar_t busName[]=L"Local\\RFGRVR_Foveation_v1";
#endif
inline Bus* bus(){static HANDLE mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Bus),busName);static Bus* p=mapping?(Bus*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Bus)):nullptr;if(p)InterlockedCompareExchange((volatile LONG*)&p->magic,0x46565231,0);return p;}
inline void publish(const Gaze& gaze){if(auto* p=bus()){InterlockedIncrement(&p->sequence);p->gaze=gaze;MemoryBarrier();InterlockedIncrement(&p->sequence);}}
inline bool read(Gaze& out){auto* p=bus();if(!p||p->magic!=0x46565231)return false;for(unsigned i=0;i<3;++i){LONG a=p->sequence;if(a&1)continue;Gaze g=p->gaze;MemoryBarrier();if(a==p->sequence){out=g;return g.valid&&DWORD(GetTickCount()-g.tick)<=60;}}return false;}
inline bool available(){auto* p=bus();return p&&p->supported&&p->gamePid&&!p->error;}
}
