#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "../src/vr_pixel_probe.h"
#include <cassert>
using Microsoft::WRL::ComPtr;
int main(int argc,char** argv){
 assert(argc==2||argc==3);ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,argc==3?D3D_DRIVER_TYPE_HARDWARE:D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));
 D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=64;desc.MipLevels=desc.ArraySize=1;desc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.SampleDesc.Count=1;desc.Usage=D3D11_USAGE_DEFAULT;desc.BindFlags=D3D11_BIND_RENDER_TARGET;
 ComPtr<ID3D11Texture2D> t;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&t)));ComPtr<ID3D11RenderTargetView> rtv;assert(SUCCEEDED(d->CreateRenderTargetView(t.Get(),nullptr,&rtv)));ID3D11RenderTargetView* raw=rtv.Get();c->OMSetRenderTargets(1,&raw,nullptr);
 D3D11_VIEWPORT viewport{3,5,51,49,.1f,.9f};c->RSSetViewports(1,&viewport);
 D3D11_TEXTURE2D_DESC inputDesc=desc;inputDesc.BindFlags=D3D11_BIND_SHADER_RESOURCE;ComPtr<ID3D11Texture2D> input;assert(SUCCEEDED(d->CreateTexture2D(&inputDesc,nullptr,&input)));ComPtr<ID3D11ShaderResourceView> inputView;assert(SUCCEEDED(d->CreateShaderResourceView(input.Get(),nullptr,&inputView)));ID3D11ShaderResourceView* rawInput=inputView.Get();c->PSSetShaderResources(127,1,&rawInput);
 assert(RFGRVRPixelProbe::begin(c.Get()));float red[4]={1,0,0,1},blue[4]={0,0,1,1};c->ClearRenderTargetView(rtv.Get(),red);RFGRVRPixelProbe::eye=0;RFGRVRPixelProbe::record(c.Get(),12,0,0,0,0,rtv.Get());
 c->ClearRenderTargetView(rtv.Get(),blue);RFGRVRPixelProbe::eye=1;RFGRVRPixelProbe::record(c.Get(),12,0,0,0,0,rtv.Get());
 c->OMSetRenderTargets(0,nullptr,nullptr);RFGRVRPixelProbe::record(c.Get(),39,24);c->OMSetRenderTargets(1,&raw,nullptr);assert(RFGRVRPixelProbe::events.size()==3&&RFGRVRPixelProbe::sources.size()==1);assert(RFGRVRPixelProbe::events[2].target==~0u);assert(RFGRVRPixelProbe::events[0].eye==0&&RFGRVRPixelProbe::events[1].eye==1);assert(RFGRVRPixelProbe::dropped==0);
 assert(RFGRVRPixelProbe::events[0].srv[127]==(uintptr_t)inputView.Get()&&RFGRVRPixelProbe::inputs.size()==1&&RFGRVRPixelProbe::inputs[0].resource.Get()==input.Get());
 assert(RFGRVRPixelProbe::finish(argv[1]));ComPtr<ID3D11RenderTargetView> stillBound;c->OMGetRenderTargets(1,&stillBound,nullptr);assert(stillBound.Get()==rtv.Get());UINT n=1;D3D11_VIEWPORT after{};c->RSGetViewports(&n,&after);assert(after.TopLeftX==3&&after.TopLeftY==5&&after.Width==51&&after.Height==49&&after.MinDepth==.1f&&after.MaxDepth==.9f);
 ComPtr<ID3D11ShaderResourceView> stillInput;c->PSGetShaderResources(127,1,&stillInput);assert(stillInput.Get()==inputView.Get());
 char path[MAX_PATH]{};sprintf_s(path,"%s-target-0.bin",argv[1]);FILE* f=nullptr;assert(!fopen_s(&f,path,"rb")&&f);unsigned char pixels[128]{};assert(fread(pixels,1,sizeof(pixels),f)==sizeof(pixels));assert(fgetc(f)==EOF);fclose(f);
 for(unsigned i=0;i<32;++i){assert(pixels[i*4+(i<16?0:2)]==255&&pixels[i*4+(i<16?2:0)]==0&&pixels[i*4+1]==0&&pixels[i*4+3]==255);}
}


