#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <cstring>
#include <cassert>
#include "../src/vr_batch_trace.h"
static unsigned calls=0;
static void __fastcall batch(void* s,void*,void* r,unsigned m,unsigned f){assert(s==(void*)1&&r==(void*)2&&m==0x87654321&&f==3);++calls;}
static void __fastcall list(void* s,void*,void* r,void* other,unsigned m,unsigned f){assert(s==(void*)1&&r==(void*)2&&other==(void*)3&&m==0x12345678&&f==1);++calls;}
int main(){RFGRVRBatchTrace::batch=(RFGRVRBatchTrace::Batch)&batch;RFGRVRBatchTrace::list=(RFGRVRBatchTrace::List)&list;RFGRVRBatchTrace::onBatch((void*)1,nullptr,(void*)2,0x87654321,3);RFGRVRBatchTrace::onList((void*)1,nullptr,(void*)2,(void*)3,0x12345678,1);assert(calls==2&&RFGRVRBatchTrace::rows==0);assert(!RFGRVRBatchTrace::readable(nullptr,4));unsigned value=73;assert(RFGRVRBatchTrace::word(&value,0)==73);}
