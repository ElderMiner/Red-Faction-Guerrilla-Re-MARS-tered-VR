#include "../src/vr_neutral_pose.h"
#include <cassert>
using namespace vrarm;
int main(){M identity{{1,0,0},{0,1,0},{0,0,1}};Pose root{turnAround(turnAround(identity,{0,1,0},.56f),{1,0,0},.1f),{0,.93f,0}};
 Pose spine{root.b,add(root.p,world(root.b,{0,.5f,0}))};auto fixed=RFGRVR_NeutralBone(spine,root,1);
 assert(length(sub(fixed.b.u,identity.u))<.00001f&&length(sub(fixed.b.f,identity.f))<.00001f);
 assert(length(sub(fixed.p,V{0,1.43f,0}))<.00001f);
 for(int i=0;i<=10;++i)assert(valid(RFGRVR_NeutralBone(spine,root,i*.1f).b));
 RFGRVRNeutralPose idle;float w=0;for(int i=0;i<80;++i)w=idle.update({1,0,0},1.f/90,true);assert(w==1);
 for(int i=0;i<30;++i)w=idle.update({1+float(i)*.02f,0,0},1.f/90,true);assert(w==1); // walking cannot relinquish facing
 assert(idle.update({2,0,0},2,true)==1); // frame stall cannot reset pose ownership
 for(int i=0;i<80;++i)w=idle.update({1,0,0},1.f/90,false);assert(w==0);
 idle.reset();assert(idle.weight==0&&!idle.ready);
}
