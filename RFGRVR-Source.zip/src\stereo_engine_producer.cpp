#include "stereo_engine_producer.h"
#include "stereo_gpu_protocol.h"
#include <wrl/client.h>
#include <cstring>
#include <cmath>
using Microsoft::WRL::ComPtr;
namespace {
struct Producer {
    HANDLE map=nullptr;
    RFGRStereoGpuShared* shared=nullptr;
    ComPtr<ID3D11Device> device;
    ComPtr<ID3D11Texture2D> tex[2], depth[2];
    ComPtr<ID3D11RenderTargetView> rtv[2];
    ComPtr<ID3D11DepthStencilView> dsv[2];
    ComPtr<IDXGIKeyedMutex> mutex[2];
    HANDLE exported[2]{};
    UINT width=0,height=0;
    DXGI_FORMAT format=DXGI_FORMAT_UNKNOWN;
    DWORD ownerThread=0;
    volatile LONG entered=0;
} g;
static bool validPose(const RFGREye& e) {
    if ((e.pose.validFlags&3)!=3)return false;
    float n=0;
    for(float x:e.pose.orientation){if(!std::isfinite(x))return false;n+=x*x;}
    if(n<.85f||n>1.15f)return false;
    for(float x:e.pose.position)if(!std::isfinite(x))return false;
    for(float x:e.fov)if(!std::isfinite(x))return false;
    return e.fov[0]<0&&e.fov[1]>0&&e.fov[2]>0&&e.fov[3]<0;
}
static bool eyesDifferent(const RFGREye& l,const RFGREye& r){
    float ds=0;
    for(unsigned i=0;i<3;i++){const float d=l.pose.position[i]-r.pose.position[i];ds+=d*d;}
    for(unsigned i=0;i<4;i++){const float d=l.pose.orientation[i]-r.pose.orientation[i];ds+=d*d;}
    return ds>0.0000000001f;
}
static bool snapshotEyes(RFGREye out[2]){
    HANDLE map=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_MAP_NAME);
    if(!map)return false;
    auto* s=static_cast<RFGRShared*>(MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(RFGRShared)));
    bool ok=false;
    if(s && s->magic==RFGR_MAGIC && s->version==RFGR_PROTOCOL){
        for(unsigned a=0;a<3;a++){
            LONG before=s->stereoSequence;
            if(before&1)continue;
            MemoryBarrier();
            RFGREye l=s->eyes[0],r=s->eyes[1];
            LONG valid=s->stereoValid;
            MemoryBarrier();
            LONG after=s->stereoSequence;
            if(before==after && !(after&1) && valid && validPose(l)&&validPose(r)&&eyesDifferent(l,r)){
                out[0]=l;out[1]=r;ok=true;break;
            }
        }
    }
    if(s)UnmapViewOfFile(s);
    CloseHandle(map);
    return ok;
}
static void shutdown(){
    if(g.shared)InterlockedExchange(&g.shared->ready,0);
    for(unsigned i=0;i<2;i++){
        g.mutex[i].Reset();g.dsv[i].Reset();g.rtv[i].Reset();g.depth[i].Reset();g.tex[i].Reset();g.exported[i]=nullptr;
    }
    g.device.Reset();
    if(g.shared){UnmapViewOfFile(g.shared);g.shared=nullptr;}
    if(g.map){CloseHandle(g.map);g.map=nullptr;}
    g.ownerThread=0;g.width=g.height=0;g.format=DXGI_FORMAT_UNKNOWN;
}
static bool createEye(unsigned i){
    D3D11_TEXTURE2D_DESC d{};
    d.Width=g.width;d.Height=g.height;d.MipLevels=1;d.ArraySize=1;d.Format=g.format;
    d.SampleDesc.Count=1;d.Usage=D3D11_USAGE_DEFAULT;
    d.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;
    d.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
    if(FAILED(g.device->CreateTexture2D(&d,nullptr,&g.tex[i])))return false;
    if(FAILED(g.device->CreateRenderTargetView(g.tex[i].Get(),nullptr,&g.rtv[i])))return false;
    if(FAILED(g.tex[i].As(&g.mutex[i])))return false;
    ComPtr<IDXGIResource> sharedResource;
    if(FAILED(g.tex[i].As(&sharedResource)))return false;
    if(FAILED(sharedResource->GetSharedHandle(&g.exported[i])) || !g.exported[i])return false;
    D3D11_TEXTURE2D_DESC z{};z.Width=g.width;z.Height=g.height;z.MipLevels=1;z.ArraySize=1;
    z.Format=DXGI_FORMAT_D24_UNORM_S8_UINT;z.SampleDesc.Count=1;
    z.Usage=D3D11_USAGE_DEFAULT;z.BindFlags=D3D11_BIND_DEPTH_STENCIL;
    if(FAILED(g.device->CreateTexture2D(&z,nullptr,&g.depth[i])))return false;
    return SUCCEEDED(g.device->CreateDepthStencilView(g.depth[i].Get(),nullptr,&g.dsv[i]));
}
struct Busy {
    bool held;
    Busy():held(InterlockedCompareExchange(&g.entered,1,0)==0){}
    ~Busy(){if(held)InterlockedExchange(&g.entered,0);}
};
}
extern "C" __declspec(dllexport) BOOL __stdcall RFGRVR_StereoProducer_Init(ID3D11Device* device,UINT w,UINT h,DXGI_FORMAT format){
    Busy guard;if(!guard.held)return FALSE;
    if(!device||!w||!h||w>8192||h>8192||
       (format!=DXGI_FORMAT_R8G8B8A8_UNORM && format!=DXGI_FORMAT_B8G8R8A8_UNORM &&
        format!=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB && format!=DXGI_FORMAT_B8G8R8A8_UNORM_SRGB))return FALSE;
    if(g.shared && g.device.Get()==device && g.width==w && g.height==h && g.format==format)return TRUE;
    shutdown();
    g.ownerThread=GetCurrentThreadId();g.device=device;g.width=w;g.height=h;g.format=format;
    // Single producer per game. The mapping name is the same one used by the v7 XR bridge.
    g.map=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRStereoGpuShared),RFGR_STEREO_GPU_MAP);
    if(!g.map || GetLastError()==ERROR_ALREADY_EXISTS){shutdown();return FALSE;}
    g.shared=static_cast<RFGRStereoGpuShared*>(MapViewOfFile(g.map,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRStereoGpuShared)));
    if(!g.shared){shutdown();return FALSE;}
    ZeroMemory(g.shared,sizeof(*g.shared));
    if(!createEye(0)||!createEye(1)||g.exported[0]==g.exported[1]){shutdown();return FALSE;}
    g.shared->magic=RFGR_STEREO_GPU_MAGIC;g.shared->version=2;
    g.shared->width=w;g.shared->height=h;g.shared->format=static_cast<unsigned>(format);
    for(unsigned i=0;i<2;i++)g.shared->eyeHandle[i]=static_cast<uint64_t>(reinterpret_cast<uintptr_t>(g.exported[i]));
    MemoryBarrier();InterlockedExchange(&g.shared->ready,1);
    return TRUE;
}
extern "C" __declspec(dllexport) BOOL __stdcall RFGRVR_StereoProducer_Render(ID3D11DeviceContext* ctx, RFGRVRRenderEngineEye renderEye,void* user){
    Busy guard;if(!guard.held || !ctx || !renderEye || GetCurrentThreadId()!=g.ownerThread || !g.shared || g.shared->ready!=1)return FALSE;
    ComPtr<ID3D11Device> d;ctx->GetDevice(&d);if(d.Get()!=g.device.Get())return FALSE;
    RFGREye eyes[2]{};if(!snapshotEyes(eyes))return FALSE;
    // Acquire BOTH eye buffers before rendering so partial frames are never published.
    // Never block the render thread waiting for the companion process.
    if(g.mutex[0]->AcquireSync(0,0)!=S_OK)return FALSE;
    if(g.mutex[1]->AcquireSync(0,0)!=S_OK){g.mutex[0]->ReleaseSync(0);return FALSE;}
    bool complete=true;
    for(unsigned i=0;i<2;i++){
        RFGRVREyeRenderContext args{i,&eyes[i],ctx,g.rtv[i].Get(),g.dsv[i].Get(),g.width,g.height,{}};
        if(!RFGRVR_BuildD3DProjection(eyes[i].fov,0.05f,2000.f,&args.d3dProjection)){complete=false;break;}
        if(!renderEye(user,&args)){complete=false;break;}
    }
    if(complete)ctx->Flush();
    // A callback failure keeps both mutexes at producer key 0.
    // On success both buffers are handed off with consumer key 1.
    HRESULT a=g.mutex[0]->ReleaseSync(complete?1:0);
    HRESULT b=g.mutex[1]->ReleaseSync(complete?1:0);
    if(!complete||FAILED(a)||FAILED(b))return FALSE;
    MemoryBarrier();
    InterlockedIncrement(&g.shared->eyeFrames[0]);
    InterlockedIncrement(&g.shared->eyeFrames[1]);
    return TRUE;
}
extern "C" __declspec(dllexport) void __stdcall RFGRVR_StereoProducer_Shutdown(){
    Busy guard;if(!guard.held)return;
    if(g.ownerThread && g.ownerThread!=GetCurrentThreadId())return;
    shutdown();
}
