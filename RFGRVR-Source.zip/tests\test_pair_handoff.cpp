#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <cassert>
#include "../src/vr_pair_mutex.h"
using Microsoft::WRL::ComPtr;
int main(){ComPtr<ID3D11Device>d;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,nullptr)));ComPtr<ID3D11Texture2D>t[2];ComPtr<IDXGIKeyedMutex>m[2];D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=16;desc.MipLevels=desc.ArraySize=1;desc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.SampleDesc.Count=1;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;desc.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;for(int i=0;i<2;++i){assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&t[i])));assert(SUCCEEDED(t[i].As(&m[i])));}assert(m[0]->AcquireSync(0,0)==S_OK);m[0]->ReleaseSync(1);assert(RFGRVR_AcquirePair(m[0].Get(),m[1].Get()));m[0]->ReleaseSync(1);m[1]->ReleaseSync(1);assert(RFGRVR_AcquirePair(m[0].Get(),m[1].Get()));m[0]->ReleaseSync(1);m[1]->ReleaseSync(7);assert(!RFGRVR_AcquirePair(m[0].Get(),m[1].Get()));assert(m[0]->AcquireSync(1,0)==S_OK);m[0]->ReleaseSync(0);assert(m[1]->AcquireSync(7,0)==S_OK);m[1]->ReleaseSync(0);assert(RFGRVR_AcquirePair(m[0].Get(),m[1].Get()));m[0]->ReleaseSync(1);m[1]->ReleaseSync(1);
// Steady stereo must leave a pending pair available to its consumer.
assert(!RFGRVR_AcquirePair(m[0].Get(),m[1].Get(),false));
assert(m[0]->AcquireSync(1,0)==S_OK);assert(m[1]->AcquireSync(1,0)==S_OK);
m[0]->ReleaseSync(0);m[1]->ReleaseSync(0);
assert(RFGRVR_AcquirePair(m[0].Get(),m[1].Get(),false,1));m[0]->ReleaseSync(1);m[1]->ReleaseSync(1);
assert(!RFGRVR_AcquirePair(m[0].Get(),m[1].Get(),false,1));
assert(m[0]->AcquireSync(1,0)==S_OK&&m[1]->AcquireSync(1,0)==S_OK);m[0]->ReleaseSync(0);m[1]->ReleaseSync(0);}
