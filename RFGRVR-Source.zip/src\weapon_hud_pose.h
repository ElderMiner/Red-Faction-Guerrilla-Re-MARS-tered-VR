#pragma once
#include "ipc.h"
#include "vr_arm_math.h"
#ifdef RFGR_TEST_WEAPON_HUD_CHANNELS
static constexpr wchar_t RFGR_WEAPON_HUD_POSE[]=L"Local\\RFGRVR_TEST_WeaponHudPose_v2";
#else
static constexpr wchar_t RFGR_WEAPON_HUD_POSE[]=L"Local\\RFGRVR_WeaponHudPose_v2";
#endif
struct RFGRHudAnchor {int hand=-1;vrarm::Pose local{};};
struct RFGRWeaponHudPose {unsigned magic=0x48554432;volatile LONG sequence=0;DWORD tick=0;unsigned weapon=0;RFGRHudAnchor ammo{},charges{};int supportHand=-1;float supportPoint[3]{};unsigned supportHeld=0;float chestPosition[3]{},chestYaw=0;unsigned chestValid=0;};
inline RFGRHudAnchor RFGRVR_PalmHudAnchor(int hand,bool chargeStatus=false){
 RFGRHudAnchor out;if(hand<0||hand>1)return out;float side=hand? -1.f:1.f;
 out.hand=hand;out.local.b={{0,-side,0},{0,0,-1},{side,0,0}};
 // Face the palm, rather than assuming the detonator shares rifle axes.
 // Two panels sit beside each other, clear of the glove and wrist map.
 out.local.p={side*.06f,chargeStatus?-.09f:.035f,-.11f};return out;
}
inline RFGRHudAnchor RFGRVR_HudAnchor(int hand,const vrarm::Pose& controller,const vrarm::Pose& item,float scale,bool rightSide=false){
 using namespace vrarm;RFGRHudAnchor out;if(hand<0||hand>1||!valid(controller.b)||!valid(item.b)||!finite(item.p)||!std::isfinite(scale)||scale<.1f)return out;
 // Native +Z is barrel-forward. Text runs along the receiver and faces out.
 float side=rightSide?1.f:-1.f;Pose panel{{mul(item.b.f,side),item.b.u,mul(item.b.r,side)},add(item.p,world(item.b,{side*.055f*scale,.065f*scale,.10f*scale}))};
 M relativeBasis=relative(controller.b,panel.b);V offset=mul(local(controller.b,sub(panel.p,controller.p)),1/scale);
 // Game controller basis maps XR -Z to native +Z; panel +Z is its front.
 out.hand=hand;out.local={M{{relativeBasis.r.x,relativeBasis.r.y,-relativeBasis.r.z},{relativeBasis.u.x,relativeBasis.u.y,-relativeBasis.u.z},{relativeBasis.f.x,relativeBasis.f.y,-relativeBasis.f.z}},{offset.x,offset.y,-offset.z}};return out;
}
inline bool RFGRVR_HudPose(const RFGRPose& hand,const RFGRHudAnchor& anchor,RFGRPose& out){
 using namespace vrarm;if(anchor.hand<0||(hand.validFlags&3)!=3||!hand.active||!valid(anchor.local.b)||!finite(anchor.local.p))return false;
 float x=hand.orientation[0],y=hand.orientation[1],z=hand.orientation[2],w=hand.orientation[3];if(fabsf(x*x+y*y+z*z+w*w-1)>.05f)return false;
 M h{{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};
 M b=compose(h,anchor.local.b);V p=add(V{hand.position[0],hand.position[1],hand.position[2]},world(h,anchor.local.p));float trace=b.r.x+b.u.y+b.f.z;float q[4]{};
 if(trace>0){float s=sqrtf(trace+1)*2;q[3]=s*.25f;q[0]=(b.u.z-b.f.y)/s;q[1]=(b.f.x-b.r.z)/s;q[2]=(b.r.y-b.u.x)/s;}
 else if(b.r.x>b.u.y&&b.r.x>b.f.z){float s=sqrtf(1+b.r.x-b.u.y-b.f.z)*2;q[0]=s*.25f;q[1]=(b.u.x+b.r.y)/s;q[2]=(b.f.x+b.r.z)/s;q[3]=(b.u.z-b.f.y)/s;}
 else if(b.u.y>b.f.z){float s=sqrtf(1+b.u.y-b.r.x-b.f.z)*2;q[0]=(b.u.x+b.r.y)/s;q[1]=s*.25f;q[2]=(b.f.y+b.u.z)/s;q[3]=(b.f.x-b.r.z)/s;}
 else{float s=sqrtf(1+b.f.z-b.r.x-b.u.y)*2;q[0]=(b.f.x+b.r.z)/s;q[1]=(b.f.y+b.u.z)/s;q[2]=s*.25f;q[3]=(b.r.y-b.u.x)/s;}
 out=hand;memcpy(out.position,&p,12);memcpy(out.orientation,q,16);return true;
}
// Context prompts follow the hand position but remain readable as the wrist rolls.
inline bool RFGRVR_InteractionHudPose(const RFGRPose& head,const RFGRPose& hand,int dominant,RFGRPose& out){
 if((head.validFlags&3)!=3)return false;
 RFGRHudAnchor anchor;anchor.hand=dominant;anchor.local.b={{1,0,0},{0,1,0},{0,0,1}};anchor.local.p={0,.06f,-.25f};
 if(!RFGRVR_HudPose(hand,anchor,out))return false;
 float norm=0;for(float q:head.orientation)norm+=q*q;if(fabsf(norm-1)>.05f)return false;
 memcpy(out.orientation,head.orientation,sizeof(out.orientation));return true;
}

// Chest-height HUD follows view heading as a whole, without pitch/roll swivel.
inline bool RFGRVR_ChestLookHudPose(const RFGRPose& head,RFGRPose& out){
 if((head.validFlags&3)!=3)return false;float x=head.orientation[0],y=head.orientation[1],z=head.orientation[2],w=head.orientation[3];
 if(!std::isfinite(x+y+z+w)||fabsf(x*x+y*y+z*z+w*w-1)>.05f)return false;
 float yaw=atan2f(2*(x*z+w*y),1-2*(x*x+y*y));out=head;out.position[0]-=.5f*sinf(yaw);out.position[1]-=.5f;out.position[2]-=.5f*cosf(yaw);
 out.orientation[0]=out.orientation[2]=0;out.orientation[1]=sinf(yaw*.5f);out.orientation[3]=cosf(yaw*.5f);return true;
}

inline bool RFGRVR_MissionOfferHudPose(const RFGRPose& head,RFGRPose& out){if(!RFGRVR_ChestLookHudPose(head,out))return false;out.position[1]+=.14f;return true;}
