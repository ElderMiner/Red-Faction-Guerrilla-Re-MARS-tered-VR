#pragma once
#include <cmath>
// A mount relocation changes the tracking-space parent, not the physical floor.
// Capture once per mount; never zero tracking every rendered eye or frame.
struct RFGRVRMountTracking {
 unsigned identity=~0u;
 bool update(unsigned mount,const float center[3],float origin[3]){
  if(mount==identity)return false;
  bool relocating=mount!=~0u||identity!=~0u;
  identity=mount;
  if(!relocating||!std::isfinite(center[0])||!std::isfinite(center[2]))return false;
  origin[0]=center[0];origin[2]=center[2];return true;
 }
};
