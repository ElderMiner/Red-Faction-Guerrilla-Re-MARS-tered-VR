#include "gpu_common.h"
#include <algorithm>
int main() {
    ComPtr<ID3D11Device> dev; ComPtr<ID3D11DeviceContext> ctx;
    HRESULT hr=makeDevice(dev,ctx); if(FAILED(hr)){msg("x86 D3D device failure",hr);return 2;}
    D3D11_TEXTURE2D_DESC desc{};desc.Width=960;desc.Height=540;desc.MipLevels=1;desc.ArraySize=1;
    desc.Format=DXGI_FORMAT_B8G8R8A8_UNORM;desc.SampleDesc.Count=1;
    desc.Usage=D3D11_USAGE_DEFAULT;desc.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;
    desc.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
    ComPtr<ID3D11Texture2D> tex;
    hr=dev->CreateTexture2D(&desc,nullptr,&tex);if(FAILED(hr)){msg("Create shared texture failed",hr);return 3;}
    ComPtr<IDXGIResource> resource;hr=tex.As(&resource);if(FAILED(hr))return 4;
    HANDLE share=nullptr;hr=resource->GetSharedHandle(&share);
    if(FAILED(hr)||!share){msg("GetSharedHandle failed",hr);return 5;}
    ComPtr<IDXGIKeyedMutex> mutex;hr=tex.As(&mutex);if(FAILED(hr))return 6;
    ComPtr<ID3D11RenderTargetView> rtv;hr=dev->CreateRenderTargetView(tex.Get(),nullptr,&rtv);
    if(FAILED(hr)){msg("Create RTV failed",hr);return 7;}
    HANDLE mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRGpuShared),RFGR_GPU_MAP);
    if(!mapping){std::printf("CreateFileMapping failed: %lu\n",GetLastError());return 8;}
    auto* s=static_cast<RFGRGpuShared*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRGpuShared)));
    if(!s){CloseHandle(mapping);return 9;}
    // Avoid stale data if the mapped object already exists.
    ZeroMemory(s,sizeof(*s));s->magic=RFGR_GPU_MAGIC;s->version=1;s->width=desc.Width;
    s->height=desc.Height;s->format=desc.Format;s->legacyShareHandle=static_cast<uint64_t>(reinterpret_cast<uintptr_t>(share));
    MemoryBarrier();InterlockedExchange(&s->ready,1);
    std::puts("x86 producer ready. Start CONSUMER.exe (x64) within 30 seconds.");
    int result=0;
    for(int i=0;i<1800;++i){
        hr=mutex->AcquireSync(0,5000);if(FAILED(hr)){msg("producer AcquireSync failed",hr);result=10;break;}
        float rgba[4]={float(i%100)/100.f,0.2f,0.7f,1.f};ctx->ClearRenderTargetView(rtv.Get(),rgba);
        ctx->Flush();
        hr=mutex->ReleaseSync(1);if(FAILED(hr)){result=11;break;}
        InterlockedIncrement(&s->frames);
        if(s->acknowledged>=600){std::puts("PASS: x64 consumer received 600 frames");break;}
        Sleep(16);
    }
    if(s->acknowledged<600 && result==0){std::puts("FAIL: no completed 600-frame handshake");result=12;}
    InterlockedExchange(&s->ready,0);UnmapViewOfFile(s);CloseHandle(mapping);return result;
}
