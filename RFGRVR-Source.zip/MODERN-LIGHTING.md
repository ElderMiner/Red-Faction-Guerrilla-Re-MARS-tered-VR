# Experimental material renderer

Isolated fork of confirmed0.10.105. Experimental builds are installed locally for testing; the published stable release remains unchanged.

A marker RFGRVR-modern-lighting.enable beside rfg.exe opts into checksum-verified native material pixel shader replacement at creation. No extra eye buffers, compositor surfaces, per-frame texture copies or per-draw hooks are added. Standard mode still bypasses all VR hooks. Unknown shaders and compile/device failures retain native behavior.

Current coverage:46 verified rfg-brdf material resources (36 native lighting shaders mapped to24 verified texture/constant layouts), including generic, concrete, cloth, paint, rust and metal variants. Replaces their BRDF LUT lighting with GGX distribution, correlated Smith visibility, Schlick Fresnel and energy-weighted diffuse. Preserves native normal decoding, texture/tint/alpha interfaces, light color, point/spot attenuation, projected shadow input and fog. Legacy specular/gloss assets are heuristically converted; this is not newly authored PBR material data.

Terrain extension: checksum-selected high-detail four-layer ground/hill materials now use directional/local GGX shading, retaining ordered alpha blending, packed normals, per-layer tint, shadow/ambient occlusion and fog. Distant low-detail terrain still uses its native path. Hardware checks cover every layer selection, shadow rejection and identical per-eye radiometry.

Incomplete: distant terrain, road overlays and glass shaders, indirect bounce, environment reflections, volumetrics and shadow-map generation are not replaced. Do not claim a completed engine lighting overhaul or ray tracing. Native postprocess remains.

Mathematical reference (not copied engine code): https://google.github.io/filament/Filament.html
Native identities were obtained from local owned archives; only checksums are source data. No extracted shader binaries or game textures are distributable.

Next gate: hardware GPU shading/energy and state-isolation tests, then matched per-eye scene capture. No performance or visual improvement is claimed before measurement.


## Current development boundary

The working runtime path is material/terrain GGX shading. The latest source also adds native-clock night light/ambient control and a private HDR metering-floor adjustment. These changes need live balance verification. The native light collector copies bounded directional/point/spot uploads, with spot radians and range fields verified against the supported executable. It does not scan the world registry.

`modern_volumetrics.hlsl`, `modern_volume_renderer.h` and `test_modern_transport.cpp` implement/test a separate HDR volumetric backend: Beer-Lambert extinction, Henyey-Greenstein phase, directional/point/spot sources, shadow-array sampling, depth-limited ray lengths, quarter-resolution scattering and depth-aware upsampling. The renderer uses a private command list with immediate-state restoration, keeps native target alpha, rejects LDR targets and caches only its own reduced textures.

**The volumetric backend is not connected to the native scene yet.** Shadow-map ownership/matrices and the insertion point before native tone mapping still need actual-engine verification. Do not advertise active in-game god rays, new local-light shadows, or global illumination. Do not silently substitute additive sprite cones or a flat colour filter for those features.

An opt-in `RFGRVR-modern-engine-capture.enable` marker captures at most512 unique shader interface records with4096 bounded object mappings and one bounded scene/state/light snapshot plus one paired GPU trace. This is private local diagnostic data; none belongs in the distributed payload/source. The capture removes its request marker when scheduled. No native bytecode or game textures are added to the mod source.

## 0.11.3 diagnostic candidate

Adds29 ordinary surface resource variants (12 verified pixel-shader identities), including nodecal, standard, single-decal and metal/environment materials observed in the live scene. Keeps their native texture, fog, decal and shadow interfaces. Local passes without native shadow inputs do not sample a stale shadow binding. GPU checks verify lighting, decals and environment reflections.

The paired GPU trace now consumes its request marker once. A separately bounded diagnostic records the first three occupied-vehicle cascade calls, preserving all13 arguments and optimized caller registers. These private files are not distributed. Volumetric integration remains unfinished; this candidate does not enable god rays.

## Offline shadow integration work

See ENGINE-LIGHTING.md for the reverse-engineered pass map and exact verified
interfaces. Native captured cascade projections agree with clip-to-texture
conversion to within 1.5e-8, with approximately -0.00006 native depth bias.

The backend now preserves three reused shadow maps as an ordered texture array,
with immediate/deferred GPU overwrite regressions. Volumetric directional
lighting selects the containing cascade without counting one sun three times.
Tests reject incomplete/stale maps, bound depth sources and invalid matrices.
The GPU light ABI is now256 bytes per light /2224 bytes per frame; HLSL and
C++ layouts must stay aligned. This does not enable volumetrics in gameplay.
No new build has been installed or published for this offline work.

## 0.11.4 connected candidate (activation verified; appearance unverified)

The native cascade completion hook now records matching matrices/depth maps
on the actual engine context, and the existing pre-bloom source hook calls
world-depth-limited scattering before HDR downsampling. Main eye ownership,
resource dimensions/formats, immediate context, complete shadow epochs and
once-per-eye execution are checked; auxiliary/foreign cameras are rejected.
GPU tests exercise this production connection using native-layout fixtures
and read actual nonzero scattering from an R11 HDR target.

The separately verified local-light geometry writer is collected too.
The backend selects one directional light plus up to three nearby local
lights using fixed bounded storage. Local scattering uses current-eye
screen-space contact occlusion. It does not provide complete off-screen local
shadow maps. The world-height medium does not follow the player's head.

Three exact native final-HDR shader identities are replaced with filmic
highlight rolloff, bounded bloom and compatible native particle reconstruction.
Native scene storage scaling (1/8 in two HDR variants) and alpha semantics
are preserved. UI/menu shaders are not replaced. Exposure history and native
bloom filtering remain reusable engine infrastructure, not new GI.

This is a more connected candidate, not a claim of finished whole-engine
replacement or verified visual quality. Full local shadows, indirect bounce,
complete sky/reflection coordination and remaining material coverage still
need work. Keep the published release untouched.

Glass base/local lighting now uses an exact-identity GGX path with its verified
world-normal input ABI; authored opacity and specular-amount controls stay in
charge. GPU tests cover both variants and the unchanged opacity contract.

The 0.11.3 coverage audit also identified remaster-generated terrain/surface
shader interfaces outside the legacy .fxo set. The opt-in private catalogue
can now retain up to64 of those compiled shaders (1 MiB each maximum) beneath
vr-research/output for analysis. Those are proprietary local diagnostic assets;
never distribute them. They are captured only during an explicitly enabled
engine capture, never during ordinary rendering.

The native capture establishes that HDR downsampling uses the secondary,
deferred renderer. The runtime connection accepts only the explicitly supplied
primary/secondary pair, with matching eye position. Immediate work uses the
private command list; deferred work records inline and restores native graphics
bindings and predication. An additional real-GPU regression covers primary
immediate shadow copies feeding secondary deferred HDR scattering, including
reading nonzero output after native-style command-list execution.

See Microsoft's context ordering documentation:
https://learn.microsoft.com/en-us/windows/win32/direct3d11/overviews-direct3d-11-render-multi-thread-render

## 0.11.5 generated-material extension

The private 0.11.4 gameplay capture confirmed 4,503 volumetric draws and 15,840
native shadow copies with zero recorded resource/camera rejections at eye epoch
5,280. This proves engine activation, not visual quality or an FPS improvement.

26 exact generated shader identities now use 20 original GGX templates for
standard/decal surfaces, diffuse-normal materials, and one/two/four-layer
terrain. Native texture slots, layer masks, normal packing, authored colours,
far combine maps, fog, alpha and main/local light interfaces are retained.
Unknown generated shaders still use their original implementation. Native
bytecode and disassembly remain private and are excluded from releases.

The GPU regression renders every identified interface and verifies albedo,
individual terrain-layer selection, main shadow occlusion, local independence
from an unbound shadow image, alpha and finite zero-light output. The expanded
material replacement still needs in-game activation and visual verification.
This is not a complete replacement of the lighting engine: native shadow-map
generation, reflection infrastructure and unsupported material families remain.
Local volumetric occlusion is screen-space and cannot shadow off-screen objects.

## 0.11.6 material-response correction

User reported a plastic covering over most surfaces in 0.11.5. Two errors
were found in the original replacement (not evidence of native asset quality):
legacy specular masks were promoted into high dielectric reflectance, and
Blinn exponent was mapped to perceptual roughness with a square root, then
squared again by the GGX evaluation. Exponent conversion now uses the fourth
root, so GGX alpha=sqrt(2/(power+2)). Nonmetal F0 remains 0.04 and authored
specular maps/amounts gate its intensity. Explicit native metalness remains
separate; glass retains its own opacity and reflection controls.

Generated GlossMap values now feed the captured native gloss exponent scale,
not an invented 1-gloss roughness map. Generated materials keep their original
per-layer specular amounts and powers. No classification is inferred from
texture colour, and no universal metallic/plastic response is substituted.

Coverage extends from 26 to 32 captured generated identities with two-layer
surface blending and main/local environment-material variants. Reflection
mapping uses the verified tangent frame and dual-paraboloid coordinates;
local variants do not require the main-pass reflection or shadow resources.
Six captured terrain-overlay interfaces remain native pending verification.

Real-GPU tests exercise black/white specular masks, bounded peak response
across authored gloss exponents, independent layer texture endpoints, explicit
metal controls and retained environment reflections. In-game appearance and
performance remain unverified. Stable public 0.10.105 remains untouched.

## 0.11.7 stereo-light source ownership

User confirmed the 0.11.6 material appearance improved, then reported right-eye
flicker. A private 12-second read-only poll of 1,146 eye epochs saw only three
completed draws for odd epochs versus 78 for even epochs. Polling can miss a
short callback, so this is evidence of an asymmetry to investigate, not a
complete per-eye delivery count or proof of the sole visible flicker source.

The source collector previously reset every pair and depended on native colour
uploads that can be cached. It also accepted their per-draw scale as source
radiance. Native RVA C27E0 directly multiplies +CC/+D0/+D4 by its scale argument;
that scale is now removed for collection (the native draw output is unchanged).
The authoritative selected directional light is seeded each pair from its
verified scene-root link and raw colour, with the current night-main multiplier.

Light selection/radiance is frozen for both eyes of one collector frame;
cameras, depth, cascade matrices and shadow snapshots remain per-eye. Detailed
attempt/draw/empty-source counts are recorded by eye in opt-in diagnostics.
A real GPU regression changes the source between left/right calls and verifies
identical pair selection, then confirms a new pair adopts the changed light.
This candidate preserves the accepted material response and makes no claim of
complete local shadow maps, indirect bounce or confirmed flicker resolution.

## Offline backend milestone (not installed)

Local spot/point shadow rendering, SH irradiance probes with distance moments,
HDR environment prefiltering and BRDF integration, physical single-scattering
sky, stereo histogram exposure, and the bounded asynchronous coordinator now
have real-GPU tests. See LIGHTING-ROADMAP.md for the precise native integration
work that remains. They are not enabled merely by adding their source files.
Generated material coverage now includes all 38 identities in the captured
scene, including six terrain-overlay variants with their native CB7 tint,
edge masks, normal rotation and three layer-order modes. This is not a claim
of complete material coverage across the game.

The development milestone also contains a complete owned cube HDR/distance
capture backend and a stereo-union, texel-snapped cascade planner. The former
feeds the tested probe/reflection backends; the latter has not replaced native
culling or caster submission. The original material correction remains intact.
The native HDR meter bridge is bounded opt-in diagnostics only, with deferred
stream/state/counter tests; no new exposure is applied. See the ledger before
claiming native activation or final lighting quality.

### Private 0.13.3 offline batch

The combined candidate adds the deferred lighting handoff, local terrain parallax
relief and position-corrected local cubemap reflections. It is not installed or
visually verified. Relief leaves ground collision and silhouettes unchanged.
Generate height data locally with MAKE-TERRAIN-HEIGHTS.py; its output must never
be redistributed. The runtime reads RFGRVR/terrain-heights.rfgh at startup;
without that optional local bundle terrain remains native. No game assets are
included in the source or installer. Missing terrain names fall back safely.

### Private 0.13.5

Adds an expected-projection guard for atmospheric passes, texture-derived
reflectivity/roughness, common Fresnel/finite-range light response and conservative
view-priority scheduling. Local authoring: MAKE-MATERIAL-LIGHTMAPS.py GAME OUTPUT;
place the resulting material-reflectivity.rfgo in GAME/RFGRVR only for private use.
Never redistribute derived maps. Native activation and appearance remain unverified.
Secondary transport is a backend awaiting verified surface-hit/occlusion integration;
no photon emitter or complete modern renderer is claimed.

## Reflection-cache optimization candidate (not installed)

The 0.13.5 headset report confirms no visible sky flicker, but little visual improvement and possible slowdown. Live pair timing samples show roughly 9.4–10.9 ms left-eye GPU and 5.7–6.4 ms right-eye GPU; these are whole-eye measurements, not isolated replacement-lighting costs or an off/on comparison.

Probe completion previously filtered and replaced the reflection cubemap for every grid cell. The candidate retains the nearest capture: an appreciably closer cell can replace it, while equivalent captures refresh after 600 graph frames. More distant grid cells still update diffuse irradiance without rebuilding reflections. Scene/device reset clears ownership through the existing graph reset. Policy tests cover stationary 27-cell filling, movement, age, and invalid distances; GPU graph/runtime regressions pass. No resolution, scattering steps, material response, camera, or shipping profile changes. In-game cost reduction and reflection appearance remain unverified. This is an optimization, not completion of the modern renderer or proof of improved visual quality.
