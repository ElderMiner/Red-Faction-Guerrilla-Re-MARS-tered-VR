#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <wrl/client.h>
#include <cstdio>
#include <cassert>
using Microsoft::WRL::ComPtr;
int main(){ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c,deferred;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));assert(SUCCEEDED(d->CreateDeferredContext(0,&deferred)));D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=64;td.MipLevels=td.ArraySize=1;td.Format=DXGI_FORMAT_R8G8B8A8_UNORM;td.SampleDesc.Count=1;td.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> t;ComPtr<ID3D11RenderTargetView> v,queried;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&t)));assert(SUCCEEDED(d->CreateRenderTargetView(t.Get(),nullptr,&v)));ID3D11RenderTargetView* raw=v.Get();deferred->OMSetRenderTargets(1,&raw,nullptr);deferred->OMGetRenderTargets(1,&queried,nullptr);printf("deferred getter returns bound target=%d\n",queried.Get()==v.Get());}
