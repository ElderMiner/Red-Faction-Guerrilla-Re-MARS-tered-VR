#include <cstring>
#include <cassert>
#include "../src/vr_hud_heading.h"
static void* __fastcall copy(void* dst,void*,const void* src){memcpy(dst,src,36);return dst;}
int main(){using namespace RFGRVRHudHeading;nativeCopy=(Copy)(void*)copy;float native[9]={0,1,2,3,4,5,6,7,8},a[9],b[9];publish(1.57079632679f);mapBasis(a,nullptr,native);for(auto& x:native)x=-10;mapBasis(b,nullptr,native);assert(!memcmp(a,b,36));assert(fabsf(a[6]-1)<.0001f&&fabsf(a[2]+1)<.0001f&&a[4]==1);tick.store(GetTickCount64()-251);mapBasis(b,nullptr,native);assert(!memcmp(b,native,36));tick.store(0);mapBasis(a,nullptr,native);assert(!memcmp(a,native,36));}
