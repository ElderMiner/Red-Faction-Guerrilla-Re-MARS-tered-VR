#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <cstdio>
#include "gpu_protocol.h"
using Microsoft::WRL::ComPtr;
inline HRESULT makeDevice(ComPtr<ID3D11Device>& dev, ComPtr<ID3D11DeviceContext>& ctx) {
    D3D_FEATURE_LEVEL fl;
    return D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,
       D3D11_CREATE_DEVICE_BGRA_SUPPORT,nullptr,0,D3D11_SDK_VERSION,&dev,&fl,&ctx);
}
inline void msg(const char* text,HRESULT hr=0) { std::printf("%s hr=0x%08lX\n",text,(unsigned long)hr); }
