#pragma once
#include "vr_arm_math.h"
struct RFGRVRForwardLean {float angle=0;float update(float forward,float dt,bool allowed){if(!std::isfinite(dt)||dt<0)return angle;if(dt>.05f)dt=.05f;float target=allowed&&std::isfinite(forward)?(std::max)(0.f,(std::min)(1.f,forward))*.174532925f:0;angle+=(target-angle)*(1-expf(-dt*10));return angle;}};
inline vrarm::Pose RFGRVR_LeanPose(vrarm::Pose p,vrarm::V pivot,float angle,vrarm::V right={1,0,0}){p.p=vrarm::add(pivot,vrarm::turnAround(vrarm::sub(p.p,pivot),right,angle));p.b=vrarm::turnAround(p.b,right,angle);return p;}

