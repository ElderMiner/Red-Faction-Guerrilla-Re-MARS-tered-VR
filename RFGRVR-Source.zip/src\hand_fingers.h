#pragma once
#include "vr_mapping.h"
#include <windows.h>
#include <cmath>
#include <cstring>
#ifdef RFGR_FINGERS_TEST
static constexpr wchar_t RFGR_HAND_FINGERS[]=L"Local\\RFGRVR_HandFingers_TEST_v1";
#else
static constexpr wchar_t RFGR_HAND_FINGERS[]=L"Local\\RFGRVR_HandFingers_v1";
#endif
struct RFGRHandFingers{unsigned magic=0x46494e31;volatile LONG sequence=0;DWORD tick=0;unsigned valid=0;float curl[2][5]{};};
inline void RFGRVR_PublishFingers(RFGRHandFingers value){static HANDLE map=nullptr;static RFGRHandFingers* view=nullptr;if(!view){if(!map)map=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(value),RFGR_HAND_FINGERS);if(map)view=(RFGRHandFingers*)RFGRVR_MapViewOrClose(map,FILE_MAP_ALL_ACCESS,0,0,sizeof(value));}if(!view)return;value.tick=GetTickCount();InterlockedIncrement(&view->sequence);MemoryBarrier();view->magic=value.magic;memcpy(&view->tick,&value.tick,sizeof(value)-offsetof(RFGRHandFingers,tick));MemoryBarrier();InterlockedIncrement(&view->sequence);}
struct RFGRFingerReader{HANDLE map=nullptr;RFGRHandFingers* view=nullptr;bool read(RFGRHandFingers& out){if(!view){if(!map)map=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_HAND_FINGERS);if(map)view=(RFGRHandFingers*)RFGRVR_MapViewOrClose(map,FILE_MAP_READ,0,0,sizeof(out));}if(!view)return false;for(unsigned n=0;n<3;++n){LONG s=view->sequence;if(s&1)continue;MemoryBarrier();memcpy(&out,view,sizeof(out));MemoryBarrier();if(s==view->sequence)return out.magic==0x46494e31&&DWORD(GetTickCount()-out.tick)<200;}return false;}};
