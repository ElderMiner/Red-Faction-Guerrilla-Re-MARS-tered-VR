#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <atomic>
#include <mutex>
#include "../third_party/nvapi/nvapi.h"
#include "vr_foveation_state.h"
#include "vr_foveation_math.h"
namespace vrfoveation {
struct Driver {
 HMODULE library=nullptr;decltype(&NvAPI_Initialize) initialize=nullptr;decltype(&NvAPI_D3D1x_GetGraphicsCapabilities) caps=nullptr;
 decltype(&NvAPI_D3D11_CreateShadingRateResourceView) create=nullptr;decltype(&NvAPI_D3D11_RSSetShadingRateResourceView) bind=nullptr;decltype(&NvAPI_D3D11_RSSetViewportsPixelShadingRates) rates=nullptr;bool ready=false;
 bool load(){if(library)return ready;
#ifdef _WIN64
 library=LoadLibraryExW(L"nvapi64.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
#else
 library=LoadLibraryExW(L"nvapi.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
#endif
 if(!library)return false;auto query=(void*(__cdecl*)(unsigned))GetProcAddress(library,"nvapi_QueryInterface");if(!query)return false;
 initialize=(decltype(initialize))query(0x0150e828);caps=(decltype(caps))query(0x52b1499a);create=(decltype(create))query(0x99ca2dff);bind=(decltype(bind))query(0x1b0c2f83);rates=(decltype(rates))query(0x34f7938f);
 ready=initialize&&caps&&create&&bind&&rates&&initialize()==NVAPI_OK;return ready;}
};
inline Driver driver;
template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
inline Ptr<ID3D11Device> owner;inline Ptr<ID3D11Texture2D> textures[2];inline Ptr<ID3D11NvShadingRateResourceView> views[2];inline unsigned textureWidth=0,textureHeight=0;
inline std::atomic<bool> frameActive{false};inline std::atomic<unsigned> generation{0};inline unsigned eyeIndex=0;inline bool supported=false;inline std::atomic<bool> failed{false};inline std::vector<unsigned char> tiles[2];
struct Context {ID3D11DeviceContext* pointer=nullptr;void** table=nullptr;bool enabled=false;unsigned generation=0;};
inline Context contexts[128]{};inline std::mutex contextsLock;
inline Context* context(ID3D11DeviceContext* c){thread_local Context* cached=nullptr;auto table=*(void***)c;if(cached&&cached->pointer==c&&cached->table==table)return cached;std::lock_guard<std::mutex> held(contextsLock);for(auto& s:contexts)if(s.pointer==c&&s.table==table)return cached=&s;for(auto& s:contexts)if(!s.pointer){s.pointer=c;s.table=table;return cached=&s;}return nullptr;}
inline void failure(int code){failed=true;frameActive=false;if(auto* p=bus()){p->active=0;p->error=code;}}
inline bool initialize(ID3D11Device* device){if(!device)return false;if(owner.Get()==device)return supported&&!failed;owner=device;for(auto& v:views)v.Reset();for(auto& t:textures)t.Reset();textureWidth=textureHeight=0;failed=false;supported=false;
 if(driver.load()){NV_D3D1x_GRAPHICS_CAPS caps{};supported=driver.caps(device,NV_D3D1x_GRAPHICS_CAPS_VER,&caps)==NVAPI_OK&&caps.bVariablePixelRateShadingSupported;}
 if(auto* p=bus()){p->gamePid=GetCurrentProcessId();p->supported=supported?1:0;p->active=0;p->error=0;}return supported;}
inline bool disable(ID3D11DeviceContext* c,bool force=false){if(!c||!driver.ready)return false;auto* state=context(c);if(!force&&(!state||!state->enabled))return true;NV_D3D11_VIEWPORTS_SHADING_RATE_DESC desc{};desc.version=NV_D3D11_VIEWPORTS_SHADING_RATE_DESC_VER;auto a=driver.rates(c,&desc);auto b=driver.bind(c,nullptr);if(state){state->enabled=false;state->generation=0;}if(a!=NVAPI_OK||b!=NVAPI_OK){failure(a!=NVAPI_OK?a:b);return false;}return true;}
inline void end(ID3D11DeviceContext* immediate=nullptr){frameActive=false;if(auto* p=bus())p->active=0;if(immediate)disable(immediate);}
inline bool begin(ID3D11Device* device,ID3D11DeviceContext* immediate,unsigned eye,unsigned width,unsigned height,const float projection[4],vrarm::V gaze,bool enabled){
 end(immediate);if(!initialize(device)||!enabled||eye>1)return false;
 unsigned w=(width+15)/16,h=(height+15)/16;if(!pattern(width,height,projection,gaze,tiles[eye]))return false;
 if(textureWidth!=w||textureHeight!=h){for(auto& v:views)v.Reset();for(auto& t:textures)t.Reset();textureWidth=w;textureHeight=h;}
 if(!textures[eye]){D3D11_TEXTURE2D_DESC d{};d.Width=w;d.Height=h;d.MipLevels=d.ArraySize=d.SampleDesc.Count=1;d.Format=DXGI_FORMAT_R8_UINT;d.Usage=D3D11_USAGE_DEFAULT;d.BindFlags=D3D11_BIND_SHADER_RESOURCE;
 if(FAILED(device->CreateTexture2D(&d,nullptr,&textures[eye]))){failure(-1001);return false;}NV_D3D11_SHADING_RATE_RESOURCE_VIEW_DESC view{};view.version=NV_D3D11_SHADING_RATE_RESOURCE_VIEW_DESC_VER;view.Format=d.Format;view.ViewDimension=NV_SRRV_DIMENSION_TEXTURE2D;auto result=driver.create(device,textures[eye].Get(),&view,&views[eye]);if(result!=NVAPI_OK){failure(result);return false;}}
 immediate->UpdateSubresource(textures[eye].Get(),0,nullptr,tiles[eye].data(),w,0);eyeIndex=eye;++generation;frameActive=true;if(auto* p=bus())p->active=1;return true;
}
inline void draw(ID3D11DeviceContext* c,bool eligible){
 // Zero driver calls and no locks when the option is off and context is clean.
 if(!driver.ready||!frameActive.load(std::memory_order_acquire))return;bool enable=eligible;auto* state=context(c);if(!state){failure(-1002);return;}
 if(!enable){if(state->enabled)disable(c);return;}if(state->enabled&&state->generation==generation.load())return;
 if(driver.bind(c,views[eyeIndex].Get())!=NVAPI_OK){disable(c,true);failure(-1003);return;}
 NV_D3D11_VIEWPORT_SHADING_RATE_DESC viewport{};viewport.enableVariablePixelShadingRate=true;for(auto& rate:viewport.shadingRateTable)rate=NV_PIXEL_X1_PER_RASTER_PIXEL;viewport.shadingRateTable[1]=NV_PIXEL_X1_PER_1X2_RASTER_PIXELS;viewport.shadingRateTable[2]=NV_PIXEL_X1_PER_2X2_RASTER_PIXELS;
 NV_D3D11_VIEWPORTS_SHADING_RATE_DESC desc{NV_D3D11_VIEWPORTS_SHADING_RATE_DESC_VER,1,&viewport};auto result=driver.rates(c,&desc);if(result!=NVAPI_OK){disable(c,true);failure(result);return;}state->enabled=true;state->generation=generation.load();if(auto* p=bus()){InterlockedIncrement(&p->changes);InterlockedIncrement(&p->draws);}
}
}
