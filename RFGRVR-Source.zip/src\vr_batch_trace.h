#pragma once
#include <atomic>
#include <mutex>
#include <cstdio>
namespace RFGRVRBatchTrace {
inline std::atomic<int> eye{-1};
inline unsigned rows=0;
inline std::mutex mutex;
inline bool readable(void* p,size_t n){MEMORY_BASIC_INFORMATION m{};return p&&VirtualQuery(p,&m,sizeof(m))&&m.State==MEM_COMMIT&&!(m.Protect&(PAGE_NOACCESS|PAGE_GUARD))&&(uintptr_t)p>=(uintptr_t)m.BaseAddress&&n<=m.RegionSize&&((uintptr_t)p-(uintptr_t)m.BaseAddress)<=m.RegionSize-n;}
inline unsigned word(void* p,unsigned off){unsigned v=0;if(readable((char*)p+off,4))memcpy(&v,(char*)p+off,4);return v;}
inline void record(const char* phase,void* object,void* renderer,unsigned mask,unsigned flags){
 int current=eye.load();if(current<0)return;
 std::lock_guard<std::mutex> lock(mutex);if(rows++>=2048)return;
 char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,92);if(!slash)return;
 sprintf_s(slash+1,MAX_PATH-(slash+1-path),"vr-research\\output\\BatchTrace-%lu.csv",GetCurrentProcessId());
 FILE* f=nullptr;if(fopen_s(&f,path,"a")||!f)return;
 if(!_ftelli64(f))fputs("phase,eye,object,renderer,mask,flags,vtable,count8,count14,ptr18,count24,count30,visible90,lod128,lod14c,lod150,stamp154,frame\n",f);
 auto* base=(char*)GetModuleHandleW(nullptr);auto* frame=(void*)(uintptr_t)word(base,0x1637910);
 fprintf(f,"%s,%d,%p,%p,%08X,%08X,%08X,%u,%u,%08X,%u,%u,%08X,%u,%u,%u,%u,%u\n",phase,current,object,renderer,mask,flags,word(object,0),word(object,8),word(object,0x14),word(object,0x18),word(object,0x24),word(object,0x30),word(object,0x90),word(object,0x128),word(object,0x14c),word(object,0x150),word(object,0x154),word(frame,0x6dc));fclose(f);
}
using Batch=void(__thiscall*)(void*,void*,unsigned,unsigned);
using List=void(__thiscall*)(void*,void*,void*,unsigned,unsigned);
inline Batch batch=nullptr;inline List list=nullptr;
inline void __fastcall onBatch(void* self,void*,void* renderer,unsigned mask,unsigned flags){
 record("batch-before",self,renderer,mask,flags);batch(self,renderer,mask,flags);record("batch-after",self,renderer,mask,flags);
}
inline void __fastcall onList(void* self,void*,void* renderer,void* other,unsigned mask,unsigned flags){
 record("list-before",self,renderer,mask,flags);list(self,renderer,other,mask,flags);record("list-after",self,renderer,mask,flags);
}
}
