#define RFGR_TEST_FRAMEPACER
#include "../src/vr_frame_clock.h"
#include <thread>
#include <cassert>
int main(){vrframeclock::Publisher publisher;vrframeclock::Reader reader;publisher.publish(1000000000,50000000,true);assert(reader.pace()&&reader.period==50000000&&reader.frames==1);std::thread next([&]{Sleep(3);publisher.publish(1050000000,50000000,true);});assert(reader.pace()&&reader.frames==2&&reader.waits>0);next.join();assert(!reader.pace()&&reader.timeouts>0);publisher.publish(1020000000,11111111,true);assert(reader.pace()&&reader.period==11111111);publisher.publish(1030000000,11111111,false);assert(!reader.pace());publisher.publish(1040000000,0,true);assert(!reader.pace());publisher.publish(1050000000,6944444,true);assert(reader.pace());}
