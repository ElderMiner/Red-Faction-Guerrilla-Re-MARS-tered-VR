#pragma once
#include "vr_user_settings.h"
#include "../vendor/MinHook.h"
#include <intrin.h>
#include <cstring>
extern "C" bool RFGRVR_HeadCam_PauseMenu();
namespace RFGRVRPauseSettings {
using Add=int(__cdecl*)(unsigned,const char*,void(__cdecl*)(),unsigned,unsigned,unsigned);
inline unsigned char* base=nullptr;inline Add original=nullptr;inline unsigned additions=0;
inline void __cdecl open(){if(RFGRVR_HeadCam_PauseMenu())if(auto* b=vrsettings::bus()){InterlockedExchange(&b->nativeSettings,0);InterlockedExchange(&b->openRequest,1);}}
using Create=unsigned(__cdecl*)(unsigned);inline Create create=nullptr;
inline void append(unsigned handle){if(!base||!original||handle==~0u)return;if(original(handle,"VR SETTINGS",&open,1,0,0)>=0)++additions;}
inline unsigned __cdecl onCreate(unsigned parent){unsigned result=create(parent);unsigned handle=~0u;memcpy(&handle,base+0x1264108,4);append(handle);return result;}
inline bool install(unsigned char* b){unsigned target=0;memcpy(&target,b+0x517ee1,4);if(b[0x517e90]!=0x51||b[0x517e91]!=0x83||b[0x517e92]!=0x3d||b[0x4b8ff0]!=0x53||b[0x4b8ff1]!=0x8b||b[0x4b8ff2]!=0x1d||b[0x517ee0]!=0xe8||(unsigned)(uintptr_t)(b+0x517ee5)+target!=(unsigned)(uintptr_t)(b+0x4b8ff0))return false;
 if(MH_CreateHook(b+0x517e90,(void*)onCreate,(void**)&create)!=MH_OK)return false;original=(Add)(b+0x4b8ff0);base=b;if(MH_EnableHook(b+0x517e90)!=MH_OK){MH_RemoveHook(b+0x517e90);base=nullptr;return false;}return true;}
}
