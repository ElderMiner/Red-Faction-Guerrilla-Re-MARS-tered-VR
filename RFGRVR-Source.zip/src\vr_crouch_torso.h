#pragma once
#include "vr_neutral_pose.h"
#include <algorithm>
inline vrarm::Pose RFGRVR_StableCrouchTorso(const vrarm::Pose& rest,const vrarm::Pose& root,float pelvisY,float headY,float drop,vrarm::M facing){
 auto result=RFGRVR_NeutralBone(rest,root,1,facing);float span=headY-pelvisY;float t=span>.1f?(rest.p.y-pelvisY)/span:1.f;t=(std::clamp)(t,0.f,1.f);result.p.y+=drop*(.65f+.35f*t);return result;
}
