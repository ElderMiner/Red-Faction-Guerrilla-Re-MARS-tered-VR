#pragma once
#include "vr_arm_math.h"
inline vrarm::Pose RFGRVR_RagdollEye(const vrarm::Pose& head,vrarm::V localXrEye,float scale){
 return {head.b,vrarm::add(head.p,vrarm::world(head.b,{localXrEye.x*scale,localXrEye.y*scale,-localXrEye.z*scale}))};
}
