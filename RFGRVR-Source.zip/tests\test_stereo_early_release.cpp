#define main RFGRVR_BridgeEntryForTest
#include "../src/bridge.cpp"
#undef main
#include <cassert>
using Microsoft::WRL::ComPtr;
// The head-update signal has a 350ms grace followed by a 1500ms debounce.
// A menu can therefore arrive AFTER gameplay image freshness expires.
static void menuTransitionCache(){RFGRVRSceneTransition t;
 assert(!t.update(1,false,false,true,100));assert(t.update(1,true,false,false,200));
 assert(t.update(1,false,false,false,300));assert(t.update(1,false,false,false,1800));
 assert(!t.update(1,false,false,false,2301));assert(!t.update(1,false,false,true,2400));
 assert(t.update(1,true,false,false,2500));assert(!t.update(1,false,true,false,2600));
 assert(!t.update(2,false,false,false,2700));assert(!t.update(0,false,false,false,2800));
bool cached=true;assert(RFGRVR_SubmitCachedScene(cached,false,2499,1000));assert(!RFGRVR_SubmitCachedScene(cached,false,2501,1000));assert(cached);assert(RFGRVR_SubmitCachedScene(cached,true,2850,1000));assert(RFGRVR_SubmitCachedScene(cached,true,100000,1000));assert(!RFGRVR_SubmitCachedScene(false,true,2850,1000));}
int main(int argc,char**){menuTransitionCache();wchar_t modePath[MAX_PATH]{};if(argc>1){GetModuleFileNameW(nullptr,modePath,MAX_PATH);auto* slash=wcsrchr(modePath,92);wcscpy_s(slash+1,MAX_PATH-(slash+1-modePath),L"RFGRVR-upscaler.txt");assert(GetFileAttributesW(modePath)==INVALID_FILE_ATTRIBUTES);FILE* f=nullptr;_wfopen_s(&f,modePath,L"w");assert(f);fputs("1 .8\n",f);fclose(f);}ComPtr<ID3D11Device>producer,consumer;ComPtr<ID3D11DeviceContext>pc,cc;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&producer,nullptr,&pc)));assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&consumer,nullptr,&cc)));
 ComPtr<ID3D11Texture2D>shared[2],output[2];ComPtr<IDXGIKeyedMutex>pm[2];StereoGpuConsumer bridge;assert(bridge.acknowledgement(0)==-1&&bridge.acknowledgement(1)==-1);RFGRStereoGpuShared packet{};packet.ready=1;packet.renderMode=3;bridge.state=&packet;assert(bridge.acknowledgement(0)==0);
 D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=16;desc.MipLevels=desc.ArraySize=desc.SampleDesc.Count=1;desc.Format=DXGI_FORMAT_B8G8R8A8_UNORM;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;desc.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
 for(unsigned eye=0;eye<2;++eye){assert(SUCCEEDED(producer->CreateTexture2D(&desc,nullptr,&shared[eye])));shared[eye].As(&pm[eye]);ComPtr<IDXGIResource>resource;shared[eye].As(&resource);HANDLE handle{};assert(SUCCEEDED(resource->GetSharedHandle(&handle)));assert(SUCCEEDED(consumer->OpenSharedResource(handle,IID_PPV_ARGS(&bridge.texture[eye]))));bridge.texture[eye].As(&bridge.mutex[eye]);auto outDesc=desc;outDesc.Width=outDesc.Height=32;outDesc.MiscFlags=0;outDesc.BindFlags=D3D11_BIND_RENDER_TARGET;assert(SUCCEEDED(consumer->CreateTexture2D(&outDesc,nullptr,&output[eye])));}
 auto publish=[&](unsigned left,unsigned right,unsigned frame){unsigned colors[2]={left,right};for(unsigned i=0;i<2;++i){assert(pm[i]->AcquireSync(0,1000)==S_OK);unsigned data[256];for(auto& p:data)p=colors[i];pc->UpdateSubresource(shared[i].Get(),0,nullptr,data,64,0);packet.eyeFrames[i]=frame;packet.eyePosition[i][0]=float(frame*10+i);packet.eyeOrientation[i][3]=1;packet.eyeFov[i][0]=-.5f;packet.eyeFov[i][1]=packet.eyeFov[i][2]=.5f;packet.eyeFov[i][3]=-.5f;packet.sourceProjection[i][0]=packet.sourceProjection[i][1]=1;}packet.sceneFrame=frame;pc->Flush();for(auto& m:pm)assert(SUCCEEDED(m->ReleaseSync(1)));};
 auto check=[&](unsigned eye,unsigned color){D3D11_TEXTURE2D_DESC t{};output[eye]->GetDesc(&t);t.BindFlags=0;t.Usage=D3D11_USAGE_STAGING;t.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D>read;consumer->CreateTexture2D(&t,nullptr,&read);cc->CopyResource(read.Get(),output[eye].Get());D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(cc->Map(read.Get(),0,D3D11_MAP_READ,0,&map)));for(unsigned y=0;y<32;++y)for(unsigned x=0;x<32;++x)assert(*(unsigned*)((char*)map.pData+y*map.RowPitch+x*4)==color);cc->Unmap(read.Get(),0);};
 XrView eyes[2]{};ID3D11Texture2D* dst[2]={output[0].Get(),output[1].Get()};publish(0xff0000ff,0xff00ff00,1);assert(bridge.stagePair(cc.Get(),eyes));assert(packet.eyeAcknowledged[0]==1&&packet.eyeAcknowledged[1]==1);auto* cached=bridge.staged.image[0].Get();
 // The producer reuses BOTH shared buffers before any upscale is rendered.
 // The staged image, pose, projection and consumed frame IDs must stay at1.
 publish(0xffff0000,0xff00ffff,2);packet.sourceProjection[0][0]=.75f;assert(bridge.renderStaged(cc.Get(),dst,90));check(0,0xff0000ff);check(1,0xff00ff00);assert(bridge.sceneFrame==1&&bridge.consumedFrames[0]==1&&bridge.consumedFrames[1]==1&&bridge.renderedViews[0].pose.position.x==10&&bridge.staged.projection[0][0]==1);
 assert(bridge.copyPair(cc.Get(),dst,eyes,90));check(0,0xffff0000);check(1,0xff00ffff);assert(bridge.sceneFrame==2&&bridge.consumedFrames[0]==2&&bridge.staged.image[0].Get()==cached);
 // A partial acquisition must retain key1 for the untouched complete pair.
 publish(0xffffffff,0xff000000,3);assert(bridge.mutex[1]->AcquireSync(1,1000)==S_OK);bridge.mutex[1]->ReleaseSync(7);auto ack=packet.eyeAcknowledged[0];assert(!bridge.stagePair(cc.Get(),eyes));assert(packet.eyeAcknowledged[0]==ack);assert(pm[0]->AcquireSync(1,1000)==S_OK);pm[0]->ReleaseSync(1);assert(pm[1]->AcquireSync(7,1000)==S_OK);pm[1]->ReleaseSync(1);assert(bridge.copyPair(cc.Get(),dst,eyes,90));check(0,0xffffffff);check(1,0xff000000);
 // A recreated producer may restart at frame 1, including after a failed initial attach.
 packet.ownerPid=GetCurrentProcessId();packet.generation=2;packet.eyeAcknowledged[0]=packet.eyeAcknowledged[1]=0;packet.width=packet.height=16;packet.format=desc.Format;
 packet.eyeHandle[0]=packet.eyeHandle[1]=0;assert(!bridge.attachTextures(consumer.Get()));
 for(unsigned eye=0;eye<2;++eye){ComPtr<IDXGIResource> resource;shared[eye].As(&resource);HANDLE h{};assert(SUCCEEDED(resource->GetSharedHandle(&h)));packet.eyeHandle[eye]=(uint64_t)(uintptr_t)h;}
 assert(bridge.attachTextures(consumer.Get())&&bridge.epochChanged&&!bridge.staged.valid&&bridge.consumedFrames[0]==0);
 publish(0xff112233,0xff445566,1);assert(bridge.copyPair(cc.Get(),dst,eyes,90));check(0,0xff112233);check(1,0xff445566);
 assert(packet.eyeAcknowledged[0]==1&&bridge.consumedFrames[0]==1);assert(bridge.attachTextures(consumer.Get())&&!bridge.epochChanged);
 if(argc>1)assert(bridge.scale.fsr.applied>=6);assert(SUCCEEDED(producer->GetDeviceRemovedReason())&&SUCCEEDED(consumer->GetDeviceRemovedReason()));bridge.state=nullptr;bridge.close();assert(bridge.acknowledgement(0)==-1&&bridge.acknowledgement(1)==-1);check(0,0xff112233);check(1,0xff445566);assert(!bridge.staged.image[0]&&!bridge.staged.image[1]);for(auto& entry:bridge.scale.cached)assert(!entry.source&&!entry.target);for(auto& entry:bridge.scale.fsr.cache)assert(!entry.source&&!entry.target&&!entry.middle);if(argc>1)DeleteFileW(modePath);puts("PASS: cross-device early release, immutable eye images/poses/frame IDs, partial acquisition rollback and resize-cache cleanup");}



