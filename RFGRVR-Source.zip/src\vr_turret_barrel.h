#pragma once
#include "vr_arm_math.h"
inline bool RFGRVR_TurretBarrel(const vrarm::M& root,const vrarm::M& reference,const vrarm::M& gun,float* yaw,float* pitch){
 if(!yaw||!pitch||!vrarm::valid(root)||!vrarm::valid(reference)||!vrarm::valid(gun))return false;
 vrarm::M barrel=vrarm::compose(root,vrarm::relative(reference,gun));
 *yaw=atan2f(barrel.f.x,barrel.f.z);float y=barrel.f.y;if(y>1)y=1;if(y< -1)y=-1;*pitch=asinf(y);return std::isfinite(*yaw)&&std::isfinite(*pitch);
}
