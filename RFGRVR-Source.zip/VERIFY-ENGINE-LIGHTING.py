"""Read-only verification of the supported game's native lighting interfaces.

Uses only Python's standard library. Does not extract shaders, patch the game,
or call native functions. Addresses below are RVAs, never runtime addresses.
"""
import argparse
import json
import struct
from pathlib import Path


class Image:
    def __init__(self, path):
        self.data = Path(path).read_bytes()
        assert self.data[:2] == b'MZ', 'Not a PE image'
        pe = self.u32(0x3c)
        assert self.data[pe:pe + 4] == b'PE\0\0', 'Invalid PE signature'
        machine, count = struct.unpack_from('<HH', self.data, pe + 4)
        optional_size = struct.unpack_from('<H', self.data, pe + 20)[0]
        optional = pe + 24
        assert machine == 0x14c and self.u16(optional) == 0x10b, 'Expected x86 PE32'
        self.base = self.u32(optional + 28)
        self.sections = []
        for index in range(count):
            at = optional + optional_size + index * 40
            virtual_size, rva, size, offset = struct.unpack_from('<4I', self.data, at + 8)
            self.sections.append((rva, virtual_size, offset, size))

    def u16(self, at):
        return struct.unpack_from('<H', self.data, at)[0]

    def u32(self, at):
        return struct.unpack_from('<I', self.data, at)[0]

    def read(self, rva, size):
        for start, virtual_size, offset, raw_size in self.sections:
            if start <= rva and rva + size <= start + min(virtual_size, raw_size):
                at = offset + rva - start
                return self.data[at:at + size]
        raise ValueError(f'RVA {rva:#x} is not backed by file data')

    def pointer(self, rva):
        return struct.unpack('<I', self.read(rva, 4))[0] - self.base

    def class_name(self, table):
        locator = self.pointer(table - 4)
        signature, offset, constructor_offset = struct.unpack('<3I', self.read(locator, 12))
        assert signature == 0 and offset == 0 and constructor_offset == 0, 'Unexpected RTTI layout'
        descriptor = self.pointer(locator + 12)
        return self.read(descriptor + 8, 96).split(b'\0')[0].decode('ascii')


def verify(path):
    image = Image(path)
    definitions = [
        (0xec05a8, '.?AVrl_scene_renderer@@', {0: 0x144750, 4: 0xc7510, 8: 0x162eb0, 12: 0x161d20}),
        (0xec1414, '.?AVrl_camera@@', {0: 0x148eb0, 4: 0xba9e0, 8: 0xf5da0, 12: 0xf5db0}),
        (0xec14fc, '.?AVrl_light@@', {0: 0x14bc40, 4: 0x13e910, 8: 0xf5da0, 12: 0xf5db0}),
        (0xec0774, '.?AVrl_terrain_renderer@@', {20: 0x134360}),
        (0xebeefc, '.?AVrl_batched_pass@@', {0: 0xdf860, 4: 0x109be0, 8: 0x155790,
                                         12: 0x155800, 16: 0x136e20, 20: 0x120af0}),
    ]
    interfaces = []
    for table, name, slots in definitions:
        assert image.class_name(table) == name, f'Wrong class at {table:#x}'
        for slot, function in slots.items():
            assert image.pointer(table + slot) == function, f'Wrong method at {table:#x}+{slot:#x}'
        interfaces.append({'class': name, 'vtableRva': hex(table),
                           'methods': {hex(slot): hex(function) for slot, function in slots.items()}})
    # Exact stack-pop contracts at verified function boundaries, not a search
    # for a coincidental RET byte in an arbitrary function window.
    for rva, expected in [(0x137346, b'\xc2\x10\x00'), (0x120c60, b'\xc2\x04\x00')]:
        assert image.read(rva, len(expected)) == expected, f'Calling convention changed at {rva:#x}'
    return {'verified': True, 'interfaces': interfaces,
            'note': 'Identity and ABI verification only; world visibility and native invocation remain separate.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executable', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.executable), indent=2))
