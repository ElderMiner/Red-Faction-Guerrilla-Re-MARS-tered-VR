#pragma once
#include <cstring>
#include <algorithm>
#include <vector>
#include <cstdint>
#include "vr_arm_math.h"
namespace vrbody {
inline bool handBone(const char* name){return name&&(!strcmp(name,"l-hand")||!strcmp(name,"r-hand")||!strncmp(name,"l-finger",8)||!strncmp(name,"r-finger",8)||!strncmp(name,"l-thumb",7)||!strncmp(name,"r-thumb",7));}
struct HandRegion {
 struct Box{vrarm::V lo,hi;};std::vector<Box> components;
 vrarm::V joint[128]{};unsigned count=0;
 bool contains(vrarm::V p)const{if(!vrarm::finite(p))return false;for(const auto& b:components)if(p.x>=b.lo.x&&p.x<=b.hi.x&&p.y>=b.lo.y&&p.y<=b.hi.y&&p.z>=b.lo.z&&p.z<=b.hi.z)return true;for(unsigned i=0;i<count;++i){auto d=vrarm::sub(p,joint[i]);if(vrarm::dot(d,d)<=.055f*.055f)return true;}return false;}
};
// Keep complete connected glove sections and decorations inside their bounds.
// A component reaching the torso/whole arm is never promoted as a glove.
inline void completeGloves(const unsigned char* vertices,unsigned vertexBytes,unsigned stride,const unsigned char* indices,unsigned indexBytes,unsigned count,unsigned indexSize,bool strip,HandRegion& region,const unsigned* groupStarts=nullptr,unsigned groupCount=0){
 using namespace vrarm;if(!vertices||!indices||stride<12||(indexSize!=2&&indexSize!=4)||uint64_t(count)*indexSize>indexBytes||!region.count)return;unsigned nv=vertexBytes/stride;if(!nv||nv>262144)return;std::vector<unsigned> parents(nv);for(unsigned i=0;i<nv;++i)parents[i]=i;
 auto root=[&](unsigned n){while(parents[n]!=n){parents[n]=parents[parents[n]];n=parents[n];}return n;};auto get=[&](unsigned i){unsigned n=0;memcpy(&n,indices+size_t(i)*indexSize,indexSize);return n;};auto join=[&](unsigned a,unsigned b,unsigned c){if(a>=nv||b>=nv||c>=nv||a==b||a==c||b==c)return;parents[root(a)]=root(c);parents[root(b)]=root(c);};
 if(strip){unsigned a=0,b=0,run=0,cut=indexSize==2?65535u:~0u;std::vector<unsigned char> boundary(count);for(unsigned g=0;g<groupCount;++g)if(groupStarts&&groupStarts[g]<count)boundary[groupStarts[g]]=1;for(unsigned i=0;i<count;++i){if(boundary[i])run=0;unsigned n=get(i);if(n==cut||n>=nv){run=0;continue;}if(run>=2)join(a,b,n);a=b;b=n;++run;}}
 else for(unsigned i=0;i+2<count;i+=3)join(get(i),get(i+1),get(i+2));
 struct Bounds{V lo{},hi{};bool ready=false,seed=false;};std::vector<Bounds> bounds(nv);for(unsigned i=0;i<nv;++i){V p{};memcpy(&p,vertices+size_t(i)*stride,12);if(!finite(p))continue;auto& box=bounds[root(i)];if(!box.ready){box.lo=box.hi=p;box.ready=true;}else for(unsigned axis=0;axis<3;++axis){(&box.lo.x)[axis]=(std::min)((&box.lo.x)[axis],(&p.x)[axis]);(&box.hi.x)[axis]=(std::max)((&box.hi.x)[axis],(&p.x)[axis]);}box.seed=box.seed||region.contains(p);}
 for(const auto& b:bounds)if(b.ready&&b.seed&&region.components.size()<128){V extent=sub(b.hi,b.lo);if((std::max)({extent.x,extent.y,extent.z})>.45f||length(extent)>.6f)continue;V margin{.005f,.005f,.005f};region.components.push_back({sub(b.lo,margin),add(b.hi,margin)});}
}
// Remove whole triangles; never stretch vertices or alter skeleton transforms.
inline unsigned filter(const unsigned char* vertices,unsigned vertexBytes,unsigned stride,const unsigned char* indices,unsigned indexBytes,unsigned count,unsigned indexSize,const HandRegion& region,std::vector<unsigned char>& output){
 if(!vertices||!indices||stride<12||(indexSize!=2&&indexSize!=4)||uint64_t(count)*indexSize>indexBytes)return ~0u;
 output.assign(indices,indices+indexBytes);unsigned kept=0;
 auto index=[&](unsigned i){unsigned n=0;memcpy(&n,indices+size_t(i)*indexSize,indexSize);return n;};
 for(unsigned i=0;i+2<count;i+=3){bool keep=true;for(unsigned corner=0;corner<3;++corner){unsigned n=index(i+corner);if(uint64_t(n)*stride+12>vertexBytes){keep=false;break;}vrarm::V p{};memcpy(&p,vertices+size_t(n)*stride,12);keep=keep&&region.contains(p);}
  if(keep){++kept;continue;}memcpy(output.data()+size_t(i+1)*indexSize,output.data()+size_t(i)*indexSize,indexSize);memcpy(output.data()+size_t(i+2)*indexSize,output.data()+size_t(i)*indexSize,indexSize);
 }return kept;
}
// Preserve strip indices/material ranges. Cut out non-hand vertices; add a
// degenerate prefix when required to retain the original strip winding.
inline unsigned filterStrip(const unsigned char* vertices,unsigned vertexBytes,unsigned stride,const unsigned char* indices,unsigned indexBytes,unsigned count,unsigned indexSize,const HandRegion& region,std::vector<unsigned char>& output,const unsigned* groupStarts=nullptr,unsigned groupCount=0){
 if(!vertices||!indices||stride<12||(indexSize!=2&&indexSize!=4)||uint64_t(count)*indexSize>indexBytes)return ~0u;
 output.assign(indices,indices+indexBytes);unsigned cut=indexSize==2?65535u:~0u;
 auto get=[&](const unsigned char* data,unsigned i){unsigned n=0;memcpy(&n,data+size_t(i)*indexSize,indexSize);return n;};
 auto put=[&](unsigned i,unsigned n){memcpy(output.data()+size_t(i)*indexSize,&n,indexSize);};
 std::vector<unsigned char> boundary(count);for(unsigned g=0;g<groupCount;++g)if(groupStarts&&groupStarts[g]<count)boundary[groupStarts[g]]=1;
 std::vector<unsigned char> allowed(count);for(unsigned i=0;i<count;++i){unsigned n=get(indices,i);vrarm::V p{};bool valid=n!=cut&&uint64_t(n)*stride+12<=vertexBytes;if(valid)memcpy(&p,vertices+size_t(n)*stride,12);allowed[i]=valid&&region.contains(p);if(!allowed[i])put(i,cut);}
 unsigned originalStart=0;for(unsigned i=0;i<count;){if(boundary[i])originalStart=i;if(get(indices,i)==cut){originalStart=++i;continue;}if(!allowed[i]){++i;continue;}unsigned start=i;while(i<count&&allowed[i]&&(i==start||!boundary[i]))++i;if(i-start<3)continue;if((start-originalStart)&1u){if(start>=originalStart+2)put(start-2,cut);put(start-1,get(indices,start));}}
 unsigned kept=0,a=0,b=0,run=0;for(unsigned i=0;i<count;++i){if(boundary[i])run=0;unsigned v=get(output.data(),i);if(v==cut){run=0;continue;}if(run>=2&&a!=b&&a!=v&&b!=v)++kept;a=b;b=v;++run;}return kept;
}

}
