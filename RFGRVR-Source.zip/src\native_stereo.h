#pragma once
#include <cmath>
#include <cstdint>
// Engine-agnostic stereo render scheduler. Only schedules genuine separate eye views;
// no desktop capture, no duplicate mono frame, no global COM vtable patches.
namespace rfgrvr {
struct Vec3 {float x,y,z;};
struct Quat {float x,y,z,w;};
struct Pose {Vec3 p;Quat q;};
struct Eye {Pose tracked; float fovLeft,fovRight,fovUp,fovDown;};
struct Matrix4 {float m[16];};
struct StereoFrame {Eye eyes[2]; uint64_t predictedTime;};
struct FrameSink {
 virtual ~FrameSink() = default;
 // Called exactly once per eye; implementation must render actual scene from view/projection.
 virtual bool renderEye(unsigned eye, const Matrix4& view, const Matrix4& proj)=0;
};
inline bool valid(float x){return std::isfinite(x);}
inline bool validEye(const Eye& e){
 const auto& q=e.tracked.q; const auto& p=e.tracked.p;
 const float n=q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w;
 return valid(n)&&n>0.85f&&n<1.15f&&valid(p.x)&&valid(p.y)&&valid(p.z)&&
 valid(e.fovLeft)&&valid(e.fovRight)&&valid(e.fovUp)&&valid(e.fovDown)&&
 e.fovLeft<0&&e.fovRight>0&&e.fovDown<0&&e.fovUp>0;
}
inline Matrix4 projection(const Eye& e,float nearZ=0.05f,float farZ=4000.f){
 Matrix4 a{};const float l=std::tan(e.fovLeft),r=std::tan(e.fovRight),b=std::tan(e.fovDown),t=std::tan(e.fovUp);
 a.m[0]=2.f/(r-l);a.m[5]=2.f/(t-b);a.m[8]=(r+l)/(r-l);a.m[9]=(t+b)/(t-b);
 a.m[10]=farZ/(nearZ-farZ);a.m[11]=-1.f;a.m[14]=(farZ*nearZ)/(nearZ-farZ);
 return a;
}
inline Matrix4 view(const Eye& e){
 const auto&q=e.tracked.q;const auto&p=e.tracked.p;
 const float xx=q.x*q.x,yy=q.y*q.y,zz=q.z*q.z,xy=q.x*q.y,xz=q.x*q.z,yz=q.y*q.z,wx=q.w*q.x,wy=q.w*q.y,wz=q.w*q.z;
 // Rotation transpose, column major, translation = -R^T * position.
 Matrix4 a{};
 a.m[0]=1-2*(yy+zz);a.m[1]=2*(xy-wz);a.m[2]=2*(xz+wy);
 a.m[4]=2*(xy+wz);a.m[5]=1-2*(xx+zz);a.m[6]=2*(yz-wx);
 a.m[8]=2*(xz-wy);a.m[9]=2*(yz+wx);a.m[10]=1-2*(xx+yy);
 a.m[12]=-(a.m[0]*p.x+a.m[4]*p.y+a.m[8]*p.z);
 a.m[13]=-(a.m[1]*p.x+a.m[5]*p.y+a.m[9]*p.z);
 a.m[14]=-(a.m[2]*p.x+a.m[6]*p.y+a.m[10]*p.z);
 a.m[15]=1.f;return a;
}
inline bool renderStereo(const StereoFrame& frame,FrameSink& renderer){
 if(!validEye(frame.eyes[0])||!validEye(frame.eyes[1]))return false;
 for(unsigned i=0;i<2;i++)if(!renderer.renderEye(i,view(frame.eyes[i]),projection(frame.eyes[i])))return false;
 return true;
}
}
