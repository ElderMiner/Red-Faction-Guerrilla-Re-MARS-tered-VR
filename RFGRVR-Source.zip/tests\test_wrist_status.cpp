#define RFGR_WRIST_STATUS_TEST
#include "../src/bridge_wrist_status.h"
#include <cassert>
int main(){static_assert(sizeof(RFGRWristStatus)==1316,"Cross-process status ABI");vrstatus::hold(true);assert(vrstatus::value.twoHand==1);vrstatus::force(.75f,true);assert(vrstatus::value.percent==75&&vrstatus::value.hitPercent==75);vrstatus::force(1.5f);assert(vrstatus::value.percent==100&&vrstatus::value.hitPercent==75);vrstatus::notify("Tank request rejected");assert(!strcmp(vrstatus::value.message,"Tank request rejected"));vrstatus::hold(false);assert(!vrstatus::value.twoHand);WristStatusPixels panel;assert(panel.draw(vrstatus::value));assert(!panel.draw(vrstatus::value));auto* pixel=(unsigned char*)panel.pixels;assert(pixel&&pixel[3]==255&&pixel[512*160*4+3]==0);}
