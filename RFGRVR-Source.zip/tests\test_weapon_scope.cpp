#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#define RFGR_WRIST_STATUS_TEST
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include "../src/weapon_scope_gpu.h"
#include "../src/vr_eye_projection.h"
#include "../src/vr_auto_focus.h"
#include <cassert>
using Microsoft::WRL::ComPtr;
static ID3D11ShaderResourceView* nativeFixture=nullptr;
static ID3D11ShaderResourceView* nativeImage(int){if(nativeFixture)nativeFixture->AddRef();return nativeFixture;}
static unsigned readPixel(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* t,unsigned x,unsigned y){D3D11_TEXTURE2D_DESC desc{};t->GetDesc(&desc);desc.BindFlags=desc.MiscFlags=0;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;desc.Usage=D3D11_USAGE_STAGING;ComPtr<ID3D11Texture2D> s;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&s)));c->CopyResource(s.Get(),t);D3D11_MAPPED_SUBRESOURCE m{};assert(SUCCEEDED(c->Map(s.Get(),0,D3D11_MAP_READ,0,&m)));unsigned out=*(unsigned*)((char*)m.pData+y*m.RowPitch+x*4);c->Unmap(s.Get(),0);return out;}
int main(){using namespace vrscope;char temp[MAX_PATH]{};GetTempPathA(MAX_PATH,temp);sprintf_s(path,"%sRFGRVR-scope-test-%lu.ini",temp,GetCurrentProcessId());DeleteFileA(path);loaded=false;
 assert(index("sniper_rifle")==0&&index("rail_driver")==1&&index("nano_rifle")==-1);
 assert(fabsf(tanf(halfAngle(0))-.25f)<.00001f&&fabsf(tanf(halfAngle(1))-.4f)<.00001f);
 assert(edit(0,VK_MULTIPLY));assert(edit(0,VK_DIVIDE));assert(editing);assert(edit(0,VK_NUMPAD8));assert(edit(0,VK_NUMPAD7));assert(edit(0,VK_INSERT));assert(edit(0,VK_OEM_5));auto saved=settings(0);assert(saved.cut&&saved.scale>1&&saved.offset.y>.09f&&saved.offset.z>-.12f);
 loaded=false;profiles[0]={};assert(settings(0).cut&&fabsf(settings(0).offset.y-saved.offset.y)<.000001f&&settings(1).scale==1);
 assert(edit(0,VK_DIVIDE)&&!editing);assert(edit(0,VK_HOME));assert(settings(0).overlay);loaded=false;profiles[0]={};assert(settings(0).overlay&&!settings(1).overlay);assert(edit(0,VK_HOME)&&!settings(0).overlay);vrfocus::Control focus;assert(focus.update(1,0,true,true,3)==3);assert(focus.update(1,3,true,false,3)==0);
 Pose authoredWrist{identity,{.1f,.02f,.3f}};V palm{0,.02f,.08f};auto fitted=scaledWrist(authoredWrist,palm,2);assert(length(sub(add(fitted.p,world(fitted.b,palm)),mul(add(authoredWrist.p,world(authoredWrist.b,palm)),2)))<.00001f&&valid(fitted.b));
 Pose eye{identity,{}},weapon{identity,{0,0,1}},muzzle=weapon;publish(names[0],weapon,muzzle,1,true,true);Sleep(30);publish(names[0],weapon,muzzle,1,true,true);assert(snapshot().alpha>0);for(int n=0;n<3;++n){Sleep(60);publish(names[0],weapon,muzzle,1,false,true);}assert(!visible());publish("m16",weapon,muzzle,1,false,false);assert(!visible());
 // Magnification follows physical lens distance rather than a fixed-FOV texture.
 Frame lens;lens.kind=1;lens.panel={identity,{0,0,.3f}};lens.camera=lens.panel;lens.worldScale=1;
 auto centered=optics(lens,eye,1400);assert(centered.pupil==1&&centered.pixels>=1408);
 float apparent=.1f/.3f;assert(fabsf(apparent/tanf(centered.angles[1])-2.5f)<.0001f);
 Pose lateral=eye;lateral.p.x=.025f;auto right=optics(lens,lateral);lateral.p.x=-.025f;auto left=optics(lens,lateral);
 assert(fabsf(right.angles[0]+left.angles[1])<.00001f&&right.camera.p.x>left.camera.p.x);
 lens.panel.p.z=.6f;auto distant=optics(lens,eye,1400);assert(fabsf((.1f/.6f)/tanf(distant.angles[1])-2.5f)<.0001f&&distant.pixels<centered.pixels);
 lens.radius=.2f;auto smallCircle=optics(lens,eye);assert(fabsf(smallCircle.angles[1]-distant.angles[1])<.00001f);
 lateral.p.x=.2f;assert(optics(lens,lateral).pupil==0);lens.editing=true;assert(optics(lens,lateral).pupil==1);
 lens.kind=0;lens.editing=false;auto stableSniper=optics(lens,lateral);lens.panel.p.z=.1f;lateral.p.x=-.3f;auto movedSniper=optics(lens,lateral);assert(stableSniper.pixels==1536&&movedSniper.pixels==1536&&stableSniper.pupil==1&&movedSniper.pupil==1&&fabsf(tanf(movedSniper.angles[1])-.25f)<.00001f&&movedSniper.shift[0]==0&&movedSniper.shift[1]==0);
 char focusTemp[MAX_PATH];sprintf_s(focusTemp,"%sRFGRVR-focus-test-%lu.ini",temp,GetCurrentProcessId());strcpy_s(vrfocus::distancePath,focusTemp);DeleteFileA(focusTemp);vrfocus::distancesLoaded=false;
 assert(vrfocus::distanceGroup("rail_driver",2)==0&&vrfocus::distanceGroup("m16",2)==1&&vrfocus::distanceGroup("rocket_launcher",2)==2);
 assert(vrfocus::saveDistance(0,.19f));vrfocus::distancesLoaded=false;assert(fabsf(vrfocus::focusDistance(0)-.19f)<.00001f);assert(!vrfocus::saveDistance(0,3));
 vrfocus::DistanceCapture capture;capture.arm(0);float measured=0;assert(!capture.step(1,.19f,measured));assert(!capture.step(0,.19f,measured));assert(capture.step(1,.19f,measured)&&measured==.19f);assert(!capture.step(1,.19f,measured));DeleteFileA(focusTemp);
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));
 D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=512;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> back,source;ComPtr<ID3D11RenderTargetView> rt,srt;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&back)));assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&source)));d->CreateRenderTargetView(back.Get(),nullptr,&rt);d->CreateRenderTargetView(source.Get(),nullptr,&srt);float green[4]={0,1,0,1},red[4]={1,0,0,1};c->ClearRenderTargetView(srt.Get(),green);
 td.Format=DXGI_FORMAT_D32_FLOAT;td.BindFlags=D3D11_BIND_DEPTH_STENCIL;ComPtr<ID3D11Texture2D> z;ComPtr<ID3D11DepthStencilView> depth;d->CreateTexture2D(&td,nullptr,&z);d->CreateDepthStencilView(z.Get(),nullptr,&depth);
 RFGRScopeFeed feed;assert(feed.capture(d.Get(),c.Get(),source.Get(),0));RFGRWeaponScopeSurface surface;assert(surface.init(d.Get()));RFGRVREyeProjection p{};float angles[4]={-.785398f,.785398f,.785398f,-.785398f};assert(RFGRVR_BuildEngineProjection(angles,.1f,100,&p));
 ComPtr<ID3D11Texture2D> optic;ComPtr<ID3D11RenderTargetView> opticTarget;ComPtr<ID3D11ShaderResourceView> opticView;
 auto opticDesc=td;opticDesc.Format=DXGI_FORMAT_B8G8R8A8_UNORM;opticDesc.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;assert(SUCCEEDED(d->CreateTexture2D(&opticDesc,nullptr,&optic)));assert(SUCCEEDED(d->CreateRenderTargetView(optic.Get(),nullptr,&opticTarget)));assert(SUCCEEDED(d->CreateShaderResourceView(optic.Get(),nullptr,&opticView)));float clearOptic[4]={0,0,0,0};c->ClearRenderTargetView(opticTarget.Get(),clearOptic);nativeFixture=opticView.Get();nativeOverlay=&nativeImage;
 Frame f;f.panel=weapon;f.alpha=1;f.worldScale=1;f.cut=true;f.radius=.42f;
 auto draw=[&](float depthValue){c->ClearRenderTargetView(rt.Get(),red);c->ClearDepthStencilView(depth.Get(),D3D11_CLEAR_DEPTH,depthValue,0);assert(surface.draw(d.Get(),c.Get(),back.Get(),depth.Get(),feed,eye,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1));};
 draw(1);assert((readPixel(d.Get(),c.Get(),back.Get(),262,262)&0xffffff)==0x00ff00);assert((readPixel(d.Get(),c.Get(),back.Get(),274,274)&0xffffff)==0xff0000);
 f.cut=false;draw(1);assert((readPixel(d.Get(),c.Get(),back.Get(),274,274)&0xffffff)==0x00ff00);
 f.cut=true;draw(0);assert((readPixel(d.Get(),c.Get(),back.Get(),262,262)&0xffffff)==0xff0000);
 f.alpha=.5f;draw(1);unsigned mixed=readPixel(d.Get(),c.Get(),back.Get(),262,262);assert(((mixed>>16)&255)>100&&((mixed>>8)&255)>100);
 // Overlay bypasses world occluders; both eyes get the same retinal framing.
 f.overlay=true;f.alpha=1;f.cut=false;f.panel.p={100,100,-100};
 c->ClearRenderTargetView(rt.Get(),red);assert(surface.draw(d.Get(),c.Get(),back.Get(),nullptr,feed,eye,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1));assert((readPixel(d.Get(),c.Get(),back.Get(),280,280)&0xffffff)==0x00ff00);
 Pose other=eye;other.p.x=.07f;c->ClearRenderTargetView(rt.Get(),red);assert(surface.draw(d.Get(),c.Get(),back.Get(),nullptr,feed,other,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1));assert((readPixel(d.Get(),c.Get(),back.Get(),280,280)&0xffffff)==0x00ff00);
 // Setup stays a world-positioned panel, but remains placeable when no
 // scene-depth surface has been found (the live zero-draw failure).
 f.overlay=false;f.editing=true;f.panel=weapon;
 c->ClearRenderTargetView(rt.Get(),red);assert(surface.draw(d.Get(),c.Get(),back.Get(),nullptr,feed,eye,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1));assert((readPixel(d.Get(),c.Get(),back.Get(),274,274)&0xffffff)==0x00ff00);
 f.editing=false;assert(!surface.draw(d.Get(),c.Get(),back.Get(),nullptr,feed,eye,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1));
 f.editing=true;float blueOptic[4]={0,0,1,1};c->ClearRenderTargetView(opticTarget.Get(),blueOptic);c->ClearRenderTargetView(rt.Get(),red);assert(surface.draw(d.Get(),c.Get(),back.Get(),nullptr,feed,eye,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1));assert((readPixel(d.Get(),c.Get(),back.Get(),262,262)&0xffffff)==0x0000ff);
 // Independent eye feeds retain their own images and resize without an atlas copy.
 c->ClearRenderTargetView(opticTarget.Get(),clearOptic);c->ClearRenderTargetView(srt.Get(),red);assert(feed.capture(d.Get(),c.Get(),source.Get(),1));
 c->ClearRenderTargetView(rt.Get(),green);assert(surface.draw(d.Get(),c.Get(),back.Get(),nullptr,feed,eye,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1,1));assert((readPixel(d.Get(),c.Get(),back.Get(),262,262)&0xffffff)==0xff0000);
 c->ClearRenderTargetView(rt.Get(),red);assert(surface.draw(d.Get(),c.Get(),back.Get(),nullptr,feed,eye,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1,0));assert((readPixel(d.Get(),c.Get(),back.Get(),262,262)&0xffffff)==0x00ff00);
 D3D11_TEXTURE2D_DESC high{};source->GetDesc(&high);high.Width=high.Height=2048;ComPtr<ID3D11Texture2D> highSource;assert(SUCCEEDED(d->CreateTexture2D(&high,nullptr,&highSource)));assert(feed.capture(d.Get(),c.Get(),highSource.Get(),1));D3D11_TEXTURE2D_DESC actual{};feed.images[1]->GetDesc(&actual);assert(actual.Width==2048&&actual.Height==2048);feed.images[0]->GetDesc(&actual);assert(actual.Width==512);
 nativeOverlay=nullptr;assert(!surface.draw(d.Get(),c.Get(),back.Get(),nullptr,feed,eye,p.columnMajor,f,D3D11_COMPARISON_LESS_EQUAL,0,1)&&surface.lastFailure==11);
 surface.beforeResize();assert(!surface.output&&!surface.target);DeleteFileA(path);
 puts("PASS: independent scope settings/reload, native scope focus state, circular feathered GPU mask, alpha fade, world-depth occlusion and resize cleanup");
}

