#pragma once
#include "vr_night_lighting.h"
#include <atomic>
#include <cstdint>
namespace vrnightlights {
// Verified GameRenderGetTodLight (3C2960): +130 overrides +12C. These are
// rl_light pointers, NEVER camera pointers. Native colour lives at +CC.
inline void** sceneRoot=nullptr;
inline std::atomic<unsigned> mainSamples{0},mainWrites{0},ambientWrites{0};
inline void* pointer(const void* p,unsigned offset){unsigned value=0;if(vrmemory::check((const char*)p+offset,4))memcpy(&value,(const char*)p+offset,4);return (void*)(uintptr_t)value;}
inline void* selected(){void* root=sceneRoot?*sceneRoot:nullptr;if(!vrmemory::check(root,0x134))return nullptr;void* light=pointer(root,0x130);return light?light:pointer(root,0x12c);}
using Colour=uintptr_t(__thiscall*)(void*,float*,float);inline Colour colour=nullptr;
inline uintptr_t __fastcall onColour(void* self,void*,float* output,float scale){
 uintptr_t result=colour(self,output,scale);const auto* p=vrnight::current;
 if(!p||!RFGRVR_HeadCam_Enabled()||self!=selected()||!vrmemory::check(self,0x11c)||!vrmemory::check(output,12,true))return result;
 unsigned type=~0u;memcpy(&type,(char*)self+0xc8,4);if(type!=0)return result;
 ++mainSamples;if(p->mainLight==1)return result;
 for(int i=0;i<3;++i)if(!std::isfinite(output[i]))return result;
 for(int i=0;i<3;++i)output[i]*=p->mainLight;
 ++mainWrites;return result;
}
using Ambient=void(__thiscall*)(void*,const float*);inline Ambient front=nullptr,back=nullptr;
inline void ambient(Ambient native,void* renderer,const float* input){
 const auto* p=vrnight::current;
 if(!p||!RFGRVR_HeadCam_Enabled()||p->ambient==1||!vrmemory::check(input,16)){native(renderer,input);return;}
 float value[4];memcpy(value,input,16);for(int i=0;i<3;++i)if(!std::isfinite(value[i])){native(renderer,input);return;}
 for(int i=0;i<3;++i)value[i]*=p->ambient;
 ++ambientWrites;native(renderer,value);
}
inline void __fastcall onFront(void* renderer,void*,const float* input){ambient(front,renderer,input);}
inline void __fastcall onBack(void* renderer,void*,const float* input){ambient(back,renderer,input);}
// Native 117855 calls front then back without reloading ECX/EDX, and retains
// XMM6/7 across both. A normal C++ callback has a weaker register contract.
__declspec(naked) inline void frontEntry(){__asm {
 push ecx
 push edx
 sub esp,32
 movups [esp],xmm6
 movups [esp+16],xmm7
 push [esp+44]
 call onFront
 movups xmm6,[esp]
 movups xmm7,[esp+16]
 add esp,32
 pop edx
 pop ecx
 ret 4
}}
__declspec(naked) inline void backEntry(){__asm {
 push ecx
 push edx
 sub esp,32
 movups [esp],xmm6
 movups [esp+16],xmm7
 push [esp+44]
 call onBack
 movups xmm6,[esp]
 movups xmm7,[esp+16]
 add esp,32
 pop edx
 pop ecx
 ret 4
}}
}
