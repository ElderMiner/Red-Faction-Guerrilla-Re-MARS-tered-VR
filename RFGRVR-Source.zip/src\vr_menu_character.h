#pragma once
#include <windows.h>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include "vr_arm_math.h"
namespace RFGRVRMenuCharacter {
struct Placement {vrarm::V offset{};float scale=1;};
inline Placement placement;inline SRWLOCK lock=SRWLOCK_INIT;inline INIT_ONCE once=INIT_ONCE_STATIC_INIT;inline char path[MAX_PATH]{};
inline BOOL CALLBACK load(PINIT_ONCE,void*,void**){GetModuleFileNameA(nullptr,path,MAX_PATH);char* slash=strrchr(path,92);if(!slash){path[0]=0;return TRUE;}strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-menu-character.ini");const char* keys[]={"X","Y","Z","Scale"};float* values[]={&placement.offset.x,&placement.offset.y,&placement.offset.z,&placement.scale};for(unsigned i=0;i<4;++i){char text[40]{};GetPrivateProfileStringA("Character",keys[i],"",text,40,path);float value=0;if(sscanf_s(text,"%f",&value)==1&&std::isfinite(value)&&((i<3&&fabsf(value)<=10)||(i==3&&value>=.25f&&value<=4)))*values[i]=value;}return TRUE;}
inline Placement get(){InitOnceExecuteOnce(&once,load,nullptr,nullptr);AcquireSRWLockShared(&lock);auto value=placement;ReleaseSRWLockShared(&lock);return value;}
inline void save(const Placement& value){const char* keys[]={"X","Y","Z","Scale"};const float values[]={value.offset.x,value.offset.y,value.offset.z,value.scale};if(!path[0])return;for(unsigned i=0;i<4;++i){char text[40];sprintf_s(text,"%.6f",values[i]);WritePrivateProfileStringA("Character",keys[i],text,path);}}
inline void poll(bool active){static bool held[8]{};static ULONGLONG repeat[8]{};const int keys[]={VK_NUMPAD9,VK_NUMPAD3,VK_NUMPAD4,VK_NUMPAD6,VK_NUMPAD8,VK_NUMPAD2,VK_NUMPAD7,VK_NUMPAD1};for(unsigned i=0;i<8;++i){bool down=active&&(GetAsyncKeyState(keys[i])&0x8000);ULONGLONG now=GetTickCount64();if(down&&(!held[i]||now>=repeat[i])){auto value=get();if(i<6){float* axis=i<2?&value.offset.z:i<4?&value.offset.x:&value.offset.y;float sign=(i==0||i==2||i==5)?-1.f:1.f;*axis=(std::max)(-10.f,(std::min)(10.f,*axis+sign*.025f));}else value.scale=(std::max)(.25f,(std::min)(4.f,value.scale*(i==6?1.025f:1/1.025f)));AcquireSRWLockExclusive(&lock);placement=value;ReleaseSRWLockExclusive(&lock);save(value);repeat[i]=now+(held[i]?60:350);}held[i]=down;}}
// Inverse camera transform is equivalent to transforming the isolated 3D
// character scene. Both the center camera and eye separation use this scale.
inline vrarm::V camera(vrarm::V center,vrarm::M basis,float units,const Placement& value){using namespace vrarm;V pivot=add(center,world(basis,{0,-.85f*units,2.f*units}));V translation=world(basis,mul(value.offset,units));return add(pivot,mul(sub(sub(center,pivot),translation),1/value.scale));}
}

