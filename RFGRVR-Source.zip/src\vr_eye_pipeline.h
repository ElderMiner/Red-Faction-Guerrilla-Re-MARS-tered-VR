#pragma once
#include <d3d11.h>
#include <wrl/client.h>
// Preserve bindings as well as buffer bytes. Get calls retain COM references;
// all are released when this one pair ends. No ClearState or global-vtable edits.
template<class T,unsigned N> struct RFGRVRBindings {
 T* p[N]{};
 RFGRVRBindings()=default;RFGRVRBindings(const RFGRVRBindings&)=delete;
 ~RFGRVRBindings(){for(auto* value:p)if(value)value->Release();}
};
template<class Shader> struct RFGRVRShaderBindings {
 Microsoft::WRL::ComPtr<Shader> shader;
 RFGRVRBindings<ID3D11ClassInstance,256> classes;UINT count=256;
 RFGRVRBindings<ID3D11Buffer,14> buffers;
 RFGRVRBindings<ID3D11ShaderResourceView,128> resources;
 RFGRVRBindings<ID3D11SamplerState,16> samplers;
};
struct RFGRVREyePipeline {
 RFGRVRShaderBindings<ID3D11VertexShader> vs;
 RFGRVRShaderBindings<ID3D11PixelShader> ps;
 RFGRVRShaderBindings<ID3D11GeometryShader> gs;
 RFGRVRShaderBindings<ID3D11HullShader> hs;
 RFGRVRShaderBindings<ID3D11DomainShader> ds;
 RFGRVRBindings<ID3D11RenderTargetView,8> targets;
 Microsoft::WRL::ComPtr<ID3D11DepthStencilView> depth;
 Microsoft::WRL::ComPtr<ID3D11BlendState> blend;FLOAT factors[4]{};UINT sampleMask=0;
 Microsoft::WRL::ComPtr<ID3D11DepthStencilState> depthState;UINT stencil=0;
 Microsoft::WRL::ComPtr<ID3D11RasterizerState> raster;
 D3D11_VIEWPORT viewports[16]{};UINT viewportCount=16;
 D3D11_RECT scissors[16]{};UINT scissorCount=16;
 Microsoft::WRL::ComPtr<ID3D11InputLayout> layout;
 RFGRVRBindings<ID3D11Buffer,32> vertices;UINT strides[32]{},offsets[32]{};
 Microsoft::WRL::ComPtr<ID3D11Buffer> indices;DXGI_FORMAT indexFormat{};UINT indexOffset=0;
 D3D11_PRIMITIVE_TOPOLOGY topology{};
 void save(ID3D11DeviceContext* c){
#define RFGR_GET_STAGE(S,N) c->N##GetShader(&S.shader,S.classes.p,&S.count);c->N##GetConstantBuffers(0,14,S.buffers.p);c->N##GetShaderResources(0,128,S.resources.p);c->N##GetSamplers(0,16,S.samplers.p)
  RFGR_GET_STAGE(vs,VS);RFGR_GET_STAGE(ps,PS);RFGR_GET_STAGE(gs,GS);RFGR_GET_STAGE(hs,HS);RFGR_GET_STAGE(ds,DS);
#undef RFGR_GET_STAGE
  c->OMGetRenderTargets(8,targets.p,&depth);c->OMGetBlendState(&blend,factors,&sampleMask);c->OMGetDepthStencilState(&depthState,&stencil);
  c->RSGetState(&raster);c->RSGetViewports(&viewportCount,viewports);c->RSGetScissorRects(&scissorCount,scissors);
  c->IAGetInputLayout(&layout);c->IAGetVertexBuffers(0,32,vertices.p,strides,offsets);c->IAGetIndexBuffer(&indices,&indexFormat,&indexOffset);c->IAGetPrimitiveTopology(&topology);
 }
 void restore(ID3D11DeviceContext* c,unsigned mask=~0u)const{
  RFGRVRBindings<ID3D11RenderTargetView,8> currentTargets;Microsoft::WRL::ComPtr<ID3D11DepthStencilView> currentDepth;
  if(!(mask&16))c->OMGetRenderTargets(8,currentTargets.p,&currentDepth);
  c->OMSetRenderTargets(0,nullptr,nullptr);
  // Release output bindings before restoring SRVs, avoiding implicit hazard
  // unbinding of a texture that the baseline expects to read.
#define RFGR_SET_STAGE(S,N) c->N##SetShader(S.shader.Get(),S.classes.p,S.count);c->N##SetConstantBuffers(0,14,S.buffers.p);c->N##SetShaderResources(0,128,S.resources.p);c->N##SetSamplers(0,16,S.samplers.p)
  if(mask&1){RFGR_SET_STAGE(vs,VS);}if(mask&2){RFGR_SET_STAGE(ps,PS);}if(mask&4){RFGR_SET_STAGE(gs,GS);}if(mask&8){RFGR_SET_STAGE(hs,HS);RFGR_SET_STAGE(ds,DS);}
#undef RFGR_SET_STAGE
  if(mask&16){c->OMSetRenderTargets(8,targets.p,depth.Get());c->OMSetBlendState(blend.Get(),factors,sampleMask);c->OMSetDepthStencilState(depthState.Get(),stencil);}
  else c->OMSetRenderTargets(8,currentTargets.p,currentDepth.Get());
  if(mask&32){c->RSSetState(raster.Get());c->RSSetViewports(viewportCount,viewports);c->RSSetScissorRects(scissorCount,scissors);}
  if(mask&64){c->IASetInputLayout(layout.Get());c->IASetVertexBuffers(0,32,vertices.p,strides,offsets);c->IASetIndexBuffer(indices.Get(),indexFormat,indexOffset);c->IASetPrimitiveTopology(topology);}
 }
};
