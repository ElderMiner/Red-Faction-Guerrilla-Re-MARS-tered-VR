#pragma once
#include <atomic>
#include "vr_memory_access.h"
#include <cstdint>
#include <cstring>
#include <mutex>
namespace RFGRVREffectGeometry {
inline bool profiling=false;
inline std::atomic<unsigned long long> prepareTicks{0},renderTicks{0};
inline std::atomic<unsigned> probeCount{0},fullTables{0};
struct Entry {void* object=nullptr;unsigned generation=0,identity=0,count40=0,count58=0,storage38=0,storage50=0;unsigned restoredPass=0;};
inline std::atomic<unsigned> calls[2]{},restores{0};inline std::mutex guard;inline Entry entries[4096]{};inline unsigned generation=0,usedCount=0,viewPass=0;inline unsigned used[4096]{};inline std::atomic<int> eye{-1};
inline bool readable(void* p,size_t n){return vrmemory::check(p,n); }
inline unsigned slotFor(const void* object){uint32_t x=uint32_t(uintptr_t(object)>>4);x^=x>>16;x*=0x7feb352du;x^=x>>15;return x&4095;}
inline unsigned word(void* p,unsigned offset){unsigned v=0;memcpy(&v,(char*)p+offset,4);return v;}
inline Entry* lookup(void* object,bool create){unsigned slot=slotFor(object);for(unsigned i=0;i<4096;++i){if(profiling)++probeCount;auto& e=entries[(slot+i)&4095];if(e.generation!=generation){if(!create)return nullptr;e={object,generation,word(object,0xcc),word(object,0x40),word(object,0x58),word(object,0x38),word(object,0x50),0};if(usedCount<4096)used[usedCount++]=(slot+i)&4095;return &e;}if(e.object==object)return &e;}if(profiling)++fullTables;return nullptr;}
inline void select(unsigned e);
inline bool prepare(void* object){int e=eye.load();if(e<0)return false;std::lock_guard<std::mutex> lock(guard);if(e<0||!readable(object,0xd0))return false;++calls[e];if(!e){auto* saved=lookup(object,true);if(saved){if(!saved->count40)saved->count40=word(object,0x40);if(!saved->count58)saved->count58=word(object,0x58);}return false;}auto* saved=lookup(object,false);if(!saved){saved=lookup(object,true);if(saved)saved->restoredPass=viewPass;return false;}if(saved->restoredPass==viewPass||saved->identity!=word(object,0xcc))return false;saved->restoredPass=viewPass;bool changed=false;
 for(unsigned i=0;i<2;++i){unsigned offset=i?0x58:0x40,count=i?saved->count58:saved->count40,storage=i?saved->storage50:saved->storage38;unsigned capacity=word(object,offset-4);if(count&&!word(object,offset)&&capacity<=1048576&&count<=capacity&&word(object,offset-8)==storage&&readable((void*)(uintptr_t)storage,1)){memcpy((char*)object+offset,&count,4);changed=true;}}
 if(changed)++restores;return changed;}
inline void select(unsigned e){
 if(!e){viewPass=0;usedCount=0;calls[0]=0;calls[1]=0;restores=0;if(++generation==0){for(auto& x:entries)x.generation=0;generation=1;}}
 if(!e)profiling=(generation%120)==0;
 eye=int(e);if(e)++viewPass;
 // Restore before the second scene builds its visible lists. Restoring only
 // at submission is too late when an empty queue excludes the effect upstream.
 if(e==1)for(unsigned i=0;i<usedCount;++i){auto& entry=entries[used[i]];if(entry.generation==generation)prepare(entry.object);}
}
using Render=void(__thiscall*)(void*,uintptr_t,uintptr_t,void*,uintptr_t,uintptr_t);
inline Render render=nullptr;
inline void __fastcall onRender(void* self,void*,uintptr_t a,uintptr_t b,void* source,uintptr_t d,uintptr_t e){vrmemory::Scope memoryScope;if(!profiling){prepare(source);render(self,a,b,source,d,e);return;}LARGE_INTEGER start{},prepared{},done{};QueryPerformanceCounter(&start);prepare(source);QueryPerformanceCounter(&prepared);render(self,a,b,source,d,e);QueryPerformanceCounter(&done);prepareTicks+=prepared.QuadPart-start.QuadPart;renderTicks+=done.QuadPart-prepared.QuadPart;}
}




