#pragma once
#include "ipc.h"
#include <cmath>
#include <initializer_list>
inline bool RFGRVR_TPose(const RFGRPose& head,const RFGRPose& left,const RFGRPose& right,bool floor,float& height,float& span){
 if((head.validFlags&3)!=3||(left.validFlags&3)!=3||(right.validFlags&3)!=3||!left.active||!right.active)return false;
 for(auto* pose:{&head,&left,&right})for(float v:pose->position)if(!std::isfinite(v))return false;
 float dx=left.position[0]-right.position[0],dy=left.position[1]-right.position[1],dz=left.position[2]-right.position[2];span=sqrtf(dx*dx+dy*dy+dz*dz);
 height=floor?head.position[1]:1.65f;
 if(height<1||height>2.4f||span<.8f||span>2.6f||fabsf(dy)>.2f)return false;
 for(auto* hand:{&left,&right}){float down=head.position[1]-hand->position[1];if(down<-.15f||down>.65f)return false;}
 return true;
}
struct RFGRVRCalibrationSamples {
 unsigned count=0;double heightSum=0,spanSum=0;float minHeight=0,maxHeight=0,minSpan=0,maxSpan=0;
 void reset(){*this={};}
 bool add(float height,float span){
  if(!std::isfinite(height)||!std::isfinite(span)){reset();return false;}
  if(!count){minHeight=maxHeight=height;minSpan=maxSpan=span;}
  if(height<minHeight)minHeight=height;if(height>maxHeight)maxHeight=height;if(span<minSpan)minSpan=span;if(span>maxSpan)maxSpan=span;
  if(maxHeight-minHeight>.04f||maxSpan-minSpan>.08f){reset();return false;}
  ++count;heightSum+=height;spanSum+=span;return true;
 }
 bool average(float& height,float& span)const{if(!count)return false;height=float(heightSum/count);span=float(spanSum/count);return true;}
};

// Explicit companion-only restart in an unchanged runtime STAGE space.
inline bool RFGRVR_CanResumeCalibration(const RFGRShared* shared,bool stage){return shared&&stage&&shared->magic==RFGR_MAGIC&&shared->version==RFGR_PROTOCOL&&shared->gamePid&&shared->calibrationReady&&shared->calibrationFloorValid&&(shared->hmd.validFlags&3)==3&&std::isfinite(shared->calibratedHeadHeight)&&shared->calibratedHeadHeight>=1&&shared->calibratedHeadHeight<=2.4f&&std::isfinite(shared->calibratedArmSpan)&&shared->calibratedArmSpan>=.8f&&shared->calibratedArmSpan<=2.6f;}
