#pragma once
#include <windows.h>
#include <stdint.h>
#pragma pack(push,8)
struct RFGRPose {
    float position[3];
    float orientation[4]; // x,y,z,w
    uint32_t validFlags;  // 1 orientation valid, 2 position valid
    uint32_t active;      // action active for hands
};
// XR view measurements are sampled for the predicted display time of each XR frame.
// Zero valid flags => do not submit/render the eye. Floats use OpenXR right-handed meters.
struct RFGREye {
    RFGRPose pose;
    float fov[4]; // angleLeft, angleRight, angleUp, angleDown (radians)
};
struct RFGRGamepad {uint16_t buttons;uint8_t leftTrigger,rightTrigger;int16_t leftX,leftY,rightX,rightY;};
static_assert(sizeof(RFGRGamepad)==12,"Gamepad layout");
struct RFGRShared {
    uint32_t magic;
    uint32_t version;       // protocol = 2
    volatile LONG gamePid;
    volatile LONG bridgePid;
    volatile LONG openxrState; // 1 loader, 2 instance, 3 headset, 4 session, 5 tracking, negatives error
    volatile LONG gameHeartbeat;
    volatile LONG bridgeHeartbeat;
    char status[192];
    volatile LONG poseSequence; // odd writing, even consistent. Don't reset counters on reconnect.
    volatile LONG poseSamples;
    volatile LONG menuSelect; // 1 while right-hand confirm action is pressed
    volatile LONG menuBack;   // 1 while right-hand back action is pressed
    volatile LONG menuNavX;   // -1, 0, +1 from left thumbstick
    volatile LONG menuNavY;   // -1, 0, +1 from left thumbstick
    RFGRPose hmd;
    RFGRPose left;
    RFGRPose right;
    volatile LONG stereoSequence; // even: stable; odd: bridge updating
    volatile LONG stereoSamples;
    int64_t predictedDisplayTime; // XrTime, in runtime-specific units
    RFGREye eyes[2];
    volatile LONG stereoValid; // 1 iff locateViews returned two valid tracked poses
    volatile LONG gameplayActive; // recent player-head update; heuristic, not engine menu state
    volatile LONG theaterMode; // explicit F5 override, also suppresses head-look
    volatile LONG inputSequence,inputSamples,gamepadActive;
    RFGRGamepad gamepad;
    RFGRPose leftAim,rightAim;
    float calibratedHeadHeight,calibratedArmSpan;volatile LONG calibrationReady;
    volatile LONG playerParentState; // game-published state; 7..10 seated vehicle
    volatile LONG calibrationFloorValid; // standing eye height measured in STAGE floor space
    float gripValue[2]; // raw left/right squeeze, published under inputSequence
};
#pragma pack(pop)
static constexpr wchar_t RFGR_MAP_NAME[]=L"Local\\RFGRVR_native_v19_IPC";
static constexpr uint32_t RFGR_MAGIC=0x52464752;
static constexpr uint32_t RFGR_PROTOCOL=11;
