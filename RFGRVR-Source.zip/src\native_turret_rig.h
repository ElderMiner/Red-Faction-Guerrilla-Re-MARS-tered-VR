#pragma once
#include "vr_turret_rig.h"
#include <windows.h>
#include <atomic>
#include <cstring>
#include "../vendor/MinHook.h"
extern "C" bool RFGRVR_Arms_TurretHand(float[3],float[3]);
extern "C" bool RFGRVR_Arms_TurretBody(float[3]);
extern "C" bool RFGRVR_Arms_TurretHandZero(float[3]);
extern "C" bool RFGRVR_Arms_TurretHandleTarget(float[3],float[3]);
extern "C" float RFGRVR_Arms_TurretGripLever(unsigned);
extern "C" bool RFGRVR_HeadCam_Enabled();
extern "C" bool RFGRVR_DriverTurretOwned(void*);
extern "C" float RFGRVR_HeadCam_WorldScale();
namespace RFGRVRNativeTurret {
inline unsigned char* base=nullptr;inline std::atomic<float> stick{0};inline std::atomic<ULONGLONG> stickTick{0};
inline SRWLOCK lock=SRWLOCK_INIT;inline RFGRVRTurretRig rig;inline ULONGLONG tick=0,fresh=0;inline vrarm::V pivotLocal{};
using Lookup=void*(__thiscall*)(void*,unsigned);using Update=void(__thiscall*)(void*);using Input=void(__thiscall*)(void*,unsigned,unsigned,unsigned,unsigned);using Motor=void(__cdecl*)(void*,bool,bool);using Wake=void(__thiscall*)(void*);
using JointSync=void(__cdecl*)(void*,void*);inline JointSync originalJointSync=nullptr;inline std::atomic<unsigned> jointSyncSkipped{0};
inline Lookup lookup=nullptr;inline Update original=nullptr;inline Input input[2]{};inline Motor motor=nullptr;inline Wake wake=nullptr;
// Cache page metadata only within one synchronous native update; never across frames.
struct RegionBatch {MEMORY_BASIC_INFORMATION regions[24]{};unsigned count=0,depth=0;};
inline thread_local RegionBatch regionBatch;
struct BatchMemory {BatchMemory(){if(!regionBatch.depth++)regionBatch.count=0;}~BatchMemory(){if(!--regionBatch.depth)regionBatch.count=0;}};
inline bool memory(const void* p,size_t n,bool write=false){if(!p)return false;auto a=(uintptr_t)p;MEMORY_BASIC_INFORMATION m{};bool found=false;
 if(regionBatch.depth)for(unsigned i=0;i<regionBatch.count;++i){auto& r=regionBatch.regions[i];auto b=(uintptr_t)r.BaseAddress;if(a>=b&&n<=r.RegionSize&&a-b<=r.RegionSize-n){m=r;found=true;break;}}
 if(!found){if(!VirtualQuery(p,&m,sizeof(m)))return false;if(regionBatch.depth&&regionBatch.count<24)regionBatch.regions[regionBatch.count++]=m;}
 if(m.State!=MEM_COMMIT||m.Protect&(PAGE_GUARD|PAGE_NOACCESS))return false;auto b=(uintptr_t)m.BaseAddress;DWORD prot=m.Protect&255;return a>=b&&n<=m.RegionSize&&a-b<=m.RegionSize-n&&(!write||prot==PAGE_READWRITE||prot==PAGE_WRITECOPY||prot==PAGE_EXECUTE_READWRITE||prot==PAGE_EXECUTE_WRITECOPY);}

inline unsigned word(const void* p,size_t o){unsigned v=0;if(memory((char*)p+o,4))memcpy(&v,(char*)p+o,4);return v;}
inline bool gunRenderPose(void* gun,vrarm::Pose& pose){using namespace vrarm;if(!memory(gun,0x80))return false;memcpy(&pose.p,(char*)gun+4,12);memcpy(&pose.b,(char*)gun+0x10,36);if(!valid(pose.b)||!finite(pose.p))return false;
 // Mounted guns use a skinned CharacterInstance at item+BC. Their visible
 // transform is interpolated separately from object+4, just like the avatar.
 // Put the hands on that visible gun, rather than its simulation pose.
 void* character=(void*)(uintptr_t)word(gun,0xbc);void* renderable=(void*)(uintptr_t)word(character,0x30);Pose rendered{};if(memory(character,0x38)&&memory((char*)renderable+8,48)){memcpy(&rendered,(char*)renderable+8,48);if(valid(rendered.b)&&finite(rendered.p)&&length(sub(rendered.p,pose.p))<2)pose=rendered;}return true;
}
// The pitch hinge's parent frame supplies a gun-only horizontal swivel.
// Keep the assembly's own yaw motor reserved for coarse seat rotation.
struct GunSwivel {
 void* constraint=nullptr;void* data=nullptr;unsigned bodyA=0,bodyB=0;vrarm::M saved{},written{};float angle=0;bool changed=false;
 bool same(){return memory(constraint,0x20)&&word(constraint,12)==(unsigned)(uintptr_t)data&&word(constraint,0x14)==bodyA&&word(constraint,0x18)==bodyB&&memory(data,0xa0,true);}
 vrarm::M read(){vrarm::M m{};memcpy(&m.r,(char*)data+0x20,12);memcpy(&m.u,(char*)data+0x30,12);memcpy(&m.f,(char*)data+0x40,12);return m;}
 void write(vrarm::M m){memcpy((char*)data+0x20,&m.r,12);memcpy((char*)data+0x30,&m.u,12);memcpy((char*)data+0x40,&m.f,12);}
 bool worldUnlocked(){void* a=(void*)(uintptr_t)bodyA;void* b=(void*)(uintptr_t)bodyB;void* world=(void*)(uintptr_t)word(a,8);return memory(a,12)&&memory(b,12)&&world&&(unsigned)(uintptr_t)world==word(b,8)&&memory(world,0x90)&&word(world,0x8c)==0;}
 bool restore(){if(changed&&same()){auto current=read();if(!memcmp(&current,&written,sizeof(current))){if(!worldUnlocked())return false;write(saved);}}*this={};return true;}
 bool apply(void* joint,float yaw,float dt=.05f){using namespace vrarm;void* c=(void*)(uintptr_t)word(joint,0x74);void* d=(void*)(uintptr_t)word(c,12);
  if(c!=constraint||d!=data){if(!restore())return false;if(!memory(c,0x20)||!memory(d,0xa0,true)||!memory((void*)(uintptr_t)word(d,0),0x14)||word((void*)(uintptr_t)word(d,0),0x10)!=(unsigned)(uintptr_t)(base+0x96c970)||*(unsigned short*)((char*)d+0x10)!=2)return false;constraint=c;data=d;bodyA=word(c,0x14);bodyB=word(c,0x18);saved=read();if(!valid(saved)){*this={};return false;}}
  if(!same()||!worldUnlocked()||!std::isfinite(yaw))return false;
  float target=(std::max)(-.75f,(std::min)(.75f,yaw)),step=4.f*(std::max)(0.f,(std::min)(.05f,std::isfinite(dt)?dt:0.f));angle+=(std::max)(-step,(std::min)(step,target-angle));written=turnAround(saved,{0,1,0},angle);write(written);changed=true;return true;
 }
};inline GunSwivel gunSwivel;
// Measured assembly rotation, rather than its motor target, carries the seat.
inline unsigned seatAssemblyId=~0u;inline float seatAssemblyStart=0;
inline bool assemblyBasis(void* joint,vrarm::M& m){unsigned h=word(joint,0x48);if(h>=65536)return false;void* b=(void*)(uintptr_t)word(base,0x236e980+h*4);if(!memory(b,0x130))return false;memcpy(&m.r,(char*)b+0xf0,12);memcpy(&m.u,(char*)b+0x100,12);memcpy(&m.f,(char*)b+0x110,12);return vrarm::valid(m);}
inline bool assemblyYaw(void* joint,float& yaw){vrarm::M m{};if(!assemblyBasis(joint,m))return false;yaw=atan2f(m.f.x,m.f.z);return std::isfinite(yaw);}

inline bool rotationPivot(void* joint,vrarm::V& out){using namespace vrarm;void* c=(void*)(uintptr_t)word(joint,0x4c);void* d=(void*)(uintptr_t)word(c,12);void* a=(void*)(uintptr_t)word(c,0x14);void* b=(void*)(uintptr_t)word(c,0x18);if(!memory(d,0xa0)||!memory(a,0x130)||!memory(b,0x130)||word((void*)(uintptr_t)word(d,0),0x10)!=(unsigned)(uintptr_t)(base+0x96c970))return false;auto point=[&](void* body,unsigned offset,V& value){M m{};V p{},v{};memcpy(&m.r,(char*)body+0xf0,12);memcpy(&m.u,(char*)body+0x100,12);memcpy(&m.f,(char*)body+0x110,12);memcpy(&p,(char*)body+0x120,12);memcpy(&v,(char*)d+offset,12);if(!valid(m)||!finite(p)||!finite(v)||length(v)>20)return false;value=add(p,world(m,v));return finite(value);};V pa{},pb{};if(!point(a,0x50,pa)||!point(b,0x90,pb)||length(sub(pa,pb))>.15f)return false;out=*((unsigned char*)b+0xe8)==5?pb:pa;return true;}

inline void* player(){return base?(void*)(uintptr_t)word(base,0x2c23874):nullptr;}
// Raider harpoon is operated from a standing rear platform. It is not a
// centered ring seat even though the native player state is vehicle gunner.
inline bool standingVehicleMount(void* turret){void* info=(void*)(uintptr_t)word(turret,0x9c);const char* name=(const char*)(uintptr_t)word(info,0);constexpr char expected[]="turret_vehicle_raider_harpoon";return memory(name,sizeof(expected))&&!memcmp(name,expected,sizeof(expected));}
inline bool owned(void* turret){void* p=player();if(!RFGRVR_HeadCam_Enabled()||!lookup||!memory(p,0xc94)||!memory(turret,0x164))return false;unsigned state=word(p,0x2f4),id=word(p,0xa08);return (state==3||state==8)&&id&&id!=~0u&&lookup(base+0x2b98490,id)==turret&&*((unsigned char*)turret+0x7e)==6;}
// The independent object-frame update calls this after player input. It
// replaces +9C/+A0 with measured assembly yaw, cancelling our motor target.
// Keep native object/physics updates; exclude only this feedback writer for
// the exact joint currently owned by the local standing/gunner VR controller.
inline void __cdecl onJointSync(void* joint,void* turret){if(owned(turret)&&(void*)(uintptr_t)word(turret,0xd8)==joint){++jointSyncSkipped;return;}originalJointSync(joint,turret);}
inline void __fastcall onInput0(void* self,void*,unsigned a,unsigned b,unsigned c,unsigned d){if(!owned(self)&&!RFGRVR_DriverTurretOwned(self))input[0](self,a,b,c,d);}
inline void __fastcall onInput1(void* self,void*,unsigned a,unsigned b,unsigned c,unsigned d){if(!owned(self)&&!RFGRVR_DriverTurretOwned(self))input[1](self,a,b,c,d);}
inline void wakeBodies(void* joint){
 if(!wake||!base)return;
 for(unsigned offset:{0x20u,0x48u,0x70u}){unsigned handle=word(joint,offset);if(handle>=65536)continue;
  void* body=(void*)(uintptr_t)word(base,0x236e980+handle*4);
  // Native activation is queue-safe if the physics world is locked. Fixed
  // bodies and detached bodies are skipped; no velocity/force is supplied.
  if(memory(body,0x130)&&word(body,8)&&*((unsigned char*)body+0xe8)!=5)wake(body);
 }
}
inline void apply(void* self){
 if(!owned(self)){original(self);return;}auto* t=(char*)self;void* p=player();float hand[3]{},aim[3]{};
 if(!RFGRVR_Arms_TurretHand(hand,aim)||t[0xdc]!=1){original(self);return;}
 void* joint=(void*)(uintptr_t)word(t,0xd8);if(!memory(joint,0xa4,true)){original(self);return;}
 void* gun=lookup(base+0x2b98490,word(t,0xe8));if(!memory(gun,0x80)||*((unsigned char*)gun+0x7e)!=1||*((unsigned char*)gun+0x7f)!=7){original(self);return;}
 vrarm::Pose root{};memcpy(&root.p,t+4,12);memcpy(&root.b,t+0x10,36);vrarm::V gunPivot{};memcpy(&gunPivot,(char*)gun+4,12);vrarm::V trackedBody{};bool haveBody=RFGRVR_Arms_TurretBody(&trackedBody.x);vrarm::V body{};memcpy(&body,(char*)p+4,12);
 float bounds[4]{};memcpy(bounds,t+0xf0,16);for(float v:bounds)if(!std::isfinite(v)){original(self);return;}
 vrarm::V axisCenter{};if(word(p,0x2f4)==8&&rotationPivot(joint,axisCenter)){root.p.x=axisCenter.x;root.p.z=axisCenter.z;}
 float measuredLever=RFGRVR_Arms_TurretGripLever(word(t,0xe8))/RFGRVR_HeadCam_WorldScale();
 auto now=GetTickCount64();AcquireSRWLockExclusive(&lock);float dt=tick?float(now-tick)/1000.f:0;tick=now;
 // Capture the fulcrum in the fixed mount frame. Gun recoil/elevation
 // must never drag the player's body or camera around.
 if(!rig.ready||rig.identity!=word(p,0xa08))pivotLocal=vrarm::local(root.b,vrarm::sub(gunPivot,root.p));
 if(word(p,0x2f4)!=8)root.p=vrarm::add(root.p,vrarm::world(root.b,pivotLocal));
 float yawMargin=fabsf(bounds[0]-bounds[1])>=6.2f?1.f:.95f;
 float zero[3]{};bool haveZero=RFGRVR_Arms_TurretHandZero(zero);if(haveZero&&rig.ready)rig.origin={zero[0],zero[1],zero[2]};if(rig.ready)rig.roomYaw=atan2f(aim[0],aim[2]);
 bool ok=rig.update(word(p,0xa08),root,body,{hand[0],hand[1],hand[2]},atan2f(aim[0],aim[2]),RFGRVR_HeadCam_WorldScale(),now-stickTick.load()<250?stick.load():0,dt,bounds[1]*yawMargin,bounds[0]*yawMargin,bounds[3]*.95f,bounds[2]*.95f,haveBody?&trackedBody:nullptr,word(p,0x2f4)==8,*(float*)((char*)joint+0xa0),*(float*)((char*)joint+0x98),measuredLever,standingVehicleMount(self));

 if(ok&&rig.vehicle){vrarm::M measured{};if(assemblyBasis(joint,measured)){rig.body.b=measured;if(rig.standingVehicle){vrarm::M entry=vrarm::turnAround(vrarm::M{{1,0,0},{0,1,0},{0,0,1}},{0,1,0},rig.entryYaw);rig.body.p=vrarm::add(root.p,vrarm::world(measured,vrarm::local(entry,rig.seatLocal)));}}}
 vrarm::V handleTarget{},handleLocal{};if(ok&&RFGRVR_Arms_TurretHandleTarget(&handleTarget.x,&handleLocal.x)){vrarm::Pose fulcrum=root;fulcrum.p=rig.vehicle?vrarm::add(root.p,vrarm::world(root.b,pivotLocal)):root.p;if(rig.vehicle){fulcrum.b=rig.body.b;float coarseTarget=rig.entryYaw+rig.orbit;if(rig.aimFromSeat(fulcrum,handleLocal,{hand[0],hand[1],hand[2]},rig.origin,atan2f(aim[0],aim[2]),RFGRVR_HeadCam_WorldScale(),bounds[3]*.95f,bounds[2]*.95f))rig.gunYaw=coarseTarget+rig.gunYaw;}else rig.aimAtHandle(fulcrum,handleLocal,handleTarget,bounds[1]*yawMargin,bounds[0]*yawMargin,bounds[3]*.95f,bounds[2]*.95f);}

 float yaw=rig.gunYaw,pitch=rig.gunPitch,coarse=rig.entryYaw+rig.orbit;bool seated=rig.vehicle;if(ok)fresh=now;ReleaseSRWLockExclusive(&lock);if(!ok){original(self);return;}
 if(seated){float fine=std::remainder(yaw-coarse,6.28318530718f);gunSwivel.apply(joint,fine,dt);yaw=coarse;}else gunSwivel.restore();
 // Native target layout: pitch +98, yaw +9C, yaw position-motor target +A0.
 // Skip third-person tracking/body-follow and its acceleration input writers.
 memcpy((char*)joint+0x98,&pitch,4);memcpy((char*)joint+0x9c,&yaw,4);memcpy((char*)joint+0xa0,&yaw,4);wakeBodies(joint);motor(joint,false,false);
}
// Native onUpdate is conditional (including firing). It no longer owns the
// VR cadence. PlayerFrame calls step once every mounted player frame instead.
inline void __fastcall onUpdate(void* self,void*){if(!owned(self)&&!RFGRVR_DriverTurretOwned(self))original(self);}
inline void step(void* p){if(!base||!lookup||p!=player())return;void* turret=lookup(base+0x2b98490,word(p,0xa08));if(owned(turret))apply(turret);}
inline void unmount(){gunSwivel.restore();AcquireSRWLockExclusive(&lock);rig.reset();seatAssemblyId=~0u;tick=fresh=0;ReleaseSRWLockExclusive(&lock);}
inline bool body(void* p,vrarm::Pose& result){if(!memory(p,0xa0c))return false;AcquireSRWLockShared(&lock);bool ok=rig.ready&&rig.identity==word(p,0xa08)&&GetTickCount64()-fresh<200;if(ok)result=rig.body;ReleaseSRWLockShared(&lock);return ok;}
inline bool install(unsigned char* b){
 const unsigned char updateSig[]={0x81,0xec,0xb8,0,0,0,0x56,0x8b,0xf1};const unsigned char in0[]={0x8b,0x44,0x24,0x10,0x83,0xec,0x0c};const unsigned char in1[]={0x8d,0x44,0x24,0x0c,0x50};const unsigned char motorSig[]={0x80,0x7c,0x24,0x08,0,0x53,0x56,0x57};
 const unsigned char wakeSig[]={0x8b,0x41,0x08,0x83,0xec,0x08,0x85,0xc0};
 const unsigned char syncSig[]={0x83,0xec,0x34,0x56,0x68};
 if(memcmp(b+0x6216c0,syncSig,sizeof(syncSig))||memcmp(b+0x9dd7d0,wakeSig,sizeof(wakeSig))||memcmp(b+0x642040,updateSig,sizeof(updateSig))||memcmp(b+0x643150,in0,sizeof(in0))||memcmp(b+0x643560,in1,sizeof(in1))||memcmp(b+0x621940,motorSig,sizeof(motorSig)))return false;
 struct Hook{unsigned rva;void* detour;void** prior;};Hook hooks[]={{0x642040,(void*)onUpdate,(void**)&original},{0x643150,(void*)onInput0,(void**)&input[0]},{0x643560,(void*)onInput1,(void**)&input[1]},{0x6216c0,(void*)onJointSync,(void**)&originalJointSync}};
 unsigned created=0;for(auto& h:hooks){if(MH_CreateHook(b+h.rva,h.detour,h.prior)!=MH_OK){for(unsigned i=0;i<created;++i)MH_RemoveHook(b+hooks[i].rva);return false;}++created;}
 base=b;lookup=(Lookup)(b+0x53c050);motor=(Motor)(b+0x621940);wake=(Wake)(b+0x9dd7d0);for(auto& h:hooks)if(MH_EnableHook(b+h.rva)!=MH_OK){for(auto& undo:hooks){MH_DisableHook(b+undo.rva);MH_RemoveHook(b+undo.rva);}base=nullptr;return false;}return true;
}
}
extern "C" void RFGRVR_TurretStick(float value){RFGRVRNativeTurret::stick=std::isfinite(value)?value:0;RFGRVRNativeTurret::stickTick=GetTickCount64();}
