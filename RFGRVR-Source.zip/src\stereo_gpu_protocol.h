#pragma once
#include <windows.h>
#include <cstdint>
// Distinct-eye D3D11 keyed-mutex shared textures, independently produced by
// an RFGR scene renderer hook. Two different handles are mandatory.
// Producer per-eye contract: acquire key 0, render, Flush, release key 1,
// increment eyeFrames[eye]. The 64-bit XR bridge acquires key 1, copies,
// Flush, releases key 0. Do not publish a mono back-buffer twice.
static constexpr wchar_t RFGR_STEREO_GPU_MAP[] = L"Local\\RFGRVR_StereoGPU_Shared_v4";
static constexpr uint32_t RFGR_STEREO_GPU_MAGIC=0x52565332; // RVS2
struct alignas(8) RFGRStereoGpuShared {
 uint32_t magic;
 uint32_t version;
 volatile LONG ready;
 uint32_t width;
 uint32_t height;
 uint32_t format;
 uint64_t eyeHandle[2];
 volatile LONG eyeFrames[2];
 volatile LONG eyeAcknowledged[2];
 volatile LONG pairSequence;
 uint32_t renderMode; // 0 legacy, 1 exact native pair, 2 measured temporal, 3 measured native pair
 uint64_t sceneFrame;
 int64_t predictedTime;
 float eyePosition[2][3];
 float eyeOrientation[2][4];
 float eyeFov[2][4];
 uint32_t ownerPid,generation; // new texture set, even if frame counters/handles repeat
 float sourceProjection[2][4]; // m00, m11, m20, m21 used for this eye image
};
static_assert(sizeof(RFGRStereoGpuShared)==208,"Stereo GPU protocol ABI mismatch");
