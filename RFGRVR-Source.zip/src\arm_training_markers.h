#pragma once
#include "vr_mapping.h"
#include "vr_arm_math.h"
#include <atomic>
#include <windows.h>
namespace vrtraining {
#ifdef RFGR_TEST_ARM_TRAINING
inline constexpr wchar_t channelName[]=L"Local\\RFGRVR_TEST_ArmTraining_v1";
#else
inline constexpr wchar_t channelName[]=L"Local\\RFGRVR_ArmTraining_v1";
#endif
inline std::atomic<bool> active{false};
inline std::atomic<unsigned> request{0};
struct Markers {LONG sequence=0;unsigned magic=0x41524d31,tick=0,pid=0,phase=0,count=0;float points[16][3]{};unsigned state[16]{};};
inline void publish(const Markers& packet){static HANDLE mapping=nullptr;static Markers* data=nullptr;if(!data){if(!mapping)mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Markers),channelName);if(mapping)data=(Markers*)RFGRVR_MapViewOrClose(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Markers));}if(!data)return;InterlockedIncrement(&data->sequence);MemoryBarrier();memcpy((char*)data+4,(const char*)&packet+4,sizeof(packet)-4);MemoryBarrier();InterlockedIncrement(&data->sequence);}
struct Reader {HANDLE mapping=nullptr;const Markers* data=nullptr;~Reader(){if(data)UnmapViewOfFile(data);if(mapping)CloseHandle(mapping);}bool read(unsigned pid,Markers& packet){if(!data){if(!mapping)mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,channelName);if(mapping)data=(const Markers*)RFGRVR_MapViewOrClose(mapping,FILE_MAP_READ,0,0,sizeof(Markers));}if(!data)return false;for(int i=0;i<3;++i){LONG n=data->sequence;if(n&1)continue;MemoryBarrier();packet=*data;MemoryBarrier();if(n==data->sequence)return packet.magic==0x41524d31&&packet.pid==pid&&packet.phase&&packet.count<=16&&DWORD(GetTickCount()-packet.tick)<250;}return false;}};
}
