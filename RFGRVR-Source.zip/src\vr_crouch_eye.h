#pragma once
#include <cmath>
struct RFGRVRCrouchEye {
 float weight=0,standingTime=0;
 float update(bool allowed,bool crouched,float eyeDifference,float dt){
  if(!allowed){weight=standingTime=0;return 0;}
  if(!std::isfinite(dt)||dt<0)dt=0;if(dt>.05f)dt=.05f;
  if(crouched){weight=1;standingTime=0;return weight;}
  if(weight<=0)return 0;standingTime+=dt;
  // Stance flags may clear before the stand-up skeleton finishes blending.
  if(standingTime<.25f||(std::isfinite(eyeDifference)&&fabsf(eyeDifference)>.04f&&standingTime<.8f))return weight;
  weight-=dt/.2f;if(weight<0)weight=0;return weight;
 }
};
