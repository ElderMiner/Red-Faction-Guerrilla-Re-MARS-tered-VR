#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
// A successful open with a failed view must not leak or pin an obsolete mapping.
inline void* RFGRVR_MapViewOrClose(HANDLE& mapping,DWORD access,DWORD high,DWORD low,SIZE_T bytes){void* view=MapViewOfFile(mapping,access,high,low,bytes);if(!view&&mapping){CloseHandle(mapping);mapping=nullptr;}return view;}

