#define RFGR_WRIST_STATUS_TEST
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "../src/native_weapon_physics.h"
#include "../src/propane_markers.h"
#include <cassert>
using namespace RFGRVRWeaponPhysics;
static unsigned char object[0x300]{},definition[0x200]{},physics[0x300]{};static void* vt[20]{};static unsigned creates=0,erases=0,moves=0,velocities=0,spins=0;static V velocity{},angular{};
static void __fastcall moveItem(void*,void*,const V* p,const M* b,bool){memcpy(object+4,p,12);memcpy(object+0x10,b,36);++moves;}
static void* __fastcall descriptor(void* data,void*,void* info,const V* p,const M* b,unsigned*,unsigned,float,unsigned){assert(info==definition);memcpy(data,p,12);memcpy((char*)data+12,b,36);return data;}
static void __fastcall descFree(void*,void*){}
static void* __fastcall create(void*,void*,void*,void* data,bool,unsigned){memset(object,0,sizeof(object));*(void***)object=vt;memcpy(object+4,data,12);memcpy(object+0x10,(char*)data+12,36);*(unsigned*)(object+0x6c)=123;*(unsigned*)(object+0x70)=~0u;object[0x7e]=1;*(void**)(object+0xa4)=definition;*(unsigned*)(object+0x4c)=4;++creates;return object;}
static void __fastcall erase(void*,void*,void* o,bool){assert(o==object);*(unsigned*)(object+0x6c)=~0u;++erases;}
static void* __cdecl lookupInfo(const char* name){assert(!strcmp(name,"propane_tank"));return definition;}
static void __cdecl movableBody(unsigned id,bool yes){assert(id==4&&yes);}
static void __cdecl velocityBody(unsigned id,const V* v){assert(id==4&&finite(*v));velocity=*v;++velocities;}
static void __cdecl spinBody(unsigned id,const V* v){assert(id==4&&finite(*v));angular=*v;++spins;}
static void* __fastcall resolve(void*,void*,unsigned id){return id==123?object:nullptr;}
static bool __cdecl query(SweepRequest* r,void* out){static unsigned char hit[0x38]{};auto* h=(HitArray*)out;h->data=hit;h->count=1;*(unsigned*)(hit+0x28)=123;assert(r->filter&&r->radius>0);return true;}
static void __fastcall freeQuery(void*,void*){}
static unsigned pairCalls=0,filterCalls=0;
static unsigned char* __fastcall nativePair(void*,void*,unsigned char* out,const void*,const void*){++pairCalls;*out=1;return out;}
static bool __cdecl nativeFilter(void* object,void* context){assert(context==(void*)77);++filterCalls;return object!=definition;}
static bool __cdecl movementQuery(SweepRequest* r,void*){using Filter=bool(__cdecl*)(void*,void*);return !r->filter||((Filter)r->filter)(object,r->context);}
int main(){M identity{{1,0,0},{0,1,0},{0,0,1}};Pose zero{identity,{0,0,0}};
 vrprop::Grips g;Pose grip{turnAround(identity,{0,0,1},.6f),{.1f,.3f,0}};assert(g.add(grip)&&g.count==1);Pose targetHand{turnAround(identity,{0,1,0},.4f),{1,2,3}};Pose item=vrprop::inverseGrip(targetHand,grip);assert(length(sub(add(item.p,world(item.b,grip.p)),targetHand.p))<.00001f);assert(length(sub(compose(item.b,grip.b).r,targetHand.b.r))<.00001f);assert(g.nearest(item,targetHand.p,.1f)==0);assert(g.nearest(item,{9,9,9},.1f)==-1);
 Pose reversed=targetHand;reversed.b=turnAround(targetHand.b,item.b.u,3.141592654f);Pose smart=g.smart(0,item,reversed);assert(dot(compose(item.b,smart.b).r,reversed.b.r)>.999f);assert(g.add({identity,{.5f,0,0}})&&g.add({identity,{-.5f,0,0}})&&!g.add({identity,{0,-1.5f,0}}));
 assert(g.set(0,{identity,{0,-.9f,0}})&&g.set(1,{identity,{0,.9f,0}})&&g.count==3);assert(g.pose[0].p.y==-.9f&&g.pose[1].p.y==.9f);
 RFGRPropMarkers markers;markers.tick=GetTickCount();markers.count=3;markers.selected=2;markers.point[0][0]=1;markers.point[1][1]=2;markers.point[2][2]=3;RFGRVR_PublishPropMarkers(markers);RFGRPropMarkersReader reader;RFGRPropMarkers copy;assert(reader.read(copy)&&copy.count==3&&copy.selected==2&&!memcmp(copy.point,markers.point,sizeof(copy.point)));markers.count=0;RFGRVR_PublishPropMarkers(markers);assert(reader.read(copy)&&copy.count==0);
 vrprop::Grips aimed;aimed.add({identity,{-.12f,0,.2f}});aimed.add({identity,{.12f,0,.2f}});assert(aimed.aimed(zero,zero,{1,0,1},.55f)==1&&aimed.aimed(zero,zero,{-1,0,1},.55f)==0);
 vrprop::Motor single,two;Pose goal=zero;goal.p={1,1,0};assert(!single.step(zero,goal,1,1,100));assert(!two.step(zero,goal,2,1,100));assert(single.step(zero,goal,1,1,110)&&two.step(zero,goal,2,1,110));assert(length(single.velocity)<length(two.velocity)&&single.velocity.y<single.velocity.x);assert(!single.step(zero,goal,1,1,110));goal.p.x=4;assert(!single.step(zero,goal,1,1,120));
 base=(unsigned char*)VirtualAlloc(nullptr,0x3400000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);assert(base);*(void**)(base+0x2c6654c)=(void*)1;*(void**)(base+0x236e980+4*4)=physics;*(const char**)definition="propane_tank";vt[12]=(void*)moveItem;
 Reload::descriptor=(Reload::Descriptor)descriptor;Reload::descriptorFree=(Reload::DescriptorFree)descFree;Reload::create=(Reload::RegistryCreate)create;Reload::destroy=(Reload::RegistryDelete)erase;Reload::itemLookup=lookupInfo;movable=movableBody;linearVelocity=velocityBody;spin=spinBody;resolveObject=(ResolveObject)resolve;worldQuery=query;freeHits=(FreeHits)freeQuery;
 char cwd[MAX_PATH];GetCurrentDirectoryA(MAX_PATH,cwd);sprintf_s(Propane::profileOverride,"%s\\vr-research\\project\\build-check\\propane-test-%lu.ini",cwd,GetCurrentProcessId());DeleteFileA(Propane::profileOverride);
 Target t{};t.motion.body=zero;t.motion.scale=1;t.motion.tracked=true;t.motion.sample=1;t.motion.seconds=1;t.handle=555;t.hand[0]={identity,{0,1.3f,.7f}};t.hand[1]={identity,{.2f,1.3f,.7f}};
 Propane::captureRequest=true;Propane::update(t,true);assert(creates==1&&Reload::validObject(Propane::preview)&&Propane::editing&&RFGRVRWeaponInput::carrying());Pose preview=Propane::pose(Propane::preview);t.hand[0].b=turnAround(identity,{1,0,0},.7f);t.squeeze[0]=1;Propane::update(t,true);assert(Propane::grips.count==1);Pose saved=Propane::grips.pose[0];assert(length(sub(saved.b.u,t.hand[0].b.u))<.00001f);Propane::grips={};assert(Propane::profile(false)&&Propane::grips.count==1);assert(length(sub(Propane::grips.pose[0].b.u,saved.b.u))<.00001f);
 t.squeeze[0]=0;Propane::update(t,true);Propane::captureRequest=true;Propane::update(t,true);assert(erases==1&&!Reload::validObject(Propane::preview));
 auto loose=Reload::spawn(definition,zero,true);assert(Propane::tank(loose.ptr));*(unsigned*)(object+0x70)=900;assert(Propane::tank(loose.ptr));*(unsigned*)(object+0x48)=1;assert(!Propane::tank(loose.ptr));*(unsigned*)(object+0x48)=0;*(unsigned*)(object+0x70)=~0u;Propane::lastSearch=0;t.hand[0]={identity,{0,.32f,0}};t.hand[1]={identity,{0,.32f,0}};t.occupiedMask=2;Propane::update(t,true);Propane::Visual out;assert(Propane::readVisual(out)&&out.markerValid&&out.nearHand==0);
 t.squeeze[0]=1;Propane::update(t,true);assert(Propane::heldMask==1&&RFGRVRWeaponInput::carrying());unsigned char weapon[0x104]{};*(unsigned*)(weapon+0x6c)=555;assert(Propane::hidden(weapon));RFGRGamepad pad{};pad.rightTrigger=pad.leftTrigger=255;pad.buttons=0x4200;RFGRVRWeaponInput::filter(pad);assert(!pad.rightTrigger&&!pad.leftTrigger&&!pad.buttons);
 // Second hand may join after the first pickup stows the weapon.
 t.squeeze[1]=1;Propane::update(t,true);assert(Propane::heldMask==3);t.squeeze[0]=0;Propane::update(t,true);assert(Propane::heldMask==2);t.squeeze[1]=0;Propane::update(t,true);assert(!Propane::heldMask&&!RFGRVRWeaponInput::carrying()&&!Propane::hidden(weapon)&&velocities>0&&spins>0);
 t.squeeze[0]=0;Propane::update(t,true);t.squeeze[0]=1;Propane::update(t,true);assert(Propane::heldMask==1);
 // Release follows tracked grip motion, including the center's lever arc,
 // rather than the low-speed heavy motor. No double angular contribution.
 t.motion.sample=10;t.motion.seconds=2;Propane::sampleRelease(t);t.motion.sample=11;t.motion.seconds=2.02;t.hand[0].p.x+=.1f;Propane::sampleRelease(t);Propane::releaseHand=0;Propane::motor.velocity={.1f,0,0};Propane::release(t,true);assert(velocity.x>5.f&&velocity.x<6.f);
 // A 90-cm reach now acquires the same saved grip without touching the tank.
 t.occupiedMask=3;t.squeeze[0]=0;t.hand[0]={identity,{.9f,.32f,0}};Propane::lastSearch=0;Propane::update(t,true);t.squeeze[0]=1;Propane::update(t,true);assert(Propane::heldMask==1);
 unsigned char player[0x100]{},playerBody[0x100]{},npcBody[0x100]{},properties[16]{};t.player=player;t.playerHandle=321;*(unsigned*)(player+0x4c)=5;*(void**)(base+0x236e980+5*4)=playerBody;playerBody[0x20]=npcBody[0x20]=(unsigned char)-16;*(void**)(playerBody+0x7c)=properties;*(unsigned*)(playerBody+0x80)=1;*(unsigned*)(properties+8)=(unsigned)(uintptr_t)player;*(unsigned*)(npcBody+0xc)=999;
 PropaneCollision::publish(t,object);PropaneCollision::originalPair=(PropaneCollision::Pair)nativePair;unsigned char enabled=1;
 assert(PropaneCollision::pair(nullptr,nullptr,&enabled,physics+0x10,playerBody+0x10)==&enabled&&!enabled&&!pairCalls);
 PropaneCollision::pair(nullptr,nullptr,&enabled,npcBody+0x10,physics+0x10);assert(enabled&&pairCalls==1);
 SweepRequest request{};request.filter=(void*)nativeFilter;request.context=(void*)77;PropaneCollision::originalQuery=movementQuery;
 assert(PropaneCollision::query(&request,nullptr));{PropaneCollision::PlayerScope scope(player);assert(!PropaneCollision::query(&request,nullptr));assert(request.context==(void*)77&&request.filter==(void*)nativeFilter);}
 PropaneCollision::QueryContext context{&request,(uintptr_t)object,123};assert(!PropaneCollision::filter(definition,&context)&&filterCalls==2);
 // Loose propane cannot receive a kick from the local player, but NPC/world
 // contacts remain forwarded even while no tank is held.
 unsigned char tankProperties[16]{};*(void**)(physics+0x7c)=tankProperties;*(unsigned*)(physics+0x80)=1;*(unsigned*)(tankProperties+8)=(unsigned)(uintptr_t)object;physics[0x20]=(unsigned char)-16;
 PropaneCollision::clear();PropaneCollision::localPlayer=(uintptr_t)player;assert(PropaneCollision::excluded(playerBody+0x10,physics+0x10));assert(!PropaneCollision::excluded(npcBody+0x10,physics+0x10));
 // Registry discovery must find tanks when physics queries return no hits.
 Propane::release(t,false);auto queryBefore=worldQuery;worldQuery=nullptr;unsigned char registryNode[16]{};unsigned registryBuckets[1]={(unsigned)(uintptr_t)registryNode};*(void**)registryNode=object;*(unsigned*)(registryNode+12)=123;*(void**)(base+0x2b98950)=registryBuckets;*(unsigned*)(base+0x2b98954)=1;Propane::discoveryTick=0;Propane::discoveryCursor=0;memset(Propane::discovered,0,sizeof(Propane::discovered));t.squeeze[0]=0;Propane::update(t,true);t.squeeze[0]=1;Propane::update(t,true);assert(Propane::heldMask==1);worldQuery=queryBefore;
 // Reproduce the actual regression: the player movement scope must NOT
 // suppress tanks from a nested pickup-discovery query.
 {PropaneCollision::PlayerScope scope(player);SweepRequest pickup{};pickup.filter=(void*)Propane::filter;
  assert(!PropaneCollision::query(&pickup,nullptr));
  {PropaneCollision::DiscoveryScope discovery;assert(PropaneCollision::query(&pickup,nullptr));}
  assert(!PropaneCollision::query(&pickup,nullptr));
 }
 Propane::update(t,false);assert(!Propane::heldMask&&!RFGRVRWeaponInput::carrying()&&!PropaneCollision::tankCollider.load());assert(!Propane::readVisual(out));DeleteFileA(Propane::profileOverride);VirtualFree(base,0,MEM_RELEASE);puts("PASS: propane grip persistence, longer reach, weighted motor, tracked throws, carrier-only collisions, query forwarding, stow/support/release and pause cleanup");
}


