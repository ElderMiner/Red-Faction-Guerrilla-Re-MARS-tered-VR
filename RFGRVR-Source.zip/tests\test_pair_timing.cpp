#include "../src/vr_pair_timing.h"
#include <cassert>
int main(){
 Microsoft::WRL::ComPtr<ID3D11Device> device;Microsoft::WRL::ComPtr<ID3D11DeviceContext> ctx;
 assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,device.GetAddressOf(),nullptr,ctx.GetAddressOf())));
 RFGRVRPairTiming timing;
 for(int n=0;n<16;++n)timing.begin(device.Get(),ctx.Get());assert(timing.active>=0);
 timing.eye(ctx.Get(),0);timing.end(ctx.Get(),false); // failed pair closes all queries
 for(int n=0;n<16;++n)timing.begin(device.Get(),ctx.Get());assert(timing.active>=0);
 timing.eye(ctx.Get(),0);timing.eye(ctx.Get(),1);timing.end(ctx.Get(),true);
 // Only the TEST explicitly flushes. Production poll must never submit/wait.
 ctx->Flush();auto deadline=GetTickCount64()+5000;
 while(timing.samples<1&&GetTickCount64()<deadline){timing.poll(ctx.Get());Sleep(1);}
 assert(timing.samples==1&&timing.active==-1);assert(timing.leftMs>=0&&timing.rightMs>=0);
 assert(device->GetDeviceRemovedReason()==S_OK);timing.reset();assert(!timing.slots[0].disjoint&&timing.samples==0);
}
