#include <optional>
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "vr_frame_clock.h"
#include "vr_memory_access.h"
#include "vr_user_settings.h"
#include "vr_sun_glare.h"
extern "C" void RFGRVR_Arms_BodyGeometryBegin();
extern "C" void RFGRVR_Arms_BodyGeometryEnd();
struct LocalBodyScope {LocalBodyScope(){RFGRVR_Arms_BodyGeometryBegin();}~LocalBodyScope(){RFGRVR_Arms_BodyGeometryEnd();}};
extern "C" void RFGRVR_Temporal_Recenter();
// Experimental same-simulation-frame rendering at the verified public renderer wrapper.
// Never reenters Present and never retains a scene worker's stack parameters.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "vr_menu_world_scope.h"
#include "weapon_scope.h"
extern "C" bool RFGRVR_HeadCam_PopupMenu();
extern "C" bool RFGRVR_HeadCam_PauseMenu();
extern "C" bool RFGRVR_HeadCam_FirstPersonVehicle();
extern "C" bool RFGRVR_Scope_AuxView(unsigned,vrarm::Pose*);
static unsigned char* nativeScopeVision=nullptr;
// Outer rendering bakes native rail vision into scene+1B8 BEFORE eye rendering.
// Clearing only the global toggle leaves that prepared descriptor active.
struct NativeScopeWorldVision {unsigned char* flag=nullptr,*descriptor=nullptr;unsigned char saved=0,savedDescriptor=0;
 explicit NativeScopeWorldVision(void* scene=nullptr){if(nativeScopeVision&&vrscope::nativeVisualKind.load()==1){flag=nativeScopeVision;saved=*flag;*flag=0;if(scene){descriptor=(unsigned char*)scene+0x1b8;savedDescriptor=*descriptor;*descriptor=0;}}}
 ~NativeScopeWorldVision(){if(descriptor)*descriptor=savedDescriptor;if(flag)*flag=saved;}
};
static bool popupWorldMaskVerified=false;static unsigned char* popupGeometryCache=nullptr;
#include <d3d11.h>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <atomic>
#include "vr_renderer_cache.h"
#include "vr_sky_distance.h"
#include "vr_vehicle_bloom.h"
#include "native_night_lights.h"
#include "modern_lighting.h"
#include "modern_native_evidence.h"
#include "modern_shadow_capture.h"
#include "modern_runtime.h"
#include "modern_material_bindings.h"
#include "vr_orbital_billboard.h"
#include "vr_cone_trace.h"
#include "vr_human_visibility_trace.h"
extern "C" bool RFGRVR_HeadCam_Enabled();
extern "C" void RFGRVR_HeadCam_RenderFov(float);
#include "vr_batch_trace.h"
#include "vr_vertex_cursor.h"
#include "vr_effect_geometry.h"
#include "vr_effect_view_cache.h"
#include "vr_bloom_view_cache.h"
#include "wrist_map_trace.h"
#include "vr_hud_heading.h"
#include "native_apc_cameras.h"
#include "apc_render_targets.h"
extern "C" void RFGRVR_APC_AuxSet(const vrarm::Pose*);
extern "C" void RFGRVR_Scope_AuxSet(const vrarm::Pose*);
extern "C" bool RFGRVR_APC_AuxProjection(void*,float[16],float*);
extern "C" bool RFGRVR_APC_AuxCapture(unsigned);
extern "C" void RFGRVR_APC_Pipeline(bool);
extern "C" void RFGRVR_APC_BeforeResize();

#include "../vendor/MinHook.h"
#include "vr_native_dust.h"
extern "C" bool RFGRVR_NativePair_Begin();
extern "C" bool RFGRVR_NativePair_BuffersBusy();
extern "C" bool RFGRVR_RingPair_Install();
extern "C" void RFGRVR_RingPair_Begin();
extern "C" void RFGRVR_RingPair_End();
extern "C" bool RFGRVR_Temporal_OpticsFov(void*,float*);
extern "C" bool RFGRVR_RenderWindow_Requested(unsigned*,unsigned*);
extern "C" bool RFGRVR_Temporal_EyeProjection(void*,float[16],float*);
extern "C" void RFGRVR_Temporal_OpticsApplied(void*);
extern "C" bool RFGRVR_Temporal_HoldFov(void*,float,float);
extern "C" void RFGRVR_NativePair_Select(unsigned);
extern "C" bool RFGRVR_NativePair_Capture(unsigned);
extern "C" void RFGRVR_NativePair_End(bool);
extern "C" bool RFGRVR_NativePair_Projection(void*,float[16],float*);
extern "C" bool RFGRVR_NativePair_CompatibilityFov(void*,float*);
extern "C" void RFGRVR_NativePair_CompatibilityApplied(void*);
extern "C" void RFGRVR_NativePair_ProjectionApplied();
extern "C" unsigned RFGRVR_HeadCam_HeadSamples();
extern "C" void RFGRVR_Arms_RenderWeapon(void*);
extern "C" unsigned long long RFGRVR_GPU_DrawCount();
extern "C" void RFGRVR_GPUCapture_Mark(unsigned,void*,void*);
extern "C" void RFGRVR_PairGpuMarker(const wchar_t*,bool);
extern "C" bool RFGRVR_HeadCam_Recent();
extern "C" bool RFGRVR_HeadCam_MenuScene();
extern "C" void RFGRVR_PixelProbe_Begin();
extern "C" void RFGRVR_PixelProbe_Select(unsigned);
extern "C" void RFGRVR_PixelProbe_End();
extern "C" void RFGRVR_NativePair_SetRequested(bool);
extern "C" void RFGRVR_NativePair_TestMode(unsigned,unsigned);
extern "C" void RFGRVR_NativePair_Continuous(bool);
extern "C" void RFGRVR_NativePair_DiagnosticEnd();
extern "C" bool RFGRVR_EyeResources_Begin(unsigned);
extern "C" bool RFGRVR_EyeResources_Between(unsigned);
extern "C" unsigned RFGRVR_EyeResources_Count();
extern "C" void RFGRVR_EyeResources_End();
extern "C" bool RFGRVR_EyePipeline_Begin();
extern "C" void RFGRVR_EyePipeline_Between(unsigned);
extern "C" void RFGRVR_EyePipeline_End();
namespace {
using SwitchResolution=bool(__cdecl*)(void*,void*,unsigned,unsigned,unsigned,unsigned,unsigned);
using ResizeRenderBuffers=bool(__cdecl*)(void*,unsigned,unsigned);
SwitchResolution switchResolution=nullptr;ResizeRenderBuffers resizeRenderBuffers=nullptr;
std::atomic<void*> renderBufferWindow{nullptr};std::atomic<DWORD> renderBufferThread{0};
std::atomic<unsigned> renderBufferWidth{0},renderBufferHeight{0};
thread_local bool renderBufferResizing=false;
struct RenderResizeScope {RenderResizeScope(){renderBufferResizing=true;}~RenderResizeScope(){renderBufferResizing=false;}};
static bool __cdecl OnSwitchResolution(void* device,void* window,unsigned width,unsigned height,unsigned numerator,unsigned denominator,unsigned mode){
 unsigned w=0,h=0;
 if(mode==2&&RFGRVR_RenderWindow_Requested(&w,&h)){width=1280;height=720;}
 return switchResolution(device,window,width,height,numerator,denominator,mode);
}
static bool __cdecl OnResizeRenderBuffers(void* window,unsigned width,unsigned height){
 if(renderBufferResizing)return true;
 RenderResizeScope resizeScope;
 renderBufferThread.store(GetCurrentThreadId());renderBufferWindow.store(window,std::memory_order_release);
 unsigned w=0,h=0;
 // This engine routine rebuilds the swap-chain buffers, depth resources and
 // cached dimensions together. Its size is independent of the desktop client.
 if(width&&height&&RFGRVR_RenderWindow_Requested(&w,&h)){width=w;height=h;}
 // The engine also calls this as an unchanged-size ensure operation. Only
 // invalidate cached surfaces when dimensions change; HookResize still
 // releases window references immediately before every actual DXGI resize.
 if(width!=renderBufferWidth.load()||height!=renderBufferHeight.load())RFGRVR_APC_BeforeResize();
 bool ok=resizeRenderBuffers(window,width,height);
 if(ok){renderBufferWidth=width;renderBufferHeight=height;}return ok;
}
using Render=uintptr_t(__cdecl*)(void*,unsigned,void*);
using Prepare=void(__fastcall*)(void*,void*,void*);
using Update=void(__thiscall*)(void*);
using Initialize=void(__thiscall*)(void*,void*,unsigned,unsigned,const void*,void*,unsigned);
static void initializeEye(Initialize initialize,void* eye,void* renderer,unsigned width,unsigned height,const void* lod){initialize(eye,renderer,width,height,lod,nullptr,0);}
using Allocate=void*(__cdecl*)(unsigned);using Construct=void*(__thiscall*)(void*);
Allocate allocateEye=nullptr;Construct constructEye=nullptr;
using RingCapacity=void(__thiscall*)(void*,unsigned);RingCapacity ringCapacityOriginal=nullptr;using RingInitialize=void(__thiscall*)(void*);RingInitialize ringInitializeOriginal=nullptr;void* stereoRing=nullptr;
Initialize initializeOriginal=nullptr;using TerrainInitialize=void(__thiscall*)(void*);TerrainInitialize terrainInitializeOriginal=nullptr;
using SceneRender=void(__thiscall*)(void*,void*,void*,void*,void*,void*,void*);using CameraBegin=void(__thiscall*)(void*,void*);
static vrglare::Owned sunGlare;static unsigned char* sunGeneration=nullptr;
static float* nightClock=nullptr;
static float nativeNightHour(){float hour=NAN;if(nightClock&&RFGRVR_HeadCam_Enabled()&&!RFGRVR_HeadCam_MenuScene()&&vrmemory::check(nightClock,4))memcpy(&hour,nightClock,4);return hour;}
static void** sunObject=nullptr;using SunSprite=void(__thiscall*)(void*,void*,void*);static SunSprite sunSprite=nullptr;
using OrbitalDraw=void(__thiscall*)(void*,void*,void*,const void*);static OrbitalDraw orbitalDraw=nullptr;static std::atomic<unsigned> orbitalOrientationFixes{0};
using SkyRefresh=void(__cdecl*)();static SkyRefresh skyRefresh=nullptr;static std::atomic<unsigned> skyEyeRefreshes{0};
SceneRender sceneRender=nullptr;CameraBegin cameraBegin=nullptr;
Render render=nullptr;Prepare prepare=nullptr;Update updateMatrices=nullptr,updateRenderer=nullptr;
thread_local bool entered=false;
std::atomic<unsigned> pairs{0},failed{0},attempted{0};std::atomic<ULONGLONG> retryAfter{0};
// Live selection avoids a reinstall between controlled comparisons and stereo.
// 0 baseline once; 1 identical-view comparison; 2 resource-restored comparison;
// 3 continuous restored resources; 4 continuous unmodified scene resources.
unsigned testMode=0,restoreMask=~0u;
static bool continuousMode(unsigned mode){return mode==3||mode==4||mode==8||mode==9||mode==10||mode==13||mode==14||mode==15;}
static bool canAttemptPair(ULONGLONG now){return attempted.load()==0||(continuousMode(testMode)&&now>=retryAfter.load());}
static void pollTestMode(){
 static ULONGLONG next=0;auto now=GetTickCount64();if(now<next)return;next=now+500;
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-stereo-test.mode");
 FILE* f=nullptr;unsigned mode=0,mask=~0u;
 if(!_wfopen_s(&f,path,L"r")&&f){fscanf_s(f,"%u %x",&mode,&mask);fclose(f);}
 if(mode>15)mode=0;
 if(mode!=testMode||mask!=restoreMask){testMode=mode;restoreMask=mask;attempted=0;failed=0;retryAfter=0;RFGRVR_NativePair_Continuous(continuousMode(mode));}
}
struct EyeResources {void* scene=nullptr;void* original=nullptr;void* right=nullptr;unsigned width=0,height=0;} resources;
bool resourceFailed=false;bool reuseOriginalRenderer=true;
static bool memory(void* p,size_t n){
 if(!p||!n)return false;uintptr_t current=(uintptr_t)p;if(current+n<current)return false;const uintptr_t end=current+n;
 while(current<end){MEMORY_BASIC_INFORMATION m{};if(!VirtualQuery((void*)current,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;auto next=(uintptr_t)m.BaseAddress+m.RegionSize;if(next<=current)return false;current=next;}
 return true;
}
static unsigned word(void* p,size_t offset){unsigned v=0;if(memory((char*)p+offset,4))memcpy(&v,(char*)p+offset,4);return v;}
static void disposeResources(){
 if(resources.right&&resources.right!=resources.original){using Destroy=void(__thiscall*)(void*,unsigned);auto** table=*(void***)resources.right;
  ((Destroy)table[0])(resources.right,1);}
 resources={};
}
static void resourceReport(const char* stage,void* renderer,void* original,void* right){
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Eye-Resources.csv");FILE* f=nullptr;
 if(_wfopen_s(&f,path,L"a")||!f)return;
 if(_ftelli64(f)==0)fputs("stage,renderer,left,right,left_main,right_main,left_srgb,right_srgb,left_half,right_half\n",f);
 fprintf(f,"%s,%p,%p,%p,%08X,%08X,%08X,%08X,%08X,%08X\n",stage,renderer,original,right,word(original,0x220),word(right,0x220),word(original,0x25c),word(right,0x25c),word(original,0x234),word(right,0x234));fclose(f);
}
static bool requested();
static void __fastcall OnRingCapacity(void* self,void*,unsigned bytes){
 const bool expand=!reuseOriginalRenderer&&bytes==10u*1024*1024&&requested();
 ringCapacityOriginal(self,expand?40u*1024*1024:bytes);
 if(expand){stereoRing=self;resourceReport("stereo-ring-capacity-40MiB",self,nullptr,nullptr);}
}
static void __fastcall OnRingInitialize(void* self,void*){
 if(memory(self,0x28)&&!*((unsigned char*)self+0x1c))OnRingCapacity(self,nullptr,word(self,0x14));
 ringInitializeOriginal(self);
}
static bool createIndependentEye(void* original,void* context,unsigned width,unsigned height,const void* lod,void* commands,unsigned bytes){
 if(!allocateEye||!constructEye||!initializeOriginal||commands||bytes||!memory(context,8)||!memory((void*)lod,0x94)||width<640||height<360||width>8192||height>8192)return false;
 disposeResources();void* raw=allocateEye(0x4bbe8);if(!raw)return false;void* right=constructEye(raw);if(!memory(right,0x4bbe8))return false;
 *(unsigned*)((char*)right+4)=0xffffffffu;
 resourceReport("valid-context-initialize-begin",context,original,right);
 // The engine-supplied context and LOD are borrowed ONLY within this callback.
 initializeEye(initializeOriginal,right,context,width,height,lod);
 resources={nullptr,original,right,width,height};resourceReport("valid-context-initialize-end",context,original,right);
 if(!word(right,0x220)||word(right,0x220)==word(original,0x220)||word(right,0x1f8)!=width||word(right,0x1fc)!=height||!word(right,0x4bb24)||!word(right,0x4bb28)){disposeResources();return false;}
 return true;
}
static void __fastcall OnInitialize(void* self,void*,void* context,unsigned width,unsigned height,const void* lod,void* commands,unsigned bytes){
 // Observe the engine's own construction, without substituting arguments.
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');
 if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Scene-Initialization.csv");FILE* f=nullptr;
 if(!_wfopen_s(&f,path,L"a")&&f){
 if(!_ftelli64(f))fputs("scene,context,context_first,context_second,width,height,lod,commands,bytes,thread\n",f);
 fprintf(f,"%p,%p,%08X,%08X,%u,%u,%p,%p,%u,%lu\n",self,context,word(context,0),word(context,4),width,height,lod,commands,bytes,GetCurrentThreadId());fclose(f);}}
 initializeOriginal(self,context,width,height,lod,commands,bytes);
 if(requested()&&!reuseOriginalRenderer)resourceFailed=!createIndependentEye(self,context,width,height,lod,commands,bytes);
}
static void __fastcall OnTerrainInitialize(void* self,void*){
 terrainInitializeOriginal(self);
 if(reuseOriginalRenderer||!resources.right||!resources.original||self!=(void*)(uintptr_t)word(resources.original,0x1c))return;
 void* right=(void*)(uintptr_t)word(resources.right,0x1c);
 if(!memory(right,0x3d308)){resourceFailed=true;return;}
 resourceReport("terrain-initialize-begin",self,resources.original,resources.right);
 // Mirror the engine's terrain-world setup at the same lifecycle point.
 terrainInitializeOriginal(right);
 resourceReport("terrain-initialize-end",self,resources.original,resources.right);
 if(!memory((void*)(uintptr_t)word(right,0x3d2e4),0x704))resourceFailed=true;
}
static bool prepareResources(void* renderer){
 auto* base=(unsigned char*)GetModuleHandleW(nullptr);
 void* scene=(void*)(uintptr_t)word(base,0x2133894);
 void* original=(void*)(uintptr_t)word(scene,0x13c);
 if(!memory(original,0x4bbe8)||word(original,0)!=(unsigned)(uintptr_t)(base+0xec05a8))return false;
 const unsigned width=word(original,0x1f8),height=word(original,0x1fc);
 if(width<640||height<360||width>8192||height>8192)return false;
 if(reuseOriginalRenderer){
 if(resources.right&&resources.right!=resources.original)disposeResources();
 resources={scene,original,original,width,height};return true;
 }
 if(resourceFailed||!resources.right||resources.original!=original||resources.width!=width||resources.height!=height)return false;
 if(resources.scene&&resources.scene!=scene)return false;
 void* terrain=(void*)(uintptr_t)word(resources.right,0x1c);
 if(!memory(terrain,0x3d308)||!memory((void*)(uintptr_t)word(terrain,0x3d2e4),0x704))return false;
 resources.scene=scene;memcpy((char*)resources.right+0x18,&scene,4);
 // Construction must happen at the real initializer, never using the outer renderer.

 return true;
}
static bool requested(){
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return false;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-independent-stereo.enable");
 return GetFileAttributesW(path)!=INVALID_FILE_ATTRIBUTES;
}
static void report(unsigned long long left,unsigned long long right,unsigned before,unsigned after,bool ok){
 if(continuousMode(testMode)&&ok&&attempted.load()!=1&&attempted.load()%120)return;
 char effectSummary[160]{};sprintf_s(effectSummary,"RFGR effects: first=%u second=%u geometry_restores=%u\n",RFGRVREffectGeometry::calls[0].load(),RFGRVREffectGeometry::calls[1].load(),RFGRVREffectGeometry::restores.load());OutputDebugStringA(effectSummary);
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Native-Stereo.csv");FILE* f=nullptr;
 if(_wfopen_s(&f,path,L"a")||!f)return;
 if(_ftelli64(f)==0)fputs("attempt,pairs,failed,left_draws,right_draws,head_samples_before,head_samples_after,complete\n",f);
 fprintf(f,"%u,%u,%u,%llu,%llu,%u,%u,%u\n",attempted.load(),pairs.load(),failed.load(),left,right,before,after,ok?1:0);fclose(f);
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Effect-Cost.log");
 if(!_wfopen_s(&f,path,L"a")&&f){LARGE_INTEGER frequency{};QueryPerformanceFrequency(&frequency);double ms=1000.0/double(frequency.QuadPart);fprintf(f,"tick=%llu pair=%u sampledPrepareMs=%.4f sampledNativeEffectsMs=%.4f sampledViewFixMs=%.4f sampledNativeViewMs=%.4f probes=%u fullTables=%u used=%u first=%u second=%u restores=%u\n",GetTickCount64(),attempted.load(),RFGRVREffectGeometry::prepareTicks.exchange(0)*ms,RFGRVREffectGeometry::renderTicks.exchange(0)*ms,RFGRVREffectViewCache::prepareTicks.exchange(0)*ms,RFGRVREffectViewCache::renderTicks.exchange(0)*ms,RFGRVREffectGeometry::probeCount.exchange(0),RFGRVREffectGeometry::fullTables.exchange(0),RFGRVREffectGeometry::usedCount,RFGRVREffectGeometry::calls[0].load(),RFGRVREffectGeometry::calls[1].load(),RFGRVREffectGeometry::restores.load());fclose(f);}
}
static void pairStage(const char* phase,unsigned eye){
 if(continuousMode(testMode)&&attempted.load()!=1&&attempted.load()%120)return;
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Pair-Stages.log");FILE* file=nullptr;
 if(!_wfopen_s(&file,path,L"a")&&file){fprintf(file,"%llu pair=%u eye=%u phase=%s head=%u ring=%p capacity=%u write=%u read=%u pending=%u\n",GetTickCount64(),attempted.load(),eye,phase,RFGRVR_HeadCam_HeadSamples(),stereoRing,word(stereoRing,0x14),word(stereoRing,0x60),word(stereoRing,0x64),word(stereoRing,0x68));fflush(file);fclose(file);}
}
static void refreshEyeSky(void*,void* camera){
 if(!skyRefresh||!RFGRVR_HeadCam_Enabled())return;
 // Native sky setup reads the world time-of-day LIGHT. Retain its native pointer.
 skyRefresh();if(sunGlare.record&&memory(sunGlare.record,0x5c))sunGlare.apply(sunGlare.record,true);++skyEyeRefreshes;
}
static void __fastcall onOrbitalDraw(void* self,void*,void* renderer,void* camera,const void* orbital){
 // This verified native routine draws only queued celestial sprites. Feed
 // its right/up reads a private orientation; never edit the scene camera.
 if(RFGRVR_HeadCam_Enabled()&&memory(camera,0x38)&&memory(const_cast<void*>(orbital),0x28)){
  vrarm::V direction{};memcpy(&direction,(const char*)orbital+0x10,12);vrarm::M basis{};
  if(RFGRVR_OrbitalBillboard(direction,basis)){
   ++orbitalOrientationFixes;alignas(16) unsigned char imageCamera[0x38];memcpy(imageCamera,camera,sizeof(imageCamera));memcpy(imageCamera+8,&basis,36);orbitalDraw(self,renderer,imageCamera,orbital);return;
  }
 }
 orbitalDraw(self,renderer,camera,orbital);
}
static void __fastcall onSunSprite(void* self,void*,void* renderer,void* camera){
 // The verified sun sprite contains the oversized camera glare. Omit it in
 // VR instead of scaling an intensity the engine can rebuild each frame.
 if(RFGRVR_HeadCam_Enabled()&&vrvisual::enhanced()&&sunObject&&*sunObject==self)return;
 sunSprite(self,renderer,camera);
}
static void prepareEyeCameras(void* camera,void* renderer,void* secondary){
 cameraBegin(camera,renderer);
 // F3050 copies CPU shader constants, not the secondary state manager's
 // active camera, eye position, view matrix or derived view transforms.
 // Refresh those from the same eye before its lighting/material work.
 if(secondary!=renderer&&memory(secondary,0x480)&&memory((void*)(uintptr_t)word(secondary,0x478),0x580))cameraBegin(camera,secondary);
}
static void recordEyeCameras(unsigned eye,void* camera,void* renderer,void* secondary){
 if(attempted.load()!=1||!memory((char*)camera+0x2c,12))return;
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Eye-Camera-State.csv");
 FILE* file=nullptr;if(_wfopen_s(&file,path,eye?L"a":L"w")||!file)return;
 if(!eye)fputs("eye,renderer,active_camera,expected_camera,eye_x,eye_y,eye_z,shader_eye_x,shader_eye_y,shader_eye_z\n",file);
 void* renderers[2]={renderer,secondary};for(unsigned i=0;i<2;++i){auto* r=(unsigned char*)renderers[i];auto* state=(unsigned char*)(uintptr_t)word(r,0x478);
  if(!memory(r,0xf0)||!memory(state,0x90))continue;float position[3],shader[3];memcpy(position,state+0x74,12);memcpy(shader,r+0xe0,12);
  fprintf(file,"%u,%u,%08X,%p,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n",eye,i,word(state,0x70),camera,position[0],position[1],position[2],shader[0],shader[1],shader[2]);}
 fclose(file);
}
extern "C" bool RFGRVR_HeadCam_MapMenu();
static bool mapWorldGateVerified=false;
extern "C" void RFGRVR_FrameTiming_Outer(long long);
static uintptr_t __cdecl OnRender(void* renderer,unsigned scene,void* secondary){
 vrvehiclebloom::active.store(RFGRVR_HeadCam_FirstPersonVehicle(),std::memory_order_relaxed);
 vrsettings::publishNightHour(nativeNightHour(),GetCurrentProcessId(),GetTickCount());
 // Pace before doing render work. XR supplies one credit per runtime frame;
 // never skip/re-enter the native renderer or wait while holding eye mutexes.
 static vrframeclock::Reader frameClock;if(RFGRVR_HeadCam_Enabled()&&RFGRVR_HeadCam_Recent()&&continuousMode(testMode))frameClock.pace();

 // Native Map passes renderWorld=0. Enable geometry in this ORIGINAL
 // scheduled frame, before the command writer is released. Never render at Present.
 const bool mapWorld=mapWorldGateVerified&&RFGRVR_HeadCam_MapMenu()&&memory(renderer,0x444)&&word(renderer,0x440);if(mapWorld)scene=1;
 static ULONGLONG nextGlareCheck=0;auto* glareBase=(unsigned char*)GetModuleHandleW(nullptr);
 if(!RFGRVR_HeadCam_Enabled()||!vrvisual::enhanced()){sunGlare.apply(nullptr,false);}else if(GetTickCount64()>=nextGlareCheck){nextGlareCheck=GetTickCount64()+1000;unsigned count=word(glareBase,0x19ee498);if(count&&count<=64&&memory(glareBase+0x1a1a770,size_t(count)*0x5c))for(unsigned i=0;i<count;++i){auto* record=glareBase+0x1a1a770+i*0x5c;if(!memcmp(record,"SunGlare01\0",11)){sunGlare.apply(record,true);break;}}}

 // This wrapper contains frame work and must execute exactly once.
 LARGE_INTEGER start{},end{};QueryPerformanceCounter(&start);
 // Preserve native sun visibility/shaft generation. Glare is suppressed at
 // its dedicated sprite, lens and composite inputs instead.
 RFGRVR_GPUCapture_Mark(40,renderer,secondary);auto result=render(renderer,scene,secondary);RFGRVR_GPUCapture_Mark(41,renderer,secondary);
 modernaux::producer.markSubmitted();
 if(mapWorld){static DWORD reported=0;if(GetTickCount()-reported>1000){reported=GetTickCount();char file[MAX_PATH]{};GetModuleFileNameA(nullptr,file,MAX_PATH);if(auto* slash=strrchr(file,92)){strcpy_s(slash+1,MAX_PATH-(slash+1-file),"vr-research\\output\\map-world-state.json");FILE* out=nullptr;if(!fopen_s(&out,file,"w")&&out){fprintf(out,"{\"scheduledWorld\":true,\"liveWriter\":true,\"pairs\":%u}\n",pairs.load());fclose(out);}}}}
 QueryPerformanceCounter(&end);RFGRVR_FrameTiming_Outer(end.QuadPart-start.QuadPart);return result;
}
static void runScenePair(void* self,void* renderer,void* secondary,void* scene,void* camera,void* a5,void* a6){
 const auto nightSettings=vrsettings::get();modernlight::configure(nightSettings.value[vrsettings::Lighting]!=0);vrsettings::publishVisualMode(vrvisual::enhanced(),GetCurrentProcessId(),GetTickCount());const float hour=nativeNightHour();modernscene::Frame modernEnvironment(modernlight::transportEnabled(),hour);
 vrnight::Plan lightingPlan=vrvisual::enhanced()?vrsettings::nightPlan(nightSettings,hour):vrnight::Plan{};
 if(modernlight::transportEnabled()){lightingPlan={};lightingPlan.mainLight=modernEnvironment.value.main;lightingPlan.ambient=modernEnvironment.value.ambient;lightingPlan.bloom=modernEnvironment.value.bloom;}
 vrnight::Frame night(lightingPlan);
 static uint64_t modernLightFrame=0;if(modernlight::transportEnabled()){
 modernscene::collector.begin(++modernLightFrame);
 // Native constant uploads can be cached independently for either eye.
 // Seed the authoritative scene directional light every pair instead of
 // requiring an upload callback to happen before each HDR pass.
 void* source=vrnightlights::selected();if(memory(source,0x110)){
  float radiance[3];memcpy(radiance,(char*)source+0xcc,12);for(float& value:radiance)value*=lightingPlan.mainLight;
  vrnightlights::captureModern(source,radiance);
 }
 modernruntime::beginPair(renderer,self,modernLightFrame,hour,!RFGRVR_HeadCam_MenuScene()&&!RFGRVR_HeadCam_PopupMenu());
 }
 static unsigned busyFallbacks=0,otherFallbacks=0;static unsigned long long busyCpuTicks=0;static LARGE_INTEGER frequency{};
 if(!RFGRVR_NativePair_Begin()){
  const bool busy=RFGRVR_NativePair_BuffersBusy();LARGE_INTEGER begin{},end{};if(busy){++busyFallbacks;QueryPerformanceCounter(&begin);}else ++otherFallbacks;
  sceneRender(self,renderer,secondary,scene,camera,a5,a6);
  if(busy){QueryPerformanceCounter(&end);busyCpuTicks+=end.QuadPart-begin.QuadPart;}return;
 }
 RFGRVR_NativePair_TestMode(testMode,restoreMask);
 RFGRVRHumanVisibility::sample(0);
 RFGRVR_PixelProbe_Begin();
 entered=true;++attempted;unsigned before=RFGRVR_HeadCam_HeadSamples();unsigned long long draws[2]{};bool ok=true;
 if(attempted.load()%120==0){
  if(!frequency.QuadPart)QueryPerformanceFrequency(&frequency);wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');
  if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Stereo-Pacing.log");FILE* f=nullptr;if(!_wfopen_s(&f,path,L"a")&&f){fprintf(f,"tick=%llu pairs=%u busyFallbackScenes=%u otherFallbackScenes=%u busySceneCpuMs=%.3f\n",GetTickCount64(),pairs.load(),busyFallbacks,otherFallbacks,1000.0*busyCpuTicks/frequency.QuadPart);fclose(f);}}
 }
 if(attempted==1){char label[64]{};sprintf_s(label,"mode-%u-mask-%08X",testMode,restoreMask);pairStage(label,2);}
 const bool restoreResources=testMode==2||testMode==3||testMode==5||testMode==7||testMode==8||testMode==9||testMode==12||testMode==13;
 const bool restoreCache=testMode==6||testMode==7||testMode==8||testMode==10||testMode==12||testMode==13;
 const bool restorePipeline=testMode==11||testMode==12||testMode==13||testMode==14;
 RFGRVRRendererCache cache[2];
 if(restoreCache){if(!memory(renderer,0x448)||!memory(secondary,0x448))ok=false;else{cache[0].save(renderer);cache[1].save(secondary);}}
 if(restoreResources&&!RFGRVR_EyeResources_Begin(testMode==2||testMode==3?1:2))ok=false;
 if(restorePipeline&&!RFGRVR_EyePipeline_Begin())ok=false;
 for(unsigned eye=0;ok&&eye<2;++eye){
 if(eye){
  void* pools[2]={(void*)(uintptr_t)word(renderer,0x24),(void*)(uintptr_t)word(secondary,0x24)};
  for(auto* pool:pools)if(!memory(pool,16)||!RFGRVR_VertexPoolReady(pool)){ok=false;break;}
  if(!ok){pairStage("vertex-pool-not-ready",eye);break;}
  // The first scene already executed its command list. Reset allocation cursors
  // so the next list starts with WRITE_DISCARD, letting D3D rename the storage.
  for(auto* pool:pools)RFGRVR_VertexPoolRestart(pool);
 }
 if(eye&&restoreResources&&!RFGRVR_EyeResources_Between(restoreMask)){ok=false;break;}
 if(eye&&restorePipeline)RFGRVR_EyePipeline_Between(restoreMask);
 if(eye&&restoreCache){cache[0].restore(renderer,restoreMask);cache[1].restore(secondary,restoreMask);}
 // The paused-view cache must be disabled BEFORE camera preparation too.
 // Otherwise its shader/view constants still describe the frozen first view.
 NativeScopeWorldVision ordinaryVision(memory(scene,0x208)?scene:nullptr);
 RFGRVRMenuWorldScope menuWorld((uint32_t*)((char*)self+0x14),popupWorldMaskVerified&&RFGRVR_HeadCam_PopupMenu()&&memory((char*)self+0x14,4));
 RFGRVRMenuGeometryScope menuGeometry(popupGeometryCache,(uint32_t*)((char*)self+0x50),popupGeometryCache&&RFGRVR_HeadCam_PopupMenu()&&memory((char*)self+0x50,4));

 RFGRVR_NativePair_Select(eye);prepareEyeCameras(camera,renderer,secondary);vrconetrace::eye=int(eye);{auto* state=(char*)(uintptr_t)word(renderer,0x478);if(memory(state,0x80))memcpy(vrconetrace::expected[eye],state+0x74,12);}refreshEyeSky(scene,camera);LocalBodyScope localBodyGeometry;RFGRVR_Arms_RenderWeapon(renderer);recordEyeCameras(eye,camera,renderer,secondary);pairStage("scene-render-begin",eye);auto start=RFGRVR_GPU_DrawCount();
 RFGRVREffectGeometry::select(eye);
 if(modernlight::enabled())modernruntime::begin(self,renderer,vrconetrace::expected[eye],secondary,int(eye));
 RFGRVREffectViewCache::select(eye);
 RFGRVR_PixelProbe_Select(eye);
 RFGRVR_PairGpuMarker(eye?L"RFGR second scene pass":L"RFGR first scene pass",true);
 RFGRVR_GPUCapture_Mark(50+eye*2,renderer,self);
 // Paused rendering sets the geometry-skip bit again after the first pass.
 // Clear it separately for EACH eye, rather than only around the pair.
 {modernmaterial::Bindings primaryLighting,secondaryLighting;std::optional<modernmaterial::WorldScope> dynamicLighting;
  if(modernlight::transportEnabled()){auto* a=modernruntime::context(renderer);auto* b=modernruntime::context(secondary);auto* reflection=modernruntime::developmentGraph.reflectionResource();auto* brdf=modernruntime::developmentGraph.reflectionBRDFResource();modernmaterial::Frame frameA,frameB;bool validA=modernruntime::materialFrame(renderer,self,frameA),validB=modernruntime::materialFrame(secondary,self,frameB);auto* probes=modernruntime::developmentGraph.materialProbes();if(validA)dynamicLighting.emplace(frameA,reflection,brdf,probes,modernruntime::developmentGraph.skyResource());primaryLighting.bind(a,reflection,brdf,validA?&frameA:nullptr,validA?probes:nullptr,validA?modernruntime::developmentGraph.skyResource():nullptr);if(b!=a)secondaryLighting.bind(b,reflection,brdf,validB?&frameB:nullptr,validB?probes:nullptr,validB?modernruntime::developmentGraph.skyResource():nullptr);}
  sceneRender(self,renderer,secondary,scene,camera,a5,a6);}
 if(modernlight::enabled()){modernruntime::end();if(moderncatalog::enabled()&&attempted.load()%120==0)modernruntime::evidence();}
 vrconetrace::eye=-1;RFGRVRHumanVisibility::sample(eye+1);RFGRVREffectViewCache::select(-1);RFGRVREffectGeometry::eye=-1;RFGRVRBatchTrace::eye=-1;pairStage("scene-render-end",eye);draws[eye]=RFGRVR_GPU_DrawCount()-start;
 RFGRVR_PairGpuMarker(nullptr,false);
 RFGRVR_GPUCapture_Mark(51+eye*2,renderer,self);
 if(!draws[eye]||!RFGRVR_NativePair_Capture(eye)){ok=false;break;}
 }
 modernevidence::capture(self,renderer,scene,camera);
 // Bounded reduced-resolution feeds after both eyes: tanks prioritize gun view.
 vrarm::Pose auxiliary{};unsigned cameraIndex=0;
 bool apcPasses=false;{AcquireSRWLockShared(&RFGRVRAPC::lock);apcPasses=ok&&continuousMode(testMode)&&(RFGRVRAPC::packet.active&2);ReleaseSRWLockShared(&RFGRVRAPC::lock);}
 auto scopeFrame=vrscope::snapshot();bool scopePass=ok&&continuousMode(testMode)&&!apcPasses&&scopeFrame.alpha>.005f;
 RFGRVRRendererCache apcCache[2];if(apcPasses||scopePass){apcCache[0].save(renderer);apcCache[1].save(secondary);RFGRVR_APC_Pipeline(true);}
 for(unsigned feed=0;feed<(scopePass?2u:RFGRVRAPC::cameraBudget())&&ok&&continuousMode(testMode)&&(scopePass?(cameraIndex=feed,RFGRVR_Scope_AuxView(feed,&auxiliary)):RFGRVRAPC::next(auxiliary,cameraIndex,feed));++feed){
  void* pools[2]={(void*)(uintptr_t)word(renderer,0x24),(void*)(uintptr_t)word(secondary,0x24)};bool available=true;
  for(auto* pool:pools)available=available&&memory(pool,16)&&RFGRVR_VertexPoolReady(pool);
  if(available){for(auto* pool:pools)RFGRVR_VertexPoolRestart(pool);
   if(restoreResources)available=RFGRVR_EyeResources_Between(restoreMask);
   if(restorePipeline)RFGRVR_EyePipeline_Between(restoreMask);
   if(restoreCache){cache[0].restore(renderer,restoreMask);cache[1].restore(secondary,restoreMask);}
   if(available){
    // Auxiliary cameras are new views, never replays of the headset's cached
    // geometry/impact queue. Restore the borrowed queue after each feed.
    vrglare::SunGenerationScope auxiliarySun(sunGeneration,RFGRVR_HeadCam_Enabled()&&vrvisual::enhanced());
    RFGRVRMenuWorldScope auxiliaryWorld((uint32_t*)((char*)self+0x14),popupWorldMaskVerified&&memory((char*)self+0x14,4));
    RFGRVRMenuGeometryScope auxiliaryGeometry(popupGeometryCache,(uint32_t*)((char*)self+0x50),popupGeometryCache&&memory((char*)self+0x50,4));

    apcCache[0].restore(renderer);apcCache[1].restore(secondary);RFGRVR_NativePair_Select(1);if(scopePass)RFGRVR_Scope_AuxSet(&auxiliary);else RFGRVR_APC_AuxSet(&auxiliary);prepareEyeCameras(camera,renderer,secondary);
    RFGRVREffectGeometry::select(1);RFGRVREffectViewCache::select(1);refreshEyeSky(scene,camera);
    // Keep native viewport/ray constants consistent with the auxiliary targets.
    unsigned previousWidth=word(self,0x1f8),previousHeight=word(self,0x1fc);unsigned feedWidth=RFGRAPCTargets::width,feedHeight=RFGRAPCTargets::height;
    memcpy((char*)self+0x1f8,&feedWidth,4);memcpy((char*)self+0x1fc,&feedHeight,4);
    {modernmaterial::Bindings capturePrimary,captureSecondary;std::optional<modernmaterial::WorldScope> dynamicCapture;
     auto* sky=modernruntime::developmentGraph.skyResource();
     if(sky){modernmaterial::Frame first,second;auto* a=modernruntime::context(renderer);auto* b=modernruntime::context(secondary);
      if(modernruntime::materialFrame(renderer,self,first)){first.reflection[3]=0;first.layout[1]=0;dynamicCapture.emplace(first,nullptr,nullptr,nullptr,sky);capturePrimary.bind(a,nullptr,nullptr,&first,nullptr,sky);}
      if(b!=a&&modernruntime::materialFrame(secondary,self,second)){second.reflection[3]=0;second.layout[1]=0;captureSecondary.bind(b,nullptr,nullptr,&second,nullptr,sky);}}
     // The same atmosphere enters reflections; diffuse probes are excluded to
     // avoid feeding a previous bounce into the next capture without control.
     sceneRender(self,renderer,secondary,scene,camera,a5,a6);
    }
    memcpy((char*)self+0x1f8,&previousWidth,4);memcpy((char*)self+0x1fc,&previousHeight,4);RFGRVR_APC_AuxCapture(cameraIndex);
    RFGRVREffectViewCache::select(-1);RFGRVREffectGeometry::eye=-1;RFGRVRBatchTrace::eye=-1;
    if(scopePass)RFGRVR_Scope_AuxSet(nullptr);else RFGRVR_APC_AuxSet(nullptr);
   }
  }
 }
 if(apcPasses||scopePass){RFGRVR_APC_Pipeline(false);apcCache[0].restore(renderer);apcCache[1].restore(secondary);}
 // Budgeted adapter: one real auxiliary world face every eight pairs.
 // Opt-in until native capture diagnostics prove all six camera/stream paths.
 static bool worldCapture=[](){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* slash=strrchr(path,92)){strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-modern-world-capture.enable");return GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES;}return false;}();
 static uint64_t worldFrame=0,captureId=0,lastCaptureFrame=0,captureScene=0;static unsigned captureAttempts=0;static bool captureFinished=false;
 if(worldCapture&&modernlight::transportEnabled()&&ok&&!apcPasses&&!scopePass&&!RFGRVR_HeadCam_MenuScene()&&!RFGRVR_HeadCam_PopupMenu()&&!captureFinished&&++worldFrame%8==0){
  auto* immediate=modernruntime::context(renderer);Microsoft::WRL::ComPtr<ID3D11Device> device;if(immediate)immediate->GetDevice(&device);
  // Plan in absolute world coordinates; overlapping probe cells survive
  // movement. Completed generations remain owned until consumers submit.
  auto* captureState=(char*)modernruntime::pointer(renderer,0x478);modernlocal::V probePosition{};bool missingProbe=false,planned=false;
  if(memory(captureState,0x500)){float eye[3]{},renderOrigin[3]{};memcpy(eye,captureState+0x74,12);memcpy(renderOrigin,captureState+0x80,12);for(unsigned k=0;k<3;++k)eye[k]+=renderOrigin[k];planned=modernruntime::developmentGraph.planProbe({eye[0],eye[1],eye[2]},probePosition,missingProbe,(float*)(captureState+0x4c0),renderOrigin);}
  if(captureId&&modernaux::producer.completed()==captureId&&modernruntime::consumedCapture==captureId&&(missingProbe||worldFrame-lastCaptureFrame>=600)){captureId=0;captureAttempts=0;}
  if(captureScene!=(uint64_t)(uintptr_t)scene){if(modernaux::producer.busy())modernaux::producer.cancel();captureId=0;captureScene=(uint64_t)(uintptr_t)scene;captureAttempts=0;}
  if(device&&!captureId&&planned&&modernaux::producer.begin(device.Get(),(uint64_t)(uintptr_t)scene,worldFrame,0,probePosition)){captureId=worldFrame;lastCaptureFrame=worldFrame;}
  vrarm::Pose view{};
  if(captureId&&modernaux::producer.next(worldFrame,view)){
   bool available=true;void* pools[2]={(void*)(uintptr_t)word(renderer,0x24),(void*)(uintptr_t)word(secondary,0x24)};
   for(auto* pool:pools)available=available&&memory(pool,16)&&RFGRVR_VertexPoolReady(pool);
   if(available){for(auto* pool:pools)RFGRVR_VertexPoolRestart(pool);if(restoreResources)available=RFGRVR_EyeResources_Between(restoreMask);if(restorePipeline)RFGRVR_EyePipeline_Between(restoreMask);if(restoreCache){cache[0].restore(renderer,restoreMask);cache[1].restore(secondary,restoreMask);}}
   if(available){
    apcCache[0].save(renderer);apcCache[1].save(secondary);RFGRVR_APC_Pipeline(true);
    RFGRVRMenuWorldScope world((uint32_t*)((char*)self+0x14),popupWorldMaskVerified&&memory((char*)self+0x14,4));
    RFGRVRMenuGeometryScope geometry(popupGeometryCache,(uint32_t*)((char*)self+0x50),popupGeometryCache&&memory((char*)self+0x50,4));
    modernaux::nativeScene=self;modernaux::nativeRenderer=renderer;modernaux::nativeSecondary=secondary;modernaux::active=true;
    RFGRVR_NativePair_Select(1);RFGRVR_APC_AuxSet(&view);prepareEyeCameras(camera,renderer,secondary);
    RFGRVREffectGeometry::select(1);RFGRVREffectViewCache::select(1);refreshEyeSky(scene,camera);
    unsigned previousWidth=word(self,0x1f8),previousHeight=word(self,0x1fc),size=128;memcpy((char*)self+0x1f8,&size,4);memcpy((char*)self+0x1fc,&size,4);
    {modernmaterial::Bindings capturePrimary,captureSecondary;std::optional<modernmaterial::WorldScope> dynamicCapture;
     auto* sky=modernruntime::developmentGraph.skyResource();
     if(sky){modernmaterial::Frame first,second;auto* a=modernruntime::context(renderer);auto* b=modernruntime::context(secondary);
      if(modernruntime::materialFrame(renderer,self,first)){first.reflection[3]=0;first.layout[1]=0;dynamicCapture.emplace(first,nullptr,nullptr,nullptr,sky);capturePrimary.bind(a,nullptr,nullptr,&first,nullptr,sky);}
      if(b!=a&&modernruntime::materialFrame(secondary,self,second)){second.reflection[3]=0;second.layout[1]=0;captureSecondary.bind(b,nullptr,nullptr,&second,nullptr,sky);}}
     // The same atmosphere enters reflections; diffuse probes are excluded to
     // avoid feeding a previous bounce into the next capture without control.
     sceneRender(self,renderer,secondary,scene,camera,a5,a6);
    }
    memcpy((char*)self+0x1f8,&previousWidth,4);memcpy((char*)self+0x1fc,&previousHeight,4);
    modernaux::producer.finishFace();
    RFGRVR_APC_AuxSet(nullptr);modernaux::active=false;modernaux::nativeScene=modernaux::nativeRenderer=modernaux::nativeSecondary=nullptr;
    RFGRVREffectViewCache::select(-1);RFGRVREffectGeometry::eye=-1;RFGRVRBatchTrace::eye=-1;RFGRVR_APC_Pipeline(false);apcCache[0].restore(renderer);apcCache[1].restore(secondary);
   }
   if(++captureAttempts>=120){modernaux::producer.cancel();captureFinished=true;}
  }
  // GPU completion is polled at the next pair, without blocking.
 }
 RFGRVR_PixelProbe_End();
 if(restoreResources){char label[96]{};sprintf_s(label,"mode-%u-snapshots-%u-ok-%u",testMode,RFGRVR_EyeResources_Count(),ok?1:0);if(attempted==1||!ok)pairStage(label,2);RFGRVR_EyeResources_End();}
 if(restorePipeline)RFGRVR_EyePipeline_End();
 if(testMode!=0&&!continuousMode(testMode))RFGRVR_NativePair_DiagnosticEnd();else RFGRVR_NativePair_End(ok);
 entered=false;if(!continuousMode(testMode)||attempted==1||!ok)pairStage("scene-pair-ended",2);if(ok){++pairs;retryAfter=0;}else{++failed;retryAfter=GetTickCount64()+100;RFGRVR_NativePair_Continuous(false);}
 report(draws[0],draws[1],before,RFGRVR_HeadCam_HeadSamples(),ok);
 if(!draws[0])sceneRender(self,renderer,secondary,scene,camera,a5,a6);
}
static void __fastcall OnSceneRender(void* self,void*,void* renderer,void* secondary,void* scene,void* camera,void* a5,void* a6){
 vrmemory::Scope memoryScope;
 if(auto* b=vrsettings::bus()){if(InterlockedExchange(&b->recalibrated,0))RFGRVR_Temporal_Recenter();InterlockedExchange(&b->gamePid,GetCurrentProcessId());InterlockedExchange(&b->pauseTick,RFGRVR_HeadCam_PopupMenu()?LONG(GetTickCount()):0);InterlockedExchange(&b->pauseMenuTick,RFGRVR_HeadCam_PauseMenu()?LONG(GetTickCount()):0);}
 if(!entered)pollTestMode();
 auto* base=(unsigned char*)GetModuleHandleW(nullptr);void* mainScene=(void*)(uintptr_t)word(base,0x2133894);
 bool want=!entered&&requested()&&canAttemptPair(GetTickCount64())&&(RFGRVR_HeadCam_HeadSamples()>120||RFGRVR_HeadCam_MenuScene())&&scene==mainScene&&self==(void*)(uintptr_t)word(scene,0x13c)&&memory(camera,0x598)&&memory(renderer,0x480);
 if(!entered&&scene==mainScene)RFGRVR_NativePair_Continuous(continuousMode(testMode)&&want);
 RFGRVR_NativePair_SetRequested(want);
 if(!want){sceneRender(self,renderer,secondary,scene,camera,a5,a6);return;}
 RFGRVRMenuWorldScope menuWorld((uint32_t*)((char*)self+0x14),popupWorldMaskVerified&&RFGRVR_HeadCam_PopupMenu()&&memory((char*)self+0x14,4));
 runScenePair(self,renderer,secondary,scene,camera,a5,a6);
}
static void __fastcall OnPrepare(void* camera,void* edx,void* renderer){
 float projection[16]{},fov=0;auto* c=(unsigned char*)camera;
 if(RFGRVR_APC_AuxProjection(camera,projection,&fov)&&memory(c+0x140,4)&&memory(renderer,0x47c)){
  float saved=0;memcpy(&saved,c+0x140,4);memcpy(c+0x140,&fov,4);prepare(camera,edx,renderer);memcpy(c+0x140,&saved,4);
  void* state=(void*)(uintptr_t)word(renderer,0x478);if(memory(c+0xc0,64)&&memory((char*)state+0x440,64)){memcpy(c+0xc0,projection,64);memcpy((char*)state+0x440,projection,64);updateMatrices(state);updateRenderer(renderer);}return;
 }

 const bool eye=RFGRVR_NativePair_Projection(camera,projection,&fov)&&memory(c+0x140,4)&&memory(renderer,0x47c);
 const bool compatible=!eye&&RFGRVR_NativePair_CompatibilityFov(camera,&fov)&&memory(c+0x140,4);
 // The stable temporal path uses a symmetric source image, not a per-eye projection.
 const bool exactTemporal=false;
 const bool temporal=!compatible&&(exactTemporal||(!eye&&memory(c+0x140,4)&&RFGRVR_Temporal_OpticsFov(camera,&fov)));
 float saved=0;if(eye||temporal||compatible){RFGRVR_HeadCam_RenderFov(fov);memcpy(&saved,c+0x140,4);memcpy(c+0x140,&fov,4);}
 const bool held=(temporal||compatible)&&RFGRVR_Temporal_HoldFov(camera,saved,fov);
 prepare(camera,edx,renderer);
 if(eye||((temporal||compatible)&&!held))memcpy(c+0x140,&saved,4);
 if(compatible){RFGRVR_NativePair_CompatibilityApplied(camera);return;}
 if(!eye&&!exactTemporal){if(temporal)RFGRVR_Temporal_OpticsApplied(camera);return;}
 void* state=nullptr;memcpy(&state,(unsigned char*)renderer+0x478,4);
 if(!memory(c+0xc0,64)||!memory((unsigned char*)state+0x440,64)){if(temporal)RFGRVR_Temporal_OpticsApplied(camera);return;}
 // The original just generated conservative frusta from the encompassing FOV.
 // Replace the render projection after preparation, then refresh derived state.
 memcpy(c+0xc0,projection,64);memcpy((unsigned char*)state+0x440,projection,64);
 updateMatrices(state);updateRenderer(renderer);if(eye)RFGRVR_NativePair_ProjectionApplied();if(temporal)RFGRVR_Temporal_OpticsApplied(camera);
}
}
// This final-frame step captures pixels only. It must never reenter rendering:
// native renderer+440 has already been cleared by frame cleanup here.
extern "C" void RFGRVR_MapWorld_Present(IDXGISwapChain* swap){if(mapWorldGateVerified&&RFGRVR_HeadCam_MapMenu())RFGRVR_CaptureMapPanel(swap);}
static void installReport(const char* stage,MH_STATUS status=MH_OK){
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Scene-Hook-Install.log");FILE* f=nullptr;if(!_wfopen_s(&f,path,L"a")&&f){fprintf(f,"%s status=%d\n",stage,(int)status);fclose(f);}
}
extern "C" bool RFGRVR_ResizeRenderBuffersOnOwner(unsigned width,unsigned height){
 auto* window=renderBufferWindow.load(std::memory_order_acquire);
 if(!window||!resizeRenderBuffers||GetCurrentThreadId()!=renderBufferThread.load()||!width||!height)return false;
 if(renderBufferResizing)return false;
 if(renderBufferWidth==width&&renderBufferHeight==height)return true;
 RenderResizeScope resizeScope;
 RFGRVR_APC_BeforeResize();bool ok=resizeRenderBuffers(window,width,height);
 if(ok){renderBufferWidth=width;renderBufferHeight=height;}return ok;
}
extern "C" bool RFGRVR_NativeScene_Install(){
 auto* b=(unsigned char*)GetModuleHandleW(nullptr);
 const unsigned char visionWriteSig[]={0xc6,0x05};unsigned visionAddress=0;
 memcpy(&visionAddress,b+0x3c2f90,4);
 const unsigned char visionDescriptorSig[]={0x81,0xc7,0xb8,0x01,0,0};
 if(!memcmp(b+0x3d080c,visionDescriptorSig,sizeof(visionDescriptorSig))&&!memcmp(b+0x3c2f8e,visionWriteSig,2)&&visionAddress==(unsigned)(uintptr_t)(b+0x21338a7)&&b[0x3c2f94]==1)nativeScopeVision=b+0x21338a7;
 const unsigned char menuMaskSig[]={0x8b,0x53,0x14,0xd1,0xea,0xf6,0xc2,0x01,0x0f,0x85};
 const unsigned char snapshotRouteSig[]={0xf6,0x45,0x14,0x01};
 const unsigned char snapshotCaptureSig[]={0x83,0x4e,0x14,0x02};
 popupWorldMaskVerified=b&&!memcmp(b+0x16217e,menuMaskSig,sizeof(menuMaskSig))&&
  !memcmp(b+0x161337,snapshotRouteSig,sizeof(snapshotRouteSig))&&
  !memcmp(b+0x10ad98,snapshotCaptureSig,sizeof(snapshotCaptureSig));
 // These operands are relocated by ASLR; compare against this process's base.
 if(popupWorldMaskVerified&&RFGRVRMenuGeometrySignature(b+0x16218c,b+0x1629f0,(unsigned)(uintptr_t)(b+0x177bd1b),(unsigned)(uintptr_t)(b+0x177bd18)))popupGeometryCache=b+0x177bd18;
 const unsigned char mapGateSig[]={0x80,0x7c,0x24,0x34,0,0xbb,4,0,0,0,0x74,0x14};
 mapWorldGateVerified=!memcmp(b+0x3cfb2f,mapGateSig,sizeof(mapGateSig));
 const unsigned char renderSig[]={0x8b,0x44,0x24,0x0c,0x8b,0x4c,0x24,0x08,0x57};
 const unsigned char prepareSig[]={0x83,0xec,0x2c,0x53,0x55,0x56,0x57};
 const unsigned char sceneSig[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x81,0xec,0xc4,5,0,0};
 if(!b||memcmp(b+0x3d0a90,renderSig,sizeof(renderSig))||memcmp(b+0x120d70,prepareSig,sizeof(prepareSig))||memcmp(b+0x161d20,sceneSig,sizeof(sceneSig))){installReport("signature-rejected");return false;}
 const unsigned char switchSig[]={0x83,0xec,0x44,0xa1};
 if(memcmp(b+0x86ddd0,switchSig,sizeof(switchSig))||b[0x86dde6]!=0x53||b[0x86dde7]!=0x55){installReport("resolution-signature-rejected");return false;}
 const unsigned char effectsSig[]={0x81,0xec,0xa0,0,0,0};
 if(memcmp(b+0x129f80,effectsSig,sizeof(effectsSig))){installReport("effects-signature-rejected");return false;}
 const unsigned char viewEffectSig[]={0x81,0xec,0xdc,0,0,0};
 if(memcmp(b+0x12a9f0,viewEffectSig,sizeof(viewEffectSig))){installReport("effect-view-signature-rejected");return false;}
 const unsigned char bloomSourceSig[]={0x83,0xec,0x38,0x8b,0x15};
 const unsigned char bloomExposureSig[]={0x8b,0x44,0x24,0x10,0x83,0xec,0x38};
 if(memcmp(b+0x13d4c0,bloomSourceSig,sizeof(bloomSourceSig))||memcmp(b+0x13b9a0,bloomExposureSig,sizeof(bloomExposureSig))){installReport("bloom-source-signature-rejected");return false;}
 // Independently verify stack cleanup: source has SEVEN stack arguments;
 // exposure has SIX. Sharing their function type corrupts the caller stack.
 const unsigned char bloomSourceReturn[]={0xc2,0x1c,0};
 const unsigned char bloomExposureReturn[]={0xc2,0x18,0};
 if(memcmp(b+0x13d78e,bloomSourceReturn,3)||memcmp(b+0x13c6fd,bloomExposureReturn,3)||memcmp(b+0x13c719,bloomExposureReturn,3)){installReport("bloom-calling-convention-rejected");return false;}
 const unsigned char hdrUploadStart[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x83,0xec,0x14};
 const unsigned char bloomUploadField[]={0x8b,0x8e,0x58,0x0b,0,0,0x8b,0x5a,0x48,0x89,0x9c,0x88,0xc0,0x02,0,0};
 if(memcmp(b+0x1259e0,hdrUploadStart,sizeof(hdrUploadStart))||memcmp(b+0x125b17,bloomUploadField,sizeof(bloomUploadField))||b[0x125caa]!=0xc2||word(b,0x125cab)%65536!=12){installReport("vehicle-bloom-upload-signature-rejected");return false;}
 RFGRVRBloomViewCache::manager=(void**)(b+0x1637910);
 const unsigned char clockRead[]={0xf3,0x0f,0x10,0x05};
 nightClock=!memcmp(b+0x3e31d1,clockRead,4)&&word(b,0x3e31d5)==(unsigned)(uintptr_t)(b+0x125cc80)?(float*)(b+0x125cc80):nullptr;
 if(!nightClock)installReport("night-clock-signature-unavailable");
 RFGRVREffectViewCache::frame=(unsigned*)(b+0x177bcf8);
 const unsigned char resizeSig[]={0x53,0x8b,0x5c,0x24,0x0c,0x57};
 if(memcmp(b+0x86ab20,resizeSig,sizeof(resizeSig))){installReport("render-resize-signature-rejected");return false;}
 updateMatrices=(Update)(b+0xd24d0);updateRenderer=(Update)(b+0xf2500);cameraBegin=(CameraBegin)(b+0x137660);
 struct Hook {unsigned rva;void* detour;void** original;const char* name;};
 const unsigned char skySig[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x81,0xec,0xb8,0x01,0,0};
 if(memcmp(b+0x66bc90,skySig,sizeof(skySig))){installReport("sky-signature-rejected");return false;}skyRefresh=(SkyRefresh)(b+0x66bc90);
 const unsigned char todGetterTail[]={0x85,0xc0,0x75,0x01,0xc3};
 const bool todVerified=b[0x3c2960]==0xa1&&word(b,0x3c2961)==(unsigned)(uintptr_t)(b+0x2133894)&&!memcmp(b+0x3c2965,todGetterTail,5);
 const unsigned char lightColourStart[]={0x83,0xec,0x10,0xf3,0x0f,0x10,0x89,0xcc,0,0,0};
 const unsigned char ambientStart[]={0x83,0xec,0x10,0x8b,0x44,0x24,0x14,0xf3,0x0f,0x10,0x08};
 if(!todVerified||memcmp(b+0xc27e0,lightColourStart,sizeof(lightColourStart))||memcmp(b+0x116460,ambientStart,sizeof(ambientStart))||b[0x116590]!=0x83||word(b,0x116595)!=(unsigned)(uintptr_t)(b+0x10fa3d8)){installReport("night-light-signature-rejected");return false;}
 vrnightlights::sceneRoot=(void**)(b+0x2133894);
 // Orbital quad builder: camera up at +14/+18/+1c and right at +8/+c/+10.
 const unsigned char orbitalStart[]={0x83,0xec,0x3c,0x80,0x3d};
 const unsigned char orbitalUp[]={0xf3,0x0f,0x10,0x48,0x14};
 const unsigned char orbitalRight[]={0xf3,0x0f,0x10,0x40,0x08};
 if(memcmp(b+0x1313f0,orbitalStart,sizeof(orbitalStart))||word(b,0x1313f5)!=(unsigned)(uintptr_t)(b+0x177bd35)||memcmp(b+0x131471,orbitalUp,sizeof(orbitalUp))||memcmp(b+0x1314a7,orbitalRight,sizeof(orbitalRight))){installReport("orbital-billboard-signature-rejected");return false;}
 const unsigned char sunSig[]={0x81,0xec,0x88,0,0,0};if(memcmp(b+0x1193a0,sunSig,sizeof(sunSig))||b[0x119665]!=0xc2||word(b,0x119666)%65536!=8){installReport("sun-sprite-signature-rejected");return false;}sunObject=(void**)(b+0x18d2708);
 const unsigned char compositeSig[]={0x81,0xec,0xc0,1,0,0},sunInputSig[]={0x8b,0x87,0x78,9,0,0},shaftInputSig[]={0x8b,0x87,0xac,0x0a,0,0};if(memcmp(b+0x13d7a0,compositeSig,sizeof(compositeSig))||memcmp(b+0x13da5b,sunInputSig,sizeof(sunInputSig))||memcmp(b+0x13dfe3,shaftInputSig,sizeof(shaftInputSig))||b[0x13e300]!=0xc2||word(b,0x13e301)%65536!=0x24){installReport("sun-composite-signature-rejected");return false;}
 // Both the visibility pass and sun-shaft generation test this relocated flag.
 const unsigned gateRvas[]={0x1351d8,0x13535c,0x146047};for(unsigned rva:gateRvas)if(b[rva]!=0x80||b[rva+1]!=0x3d||word(b,rva+2)!=(unsigned)(uintptr_t)(b+0x10fa527)||b[rva+6]!=0){installReport("sun-generation-switch-rejected");return false;}sunGeneration=b+0x10fa527;
 const unsigned char lensSig[]={0x83,0xec,0x40,0x57,0x8b,0xf9};if(memcmp(b+0x13f8c0,lensSig,sizeof(lensSig))||b[0x13fa70]!=0xc2||word(b,0x13fa71)%65536!=8){installReport("lens-flare-signature-rejected");return false;}
 Hook hooks[]={{0xc27e0,(void*)&vrnightlights::onColour,(void**)&vrnightlights::colour,"night-main-light"},{0x116460,(void*)&vrnightlights::frontEntry,(void**)&vrnightlights::front,"night-ambient-front"},{0x116590,(void*)&vrnightlights::backEntry,(void**)&vrnightlights::back,"night-ambient-back"},{0x1259e0,(void*)&vrvehiclebloom::onUpload,(void**)&vrvehiclebloom::upload,"vehicle-bloom-only"},{0x1313f0,(void*)&onOrbitalDraw,(void**)&orbitalDraw,"world-oriented-orbitals"},{0x13f8c0,(void*)&vrglare::onLens,(void**)&vrglare::lens,"vr-lens-ghosts"},{0x13d7a0,(void*)&vrglare::onComposite,(void**)&vrglare::composite,"vr-sun-composite"},{0x1193a0,(void*)&onSunSprite,(void**)&sunSprite,"vr-sun-glare"},{0x13d4c0,(void*)&RFGRVRBloomViewCache::onDownsample,(void**)&RFGRVRBloomViewCache::downsample,"bloom-eye-source"},{0x13b9a0,(void*)&RFGRVRBloomViewCache::onAdaptation,(void**)&RFGRVRBloomViewCache::adaptation,"bloom-shared-exposure"},{0x120d70,(void*)&OnPrepare,(void**)&prepare,"camera-optics"},{0x161d20,(void*)&OnSceneRender,(void**)&sceneRender,"scene-stereo"},{0x3d0a90,(void*)&OnRender,(void**)&render,"outer-once"},{0x86ddd0,(void*)&OnSwitchResolution,(void**)&switchResolution,"resolution-switch"},{0x86ab20,(void*)&OnResizeRenderBuffers,(void**)&resizeRenderBuffers,"render-buffer-resize"},{0x129f80,(void*)&RFGRVREffectGeometry::onRender,(void**)&RFGRVREffectGeometry::render,"effects-geometry-stereo"},{0x12a9f0,(void*)&RFGRVREffectViewCache::onRender,(void**)&RFGRVREffectViewCache::render,"effects-view-cache"}};
 const unsigned char coronaCamera[]={0x8b,0x84,0x24,0xf4,0,0,0,0x83,0xc0,0x08};
 const unsigned char coronaPosition[]={0xf3,0x0f,0x7e,0x4e,0x14};
 const unsigned char coronaSpin[]={0xf3,0x0f,0x10,0x4e,0x64};
 if(memcmp(b+0x12aca4,coronaCamera,sizeof(coronaCamera))||memcmp(b+0x12ae1b,coronaPosition,sizeof(coronaPosition))||memcmp(b+0x12ae6e,coronaSpin,sizeof(coronaSpin))){installReport("corona-billboard-layout-rejected");return false;}
 unsigned created=0;
 for(auto& hook:hooks){MH_STATUS result=MH_CreateHook(b+hook.rva,hook.detour,hook.original);if(result!=MH_OK){installReport(hook.name,result);for(unsigned i=0;i<created;++i)MH_RemoveHook(b+hooks[i].rva);return false;}++created;}
 for(auto& hook:hooks){MH_STATUS result=MH_EnableHook(b+hook.rva);if(result!=MH_OK){installReport(hook.name,result);for(auto& undo:hooks){MH_DisableHook(b+undo.rva);MH_RemoveHook(b+undo.rva);}return false;}}
 if(modernlight::available())RFGRVRBloomViewCache::beforeSource=&modernruntime::beforeHDR;
 if(modernlight::transportEnabled()){
  const unsigned char lightGeometryStart[]={0x55,0x8b,0xec,0x83,0xe4,0xf8,0x83,0xec,0x20,0x56,0x8b,0xf1,0x8b,0x86,0xc8,0,0,0};
  if(!memcmp(b+0xc2510,lightGeometryStart,sizeof(lightGeometryStart))&&b[0xc2700]==0xc2&&b[0xc2701]==8&&b[0xc2702]==0){
   if(MH_CreateHook(b+0xc2510,(void*)&vrnightlights::geometryEntry,(void**)&vrnightlights::geometry)==MH_OK){if(MH_EnableHook(b+0xc2510)!=MH_OK)MH_RemoveHook(b+0xc2510);else installReport("modern-local-light-collection-connected");}
  }else installReport("modern-local-light-signature-rejected");
  const unsigned char shadowStart[]={0x83,0xec,0x24,0x53,0x55,0x56,0x8b,0xf1,0x83,0xbe,0x80,0x03,0,0,0,0x57};
  const unsigned char shadowReturn[]={0xc2,0x34,0};
  if(!memcmp(b+0x12e8d0,shadowStart,sizeof(shadowStart))&&!memcmp(b+0x12e9ec,shadowReturn,3)){
   if(MH_CreateHook(b+0x12e8d0,(void*)&modernshadow::entry,(void**)&modernshadow::native)==MH_OK){
    if(MH_EnableHook(b+0x12e8d0)!=MH_OK){MH_RemoveHook(b+0x12e8d0);installReport("modern-shadow-capture-enable-failed");}
    else {modernshadow::notice=&modernruntime::cascade;RFGRVRBloomViewCache::beforeSource=&modernruntime::beforeHDR;installReport("modern-shadow-transport-connected");}
   }else installReport("modern-shadow-capture-create-failed");
  }else installReport("modern-shadow-capture-signature-rejected");
 }
 installReport(RFGRVRWristMapTrace::install()?"wrist-map-native-routing-installed":"wrist-map-routing-unavailable");
 installReport(RFGRVRHudHeading::install()?"map-stable-vr-heading-installed":"map-stable-heading-unavailable");
 installReport(RFGRVRNativeDust::install(b)?"ambient-dust-worldspace-depth-installed":"ambient-dust-correction-unavailable");
 vrcoronadepth::enabled=true;installReport("scene-stereo-and-optics-installed");return true;
}





















