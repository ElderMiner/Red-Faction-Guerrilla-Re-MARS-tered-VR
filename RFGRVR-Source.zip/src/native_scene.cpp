#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "vr_frame_clock.h"
#include "vr_memory_access.h"
#include "vr_user_settings.h"
#include "vr_sun_glare.h"
extern "C" void RFGRVR_Arms_BodyGeometryBegin();
extern "C" void RFGRVR_Arms_BodyGeometryEnd();
struct LocalBodyScope {LocalBodyScope(){RFGRVR_Arms_BodyGeometryBegin();}~LocalBodyScope(){RFGRVR_Arms_BodyGeometryEnd();}};
extern "C" void RFGRVR_Temporal_Recenter();
// Experimental same-simulation-frame rendering at the verified public renderer wrapper.
// Never reenters Present and never retains a scene worker's stack parameters.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "vr_menu_world_scope.h"
#include "weapon_scope.h"
extern "C" bool RFGRVR_HeadCam_PopupMenu();
extern "C" bool RFGRVR_HeadCam_PauseMenu();
extern "C" bool RFGRVR_HeadCam_FirstPersonVehicle();
extern "C" bool RFGRVR_Scope_AuxView(unsigned,vrarm::Pose*);
static unsigned char* nativeScopeVision=nullptr;
// Outer rendering bakes native rail vision into scene+1B8 BEFORE eye rendering.
// Clearing only the global toggle leaves that prepared descriptor active.
struct NativeScopeWorldVision {unsigned char* flag=nullptr,*descriptor=nullptr;unsigned char saved=0,savedDescriptor=0;
 explicit NativeScopeWorldVision(void* scene=nullptr){if(nativeScopeVision&&vrscope::nativeVisualKind.load()==1){flag=nativeScopeVision;saved=*flag;*flag=0;if(scene){descriptor=(unsigned char*)scene+0x1b8;savedDescriptor=*descriptor;*descriptor=0;}}}
 ~NativeScopeWorldVision(){if(descriptor)*descriptor=savedDescriptor;if(flag)*flag=saved;}
};
static bool popupWorldMaskVerified=false;static unsigned char* popupGeometryCache=nullptr;
#include <d3d11.h>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <atomic>
#include "vr_renderer_cache.h"
#include "vr_sky_distance.h"
#include "vr_human_visibility_trace.h"
extern "C" bool RFGRVR_HeadCam_Enabled();
extern "C" void RFGRVR_HeadCam_RenderFov(float);
#include "vr_batch_trace.h"
#include "vr_vertex_cursor.h"
#include "vr_effect_geometry.h"
#include "vr_effect_view_cache.h"
#include "vr_bloom_view_cache.h"
#include "wrist_map_trace.h"
#include "vr_hud_heading.h"
#include "native_apc_cameras.h"
#include "apc_render_targets.h"
extern "C" void RFGRVR_APC_AuxSet(const vrarm::Pose*);
extern "C" void RFGRVR_Scope_AuxSet(const vrarm::Pose*);
extern "C" bool RFGRVR_APC_AuxProjection(void*,float[16],float*);
extern "C" bool RFGRVR_APC_AuxCapture(unsigned);
extern "C" void RFGRVR_APC_Pipeline(bool);
extern "C" void RFGRVR_APC_BeforeResize();

#include "../vendor/MinHook.h"
#include "vr_native_dust.h"
extern "C" bool RFGRVR_NativePair_Begin();
extern "C" bool RFGRVR_NativePair_BuffersBusy();
extern "C" bool RFGRVR_RingPair_Install();
extern "C" void RFGRVR_RingPair_Begin();
extern "C" void RFGRVR_RingPair_End();
extern "C" bool RFGRVR_Temporal_OpticsFov(void*,float*);
extern "C" bool RFGRVR_RenderWindow_Requested(unsigned*,unsigned*);
extern "C" bool RFGRVR_Temporal_EyeProjection(void*,float[16],float*);
extern "C" void RFGRVR_Temporal_OpticsApplied(void*);
extern "C" bool RFGRVR_Temporal_HoldFov(void*,float,float);
extern "C" void RFGRVR_NativePair_Select(unsigned);
extern "C" bool RFGRVR_NativePair_Capture(unsigned);
extern "C" void RFGRVR_NativePair_End(bool);
extern "C" bool RFGRVR_NativePair_Projection(void*,float[16],float*);
extern "C" bool RFGRVR_NativePair_CompatibilityFov(void*,float*);
extern "C" void RFGRVR_NativePair_CompatibilityApplied(void*);
extern "C" void RFGRVR_NativePair_ProjectionApplied();
extern "C" unsigned RFGRVR_HeadCam_HeadSamples();
extern "C" void RFGRVR_Arms_RenderWeapon(void*);
extern "C" unsigned long long RFGRVR_GPU_DrawCount();
extern "C" void RFGRVR_GPUCapture_Mark(unsigned,void*,void*);
extern "C" void RFGRVR_PairGpuMarker(const wchar_t*,bool);
extern "C" bool RFGRVR_HeadCam_Recent();
extern "C" bool RFGRVR_HeadCam_MenuScene();
extern "C" void RFGRVR_PixelProbe_Begin();
extern "C" void RFGRVR_PixelProbe_Select(unsigned);
extern "C" void RFGRVR_PixelProbe_End();
extern "C" void RFGRVR_NativePair_SetRequested(bool);
extern "C" void RFGRVR_NativePair_TestMode(unsigned,unsigned);
extern "C" void RFGRVR_NativePair_Continuous(bool);
extern "C" void RFGRVR_NativePair_DiagnosticEnd();
extern "C" bool RFGRVR_EyeResources_Begin(unsigned);
extern "C" bool RFGRVR_EyeResources_Between(unsigned);
extern "C" unsigned RFGRVR_EyeResources_Count();
extern "C" void RFGRVR_EyeResources_End();
extern "C" bool RFGRVR_EyePipeline_Begin();
extern "C" void RFGRVR_EyePipeline_Between(unsigned);
extern "C" void RFGRVR_EyePipeline_End();
namespace {
using SwitchResolution=bool(__cdecl*)(void*,void*,unsigned,unsigned,unsigned,unsigned,unsigned);
using ResizeRenderBuffers=bool(__cdecl*)(void*,unsigned,unsigned);
SwitchResolution switchResolution=nullptr;ResizeRenderBuffers resizeRenderBuffers=nullptr;
std::atomic<void*> renderBufferWindow{nullptr};std::atomic<DWORD> renderBufferThread{0};
std::atomic<unsigned> renderBufferWidth{0},renderBufferHeight{0};
thread_local bool renderBufferResizing=false;
struct RenderResizeScope {RenderResizeScope(){renderBufferResizing=true;}~RenderResizeScope(){renderBufferResizing=false;}};
static bool __cdecl OnSwitchResolution(void* device,void* window,unsigned width,unsigned height,unsigned numerator,unsigned denominator,unsigned mode){
 unsigned w=0,h=0;
 if(mode==2&&RFGRVR_RenderWindow_Requested(&w,&h)){width=1280;height=720;}
 return switchResolution(device,window,width,height,numerator,denominator,mode);
}
static bool __cdecl OnResizeRenderBuffers(void* window,unsigned width,unsigned height){
 if(renderBufferResizing)return true;
 RenderResizeScope resizeScope;
 renderBufferThread.store(GetCurrentThreadId());renderBufferWindow.store(window,std::memory_order_release);
 unsigned w=0,h=0;
 // This engine routine rebuilds the swap-chain buffers, depth resources and
 // cached dimensions together. Its size is independent of the desktop client.
 if(width&&height&&RFGRVR_RenderWindow_Requested(&w,&h)){width=w;height=h;}
 // The engine also calls this as an unchanged-size ensure operation. Only
 // invalidate cached surfaces when dimensions change; HookResize still
 // releases window references immediately before every actual DXGI resize.
 if(width!=renderBufferWidth.load()||height!=renderBufferHeight.load())RFGRVR_APC_BeforeResize();
 bool ok=resizeRenderBuffers(window,width,height);
 if(ok){renderBufferWidth=width;renderBufferHeight=height;}return ok;
}
using Render=uintptr_t(__cdecl*)(void*,unsigned,void*);
using Prepare=void(__fastcall*)(void*,void*,void*);
using Update=void(__thiscall*)(void*);
using Initialize=void(__thiscall*)(void*,void*,unsigned,unsigned,const void*,void*,unsigned);
static void initializeEye(Initialize initialize,void* eye,void* renderer,unsigned width,unsigned height,const void* lod){initialize(eye,renderer,width,height,lod,nullptr,0);}
using Allocate=void*(__cdecl*)(unsigned);using Construct=void*(__thiscall*)(void*);
Allocate allocateEye=nullptr;Construct constructEye=nullptr;
using RingCapacity=void(__thiscall*)(void*,unsigned);RingCapacity ringCapacityOriginal=nullptr;using RingInitialize=void(__thiscall*)(void*);RingInitialize ringInitializeOriginal=nullptr;void* stereoRing=nullptr;
Initialize initializeOriginal=nullptr;using TerrainInitialize=void(__thiscall*)(void*);TerrainInitialize terrainInitializeOriginal=nullptr;
using SceneRender=void(__thiscall*)(void*,void*,void*,void*,void*,void*,void*);using CameraBegin=void(__thiscall*)(void*,void*);
static vrglare::Owned sunGlare;static unsigned char* sunGeneration=nullptr;
static bool skyCameraVerified=false;static void** sunObject=nullptr;using SunSprite=void(__thiscall*)(void*,void*,void*);static SunSprite sunSprite=nullptr;
using SkyRefresh=void(__cdecl*)();static SkyRefresh skyRefresh=nullptr;static std::atomic<unsigned> skyEyeRefreshes{0};
SceneRender sceneRender=nullptr;CameraBegin cameraBegin=nullptr;
Render render=nullptr;Prepare prepare=nullptr;Update updateMatrices=nullptr,updateRenderer=nullptr;
thread_local bool entered=false;
std::atomic<unsigned> pairs{0},failed{0},attempted{0};std::atomic<ULONGLONG> retryAfter{0};
// Live selection avoids a reinstall between controlled comparisons and stereo.
// 0 baseline once; 1 identical-view comparison; 2 resource-restored comparison;
// 3 continuous restored resources; 4 continuous unmodified scene resources.
unsigned testMode=0,restoreMask=~0u;
static bool continuousMode(unsigned mode){return mode==3||mode==4||mode==8||mode==9||mode==10||mode==13||mode==14||mode==15;}
static bool canAttemptPair(ULONGLONG now){return attempted.load()==0||(continuousMode(testMode)&&now>=retryAfter.load());}
static void pollTestMode(){
 static ULONGLONG next=0;auto now=GetTickCount64();if(now<next)return;next=now+500;
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-stereo-test.mode");
 FILE* f=nullptr;unsigned mode=0,mask=~0u;
 if(!_wfopen_s(&f,path,L"r")&&f){fscanf_s(f,"%u %x",&mode,&mask);fclose(f);}
 if(mode>15)mode=0;
 if(mode!=testMode||mask!=restoreMask){testMode=mode;restoreMask=mask;attempted=0;failed=0;retryAfter=0;RFGRVR_NativePair_Continuous(continuousMode(mode));}
}
struct EyeResources {void* scene=nullptr;void* original=nullptr;void* right=nullptr;unsigned width=0,height=0;} resources;
bool resourceFailed=false;bool reuseOriginalRenderer=true;
static bool memory(void* p,size_t n){
 if(!p||!n)return false;uintptr_t current=(uintptr_t)p;if(current+n<current)return false;const uintptr_t end=current+n;
 while(current<end){MEMORY_BASIC_INFORMATION m{};if(!VirtualQuery((void*)current,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;auto next=(uintptr_t)m.BaseAddress+m.RegionSize;if(next<=current)return false;current=next;}
 return true;
}
static unsigned word(void* p,size_t offset){unsigned v=0;if(memory((char*)p+offset,4))memcpy(&v,(char*)p+offset,4);return v;}
static void disposeResources(){
 if(resources.right&&resources.right!=resources.original){using Destroy=void(__thiscall*)(void*,unsigned);auto** table=*(void***)resources.right;
  ((Destroy)table[0])(resources.right,1);}
 resources={};
}
static void resourceReport(const char* stage,void* renderer,void* original,void* right){
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Eye-Resources.csv");FILE* f=nullptr;
 if(_wfopen_s(&f,path,L"a")||!f)return;
 if(_ftelli64(f)==0)fputs("stage,renderer,left,right,left_main,right_main,left_srgb,right_srgb,left_half,right_half\n",f);
 fprintf(f,"%s,%p,%p,%p,%08X,%08X,%08X,%08X,%08X,%08X\n",stage,renderer,original,right,word(original,0x220),word(right,0x220),word(original,0x25c),word(right,0x25c),word(original,0x234),word(right,0x234));fclose(f);
}
static bool requested();
static void __fastcall OnRingCapacity(void* self,void*,unsigned bytes){
 const bool expand=!reuseOriginalRenderer&&bytes==10u*1024*1024&&requested();
 ringCapacityOriginal(self,expand?40u*1024*1024:bytes);
 if(expand){stereoRing=self;resourceReport("stereo-ring-capacity-40MiB",self,nullptr,nullptr);}
}
static void __fastcall OnRingInitialize(void* self,void*){
 if(memory(self,0x28)&&!*((unsigned char*)self+0x1c))OnRingCapacity(self,nullptr,word(self,0x14));
 ringInitializeOriginal(self);
}
static bool createIndependentEye(void* original,void* context,unsigned width,unsigned height,const void* lod,void* commands,unsigned bytes){
 if(!allocateEye||!constructEye||!initializeOriginal||commands||bytes||!memory(context,8)||!memory((void*)lod,0x94)||width<640||height<360||width>8192||height>8192)return false;
 disposeResources();void* raw=allocateEye(0x4bbe8);if(!raw)return false;void* right=constructEye(raw);if(!memory(right,0x4bbe8))return false;
 *(unsigned*)((char*)right+4)=0xffffffffu;
 resourceReport("valid-context-initialize-begin",context,original,right);
 // The engine-supplied context and LOD are borrowed ONLY within this callback.
 initializeEye(initializeOriginal,right,context,width,height,lod);
 resources={nullptr,original,right,width,height};resourceReport("valid-context-initialize-end",context,original,right);
 if(!word(right,0x220)||word(right,0x220)==word(original,0x220)||word(right,0x1f8)!=width||word(right,0x1fc)!=height||!word(right,0x4bb24)||!word(right,0x4bb28)){disposeResources();return false;}
 return true;
}
static void __fastcall OnInitialize(void* self,void*,void* context,unsigned width,unsigned height,const void* lod,void* commands,unsigned bytes){
 // Observe the engine's own construction, without substituting arguments.
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');
 if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Scene-Initialization.csv");FILE* f=nullptr;
 if(!_wfopen_s(&f,path,L"a")&&f){
 if(!_ftelli64(f))fputs("scene,context,context_first,context_second,width,height,lod,commands,bytes,thread\n",f);
 fprintf(f,"%p,%p,%08X,%08X,%u,%u,%p,%p,%u,%lu\n",self,context,word(context,0),word(context,4),width,height,lod,commands,bytes,GetCurrentThreadId());fclose(f);}}
 initializeOriginal(self,context,width,height,lod,commands,bytes);
 if(requested()&&!reuseOriginalRenderer)resourceFailed=!createIndependentEye(self,context,width,height,lod,commands,bytes);
}
static void __fastcall OnTerrainInitialize(void* self,void*){
 terrainInitializeOriginal(self);
 if(reuseOriginalRenderer||!resources.right||!resources.original||self!=(void*)(uintptr_t)word(resources.original,0x1c))return;
 void* right=(void*)(uintptr_t)word(resources.right,0x1c);
 if(!memory(right,0x3d308)){resourceFailed=true;return;}
 resourceReport("terrain-initialize-begin",self,resources.original,resources.right);
 // Mirror the engine's terrain-world setup at the same lifecycle point.
 terrainInitializeOriginal(right);
 resourceReport("terrain-initialize-end",self,resources.original,resources.right);
 if(!memory((void*)(uintptr_t)word(right,0x3d2e4),0x704))resourceFailed=true;
}
static bool prepareResources(void* renderer){
 auto* base=(unsigned char*)GetModuleHandleW(nullptr);
 void* scene=(void*)(uintptr_t)word(base,0x2133894);
 void* original=(void*)(uintptr_t)word(scene,0x13c);
 if(!memory(original,0x4bbe8)||word(original,0)!=(unsigned)(uintptr_t)(base+0xec05a8))return false;
 const unsigned width=word(original,0x1f8),height=word(original,0x1fc);
 if(width<640||height<360||width>8192||height>8192)return false;
 if(reuseOriginalRenderer){
 if(resources.right&&resources.right!=resources.original)disposeResources();
 resources={scene,original,original,width,height};return true;
 }
 if(resourceFailed||!resources.right||resources.original!=original||resources.width!=width||resources.height!=height)return false;
 if(resources.scene&&resources.scene!=scene)return false;
 void* terrain=(void*)(uintptr_t)word(resources.right,0x1c);
 if(!memory(terrain,0x3d308)||!memory((void*)(uintptr_t)word(terrain,0x3d2e4),0x704))return false;
 resources.scene=scene;memcpy((char*)resources.right+0x18,&scene,4);
 // Construction must happen at the real initializer, never using the outer renderer.

 return true;
}
static bool requested(){
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return false;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-independent-stereo.enable");
 return GetFileAttributesW(path)!=INVALID_FILE_ATTRIBUTES;
}
static void report(unsigned long long left,unsigned long long right,unsigned before,unsigned after,bool ok){
 if(continuousMode(testMode)&&ok&&attempted.load()!=1&&attempted.load()%120)return;
 char effectSummary[160]{};sprintf_s(effectSummary,"RFGR effects: first=%u second=%u geometry_restores=%u\n",RFGRVREffectGeometry::calls[0].load(),RFGRVREffectGeometry::calls[1].load(),RFGRVREffectGeometry::restores.load());OutputDebugStringA(effectSummary);
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Native-Stereo.csv");FILE* f=nullptr;
 if(_wfopen_s(&f,path,L"a")||!f)return;
 if(_ftelli64(f)==0)fputs("attempt,pairs,failed,left_draws,right_draws,head_samples_before,head_samples_after,complete\n",f);
 fprintf(f,"%u,%u,%u,%llu,%llu,%u,%u,%u\n",attempted.load(),pairs.load(),failed.load(),left,right,before,after,ok?1:0);fclose(f);
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Effect-Cost.log");
 if(!_wfopen_s(&f,path,L"a")&&f){LARGE_INTEGER frequency{};QueryPerformanceFrequency(&frequency);double ms=1000.0/double(frequency.QuadPart);fprintf(f,"tick=%llu pair=%u sampledPrepareMs=%.4f sampledNativeEffectsMs=%.4f sampledViewFixMs=%.4f sampledNativeViewMs=%.4f probes=%u fullTables=%u used=%u first=%u second=%u restores=%u\n",GetTickCount64(),attempted.load(),RFGRVREffectGeometry::prepareTicks.exchange(0)*ms,RFGRVREffectGeometry::renderTicks.exchange(0)*ms,RFGRVREffectViewCache::prepareTicks.exchange(0)*ms,RFGRVREffectViewCache::renderTicks.exchange(0)*ms,RFGRVREffectGeometry::probeCount.exchange(0),RFGRVREffectGeometry::fullTables.exchange(0),RFGRVREffectGeometry::usedCount,RFGRVREffectGeometry::calls[0].load(),RFGRVREffectGeometry::calls[1].load(),RFGRVREffectGeometry::restores.load());fclose(f);}
}
static void pairStage(const char* phase,unsigned eye){
 if(continuousMode(testMode)&&attempted.load()!=1&&attempted.load()%120)return;
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Pair-Stages.log");FILE* file=nullptr;
 if(!_wfopen_s(&file,path,L"a")&&file){fprintf(file,"%llu pair=%u eye=%u phase=%s head=%u ring=%p capacity=%u write=%u read=%u pending=%u\n",GetTickCount64(),attempted.load(),eye,phase,RFGRVR_HeadCam_HeadSamples(),stereoRing,word(stereoRing,0x14),word(stereoRing,0x60),word(stereoRing,0x64),word(stereoRing,0x68));fflush(file);fclose(file);}
}
static void refreshEyeSky(void* scene,void* camera){
 if(!skyRefresh||!RFGRVR_HeadCam_Enabled())return;
 // Native celestial material setup queries scene+130, not the worker camera.
 // Borrow only that accessor for this synchronous refresh, never its ownership.
 void** slot=skyCameraVerified&&memory(scene,0x134)?(void**)((char*)scene+0x130):nullptr;void* saved=slot?*slot:nullptr;if(slot)*slot=camera;
 skyRefresh();if(slot)*slot=saved;if(sunGlare.record&&memory(sunGlare.record,0x5c))sunGlare.apply(sunGlare.record,true);++skyEyeRefreshes;
}
static void __fastcall onSunSprite(void* self,void*,void* renderer,void* camera){
 // The verified sun sprite contains the oversized camera glare. Omit it in
 // VR instead of scaling an intensity the engine can rebuild each frame.
 if(RFGRVR_HeadCam_Enabled()&&sunObject&&*sunObject==self)return;
 sunSprite(self,renderer,camera);
}
static void prepareEyeCameras(void* camera,void* renderer,void* secondary){
 cameraBegin(camera,renderer);
 // F3050 copies CPU shader constants, not the secondary state manager's
 // active camera, eye position, view matrix or derived view transforms.
 // Refresh those from the same eye before its lighting/material work.
 if(secondary!=renderer&&memory(secondary,0x480)&&memory((void*)(uintptr_t)word(secondary,0x478),0x580))cameraBegin(camera,secondary);
}
static void recordEyeCameras(unsigned eye,void* camera,void* renderer,void* secondary){
 if(attempted.load()!=1||!memory((char*)camera+0x2c,12))return;
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Eye-Camera-State.csv");
 FILE* file=nullptr;if(_wfopen_s(&file,path,eye?L"a":L"w")||!file)return;
 if(!eye)fputs("eye,renderer,active_camera,expected_camera,eye_x,eye_y,eye_z,shader_eye_x,shader_eye_y,shader_eye_z\n",file);
 void* renderers[2]={renderer,secondary};for(unsigned i=0;i<2;++i){auto* r=(unsigned char*)renderers[i];auto* state=(unsigned char*)(uintptr_t)word(r,0x478);
  if(!memory(r,0xf0)||!memory(state,0x90))continue;float position[3],shader[3];memcpy(position,state+0x74,12);memcpy(shader,r+0xe0,12);
  fprintf(file,"%u,%u,%08X,%p,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n",eye,i,word(state,0x70),camera,position[0],position[1],position[2],shader[0],shader[1],shader[2]);}
 fclose(file);
}
extern "C" bool RFGRVR_HeadCam_MapMenu();
static bool mapWorldGateVerified=false;
extern "C" void RFGRVR_FrameTiming_Outer(long long);
static uintptr_t __cdecl OnRender(void* renderer,unsigned scene,void* secondary){
 RFGRVRBloomViewCache::vehicleExposure.store(RFGRVR_HeadCam_FirstPersonVehicle(),std::memory_order_relaxed);
 // Pace before doing render work. XR supplies one credit per runtime frame;
 // never skip/re-enter the native renderer or wait while holding eye mutexes.
 static vrframeclock::Reader frameClock;if(RFGRVR_HeadCam_Enabled()&&RFGRVR_HeadCam_Recent()&&continuousMode(testMode))frameClock.pace();

 // Native Map passes renderWorld=0. Enable geometry in this ORIGINAL
 // scheduled frame, before the command writer is released. Never render at Present.
 const bool mapWorld=mapWorldGateVerified&&RFGRVR_HeadCam_MapMenu()&&memory(renderer,0x444)&&word(renderer,0x440);if(mapWorld)scene=1;
 static ULONGLONG nextGlareCheck=0;auto* glareBase=(unsigned char*)GetModuleHandleW(nullptr);
 if(!RFGRVR_HeadCam_Enabled()){sunGlare.apply(nullptr,false);}else if(GetTickCount64()>=nextGlareCheck){nextGlareCheck=GetTickCount64()+1000;unsigned count=word(glareBase,0x19ee498);if(count&&count<=64&&memory(glareBase+0x1a1a770,size_t(count)*0x5c))for(unsigned i=0;i<count;++i){auto* record=glareBase+0x1a1a770+i*0x5c;if(!memcmp(record,"SunGlare01\0",11)){sunGlare.apply(record,true);break;}}}

 // This wrapper contains frame work and must execute exactly once.
 LARGE_INTEGER start{},end{};QueryPerformanceCounter(&start);
 vrglare::SunGenerationScope disableSun(sunGeneration,RFGRVR_HeadCam_Enabled());
 RFGRVR_GPUCapture_Mark(40,renderer,secondary);auto result=render(renderer,scene,secondary);RFGRVR_GPUCapture_Mark(41,renderer,secondary);
 if(mapWorld){static DWORD reported=0;if(GetTickCount()-reported>1000){reported=GetTickCount();char file[MAX_PATH]{};GetModuleFileNameA(nullptr,file,MAX_PATH);if(auto* slash=strrchr(file,92)){strcpy_s(slash+1,MAX_PATH-(slash+1-file),"vr-research\\output\\map-world-state.json");FILE* out=nullptr;if(!fopen_s(&out,file,"w")&&out){fprintf(out,"{\"scheduledWorld\":true,\"liveWriter\":true,\"pairs\":%u}\n",pairs.load());fclose(out);}}}}
 QueryPerformanceCounter(&end);RFGRVR_FrameTiming_Outer(end.QuadPart-start.QuadPart);return result;
}
static void runScenePair(void* self,void* renderer,void* secondary,void* scene,void* camera,void* a5,void* a6){
 static unsigned busyFallbacks=0,otherFallbacks=0;static unsigned long long busyCpuTicks=0;static LARGE_INTEGER frequency{};
 if(!RFGRVR_NativePair_Begin()){
  const bool busy=RFGRVR_NativePair_BuffersBusy();LARGE_INTEGER begin{},end{};if(busy){++busyFallbacks;QueryPerformanceCounter(&begin);}else ++otherFallbacks;
  sceneRender(self,renderer,secondary,scene,camera,a5,a6);
  if(busy){QueryPerformanceCounter(&end);busyCpuTicks+=end.QuadPart-begin.QuadPart;}return;
 }
 RFGRVR_NativePair_TestMode(testMode,restoreMask);
 RFGRVRHumanVisibility::sample(0);
 RFGRVR_PixelProbe_Begin();
 entered=true;++attempted;unsigned before=RFGRVR_HeadCam_HeadSamples();unsigned long long draws[2]{};bool ok=true;
 if(attempted.load()%120==0){
  if(!frequency.QuadPart)QueryPerformanceFrequency(&frequency);wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');
  if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Stereo-Pacing.log");FILE* f=nullptr;if(!_wfopen_s(&f,path,L"a")&&f){fprintf(f,"tick=%llu pairs=%u busyFallbackScenes=%u otherFallbackScenes=%u busySceneCpuMs=%.3f\n",GetTickCount64(),pairs.load(),busyFallbacks,otherFallbacks,1000.0*busyCpuTicks/frequency.QuadPart);fclose(f);}}
 }
 if(attempted==1){char label[64]{};sprintf_s(label,"mode-%u-mask-%08X",testMode,restoreMask);pairStage(label,2);}
 const bool restoreResources=testMode==2||testMode==3||testMode==5||testMode==7||testMode==8||testMode==9||testMode==12||testMode==13;
 const bool restoreCache=testMode==6||testMode==7||testMode==8||testMode==10||testMode==12||testMode==13;
 const bool restorePipeline=testMode==11||testMode==12||testMode==13||testMode==14;
 RFGRVRRendererCache cache[2];
 if(restoreCache){if(!memory(renderer,0x448)||!memory(secondary,0x448))ok=false;else{cache[0].save(renderer);cache[1].save(secondary);}}
 if(restoreResources&&!RFGRVR_EyeResources_Begin(testMode==2||testMode==3?1:2))ok=false;
 if(restorePipeline&&!RFGRVR_EyePipeline_Begin())ok=false;
 for(unsigned eye=0;ok&&eye<2;++eye){
 if(eye){
  void* pools[2]={(void*)(uintptr_t)word(renderer,0x24),(void*)(uintptr_t)word(secondary,0x24)};
  for(auto* pool:pools)if(!memory(pool,16)||!RFGRVR_VertexPoolReady(pool)){ok=false;break;}
  if(!ok){pairStage("vertex-pool-not-ready",eye);break;}
  // The first scene already executed its command list. Reset allocation cursors
  // so the next list starts with WRITE_DISCARD, letting D3D rename the storage.
  for(auto* pool:pools)RFGRVR_VertexPoolRestart(pool);
 }
 if(eye&&restoreResources&&!RFGRVR_EyeResources_Between(restoreMask)){ok=false;break;}
 if(eye&&restorePipeline)RFGRVR_EyePipeline_Between(restoreMask);
 if(eye&&restoreCache){cache[0].restore(renderer,restoreMask);cache[1].restore(secondary,restoreMask);}
 // The paused-view cache must be disabled BEFORE camera preparation too.
 // Otherwise its shader/view constants still describe the frozen first view.
 NativeScopeWorldVision ordinaryVision(memory(scene,0x208)?scene:nullptr);
 RFGRVRMenuWorldScope menuWorld((uint32_t*)((char*)self+0x14),popupWorldMaskVerified&&RFGRVR_HeadCam_PopupMenu()&&memory((char*)self+0x14,4));
 RFGRVRMenuGeometryScope menuGeometry(popupGeometryCache,(uint32_t*)((char*)self+0x50),popupGeometryCache&&RFGRVR_HeadCam_PopupMenu()&&memory((char*)self+0x50,4));
 RFGRVR_NativePair_Select(eye);prepareEyeCameras(camera,renderer,secondary);refreshEyeSky(scene,camera);LocalBodyScope localBodyGeometry;RFGRVR_Arms_RenderWeapon(renderer);recordEyeCameras(eye,camera,renderer,secondary);pairStage("scene-render-begin",eye);auto start=RFGRVR_GPU_DrawCount();
 RFGRVREffectGeometry::select(eye);
 RFGRVREffectViewCache::select(eye);
 RFGRVR_PixelProbe_Select(eye);
 RFGRVR_PairGpuMarker(eye?L"RFGR second scene pass":L"RFGR first scene pass",true);
 RFGRVR_GPUCapture_Mark(50+eye*2,renderer,self);
 // Paused rendering sets the geometry-skip bit again after the first pass.
 // Clear it separately for EACH eye, rather than only around the pair.
 sceneRender(self,renderer,secondary,scene,camera,a5,a6);
 RFGRVRHumanVisibility::sample(eye+1);RFGRVREffectViewCache::select(-1);RFGRVREffectGeometry::eye=-1;RFGRVRBatchTrace::eye=-1;pairStage("scene-render-end",eye);draws[eye]=RFGRVR_GPU_DrawCount()-start;
 RFGRVR_PairGpuMarker(nullptr,false);
 RFGRVR_GPUCapture_Mark(51+eye*2,renderer,self);
 if(!draws[eye]||!RFGRVR_NativePair_Capture(eye)){ok=false;break;}
 }
 // Four reduced-resolution feeds per game frame, after both headset eyes.
 vrarm::Pose auxiliary{};unsigned cameraIndex=0;
 bool apcPasses=false;{AcquireSRWLockShared(&RFGRVRAPC::lock);apcPasses=ok&&continuousMode(testMode)&&(RFGRVRAPC::packet.active&2);ReleaseSRWLockShared(&RFGRVRAPC::lock);}
 auto scopeFrame=vrscope::snapshot();bool scopePass=ok&&continuousMode(testMode)&&!apcPasses&&scopeFrame.alpha>.005f;
 RFGRVRRendererCache apcCache[2];if(apcPasses||scopePass){apcCache[0].save(renderer);apcCache[1].save(secondary);RFGRVR_APC_Pipeline(true);}
 for(unsigned feed=0;feed<(scopePass?2u:4u)&&ok&&continuousMode(testMode)&&(scopePass?(cameraIndex=feed,RFGRVR_Scope_AuxView(feed,&auxiliary)):RFGRVRAPC::next(auxiliary,cameraIndex));++feed){
  void* pools[2]={(void*)(uintptr_t)word(renderer,0x24),(void*)(uintptr_t)word(secondary,0x24)};bool available=true;
  for(auto* pool:pools)available=available&&memory(pool,16)&&RFGRVR_VertexPoolReady(pool);
  if(available){for(auto* pool:pools)RFGRVR_VertexPoolRestart(pool);
   if(restoreResources)available=RFGRVR_EyeResources_Between(restoreMask);
   if(restorePipeline)RFGRVR_EyePipeline_Between(restoreMask);
   if(restoreCache){cache[0].restore(renderer,restoreMask);cache[1].restore(secondary,restoreMask);}
   if(available){
    // Auxiliary cameras are new views, never replays of the headset's cached
    // geometry/impact queue. Restore the borrowed queue after each feed.
    RFGRVRMenuWorldScope auxiliaryWorld((uint32_t*)((char*)self+0x14),popupWorldMaskVerified&&memory((char*)self+0x14,4));
    RFGRVRMenuGeometryScope auxiliaryGeometry(popupGeometryCache,(uint32_t*)((char*)self+0x50),popupGeometryCache&&memory((char*)self+0x50,4));
    apcCache[0].restore(renderer);apcCache[1].restore(secondary);RFGRVR_NativePair_Select(1);if(scopePass)RFGRVR_Scope_AuxSet(&auxiliary);else RFGRVR_APC_AuxSet(&auxiliary);prepareEyeCameras(camera,renderer,secondary);
    RFGRVREffectGeometry::select(1);RFGRVREffectViewCache::select(1);refreshEyeSky(scene,camera);
    // Keep native viewport/ray constants consistent with the auxiliary targets.
    unsigned previousWidth=word(self,0x1f8),previousHeight=word(self,0x1fc);unsigned feedWidth=RFGRAPCTargets::width,feedHeight=RFGRAPCTargets::height;
    memcpy((char*)self+0x1f8,&feedWidth,4);memcpy((char*)self+0x1fc,&feedHeight,4);
    sceneRender(self,renderer,secondary,scene,camera,a5,a6);
    memcpy((char*)self+0x1f8,&previousWidth,4);memcpy((char*)self+0x1fc,&previousHeight,4);RFGRVR_APC_AuxCapture(cameraIndex);
    RFGRVREffectViewCache::select(-1);RFGRVREffectGeometry::eye=-1;RFGRVRBatchTrace::eye=-1;
    if(scopePass)RFGRVR_Scope_AuxSet(nullptr);else RFGRVR_APC_AuxSet(nullptr);
   }
  }
 }
 if(apcPasses||scopePass){RFGRVR_APC_Pipeline(false);apcCache[0].restore(renderer);apcCache[1].restore(secondary);}
 RFGRVR_PixelProbe_End();
 if(restoreResources){char label[96]{};sprintf_s(label,"mode-%u-snapshots-%u-ok-%u",testMode,RFGRVR_EyeResources_Count(),ok?1:0);if(attempted==1||!ok)pairStage(label,2);RFGRVR_EyeResources_End();}
 if(restorePipeline)RFGRVR_EyePipeline_End();
 if(testMode!=0&&!continuousMode(testMode))RFGRVR_NativePair_DiagnosticEnd();else RFGRVR_NativePair_End(ok);
 entered=false;if(!continuousMode(testMode)||attempted==1||!ok)pairStage("scene-pair-ended",2);if(ok){++pairs;retryAfter=0;}else{++failed;retryAfter=GetTickCount64()+100;RFGRVR_NativePair_Continuous(false);}
 report(draws[0],draws[1],before,RFGRVR_HeadCam_HeadSamples(),ok);
 if(!draws[0])sceneRender(self,renderer,secondary,scene,camera,a5,a6);
}
static void __fastcall OnSceneRender(void* self,void*,void* renderer,void* secondary,void* scene,void* camera,void* a5,void* a6){
 vrmemory::Scope memoryScope;
 if(auto* b=vrsettings::bus()){if(InterlockedExchange(&b->recalibrated,0))RFGRVR_Temporal_Recenter();InterlockedExchange(&b->gamePid,GetCurrentProcessId());InterlockedExchange(&b->pauseTick,RFGRVR_HeadCam_PopupMenu()?LONG(GetTickCount()):0);InterlockedExchange(&b->pauseMenuTick,RFGRVR_HeadCam_PauseMenu()?LONG(GetTickCount()):0);}
 if(!entered)pollTestMode();
 auto* base=(unsigned char*)GetModuleHandleW(nullptr);void* mainScene=(void*)(uintptr_t)word(base,0x2133894);
 bool want=!entered&&requested()&&canAttemptPair(GetTickCount64())&&(RFGRVR_HeadCam_HeadSamples()>120||RFGRVR_HeadCam_MenuScene())&&scene==mainScene&&self==(void*)(uintptr_t)word(scene,0x13c)&&memory(camera,0x598)&&memory(renderer,0x480);
 if(!entered&&scene==mainScene)RFGRVR_NativePair_Continuous(continuousMode(testMode)&&want);
 RFGRVR_NativePair_SetRequested(want);
 if(!want){sceneRender(self,renderer,secondary,scene,camera,a5,a6);return;}
 RFGRVRMenuWorldScope menuWorld((uint32_t*)((char*)self+0x14),popupWorldMaskVerified&&RFGRVR_HeadCam_PopupMenu()&&memory((char*)self+0x14,4));
 runScenePair(self,renderer,secondary,scene,camera,a5,a6);
}
static void __fastcall OnPrepare(void* camera,void* edx,void* renderer){
 float projection[16]{},fov=0;auto* c=(unsigned char*)camera;
 if(RFGRVR_APC_AuxProjection(camera,projection,&fov)&&memory(c+0x140,4)&&memory(renderer,0x47c)){
  float saved=0;memcpy(&saved,c+0x140,4);memcpy(c+0x140,&fov,4);prepare(camera,edx,renderer);memcpy(c+0x140,&saved,4);
  void* state=(void*)(uintptr_t)word(renderer,0x478);if(memory(c+0xc0,64)&&memory((char*)state+0x440,64)){memcpy(c+0xc0,projection,64);memcpy((char*)state+0x440,projection,64);updateMatrices(state);updateRenderer(renderer);}return;
 }

 const bool eye=RFGRVR_NativePair_Projection(camera,projection,&fov)&&memory(c+0x140,4)&&memory(renderer,0x47c);
 const bool compatible=!eye&&RFGRVR_NativePair_CompatibilityFov(camera,&fov)&&memory(c+0x140,4);
 // The stable temporal path uses a symmetric source image, not a per-eye projection.
 const bool exactTemporal=false;
 const bool temporal=!compatible&&(exactTemporal||(!eye&&memory(c+0x140,4)&&RFGRVR_Temporal_OpticsFov(camera,&fov)));
 float saved=0;if(eye||temporal||compatible){RFGRVR_HeadCam_RenderFov(fov);memcpy(&saved,c+0x140,4);memcpy(c+0x140,&fov,4);}
 const bool held=(temporal||compatible)&&RFGRVR_Temporal_HoldFov(camera,saved,fov);
 prepare(camera,edx,renderer);
 if(eye||((temporal||compatible)&&!held))memcpy(c+0x140,&saved,4);
 if(compatible){RFGRVR_NativePair_CompatibilityApplied(camera);return;}
 if(!eye&&!exactTemporal){if(temporal)RFGRVR_Temporal_OpticsApplied(camera);return;}
 void* state=nullptr;memcpy(&state,(unsigned char*)renderer+0x478,4);
 if(!memory(c+0xc0,64)||!memory((unsigned char*)state+0x440,64)){if(temporal)RFGRVR_Temporal_OpticsApplied(camera);return;}
 // The original just generated conservative frusta from the encompassing FOV.
 // Replace the render projection after preparation, then refresh derived state.
 memcpy(c+0xc0,projection,64);memcpy((unsigned char*)state+0x440,projection,64);
 updateMatrices(state);updateRenderer(renderer);if(eye)RFGRVR_NativePair_ProjectionApplied();if(temporal)RFGRVR_Temporal_OpticsApplied(camera);
}
}
// This final-frame step captures pixels only. It must never reenter rendering:
// native renderer+440 has already been cleared by frame cleanup here.
extern "C" void RFGRVR_MapWorld_Present(IDXGISwapChain* swap){if(mapWorldGateVerified&&RFGRVR_HeadCam_MapMenu())RFGRVR_CaptureMapPanel(swap);}
static void installReport(const char* stage,MH_STATUS status=MH_OK){
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Scene-Hook-Install.log");FILE* f=nullptr;if(!_wfopen_s(&f,path,L"a")&&f){fprintf(f,"%s status=%d\n",stage,(int)status);fclose(f);}
}
extern "C" bool RFGRVR_ResizeRenderBuffersOnOwner(unsigned width,unsigned height){
 auto* window=renderBufferWindow.load(std::memory_order_acquire);
 if(!window||!resizeRenderBuffers||GetCurrentThreadId()!=renderBufferThread.load()||!width||!height)return false;
 if(renderBufferResizing)return false;
 if(renderBufferWidth==width&&renderBufferHeight==height)return true;
 RenderResizeScope resizeScope;
 RFGRVR_APC_BeforeResize();bool ok=resizeRenderBuffers(window,width,height);
 if(ok){renderBufferWidth=width;renderBufferHeight=height;}return ok;
}
extern "C" bool RFGRVR_NativeScene_Install(){
 auto* b=(unsigned char*)GetModuleHandleW(nullptr);
 const unsigned char visionWriteSig[]={0xc6,0x05};unsigned visionAddress=0;
 memcpy(&visionAddress,b+0x3c2f90,4);
 const unsigned char visionDescriptorSig[]={0x81,0xc7,0xb8,0x01,0,0};
 if(!memcmp(b+0x3d080c,visionDescriptorSig,sizeof(visionDescriptorSig))&&!memcmp(b+0x3c2f8e,visionWriteSig,2)&&visionAddress==(unsigned)(uintptr_t)(b+0x21338a7)&&b[0x3c2f94]==1)nativeScopeVision=b+0x21338a7;
 const unsigned char menuMaskSig[]={0x8b,0x53,0x14,0xd1,0xea,0xf6,0xc2,0x01,0x0f,0x85};
 const unsigned char snapshotRouteSig[]={0xf6,0x45,0x14,0x01};
 const unsigned char snapshotCaptureSig[]={0x83,0x4e,0x14,0x02};
 popupWorldMaskVerified=b&&!memcmp(b+0x16217e,menuMaskSig,sizeof(menuMaskSig))&&
  !memcmp(b+0x161337,snapshotRouteSig,sizeof(snapshotRouteSig))&&
  !memcmp(b+0x10ad98,snapshotCaptureSig,sizeof(snapshotCaptureSig));
 // These operands are relocated by ASLR; compare against this process's base.
 if(popupWorldMaskVerified&&RFGRVRMenuGeometrySignature(b+0x16218c,b+0x1629f0,(unsigned)(uintptr_t)(b+0x177bd1b),(unsigned)(uintptr_t)(b+0x177bd18)))popupGeometryCache=b+0x177bd18;
 const unsigned char mapGateSig[]={0x80,0x7c,0x24,0x34,0,0xbb,4,0,0,0,0x74,0x14};
 mapWorldGateVerified=!memcmp(b+0x3cfb2f,mapGateSig,sizeof(mapGateSig));
 const unsigned char renderSig[]={0x8b,0x44,0x24,0x0c,0x8b,0x4c,0x24,0x08,0x57};
 const unsigned char prepareSig[]={0x83,0xec,0x2c,0x53,0x55,0x56,0x57};
 const unsigned char sceneSig[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x81,0xec,0xc4,5,0,0};
 if(!b||memcmp(b+0x3d0a90,renderSig,sizeof(renderSig))||memcmp(b+0x120d70,prepareSig,sizeof(prepareSig))||memcmp(b+0x161d20,sceneSig,sizeof(sceneSig))){installReport("signature-rejected");return false;}
 const unsigned char switchSig[]={0x83,0xec,0x44,0xa1};
 if(memcmp(b+0x86ddd0,switchSig,sizeof(switchSig))||b[0x86dde6]!=0x53||b[0x86dde7]!=0x55){installReport("resolution-signature-rejected");return false;}
 const unsigned char effectsSig[]={0x81,0xec,0xa0,0,0,0};
 if(memcmp(b+0x129f80,effectsSig,sizeof(effectsSig))){installReport("effects-signature-rejected");return false;}
 const unsigned char viewEffectSig[]={0x81,0xec,0xdc,0,0,0};
 if(memcmp(b+0x12a9f0,viewEffectSig,sizeof(viewEffectSig))){installReport("effect-view-signature-rejected");return false;}
 const unsigned char bloomSourceSig[]={0x83,0xec,0x38,0x8b,0x15};
 const unsigned char bloomExposureSig[]={0x8b,0x44,0x24,0x10,0x83,0xec,0x38};
 if(memcmp(b+0x13d4c0,bloomSourceSig,sizeof(bloomSourceSig))||memcmp(b+0x13b9a0,bloomExposureSig,sizeof(bloomExposureSig))){installReport("bloom-source-signature-rejected");return false;}
 // Independently verify stack cleanup: source has SEVEN stack arguments;
 // exposure has SIX. Sharing their function type corrupts the caller stack.
 const unsigned char bloomSourceReturn[]={0xc2,0x1c,0};
 const unsigned char bloomExposureReturn[]={0xc2,0x18,0};
 if(memcmp(b+0x13d78e,bloomSourceReturn,3)||memcmp(b+0x13c6fd,bloomExposureReturn,3)||memcmp(b+0x13c719,bloomExposureReturn,3)){installReport("bloom-calling-convention-rejected");return false;}
 RFGRVRBloomViewCache::manager=(void**)(b+0x1637910);
 RFGRVREffectViewCache::frame=(unsigned*)(b+0x177bcf8);
 const unsigned char resizeSig[]={0x53,0x8b,0x5c,0x24,0x0c,0x57};
 if(memcmp(b+0x86ab20,resizeSig,sizeof(resizeSig))){installReport("render-resize-signature-rejected");return false;}
 updateMatrices=(Update)(b+0xd24d0);updateRenderer=(Update)(b+0xf2500);cameraBegin=(CameraBegin)(b+0x137660);
 struct Hook {unsigned rva;void* detour;void** original;const char* name;};
 const unsigned char skySig[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x81,0xec,0xb8,0x01,0,0};
 if(memcmp(b+0x66bc90,skySig,sizeof(skySig))){installReport("sky-signature-rejected");return false;}skyRefresh=(SkyRefresh)(b+0x66bc90);
 const unsigned char cameraGetter[]={0xa1,0x94,0x38,0x53,0x02,0x85,0xc0,0x75,0x01,0xc3};
 // Compare the relocated absolute scene address separately from instructions.
 skyCameraVerified=b[0x3c2960]==0xa1&&word(b,0x3c2961)==(unsigned)(uintptr_t)(b+0x2133894)&&!memcmp(b+0x3c2965,cameraGetter+5,5);
 const unsigned char sunSig[]={0x81,0xec,0x88,0,0,0};if(memcmp(b+0x1193a0,sunSig,sizeof(sunSig))||b[0x119665]!=0xc2||word(b,0x119666)%65536!=8){installReport("sun-sprite-signature-rejected");return false;}sunObject=(void**)(b+0x18d2708);
 const unsigned char compositeSig[]={0x81,0xec,0xc0,1,0,0},sunInputSig[]={0x8b,0x87,0x78,9,0,0},shaftInputSig[]={0x8b,0x87,0xac,0x0a,0,0};if(memcmp(b+0x13d7a0,compositeSig,sizeof(compositeSig))||memcmp(b+0x13da5b,sunInputSig,sizeof(sunInputSig))||memcmp(b+0x13dfe3,shaftInputSig,sizeof(shaftInputSig))||b[0x13e300]!=0xc2||word(b,0x13e301)%65536!=0x24){installReport("sun-composite-signature-rejected");return false;}
 // Both the visibility pass and sun-shaft generation test this relocated flag.
 const unsigned gateRvas[]={0x1351d8,0x13535c,0x146047};for(unsigned rva:gateRvas)if(b[rva]!=0x80||b[rva+1]!=0x3d||word(b,rva+2)!=(unsigned)(uintptr_t)(b+0x10fa527)||b[rva+6]!=0){installReport("sun-generation-switch-rejected");return false;}sunGeneration=b+0x10fa527;
 const unsigned char lensSig[]={0x83,0xec,0x40,0x57,0x8b,0xf9};if(memcmp(b+0x13f8c0,lensSig,sizeof(lensSig))||b[0x13fa70]!=0xc2||word(b,0x13fa71)%65536!=8){installReport("lens-flare-signature-rejected");return false;}
 Hook hooks[]={{0x13f8c0,(void*)&vrglare::onLens,(void**)&vrglare::lens,"vr-lens-ghosts"},{0x13d7a0,(void*)&vrglare::onComposite,(void**)&vrglare::composite,"vr-sun-composite"},{0x1193a0,(void*)&onSunSprite,(void**)&sunSprite,"vr-sun-glare"},{0x13d4c0,(void*)&RFGRVRBloomViewCache::onDownsample,(void**)&RFGRVRBloomViewCache::downsample,"bloom-eye-source"},{0x13b9a0,(void*)&RFGRVRBloomViewCache::onAdaptation,(void**)&RFGRVRBloomViewCache::adaptation,"bloom-shared-exposure"},{0x120d70,(void*)&OnPrepare,(void**)&prepare,"camera-optics"},{0x161d20,(void*)&OnSceneRender,(void**)&sceneRender,"scene-stereo"},{0x3d0a90,(void*)&OnRender,(void**)&render,"outer-once"},{0x86ddd0,(void*)&OnSwitchResolution,(void**)&switchResolution,"resolution-switch"},{0x86ab20,(void*)&OnResizeRenderBuffers,(void**)&resizeRenderBuffers,"render-buffer-resize"},{0x129f80,(void*)&RFGRVREffectGeometry::onRender,(void**)&RFGRVREffectGeometry::render,"effects-geometry-stereo"},{0x12a9f0,(void*)&RFGRVREffectViewCache::onRender,(void**)&RFGRVREffectViewCache::render,"effects-view-cache"}};
 unsigned created=0;
 for(auto& hook:hooks){MH_STATUS result=MH_CreateHook(b+hook.rva,hook.detour,hook.original);if(result!=MH_OK){installReport(hook.name,result);for(unsigned i=0;i<created;++i)MH_RemoveHook(b+hooks[i].rva);return false;}++created;}
 for(auto& hook:hooks){MH_STATUS result=MH_EnableHook(b+hook.rva);if(result!=MH_OK){installReport(hook.name,result);for(auto& undo:hooks){MH_DisableHook(b+undo.rva);MH_RemoveHook(b+undo.rva);}return false;}}
 installReport(RFGRVRWristMapTrace::install()?"wrist-map-native-routing-installed":"wrist-map-routing-unavailable");
 installReport(RFGRVRHudHeading::install()?"map-stable-vr-heading-installed":"map-stable-heading-unavailable");
 installReport(RFGRVRNativeDust::install(b)?"ambient-dust-worldspace-depth-installed":"ambient-dust-correction-unavailable");
 vrcoronadepth::enabled=true;installReport("scene-stereo-and-optics-installed");return true;
}












