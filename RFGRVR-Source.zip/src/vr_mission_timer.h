#pragma once
#include "vr_memory_access.h"
#include <cstring>
namespace vrmissiontimer {
inline constexpr unsigned Group=0x2ac6d903u,Icon=0xf166e650u,Number=0x36d291c1u;
inline unsigned word(const void* p,unsigned off){unsigned v=0;if(vrmemory::check((const char*)p+off,4))memcpy(&v,(const char*)p+off,4);return v;}
// Verified live native hierarchy: icon and countdown are siblings in this
// container. The same number is reused for non-timer mission statistics.
inline bool active(const void* group){if(!group||word(group,0x24)!=Group)return false;unsigned doc=word(group,0x28);bool icon=false,number=false;auto* child=(void*)(uintptr_t)word(group,0x14);
 for(unsigned n=0;child&&n<16;++n){if(!vrmemory::check(child,0x16d)||word(child,0x1c)!=(uintptr_t)group||word(child,0x28)!=doc)return false;unsigned char visible=*((unsigned char*)child+0x16c);unsigned hash=word(child,0x24);if(visible&&hash==Icon)icon=true;if(visible&&hash==Number)number=true;child=(void*)(uintptr_t)word(child,0x18);}
 return icon&&number;
}
}
