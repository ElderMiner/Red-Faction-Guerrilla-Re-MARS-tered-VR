#pragma once
#include "vr_mission_timer.h"
#include "vr_arm_math.h"
namespace vrmissiontracker {
inline constexpr unsigned Group=0x46cf9b3bu,Score=0x1bb673efu,CanvasHeight=640,Top=512,Height=128;
inline bool active(const void* group){using vrmissiontimer::word;
 if(!group||word(group,0x24)!=Group||!vrmemory::check(group,0x16d)||!*((const unsigned char*)group+0x16c))return false;
 unsigned doc=word(group,0x28);if(!doc)return false;const char* name=(const char*)(uintptr_t(doc)+9);constexpr char expected[]="rfg_ui_hud_missions";
 if(!vrmemory::check(name,sizeof(expected))||memcmp(name,expected,sizeof(expected)))return false;
 bool score=false;auto* child=(void*)(uintptr_t)word(group,0x14);for(unsigned n=0;child&&n<32;++n){
  if(!vrmemory::check(child,0x16d)||word(child,0x1c)!=(uintptr_t)group||word(child,0x28)!=doc)return false;
  if(word(child,0x24)==Score&&*((const unsigned char*)child+0x16c))score=true;child=(void*)(uintptr_t)word(child,0x18);
 }return !child&&score;
}
inline bool aboveTimer(float x,float y,float w,float h,float mapScale,vrarm::V& offset,float& width,float& height){
 if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(w)||!std::isfinite(h)||!std::isfinite(mapScale)||w<=0||h<=0||mapScale<=0)return false;
 float unit=.17f/512.f*mapScale;width=w*unit;height=h*unit;offset={(x+w*.5f-384.f)*unit,(512.f-y+h*.625f)*unit,0};
 return vrarm::finite(offset)&&std::isfinite(width)&&std::isfinite(height)&&width>0&&height>0;
}
}
