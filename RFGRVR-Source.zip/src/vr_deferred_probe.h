#pragma once
#include "com_method_count.h"
#include "vr_pixel_probe.h"
#include <atomic>
#include <cstring>
#include "apc_render_targets.h"
#include "vr_corona_depth.h"
#include "vr_cone_trace.h"
#include "modern_lighting.h"
#include "modern_height_catalog.h"
namespace RFGRVRDeferredProbe {
using FinishNotice=void(*)(ID3D11DeviceContext*);inline std::atomic<FinishNotice> finishNotice{nullptr};
// Per-object originals: immediate and deferred contexts need not share an
// implementation. Shadow storage lives until process exit; it retains no COM
// objects and therefore cannot keep a retired render target alive.
struct Entry {void* object;void** original;void** shadow;size_t count,copyCount;bool modern=false,baselineBound=false;Microsoft::WRL::ComPtr<ID3D11PixelShader> requestedShader;uint64_t lightingEpoch=0,heightEpoch=0;unsigned normalBase=0,normalCount=0;bool heightDirty=true;uint64_t materialEpoch=0;bool materialDirty=true;unsigned albedo[4]{},albedoCount=0;ID3D11ShaderResourceView* nativeViews[16]{};};
inline std::atomic<Entry*> contexts[128]{},devices[32]{};
template<size_t N> inline Entry* find(std::atomic<Entry*> (&entries)[N],void* object){if(!object)return nullptr;auto table=*(void***)object;for(auto& slot:entries){auto* e=slot.load(std::memory_order_acquire);if(e&&e->object==object&&e->shadow==table)return e;}return nullptr;}
template<size_t N> inline Entry* prepare(std::atomic<Entry*> (&entries)[N],void* object,size_t count){
 if(find(entries,object))return nullptr;auto* old=*(void***)object;MEMORY_BASIC_INFORMATION m{};if(!VirtualQuery(old,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_NOACCESS|PAGE_GUARD))||(uintptr_t)old+count*sizeof(void*)>(uintptr_t)m.BaseAddress+m.RegionSize)return nullptr;
 // Direct3D's own helpers can call private tail entries on the public device
 // pointer (the captured crash used slot 69, just past ID3D11Device5).
 // Preserve a bounded readable tail; public count still controls which slots
 // may be replaced. Preserve RTTI metadata when it is readable as well.
 const size_t available=((uintptr_t)m.BaseAddress+m.RegionSize-(uintptr_t)old)/sizeof(void*);
 const size_t copyCount=(std::max)(count,(std::min)(size_t(512),available));
 auto* allocation=(void**)VirtualAlloc(nullptr,(copyCount+1)*sizeof(void*),MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);if(!allocation)return nullptr;auto* copy=allocation+1;
 MEMORY_BASIC_INFORMATION prior{};if(VirtualQuery(old-1,&prior,sizeof(prior))&&prior.State==MEM_COMMIT&&!(prior.Protect&(PAGE_NOACCESS|PAGE_GUARD)))copy[-1]=old[-1];
 memcpy(copy,old,copyCount*sizeof(void*));auto* e=new Entry{object,old,copy,count,copyCount};
 for(auto& slot:entries){Entry* empty=nullptr;if(slot.compare_exchange_strong(empty,e,std::memory_order_release))return e;}
 VirtualFree(allocation,0,MEM_RELEASE);delete e;return nullptr;
}
inline bool publish(Entry* e){return e&&InterlockedCompareExchangePointer((PVOID volatile*)e->object,e->shadow,e->original)==e->original;}
inline void log(const char* label,void* object,unsigned value){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,92);if(!slash)return;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-Deferred-Contexts.log");FILE* f=nullptr;if(!fopen_s(&f,path,"a")&&f){fprintf(f,"%s object=%p value=%u\n",label,object,value);fclose(f);}}
template<unsigned Slot,class... Args> inline void invoke(ID3D11DeviceContext* c,Args... args){auto* e=find(contexts,c);if(e)((void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,Args...))e->original[Slot])(c,args...);}
inline void sample(ID3D11DeviceContext* c,unsigned kind,unsigned count,unsigned instances=0,unsigned start=0,unsigned base=0,ID3D11RenderTargetView* cleared=nullptr){RFGRVRPixelProbe::record(c,kind,count,instances,start,base,cleared,true);}
inline void lighting(ID3D11DeviceContext* c){auto* e=find(contexts,c);if(!e)return;if(e->requestedShader){bool baseline=modernlight::bypass.load();if(baseline!=e->baselineBound){auto original=baseline?modernlight::originalShader(e->requestedShader.Get()):Microsoft::WRL::ComPtr<ID3D11PixelShader>{};invoke<9>(c,original?original.Get():e->requestedShader.Get(),(ID3D11ClassInstance*const*)nullptr,UINT(0));e->baselineBound=baseline;}}if(!e->modern||modernlight::bypass.load())return;auto epoch=modernmaterial::worldEpoch.load(std::memory_order_acquire);if(epoch&&epoch!=e->lightingEpoch)e->lightingEpoch=modernmaterial::applyWorld(c);if(epoch&&e->albedoCount&&(e->materialDirty||e->materialEpoch!=epoch)){ID3D11ShaderResourceView* sources[4]{};for(unsigned i=0;i<e->albedoCount;++i)sources[i]=e->nativeViews[e->albedo[i]];if(modernmaterial::applyMaterialMaps(c,sources,e->albedoCount)){e->materialEpoch=epoch;e->materialDirty=false;}}if(epoch&&e->normalCount&&(e->heightDirty||e->heightEpoch!=epoch)){if(modernmaterial::applyHeights(c,e->nativeViews+e->normalBase,e->normalCount)){e->heightEpoch=epoch;e->heightDirty=false;}}}
inline void STDMETHODCALLTYPE setPixelShader(ID3D11DeviceContext* c,ID3D11PixelShader* shader,ID3D11ClassInstance*const* classes,UINT count){if(auto* e=find(contexts,c)){int mode=modernmaterial::mode(shader);e->requestedShader=mode>=0?shader:nullptr;e->baselineBound=modernlight::bypass.load();e->modern=mode>=0;unsigned indices[4]{},albedoCount=0;
 if(mode>=500&&unsigned(mode-500)<sizeof(moderngenerated::variants)/sizeof(moderngenerated::variants[0])){auto& v=moderngenerated::variants[mode-500].values;int type=atoi(v[0]);if(type==2||type==5){albedoCount=unsigned(atoi(v[2]));unsigned start=type==5?4:unsigned(atoi(v[4]));for(unsigned i=0;i<albedoCount&&i<4;++i)indices[i]=start+i;}else if(type==3){albedoCount=2;indices[1]=2;}else if(type!=4)albedoCount=1;}
 else if(mode==100||mode==101){albedoCount=4;for(unsigned i=0;i<4;++i)indices[i]=4+i;}
 else if(mode>=200&&unsigned(mode-200)<sizeof(modernsurface::variants)/sizeof(modernsurface::variants[0])){albedoCount=1;indices[0]=unsigned(atoi(modernsurface::variants[mode-200].values[3]+1));}
 else if(mode==400||mode==401)albedoCount=1;else if(mode>=0&&unsigned(mode)<sizeof(modernlight::variants)/sizeof(modernlight::variants[0])){albedoCount=1;indices[0]=unsigned(atoi(modernlight::variants[mode].diffT+1));}
 if(albedoCount>4)albedoCount=0;for(unsigned i=0;i<albedoCount;++i)if(indices[i]>=16){albedoCount=0;break;}if(albedoCount!=e->albedoCount||memcmp(indices,e->albedo,sizeof(indices)))e->materialDirty=true;e->albedoCount=albedoCount;memcpy(e->albedo,indices,sizeof(indices));unsigned base=0,count=0;if(mode>=500&&unsigned(mode-500)<sizeof(moderngenerated::variants)/sizeof(moderngenerated::variants[0])){auto& values=moderngenerated::variants[mode-500].values;int type=atoi(values[0]);if(type==2||type==5){base=unsigned(atoi(values[3]));count=unsigned(atoi(values[2]));}}if(mode==100||mode==101){base=0;count=4;}if(base+count>16||count>4)count=0;if(base!=e->normalBase||count!=e->normalCount)e->heightDirty=true;e->normalBase=base;e->normalCount=count;}auto original=modernlight::bypass.load()?modernlight::originalShader(shader):Microsoft::WRL::ComPtr<ID3D11PixelShader>{};invoke<9>(c,original?original.Get():shader,classes,count);}
inline void STDMETHODCALLTYPE clearState(ID3D11DeviceContext* c){if(auto* e=find(contexts,c)){e->requestedShader.Reset();e->modern=false;e->lightingEpoch=e->heightEpoch=e->materialEpoch=0;e->heightDirty=e->materialDirty=true;memset(e->nativeViews,0,sizeof(e->nativeViews));}invoke<110>(c);}
inline void STDMETHODCALLTYPE draw(ID3D11DeviceContext* c,UINT n,UINT start){lighting(c);vrconetrace::draw(c);RFGRAPCTargets::geometry(c,n);invoke<13>(c,n,start);sample(c,1,n,0,start);}
inline void STDMETHODCALLTYPE indexed(ID3D11DeviceContext* c,UINT n,UINT start,INT base){lighting(c);vrconetrace::draw(c);RFGRAPCTargets::geometry(c,n);if(vrcoronadepth::drawing){vrcoronadepth::DepthGuard glow(c);invoke<12>(c,n,start,base);}else invoke<12>(c,n,start,base);RFGRVRPixelProbe::instancedSite(c,n,402);sample(c,2,n,0,start,unsigned(base));}
inline void STDMETHODCALLTYPE instanced(ID3D11DeviceContext* c,UINT n,UINT instances,UINT start,UINT first){lighting(c);vrconetrace::draw(c);RFGRAPCTargets::geometry(c,uint64_t(n)*instances);invoke<21>(c,n,instances,start,first);sample(c,3,n,instances,start,first);}
inline void STDMETHODCALLTYPE indexedInstanced(ID3D11DeviceContext* c,UINT n,UINT instances,UINT start,INT base,UINT first){lighting(c);vrconetrace::draw(c);RFGRAPCTargets::geometry(c,uint64_t(n)*instances);invoke<20>(c,n,instances,start,base,first);RFGRVRPixelProbe::instancedSite(c,n);sample(c,4,n,instances,start,unsigned(base));}
inline void STDMETHODCALLTYPE automatic(ID3D11DeviceContext* c){lighting(c);vrconetrace::draw(c);RFGRAPCTargets::geometry(c,64);invoke<38>(c);sample(c,38,0);}
inline void STDMETHODCALLTYPE indexedIndirect(ID3D11DeviceContext* c,ID3D11Buffer* b,UINT offset){lighting(c);vrconetrace::draw(c);RFGRAPCTargets::geometry(c,64);invoke<39>(c,b,offset);sample(c,39,offset);}
inline void STDMETHODCALLTYPE instancedIndirect(ID3D11DeviceContext* c,ID3D11Buffer* b,UINT offset){lighting(c);vrconetrace::draw(c);RFGRAPCTargets::geometry(c,64);invoke<40>(c,b,offset);sample(c,40,offset);}
inline void STDMETHODCALLTYPE dispatch(ID3D11DeviceContext* c,UINT x,UINT y,UINT z){invoke<41>(c,x,y,z);sample(c,41,x,y,z);}
inline void STDMETHODCALLTYPE dispatchIndirect(ID3D11DeviceContext* c,ID3D11Buffer* b,UINT offset){invoke<42>(c,b,offset);sample(c,42,offset);}
inline void STDMETHODCALLTYPE clearRT(ID3D11DeviceContext* c,ID3D11RenderTargetView* v,const FLOAT* color){invoke<50>(c,v,color);sample(c,12,0,0,0,0,v);}
inline void STDMETHODCALLTYPE clearDS(ID3D11DeviceContext* c,ID3D11DepthStencilView* v,UINT flags,FLOAT depth,UINT8 stencil){invoke<53>(c,v,flags,depth,stencil);vrcoronadepth::recordClear(v,flags,depth);sample(c,13,flags,stencil);}
inline HRESULT STDMETHODCALLTYPE finish(ID3D11DeviceContext* c,BOOL restore,ID3D11CommandList** list){auto* e=find(contexts,c);if(!e)return E_FAIL;auto hr=((HRESULT(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,BOOL,ID3D11CommandList**))e->original[114])(c,restore,list);if(!restore){e->requestedShader.Reset();e->modern=false;e->lightingEpoch=e->heightEpoch=e->materialEpoch=0;e->heightDirty=e->materialDirty=true;memset(e->nativeViews,0,sizeof(e->nativeViews));}if(auto notice=finishNotice.load())notice(c);RFGRVRPixelProbe::note(114,c,SUCCEEDED(hr)&&list?*list:nullptr,restore);return hr;}
inline HRESULT STDMETHODCALLTYPE map(ID3D11DeviceContext* c,ID3D11Resource* resource,UINT sub,D3D11_MAP type,UINT flags,D3D11_MAPPED_SUBRESOURCE* out){
 auto* e=find(contexts,c);if(!e)return E_FAIL;
 auto hr=((HRESULT(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11Resource*,UINT,D3D11_MAP,UINT,D3D11_MAPPED_SUBRESOURCE*))e->original[14])(c,resource,sub,type,flags,out);
 if(FAILED(hr))RFGRVRPixelProbe::note(140+unsigned(type),c,resource,unsigned(hr));
 return hr;
}
inline void STDMETHODCALLTYPE pixelBuffers(ID3D11DeviceContext* c,UINT start,UINT count,ID3D11Buffer*const* buffers){if(auto* e=find(contexts,c)){if(start<=13&&start+count>13)e->lightingEpoch=0;if(start<=12&&start+count>12)e->heightEpoch=0;}invoke<16>(c,start,count,buffers);}
inline void STDMETHODCALLTYPE pixelResources(ID3D11DeviceContext* c,UINT start,UINT count,ID3D11ShaderResourceView*const* views){if(auto* e=find(contexts,c)){if(start<21&&start+count>16)e->lightingEpoch=0;if(start<25&&start+count>21)e->heightEpoch=0;if(start<29&&start+count>25)e->materialEpoch=0;for(unsigned i=0;i<count&&start+i<16;++i){auto* value=views?views[i]:nullptr;if(e->nativeViews[start+i]!=value&&start+i>=e->normalBase&&start+i<e->normalBase+e->normalCount)e->heightDirty=true;if(e->nativeViews[start+i]!=value)for(unsigned k=0;k<e->albedoCount;++k)if(e->albedo[k]==start+i)e->materialDirty=true;e->nativeViews[start+i]=value;}}invoke<8>(c,start,count,views);}
inline bool attachContext(ID3D11DeviceContext* c){
 if(!c||c->GetType()!=D3D11_DEVICE_CONTEXT_DEFERRED)return false;auto* e=prepare(contexts,c,RFGRVR_ContextMethods(c));if(!e)return find(contexts,c)!=nullptr;
 e->shadow[9]=(void*)&setPixelShader;e->shadow[16]=(void*)&pixelBuffers;e->shadow[8]=(void*)&pixelResources;e->shadow[110]=(void*)&clearState;
 e->shadow[12]=(void*)&indexed;e->shadow[13]=(void*)&draw;e->shadow[20]=(void*)&indexedInstanced;e->shadow[21]=(void*)&instanced;e->shadow[38]=(void*)&automatic;e->shadow[39]=(void*)&indexedIndirect;e->shadow[40]=(void*)&instancedIndirect;e->shadow[41]=(void*)&dispatch;e->shadow[42]=(void*)&dispatchIndirect;e->shadow[50]=(void*)&clearRT;e->shadow[53]=(void*)&clearDS;e->shadow[114]=(void*)&finish;
 e->shadow[14]=(void*)&map;
 RFGRAPCTargets::attach(c,e->shadow,unsigned(e->count));
 bool ok=publish(e);log(ok?"deferred-attached":"deferred-attach-failed",c,unsigned(e->count));return ok;
}
template<unsigned Slot> inline HRESULT STDMETHODCALLTYPE create(void* d,UINT flags,void** context){auto* e=find(devices,d);if(!e)return E_FAIL;auto hr=((HRESULT(STDMETHODCALLTYPE*)(void*,UINT,void**))e->original[Slot])(d,flags,context);if(SUCCEEDED(hr)&&context&&*context)attachContext((ID3D11DeviceContext*)*context);return hr;}
inline size_t deviceMethods(ID3D11Device* d){if(RFGRVR_SameInterface<ID3D11Device5>(d))return 69;if(RFGRVR_SameInterface<ID3D11Device4>(d))return 67;if(RFGRVR_SameInterface<ID3D11Device3>(d))return 65;if(RFGRVR_SameInterface<ID3D11Device2>(d))return 54;if(RFGRVR_SameInterface<ID3D11Device1>(d))return 50;return 43;}
inline HRESULT STDMETHODCALLTYPE vertexShader(ID3D11Device* d,const void* bytes,SIZE_T size,ID3D11ClassLinkage* linkage,ID3D11VertexShader** shader){auto* e=find(devices,d);if(!e)return E_FAIL;auto hr=((HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11VertexShader**))e->original[12])(d,bytes,size,linkage,shader);if(SUCCEEDED(hr)&&shader&&*shader){vrconetrace::tag(*shader,bytes,size);if(modernlight::transportEnabled())moderngeometrycapture::tagVertex(*shader,bytes,size);}return hr;}
inline HRESULT STDMETHODCALLTYPE inputLayout(ID3D11Device* d,const D3D11_INPUT_ELEMENT_DESC* elements,UINT count,const void* code,SIZE_T size,ID3D11InputLayout** layout){auto* e=find(devices,d);if(!e)return E_FAIL;using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const D3D11_INPUT_ELEMENT_DESC*,UINT,const void*,SIZE_T,ID3D11InputLayout**);auto hr=((Create)e->original[11])(d,elements,count,code,size,layout);if(SUCCEEDED(hr)&&layout&&*layout&&modernlight::transportEnabled())moderngeometrycapture::tagLayout(*layout,elements,count);return hr;}
inline HRESULT STDMETHODCALLTYPE pixelShader(ID3D11Device* d,const void* bytes,SIZE_T count,ID3D11ClassLinkage* linkage,ID3D11PixelShader** shader){auto* entry=find(devices,d);if(!entry)return E_FAIL;return modernlight::create((modernlight::Create)entry->original[15],d,bytes,count,linkage,shader,modernlight::available());}
inline HRESULT STDMETHODCALLTYPE texture2D(ID3D11Device* d,const D3D11_TEXTURE2D_DESC* desc,const D3D11_SUBRESOURCE_DATA* data,ID3D11Texture2D** out){auto* e=find(devices,d);if(!e)return E_FAIL;using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const D3D11_TEXTURE2D_DESC*,const D3D11_SUBRESOURCE_DATA*,ID3D11Texture2D**);auto hr=((Create)e->original[5])(d,desc,data,out);if(SUCCEEDED(hr)&&desc&&out&&*out&&modernlight::transportEnabled()){modernheight::catalogue.attach(d,*out,*desc,data);modernheight::materialCatalogue.attach(d,*out,*desc,data);}return hr;}
inline HRESULT STDMETHODCALLTYPE shaderView(ID3D11Device* d,ID3D11Resource* resource,const D3D11_SHADER_RESOURCE_VIEW_DESC* desc,ID3D11ShaderResourceView** out){auto* e=find(devices,d);if(!e)return E_FAIL;using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,ID3D11Resource*,const D3D11_SHADER_RESOURCE_VIEW_DESC*,ID3D11ShaderResourceView**);auto hr=((Create)e->original[7])(d,resource,desc,out);if(SUCCEEDED(hr)&&out&&*out&&modernlight::transportEnabled())modernheight::tagView(resource,*out);return hr;}
inline bool attachDevice(ID3D11Device* d){
 if(!d)return false;auto* e=prepare(devices,d,deviceMethods(d));if(!e)return find(devices,d)!=nullptr;e->shadow[5]=(void*)&texture2D;e->shadow[7]=(void*)&shaderView;e->shadow[11]=(void*)&inputLayout;e->shadow[12]=(void*)&vertexShader;e->shadow[15]=(void*)&pixelShader;e->shadow[27]=(void*)&create<27>;if(e->count>44)e->shadow[44]=(void*)&create<44>;if(e->count>51)e->shadow[51]=(void*)&create<51>;if(e->count>62)e->shadow[62]=(void*)&create<62>;bool ok=publish(e);log(ok?"device-attached":"device-attach-failed",d,unsigned(e->count));return ok;
}
}
