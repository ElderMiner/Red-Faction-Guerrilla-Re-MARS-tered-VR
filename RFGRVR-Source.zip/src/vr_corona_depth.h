#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <atomic>
#include <vector>
#include <mutex>
#include <cmath>
// Native corona pass 0 is decorative glow. Query passes 1/2 stay native.
namespace vrcoronadepth {
inline std::atomic<bool> enabled{false};inline std::atomic<unsigned> queued{0};
inline thread_local bool drawing=false;
struct Scope {bool previous;explicit Scope(bool enabled):previous(drawing){drawing=enabled;if(enabled)++queued;}~Scope(){drawing=previous;}};
inline std::atomic<unsigned> applied{0},missingWorldDepth{0};
// Clears occur on the immediate context; corona geometry is recorded on a
// worker's deferred context. Track the actual DSV, not a context-local pass.
struct ClearLedger {
 struct Entry {Microsoft::WRL::ComPtr<ID3D11DepthStencilView> view;D3D11_COMPARISON_FUNC compare;DWORD tick;};
 std::mutex guard;std::vector<Entry> entries;
 void record(ID3D11DepthStencilView* view,UINT flags,float depth,DWORD now){
  if(!view||!(flags&D3D11_CLEAR_DEPTH)||!std::isfinite(depth)||(depth!=0.f&&depth!=1.f))return;
  const auto compare=depth==0.f?D3D11_COMPARISON_GREATER_EQUAL:D3D11_COMPARISON_LESS_EQUAL;
  std::lock_guard<std::mutex> lock(guard);for(auto& e:entries)if(e.view.Get()==view){e.compare=compare;e.tick=now;return;}
  Entry e;e.view=view;e.compare=compare;e.tick=now;
  if(entries.size()<32)entries.push_back(e);else{auto* oldest=&entries[0];for(auto& candidate:entries)if(DWORD(now-candidate.tick)>DWORD(now-oldest->tick))oldest=&candidate;*oldest=e;}
 }
 bool find(ID3D11DepthStencilView* view,D3D11_COMPARISON_FUNC& compare,DWORD now){std::lock_guard<std::mutex> lock(guard);for(auto& e:entries)if(e.view.Get()==view&&DWORD(now-e.tick)<2000){compare=e.compare;return true;}return false;}
};
inline ClearLedger clearedDepth;
inline void recordClear(ID3D11DepthStencilView* view,UINT flags,float value){if(enabled.load(std::memory_order_relaxed))clearedDepth.record(view,flags,value,GetTickCount());}
struct Cache {
 Microsoft::WRL::ComPtr<ID3D11Device> owner;
 struct Entry {Microsoft::WRL::ComPtr<ID3D11DepthStencilState> original,corrected;D3D11_COMPARISON_FUNC compare;};
 std::vector<Entry> entries;
 ID3D11DepthStencilState* get(ID3D11Device* device,ID3D11DepthStencilState* original,D3D11_COMPARISON_FUNC compare){
  if(owner.Get()!=device){entries.clear();owner=device;}
  for(auto& e:entries)if(e.original.Get()==original&&e.compare==compare)return e.corrected.Get();
  if(entries.size()>=16)return nullptr;
  D3D11_DEPTH_STENCIL_DESC desc{};if(original)original->GetDesc(&desc);
  desc.DepthEnable=TRUE;desc.DepthWriteMask=D3D11_DEPTH_WRITE_MASK_ZERO;desc.DepthFunc=compare;
  Entry e;e.original=original;e.compare=compare;if(FAILED(device->CreateDepthStencilState(&desc,&e.corrected)))return nullptr;
  entries.push_back(e);return entries.back().corrected.Get();
 }
};
inline thread_local Cache cache;
struct DepthGuard {
 ID3D11DeviceContext* context=nullptr;Microsoft::WRL::ComPtr<ID3D11DepthStencilState> saved;UINT stencil=0;
 explicit DepthGuard(ID3D11DeviceContext* c){
  if(!drawing||!c)return;Microsoft::WRL::ComPtr<ID3D11DepthStencilView> current;c->OMGetRenderTargets(0,nullptr,&current);D3D11_COMPARISON_FUNC compare;
  if(!current||!clearedDepth.find(current.Get(),compare,GetTickCount())){++missingWorldDepth;return;}apply(c,compare);
 }
 DepthGuard(ID3D11DeviceContext* c,ID3D11DepthStencilView* world,D3D11_COMPARISON_FUNC compare){
  if(!drawing||!c)return;
  Microsoft::WRL::ComPtr<ID3D11DepthStencilView> current;c->OMGetRenderTargets(0,nullptr,&current);
  if(!world||current.Get()!=world){++missingWorldDepth;return;}
  apply(c,compare);
 }
 void apply(ID3D11DeviceContext* c,D3D11_COMPARISON_FUNC compare){
  if(compare!=D3D11_COMPARISON_LESS_EQUAL&&compare!=D3D11_COMPARISON_GREATER_EQUAL)return;
  c->OMGetDepthStencilState(&saved,&stencil);
  Microsoft::WRL::ComPtr<ID3D11Device> device;c->GetDevice(&device);
  auto* corrected=cache.get(device.Get(),saved.Get(),compare);if(!corrected)return;
  context=c;context->OMSetDepthStencilState(corrected,stencil);++applied;
 }
 ~DepthGuard(){if(context)context->OMSetDepthStencilState(saved.Get(),stencil);}
};
}
