#pragma once
// Native UI only. Cubic reconstruction with a small bounded edge boost;
// preserve premultiplied alpha and never expose color outside its coverage.
inline constexpr char RFGRMenuScaleShader[]=R"HLSL(
Texture2D source:register(t0);SamplerState texSampler:register(s0);
struct Output {float4 position:SV_Position;float2 uv:TEXCOORD0;};
Output VS(uint index:SV_VertexID){Output o;float2 uv=float2((index<<1)&2,index&2);o.position=float4(uv*float2(2,-2)+float2(-1,1),0,1);o.uv=uv;return o;}
float4 PS(Output i):SV_Target{return source.Sample(texSampler,i.uv);}
float4 weights(float f){float f2=f*f,f3=f2*f;return float4(-.5*f+f2-.5*f3,1-2.5*f2+1.5*f3,.5*f+2*f2-1.5*f3,-.5*f2+.5*f3);}
float4 UpscalePS(Output i):SV_Target{
 float4 baseValue=source.SampleLevel(texSampler,i.uv,0);if(baseValue.a<=0)return 0;
 uint width,height;source.GetDimensions(width,height);float2 p=i.uv*float2(width,height)-.5;int2 origin=int2(floor(p)),hi=int2(width-1,height-1);float2 f=frac(p);float4 wx=weights(f.x),wy=weights(f.y),value=0;
 [unroll]for(int y=0;y<4;++y){[unroll]for(int x=0;x<4;++x){int2 q=clamp(origin+int2(x-1,y-1),int2(0,0),hi);value+=source.Load(int3(q,0))*wx[x]*wy[y];}}
 value=saturate(value+.20*(value-baseValue));value.rgb=min(value.rgb,value.aaa);return value;
}
)HLSL";

