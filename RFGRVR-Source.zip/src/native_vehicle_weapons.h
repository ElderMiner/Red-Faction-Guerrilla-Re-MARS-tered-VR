#include "vr_user_settings.h"
#pragma once
#include "ipc.h"
#include "vr_wrist_status.h"
#include <cstdio>
#include "vr_vehicle_controls.h"
#include "vehicle_type_catalog.h"
#include "vehicle_aim_packet.h"
#include "native_apc_cameras.h"
#include "vr_render_anchor.h"
#include "tank_controls.h"
extern "C" bool RFGRVR_VehicleSitting();
namespace RFGRVRNativeVehicle {
using namespace vrarm;
inline V rotate(float x,float y,float z,float w,V v){V q{x,y,z};return add(v,add(mul(cross(q,v),2*w),mul(cross(q,cross(q,v)),2)));}
inline std::atomic<float> heightAxis{0};inline std::atomic<bool> focusButton{false},reticle{false};inline std::atomic<ULONGLONG> inputTick{0};
inline RFGRVRVehicleHeightBlend heightBlend;
inline std::atomic<bool> resetRequested{false};inline RFGRVRVehicleControls controls;inline std::atomic<float> eyeHeight{0};inline SRWLOCK viewLock=SRWLOCK_INIT;inline Pose view{};inline ULONGLONG viewTick=0;inline M viewCarrier{};inline bool viewCarrierReady=false;
inline void* mountedVehicle(void* p){using namespace RFGRVRNativeTurret;if(!RFGRVR_HeadCam_Enabled()||!memory(p,0xc94)||word(p,0x2f4)!=9||!lookup)return nullptr;void* v=lookup(base+0x2b98490,word(p,0xac4));return memory(v,0x80)&&memory((char*)v+15700,20)&&*((unsigned char*)v+0x7e)==3?v:nullptr;}
inline bool driverOwned(void* t){using namespace RFGRVRNativeTurret;void* p=player();void* v=mountedVehicle(p);if(!v||!memory(t,0x164)||*((unsigned char*)t+0x7e)!=6||word(t,0x70)!=word(p,0xac4))return false;
 unsigned count=word(v,15700);if(count>2)return false;for(unsigned i=0;i<count;++i){void* info=(void*)(uintptr_t)word(v,15704+i*8);if(!memory(info,20)||(word(info,8)!=0&&word(info,8)!=~0u))continue;if(word(v,15708+i*8)==word(t,0x6c))return true;}return false;}
inline bool fireable(void* t){using namespace RFGRVRNativeTurret;if(!memory(t,0xec)||!lookup||*((unsigned char*)t+0xdc)!=1)return false;void* gun=lookup(base+0x2b98490,word(t,0xe8));return memory(gun,0x14c)&&*((unsigned char*)gun+0x7e)==1&&word(gun,0x148)!=0;}
namespace Glass {
inline void* material=nullptr;inline void* data=nullptr;inline float* alpha=nullptr;inline float before=0,applied=0;inline unsigned hashBefore=0;
inline void restore(){using namespace RFGRVRNativeTurret;if(material&&memory(material,28,true)&&word(material,0x18)==(uintptr_t)data&&memory(data,28)&&word(data,4)==0xdee94842&&memory(alpha,4,true)&&*alpha==applied){*alpha=before;if(!word(material,8))memcpy((char*)material+8,&hashBefore,4);}material=data=nullptr;alpha=nullptr;}
inline void update(void* car,bool active){using namespace RFGRVRNativeTurret;if(!active){restore();return;}void* sub=(void*)(uintptr_t)word(car,0x9c);void* list=(void*)(uintptr_t)word(sub,0x58);unsigned count=word(sub,0x60);if(!memory(sub,0x70)||!count||count>32||!memory(list,count*8)){restore();return;}
 for(unsigned i=0;i<count;++i){void* m=(void*)(uintptr_t)word(list,i*8);void* d=(void*)(uintptr_t)word(m,0x18);if(!memory(m,28,true)||!memory(d,28)||word(d,4)!=0xdee94842||(word(d,8)&1)==0||word(d,12)!=0x10030002)continue;
  auto* names=(unsigned*)((char*)d+0x14+word(d,0x14));auto* block=(float*)((char*)d+0x18+word(d,0x18));
  if(!memory(names,12)||names[0]!=0x08cc10ef||names[1]!=0x39e923fe||names[2]!=0xa0e07244||!memory(block,48,true))continue;
  float* value=block+8;if(material==m&&data==d&&alpha==value&&*value==applied)return;restore();if(!std::isfinite(*value)||*value<0||*value>4)return;
  material=m;data=d;alpha=value;before=*value;applied=before*.18f;hashBefore=word(m,8);*alpha=applied;unsigned zero=0;memcpy((char*)m+8,&zero,4);return;
 }restore();}
}
inline bool isFlamer();
inline bool isTank();
inline bool driverControlled(void* t){return (isTank()||isFlamer()||reticle.load())&&driverOwned(t);}
inline char heightPath[MAX_PATH]{},heightType[96]{};inline unsigned heightVehicle=~0u,heightSeat=9;inline bool sittingMode=false;inline bool heightDirty=false;inline ULONGLONG heightChanged=0;
inline void saveHeight(){if(!heightDirty||!heightType[0]||!heightPath[0])return;char value[40];sprintf_s(value,"%.6f",controls.height);if(WritePrivateProfileStringA(heightType,sittingMode?"SittingHeight":"StandingHeight",value,heightPath)){if(sittingMode)WritePrivateProfileStringA(heightType,"Height",value,heightPath);heightDirty=false;}}
inline bool vehicleType(unsigned id,char (&name)[96],bool canonical=true){using namespace RFGRVRNativeTurret;BatchMemory typeMemory;if(!lookup||id==~0u)return false;void* v=lookup(base+0x2b98490,id);if(!memory(v,0x80)||*((unsigned char*)v+0x7e)!=3)return false;void* info=(void*)(uintptr_t)word(v,13588);const char* text=(const char*)(uintptr_t)word(info,0);for(unsigned i=0;i<96;++i){if(!memory(text?text+i:nullptr,1))return false;char ch=text[i];if(!ch){name[i]=0;auto* type=RFGRVRVehicleTypeFor(name);if(type&&canonical)strcpy_s(name,type->type);return i>0;}if(!((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z')||(ch>='0'&&ch<='9')||ch=='_'||ch=='-'||ch=='.'))return false;name[i]=ch;}return false;}
inline bool isMech(){using namespace RFGRVRNativeTurret;void* p=player();unsigned id=word(p,0xac4);void* v=lookup&&id!=~0u?lookup(base+0x2b98490,id):nullptr;void* info=(void*)(uintptr_t)word(v,13588);const char* name=(const char*)(uintptr_t)word(info,0);return memory(info,16)&&RFGRVRVehicleIsMech(memory(name,80)?name:nullptr,word(info,12));}
inline bool isFlamer(){char name[96]{};void* p=RFGRVRNativeTurret::player();return p&&vehicleType(RFGRVRNativeTurret::word(p,0xac4),name)&&!_stricmp(name,"Walker_Flamer");}
inline vrtank::Aim tankAim[2];
inline std::atomic<short> tankYawInput{0},tankPitchInput{0};inline std::atomic<ULONGLONG> tankInputTick{0};
inline bool isTank(){char name[96]{};auto* p=RFGRVRNativeTurret::player();return p&&vehicleType(RFGRVRNativeTurret::word(p,0xac4),name)&&vrtestspawn::tank(name);}
inline SRWLOCK tankSeatLock=SRWLOCK_INIT;inline vrtank::Seat tankSeat;
inline bool tankBody(void* p,Pose& out){using namespace RFGRVRNativeTurret;if(p!=player()||!isTank())return false;void* v=mountedVehicle(p);if(!v)return false;Pose hull{},native{};memcpy(&hull.p,(char*)v+4,12);memcpy(&hull.b,(char*)v+16,36);memcpy(&native.p,(char*)p+4,12);memcpy(&native.b,(char*)p+16,36);AcquireSRWLockExclusive(&tankSeatLock);char name[96]{};bool rotate=vehicleType(word(v,0x6c),name)&&vrtestspawn::rotatingTankCabin(name);bool ok=tankSeat.update(word(v,0x6c),hull,native,RFGRVRAPC::tankBodyHeight.load(),out,rotate);ReleaseSRWLockExclusive(&tankSeatLock);return ok;}
inline bool lookAimAllowed(){char name[96]{};if(!vehicleType(heightVehicle,name))return true;auto* type=RFGRVRVehicleTypeFor(name);return (!isMech()||isFlamer())&&(!type||!type->tank);}
// Classification is immutable for a mounted vehicle handle. Store only the
// copied result, never native pointers or page-validity information.
inline std::atomic<uint64_t> viewClassification{0};
inline bool thirdPerson(){if(RFGRVRVehicleCalibrationActive.load())return false;unsigned id=heightVehicle;auto cached=viewClassification.load(std::memory_order_acquire);bool tank=false;
 if((cached>>32)==id&&(cached&1))tank=(cached&2)!=0;
 else {char name[96]{};if(!vehicleType(id,name))return false;auto* type=RFGRVRVehicleTypeFor(name);tank=type&&type->tank;viewClassification.store((uint64_t(id)<<32)|1|(tank?2:0),std::memory_order_release);}
 return !tank&&!vrsettings::get().value[vrsettings::Vehicles];}

inline void prepareHeight(unsigned vehicle,unsigned seat=9){bool nextSitting=RFGRVR_VehicleSitting();if(heightVehicle==vehicle&&heightSeat==seat&&sittingMode==nextSitting)return;saveHeight();viewClassification.store(0,std::memory_order_release);sittingMode=nextSitting;heightSeat=seat;heightDirty=false;heightVehicle=vehicle;heightType[0]=0;if(!heightPath[0]){GetModuleFileNameA(nullptr,heightPath,MAX_PATH);char* slash=strrchr(heightPath,92);if(slash)strcpy_s(slash+1,MAX_PATH-(slash+1-heightPath),"RFGRVR-vehicle-heights.ini");else heightPath[0]=0;}
 controls.update(vehicle,0,false,0);if(vehicleType(vehicle,heightType)&&heightPath[0]){char legacyType[96];strcpy_s(legacyType,heightType);if(seat==8)strcat_s(heightType,".Turret");else if(seat==10)strcat_s(heightType,".Passenger");char value[40];GetPrivateProfileStringA(heightType,"Height","",value,sizeof(value),heightPath);if(!value[0])GetPrivateProfileStringA(legacyType,"Height","",value,sizeof(value),heightPath);if(!value[0]){char original[96]{};if(vehicleType(vehicle,original,false))GetPrivateProfileStringA(original,"Height","0",value,sizeof(value),heightPath);}float saved=0;if(sscanf_s(value,"%f",&saved)==1&&std::isfinite(saved))controls.height=(std::max)(-.6f,(std::min)(.6f,saved));char modeValue[40];GetPrivateProfileStringA(heightType,sittingMode?"SittingHeight":"StandingHeight","",modeValue,sizeof(modeValue),heightPath);if(modeValue[0]&&sscanf_s(modeValue,"%f",&saved)==1&&std::isfinite(saved))controls.height=(std::max)(-.6f,(std::min)(sittingMode?.6f:1.2f,saved));}}
inline const char* weaponLabel(void* gun){using namespace RFGRVRNativeTurret;void* info=(void*)(uintptr_t)word(gun,0x148);const char* source=(const char*)(uintptr_t)word(info,0);if(!memory(source,64))return "Mounted weapon";char name[65]{};memcpy(name,source,64);if(strstr(name,"gauss"))return "Gauss cannon";if(strstr(name,"rocket"))return "Rocket launcher";if(strstr(name,"tank"))return "Tank cannon";if(strstr(name,"mg"))return "Machine gun";if(strstr(name,"laser"))return "Laser";return "Mounted weapon";}
inline void publishControls(void* p,unsigned state){using namespace RFGRVRNativeTurret;static ULONGLONG last=0;if(GetTickCount64()-last<150)return;last=GetTickCount64();char text[512]{};if(state>=7&&state<=10){bool turret=state==8;bool mech=isMech();strcpy_s(text,isTank()?"Drive / reverse / steer: LS\nGun rotation / elevation: RS\nMain cannon: RT    Secondary turret: LT\n":mech?"Walk forward / back: LS\nTurn: RS left/right\nPrimary attack: RT     Secondary: LT\nJump / thrust: A     Exit: Y\n":turret?(lookup&&headAimedVehicleMount(lookup(base+0x2b98490,word(p,0xa08)))?"Traverse: LS left/right    Aim: look direction\n":"Rotate: LS     Aim: Right hand\n"):"Steer: LS     Accelerate: RT\nBrake / reverse: LT     E-brake: X\n");auto append=[&](void* gun,const char* binding){char line[100];sprintf_s(line,"Fire (%s): %s\n",weaponLabel(gun),binding);if(strlen(text)+strlen(line)<sizeof(text))strcat_s(text,line);};if(turret){void* t=lookup?lookup(base+0x2b98490,rig.identity):nullptr;append(lookup?lookup(base+0x2b98490,word(t,0xe8)):nullptr,"RT");}else if(!mech){void* v=mountedVehicle(p);unsigned count=word(v,15700);if(count<=2)for(unsigned i=0;i<count;++i){void* t=lookup?lookup(base+0x2b98490,word(v,15708+i*8)):nullptr;append(lookup?lookup(base+0x2b98490,word(t,0xe8)):nullptr,"A");}}if(mech&&isFlamer())strcat_s(text,"Rocket aim overlay: RS down\n");strcat_s(text,"Reset view: LS press\nHeight: R grip + RS up/down");}vrstatus::vehicleControls(text);}
inline std::atomic<unsigned> parkedAPC{~0u};
// Vehicle creation registers the attachment once. No world-object search.
inline bool rememberCreatedAPC(void* object){using namespace RFGRVRNativeTurret;
 if(!memory(object,13600)||*((unsigned char*)object+0x7e)!=3)return false;unsigned id=word(object,0x6c);if(id==~0u)return false;
 void* info=(void*)(uintptr_t)word(object,13588);const char* text=(const char*)(uintptr_t)word(info,0);char name[96]{};for(unsigned i=0;i<95;++i){if(!memory(text?text+i:nullptr,1))return false;name[i]=text[i];if(!name[i])break;}if(!RFGRVRAPC::supported(name))return false;parkedAPC=id;return true;
}
inline void update(void* p,float dt){using namespace RFGRVRNativeTurret;unsigned state=word(p,0x2f4),vehicle=(state>=7&&state<=10)?word(p,0xac4):~0u;bool fresh=GetTickCount64()-inputTick.load()<250;Glass::update(mountedVehicle(p),state==9&&isFlamer());
 if(resetRequested.exchange(false)){heightDirty=false;heightVehicle=~0u;}prepareHeight(vehicle,state);publishControls(p,state);float oldHeight=controls.height;
 controls.update(vehicle,fresh?heightAxis.load():0,state==9&&fresh&&focusButton.load(),dt,sittingMode?.6f:1.2f);if(controls.height!=oldHeight){heightDirty=true;heightChanged=GetTickCount64();}else if(heightDirty&&GetTickCount64()-heightChanged>500)saveHeight();eyeHeight=heightBlend.update(vehicle,state,controls.height,dt);bool armed=false;void* vehicleObject=mountedVehicle(p);unsigned weaponCount=word(vehicleObject,15700);if(weaponCount<=2&&lookup)for(unsigned i=0;i<weaponCount;++i){void* turretObject=lookup(base+0x2b98490,word(vehicleObject,15708+i*8));armed=armed||(driverOwned(turretObject)&&fireable(turretObject));}reticle=state==9&&controls.reticle&&lookAimAllowed()&&armed;
 void* v=mountedVehicle(p);bool tank=isTank();if(!v||!motor||(!tank&&!reticle.load()&&!isFlamer()))return;Pose aim{};ULONGLONG stamp=0;AcquireSRWLockShared(&viewLock);aim=view;stamp=viewTick;ReleaseSRWLockShared(&viewLock);if(!tank&&(!stamp||GetTickCount64()-stamp>250||!valid(aim.b)))return;
 unsigned n=word(v,15700);if(n>2)return;for(unsigned i=0;i<n;++i){void* t=lookup(base+0x2b98490,word(v,15708+i*8));if(!driverOwned(t)||*((unsigned char*)t+0xdc)!=1)continue;void* joint=(void*)(uintptr_t)word(t,0xd8);if(!memory(joint,0xa4,true))continue;M root{};memcpy(&root,(char*)t+0x10,36);if(!valid(root))continue;V direction{0,0,1};if(reticle.load()){V origin{};void* gun=lookup(base+0x2b98490,word(t,0xe8));if(memory(gun,16))memcpy(&origin,(char*)gun+4,12);else memcpy(&origin,(char*)t+4,12);V target=add(aim.p,mul(aim.b.f,100.f*RFGRVR_HeadCam_WorldScale()));direction=local(root,unit(sub(target,origin)));}float yaw=atan2f(direction.x,direction.z),pitch=atan2f(direction.y,sqrtf(direction.x*direction.x+direction.z*direction.z));float limits[4]{};memcpy(limits,(char*)t+0xf0,16);bool finiteLimits=true;for(float f:limits)finiteLimits=finiteLimits&&std::isfinite(f);if(!finiteLimits)continue;
 if(tank){memcpy(&pitch,(char*)joint+0x98,4);memcpy(&yaw,(char*)joint+0x9c,4);if(!std::isfinite(yaw)||!std::isfinite(pitch))continue;bool inputFresh=vrtank::inputFresh(GetTickCount64(),tankInputTick.load(),vrsettings::paused());tankAim[i].update(word(t,0x6c),yaw,pitch,inputFresh?tankYawInput.load():0,inputFresh?tankPitchInput.load():0,dt);yaw=tankAim[i].yaw;pitch=tankAim[i].pitch;}
 yaw=tank?vrtank::yawLimit(yaw,limits[1],limits[0]):(std::max)(limits[1],(std::min)(limits[0],yaw));pitch=(std::max)(limits[3],(std::min)(limits[2],pitch));if(tank){tankAim[i].yaw=yaw;tankAim[i].pitch=pitch;}memcpy((char*)joint+0x98,&pitch,4);memcpy((char*)joint+0x9c,&yaw,4);memcpy((char*)joint+0xa0,&yaw,4);wakeBodies(joint);motor(joint,false,false);
 }
}
inline void publishView(const float position[3],const float basis[9],const RFGRPose* tracked,const float carrierBasis[9]=nullptr){using namespace RFGRVRNativeTurret;BatchMemory vehicleMemory;Pose camera{};memcpy(&camera.p,position,12);memcpy(&camera.b,basis,36);if(!valid(camera.b)||!finite(camera.p)||!tracked)return;
 M carrier{};if(carrierBasis)memcpy(&carrier,carrierBasis,36);
 AcquireSRWLockExclusive(&viewLock);view=camera;viewCarrier=carrier;viewCarrierReady=carrierBasis&&valid(carrier);viewTick=GetTickCount64();ReleaseSRWLockExclusive(&viewLock);RFGRVehicleAimPacket packet{};void* v=mountedVehicle(player());Pose apcBody{};char apcType[96]{};void* apc=v;bool apcDriver=false;if(v&&vehicleType(word(v,0x6c),apcType))apcDriver=RFGRVRAPC::supported(apcType);
 if(!apcDriver&&lookup){AcquireSRWLockShared(&RFGRVRAPC::lock);unsigned previous=RFGRVRAPC::identity;ReleaseSRWLockShared(&RFGRVRAPC::lock);apc=previous!=~0u?lookup(base+0x2b98490,previous):nullptr;if(!apc||!vehicleType(previous,apcType)||!RFGRVRAPC::supported(apcType))apc=nullptr;}
 // Rendering consumes the attachment registered at vehicle creation.
 if(!apc&&lookup){unsigned id=parkedAPC.load();void* candidate=id!=~0u?lookup(base+0x2b98490,id):nullptr;if(candidate&&vehicleType(id,apcType)&&RFGRVRAPC::supported(apcType))apc=candidate;}
 if(apc&&memory(apc,0x80)){memcpy(&apcBody.p,(char*)apc+4,12);memcpy(&apcBody.b,(char*)apc+16,36);
 // The view follows the rendered driver root. Carry the rigid APC screen and
 // camera anchors through that same interpolation instead of simulation time.
 if(apcDriver&&!vrtestspawn::tank(apcType)){void* driver=player();void* character=(void*)(uintptr_t)word(driver,0x32c);void* entity=(void*)(uintptr_t)word(character,0x30);Pose sampled{},rendered{},verify{};
 if(memory(driver,0x34)&&memory(entity,56)){memcpy(&sampled.p,(char*)driver+4,12);memcpy(&sampled.b,(char*)driver+0x10,36);memcpy(&rendered,(char*)entity+8,48);memcpy(&verify,(char*)entity+8,48);if(!memcmp(&rendered,&verify,48))RFGRVR_RenderAnchor(sampled,rendered,apcBody,32.f);}}
 }RFGRVRAPC::barrelReady=false;
 if(apcDriver&&vrtestspawn::tank(apcType)&&lookup){unsigned n=word(apc,15700);if(n<=2)for(unsigned i=0;i<n;++i){void* t=lookup(base+0x2b98490,word(apc,15708+i*8));if(!driverOwned(t))continue;void* gun=lookup(base+0x2b98490,word(t,0xe8));if(memory(gun,0x80)){Pose g{};memcpy(&g.p,(char*)gun+4,12);memcpy(&g.b,(char*)gun+16,36);if(valid(g.b)&&finite(g.p)){using MuzzlePose=void(__thiscall*)(void*,V*,M*);Pose muzzle=g;if(!vrtestspawn::artilleryTank(apcType))((MuzzlePose)(base+0x7dca70))(gun,&muzzle.p,&muzzle.b);if(vrtestspawn::artilleryTank(apcType)){Pose launcher{};void* joint=(void*)(uintptr_t)word(t,0xd8);if(!assemblyPose(joint,launcher)){RFGRVRAPC::barrelReady=false;break;}g=launcher;}else g=vrtank::cameraMount(false,g,muzzle);RFGRVRAPC::barrelMount=g;RFGRVRAPC::barrelReady=true;break;}}}}
 Pose rotatingSeat{};const Pose* seatFrame=nullptr;if(apcDriver&&vrtestspawn::tank(apcType)){void* seated=player();if(memory(seated,0x34)){memcpy(&rotatingSeat.p,(char*)seated+4,12);memcpy(&rotatingSeat.b,(char*)seated+16,36);if(valid(rotatingSeat.b)&&finite(rotatingSeat.p))seatFrame=&rotatingSeat;}}
 RFGRVRAPC::update(apc?apcType:nullptr,apc?word(apc,0x6c):~0u,apcBody,camera,tracked,RFGRVR_HeadCam_WorldScale(),apcDriver,seatFrame);
 // The mission crosshair follows the measured barrel, not the requested look direction.
 if(rig.identity!=~0u&&lookup&&!vrsettings::paused()&&(tracked->validFlags&3)==3){void* turret=lookup(base+0x2b98490,rig.identity);
  if(owned(turret)&&headAimedVehicleMount(turret)){void* gun=lookup(base+0x2b98490,word(turret,0xe8));if(memory(gun,0x80)&&*((unsigned char*)gun+0x7e)==1){Pose g{};memcpy(&g.p,(char*)gun+4,12);memcpy(&g.b,(char*)gun+16,36);float scale=RFGRVR_HeadCam_WorldScale();
   if(valid(g.b)&&finite(g.p)&&std::isfinite(scale)&&scale>.1f){V target=add(g.p,mul(g.b.f,100.f*scale)),e=mul(local(camera.b,sub(target,camera.p)),1/scale);e.z=-e.z;
    V point=rotate(tracked->orientation[0],tracked->orientation[1],tracked->orientation[2],tracked->orientation[3],e);point=add(point,{tracked->position[0],tracked->position[1],tracked->position[2]});if(finite(point)){memcpy(packet.target[0],&point,12);packet.count=1;}
   }
  }}
 }
 // Occupied turret heat bar follows the gun; vehicle seats display it by the map.
 if(rig.identity!=~0u&&lookup){void* turret=lookup(base+0x2b98490,rig.identity);void* gun=lookup(base+0x2b98490,word(turret,0xe8));if(memory(gun,0x80)&&*((unsigned char*)gun+0x7e)==1){Pose g{};memcpy(&g.p,(char*)gun+4,12);memcpy(&g.b,(char*)gun+0x10,36);float scale=RFGRVR_HeadCam_WorldScale();if(valid(g.b)&&finite(g.p)&&scale>.1f){V point=add(g.p,world(g.b,mul(V{.22f,.12f,-.1f},scale))),e=mul(local(camera.b,sub(point,camera.p)),1/scale);e.z=-e.z;V stage=add(rotate(tracked->orientation[0],tracked->orientation[1],tracked->orientation[2],tracked->orientation[3],e),{tracked->position[0],tracked->position[1],tracked->position[2]});memcpy(packet.heatPosition,&stage,12);memcpy(packet.heatOrientation,tracked->orientation,16);packet.heatValid=1;}}}
 if(reticle.load()&&v){unsigned n=word(v,15700);float scale=RFGRVR_HeadCam_WorldScale();if(n<=2&&scale>.1f)for(unsigned i=0;i<n;++i){void* t=lookup(base+0x2b98490,word(v,15708+i*8));if(!driverOwned(t)||!fireable(t))continue;void* gun=lookup(base+0x2b98490,word(t,0xe8));if(!memory(gun,0x80)||*((unsigned char*)gun+0x7e)!=1)continue;Pose g{};memcpy(&g.p,(char*)gun+4,12);memcpy(&g.b,(char*)gun+0x10,36);if(!valid(g.b)||!finite(g.p))continue;
 V target=add(g.p,mul(g.b.f,100.f*scale)),eye=mul(local(camera.b,sub(target,camera.p)),1/scale);eye.z=-eye.z;V room=rotate(tracked->orientation[0],tracked->orientation[1],tracked->orientation[2],tracked->orientation[3],eye);room=add(room,{tracked->position[0],tracked->position[1],tracked->position[2]});unsigned marker=packet.count++;memcpy(packet.target[marker],&room,12);
 M mount{};memcpy(&mount,(char*)t+0x10,36);float limits[4]{};memcpy(limits,(char*)t+0xf0,16);bool haveBounds=valid(mount);for(float value:limits)haveBounds=haveBounds&&std::isfinite(value);if(haveBounds){for(unsigned corner=0;corner<4;++corner){float yaw=limits[(corner&1)?0:1],pitch=limits[(corner&2)?2:3];V dir=world(mount,{sinf(yaw)*cosf(pitch),sinf(pitch),cosf(yaw)*cosf(pitch)}),point=add(g.p,mul(dir,100.f*scale)),localEye=mul(local(camera.b,sub(point,camera.p)),1/scale);localEye.z=-localEye.z;V stage=add(rotate(tracked->orientation[0],tracked->orientation[1],tracked->orientation[2],tracked->orientation[3],localEye),{tracked->position[0],tracked->position[1],tracked->position[2]});memcpy(packet.corners[marker][corner],&stage,12);}packet.bounds|=1u<<marker;}
 }}if(v&&packet.count>1){M vehicle{};memcpy(&vehicle,(char*)v+0x10,36);if(valid(vehicle)){auto stageAxis=[&](V axis){V e=local(camera.b,axis);e.z=-e.z;return rotate(tracked->orientation[0],tracked->orientation[1],tracked->orientation[2],tracked->orientation[3],e);};M fixed{stageAxis(vehicle.r),stageAxis(vehicle.u),mul(stageAxis(vehicle.f),-1)};V nativeOrigin{};memcpy(&nativeOrigin,(char*)v+4,12);V e=mul(local(camera.b,sub(nativeOrigin,camera.p)),1/RFGRVR_HeadCam_WorldScale());e.z=-e.z;V stageOrigin=add(rotate(tracked->orientation[0],tracked->orientation[1],tracked->orientation[2],tracked->orientation[3],e),{tracked->position[0],tracked->position[1],tracked->position[2]});RFGRVR_MergeVehicleAimFrame(packet,&stageOrigin.x,fixed);}}static RFGRVehicleAimWriter writer;writer.publish(packet);
}
}
extern "C" inline bool RFGRVR_VehicleAimView(float position[3],float basis[9],float carrierBasis[9]){
 using namespace RFGRVRNativeVehicle;if(!position||!basis||!carrierBasis||vrsettings::paused())return false;Pose camera{};M carrier{};bool haveCarrier=false;ULONGLONG stamp=0;
 AcquireSRWLockShared(&viewLock);camera=view;carrier=viewCarrier;haveCarrier=viewCarrierReady;stamp=viewTick;ReleaseSRWLockShared(&viewLock);if(!haveCarrier||!stamp||GetTickCount64()-stamp>250||!valid(camera.b)||!valid(carrier)||!finite(camera.p))return false;
 memcpy(position,&camera.p,12);memcpy(basis,&camera.b,36);memcpy(carrierBasis,&carrier,36);return true;
}





