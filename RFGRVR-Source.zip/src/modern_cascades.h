#pragma once
#include "modern_local_shadows.h"
#include "modern_camera_math.h"
namespace moderncascade {
using modernlocal::V;
struct Camera {float inverseClip[16]{};V eye{},forward{0,0,1};};
inline bool camera(const float* nativeColumnClip,const float* eye,Camera& result){if(!nativeColumnClip||!eye||!moderncamera::inverse(nativeColumnClip,result.inverseClip))return false;for(unsigned i=0;i<3;++i)if(!std::isfinite(eye[i]))return false;result.eye={eye[0],eye[1],eye[2]};float w=result.inverseClip[14]*.5f+result.inverseClip[15];if(std::abs(w)<1e-8f)return false;V center{(result.inverseClip[2]*.5f+result.inverseClip[3])/w,(result.inverseClip[6]*.5f+result.inverseClip[7])/w,(result.inverseClip[10]*.5f+result.inverseClip[11])/w};result.forward=modernlocal::unit(modernlocal::sub(center,result.eye));return true;}
inline bool corner(const Camera& c,float x,float y,float distance,V& point){const float* m=c.inverseClip;float w=m[12]*x+m[13]*y+m[14]*.5f+m[15];if(std::abs(w)<1e-8f)return false;V ray{(m[0]*x+m[1]*y+m[2]*.5f+m[3])/w-c.eye.x,(m[4]*x+m[5]*y+m[6]*.5f+m[7])/w-c.eye.y,(m[8]*x+m[9]*y+m[10]*.5f+m[11])/w-c.eye.z};float forward=modernlocal::dot(ray,c.forward);if(forward<=1e-8f)return false;float scale=distance/forward;point={c.eye.x+ray.x*scale,c.eye.y+ray.y*scale,c.eye.z+ray.z*scale};return true;}
struct Cascade {modernlocal::Projection projection;float nearDistance=0,farDistance=0,worldTexel=0;};
struct Plan {Cascade cascades[4]{};unsigned count=0;};
inline Plan fit(const Camera* stereo,V towardLight,float nearDistance,float farDistance,unsigned count,unsigned resolution,float casterPadding=50,float logarithmicWeight=.6f){
 Plan plan;float magnitude=modernlocal::dot(towardLight,towardLight);if(!stereo||!std::isfinite(magnitude)||magnitude<.5f||magnitude>1.5f||!std::isfinite(nearDistance)||!std::isfinite(farDistance)||nearDistance<=0||farDistance<=nearDistance||!count||count>4||resolution<32||resolution>4096||!std::isfinite(casterPadding)||casterPadding<0||!std::isfinite(logarithmicWeight)||logarithmicWeight<0||logarithmicWeight>1)return plan;
 V z=modernlocal::unit({-towardLight.x,-towardLight.y,-towardLight.z}),up=std::abs(z.y)>.95f?V{0,0,1}:V{0,1,0},x=modernlocal::unit(modernlocal::cross(up,z)),y=modernlocal::cross(z,x);float previous=nearDistance;
 for(unsigned cascade=0;cascade<count;++cascade){float t=float(cascade+1)/count,logSplit=nearDistance*std::pow(farDistance/nearDistance,t),uniformSplit=nearDistance+(farDistance-nearDistance)*t;float split=logSplit*logarithmicWeight+uniformSplit*(1-logarithmicWeight);V points[16],center{};unsigned at=0;
  for(unsigned eye=0;eye<2;++eye)for(unsigned depth=0;depth<2;++depth)for(unsigned row=0;row<2;++row)for(unsigned column=0;column<2;++column){if(!corner(stereo[eye],column?1.f:-1.f,row?1.f:-1.f,depth?split:previous,points[at]))return {};center.x+=points[at].x/16;center.y+=points[at].y/16;center.z+=points[at].z/16;++at;}
  float radius=0;for(V p:points){V d=modernlocal::sub(p,center);radius=(std::max)(radius,std::sqrt(modernlocal::dot(d,d)));}radius=std::ceil(radius*16)/16;radius*=(1+2.f/resolution);if(!std::isfinite(radius)||radius<=0)return {};
  float texel=2*radius/resolution,cx=std::round(modernlocal::dot(center,x)/texel)*texel,cy=std::round(modernlocal::dot(center,y)/texel)*texel,cz=modernlocal::dot(center,z)-radius-casterPadding,depthRange=2*(radius+casterPadding);auto& c=plan.cascades[cascade];c.nearDistance=previous;c.farDistance=split;c.worldTexel=texel;float* clip=c.projection.clip;
  clip[0]=x.x/radius;clip[1]=x.y/radius;clip[2]=x.z/radius;clip[3]=-cx/radius;clip[4]=y.x/radius;clip[5]=y.y/radius;clip[6]=y.z/radius;clip[7]=-cy/radius;clip[8]=z.x/depthRange;clip[9]=z.y/depthRange;clip[10]=z.z/depthRange;clip[11]=-cz/depthRange;clip[15]=1;
  for(unsigned k=0;k<4;++k){c.projection.texture[k]=.5f*(clip[k]+clip[12+k]);c.projection.texture[4+k]=.5f*(-clip[4+k]+clip[12+k]);c.projection.texture[8+k]=clip[8+k];c.projection.texture[12+k]=clip[12+k];}previous=split;
 }plan.count=count;return plan;
}
}
