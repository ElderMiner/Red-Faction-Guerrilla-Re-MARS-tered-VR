// Original atmospheric sky shading. Keep native geometry, stars and moon.
cbuffer Common:register(b0){float4 common[11];};
cbuffer Instance:register(b6){float4 tint;float4 alphaControl;};
Texture2D<float4> atmosphereLookup:register(t20);
float3 atmosphere(float3 ray){
 uint width,height;atmosphereLookup.GetDimensions(width,height);
 if(!width||!height)return 0;
 float azimuth=abs(ray.x)+abs(ray.z)<1e-6?0:atan2(ray.z,ray.x);
 float2 uv=float2(.5+azimuth/6.283185307,acos(clamp(ray.y,-1,1))/3.141592654);
 float2 at=uv*float2(width,height)-.5;int2 cell=int2(floor(at));float2 f=frac(at);
 int x0=(cell.x%int(width)+int(width))%int(width),x1=(x0+1)%int(width);
 int y0=clamp(cell.y,0,int(height)-1),y1=clamp(cell.y+1,0,int(height)-1);
 return lerp(lerp(atmosphereLookup.Load(int3(x0,y0,0)).rgb,atmosphereLookup.Load(int3(x1,y0,0)).rgb,f.x),lerp(atmosphereLookup.Load(int3(x0,y1,0)).rgb,atmosphereLookup.Load(int3(x1,y1,0)).rgb,f.x),f.y);
}
float3 skyRay(float4 pixel){
 float2 ndc=float2(2*pixel.x/modernViewport.x-1,1-2*pixel.y/modernViewport.y);
 float4 locationH=mul(modernInverseClip,float4(ndc,.5,1));
 return modernUnit(locationH.xyz/locationH.w-modernEye.xyz);
}
#if MODE<2
struct In{float4 position:SV_Position;float3 mesh:TEXCOORD0;float4 gradient:TEXCOORD1;};
float4 main(In i):SV_Target{
 // Atmospheric integration already includes the entire optical path. Applying
 // the far-distance native fog again would replace it with a flat fog colour.
 float3 colour=modernGridLayout.z>.5&&modernEye.w>.5?atmosphere(skyRay(i.position))*.125:lerp(i.gradient.rgb,common[4].rgb,saturate(i.gradient.w));
 #if MODE==1
 if(alphaControl.x>.5&&1<alphaControl.y)discard;
 return float4(colour,1);
 #else
 return float4(colour,1)*tint;
 #endif
}
#else
cbuffer Clouds:register(b2){float4 cloud[8];};
Texture2D<float4> layer01:register(t0),layer23:register(t1);
SamplerState cloud01:register(s0),cloud23:register(s1);
struct In{float4 position:SV_Position;float3 normal:TEXCOORD0;float4 view:TEXCOORD1;float4 uv:TEXCOORD2;};
float4 main(In i):SV_Target{
 float ramp=saturate((clamp(i.view.y,-1,1)-cloud[6].z)/max(cloud[6].w-cloud[6].z,1e-5));
 float4 first=layer01.Sample(cloud01,i.uv.xy),second=layer23.Sample(cloud23,i.uv.zw);
 float4 mass=float4(first.g,first.a,second.g,second.a)*cloud[0]*ramp;
 float4 clear=1-mass;float coverage=saturate(1-clear.x*clear.y*clear.z*clear.w);
 float brightness=saturate(lerp(lerp(lerp(first.r,first.b,mass.y),second.r,mass.z),second.b,mass.w));
 // Optical path increases through a slanted cloud layer. HDR sources behind
 // it retain transmitted radiance; opacity never depends on source brightness.
 float path=modernEye.w>.5?1/max(abs(skyRay(i.position).y),.2):1;
 float alpha=coverage>=1?1:1-pow(max(1-coverage*coverage,1e-6),path);
 float hemisphere=dot(modernUnit(i.normal),cloud[5].xyz)*.5+.5;
 float3 colour;
 if(modernGridLayout.z>.5&&modernEye.w>.5){
  float3 ambient=atmosphere(float3(0,1,0)),forward=atmosphere(skyRay(i.position));
  colour=(ambient*(.35+.65*saturate(hemisphere))+forward*.35)*(.6+.8*brightness)*.125;
 }else{
  float forward=pow(saturate(dot(modernUnit(i.view.xyz),cloud[5].xyz)),30);
  float scatter=min(exp2(-coverage*cloud[7].y),1);
  colour=brightness*(lerp(cloud[3].rgb,cloud[4].rgb,hemisphere)+scatter*cloud[3].rgb*cloud[7].z*forward)+common[2].rgb;
  colour=lerp(colour,common[4].rgb,saturate(i.view.w));
 }
 float4 result=float4(max(colour,0),alpha)*tint;result.rgb*=result.a;
 return min(result,32);
}
#endif
