#pragma once
#include "modern_scene_lights.h"
#include "vr_eye_pipeline.h"
#include "modern_compute_scope.h"
#include <d3d11.h>
#include <wrl/client.h>
#include <array>
#include <algorithm>
#include <cmath>
#include <cstring>
namespace modernlocal {
struct V {float x,y,z;};
inline V sub(V a,V b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
inline float dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline V cross(V a,V b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
inline V unit(V v){float d=std::sqrt(dot(v,v));return d>1e-8f?V{v.x/d,v.y/d,v.z/d}:V{0,0,1};}
struct Projection {float clip[16]{},texture[16]{};};
// Row-major, column-vector convention; D3D depth 0..1. These are world
// projections: neither eye pose nor screen visibility defines local shadows.
inline Projection projection(V origin,V direction,V up,float fov,float nearZ,float farZ){
 V z=unit(direction),x=unit(cross(up,z)),y=cross(z,x);float s=1/std::tan(fov*.5f),q=farZ/(farZ-nearZ);
 float view[16]={x.x,x.y,x.z,-dot(x,origin),y.x,y.y,y.z,-dot(y,origin),z.x,z.y,z.z,-dot(z,origin),0,0,0,1};
 float perspective[16]={s,0,0,0,0,s,0,0,0,0,q,-nearZ*q,0,0,1,0};Projection p;
 for(unsigned r=0;r<4;++r)for(unsigned c=0;c<4;++c)for(unsigned k=0;k<4;++k)p.clip[r*4+c]+=perspective[r*4+k]*view[k*4+c];
 for(unsigned c=0;c<4;++c){p.texture[c]=.5f*(p.clip[c]+p.clip[12+c]);p.texture[4+c]=.5f*(-p.clip[4+c]+p.clip[12+c]);p.texture[8+c]=p.clip[8+c];p.texture[12+c]=p.clip[12+c];}return p;
}
struct Views {unsigned count=0;Projection faces[6]{};};
inline Views views(const modernscene::Light& l){
 Views out;if(!modernscene::valid(l)||!l.kind)return out;V p{l.position[0],l.position[1],l.position[2]};float nearZ=(std::min)(.05f,l.range*.01f);
 if(l.kind==2){V direction{l.direction[0],l.direction[1],l.direction[2]};V up=std::abs(direction.y)>.95f?V{0,0,1}:V{0,1,0};float fov=2*std::acos((std::clamp)(l.outerCos,-.999f,.999f));if(fov>=3.13f)return out;out.count=1;out.faces[0]=projection(p,direction,up,fov,nearZ,l.range);}
 else {const V directions[]={{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};const V up[]={{0,1,0},{0,1,0},{0,0,-1},{0,0,1},{0,1,0},{0,1,0}};out.count=6;for(unsigned i=0;i<6;++i)out.faces[i]=projection(p,directions[i],up[i],1.57079632679f,nearZ,l.range);}return out;
}
inline unsigned face(V delta){float x=std::abs(delta.x),y=std::abs(delta.y),z=std::abs(delta.z);return x>=y&&x>=z?(delta.x>=0?0:1):y>=z?(delta.y>=0?2:3):(delta.z>=0?4:5);}
// Cache identity includes geometry revision. No stale map is exposed after a
// light moves or destruction changes its visibility; an incomplete cube is
// never published. Refreshes spend a bounded number of complete face draws.
class Atlas {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 struct Entry {uint64_t key=0,revision=0,last=0;modernscene::Light light{};Views projections{};bool ready=false;};
 std::array<Entry,4> entries{};Ptr<ID3D11Device> owner;Ptr<ID3D11Texture2D> texture;Ptr<ID3D11ShaderResourceView> srv;Ptr<ID3D11DepthStencilView> targets[24];unsigned resolution=0,budget=0;uint64_t frame=0;
 bool init(ID3D11Device* d,unsigned size){if(owner.Get()==d&&resolution==size&&texture)return true;
  if(!d||size<32||size>2048||(size&(size-1)))return false;D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=size;desc.MipLevels=1;desc.ArraySize=24;desc.SampleDesc.Count=1;desc.Format=DXGI_FORMAT_R32_TYPELESS;desc.BindFlags=D3D11_BIND_DEPTH_STENCIL|D3D11_BIND_SHADER_RESOURCE;
  Ptr<ID3D11Texture2D> next;Ptr<ID3D11ShaderResourceView> nextSRV;Ptr<ID3D11DepthStencilView> nextTargets[24];if(FAILED(d->CreateTexture2D(&desc,nullptr,&next)))return false;
  D3D11_SHADER_RESOURCE_VIEW_DESC sd{};sd.Format=DXGI_FORMAT_R32_FLOAT;sd.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2DARRAY;sd.Texture2DArray.MipLevels=1;sd.Texture2DArray.ArraySize=24;if(FAILED(d->CreateShaderResourceView(next.Get(),&sd,&nextSRV)))return false;
  for(unsigned i=0;i<24;++i){D3D11_DEPTH_STENCIL_VIEW_DESC vd{};vd.Format=DXGI_FORMAT_D32_FLOAT;vd.ViewDimension=D3D11_DSV_DIMENSION_TEXTURE2DARRAY;vd.Texture2DArray.ArraySize=1;vd.Texture2DArray.FirstArraySlice=i;if(FAILED(d->CreateDepthStencilView(next.Get(),&vd,&nextTargets[i])))return false;}
  owner=d;texture=next;srv=nextSRV;for(unsigned i=0;i<24;++i)targets[i]=nextTargets[i];resolution=size;entries={};return true;
 }
public:
 using Draw=bool(*)(void*,ID3D11DeviceContext*,const Projection&,unsigned);
 void begin(uint64_t id,unsigned faceBudget){if(id!=frame){frame=id;budget=(std::min)(faceBudget,24u);}}
 // Callback supplies verified scene casters, including their own skin/alpha
 // semantics. The atlas does not reinterpret native mesh memory or draw a
 // substitute bounding box. Caller must execute this on its owning stream.
 int update(ID3D11Device* d,ID3D11DeviceContext* c,uint64_t key,const modernscene::Light& light,uint64_t revision,unsigned size,Draw draw,void* user){
  if(!c||!key||!draw)return -1;Ptr<ID3D11Device> contextDevice;c->GetDevice(&contextDevice);if(contextDevice.Get()!=d||!init(d,size))return -1;Views next=views(light);if(!next.count)return -1;
  unsigned slot=0;for(unsigned i=0;i<4;++i){if(entries[i].key==key){slot=i;break;}if(!entries[i].key||entries[i].last<entries[slot].last)slot=i;}
  auto& e=entries[slot];if(e.key==key&&e.ready&&e.revision==revision&&!memcmp(&e.light,&light,sizeof(light))){e.last=frame;return int(slot);}
  if(e.key==key)e.ready=false;if(budget<next.count)return -1;budget-=next.count;e.ready=false;e.key=key;e.last=frame;
  RFGRVREyePipeline previous;previous.save(c);moderncompute::Scope compute(c);
  // Unbind readers before binding the private depth slice. The draw callback
  // installs its depth shaders/state; all graphics bindings are restored.
  ID3D11ShaderResourceView* empty[128]{};c->VSSetShaderResources(0,128,empty);c->PSSetShaderResources(0,128,empty);c->GSSetShaderResources(0,128,empty);c->HSSetShaderResources(0,128,empty);c->DSSetShaderResources(0,128,empty);c->CSSetShaderResources(0,128,empty);
  bool complete=true;D3D11_VIEWPORT viewport{0,0,float(size),float(size),0,1};
  for(unsigned face=0;face<next.count;++face){c->RSSetViewports(1,&viewport);c->OMSetRenderTargets(0,nullptr,targets[slot*6+face].Get());c->ClearDepthStencilView(targets[slot*6+face].Get(),D3D11_CLEAR_DEPTH,1,0);if(!draw(user,c,next.faces[face],face)){complete=false;break;}}
  previous.restore(c);if(!complete)return -1;e.light=light;e.revision=revision;e.projections=next;e.ready=true;return int(slot);
 }
 ID3D11ShaderResourceView* resource()const{return srv.Get();}
 const Views* lookup(unsigned slot,uint64_t key,uint64_t revision)const{return slot<4&&entries[slot].ready&&entries[slot].key==key&&entries[slot].revision==revision?&entries[slot].projections:nullptr;}
 unsigned remaining()const{return budget;}
};
}
