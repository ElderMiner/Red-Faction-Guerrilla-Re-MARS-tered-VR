#pragma once
// Verified native input paths: 2FCC00 reads camera.free_params.control_type
// at +14C. Mode 3 rotates LS through camera forward; mode 2 is hull tread
// control. This override exists only during the local tank's input call.
namespace RFGRVRTankInput {
using Drive=void(__cdecl*)();
using Axis=float(__cdecl*)(unsigned,unsigned);
using Button=bool(__cdecl*)(unsigned,unsigned);inline Button held=nullptr,pressed=nullptr;
inline SRWLOCK fireLock=SRWLOCK_INIT;inline vrtank::Secondary secondary;
inline void publish(unsigned char trigger){AcquireSRWLockExclusive(&fireLock);secondary.update(trigger,GetTickCount64());ReleaseSRWLockExclusive(&fireLock);}
inline Drive drive=nullptr;
inline Axis axis=nullptr;
inline unsigned* mode=nullptr;
inline bool local(){return RFGRVRNativeVehicle::mountedVehicle(RFGRVRNativeTurret::player())&&RFGRVRNativeVehicle::isTank();}
inline bool (*eligible)()=local;
struct TreadScope {
 unsigned* field;unsigned saved;
 TreadScope(unsigned* p,bool tank):field(tank?p:nullptr),saved(field?*field:0){if(field)*field=2;}
 ~TreadScope(){if(field)*field=saved;}
};
inline void __cdecl onDrive(){TreadScope scope(mode,eligible());drive();}
// RS is consumed by the independent joint controller. Native tank look must
// not steer the chase camera/gun a second time from controller/mouse input.
inline float __cdecl onAxis(unsigned action,unsigned controller){if(controller==0&&(action==6||action==7)&&eligible())return 0;return axis(action,controller);}
inline bool fireOverride(unsigned action,unsigned controller,bool edge,bool& result){if(action!=0x2a||controller!=0||!eligible())return false;AcquireSRWLockExclusive(&fireLock);result=edge?secondary.edge(GetTickCount64(),vrsettings::paused()):secondary.down(GetTickCount64(),vrsettings::paused());ReleaseSRWLockExclusive(&fireLock);return true;}
inline bool __cdecl onHeld(unsigned action,unsigned controller){bool result=false;return fireOverride(action,controller,false,result)?result:held(action,controller);}
inline bool __cdecl onPressed(unsigned action,unsigned controller){bool result=false;return fireOverride(action,controller,true,result)?result:pressed(action,controller);}
inline bool install(unsigned char* base,unsigned char* camera){
 const unsigned char ds[]={0x81,0xec,0x84,0,0,0,0x0f,0x57,0xc0};
 const unsigned char as[]={0x83,0xec,8,0x53,0x8b,0x5c,0x24,0x14};
 if(memcmp(base+0x2fcc00,ds,sizeof(ds))||memcmp(base+0x2f8e30,as,sizeof(as)))return false;
 mode=(unsigned*)(camera+0x14c);
 const unsigned char bs[]={0x56,0x8b,0x74,0x24,0x0c,0x83,0xfe,1};
 if(memcmp(base+0x2fe970,bs,sizeof(bs))||memcmp(base+0x2fea30,bs,sizeof(bs)))return false;
 struct Hook{unsigned rva;void* entry;void** prior;};Hook hooks[]={{0x2fcc00,(void*)onDrive,(void**)&drive},{0x2f8e30,(void*)onAxis,(void**)&axis},{0x2fe970,(void*)onHeld,(void**)&held},{0x2fea30,(void*)onPressed,(void**)&pressed}};
 for(auto& h:hooks)if(MH_CreateHook(base+h.rva,h.entry,h.prior)!=MH_OK){for(auto& undo:hooks)MH_RemoveHook(base+undo.rva);return false;}
 for(auto& h:hooks)if(MH_EnableHook(base+h.rva)!=MH_OK){for(auto& undo:hooks){MH_DisableHook(base+undo.rva);MH_RemoveHook(base+undo.rva);}return false;}
 return true;
}
}
