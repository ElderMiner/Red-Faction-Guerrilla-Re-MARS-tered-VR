#pragma once
#include <d3d11.h>
#include <wrl/client.h>
// Fullscreen eye/menu copies own their raster state. Never inherit HUD clipping.
struct RFGRFullscreenRaster {
 Microsoft::WRL::ComPtr<ID3D11RasterizerState> state;
 bool bind(ID3D11Device* d,ID3D11DeviceContext* c){if(!state){D3D11_RASTERIZER_DESC desc{};desc.FillMode=D3D11_FILL_SOLID;desc.CullMode=D3D11_CULL_NONE;desc.DepthClipEnable=TRUE;if(FAILED(d->CreateRasterizerState(&desc,&state)))return false;}c->RSSetState(state.Get());return true;}
};
