Texture2D<float4> source:register(t0);
RWStructuredBuffer<uint> histogram:register(u0);
cbuffer Meter:register(b0){float radianceScale;uint stride;uint2 padding;};
groupshared uint localBins[256];
[numthreads(8,8,1)]void main(uint3 id:SV_DispatchThreadID,uint thread:SV_GroupIndex){
 [unroll]for(uint i=thread;i<256;i+=64)localBins[i]=0;GroupMemoryBarrierWithGroupSync();
 uint width,height;source.GetDimensions(width,height);uint2 pixel=id.xy*max(stride,1);
 if(all(pixel<uint2(width,height))){float3 c=source.Load(int3(pixel,0)).rgb*radianceScale;float value=dot(max(c,0),float3(.2126,.7152,.0722));uint bin=isfinite(value)&&value>0?(uint)clamp((log2(value)+12)/28*256,0,255):0;InterlockedAdd(localBins[bin],1);}
 GroupMemoryBarrierWithGroupSync();[unroll]for(uint i=thread;i<256;i+=64)if(localBins[i])InterlockedAdd(histogram[i],localBins[i]);
}
