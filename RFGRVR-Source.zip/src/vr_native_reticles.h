#pragma once
#include <cstring>
namespace vrreticles {
// Verified native rfg_ui_hud_reticles groups; ammo/charge/overheat remain capturable.
inline bool crosshairHash(unsigned hash){
 switch(hash){case 0x88f4624eu:case 0xb028bf79u:case 0x50d7cc91u:case 0x27d0fc07u:case 0xb9b469a4u:return true;default:return false;}
}
inline bool flatCrosshair(unsigned hash,const char* document){return crosshairHash(hash)&&document&&!strcmp(document,"rfg_ui_hud_reticles");}
}
