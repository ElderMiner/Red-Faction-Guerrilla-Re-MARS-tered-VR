#pragma once
namespace modernmaterial {inline constexpr char samplingSource[]=
R"WORLD(// Shared by replacement materials. Camera math stays renderer-relative;
// probe locations are absolute world positions. No headset-space lighting.
cbuffer ModernWorld:register(b13){float4 reflectionControl;row_major float4x4 modernInverseClip;float4 modernEye;float4 modernViewport;float4 modernOrigin;float4 modernGrid;float4 modernGridLayout;float4 modernReflectionCenter;float4 modernReflectionBounds;};
TextureCube<float4> modernEnvironment:register(t16);
Texture2D<float2> modernBRDF:register(t17);
Texture2D<float4> modernProbes:register(t18);
float3 modernUnit(float3 v){return v*rsqrt(max(dot(v,v),1e-12));}
float4 modernIrradiance(float3 world,float3 normal){
 float size=modernGridLayout.x;float3 q=(world-modernGrid.xyz)/max(modernGrid.w,.25);
 if(modernGridLayout.y<.5||size<2||any(q<0)||any(q>size-1))return 0;
 int3 cell=min(int3(floor(q)),int(size)-2);float3 f=q-float3(cell);normal=modernUnit(normal);
 float basis[9]={.2820947918,.4886025119*normal.y,.4886025119*normal.z,.4886025119*normal.x,1.0925484306*normal.x*normal.y,1.0925484306*normal.y*normal.z,.3153915653*(3*normal.z*normal.z-1),1.0925484306*normal.x*normal.z,.5462742153*(normal.x*normal.x-normal.y*normal.y)};
 float3 sum=0;float total=0;
 [unroll]for(int z=0;z<2;++z)[unroll]for(int y=0;y<2;++y)[unroll]for(int x=0;x<2;++x){
  int3 node=cell+int3(x,y,z);int row=(node.z*int(size)+node.y)*int(size)+node.x;
  if(modernProbes.Load(int3(15,row,0)).x<.5)continue;
  float weight=(x?f.x:1-f.x)*(y?f.y:1-f.y)*(z?f.z:1-f.z);float3 delta=world-(modernGrid.xyz+float3(node)*modernGrid.w);float distance=length(delta);float3 axis=abs(delta);int face=axis.x>=axis.y&&axis.x>=axis.z?(delta.x>=0?0:1):axis.y>=axis.z?(delta.y>=0?2:3):(delta.z>=0?4:5);
  float2 moment=modernProbes.Load(int3(9+face,row,0)).xy;
  if(distance>moment.x+.05){float variance=max(moment.y-moment.x*moment.x,0);float difference=distance-moment.x;float p=variance/max(variance+difference*difference,1e-10);weight*=p*p*p;}
  float3 light=0;[unroll]for(int k=0;k<9;++k)light+=modernProbes.Load(int3(k,row,0)).rgb*basis[k];sum+=max(light,0)*weight;total+=weight;
 }
 return total>1e-6?float4(sum/total,saturate(total)):0;
}
float3 modernAmbient(float4 pixel,float2 uv,float3 tangentNormal,float4 normalHint,float3 nativeAmbient,float3 diffuseFactor){
 [branch]if(modernEye.w<.5||modernGridLayout.y<.5)return nativeAmbient;
 float4 locationH=mul(modernInverseClip,float4(pixel.xy/modernViewport.xy*float2(2,-2)+float2(-1,1),pixel.z,1));if(abs(locationH.w)<1e-8)return nativeAmbient;
 float3 relative=locationH.xyz/locationH.w;float3 dx=ddx(relative),dy=ddy(relative);float3 N=modernUnit(cross(dx,dy));if(dot(N,modernEye.xyz-relative)<0)N=-N;
 float2 tx=ddx(uv),ty=ddy(uv);float3 a=cross(dy,N),b=cross(N,dx);float3 T=a*tx.x+b*ty.x,B=a*tx.y+b*ty.y;float scale=rsqrt(max(max(dot(T,T),dot(B,B)),1e-12));
 float3 worldNormal=normalHint.w>.5?modernUnit(normalHint.xyz):modernUnit((T*tangentNormal.x+B*tangentNormal.y)*scale+N*tangentNormal.z);
 float4 probe=modernIrradiance(relative+modernOrigin.xyz,worldNormal);
 // Captures contain true HDR radiance; native material targets store 1/8.
 float3 bounce=max(diffuseFactor,0)*probe.rgb*(.125/3.14159265359);
 return lerp(nativeAmbient,bounce,probe.a);
}
// Finite local box projection is an approximation, not a scene ray query.
float3 modernReflectionDirection(float4 pixel,float3 direction){
 [branch]if(modernEye.w<.5||modernReflectionCenter.w<.5||any(modernReflectionBounds.xyz<=0))return direction;
 float4 locationH=mul(modernInverseClip,float4(pixel.xy/max(modernViewport.xy,1)*float2(2,-2)+float2(-1,1),pixel.z,1));
 if(abs(locationH.w)<1e-8)return direction;
 float3 relative=locationH.xyz/locationH.w+(modernOrigin.xyz-modernReflectionCenter.xyz),bounds=modernReflectionBounds.xyz;
 if(any(abs(relative)>=bounds))return direction;
 float3 safe=float3(abs(direction.x)<1e-6?(direction.x<0?-1e-6:1e-6):direction.x,abs(direction.y)<1e-6?(direction.y<0?-1e-6:1e-6):direction.y,abs(direction.z)<1e-6?(direction.z<0?-1e-6:1e-6):direction.z);
 float3 distance=(sign(safe)*bounds-relative)/safe;
 float exitDistance=min(distance.x,min(distance.y,distance.z));
 return modernUnit(relative+direction*exitDistance);
}
float3 modernSpecular(float4 position,float3 direction,float roughness,float nv,float3 f0,SamplerState state){
 uint width,height;modernBRDF.GetDimensions(width,height);int2 pixel=min(int2(saturate(float2(nv,roughness))*float2(width,height)),int2(width,height)-1);float2 brdf=modernBRDF.Load(int3(max(pixel,0),0));return max(modernEnvironment.SampleLevel(state,modernReflectionDirection(position,direction),roughness*reflectionControl.z).rgb,0)*(f0*brdf.x+brdf.y)*reflectionControl.y;
}

)WORLD";}
