#pragma once
#include "vr_fullscreen_raster.h"
// A menu transfer is a copy, not another alpha-compositing pass. The XR
// compositor applies its premultiplied alpha later, exactly once.
struct RFGRMenuCopyState {
 ID3D11DeviceContext* context;Microsoft::WRL::ComPtr<ID3D11BlendState> blend;
 Microsoft::WRL::ComPtr<ID3D11DepthStencilState> depth;Microsoft::WRL::ComPtr<ID3D11RasterizerState> raster;
 FLOAT factor[4]{};UINT mask=0,stencil=0;
 RFGRMenuCopyState(ID3D11DeviceContext* c):context(c){c->OMGetBlendState(&blend,factor,&mask);c->OMGetDepthStencilState(&depth,&stencil);c->RSGetState(&raster);}
 bool bind(ID3D11Device* device,RFGRFullscreenRaster& fullscreen){if(!fullscreen.bind(device,context))return false;context->OMSetBlendState(nullptr,nullptr,~0u);context->OMSetDepthStencilState(nullptr,0);return true;}
 ~RFGRMenuCopyState(){context->OMSetBlendState(blend.Get(),factor,mask);context->OMSetDepthStencilState(depth.Get(),stencil);context->RSSetState(raster.Get());}
};

