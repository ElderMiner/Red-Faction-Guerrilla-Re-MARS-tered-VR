#pragma once
#include "vr_night_lighting.h"
#include "modern_lighting.h"
#include "modern_scene_lights.h"
#include <atomic>
#include <cstdint>
namespace vrnightlights {
// Verified GameRenderGetTodLight (3C2960): +130 overrides +12C. These are
// rl_light pointers, NEVER camera pointers. Native colour lives at +CC.
inline void** sceneRoot=nullptr;
inline std::atomic<unsigned> mainSamples{0},mainWrites{0},ambientWrites{0};
inline void* pointer(const void* p,unsigned offset){unsigned value=0;if(vrmemory::check((const char*)p+offset,4))memcpy(&value,(const char*)p+offset,4);return (void*)(uintptr_t)value;}
inline void* selected(){void* root=sceneRoot?*sceneRoot:nullptr;if(!vrmemory::check(root,0x134))return nullptr;void* light=pointer(root,0x130);return light?light:pointer(root,0x12c);}
inline void captureModern(void* self,const float* output){
 if(!modernlight::enabled()||!RFGRVR_HeadCam_Enabled()||!vrmemory::check(self,0x110)||!vrmemory::check(output,12))return;
 modernscene::Light light;memcpy(&light.kind,(char*)self+0xc8,4);if(light.kind>2)return;memcpy(light.colour,output,12);
 if(light.kind==0){memcpy(light.direction,(char*)self+0x104,12);}else{
  memcpy(light.position,(char*)self+0x2c,12);memcpy(&light.innerRange,(char*)self+0xdc,4);memcpy(&light.range,(char*)self+0xe0,4);
  if(light.kind==2){memcpy(light.direction,(char*)self+0x20,12);float outer=0,inner=0;memcpy(&outer,(char*)self+0xe4,4);memcpy(&inner,(char*)self+0xe8,4);
   // Native C2460 calls MSVCR100!_CIcos on both angles, then stores
   // cos(inner), min(cos(outer),cos(inner)-1e-5), reciprocal cone width.
   if(!std::isfinite(inner)||!std::isfinite(outer)||inner<0||outer<inner||outer>3.141593f)return;
   light.innerCos=std::cos(inner);light.outerCos=(std::min)(std::cos(outer),light.innerCos-1e-5f);
  }
 }
 modernscene::collector.submit((uintptr_t)self,light);
}
using Colour=uintptr_t(__thiscall*)(void*,float*,float);inline Colour colour=nullptr;
using Geometry=uintptr_t(__thiscall*)(void*,float*,const float*);inline Geometry geometry=nullptr;
inline uintptr_t __fastcall onGeometry(void* self,void*,float* output,const float* origin){
 auto result=geometry(self,output,origin);
 if(modernlight::enabled()&&vrmemory::check(self,0x110)){unsigned kind=0;memcpy(&kind,(char*)self+0xc8,4);if(kind==1||kind==2)captureModern(self,(float*)((char*)self+0xcc));}
 return result;
}
__declspec(naked) inline void geometryEntry(){__asm {
 sub esp,32
 movups [esp],xmm6
 movups [esp+16],xmm7
 push [esp+40]
 push [esp+40]
 call onGeometry
 movups xmm6,[esp]
 movups xmm7,[esp+16]
 add esp,32
 ret 8
}}
inline uintptr_t __fastcall onColour(void* self,void*,float* output,float scale){
 uintptr_t result=colour(self,output,scale);auto finish=[&](){
 // Per-draw scale may be a visibility/material factor. Store source radiance,
 // not whichever scaled upload happened last for one eye.
 float source[3];if(modernscene::sourceRadiance(output,scale,source))captureModern(self,source);return result;};const auto* p=vrnight::current;
 if(!p||!RFGRVR_HeadCam_Enabled()||self!=selected()||!vrmemory::check(self,0x11c)||!vrmemory::check(output,12,true))return finish();
 unsigned type=~0u;memcpy(&type,(char*)self+0xc8,4);if(type!=0)return finish();
 ++mainSamples;if(p->mainLight==1)return finish();
 for(int i=0;i<3;++i)if(!std::isfinite(output[i]))return finish();
 for(int i=0;i<3;++i)output[i]*=p->mainLight;
 ++mainWrites;return finish();
}
using Ambient=void(__thiscall*)(void*,const float*);inline Ambient front=nullptr,back=nullptr;
inline void ambient(Ambient native,void* renderer,const float* input){
 const auto* p=vrnight::current;
 if(!p||!RFGRVR_HeadCam_Enabled()||p->ambient==1||!vrmemory::check(input,16)){native(renderer,input);return;}
 float value[4];memcpy(value,input,16);for(int i=0;i<3;++i)if(!std::isfinite(value[i])){native(renderer,input);return;}
 for(int i=0;i<3;++i)value[i]*=p->ambient;
 ++ambientWrites;native(renderer,value);
}
inline void __fastcall onFront(void* renderer,void*,const float* input){ambient(front,renderer,input);}
inline void __fastcall onBack(void* renderer,void*,const float* input){ambient(back,renderer,input);}
// Native 117855 calls front then back without reloading ECX/EDX, and retains
// XMM6/7 across both. A normal C++ callback has a weaker register contract.
__declspec(naked) inline void frontEntry(){__asm {
 push ecx
 push edx
 sub esp,32
 movups [esp],xmm6
 movups [esp+16],xmm7
 push [esp+44]
 call onFront
 movups xmm6,[esp]
 movups xmm7,[esp+16]
 add esp,32
 pop edx
 pop ecx
 ret 4
}}
__declspec(naked) inline void backEntry(){__asm {
 push ecx
 push edx
 sub esp,32
 movups [esp],xmm6
 movups [esp+16],xmm7
 push [esp+44]
 call onBack
 movups xmm6,[esp]
 movups xmm7,[esp+16]
 add esp,32
 pop edx
 pop ecx
 ret 4
}}
}
