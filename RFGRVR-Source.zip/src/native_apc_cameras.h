#pragma once
#include "apc_camera_state.h"
#include "ipc.h"
#include <cstdio>
#include <algorithm>
#include <atomic>
#include "apc_screen_layout.h"
#include "vr_wrist_status.h"
#include "apc_editor_keys.h"
#include "tank_keys.h"
#include "tank_controls.h"
#include "vehicle_type_catalog.h"
#include "test_spawn_catalog.h"
namespace RFGRVRAPC {
using namespace vrarm;
inline SRWLOCK lock=SRWLOCK_INIT;inline RFGRAPCCameras packet{};inline RFGRAPCChannel channel;
inline std::atomic<bool> tankMode{false};inline std::atomic<float> tankBodyHeight{0};inline Pose barrelMount{};inline bool barrelReady=false;
inline V artilleryCameraAnchor{-0.139707926f,1.381846993f,3.214096347f},artilleryCameraReference{};
inline float cameraMountScale=1;
inline V artilleryModelOffset{-.593809246f,1.004918950f,4.516954884f};
inline unsigned cameraCount(){return tankMode?5u:4u;}
inline unsigned cameraBudget(){return tankMode?3u:2u;}
inline bool supported(const char* name){return name&&(strstr(name,"APC")||vrtestspawn::tank(name));}
inline Pose nativeMounts[5]{};inline V offsets[5]{};inline V screenOffset{0,-.35f,.8f},seat{};inline float tilt=0,scale=1;
struct Monitor {V offset{};float tilt=0,width=1,height=1,lens=0,cameraPitch=0,yaw=0,fov=1;};
inline Monitor monitors[5]{};inline int selected=-1;inline bool cameraEdit=false;
inline V monitorOffset(unsigned i){V initial=tankMode?(i==0?V{}:V{(float(i)-2.5f)*.31f,.39f,0}):i==1?V{0,.39f,0}:i==2?V{.31f,.39f,0}:i==3?V{-.31f,.39f,0}:V{};return add(initial,monitors[i].offset);}
inline void bounds(unsigned i,float (&angles)[4]){auto m=monitors[i];float wide=tankMode?m.fov:1.f+m.lens;float x=m.width*wide,y=(9.f/16.f)*m.height*wide;angles[0]=-atanf(x);angles[1]=atanf(x);angles[2]=atanf(y);angles[3]=-atanf(y);}
inline float assemblyYaw=0;inline bool fixedSeat=false;
inline Pose screenSeatLocal{};inline V screenSeatPivot{};inline unsigned screenSeatVehicle=~0u;
inline unsigned renderIndex=0;inline Pose nativeScreens{};inline float assemblyScale=1;
inline char type[96]{},path[MAX_PATH]{};inline unsigned identity=~0u;inline uint64_t texture=0;inline unsigned epoch=0,validFeeds=0;inline DWORD feedTick[5]{};
inline int grabbed[2]={-1,-1};inline V grabStart[2]{},offsetStart[2]{};inline bool gripHeld[2]{};
inline void setOffset(unsigned i,V value){if(i>=5)return;offsets[i]=value;if(i==2||i==3)offsets[i==2?3:2]={-value.x,value.y,value.z};}
inline void save(){if(!path[0]||!type[0])return;char value[160],key[40];if(vrtestspawn::tank(type)){sprintf_s(value,"%.9f",cameraMountScale);WritePrivateProfileStringA(type,"CameraMountScale",value,path);}if(vrtestspawn::artilleryTank(type)){sprintf_s(value,"%.9f %.9f %.9f",artilleryCameraAnchor.x,artilleryCameraAnchor.y,artilleryCameraAnchor.z);WritePrivateProfileStringA(type,"Camera2FixedNativeHull",value,path);sprintf_s(value,"%.9f %.9f %.9f",artilleryCameraReference.x,artilleryCameraReference.y,artilleryCameraReference.z);WritePrivateProfileStringA(type,"Camera2FixedReference",value,path);}if(vrtestspawn::tank(type)){sprintf_s(value,"%.6f",tankBodyHeight.load());WritePrivateProfileStringA(type,"BodyHeight",value,path);}if(fixedSeat){sprintf_s(value,"%.9f %.9f %.9f",seat.x,seat.y,seat.z);WritePrivateProfileStringA(type,"Seat",value,path);}sprintf_s(value,"%.6f %.6f %.6f %.6f",screenOffset.x,screenOffset.y,screenOffset.z,tilt);WritePrivateProfileStringA(type,"Screens",value,path);sprintf_s(value,"%.6f",assemblyYaw);WritePrivateProfileStringA(type,"ScreenYaw",value,path);sprintf_s(value,"%.6f",assemblyScale);WritePrivateProfileStringA(type,"ScreenScale",value,path);for(unsigned i=0;i<cameraCount();++i){auto m=monitors[i];sprintf_s(key,"Monitor%u",i+1);sprintf_s(value,"%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f",m.offset.x,m.offset.y,m.offset.z,m.tilt,m.width,m.height,m.lens,m.cameraPitch,m.yaw,m.fov);WritePrivateProfileStringA(type,key,value,path);sprintf_s(key,"Camera%u",i+1);sprintf_s(value,"%.6f %.6f %.6f",offsets[i].y,offsets[i].z,offsets[i].x);WritePrivateProfileStringA(type,key,value,path);}}
// One-time copy of the approved medium screen arrangement. Keep each tank's
// seat, body height, camera location, camera pitch and camera FOV independent.
inline void copyMediumLayout(){
 if(!vrtestspawn::tank(type)||GetPrivateProfileIntA("TankLayout","MediumCopy1336",0,path))return;
 const char* source="EDF_MediumTank-A_1";char check[160]{};
 GetPrivateProfileStringA(source,"Monitor1","",check,sizeof(check),path);if(!check[0])return;
 char backup[MAX_PATH]{};if(sprintf_s(backup,"%s.pre-0.13.36.bak",path)<0||!CopyFileA(path,backup,TRUE)&&GetLastError()!=ERROR_FILE_EXISTS)return;
 for(const char* target:{"EDF_HeavyTank-A_1","EDF_ArtTank_1"}){
  for(const char* key:{"Screens","ScreenYaw","ScreenScale"}){char value[160]{};GetPrivateProfileStringA(source,key,"",value,sizeof(value),path);if(value[0]&&!WritePrivateProfileStringA(target,key,value,path))return;}
  for(unsigned i=1;i<=5;++i){char key[24],from[160]{},to[160]{},value[240];sprintf_s(key,"Monitor%u",i);GetPrivateProfileStringA(source,key,"",from,sizeof(from),path);GetPrivateProfileStringA(target,key,"",to,sizeof(to),path);Monitor m{},old{};
   if(sscanf_s(from,"%f %f %f %f %f %f %f %f %f %f",&m.offset.x,&m.offset.y,&m.offset.z,&m.tilt,&m.width,&m.height,&m.lens,&m.cameraPitch,&m.yaw,&m.fov)<7)continue;
   sscanf_s(to,"%f %f %f %f %f %f %f %f %f %f",&old.offset.x,&old.offset.y,&old.offset.z,&old.tilt,&old.width,&old.height,&old.lens,&old.cameraPitch,&old.yaw,&old.fov);
   sprintf_s(value,"%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f",m.offset.x,m.offset.y,m.offset.z,m.tilt,m.width,m.height,m.lens,old.cameraPitch,m.yaw,old.fov);
   if(!WritePrivateProfileStringA(target,key,value,path))return;
  }
 }
 WritePrivateProfileStringA("TankLayout","MediumCopy1336","1",path);
}
inline void load(const char* name){auto* family=RFGRVRVehicleTypeFor(name);strcpy_s(type,family?family->type:name);name=type;tankMode=vrtestspawn::tank(name);if(!path[0]){GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* s=strrchr(path,92))strcpy_s(s+1,MAX_PATH-(s+1-path),"RFGRVR-apc-cameras.ini");}tankBodyHeight=0;screenOffset={0,-.35f,.8f};tilt=0;assemblyYaw=0;assemblyScale=1;for(auto& m:monitors)m=Monitor{};selected=-1;cameraEdit=false;fixedSeat=false;memset(offsets,0,sizeof(offsets));char value[160],key[40];cameraMountScale=scale;GetPrivateProfileStringA(type,"CameraMountScale","",value,sizeof(value),path);float savedMountScale=scale;if(sscanf_s(value,"%f",&savedMountScale)==1&&std::isfinite(savedMountScale)&&savedMountScale>.1f&&savedMountScale<5)cameraMountScale=savedMountScale;else if(tankMode){sprintf_s(value,"%.9f",cameraMountScale);WritePrivateProfileStringA(type,"CameraMountScale",value,path);}artilleryCameraAnchor={-0.139707926f,1.381846993f,3.214096347f};artilleryCameraReference={};for(unsigned i=0;i<2;++i){GetPrivateProfileStringA(type,i?"Camera2FixedReference":"Camera2FixedNativeHull","",value,sizeof(value),path);V v{};if(sscanf_s(value,"%f %f %f",&v.x,&v.y,&v.z)==3&&finite(v)&&length(v)<20)(i?artilleryCameraReference:artilleryCameraAnchor)=v;}copyMediumLayout();GetPrivateProfileStringA(type,"BodyHeight","0",value,sizeof(value),path);float bodyHeight=0;if(vrtestspawn::tank(type)&&sscanf_s(value,"%f",&bodyHeight)==1&&std::isfinite(bodyHeight))tankBodyHeight=(std::clamp)(bodyHeight,-2.f,2.f);GetPrivateProfileStringA(type,"Seat","",value,sizeof(value),path);V storedSeat{};if(sscanf_s(value,"%f %f %f",&storedSeat.x,&storedSeat.y,&storedSeat.z)==3&&finite(storedSeat)&&length(storedSeat)<5){seat=storedSeat;fixedSeat=true;}GetPrivateProfileStringA(type,"Screens","",value,sizeof(value),path);V p{};float a=0;if(sscanf_s(value,"%f %f %f %f",&p.x,&p.y,&p.z,&a)==4&&finite(p)&&length(p)<5&&fabsf(a)<1.4f){screenOffset=p;tilt=a;}GetPrivateProfileStringA(type,"ScreenYaw","0",value,sizeof(value),path);float savedYaw=0;if(sscanf_s(value,"%f",&savedYaw)==1&&std::isfinite(savedYaw)&&fabsf(savedYaw)<6.4f)assemblyYaw=savedYaw;GetPrivateProfileStringA(type,"ScreenScale","1",value,sizeof(value),path);float size=1;if(sscanf_s(value,"%f",&size)==1&&std::isfinite(size))assemblyScale=(std::max)(.25f,(std::min)(3.f,size));for(unsigned i=0;i<cameraCount();++i){sprintf_s(key,"Camera%u",i+1);GetPrivateProfileStringA(type,key,"",value,sizeof(value),path);float y=0,z=0,x=0;if(sscanf_s(value,"%f %f %f",&y,&z,&x)>=2&&std::isfinite(y)&&std::isfinite(z)&&fabsf(y)<4&&fabsf(z)<4)offsets[i]={std::isfinite(x)&&fabsf(x)<4?x:0,y,z};}offsets[3]={-offsets[2].x,offsets[2].y,offsets[2].z};for(unsigned i=0;i<cameraCount();++i){sprintf_s(key,"Monitor%u",i+1);GetPrivateProfileStringA(type,key,"",value,sizeof(value),path);Monitor m{};if(sscanf_s(value,"%f %f %f %f %f %f %f %f %f %f",&m.offset.x,&m.offset.y,&m.offset.z,&m.tilt,&m.width,&m.height,&m.lens,&m.cameraPitch,&m.yaw,&m.fov)>=7&&finite(m.offset)&&length(m.offset)<10&&std::isfinite(m.tilt)&&fabsf(m.tilt)<1.5f&&m.width>=.2f&&m.width<=4&&m.height>=.2f&&m.height<=4&&m.lens>=0&&m.lens<=1&&std::isfinite(m.cameraPitch)&&fabsf(m.cameraPitch)<1.5f&&std::isfinite(m.yaw)&&fabsf(m.yaw)<6.4f&&std::isfinite(m.fov)&&m.fov>=.25f&&m.fov<=2)monitors[i]=m;}}
inline Pose rigidDriverEye(Pose root){root.p=add(root.p,world(root.b,{0,.75f,0}));root.p.y+=.08f;return root;}
inline M trackedBasis(const RFGRPose& p){float x=p.orientation[0],y=p.orientation[1],z=p.orientation[2],w=p.orientation[3];return {{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};}
inline void update(const char* name,unsigned id,const Pose& body,const Pose& eye,const RFGRPose* tracked,float worldScale,bool driver=true,const Pose* seatFrame=nullptr){
 AcquireSRWLockExclusive(&lock);bool active=supported(name)&&tracked&&valid(body.b)&&valid(eye.b)&&worldScale>.1f;
 packet.active=active?((driver?7u:5u)|(vrtestspawn::tank(name)?8u:0u)):0u;if(!active){identity=~0u;auto snapshot=packet;ReleaseSRWLockExclusive(&lock);channel.publish(snapshot);return;}
 scale=worldScale;if(vrtestspawn::rotatingTankCabin(name)&&seatFrame&&valid(seatFrame->b)&&finite(seatFrame->p)){if(screenSeatVehicle!=id){screenSeatPivot=mul(local(body.b,sub(seatFrame->p,body.p)),1/scale);screenSeatVehicle=id;}screenSeatLocal={relative(body.b,seatFrame->b),local(body.b,sub(seatFrame->p,body.p))};}if(id!=identity){identity=id;load(name);if(!fixedSeat){seat=driver?mul(local(body.b,sub(eye.p,body.p)),1/scale):V{-.451930612f,.366235375f,.815292835f};fixedSeat=true;if(driver)save();}grabbed[0]=grabbed[1]=-1;validFeeds=0;}
 M trackedFrame=trackedBasis(*tracked);auto axis=[&](V v){V e=local(eye.b,v);e.z=-e.z;return world(trackedFrame,e);};
 auto point=[&](V v){return add({tracked->position[0],tracked->position[1],tracked->position[2]},axis(mul(sub(v,eye.p),1/scale)));};
 auto stage=[&](Pose p){return Pose{{axis(p.b.r),axis(p.b.u),mul(axis(p.b.f),-1)},point(p.p)};};
 packet.vehicle=id;packet.vehicleStage=stage(body);packet.grabbed=0;
 const float mountScale=tankMode?cameraMountScale:scale;
 const V defaults[4]={{0,1.7f,3.9f},{0,1.7f,-3.9f},{1.6f,1.7f,0},{-1.6f,1.7f,0}};
 const V tankDefaults[5]={{0,1.7f,3.9f},{0,2.3f,2},{-1.6f,1.7f,0},{1.6f,1.7f,0},{0,1.7f,-3.9f}};
 const float tankYaw[5]={0,0,-1.5707963f,1.5707963f,3.14159265f};
 const float yaw[4]={0,3.14159265f,1.5707963f,-1.5707963f};M unitBasis{{1,0,0},{0,1,0},{0,0,1}};
 for(unsigned i=0;i<cameraCount();++i){nativeMounts[i]={compose(body.b,compose(turnAround(unitBasis,{0,1,0},(tankMode?tankYaw[i]:yaw[i])),turnAround(unitBasis,{1,0,0},monitors[i].cameraPitch))),add(body.p,world(body.b,mul(add(tankMode?tankDefaults[i]:defaults[i],offsets[i]),mountScale)))};if(tankMode&&i==1&&barrelReady){nativeMounts[i]=barrelMount;nativeMounts[i].p=add(barrelMount.p,world(barrelMount.b,add(vrtestspawn::artilleryTank(type)?artilleryModelOffset:V{},mul(offsets[i],mountScale))));}packet.mounts[i]=stage(nativeMounts[i]);if(grabbed[0]==int(i)||grabbed[1]==int(i))packet.grabbed|=1u<<i;}
 Pose screenBase=body;V panelOffset=add(seat,screenOffset);if(vrtestspawn::rotatingTankCabin(name)&&screenSeatVehicle==id){screenBase={compose(body.b,screenSeatLocal.b),add(body.p,world(body.b,screenSeatLocal.p))};panelOffset=sub(panelOffset,screenSeatPivot);}
 Pose screens{compose(screenBase.b,compose(turnAround(unitBasis,{0,1,0},assemblyYaw),turnAround(unitBasis,{1,0,0},tilt))),add(screenBase.p,world(screenBase.b,mul(panelOffset,scale)))};nativeScreens=screens;packet.screens=stage(screens);
 packet.texture=texture;packet.epoch=epoch;packet.valid=validFeeds;memcpy(packet.feedTick,feedTick,sizeof(feedTick));RFGRAPCCameras snapshot=packet;ReleaseSRWLockExclusive(&lock);channel.publish(snapshot);
}
// Tank-only authoring. APC placements remain locked.
struct EditInput {bool closer=false,farther=false,wider=false,narrower=false,taller=false,shorter=false,raise=false,lower=false,digit[5]{},control=false,grab=false,up=false,down=false,left=false,right=false,more=false,less=false,pgup=false,pgdown=false,home=false,end=false;};
inline bool editDirty=false;inline DWORD editChanged=0;
inline bool editGrab=false,editGrip=false;inline DWORD editTick=0;inline bool editControl=false,editDigits[5]{},editZero=false;
inline void edit(const EditInput& k,float dt,const RFGRPose* hand=nullptr,bool grip=false){
 for(unsigned i=0;i<5;++i){if(k.digit[i]&&!editDigits[i]){selected=int(i);editGrab=false;}editDigits[i]=k.digit[i];}
 if(k.control&&!editControl){cameraEdit=!cameraEdit;editGrab=false;}editControl=k.control;
 if(k.grab&&!editZero&&!cameraEdit&&selected>=0)editGrab=!editGrab;editZero=k.grab;
 dt=(std::clamp)(dt,0.f,.05f);if(vrtestspawn::tank(type)&&(k.raise||k.lower)){tankBodyHeight=(std::clamp)(tankBodyHeight.load()+(float(k.raise)-float(k.lower))*.3f*dt,-2.f,2.f);editDirty=true;editChanged=GetTickCount();}if(selected<0||selected>=5){if(editDirty&&GetTickCount()-editChanged>400){save();editDirty=false;}return;}auto& m=monitors[selected];bool changed=false;
 V delta{float(k.right)-float(k.left),float(k.up)-float(k.down),0};
 if(cameraEdit){delta.z=(std::clamp)(float(k.pgup)-float(k.pgdown)+float(k.farther)-float(k.closer),-1.f,1.f);setOffset(selected,add(offsets[selected],mul(delta,.3f*dt)));float old=m.fov;m.fov=(std::clamp)(m.fov+(float(k.more)-float(k.less))*.5f*dt,.25f,2.f);changed=length(delta)>0||old!=m.fov;}
 else {delta.z=float(k.farther)-float(k.closer);m.width=(std::clamp)(m.width+(float(k.wider)-float(k.narrower))*dt,.2f,4.f);m.height=(std::clamp)(m.height+(float(k.taller)-float(k.shorter))*dt,.2f,4.f);m.offset=add(m.offset,mul(delta,.3f*dt));float old=m.lens;m.lens=(std::clamp)(m.lens+(float(k.more)-float(k.less))*.5f*dt,0.f,1.f);m.tilt=(std::clamp)(m.tilt+(float(k.pgup)-float(k.pgdown))*dt,-1.4f,1.4f);m.yaw=(std::clamp)(m.yaw+(float(k.home)-float(k.end))*dt,-3.14f,3.14f);changed=k.wider||k.narrower||k.taller||k.shorter||length(delta)>0||old!=m.lens||k.pgup||k.pgdown||k.home||k.end;
 if(editGrab&&hand&&hand->active&&(hand->validFlags&3)==3){V point{hand->position[0],hand->position[1],hand->position[2]};V anchor=mul(local(packet.screens.b,sub(point,packet.screens.p)),1/assemblyScale);anchor.z=-anchor.z;V initial= sub(monitorOffset(selected),m.offset);m.offset=sub(anchor,initial);changed=true;if(grip&&!editGrip)editGrab=false;}}
 editGrip=grip;if(changed){editDirty=true;editChanged=GetTickCount();}if(editDirty&&!editGrab&&GetTickCount()-editChanged>400){save();editDirty=false;}
}
inline bool input(const RFGRShared* source,bool foreground,bool menu){
#ifndef RFGRVR_DEVELOPER_TOOLS
 return false;
#else
 AcquireSRWLockExclusive(&lock);bool driver=(packet.active&2)!=0;if(!driver||!tankMode||!foreground||menu||!source){if(editDirty){save();editDirty=false;}editTick=0;editGrip=false;ReleaseSRWLockExclusive(&lock);return driver;}
 DWORD now=GetTickCount();float dt=editTick?float(now-editTick)*.001f:0;editTick=now;EditInput k;auto held=[](int v){return (GetAsyncKeyState(v)&0x8000)!=0;};const unsigned scans[5]={0x4f,0x50,0x51,0x4b,0x4c};for(unsigned i=0;i<5;++i)k.digit[i]=vrtankkeys::down(scans[i]);k.raise=vrtankkeys::down(0x52,true);k.lower=vrtankkeys::down(0x53,true);k.control=held(VK_CONTROL);k.grab=vrtankkeys::down(0x52);k.up=vrtankkeys::down(0x48,true);k.down=vrtankkeys::down(0x50,true);k.left=vrtankkeys::down(0x4b,true);k.right=vrtankkeys::down(0x4d,true);k.more=held(VK_MULTIPLY);k.less=held(VK_SUBTRACT);k.pgup=vrtankkeys::down(0x49,true);k.pgdown=vrtankkeys::down(0x51,true);k.home=vrtankkeys::down(0x47,true);k.end=vrtankkeys::down(0x4f,true);k.narrower=held(VK_OEM_4);k.wider=held(VK_OEM_6);k.shorter=held(VK_OEM_1);k.taller=held(VK_OEM_7);k.closer=held(VK_OEM_PERIOD);k.farther=held(VK_OEM_2);
 edit(k,dt,&source->right,source->gripValue[1]>.55f);int screen=selected;bool camera=cameraEdit,grab=editGrab;ReleaseSRWLockExclusive(&lock);
 static DWORD last=0;if(now-last>200&&screen>=0){last=now;char message[128];sprintf_s(message,"Tank %d: %s%s",screen+1,camera?"CAMERA":"SCREEN",grab?" - move right hand, grip to place":" - Ctrl toggles camera/screen");vrstatus::notify(message);}return true;
#endif
}

inline bool next(Pose& camera,unsigned& index,unsigned slot=0){static unsigned cursor=0;static vrtank::Feeds tankFeeds;AcquireSRWLockShared(&lock);bool active=(packet.active&2)&&identity!=~0u;if(active){index=tankMode?tankFeeds.next(identity,slot):(slot%2==0?0:1+cursor++%3);renderIndex=index;camera=nativeMounts[index];}ReleaseSRWLockShared(&lock);return active;}
inline void captured(uint64_t handle,unsigned generation,unsigned index){AcquireSRWLockExclusive(&lock);texture=handle;epoch=generation;validFeeds|=1u<<index;feedTick[index]=GetTickCount();ReleaseSRWLockExclusive(&lock);}
}
