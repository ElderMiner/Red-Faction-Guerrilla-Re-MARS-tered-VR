#pragma once
#include "modern_wave_transport.h"
#include <algorithm>
#include <numeric>
#include <map>
namespace modernwave {
inline V cross(V a,V b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
inline float axis(V v,unsigned n){return n==0?v.x:n==1?v.y:v.z;}
struct Triangle {uint64_t id=0;V a,b,c;Profile material;float sheetThickness=0;};
// Owned, world-space triangle snapshot. No native pointers survive publication.
// A material belongs to an explicit geometry record, never a guessed colour ID.
class Scene {
 struct Box {V lo{INFINITY,INFINITY,INFINITY},hi{-INFINITY,-INFINITY,-INFINITY};
  void add(V p){lo={(std::min)(lo.x,p.x),(std::min)(lo.y,p.y),(std::min)(lo.z,p.z)};hi={(std::max)(hi.x,p.x),(std::max)(hi.y,p.y),(std::max)(hi.z,p.z)};}
  bool hit(V p,V d,float length)const{float near=0,far=length;for(unsigned k=0;k<3;++k){float direction=axis(d,k),origin=axis(p,k);if(std::abs(direction)<1e-8f){if(origin<axis(lo,k)||origin>axis(hi,k))return false;continue;}float a=(axis(lo,k)-origin)/direction,b=(axis(hi,k)-origin)/direction;if(a>b)std::swap(a,b);near=(std::max)(near,a);far=(std::min)(far,b);if(near>far)return false;}return true;}
 };
 struct Node {Box bounds;unsigned first=0,count=0,left=0,right=0;};
 std::vector<Triangle> triangles;std::vector<unsigned> order;std::vector<Node> nodes;uint64_t version=0;
 unsigned build(unsigned first,unsigned count){unsigned index=unsigned(nodes.size());nodes.emplace_back();Box bounds,centres;for(unsigned i=first;i<first+count;++i){auto& t=triangles[order[i]];bounds.add(t.a);bounds.add(t.b);bounds.add(t.c);centres.add(mul(add(add(t.a,t.b),t.c),1.f/3));}nodes[index].bounds=bounds;
  if(count<=8){nodes[index].first=first;nodes[index].count=count;return index;}V extent=sub(centres.hi,centres.lo);unsigned dim=extent.y>extent.x?1:0;if(extent.z>axis(extent,dim))dim=2;unsigned half=count/2;
  std::nth_element(order.begin()+first,order.begin()+first+half,order.begin()+first+count,[&](unsigned a,unsigned b){auto& x=triangles[a];auto& y=triangles[b];return axis(add(add(x.a,x.b),x.c),dim)<axis(add(add(y.a,y.b),y.c),dim);});
  unsigned left=build(first,half),right=build(first+half,count-half);nodes[index].left=left;nodes[index].right=right;return index;
 }
 struct Hit {float distance;unsigned triangle;};
 bool hits(unsigned node,V p,V d,float length,std::vector<Hit>& output)const{const auto& n=nodes[node];if(!n.bounds.hit(p,d,length))return true;if(!n.count)return hits(n.left,p,d,length,output)&&hits(n.right,p,d,length,output);
  for(unsigned i=n.first;i<n.first+n.count;++i){unsigned index=order[i];const auto& t=triangles[index];V e1=sub(t.b,t.a),e2=sub(t.c,t.a),q=cross(d,e2);float determinant=dot(e1,q);if(std::abs(determinant)<1e-8f)continue;float inverse=1/determinant;V s=sub(p,t.a);float u=dot(s,q)*inverse;if(u<-.000001f||u>1.000001f)continue;V r=cross(s,e1);float v=dot(d,r)*inverse;if(v<-.000001f||u+v>1.000001f)continue;float distance=dot(e2,r)*inverse;if(distance<=.001f||distance>=length-.001f)continue;if(output.size()>=128)return false;output.push_back({distance,index});}return true;
 }
public:
 bool publish(std::vector<Triangle> input,uint64_t revision){
  if(!revision||input.size()>32768)return false;
  for(const auto& t:input){if(!t.id||!finite(t.a)||!finite(t.b)||!finite(t.c)||!std::isfinite(t.sheetThickness)||t.sheetThickness<0||dot(cross(sub(t.b,t.a),sub(t.c,t.a)),cross(sub(t.b,t.a),sub(t.c,t.a)))<1e-12f)return false;
   auto check=interact(t.material,{0,0,-1},{0,0,1},{1,1,1},t.sheetThickness);if(!check.count)return false;}
  // Publication is transactional: a rejected snapshot retains the old scene.
  Scene next;next.triangles=std::move(input);next.version=revision;next.order.resize(next.triangles.size());std::iota(next.order.begin(),next.order.end(),0u);if(!next.order.empty())next.build(0,unsigned(next.order.size()));*this=std::move(next);return true;
 }
 uint64_t revision()const{return version;}
 bool segment(V from,V to,V& throughput)const{
  throughput={};if(!version||!finite(from)||!finite(to))return false;V delta=sub(to,from);float length=std::sqrt(dot(delta,delta));if(!std::isfinite(length)||length<.002f)return false;V direction=mul(delta,1/length);std::vector<Hit> intersections;if(!nodes.empty()&&!hits(0,from,direction,length,intersections))return false;
  std::sort(intersections.begin(),intersections.end(),[](const Hit& a,const Hit& b){return a.distance<b.distance;});throughput={1,1,1};float previous=-1;uint64_t previousId=0;
  for(auto h:intersections){const auto& t=triangles[h.triangle];if(t.id==previousId&&std::abs(h.distance-previous)<.0001f)continue;previous=h.distance;previousId=t.id;
   if(t.material.transmission<=0||t.material.metal>=1){throughput={};return true;}V normal=unit(cross(sub(t.b,t.a),sub(t.c,t.a)));float cosine=std::abs(dot(direction,normal));float f=dielectric(cosine,1,t.material.ior);V transmission=mul(beer(t.material.absorption,t.sheetThickness/(std::max)(cosine,.02f)),(1-f)*clamp(t.material.transmission)*(1-clamp(t.material.metal)));throughput=product(throughput,transmission);if(strength(throughput)<1e-8f){throughput={};return true;}
  }return true;
 }
 static bool trace(void* context,V from,V to,uint64_t,uint64_t,V& throughput){return context&&((const Scene*)context)->segment(from,to,throughput);}
 Result transport(const std::vector<Surface>& surfaces,const std::vector<Field>& sources,Limits limits={})const{
  // Cache only within this immutable snapshot and solve. Destruction/movement
  // cannot inherit a stale clear path from another scene revision.
  struct Cache {const Scene* scene;struct Value {bool known;V throughput;};std::map<std::array<float,6>,Value> entries;
   static bool query(void* context,V a,V b,uint64_t,uint64_t,V& value){auto& cache=*(Cache*)context;if(!finite(a)||!finite(b))return false;std::array<float,6> key{a.x,a.y,a.z,b.x,b.y,b.z};auto found=cache.entries.find(key);if(found!=cache.entries.end()){value=found->second.throughput;return found->second.known;}bool known=cache.scene->segment(a,b,value);cache.entries.emplace(key,Value{known,value});return known;}
  } cache{this};auto result=solve(surfaces,sources,Cache::query,&cache,limits);result.revision=version;return result;
 }
 V shade(const Result& fields,const Surface& receiver,V eye,unsigned budget=2048)const{return fields.valid&&version&&fields.revision==version?evaluate(fields.emitted,receiver,eye,trace,(void*)this,budget):V{};}
};
}
