#pragma once
#include <windows.h>
#include "vr_memory_access.h"
#include "vr_headlight_cones.h"
extern "C" bool RFGRVR_HeadCam_Enabled();
#include <cstring>
#include <cstdio>
#include "../vendor/MinHook.h"
namespace RFGRVRNativeDust {
inline bool readable(const void* p,size_t n){return vrmemory::check(p,n);}
inline bool writable(void* p,size_t n){return vrmemory::check(p,n,true);}
inline unsigned word(const void* p,unsigned offset){unsigned v=0;if(readable((char*)p+offset,4))memcpy(&v,(char*)p+offset,4);return v;}
inline bool selected(const void* info){return readable(info,18)&&!memcmp(info,"env_dust_camera_a",17)&&(((const char*)info)[17]==0||(readable(info,26)&&!memcmp((const char*)info+17,".effectx",9)));}
inline thread_local bool dustScope=false;inline unsigned patches=0;
// Layouts from RFGR_Types_Vfx_Template.h; native pointers are 8-byte sized.
inline bool patchTemplate(void* source){void* data=(void*)(uintptr_t)word(source,0x10);void* name=(void*)(uintptr_t)word(data,0x18);if(!selected(name))return false;unsigned count=word(data,0x50);void* emitters=(void*)(uintptr_t)word(data,0x58);if(!count||count>64||!readable(emitters,count*968))return false;bool changed=false;
 for(unsigned i=0;i<count;++i){auto* emitter=(unsigned char*)emitters+i*968;if(!writable(emitter,968)||emitter[68]>1||emitter[79]>1)continue;changed=changed||emitter[68]||emitter[79];emitter[68]=0;emitter[79]=0;
 // Native initializer8B4FB7 ORs byte44 into material.flags bit80, but never
 // clears it when the template boolean changes. Existing material retains it.
 unsigned materialFlags=word(emitter,0x34);changed=changed||(materialFlags&0x80)!=0;materialFlags&=~0x80u;memcpy(emitter+0x34,&materialFlags,4);
void* runtime=(void*)(uintptr_t)word(emitter,944);if(writable((char*)runtime+30,1)&&*((unsigned char*)runtime+30)<=1)*((unsigned char*)runtime+30)=0;}
 if(changed)++patches;return changed;
}
using Play=unsigned(__cdecl*)(void*,void*,void*,bool,unsigned,int,unsigned,float,bool,unsigned);using Create=void*(__cdecl*)(void*);
inline Play originalPlay=nullptr;inline Create originalCreate=nullptr;
inline unsigned __cdecl onPlay(void* info,void* pos,void* rotation,bool loop,unsigned host,int tag,unsigned source,float volume,bool camera,unsigned category){vrmemory::Scope memoryScope;bool previous=dustScope;dustScope=selected(info);unsigned result=originalPlay(info,pos,rotation,loop,dustScope?~0u:host,dustScope?-1:tag,source,volume,dustScope?false:camera,category);dustScope=previous;return result;}
inline void* __cdecl onCreate(void* effectTemplate){vrmemory::Scope memoryScope;patchTemplate(effectTemplate);vrheadlightcones::patchTemplate(effectTemplate,RFGRVR_HeadCam_Enabled());return originalCreate(effectTemplate);}
inline bool install(unsigned char* base){const unsigned char playSig[]={0x83,0xec,0x20,0x80,0x3d,0x88,0xb5,0xfe,0x02,0x01},createSig[]={0xe9,0x6b,0xff,0xff,0xff};if(memcmp(base+0x3458b0,playSig,5)||word(base+0x3458b0,5)!=(unsigned)(uintptr_t)(base+0x2beb588)||base[0x3458b9]!=1||memcmp(base+0x8ba700,createSig,sizeof(createSig))||base[0x8ba670]!=0xa1||word(base+0x8ba670,1)!=(unsigned)(uintptr_t)(base+0x3623c64))return false;
 if(MH_CreateHook(base+0x3458b0,(void*)&onPlay,(void**)&originalPlay)!=MH_OK)return false;
 if(MH_CreateHook(base+0x8ba670,(void*)&onCreate,(void**)&originalCreate)!=MH_OK){MH_RemoveHook(base+0x3458b0);return false;}
 if(MH_EnableHook(base+0x3458b0)==MH_OK&&MH_EnableHook(base+0x8ba670)==MH_OK)return true;
 MH_DisableHook(base+0x3458b0);MH_DisableHook(base+0x8ba670);MH_RemoveHook(base+0x3458b0);MH_RemoveHook(base+0x8ba670);return false;
}
}


