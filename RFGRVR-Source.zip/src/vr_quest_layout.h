#pragma once
#include "vr_user_settings.h"
namespace vrquest {
constexpr unsigned Detonate=0x400,ButtonCrouch=0x800,Commands=Detonate|ButtonCrouch;
inline unsigned selectorButtons(unsigned physical,const vrsettings::Controls& controls,const vrsettings::Config& config){
 unsigned result=physical&0xf000u;int source=config.questBinding[vrsettings::RB];if(source<18)result&=~vrsettings::masks[source];
 for(int i=vrsettings::A;i<=vrsettings::Y;++i)if(controls.buttons[i].blocked)result&=~vrsettings::masks[i];return result;
}
inline RFGRGamepad output(RFGRGamepad pad,unsigned state,unsigned physical){
 if(state==0x100){RFGRGamepad cinematic{};cinematic.buttons=pad.buttons&(0x8000u|0x10u|0x20u);return cinematic;}
 if(pad.buttons&0x2000u){pad.buttons&=~0x2000u;pad.buttons|=Detonate;}
 if(state>=7&&state<=10){pad.buttons=(pad.buttons&~0x1c0u)|(physical&0xc0u);}else if(pad.buttons&0x40u)pad.buttons|=ButtonCrouch;
 return pad;
}
inline void commands(RFGRGamepad& pad,bool gameplay,bool c4){unsigned flags=pad.buttons&Commands;pad.buttons&=~Commands;if(gameplay&&(flags&Detonate)&&c4)pad.buttons|=0x2000u;}
}
