// Original cube-to-irradiance projection. Fifteen groups produce one 240-byte
// probe: nine cosine-convolved RGB SH coefficients, six distance moments.
TextureCube<float4> radiance:register(t0);
TextureCube<float> distances:register(t1);
SamplerState nearestClamp:register(s0);
RWStructuredBuffer<float4> probe:register(u0);
groupshared float4 sums[64];
float3 direction(uint face,float2 uv){float3 d=face==0?float3(1,-uv.y,-uv.x):face==1?float3(-1,-uv.y,uv.x):face==2?float3(uv.x,1,uv.y):face==3?float3(uv.x,-1,-uv.y):face==4?float3(uv.x,-uv.y,1):float3(-uv.x,-uv.y,-1);return normalize(d);}
float basis(uint k,float3 n){if(k==0)return .2820947918;if(k==1)return .4886025119*n.y;if(k==2)return .4886025119*n.z;if(k==3)return .4886025119*n.x;if(k==4)return 1.0925484306*n.x*n.y;if(k==5)return 1.0925484306*n.y*n.z;if(k==6)return .3153915653*(3*n.z*n.z-1);if(k==7)return 1.0925484306*n.x*n.z;return .5462742153*(n.x*n.x-n.y*n.y);}
[numthreads(64,1,1)]void main(uint3 group:SV_GroupID,uint thread:SV_GroupIndex){
 float2 uv=(float2(thread%8,thread/8)+.5)/4-1;float weight=pow(1+dot(uv,uv),-1.5);float4 sum=0;
 if(group.x<9){[unroll]for(uint face=0;face<6;++face){float3 d=direction(face,uv);float3 c=radiance.SampleLevel(nearestClamp,d,0).rgb;c=all(isfinite(c))?max(c,0):0;sum+=float4(c*basis(group.x,d)*weight,weight);}}
 else {float distance=distances.SampleLevel(nearestClamp,direction(group.x-9,uv),0);distance=isfinite(distance)?clamp(distance,0,10000):0;sum=float4(distance*weight,distance*distance*weight,0,weight);}
 sums[thread]=sum;GroupMemoryBarrierWithGroupSync();
 [unroll]for(uint stride=32;stride>0;stride/=2){if(thread<stride)sums[thread]+=sums[thread+stride];GroupMemoryBarrierWithGroupSync();}
 if(thread==0){float4 total=sums[0];if(group.x<9){float kernel=group.x==0?3.1415926536:group.x<4?2.0943951024:.7853981634;probe[group.x]=float4(total.rgb*(12.5663706144/max(total.w,1e-6))*kernel,1);}else probe[group.x]=float4(total.xy/max(total.w,1e-6),0,1);}
}
