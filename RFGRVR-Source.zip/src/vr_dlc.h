#pragma once
#include <atomic>
#include <cstddef>
#include <cstring>
namespace vrdlc {
inline std::atomic<bool> active{false};
// Verified live Demons of the Badlands territory, not a weapon/asset guess.
inline bool territory(const char* value,size_t bytes){
 if(!value||bytes<19||memcmp(value,"dlc01_",6))return false;
 const char* end=(const char*)memchr(value,0,bytes);
 return end&&end-value>=17&&end-value<=63&&!strcmp(end-11,".rfgzone_pc");
}
struct Keys {
 unsigned previous=0;unsigned edges(bool enabled,unsigned held){
  unsigned result=enabled?held&~previous:0;previous=held;return result;
 }
};
}
