#pragma once
#include "modern_generated_ids.h"
#include "modern_generated_source.h"
namespace moderngenerated {
using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11PixelShader**);
inline int identify(const void* p,size_t size){if(!p||size<32||memcmp(p,"DXBC",4))return -1;for(auto i:identities)if(i.bytes==size&&!memcmp((const char*)p+4,i.hash,16))return i.mode;return -1;}
inline HRESULT create(Create native,ID3D11Device* device,const void* original,SIZE_T size,ID3D11PixelShader** shader,int mode,bool& substituted){
 substituted=false;static std::mutex mutex;static Microsoft::WRL::ComPtr<ID3DBlob> codes[sizeof(variants)/sizeof(variants[0])];std::lock_guard<std::mutex> lock(mutex);HRESULT hr=S_OK;
 if(!codes[mode]){D3D_SHADER_MACRO macros[sizeof(macroNames)/sizeof(macroNames[0])+1]{};for(unsigned i=0;i<sizeof(macroNames)/sizeof(macroNames[0]);++i)macros[i]={macroNames[i],variants[mode].values[i]};Microsoft::WRL::ComPtr<ID3DBlob> errors;hr=D3DCompile(source,sizeof(source)-1,"RFGRVR modern surface",macros,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&codes[mode],&errors);if(FAILED(hr)&&errors)OutputDebugStringA((const char*)errors->GetBufferPointer());}
 if(SUCCEEDED(hr))hr=native(device,codes[mode]->GetBufferPointer(),codes[mode]->GetBufferSize(),nullptr,shader);
 if(SUCCEEDED(hr)){substituted=true;return hr;}return native(device,original,size,nullptr,shader);
}
}
