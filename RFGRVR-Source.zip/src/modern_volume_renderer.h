#pragma once
#include "modern_volumetrics.h"
#include "vr_eye_pipeline.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <algorithm>
#include <cstring>
namespace modernvolume {
// Immediate draws use a private command list; native deferred HDR work records
// directly into its existing list with complete graphics-state restoration.
// Cached quarter-resolution
// HDR scattering/depth targets never retain swapchain buffers.
class Renderer {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> worker;
 Ptr<ID3D11VertexShader> vertex;Ptr<ID3D11PixelShader> volume,composite;
 Ptr<ID3D11Buffer> constants;Ptr<ID3D11SamplerState> sampler;
 Ptr<ID3D11RasterizerState> raster;Ptr<ID3D11DepthStencilState> depthOff;
 Ptr<ID3D11BlendState> blend;Ptr<ID3D11Texture2D> low,lowDepth;
 Ptr<ID3D11RenderTargetView> lowRT,lowDepthRT;Ptr<ID3D11ShaderResourceView> lowSRV,lowDepthSRV;
 unsigned width=0,height=0;
 bool init(ID3D11Device* device){
  if(owner.Get()==device&&worker)return true;*this={};owner=device;
  const char* v="struct O{float4 p:SV_Position;float2 uv:TEXCOORD0;};O main(uint id:SV_VertexID){O o;float2 p=float2((id<<1)&2,id&2);o.p=float4(p*float2(2,-2)+float2(-1,1),0,1);o.uv=p;return o;}";
  const char* p=R"SHADER(
cbuffer Frame:register(b0){row_major float4x4 inverseViewProjection;float4 eyeMaxDistance;};
Texture2D<float4> scattering:register(t0);Texture2D<float> distances:register(t1),sceneDepth:register(t2);SamplerState nearestClamp:register(s0);
struct In{float4 position:SV_Position;float2 uv:TEXCOORD0;};
float4 main(In input):SV_Target{
 float z=sceneDepth.SampleLevel(nearestClamp,input.uv,0);float4 p=mul(inverseViewProjection,float4(input.uv*float2(2,-2)+float2(-1,1),z,1));
 if(abs(p.w)<1e-8)return float4(0,0,0,1);float center=length(p.xyz/p.w-eyeMaxDistance.xyz);
 uint width,height;scattering.GetDimensions(width,height);float2 q=input.uv*float2(width,height)-.5;int2 cell=(int2)floor(q);float2 f=frac(q);float4 sum=0;float weights=0;
 [unroll]for(int y=0;y<2;++y)[unroll]for(int x=0;x<2;++x){int2 at=clamp(cell+int2(x,y),int2(0,0),int2(width-1,height-1));float d=distances.Load(int3(at,0));float similarity=abs(d-center)/max(.025,center*.02);float w=(x?f.x:1-f.x)*(y?f.y:1-f.y)*exp(-similarity*similarity);sum+=scattering.Load(int3(at,0))*w;weights+=w;}
 return weights>1e-5?sum/weights:float4(0,0,0,1);
})SHADER";
  Ptr<ID3DBlob> a,b,c;if(FAILED(D3DCompile(v,strlen(v),nullptr,nullptr,nullptr,"main","vs_4_0",0,0,&a,nullptr))||FAILED(D3DCompile(source,sizeof(source)-1,nullptr,nullptr,nullptr,"main","ps_4_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&b,nullptr))||FAILED(D3DCompile(p,strlen(p),nullptr,nullptr,nullptr,"main","ps_4_0",D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&c,nullptr)))return false;
  if(FAILED(device->CreateVertexShader(a->GetBufferPointer(),a->GetBufferSize(),nullptr,&vertex))||FAILED(device->CreatePixelShader(b->GetBufferPointer(),b->GetBufferSize(),nullptr,&volume))||FAILED(device->CreatePixelShader(c->GetBufferPointer(),c->GetBufferSize(),nullptr,&composite)))return false;
  D3D11_BUFFER_DESC bd{};bd.ByteWidth=sizeof(Frame);bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;
  D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_POINT;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.MaxLOD=D3D11_FLOAT32_MAX;
  D3D11_RASTERIZER_DESC rd{};rd.FillMode=D3D11_FILL_SOLID;rd.CullMode=D3D11_CULL_NONE;rd.DepthClipEnable=TRUE;
  D3D11_DEPTH_STENCIL_DESC dd{};dd.DepthFunc=D3D11_COMPARISON_ALWAYS;
  D3D11_BLEND_DESC blendDesc{};auto& rt=blendDesc.RenderTarget[0];rt.BlendEnable=TRUE;rt.SrcBlend=D3D11_BLEND_ONE;rt.DestBlend=D3D11_BLEND_SRC_ALPHA;rt.BlendOp=D3D11_BLEND_OP_ADD;rt.SrcBlendAlpha=D3D11_BLEND_ZERO;rt.DestBlendAlpha=D3D11_BLEND_ONE;rt.BlendOpAlpha=D3D11_BLEND_OP_ADD;rt.RenderTargetWriteMask=D3D11_COLOR_WRITE_ENABLE_ALL;
  return SUCCEEDED(device->CreateBuffer(&bd,nullptr,&constants))&&SUCCEEDED(device->CreateSamplerState(&sd,&sampler))&&SUCCEEDED(device->CreateRasterizerState(&rd,&raster))&&SUCCEEDED(device->CreateDepthStencilState(&dd,&depthOff))&&SUCCEEDED(device->CreateBlendState(&blendDesc,&blend))&&SUCCEEDED(device->CreateDeferredContext(0,&worker));
 }
 bool resize(unsigned w,unsigned h){w=(std::max)(1u,(w+3)/4);h=(std::max)(1u,(h+3)/4);if(width==w&&height==h)return true;
  Ptr<ID3D11Texture2D> colour,z;Ptr<ID3D11RenderTargetView> rt,zrt;Ptr<ID3D11ShaderResourceView> srv,zsrv;
  D3D11_TEXTURE2D_DESC d{};d.Width=w;d.Height=h;d.MipLevels=d.ArraySize=d.SampleDesc.Count=1;d.Format=DXGI_FORMAT_R16G16B16A16_FLOAT;d.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;
  if(FAILED(owner->CreateTexture2D(&d,nullptr,&colour))||FAILED(owner->CreateRenderTargetView(colour.Get(),nullptr,&rt))||FAILED(owner->CreateShaderResourceView(colour.Get(),nullptr,&srv)))return false;
  d.Format=DXGI_FORMAT_R32_FLOAT;if(FAILED(owner->CreateTexture2D(&d,nullptr,&z))||FAILED(owner->CreateRenderTargetView(z.Get(),nullptr,&zrt))||FAILED(owner->CreateShaderResourceView(z.Get(),nullptr,&zsrv)))return false;
  low=colour;lowDepth=z;lowRT=rt;lowDepthRT=zrt;lowSRV=srv;lowDepthSRV=zsrv;width=w;height=h;return true;
 }
public:
 bool draw(ID3D11Device* device,ID3D11DeviceContext* context,ID3D11RenderTargetView* target,ID3D11ShaderResourceView* scene,ID3D11ShaderResourceView* shadows,unsigned w,unsigned h,const Frame& frame){
  if(!device||!context||!target||!scene||!w||!h||!modernvolume::valid(frame)||frame.medium[0]<=0)return false;
  Ptr<ID3D11Resource> destination;target->GetResource(&destination);Ptr<ID3D11Texture2D> texture;if(FAILED(destination.As(&texture)))return false;D3D11_TEXTURE2D_DESC description{};texture->GetDesc(&description);D3D11_RENDER_TARGET_VIEW_DESC view{};target->GetDesc(&view);
  if(view.ViewDimension!=D3D11_RTV_DIMENSION_TEXTURE2D||description.SampleDesc.Count!=1||(description.Width>>view.Texture2D.MipSlice)!=w||(description.Height>>view.Texture2D.MipSlice)!=h||(view.Format!=DXGI_FORMAT_R16G16B16A16_FLOAT&&view.Format!=DXGI_FORMAT_R32G32B32A32_FLOAT&&view.Format!=DXGI_FORMAT_R11G11B10_FLOAT))return false;
  for(unsigned i=0;i<unsigned((std::min)(frame.options[0],8.f));++i)if(frame.lights[i].coneShadow[2]>=0&&!shadows)return false;
  if(!init(device)||!resize(w,h))return false;
  const bool deferred=context->GetType()==D3D11_DEVICE_CONTEXT_DEFERRED;
  RFGRVREyePipeline previous;Ptr<ID3D11Predicate> predicate;BOOL predicateValue=FALSE;
  if(deferred){previous.save(context);context->GetPredication(&predicate,&predicateValue);context->SetPredication(nullptr,FALSE);}
  auto* commands=deferred?context:worker.Get();if(!deferred)commands->ClearState();
  commands->IASetInputLayout(nullptr);commands->GSSetShader(nullptr,nullptr,0);commands->HSSetShader(nullptr,nullptr,0);commands->DSSetShader(nullptr,nullptr,0);commands->OMSetBlendState(nullptr,nullptr,~0u);commands->UpdateSubresource(constants.Get(),0,nullptr,&frame,0,0);auto* cb=constants.Get();commands->PSSetConstantBuffers(0,1,&cb);commands->VSSetShader(vertex.Get(),nullptr,0);commands->PSSetShader(volume.Get(),nullptr,0);commands->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);commands->RSSetState(raster.Get());commands->OMSetDepthStencilState(depthOff.Get(),0);auto* s=sampler.Get();commands->PSSetSamplers(0,1,&s);
  ID3D11RenderTargetView* outputs[]={lowRT.Get(),lowDepthRT.Get()};commands->OMSetRenderTargets(2,outputs,nullptr);D3D11_VIEWPORT vp{0,0,float(width),float(height),0,1};commands->RSSetViewports(1,&vp);ID3D11ShaderResourceView* inputs[]={scene,shadows};commands->PSSetShaderResources(0,2,inputs);commands->Draw(3,0);
  ID3D11ShaderResourceView* empty[3]{};commands->PSSetShaderResources(0,3,empty);commands->OMSetRenderTargets(1,&target,nullptr);ID3D11ShaderResourceView* compositeInputs[]={lowSRV.Get(),lowDepthSRV.Get(),scene};commands->PSSetShaderResources(0,3,compositeInputs);commands->PSSetShader(composite.Get(),nullptr,0);commands->OMSetBlendState(blend.Get(),nullptr,~0u);vp.Width=float(w);vp.Height=float(h);commands->RSSetViewports(1,&vp);commands->Draw(3,0);commands->PSSetShaderResources(0,3,empty);
  if(deferred){previous.restore(context);context->SetPredication(predicate.Get(),predicateValue);return true;}
  Ptr<ID3D11CommandList> list;if(FAILED(commands->FinishCommandList(FALSE,&list)))return false;context->ExecuteCommandList(list.Get(),TRUE);return true;
 }
 unsigned quarterWidth()const{return width;}unsigned quarterHeight()const{return height;}
};
}
