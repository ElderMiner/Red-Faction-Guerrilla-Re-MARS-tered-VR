#define MAX_VOLUME_LIGHTS 8
struct Light {float4 positionKind;float4 directionRange;float4 colourInner;float4 coneShadow;row_major float4x4 worldToShadow;row_major float4x4 worldToShadow1;row_major float4x4 worldToShadow2;};
cbuffer Frame:register(b0){row_major float4x4 inverseViewProjection;float4 eyeMaxDistance;float4 medium;float4 options;Light lights[MAX_VOLUME_LIGHTS];row_major float4x4 worldViewProjection;};
Texture2D<float> sceneDepth:register(t0);Texture2DArray<float> shadowDepth:register(t1);
SamplerState nearestClamp:register(s0);
struct In{float4 position:SV_Position;float2 uv:TEXCOORD0;};
float3 unit(float3 v){return v*rsqrt(max(dot(v,v),1e-10));}
float phase(float cosine,float g){g=clamp(g,-.9,.9);float d=max(1+g*g-2*g*cosine,.001);return (1-g*g)/(12.5663706144*d*sqrt(d));}
float visibility(Light light,float3 world){
 if(light.coneShadow.z<0)return 1;
 // A directional source uses one radiance evaluation, selecting the first
 // containing native cascade. Never add the same sun three times.
 int count=light.positionKind.w<.5&&light.directionRange.w>2.5?3:1;
 [loop]for(int cascade=0;cascade<count;++cascade){
  float4 q=cascade==0?mul(light.worldToShadow,float4(world,1)):(cascade==1?mul(light.worldToShadow1,float4(world,1)):mul(light.worldToShadow2,float4(world,1)));
  if(q.w<=0)continue;float3 p=q.xyz/q.w;
  if(any(p.xy<0)||any(p.xy>1)||p.z<0||p.z>1)continue;
  uint width,height,layers;shadowDepth.GetDimensions(width,height,layers);float layer=light.coneShadow.z+cascade;if(layer>=layers)return 0;
  float2 texel=1.0/float2(max(width,1),max(height,1));float result=0;
  [unroll]for(int y=0;y<2;++y)[unroll]for(int x=0;x<2;++x){
   float stored=shadowDepth.SampleLevel(nearestClamp,float3(p.xy+(float2(x,y)-.5)*texel,layer),0);
   result+=light.coneShadow.w>0?step(stored-light.coneShadow.y,p.z):step(p.z-light.coneShadow.y,stored);
  }
  return result*.25;
 }
 return 0;
}
// Short screen-space contact-shadow query for point/spot sources. This uses
// the current eye depth, not the directional shadow map. Off-screen geometry
// is unavailable; this is contact occlusion, not a complete local shadow map.
float contactVisibility(float3 world,float3 source){
 if(options.w<.5)return 1;
 float3 delta=source-world;float reach=length(delta);if(reach<.1)return 1;
 [unroll]for(int stepIndex=1;stepIndex<=4;++stepIndex){
  float3 test=world+delta*(stepIndex/5.0);float4 clip=mul(worldViewProjection,float4(test,1));
  if(clip.w<=0)continue;float3 projected=clip.xyz/clip.w;float2 uv=projected.xy*float2(.5,-.5)+.5;
  if(any(uv<0)||any(uv>1)||projected.z<0||projected.z>1)continue;
  float depth=sceneDepth.SampleLevel(nearestClamp,uv,0);float4 surface=mul(inverseViewProjection,float4(projected.xy,depth,1));if(abs(surface.w)<1e-8)continue;
  float separation=length(test-eyeMaxDistance.xyz)-length(surface.xyz/surface.w-eyeMaxDistance.xyz);
  if(separation>.04&&separation<max(.12,reach*.08))return 0;
 }
 return 1;
}
float3 illumination(float3 samplePosition,float3 viewRay){
 float3 sum=0;
 [loop]for(int n=0;n<min((int)options.x,MAX_VOLUME_LIGHTS);++n){Light light=lights[n];float3 toLight;float attenuation=1;
  if(light.positionKind.w<.5)toLight=unit(light.directionRange.xyz);
  else {float3 delta=light.positionKind.xyz-samplePosition;float distance=length(delta);float range=max(light.directionRange.w,.001);if(distance>=range)continue;toLight=delta/max(distance,.001);float window=saturate(1-pow(distance/range,4));attenuation=window*window/max(distance*distance,1);
   if(light.positionKind.w>1.5){float angle=dot(-toLight,unit(light.directionRange.xyz));float cone=saturate((angle-light.coneShadow.x)/max(light.colourInner.w-light.coneShadow.x,1e-5));attenuation*=cone*cone*(3-2*cone);}
  }
  float contact=light.positionKind.w>.5?contactVisibility(samplePosition,light.positionKind.xyz):1;
  sum+=max(light.colourInner.rgb,0)*attenuation*phase(dot(viewRay,toLight),options.z)*visibility(light,samplePosition)*contact;
 }
 return sum;
}
float4 integrate(In input) {
 float depth=sceneDepth.SampleLevel(nearestClamp,input.uv,0);
 float4 position=mul(inverseViewProjection,float4(input.uv*float2(2,-2)+float2(-1,1),depth,1));
 if(abs(position.w)<1e-8)return float4(0,0,0,1);
 float3 delta=position.xyz/position.w-eyeMaxDistance.xyz;float distance=min(length(delta),max(eyeMaxDistance.w,0));float3 ray=unit(delta);
 // Night haze is analytic distance fog, not globally lit volumetric scattering.
 // The first 18 metres are clear; density and colour come from the night plan.
 if(options.w>1.5){float path=max(distance-18,0);float amount=min(1-exp(-max(medium.x,0)*path),.22);return float4(max(lights[0].colourInner.rgb,0)*amount,1-amount);}
 int steps=clamp((int)options.y,8,64);float ds=distance/steps,transmittance=1;float3 scattering=0;
 // Deterministic midpoint integration: no screen-space noise or eye history.
 [loop]for(int k=0;k<steps;++k){float3 p=eyeMaxDistance.xyz+ray*((k+.5)*ds);float density=max(medium.x,0)*exp(clamp(-(p.y-medium.y)*max(medium.z,0),-6,6));
  float segment=exp(-density*ds);scattering+=transmittance*(1-segment)*saturate(medium.w)*illumination(p,ray);transmittance*=segment;if(transmittance<.001)break;
 }
 return float4(max(scattering,0),saturate(transmittance));
}
struct Output {float4 volume:SV_Target0;float distance:SV_Target1;};
Output main(In input){Output o;o.volume=integrate(input);float depth=sceneDepth.SampleLevel(nearestClamp,input.uv,0);float4 p=mul(inverseViewProjection,float4(input.uv*float2(2,-2)+float2(-1,1),depth,1));o.distance=abs(p.w)>1e-8?length(p.xyz/p.w-eyeMaxDistance.xyz):eyeMaxDistance.w;return o;}

