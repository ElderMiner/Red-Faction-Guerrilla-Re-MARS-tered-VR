#pragma once
#include "modern_hdr_ids.h"
namespace modernhdr {
// Private hybrid experiment: filmic curve parameter comparison informed by
// the user-provided Sildur pack. Native linear buffers require no Minecraft
// display-gamma decode/encode or Minecraft-specific buffers.
// Native ABI: scene t0, shared exposure t1, blurred bloom t5, particle t6.
// The scene is stored at 1/8 radiance in modes 0/2, full radiance in mode 1.
inline constexpr char source[]=R"HDR(
cbuffer Common:register(b0){float4 common[11];};
cbuffer Material:register(b2){float4 material[23];};
cbuffer Instance:register(b6){float4 tint;float4 alphaControl;};
cbuffer ModernExposure:register(b13){float4 modernControls;float4 modernReserved[8];float4 modernLayout;};
Texture2D<float4> scene:register(t0),adaptation:register(t1),bloom:register(t5),particles:register(t6);
SamplerState sceneSampler:register(s0),adaptSampler:register(s1),bloomSampler:register(s5),particleSampler:register(s6);
struct In{float4 position:SV_Position;float2 uv:TEXCOORD0;};
float3 saturation(float3 c,float amount){float y=dot(c,float3(.2126,.7152,.0722));return max(lerp(y.xxx,c,max(amount,0)),0);}
float3 shoulder(float3 x){float3 numerator=x*(.28*x+.029)+.005;float3 denominator=x*(.28*x+.29)+.07;return numerator/max(denominator,1e-6)-(.025/.35);}
float3 display(float3 radiance){return saturate(shoulder(max(radiance,0)*4.7)/shoulder(15.2));}
float4 main(In input):SV_Target{
 float4 base=scene.Sample(sceneSampler,input.uv),particle=particles.Sample(particleSampler,input.uv);
 float exposure=clamp(adaptation.SampleLevel(adaptSampler,float2(.5,.5),0).y,.02,4);
 // Native adaptation is shared by the eyes. No probe-derived exposure override.
 float3 halo=max(bloom.Sample(bloomSampler,input.uv).rgb,0)*clamp(material[18].y,0,.18);
 // Preserve bloom hue while preventing a bright source from washing the frame.
 halo/=1+max(halo.r,max(halo.g,halo.b))*2;
 float3 colour;
 #if MODE==1
 colour=display(max(base.rgb,0)*exposure+halo);
 colour=saturation(colour*saturate(particle.a)+max(particle.rgb,0),common[0].x)*tint.rgb;
 float alpha=base.a;
 #else
 float3 radiance=saturation(max(base.rgb,0)*8,common[0].x)*max(tint.rgb,0);
 // Native particles are encoded with the old exponential display curve.
 // Undo that encoding before the single new scene transform.
 float3 p=saturation(saturate(particle.rgb),common[0].y);
 float3 particleRadiance=-log(max(1-p,.0001));
 colour=display(radiance*exposure*saturate(particle.a)+particleRadiance+halo*8);
 #if MODE==2
 float alpha=saturate((base.a-particle.a+1)*1000);
 #else
 float alpha=dot(colour,float3(.299,.587,.114));
 #endif
 #endif
 return float4(saturate(colour),alpha);
}
)HDR";
using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11PixelShader**);
inline int identify(const void* p,size_t n){if(!p||n<32||memcmp(p,"DXBC",4))return -1;for(auto i:identities)if(n==i.bytes&&!memcmp((const char*)p+4,i.hash,16))return i.mode;return -1;}
inline HRESULT create(Create native,ID3D11Device* device,const void* original,SIZE_T size,ID3D11PixelShader** shader,int mode,bool& substituted){
 substituted=false;if(mode<0||mode>2)return native(device,original,size,nullptr,shader);
 static std::mutex mutex;static Microsoft::WRL::ComPtr<ID3DBlob> codes[3];std::lock_guard<std::mutex> lock(mutex);HRESULT hr=S_OK;
 if(!codes[mode]){const char* modes[]={"0","1","2"};D3D_SHADER_MACRO macros[]={{"MODE",modes[mode]},{nullptr,nullptr}};hr=D3DCompile(source,sizeof(source)-1,"RFGRVR filmic HDR",macros,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&codes[mode],nullptr);}
 if(SUCCEEDED(hr))hr=native(device,codes[mode]->GetBufferPointer(),codes[mode]->GetBufferSize(),nullptr,shader);
 if(SUCCEEDED(hr)){substituted=true;return hr;}return native(device,original,size,nullptr,shader);
}
}
