#pragma once
#include <d3d11shader.h>
#include "modern_material_bindings.h"
namespace moderncatalog {
inline bool enabled(){static bool value=[](){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,'\\');if(!slash)return false;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-modern-engine-capture.enable");return GetFileAttributesA(path)!=INVALID_FILE_ATTRIBUTES;}();return value;}
// One shader-creation catalogue, capped at 4096 objects / 512 unique interfaces. Contains interfaces and
// identities only; no native shader bytecode, textures or tracking recordings.
inline void record(ID3D11PixelShader* shader,const void* bytes,SIZE_T count,int replacement){
 modernmaterial::tag(shader,replacement);
 if(!enabled()||!shader||!bytes||count<32)return;static std::atomic<unsigned> records{0};if(records.fetch_add(1)>=4096)return;
 static std::mutex mutex;std::lock_guard<std::mutex> held(mutex);static unsigned char hashes[512][16]{};static unsigned uniqueCount=0;
 bool unique=true;for(unsigned i=0;i<uniqueCount;++i)if(!memcmp(hashes[i],(const char*)bytes+4,16)){unique=false;break;}
 if(unique&&uniqueCount<512)memcpy(hashes[uniqueCount++],(const char*)bytes+4,16);else unique=false;
 Microsoft::WRL::ComPtr<ID3D11ShaderReflection> reflection;D3D11_SHADER_DESC desc{};
 if(unique){if(FAILED(D3DReflect(bytes,count,__uuidof(ID3D11ShaderReflection),(void**)reflection.GetAddressOf())))return;if(FAILED(reflection->GetDesc(&desc)))return;}
 // Private opt-in reverse-engineering evidence for the remaster's generated
 // material shaders, which are absent from the legacy .fxo catalogue. Never
 // included in source/payload archives; bounded to64 shaders /1 MiB each.
 if(unique&&replacement<0&&count<=1024*1024){
  D3D11_SHADER_BUFFER_DESC material{};auto* surface=reflection->GetConstantBufferByName("g_materialFragmentConstantsbuffer");auto* terrain=reflection->GetConstantBufferByName("g_terrainMaterialFragmentConstantsbuffer");bool generated=(surface&&SUCCEEDED(surface->GetDesc(&material)))||(terrain&&SUCCEEDED(terrain->GetDesc(&material)));
  static unsigned captured=0;if(generated&&captured<64){++captured;char path[1024]{};GetModuleFileNameA(nullptr,path,sizeof(path));auto* slash=strrchr(path,'\\');if(slash){slash[1]=0;char suffix[160]{};char hash[33]{};for(unsigned k=0;k<16;++k)sprintf_s(hash+k*2,sizeof(hash)-k*2,"%02x",((const unsigned char*)bytes)[k+4]);sprintf_s(suffix,"vr-research\\output\\Modern-native-%lu-%s.cso",GetCurrentProcessId(),hash);strcat_s(path,suffix);FILE* output=nullptr;if(!fopen_s(&output,path,"wb")&&output){fwrite(bytes,1,count,output);fclose(output);}}}
 }
 char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,'\\');if(!slash)return;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-Modern-Shader-Catalog.log");FILE* file=nullptr;if(fopen_s(&file,path,"a")||!file)return;
 fprintf(file,"shader=%p replacement=%d bytes=%zu hash=",shader,replacement,count);for(unsigned i=4;i<20;++i)fprintf(file,"%02x",((const unsigned char*)bytes)[i]);fprintf(file," process=%lu unique=%u resources=%u buffers=%u instructions=%u\n",GetCurrentProcessId(),unique?1u:0u,desc.BoundResources,desc.ConstantBuffers,desc.InstructionCount);if(!unique){fclose(file);return;}
 for(unsigned i=0;i<desc.BoundResources;++i){D3D11_SHADER_INPUT_BIND_DESC b{};if(SUCCEEDED(reflection->GetResourceBindingDesc(i,&b)))fprintf(file," resource %s type=%u dimension=%u slot=%u count=%u\n",b.Name,unsigned(b.Type),unsigned(b.Dimension),b.BindPoint,b.BindCount);}
 for(unsigned i=0;i<desc.ConstantBuffers;++i){auto* cb=reflection->GetConstantBufferByIndex(i);D3D11_SHADER_BUFFER_DESC b{};if(FAILED(cb->GetDesc(&b)))continue;fprintf(file," buffer %s size=%u\n",b.Name,b.Size);for(unsigned j=0;j<b.Variables;++j){D3D11_SHADER_VARIABLE_DESC v{};if(SUCCEEDED(cb->GetVariableByIndex(j)->GetDesc(&v)))fprintf(file," field %s offset=%u size=%u\n",v.Name,v.StartOffset,v.Size);}}
 fclose(file);
}
}
