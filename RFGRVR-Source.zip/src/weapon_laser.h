#pragma once
#include <windows.h>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include "vr_arm_math.h"
namespace vrlaser {
using namespace vrarm;
inline constexpr float maxRange=37.5f;
struct State {V origin{},end{},normal{};float scale=1,distance=0;DWORD tick=0;bool active=false,hit=false;};
inline SRWLOCK lock=SRWLOCK_INIT;inline State state{};
inline void publish(const State& s){AcquireSRWLockExclusive(&lock);state=s;ReleaseSRWLockExclusive(&lock);}
inline State snapshot(){State s;AcquireSRWLockShared(&lock);s=state;ReleaseSRWLockShared(&lock);if(!s.tick||DWORD(GetTickCount()-s.tick)>150)s.active=false;return s;}
inline void reproject(State& s,const Pose& mounted){
 V direction=unit(mounted.b.f);if(s.hit){float denominator=dot(direction,s.normal);float distance=fabsf(denominator)>.02f?dot(sub(s.end,mounted.p),s.normal)/denominator:-1;
  if(distance>0&&distance<=maxRange*s.scale){s.end=add(mounted.p,mul(direction,distance));s.distance=distance;}else s.hit=false;
 }
 if(!s.hit){s.distance=maxRange*s.scale;s.end=add(mounted.p,mul(direction,s.distance));}s.origin=mounted.p;
}
// Native contact position (+0) differs from the swept-centre fraction (+24).
inline V surfaceContact(V from,V travel,float fraction,V contact){
 V center=add(from,mul(travel,fraction));float squared=dot(travel,travel);
 if(!finite(contact)||squared<.000001f)return center;
 float along=dot(sub(contact,from),travel)/squared;
 return along>0&&along<=1&&length(sub(contact,center))<=1.f?contact:center;
}
struct Stabilizer {
 State previous{};uintptr_t owner=0;DWORD lastHit=0;
 void apply(State& s,uintptr_t weapon){
  if(!s.active||owner!=weapon){previous={};lastHit=0;owner=weapon;}
  if(!s.active)return;
  if(s.hit){previous=s;lastHit=s.tick;return;}
  // Bridge only a very short query dropout with an almost unchanged ray.
  // Never prolong the original hit lifetime or carry it across a weapon swap.
  if(!lastHit||DWORD(s.tick-lastHit)>35||length(sub(s.origin,previous.origin))>.005f*s.scale||dot(unit(sub(s.end,s.origin)),unit(sub(previous.end,previous.origin)))<.9999f)return;
  State held=previous;Pose ray{M{{1,0,0},{0,1,0},unit(sub(s.end,s.origin))},s.origin};reproject(held,ray);if(!held.hit)return;held.tick=s.tick;s=held;
 }
};
inline float visibility(float distance,float scale){float t=(std::clamp)((maxRange-distance/scale)/(maxRange*.2f),0.f,1.f);return t*t*(3-2*t);}
struct Settings {float forward=0,vertical=-.018f,size=1,emission=2;};
// A reload/attachment refresh may rebuild native muzzle tags. The approved
// emitter remains a rigid child of this weapon instance, not that animation.
struct Mount {
 uintptr_t owner=0;unsigned serial=0;Pose localPose{};bool ready=false;
 bool resolve(uintptr_t weapon,unsigned handle,const Pose& candidate,Pose& out){
  if(owner!=weapon||serial!=handle){*this={};owner=weapon;serial=handle;}
  if(!ready){if(!weapon||!valid(candidate.b)||!finite(candidate.p)||length(candidate.p)>2)return false;localPose=candidate;ready=true;}
  out=localPose;return true;
 }
};
inline SRWLOCK settingsLock=SRWLOCK_INIT;inline Settings placement{};inline char path[MAX_PATH]{};inline bool loaded=false;
inline void load(){if(loaded)return;loaded=true;if(!path[0]){GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* s=strrchr(path,92))strcpy_s(s+1,MAX_PATH-(s+1-path),"RFGRVR-handgun-laser.ini");}char text[80]{};GetPrivateProfileStringA("Handgun","Position","",text,sizeof(text),path);Settings v;if(sscanf_s(text,"%f %f",&v.forward,&v.vertical)==2&&std::isfinite(v.forward+v.vertical)){placement.forward=(std::clamp)(v.forward,-.3f,.3f);placement.vertical=(std::clamp)(v.vertical,-.3f,.3f);}
 GetPrivateProfileStringA("Handgun","Appearance","",text,sizeof(text),path);if(sscanf_s(text,"%f %f",&v.size,&v.emission)==2&&std::isfinite(v.size+v.emission)){placement.size=(std::clamp)(v.size,.25f,4.f);placement.emission=(std::clamp)(v.emission,.1f,12.f);}}
inline Settings settings(){AcquireSRWLockExclusive(&settingsLock);load();auto s=placement;ReleaseSRWLockExclusive(&settingsLock);return s;}
inline Pose emitter(const Pose& muzzle,float scale,Settings s){return {muzzle.b,add(muzzle.p,world(muzzle.b,{0,s.vertical*scale,s.forward*scale}))};}
inline bool adjust(Settings& s,int key){switch(key){case VK_LEFT:s.forward-=.002f;break;case VK_RIGHT:s.forward+=.002f;break;case VK_UP:s.vertical+=.002f;break;case VK_DOWN:s.vertical-=.002f;break;case VK_MULTIPLY:s.size=(std::min)(4.f,s.size*1.1f);break;case VK_SUBTRACT:s.size=(std::max)(.25f,s.size/1.1f);break;case VK_NUMPAD8:s.emission=(std::min)(12.f,s.emission+.25f);break;case VK_NUMPAD9:s.emission=(std::max)(.1f,s.emission-.25f);break;default:return false;}s.forward=(std::clamp)(s.forward,-.3f,.3f);s.vertical=(std::clamp)(s.vertical,-.3f,.3f);return true;}
// Shipping placements are fixed; keyboard setup shortcuts cannot alter them.
inline void input(bool){}
// Slightly wider divergence, capped at a 37.5-mm radius.
inline float radius(float distance,float scale){return (std::clamp)(.003f+.000675f*distance/scale,.003f,.0375f)*scale;}
}
