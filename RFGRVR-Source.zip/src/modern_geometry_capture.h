#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <vector>
#include <cstdio>
#include <cstring>
// Private bounded diagnostic only. No geometry is interpreted or submitted.
namespace moderngeometrycapture {
using Microsoft::WRL::ComPtr;
inline const GUID layoutTag={0x7653fa21,0x619b,0x4c89,{0x81,0x74,0x99,0xc1,0x42,0xb6,0x5a,0x80}};
inline const GUID vertexTag={0x7653fa22,0x619b,0x4c89,{0x81,0x74,0x99,0xc1,0x42,0xb6,0x5a,0x80}};
struct Element {char semantic[32]{};unsigned index,format,slot,offset,classification,step;};
inline void tagLayout(ID3D11InputLayout* layout,const D3D11_INPUT_ELEMENT_DESC* desc,unsigned count){if(!layout||!desc||count>32)return;Element elements[32]{};for(unsigned i=0;i<count;++i){if(!desc[i].SemanticName)return;strncpy_s(elements[i].semantic,desc[i].SemanticName,31);elements[i].index=desc[i].SemanticIndex;elements[i].format=desc[i].Format;elements[i].slot=desc[i].InputSlot;elements[i].offset=desc[i].AlignedByteOffset;elements[i].classification=desc[i].InputSlotClass;elements[i].step=desc[i].InstanceDataStepRate;}layout->SetPrivateData(layoutTag,count*sizeof(Element),elements);}
inline void tagVertex(ID3D11VertexShader* shader,const void* bytes,size_t size){if(shader&&bytes&&size&&size<=256*1024)shader->SetPrivateData(vertexTag,UINT(size),bytes);}
struct Buffer {ComPtr<ID3D11Buffer> copy;unsigned bytes=0;};
struct Draw {unsigned sequence=0,count=0,start=0,base=0,instances=0,format=0,indexOffset=0,topology=0,stride[8]{},offset[8]{};uintptr_t shader=0;Buffer vertices[8],indices,constants[8];std::vector<unsigned char> layout,vertex;};
inline std::vector<Draw> draws;inline size_t bytes=0;inline unsigned rejected=0;
inline void reset(){draws.clear();bytes=0;rejected=0;}
inline Buffer copy(ID3D11DeviceContext* context,ID3D11Buffer* source){Buffer result;if(!source)return result;D3D11_BUFFER_DESC d{};source->GetDesc(&d);if(!d.ByteWidth||d.ByteWidth>4*1024*1024||bytes+d.ByteWidth>32*1024*1024){++rejected;return result;}ComPtr<ID3D11Device> device;context->GetDevice(&device);unsigned size=d.ByteWidth;d.BindFlags=d.MiscFlags=d.StructureByteStride=0;d.Usage=D3D11_USAGE_STAGING;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;if(FAILED(device->CreateBuffer(&d,nullptr,&result.copy))){++rejected;return result;}context->CopyResource(result.copy.Get(),source);result.bytes=size;bytes+=size;return result;}
inline std::vector<unsigned char> privateData(ID3D11DeviceChild* object,const GUID& tag,unsigned maximum){UINT size=0;std::vector<unsigned char> result;if(!object||FAILED(object->GetPrivateData(tag,&size,nullptr))||!size||size>maximum)return result;result.resize(size);if(FAILED(object->GetPrivateData(tag,&size,result.data())))result.clear();return result;}
inline void record(ID3D11DeviceContext* context,unsigned sequence,unsigned count,unsigned start,unsigned base,unsigned instances){
 if(!context||draws.size()>=16)return;ComPtr<ID3D11VertexShader> shader;context->VSGetShader(&shader,nullptr,nullptr);for(auto& old:draws)if(old.shader==(uintptr_t)shader.Get())return;ComPtr<ID3D11InputLayout> layout;context->IAGetInputLayout(&layout);auto elements=privateData(layout.Get(),layoutTag,32*sizeof(Element)),code=privateData(shader.Get(),vertexTag,256*1024);if(elements.empty()||code.empty())return;
 Draw d;d.sequence=sequence;d.count=count;d.start=start;d.base=base;d.instances=instances;d.shader=(uintptr_t)shader.Get();d.layout=std::move(elements);d.vertex=std::move(code);D3D11_PRIMITIVE_TOPOLOGY topology;context->IAGetPrimitiveTopology(&topology);d.topology=topology;ID3D11Buffer* buffers[8]{};context->IAGetVertexBuffers(0,8,buffers,d.stride,d.offset);for(unsigned i=0;i<8;++i)if(buffers[i]){d.vertices[i]=copy(context,buffers[i]);buffers[i]->Release();}
 ComPtr<ID3D11Buffer> indices;DXGI_FORMAT format;context->IAGetIndexBuffer(&indices,&format,&d.indexOffset);d.format=format;d.indices=copy(context,indices.Get());context->VSGetConstantBuffers(0,8,buffers);for(unsigned i=0;i<8;++i)if(buffers[i]){d.constants[i]=copy(context,buffers[i]);buffers[i]->Release();}draws.push_back(std::move(d));
}
inline bool finish(ID3D11DeviceContext* context,const char* prefix){bool ok=true;char path[MAX_PATH];sprintf_s(path,"%s-geometry.csv",prefix);FILE* f=nullptr;if(fopen_s(&f,path,"w")||!f)return false;fputs("draw,sequence,count,start,base,instances,index_format,index_offset,topology\n",f);
 auto raw=[&](unsigned draw,const char* kind,unsigned slot,const void* data,size_t size){sprintf_s(path,"%s-geometry-%u-%s-%u.bin",prefix,draw,kind,slot);FILE* out=nullptr;if(fopen_s(&out,path,"wb")||!out){ok=false;return;}if(fwrite(data,1,size,out)!=size)ok=false;fclose(out);};
 for(unsigned i=0;i<draws.size();++i){auto& d=draws[i];fprintf(f,"%u,%u,%u,%u,%u,%u,%u,%u,%u\n",i,d.sequence,d.count,d.start,d.base,d.instances,d.format,d.indexOffset,d.topology);raw(i,"layout",0,d.layout.data(),d.layout.size());raw(i,"vs",0,d.vertex.data(),d.vertex.size());raw(i,"stride",0,d.stride,sizeof(d.stride));raw(i,"offset",0,d.offset,sizeof(d.offset));auto buffer=[&](Buffer& b,const char* kind,unsigned slot){if(!b.copy)return;D3D11_MAPPED_SUBRESOURCE data{};if(FAILED(context->Map(b.copy.Get(),0,D3D11_MAP_READ,0,&data))){ok=false;return;}raw(i,kind,slot,data.pData,b.bytes);context->Unmap(b.copy.Get(),0);};buffer(d.indices,"indices",0);for(unsigned k=0;k<8;++k){buffer(d.vertices[k],"vertices",k);buffer(d.constants[k],"constants",k);}}
 fprintf(f,"# bytes=%zu rejected=%u success=%u\n",bytes,rejected,ok?1:0);fclose(f);reset();return ok;
}
}
