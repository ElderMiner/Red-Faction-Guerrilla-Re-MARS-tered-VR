#pragma once
#include <cstdint>
namespace vrpress {
enum Mode {Single,Double,Hold,Count};
constexpr uint64_t HoldMs=500,DoubleMs=300,PulseMs=90;
inline const char* names[Count]={"Single press","Double press","Hold"};
struct Button {
 bool down=false,blocked=false,second=false,held=false,waiting=false;
 uint64_t pressed=0,released=0,singleUntil=0,doubleUntil=0,holdUntil=0;
 void update(bool value,bool active,bool hasHold,bool hasDouble,uint64_t now,bool neutral){
  if(!active){*this={};blocked=!neutral;return;}
  if(blocked){if(neutral)blocked=false;value=false;}
  if(waiting&&now-released>DoubleMs){waiting=false;singleUntil=now+PulseMs;}
  if(value&&!down){second=waiting;waiting=false;pressed=now;held=false;holdUntil=0;}
  if((value||down)&&hasHold&&!held&&now-pressed>=HoldMs){held=true;waiting=false;if(!value)holdUntil=now+PulseMs;}
  if(!value&&down&&!held){
   if(second){doubleUntil=now+PulseMs;second=false;}
   else if(hasDouble){waiting=true;released=now;}
   else if(hasHold)singleUntil=now+PulseMs;
  }
  down=value;
 }
 bool value(Mode mode,bool hasHold,bool hasDouble,uint64_t now)const{
  if(blocked)return false;
  if(mode==Hold)return (down&&held)||now<holdUntil;
  if(mode==Double)return now<doubleUntil||(down&&second&&!hasHold);
  return (!hasHold&&!hasDouble)?down:now<singleUntil;
 }
};
}
