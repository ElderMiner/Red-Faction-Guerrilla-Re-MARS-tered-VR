#pragma once
#include "vr_projection_viewport.h"
#include "vr_arm_math.h"
#include "vr_menu_target_format.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <cstring>
// The main-menu UI is a world plane drawn through the application's eye
// projection, rather than relying exclusively on the runtime's quad layer.
struct RFGRMenuScene {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 struct Vertex{float clip[4],uv[2];};
 int stage=0;HRESULT error=S_OK;bool ready=false;Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> deferred;Ptr<ID3D11VertexShader> vs;Ptr<ID3D11PixelShader> ps;Ptr<ID3D11InputLayout> layout;Ptr<ID3D11Buffer> buffer;Ptr<ID3D11SamplerState> sampler;Ptr<ID3D11RasterizerState> raster;Ptr<ID3D11DepthStencilState> depth;Ptr<ID3D11BlendState> blend;Ptr<ID3D11Texture2D> source;Ptr<ID3D11ShaderResourceView> image;
 static bool vertices(const vrarm::Pose& eye,const float fov[4],const vrarm::Pose& panel,float width,float height,Vertex (&out)[6]){using namespace vrarm;
  if(!valid(eye.b)||!valid(panel.b)||!finite(eye.p)||!finite(panel.p)||width<=0||height<=0)return false;
  float l=tanf(fov[0]),r=tanf(fov[1]),u=tanf(fov[2]),d=tanf(fov[3]);if(!std::isfinite(l+r+u+d)||r-l<.01f||u-d<.01f)return false;
  unsigned front=0;const unsigned corners[6]={0,2,1,1,2,3};for(unsigned i=0;i<6;++i){unsigned n=corners[i];float x=(n&1)?1.f:0.f,y=(n&2)?1.f:0.f;V p=local(eye.b,sub(add(panel.p,world(panel.b,{(x-.5f)*width,(.5f-y)*height,0})),eye.p));float z=-p.z;if(z>.02f)++front;out[i]={{(2*p.x-(r+l)*z)/(r-l),(2*p.y-(u+d)*z)/(u-d),z*.5f,z},{x,y}};}return front!=0;
 }
 bool init(ID3D11Device* d){if(owner.Get()==d&&ready)return true;*this={};owner=d;
  const char code[]="Texture2D image:register(t0);SamplerState filter:register(s0);struct V{float4 p:POSITION;float2 uv:TEXCOORD0;};struct O{float4 p:SV_POSITION;float2 uv:TEXCOORD0;};O VS(V v){O o;o.p=v.p;o.uv=v.uv;return o;}float4 PS(O o):SV_TARGET{return image.Sample(filter,o.uv);}";
  Ptr<ID3DBlob> v,p;if(FAILED(D3DCompile(code,sizeof(code),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&v,nullptr))||FAILED(D3DCompile(code,sizeof(code),nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&p,nullptr)))return false;
  D3D11_INPUT_ELEMENT_DESC fields[]={{"POSITION",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,16,D3D11_INPUT_PER_VERTEX_DATA,0}};
  if(FAILED(d->CreateVertexShader(v->GetBufferPointer(),v->GetBufferSize(),nullptr,&vs))||FAILED(d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,&ps))||FAILED(d->CreateInputLayout(fields,2,v->GetBufferPointer(),v->GetBufferSize(),&layout))||FAILED(d->CreateDeferredContext(0,&deferred)))return false;
  D3D11_BUFFER_DESC b{};b.ByteWidth=sizeof(Vertex)*6;b.Usage=D3D11_USAGE_DYNAMIC;b.BindFlags=D3D11_BIND_VERTEX_BUFFER;b.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;if(FAILED(d->CreateBuffer(&b,nullptr,&buffer)))return false;
  D3D11_SAMPLER_DESC s{};s.Filter=D3D11_FILTER_ANISOTROPIC;s.MaxAnisotropy=16;s.AddressU=s.AddressV=s.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;s.MaxLOD=D3D11_FLOAT32_MAX;
  D3D11_RASTERIZER_DESC r{};r.FillMode=D3D11_FILL_SOLID;r.CullMode=D3D11_CULL_NONE;r.DepthClipEnable=TRUE;
  D3D11_DEPTH_STENCIL_DESC z{};z.DepthEnable=FALSE;
  D3D11_BLEND_DESC a{};auto& rt=a.RenderTarget[0];rt.BlendEnable=TRUE;rt.SrcBlend=rt.SrcBlendAlpha=D3D11_BLEND_ONE;rt.DestBlend=rt.DestBlendAlpha=D3D11_BLEND_INV_SRC_ALPHA;rt.BlendOp=rt.BlendOpAlpha=D3D11_BLEND_OP_ADD;rt.RenderTargetWriteMask=15;
  ready=SUCCEEDED(d->CreateSamplerState(&s,&sampler))&&SUCCEEDED(d->CreateRasterizerState(&r,&raster))&&SUCCEEDED(d->CreateDepthStencilState(&z,&depth))&&SUCCEEDED(d->CreateBlendState(&a,&blend));return ready;
 }
 bool draw(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* target,unsigned slice,ID3D11Texture2D* texture,const vrarm::Pose& eye,const float fov[4],const vrarm::Pose& panel,float width,float height,DXGI_FORMAT requested=DXGI_FORMAT_UNKNOWN){
  stage=1;error=E_INVALIDARG;Vertex v[6];if(!target||!texture||!vertices(eye,fov,panel,width,height,v))return false;if(!init(d)){stage=2;error=E_FAIL;return false;}
  stage=3;if(source.Get()!=texture||!image){image.Reset();source=texture;if(FAILED(error=d->CreateShaderResourceView(texture,nullptr,&image)))return false;}
  D3D11_TEXTURE2D_DESC td{};target->GetDesc(&td);if(slice>=td.ArraySize){error=E_INVALIDARG;return false;}
  D3D11_RENDER_TARGET_VIEW_DESC rd{};rd.Format=RFGRMenuTargetFormat(td.Format,requested);rd.ViewDimension=td.ArraySize>1?D3D11_RTV_DIMENSION_TEXTURE2DARRAY:D3D11_RTV_DIMENSION_TEXTURE2D;if(td.ArraySize>1){rd.Texture2DArray.ArraySize=1;rd.Texture2DArray.FirstArraySlice=slice;}
  stage=4;Ptr<ID3D11RenderTargetView> rt;if(FAILED(error=d->CreateRenderTargetView(target,&rd,&rt)))return false;
  stage=5;deferred->ClearState();D3D11_MAPPED_SUBRESOURCE m{};if(FAILED(error=deferred->Map(buffer.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&m)))return false;memcpy(m.pData,v,sizeof(v));deferred->Unmap(buffer.Get(),0);
  auto* output=rt.Get();deferred->OMSetRenderTargets(1,&output,nullptr);deferred->OMSetBlendState(blend.Get(),nullptr,~0u);deferred->OMSetDepthStencilState(depth.Get(),0);deferred->RSSetState(raster.Get());auto vp=vrprojection::viewport(td.Width,td.Height);deferred->RSSetViewports(1,&vp);auto* b=buffer.Get();UINT stride=sizeof(Vertex),offset=0;deferred->IASetVertexBuffers(0,1,&b,&stride,&offset);deferred->IASetInputLayout(layout.Get());deferred->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);deferred->VSSetShader(vs.Get(),nullptr,0);deferred->PSSetShader(ps.Get(),nullptr,0);auto* s=sampler.Get();auto* srv=image.Get();deferred->PSSetSamplers(0,1,&s);deferred->PSSetShaderResources(0,1,&srv);deferred->Draw(6,0);
  stage=6;Ptr<ID3D11CommandList> commands;if(FAILED(error=deferred->FinishCommandList(FALSE,&commands)))return false;c->ExecuteCommandList(commands.Get(),TRUE);stage=7;error=S_OK;return true;
 }
};
