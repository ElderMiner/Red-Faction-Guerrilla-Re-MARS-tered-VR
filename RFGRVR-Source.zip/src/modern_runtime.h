#pragma once
#include "modern_scene_lights.h"
#include "vr_night_lighting.h"
#include "modern_lighting.h"
#include "modern_lighting_graph.h"
#include "modern_shadow_maps.h"
#include "modern_camera_math.h"
#include "modern_volume_renderer.h"
#include "vr_memory_access.h"
#include "modern_aux_capture.h"
#include "apc_render_targets.h"
#include "modern_material_bindings.h"
#include <mutex>
#include <atomic>
namespace modernruntime {
inline void* pointer(const void* object,unsigned offset){uint32_t p=0;if(object&&vrmemory::check((const char*)object+offset,4))memcpy(&p,(const char*)object+offset,4);return (void*)(uintptr_t)p;}
// This wrapper chain is shared with the existing verified native UI emitter.
inline ID3D11DeviceContext* context(void* renderer){return (ID3D11DeviceContext*)pointer(pointer(pointer(renderer,0x440),0),0);}
struct State {
 std::mutex mutex;modernshadowmaps::Atlas atlas;modernvolume::Renderer volume;
 void* sceneRenderer=nullptr;void* renderer=nullptr;void* secondary=nullptr;uint64_t epoch=0;bool active=false,drawn=false,metered=false;
 float eye[3]{},matrices[3][16]{};unsigned matrixMask=0;
 float viewOrigin[3]{},expectedClip[16]{};bool expectedClipValid=false;
 uint64_t lightFrame=~uint64_t(0);modernscene::Selection pairLights{};int eyeIndex=-1;
 unsigned eyeDraws[2]{},emptyLights[2]{},eyeAttempts[2]{};
};
inline State state;inline std::atomic<unsigned> nonWorldPasses{0};inline std::atomic<unsigned> shadowCopies{0},draws{0},rejected{0};
// Meter only world HDR; commit exposure once per pair, never independently per eye.
inline uint64_t consumedCapture=0;
inline Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> meterInput;inline ID3D11Texture2D* meterTexture=nullptr;
inline moderngraph::Graph developmentGraph;inline bool meterPair=false;inline unsigned meterPairs=0,meterQueued=0,meterFailed=0;
inline bool materialFrame(void* renderer,void* scene,modernmaterial::Frame& frame){
 auto* camera=(char*)pointer(renderer,0x478);if(!vrmemory::check(camera,0x500)||!vrmemory::check((char*)scene+0x1f8,8)||!moderncamera::inverse((float*)(camera+0x4c0),frame.inverseClip))return false;
 memcpy(frame.eye,camera+0x74,12);frame.eye[3]=1;memcpy(frame.origin,camera+0x80,12);unsigned shape[2]{};memcpy(shape,(char*)scene+0x1f8,8);frame.viewport[0]=float(shape[0]);frame.viewport[1]=float(shape[1]);frame.reflection[3]=developmentGraph.exposureReady()?developmentGraph.sceneExposure():0;frame.layout[3]=developmentGraph.exposureBlend();modernlocal::V origin;float spacing;unsigned side;if(developmentGraph.materialGrid(origin,spacing,side)){frame.grid[0]=origin.x;frame.grid[1]=origin.y;frame.grid[2]=origin.z;frame.grid[3]=spacing;frame.layout[0]=float(side);frame.layout[1]=developmentGraph.materialProbes()?1.f:0.f;}modernlocal::V captureOrigin;if(developmentGraph.reflectionPosition(captureOrigin)){frame.reflectionCenter[0]=captureOrigin.x;frame.reflectionCenter[1]=captureOrigin.y;frame.reflectionCenter[2]=captureOrigin.z;frame.reflectionCenter[3]=1;frame.reflectionBounds[0]=frame.reflectionBounds[1]=frame.reflectionBounds[2]=12;}return shape[0]&&shape[1];
}
inline void beginPair(void* renderer,void* scene,uint64_t pair,float hour,bool diagnostics){
 meterPair=false;if(!diagnostics)return;auto* c=context(renderer);if(!c||c->GetType()!=D3D11_DEVICE_CONTEXT_IMMEDIATE)return;
 developmentGraph.poll();modernaux::producer.poll(c);Microsoft::WRL::ComPtr<ID3D11Device> device;c->GetDevice(&device);
 static LARGE_INTEGER previous{},frequency{};LARGE_INTEGER now{};if(!frequency.QuadPart)QueryPerformanceFrequency(&frequency);QueryPerformanceCounter(&now);float seconds=previous.QuadPart&&frequency.QuadPart?float(double(now.QuadPart-previous.QuadPart)/frequency.QuadPart):0;previous=now;seconds=(std::clamp)(seconds,0.f,.1f);
 bool frameReady=developmentGraph.begin(device.Get(),c,(uint64_t)(uintptr_t)scene,pair,0,modernpolicy::Quality::Default,hour,seconds*2);meterPair=frameReady&&(pair%2==0);if(meterPair)++meterPairs;

 // Update the world-space atmosphere at a bounded cadence. The authoritative
 // scene source is seeded before this call; camera rotation is never an input.
 static uint64_t skyScene=0,lastSky=0;
 if(frameReady&&(skyScene!=(uint64_t)(uintptr_t)scene||pair-lastSky>=120||!developmentGraph.skyResource())){
  auto sources=modernscene::collector.snapshot();modernsky::Frame sky;sky.colour[1][3]=.8f;sky.direction[0][3]=sky.direction[1][3]=0;
  unsigned slot=0;for(unsigned i=0;i<sources.count&&slot<2;++i)if(sources.lights[i].kind==0){const auto& light=sources.lights[i];float energy=(std::max)({light.colour[0],light.colour[1],light.colour[2]});if(energy<=0)continue;for(unsigned k=0;k<3;++k){sky.direction[slot][k]=light.direction[k];sky.colour[slot][k]=light.colour[k]/energy;}sky.direction[slot][3]=energy*8;++slot;}
  if(slot&&developmentGraph.sky(sky)){skyScene=(uint64_t)(uintptr_t)scene;lastSky=pair;}
 }
 if(frameReady&&modernaux::producer.completed()>consumedCapture){auto id=modernaux::producer.completed();auto origin=modernaux::producer.position();unsigned x=0,y=0,z=0;
  if(!developmentGraph.probeCoordinate(origin,x,y,z)){consumedCapture=id;}
  else {auto* camera=(char*)pointer(renderer,0x478);modernlocal::V eye=origin;if(vrmemory::check(camera,0x8c)){float position[3],offset[3];memcpy(position,camera+0x74,12);memcpy(offset,camera+0x80,12);eye={position[0]+offset[0],position[1]+offset[1],position[2]+offset[2]};}bool reflected=!developmentGraph.needsReflection(origin,eye)||developmentGraph.reflectionCapture(id,0,modernaux::producer.result(),id);bool projected=developmentGraph.probeCapture(x,y,z,modernaux::producer.result(),id);if(reflected&&projected)consumedCapture=id;}
 }
}
inline void meterScene(ID3D11DeviceContext* c,ID3D11Texture2D* texture){
 if(!meterPair||state.metered||state.eyeIndex<0||state.eyeIndex>1)return;D3D11_TEXTURE2D_DESC d{};texture->GetDesc(&d);if(d.Format!=DXGI_FORMAT_R11G11B10_FLOAT||!(d.BindFlags&D3D11_BIND_SHADER_RESOURCE)){++meterFailed;return;}
 Microsoft::WRL::ComPtr<ID3D11Device> device;texture->GetDevice(&device);
 // One owned view of the current non-swapchain HDR texture, replaced when
 // the engine changes it. Avoid creating two COM resources every meter pair.
 if(meterTexture!=texture||!meterInput){Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> next;if(FAILED(device->CreateShaderResourceView(texture,nullptr,&next))){++meterFailed;return;}meterInput=next;meterTexture=texture;}
 // Main final-HDR shader c73a... uses scene radiance stored at 1/8. This
 // limited sampler observes that path only; it does not meter UI/aux views.
 if(developmentGraph.meterEye(unsigned(state.eyeIndex),meterInput.Get(),8,true,c)){++meterQueued;state.metered=true;}else ++meterFailed;
}
inline void evidence(){
 char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,'\\');if(!slash)return;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"vr-research\\output\\modern-transport-status.json");FILE* file=nullptr;
 if(!fopen_s(&file,path,"w")&&file){fprintf(file,"{\"process\":%lu,\"eyeEpoch\":%llu,\"shadowCopies\":%u,\"draws\":%u,\"rejected\":%u,\"cascadeMask\":%u,\"nonWorldPasses\":%u,\"materialMaps\":%u,\"materialCacheBytes\":%zu}\n",GetCurrentProcessId(),(unsigned long long)state.epoch,shadowCopies.load(),draws.load(),rejected.load(),state.matrixMask,nonWorldPasses.load(),modernheight::materialAttached.load(),modernheight::resident.load());
 fclose(file);
 char meterPath[MAX_PATH]{};strcpy_s(meterPath,path);if(auto* name=strrchr(meterPath,'\\')){strcpy_s(name+1,MAX_PATH-(name+1-meterPath),"modern-native-meter-status.json");FILE* output=nullptr;if(!fopen_s(&output,meterPath,"w")&&output){auto status=developmentGraph.status();fprintf(output,"{\"pairs\":%u,\"queued\":%u,\"failed\":%u,\"completed\":%u,\"pending\":%u,\"diagnosticExposure\":%.6f}\n",meterPairs,meterQueued,meterFailed,status.meters,status.pending,developmentGraph.sceneExposure());fclose(output);}}

 char capturePath[MAX_PATH]{};strcpy_s(capturePath,path);if(auto* name=strrchr(capturePath,92)){strcpy_s(name+1,MAX_PATH-(name+1-capturePath),"modern-native-world-capture.json");FILE* output=nullptr;if(!fopen_s(&output,capturePath,"w")&&output){auto graph=developmentGraph.status();auto energy=developmentGraph.indirect({state.eye[0]+state.viewOrigin[0],state.eye[1]+state.viewOrigin[1],state.eye[2]+state.viewOrigin[2]},{0,1,0});fprintf(output,"{\"captured\":%u,\"rejected\":%u,\"face\":%u,\"gpuComplete\":%llu,\"stage\":%u,\"validation\":%u,\"width\":%u,\"height\":%u,\"reflections\":%s,\"probes\":%u,\"irradiance\":[%.6f,%.6f,%.6f],\"confidence\":%.6f}\n",modernaux::captured,modernaux::failed,modernaux::producer.currentFace(),(unsigned long long)modernaux::producer.completed(),modernaux::lastStage,modernaux::producer.result().lastFailure(),modernaux::lastWidth,modernaux::lastHeight,graph.reflection?"true":"false",graph.probes,energy.irradiance.x,energy.irradiance.y,energy.irradiance.z,energy.confidence);fclose(output);}}
 char eyePath[MAX_PATH]{};strcpy_s(eyePath,path);auto* name=strrchr(eyePath,'\\');if(name){strcpy_s(name+1,MAX_PATH-(name+1-eyePath),"modern-stereo-lighting-status.json");FILE* eyes=nullptr;if(!fopen_s(&eyes,eyePath,"w")&&eyes){fprintf(eyes,"{\"process\":%lu,\"leftAttempts\":%u,\"rightAttempts\":%u,\"leftDraws\":%u,\"rightDraws\":%u,\"leftEmptyLights\":%u,\"rightEmptyLights\":%u}\n",GetCurrentProcessId(),state.eyeAttempts[0],state.eyeAttempts[1],state.eyeDraws[0],state.eyeDraws[1],state.emptyLights[0],state.emptyLights[1]);fclose(eyes);}}
}
}
inline void begin(void* sceneRenderer,void* renderer,const float* eye,void* secondary=nullptr,int eyeIndex=-1){
 std::lock_guard<std::mutex> lock(state.mutex);state.active=sceneRenderer&&renderer&&eye;state.sceneRenderer=sceneRenderer;state.renderer=renderer;state.secondary=secondary;state.drawn=state.metered=false;state.matrixMask=0;state.eyeIndex=eyeIndex;
 ++state.epoch;state.atlas.begin(state.epoch);if(eye)memcpy(state.eye,eye,12);
 auto* camera=(char*)pointer(renderer,0x478);state.expectedClipValid=false;if(vrmemory::check(camera,0x500)){float inverse[16];memcpy(state.viewOrigin,camera+0x80,12);memcpy(state.expectedClip,camera+0x4c0,64);state.expectedClipValid=moderncamera::inverse(state.expectedClip,inverse);}
}
inline void end(){std::lock_guard<std::mutex> lock(state.mutex);state.active=false;state.sceneRenderer=state.renderer=state.secondary=nullptr;}
inline void cascade(void* sceneRenderer,void* renderer,const float* matrix,unsigned index){
 std::lock_guard<std::mutex> lock(state.mutex);
 if(!state.active||sceneRenderer!=state.sceneRenderer||renderer!=state.renderer||index>=3||!vrmemory::check(matrix,64))return;
 float converted[16];if(!modernshadowmaps::matrix(matrix,converted))return;
 auto* c=context(renderer);void* rt=pointer(sceneRenderer,0x384);auto* depth=(ID3D11DepthStencilView*)pointer(rt,0x20);if(!c||!depth)return;
 Microsoft::WRL::ComPtr<ID3D11Resource> resource;depth->GetResource(&resource);Microsoft::WRL::ComPtr<ID3D11Texture2D> texture;if(FAILED(resource.As(&texture)))return;
 if(index==0)state.matrixMask=0;
 if(state.atlas.copy(c,texture.Get(),index,state.epoch)){memcpy(state.matrices[index],converted,64);state.matrixMask|=1u<<index;++shadowCopies;}
}
inline bool beforeHDR(void* renderer,bool verifiedMedium){
 if(modernaux::active){
  modernaux::lastStage=1;
  if(renderer!=modernaux::nativeRenderer&&renderer!=modernaux::nativeSecondary)return false;
  auto* c=context(renderer);auto* camera=(char*)pointer(renderer,0x478);
  auto* target=(ID3D11RenderTargetView*)pointer(pointer(modernaux::nativeScene,0x220),0);
  auto* depth=(ID3D11ShaderResourceView*)pointer(pointer(modernaux::nativeScene,0x2a8),24);
  if(!c||!target||!depth||!vrmemory::check(camera,0x500))return false;
  modernaux::lastStage=2;
  target=RFGRAPCTargets::view(target);depth=RFGRAPCTargets::view(depth);if(!target||!depth)return false;
  Microsoft::WRL::ComPtr<ID3D11Resource> resource;Microsoft::WRL::ComPtr<ID3D11Texture2D> texture;target->GetResource(&resource);
  if(FAILED(resource.As(&texture)))return false;Microsoft::WRL::ComPtr<ID3D11Device> device;c->GetDevice(&device);
  D3D11_TEXTURE2D_DESC captureShape{};texture->GetDesc(&captureShape);modernaux::lastWidth=captureShape.Width;modernaux::lastHeight=captureShape.Height;modernaux::lastStage=3;
  Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> hdr;if(FAILED(device->CreateShaderResourceView(texture.Get(),nullptr,&hdr)))return false;
  modernaux::lastStage=4;
  // Inputs have already been resolved. Our owned capture targets must never
  // be mistaken for native auxiliary targets by the size-redirection hooks.
  struct Redirect {bool old=RFGRAPCTargets::active.exchange(false);~Redirect(){RFGRAPCTargets::active=old;}} redirect;
  float absoluteEye[3];for(unsigned k=0;k<3;++k){float relative=0,origin=0;memcpy(&relative,camera+0x74+k*4,4);memcpy(&origin,camera+0x80+k*4,4);absoluteEye[k]=relative+origin;}
  if(modernaux::producer.capture(c,hdr.Get(),depth,(float*)(camera+0x4c0),absoluteEye,(float*)(camera+0x80))){++modernaux::captured;modernaux::lastStage=5;}else ++modernaux::failed;
  return false;
 }
 std::lock_guard<std::mutex> lock(state.mutex);if(!state.active||state.drawn||(renderer!=state.renderer&&renderer!=state.secondary))return false;
 auto* c=context(renderer);if(!c){++rejected;return false;}
 // Explicit native scene/depth resources: never guess from the last bound UI RT.
 auto* target=(ID3D11RenderTargetView*)pointer(pointer(state.sceneRenderer,0x220),0);
 auto* scene=(ID3D11ShaderResourceView*)pointer(pointer(state.sceneRenderer,0x2a8),24);
 auto* camera=(char*)pointer(renderer,0x478);
 if(!target||!scene||!vrmemory::check(camera,0x500)){++rejected;return false;}
 float eye[3];memcpy(eye,camera+0x74,12);for(unsigned i=0;i<3;++i)if(!std::isfinite(eye[i])||std::abs(eye[i]-state.eye[i])>.05f){++rejected;return false;}
 // Native shadow/auxiliary work can reuse the eye position with an entirely
 // different (orthographic) projection. A matching eye alone is insufficient.
 if(!state.expectedClipValid)return false;
 for(unsigned i=0;i<16;++i){float current;memcpy(&current,camera+0x4c0+i*4,4);float expected=state.expectedClip[i];if(!std::isfinite(current)||std::abs(current-expected)>.0002f*(std::max)({1.f,std::abs(current),std::abs(expected)})){++nonWorldPasses;return false;}}
 modernvolume::Frame frame;if(!moderncamera::inverse(state.expectedClip,frame.inverseViewProjection)){++rejected;return false;}
 for(unsigned r=0;r<4;++r)for(unsigned col=0;col<4;++col)memcpy(&frame.worldViewProjection[r*4+col],camera+0x4c0+(col*4+r)*4,4);frame.options[3]=1;
 // World-height medium: turning, crouching or riding a vehicle cannot drag it.
 memcpy(frame.eyeMaxDistance,eye,12);frame.eyeMaxDistance[3]=100;frame.medium[0]=.004f;frame.medium[1]=0;frame.medium[2]=.003f;frame.medium[3]=.8f;frame.options[1]=24;frame.options[2]=.45f;
 float renderOrigin[3]{};memcpy(renderOrigin,camera+0x80,12);for(float x:renderOrigin)if(!std::isfinite(x))return false;frame.medium[1]=-renderOrigin[1];
 auto collected=modernscene::collector.snapshot();
 // Freeze source selection/radiance for the stereo pair. Eye-specific camera
 // and shadow matrices stay independent, but light ordering cannot flip at
 // a nearest-light boundary or after a second-eye constant upload.
 if(state.lightFrame!=collected.frame){float absoluteEye[3];for(unsigned k=0;k<3;++k)absoluteEye[k]=eye[k]+renderOrigin[k];state.pairLights=modernscene::selectForView(collected,absoluteEye,frame.worldViewProjection,renderOrigin);state.lightFrame=collected.frame;}
 const auto& lights=state.pairLights;if(state.eyeIndex>=0&&state.eyeIndex<2)++state.eyeAttempts[state.eyeIndex];auto* shadows=state.matrixMask==7?state.atlas.complete(state.epoch):nullptr;
 for(unsigned i=0;i<lights.count&&frame.options[0]<8;++i){const auto& input=lights.lights[i];if(input.kind==0&&!shadows)continue;auto& out=frame.lights[unsigned(frame.options[0])];memcpy(out.positionKind,input.position,12);out.positionKind[3]=float(input.kind);memcpy(out.directionRange,input.direction,12);out.directionRange[3]=input.range;memcpy(out.colourInner,input.colour,12);out.colourInner[3]=input.innerCos;out.coneShadow[0]=input.outerCos;out.coneShadow[2]=-1;
  if(input.kind==0){out.directionRange[3]=3;out.coneShadow[2]=0;memcpy(out.worldToShadow,state.matrices[0],64);memcpy(out.worldToShadow1,state.matrices[1],64);memcpy(out.worldToShadow2,state.matrices[2],64);}
  else {for(unsigned k=0;k<3;++k){out.colourInner[k]*=8;out.positionKind[k]-=renderOrigin[k];}out.directionRange[3]=(std::min)(input.range,50.f);}
  ++frame.options[0];
 }
 Microsoft::WRL::ComPtr<ID3D11Device> device;c->GetDevice(&device);Microsoft::WRL::ComPtr<ID3D11Resource> targetResource;target->GetResource(&targetResource);Microsoft::WRL::ComPtr<ID3D11Texture2D> texture;if(FAILED(targetResource.As(&texture)))return false;D3D11_TEXTURE2D_DESC d{};texture->GetDesc(&d);
 Microsoft::WRL::ComPtr<ID3D11Resource> depthResource;scene->GetResource(&depthResource);Microsoft::WRL::ComPtr<ID3D11Texture2D> depthTexture;if(FAILED(depthResource.As(&depthTexture)))return false;D3D11_TEXTURE2D_DESC z{};depthTexture->GetDesc(&z);D3D11_SHADER_RESOURCE_VIEW_DESC sv{};scene->GetDesc(&sv);
 if(z.Width!=d.Width||z.Height!=d.Height||z.SampleDesc.Count!=1||sv.ViewDimension!=D3D11_SRV_DIMENSION_TEXTURE2D||(sv.Format!=DXGI_FORMAT_R32_FLOAT&&sv.Format!=DXGI_FORMAT_R16_UNORM&&sv.Format!=DXGI_FORMAT_R24_UNORM_X8_TYPELESS&&sv.Format!=DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS)){++rejected;return false;}
 meterScene(c,texture.Get());
 // No authored medium has been verified in the native scene yet. Do not
 // impose global fog while collecting material/geometry integration data.
  if(!verifiedMedium){
  // Only the night-weighted hybrid path requests this restrained haze. Native
  // baseline, day and unknown clocks remain exact no-op paths.
  float night=vrnight::current?(1-vrnight::current->exposure)/.82f:0;
  if(!modernlight::enabled()||night<=0){state.drawn=true;return false;}
  frame.eyeMaxDistance[3]=150;frame.medium[0]=.0015f*(std::clamp)(night,0.f,1.f);frame.medium[2]=0;frame.options[0]=0;frame.options[3]=2;
  frame.lights[0].colourInner[0]=.01f*.125f;frame.lights[0].colourInner[1]=.018f*.125f;frame.lights[0].colourInner[2]=.035f*.125f;
  if(state.volume.draw(device.Get(),c,target,scene,nullptr,d.Width,d.Height,frame)){state.drawn=true;++draws;if(state.eyeIndex>=0&&state.eyeIndex<2)++state.eyeDraws[state.eyeIndex];return true;}++rejected;return false;
 }
 // Extinction belongs to the medium, not the selected light count.
 // Missing/unready shadowed sources must not switch the entire atmosphere
 // off for one eye/frame and brighten its sky. Do not invent unshadowed light.
 if(frame.options[0]<1&&state.eyeIndex>=0&&state.eyeIndex<2)++state.emptyLights[state.eyeIndex];
 if(state.volume.draw(device.Get(),c,target,scene,shadows,d.Width,d.Height,frame)){state.drawn=true;++draws;if(state.eyeIndex>=0&&state.eyeIndex<2)++state.eyeDraws[state.eyeIndex];return true;}++rejected;return false;
}
inline bool beforeHDR(void* renderer){return beforeHDR(renderer,false);}
}






