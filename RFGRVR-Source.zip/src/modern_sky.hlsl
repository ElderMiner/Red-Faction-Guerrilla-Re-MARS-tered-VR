// World-space single-scattering atmosphere, cached as linear HDR lat-long
// radiance. Kilometres keep ray/sphere math well-conditioned. No eye/head
// orientation, auto-exposure, bloom or display transform enters this lookup.
RWTexture2D<float4> sky:register(u0);
cbuffer Atmosphere:register(b0){float4 sourceDirection[2];float4 sourceColour[2];};
float2 sphere(float3 origin,float3 direction,float radius){float b=dot(origin,direction),c=dot(origin,origin)-radius*radius,d=b*b-c;if(d<0)return float2(-1,-1);float root=sqrt(d);return float2(-b-root,-b+root);}
float2 density(float3 position){float height=max(length(position)-6360,0);return exp(-height/float2(8,1.2));}
float3 scattering(float3 origin,float3 ray,float3 lightDirection,float3 colour){
 float2 top=sphere(origin,ray,6420);float far=max(top.y,0);float2 ground=sphere(origin,ray,6360);if(ground.x>0)far=min(far,ground.x);if(far<=0)return 0;
 float stepSize=far/20;float2 viewOptical=0;float3 result=0;float cosine=dot(ray,lightDirection);float rayleigh=3*(1+cosine*cosine)/50.26548246,g=.76;float mie=(1-g*g)/(12.56637061*pow(max(1+g*g-2*g*cosine,.001),1.5));float dust=saturate(sourceColour[1].w);float3 betaR=lerp(float3(.0058,.0135,.0331),float3(.018,.014,.010),dust),betaM=lerp(.021,.012,dust);
 [loop]for(uint stepIndex=0;stepIndex<20;++stepIndex){float3 position=origin+ray*((stepIndex+.5)*stepSize);float2 viewSegment=density(position)*stepSize;viewOptical+=viewSegment*.5;float2 hit=sphere(position,lightDirection,6360);if(hit.x<=0){float sunDistance=max(sphere(position,lightDirection,6420).y,0);float2 sunOptical=0;float sunStep=sunDistance/8;[unroll]for(uint n=0;n<8;++n)sunOptical+=density(position+lightDirection*((n+.5)*sunStep))*sunStep;float2 optical=viewOptical+sunOptical;float3 attenuation=exp(-betaR*optical.x-betaM*1.1*optical.y);result+=attenuation*(viewSegment.x*betaR*rayleigh+viewSegment.y*betaM*mie);}viewOptical+=viewSegment*.5;}
 return max(result*colour,0);
}
[numthreads(8,8,1)]void main(uint3 id:SV_DispatchThreadID){uint width,height;sky.GetDimensions(width,height);if(id.x>=width||id.y>=height)return;float2 uv=(id.xy+.5)/float2(width,height);float azimuth=(uv.x*2-1)*3.14159265359,theta=uv.y*3.14159265359;float3 ray=float3(sin(theta)*cos(azimuth),cos(theta),sin(theta)*sin(azimuth));float3 origin=float3(0,6360+max(sourceColour[0].w,.002),0),radiance=0;
 [unroll]for(uint i=0;i<2;++i)if(sourceDirection[i].w>0)radiance+=scattering(origin,ray,normalize(sourceDirection[i].xyz),max(sourceColour[i].rgb,0)*sourceDirection[i].w);
 sky[id.xy]=float4(clamp(radiance,0,65504),1);
}

