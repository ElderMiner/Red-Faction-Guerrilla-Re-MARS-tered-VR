#pragma once
namespace modernskymaterial {inline constexpr char source[]=
R"SKYMATERIAL(// Shared optical response for verified material interfaces. All radiance is HDR.
float3 modernFresnel(float3 f0,float cosine){return saturate(f0)+(1-saturate(f0))*pow(1-saturate(cosine),5);}
float modernDielectric(float cosine,float etaI,float etaT){
 float c=saturate(abs(cosine)),eta=etaI/max(etaT,.001),k=1-eta*eta*(1-c*c);if(k<=0)return 1;
 float t=sqrt(k),s=(etaI*c-etaT*t)/max(etaI*c+etaT*t,1e-7),p=(etaT*c-etaI*t)/max(etaT*c+etaI*t,1e-7);return saturate((s*s+p*p)*.5);
}
float3 modernBeer(float3 absorption,float distance){return exp(-max(absorption,0)*max(distance,0));}
float modernLightRange(float distance,float range){float q=saturate(distance/max(range,.001)),window=1-q*q*q*q;return window*window/max(distance*distance,1);}
float modernNativeLightRange(float distance,float offset,float scale){return scale>1e-7&&offset>0?modernLightRange(distance,offset/scale):saturate(offset-distance*scale);}
// Preserve authored normal-incidence opacity, increasing optical path at grazing.
float modernGlassOpacity(float opacity,float cosine,float ior){
 if(opacity>=1)return 1;float eta=1/max(ior,1.001),ct=sqrt(max(1-eta*eta*(1-saturate(cosine*cosine)),.0001));
 float base=pow(max(1-saturate(opacity),1e-6),1/ct);float f=modernDielectric(cosine,1,ior),normal=modernDielectric(1,1,ior);
 return saturate(1-base*(1-f)/max(1-normal,.001));
}

Texture2D<float2> modernMaterial0:register(t25),modernMaterial1:register(t26),modernMaterial2:register(t27),modernMaterial3:register(t28);
float3 modernMaterialMap(float2 uv,int layer,SamplerState state){
 uint w,h;float2 value;
 if(layer==0){modernMaterial0.GetDimensions(w,h);if(!w)return 0;value=modernMaterial0.Sample(state,uv);}
 else if(layer==1){modernMaterial1.GetDimensions(w,h);if(!w)return 0;value=modernMaterial1.Sample(state,uv);}
 else if(layer==2){modernMaterial2.GetDimensions(w,h);if(!w)return 0;value=modernMaterial2.Sample(state,uv);}
 else {modernMaterial3.GetDimensions(w,h);if(!w)return 0;value=modernMaterial3.Sample(state,uv);}
 return float3(value,1);
}
void modernApplyMaterialMap(float3 estimate,inout float roughness,inout float reflectivity){
 if(estimate.z<=0)return;float2 value=estimate.xy/max(estimate.z,1e-5);float confidence=saturate(estimate.z);
 // Authored material response bounds the texture-derived approximation.
 roughness=lerp(roughness,max(roughness*.65,value.y),confidence*.5);
 reflectivity=lerp(reflectivity,max(reflectivity*.5,value.x*.35),confidence);
}

// Shared by replacement materials. Camera math stays renderer-relative;
// probe locations are absolute world positions. No headset-space lighting.
cbuffer ModernWorld:register(b13){float4 reflectionControl;row_major float4x4 modernInverseClip;float4 modernEye;float4 modernViewport;float4 modernOrigin;float4 modernGrid;float4 modernGridLayout;float4 modernReflectionCenter;float4 modernReflectionBounds;};
TextureCube<float4> modernEnvironment:register(t16);
Texture2D<float2> modernBRDF:register(t17);
Texture2D<float4> modernProbes:register(t18);
float3 modernUnit(float3 v){return v*rsqrt(max(dot(v,v),1e-12));}
float4 modernIrradiance(float3 world,float3 normal){
 float size=modernGridLayout.x;float3 q=(world-modernGrid.xyz)/max(modernGrid.w,.25);
 if(modernGridLayout.y<.5||size<2||any(q<0)||any(q>size-1))return 0;
 int3 cell=min(int3(floor(q)),int(size)-2);float3 f=q-float3(cell);normal=modernUnit(normal);
 float basis[9]={.2820947918,.4886025119*normal.y,.4886025119*normal.z,.4886025119*normal.x,1.0925484306*normal.x*normal.y,1.0925484306*normal.y*normal.z,.3153915653*(3*normal.z*normal.z-1),1.0925484306*normal.x*normal.z,.5462742153*(normal.x*normal.x-normal.y*normal.y)};
 float3 sum=0;float total=0;
 [unroll]for(int z=0;z<2;++z)[unroll]for(int y=0;y<2;++y)[unroll]for(int x=0;x<2;++x){
  int3 node=cell+int3(x,y,z);int row=(node.z*int(size)+node.y)*int(size)+node.x;
  if(modernProbes.Load(int3(15,row,0)).x<.5)continue;
  float weight=(x?f.x:1-f.x)*(y?f.y:1-f.y)*(z?f.z:1-f.z);float3 delta=world-(modernGrid.xyz+float3(node)*modernGrid.w);float distance=length(delta);float3 axis=abs(delta);int face=axis.x>=axis.y&&axis.x>=axis.z?(delta.x>=0?0:1):axis.y>=axis.z?(delta.y>=0?2:3):(delta.z>=0?4:5);
  float2 moment=modernProbes.Load(int3(9+face,row,0)).xy;
  if(distance>moment.x+.05){float variance=max(moment.y-moment.x*moment.x,0);float difference=distance-moment.x;float p=variance/max(variance+difference*difference,1e-10);weight*=p*p*p;}
  float3 light=0;[unroll]for(int k=0;k<9;++k)light+=modernProbes.Load(int3(k,row,0)).rgb*basis[k];sum+=max(light,0)*weight;total+=weight;
 }
 return total>1e-6?float4(sum/total,saturate(total)):0;
}
float3 modernAmbient(float4 pixel,float2 uv,float3 tangentNormal,float4 normalHint,float3 nativeAmbient,float3 diffuseFactor){
 [branch]if(modernEye.w<.5||modernGridLayout.y<.5)return nativeAmbient;
 float4 locationH=mul(modernInverseClip,float4(pixel.xy/modernViewport.xy*float2(2,-2)+float2(-1,1),pixel.z,1));if(abs(locationH.w)<1e-8)return nativeAmbient;
 float3 relative=locationH.xyz/locationH.w;float3 dx=ddx(relative),dy=ddy(relative);float3 N=modernUnit(cross(dx,dy));if(dot(N,modernEye.xyz-relative)<0)N=-N;
 float2 tx=ddx(uv),ty=ddy(uv);float3 a=cross(dy,N),b=cross(N,dx);float3 T=a*tx.x+b*ty.x,B=a*tx.y+b*ty.y;float scale=rsqrt(max(max(dot(T,T),dot(B,B)),1e-12));
 float3 worldNormal=normalHint.w>.5?modernUnit(normalHint.xyz):modernUnit((T*tangentNormal.x+B*tangentNormal.y)*scale+N*tangentNormal.z);
 float4 probe=modernIrradiance(relative+modernOrigin.xyz,worldNormal);
 // Captures contain true HDR radiance; native material targets store 1/8.
 float3 bounce=max(diffuseFactor,0)*probe.rgb*(.125/3.14159265359);
 return lerp(nativeAmbient,bounce,probe.a);
}
// Finite local box projection is an approximation, not a scene ray query.
float3 modernReflectionDirection(float4 pixel,float3 direction){
 [branch]if(modernEye.w<.5||modernReflectionCenter.w<.5||any(modernReflectionBounds.xyz<=0))return direction;
 float4 locationH=mul(modernInverseClip,float4(pixel.xy/max(modernViewport.xy,1)*float2(2,-2)+float2(-1,1),pixel.z,1));
 if(abs(locationH.w)<1e-8)return direction;
 float3 relative=locationH.xyz/locationH.w+(modernOrigin.xyz-modernReflectionCenter.xyz),bounds=modernReflectionBounds.xyz;
 if(any(abs(relative)>=bounds))return direction;
 float3 safe=float3(abs(direction.x)<1e-6?(direction.x<0?-1e-6:1e-6):direction.x,abs(direction.y)<1e-6?(direction.y<0?-1e-6:1e-6):direction.y,abs(direction.z)<1e-6?(direction.z<0?-1e-6:1e-6):direction.z);
 float3 distance=(sign(safe)*bounds-relative)/safe;
 float exitDistance=min(distance.x,min(distance.y,distance.z));
 return modernUnit(relative+direction*exitDistance);
}
float3 modernSpecular(float4 position,float3 direction,float roughness,float nv,float3 f0,SamplerState state){
 uint width,height;modernBRDF.GetDimensions(width,height);int2 pixel=min(int2(saturate(float2(nv,roughness))*float2(width,height)),int2(width,height)-1);float2 brdf=modernBRDF.Load(int3(max(pixel,0),0));return max(modernEnvironment.SampleLevel(state,modernReflectionDirection(position,direction),roughness*reflectionControl.z).rgb,0)*(f0*brdf.x+brdf.y)*reflectionControl.y;
}


// Original atmospheric sky shading. Keep native geometry, stars and moon.
cbuffer Common:register(b0){float4 common[11];};
cbuffer Instance:register(b6){float4 tint;float4 alphaControl;};
Texture2D<float4> atmosphereLookup:register(t20);
float3 atmosphere(float3 ray){
 uint width,height;atmosphereLookup.GetDimensions(width,height);
 if(!width||!height)return 0;
 float azimuth=abs(ray.x)+abs(ray.z)<1e-6?0:atan2(ray.z,ray.x);
 float2 uv=float2(.5+azimuth/6.283185307,acos(clamp(ray.y,-1,1))/3.141592654);
 float2 at=uv*float2(width,height)-.5;int2 cell=int2(floor(at));float2 f=frac(at);
 int x0=(cell.x%int(width)+int(width))%int(width),x1=(x0+1)%int(width);
 int y0=clamp(cell.y,0,int(height)-1),y1=clamp(cell.y+1,0,int(height)-1);
 return lerp(lerp(atmosphereLookup.Load(int)SKYMATERIAL"
R"SKYMATERIAL(3(x0,y0,0)).rgb,atmosphereLookup.Load(int3(x1,y0,0)).rgb,f.x),lerp(atmosphereLookup.Load(int3(x0,y1,0)).rgb,atmosphereLookup.Load(int3(x1,y1,0)).rgb,f.x),f.y);
}
float3 skyRay(float4 pixel){
 float2 ndc=float2(2*pixel.x/modernViewport.x-1,1-2*pixel.y/modernViewport.y);
 float4 locationH=mul(modernInverseClip,float4(ndc,.5,1));
 return modernUnit(locationH.xyz/locationH.w-modernEye.xyz);
}
#if MODE<2
struct In{float4 position:SV_Position;float3 mesh:TEXCOORD0;float4 gradient:TEXCOORD1;};
float4 main(In i):SV_Target{
 // Atmospheric integration already includes the entire optical path. Applying
 // the far-distance native fog again would replace it with a flat fog colour.
 float3 colour=modernGridLayout.z>.5&&modernEye.w>.5?atmosphere(skyRay(i.position))*.125:lerp(i.gradient.rgb,common[4].rgb,saturate(i.gradient.w));
 #if MODE==1
 if(alphaControl.x>.5&&1<alphaControl.y)discard;
 return float4(colour,1);
 #else
 return float4(colour,1)*tint;
 #endif
}
#else
cbuffer Clouds:register(b2){float4 cloud[8];};
Texture2D<float4> layer01:register(t0),layer23:register(t1);
SamplerState cloud01:register(s0),cloud23:register(s1);
struct In{float4 position:SV_Position;float3 normal:TEXCOORD0;float4 view:TEXCOORD1;float4 uv:TEXCOORD2;};
float4 main(In i):SV_Target{
 float ramp=saturate((clamp(i.view.y,-1,1)-cloud[6].z)/max(cloud[6].w-cloud[6].z,1e-5));
 float4 first=layer01.Sample(cloud01,i.uv.xy),second=layer23.Sample(cloud23,i.uv.zw);
 float4 mass=float4(first.g,first.a,second.g,second.a)*cloud[0]*ramp;
 float4 clear=1-mass;float coverage=saturate(1-clear.x*clear.y*clear.z*clear.w);
 float brightness=saturate(lerp(lerp(lerp(first.r,first.b,mass.y),second.r,mass.z),second.b,mass.w));
 // Optical path increases through a slanted cloud layer. HDR sources behind
 // it retain transmitted radiance; opacity never depends on source brightness.
 float path=modernEye.w>.5?1/max(abs(skyRay(i.position).y),.2):1;
 float alpha=coverage>=1?1:1-pow(max(1-coverage*coverage,1e-6),path);
 float hemisphere=dot(modernUnit(i.normal),cloud[5].xyz)*.5+.5;
 float3 colour;
 if(modernGridLayout.z>.5&&modernEye.w>.5){
  float3 ambient=atmosphere(float3(0,1,0)),forward=atmosphere(skyRay(i.position));
  colour=(ambient*(.35+.65*saturate(hemisphere))+forward*.35)*(.6+.8*brightness)*.125;
 }else{
  float forward=pow(saturate(dot(modernUnit(i.view.xyz),cloud[5].xyz)),30);
  float scatter=min(exp2(-coverage*cloud[7].y),1);
  colour=brightness*(lerp(cloud[3].rgb,cloud[4].rgb,hemisphere)+scatter*cloud[3].rgb*cloud[7].z*forward)+common[2].rgb;
  colour=lerp(colour,common[4].rgb,saturate(i.view.w));
 }
 float4 result=float4(max(colour,0),alpha)*tint;result.rgb*=result.a;
 return min(result,32);
}
#endif
)SKYMATERIAL";}
