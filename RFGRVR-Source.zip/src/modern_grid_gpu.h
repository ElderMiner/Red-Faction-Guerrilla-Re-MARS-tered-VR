#pragma once
#include "modern_indirect.h"
namespace modernindirect {
class GPUGrid {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> device;Ptr<ID3D11Texture2D> texture;Ptr<ID3D11ShaderResourceView> view;
 std::vector<GPUProbe> rows;uint64_t uploaded=~uint64_t(0);unsigned height=0;bool populated=false;
public:
 bool update(ID3D11DeviceContext* c,const Grid& grid){
  if(!c||c->GetType()!=D3D11_DEVICE_CONTEXT_IMMEDIATE)return false;V origin;float spacing;unsigned side;if(!grid.layout(origin,spacing,side))return false;
  Ptr<ID3D11Device> owner;c->GetDevice(&owner);unsigned count=side*side*side;
  if(device.Get()!=owner.Get()||height!=count){D3D11_TEXTURE2D_DESC desc{};desc.Width=16;desc.Height=count;desc.MipLevels=desc.ArraySize=desc.SampleDesc.Count=1;desc.Format=DXGI_FORMAT_R32G32B32A32_FLOAT;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;Ptr<ID3D11Texture2D> next;Ptr<ID3D11ShaderResourceView> nextView;if(FAILED(owner->CreateTexture2D(&desc,nullptr,&next))||FAILED(owner->CreateShaderResourceView(next.Get(),nullptr,&nextView)))return false;device=owner;texture=next;view=nextView;height=count;uploaded=~uint64_t(0);}
  if(uploaded!=grid.version()){grid.gpu(rows);populated=false;for(auto& row:rows)populated|=row.ready[0]>.5f;c->UpdateSubresource(texture.Get(),0,nullptr,rows.data(),sizeof(GPUProbe),unsigned(rows.size()*sizeof(GPUProbe)));uploaded=grid.version();}return true;
 }
 ID3D11ShaderResourceView* resource()const{return view.Get();}
 bool current(const Grid& grid)const{return populated&&uploaded==grid.version();}
};
}
