#include "vr_head_motion.h"
#include "vr_quest_layout.h"
#include "vr_interaction_context.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <xinput.h>
#include <cstring>
#include <atomic>
#include "ipc.h"
#include "vr_haptics.h"
#include "weapon_physics_input.h"
#include "arm_training_markers.h"
#include "vr_gamepad_math.h"
#include "vr_physical_crouch.h"
#include "vr_physical_jump.h"
#include "vr_user_settings.h"
extern "C" void RFGRVR_HeadCam_Locomotion(bool,bool);
extern "C" void RFGRVR_HeadCam_MoveForward(float);
extern "C" float RFGRVR_HeadCam_ViewYaw();
extern "C" bool RFGRVR_HeadCam_RoomAxes(float,bool,short*,short*);
extern "C" unsigned RFGRVR_HeadCam_PlayerState();
extern "C" void RFGRVR_TankDriverInput(RFGRGamepad*,bool);
extern "C" void RFGRVR_VehicleDriverAxes(short*,short*,short);
extern "C" bool RFGRVR_NativeFacing(float*,float*);
extern "C" bool RFGRVR_NativeTurretAxes(short*,short*);
extern "C" void RFGRVR_TurretStick(float);
extern "C" bool RFGRVR_VehicleFlamer();
extern "C" void RFGRVR_VehicleControlsInput(float,bool);
extern "C" void RFGRVR_VehicleResetView();
extern "C" void RFGRVR_Temporal_Recenter();
extern "C" bool RFGRVR_HeadCam_TurretMounted();
extern "C" void RFGRVR_NativeTurnAxis(float);
extern "C" bool RFGRVR_NativeParented();
extern "C" bool RFGRVR_HeadCam_Enabled();
namespace {
using GetState=DWORD(WINAPI*)(DWORD,XINPUT_STATE*);using SetState=DWORD(WINAPI*)(DWORD,XINPUT_VIBRATION*);
GetState realGet=nullptr;SetState realSet=nullptr;RFGRShared* shared=nullptr;
std::atomic<unsigned> polls{0};bool installed=false;SRWLOCK lock=SRWLOCK_INIT;
LONG previousSamples=0;ULONGLONG changed=0;
static bool foreground(){DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);return pid==GetCurrentProcessId();}
// XR focus loss is not a controller unplug. Keep the virtual pad connected
// and neutral during a short input gap while the companion is still alive.
static bool bridgeConnected(){static LONG beat=0,pid=0;static ULONGLONG tick=0;if(!shared||shared->magic!=RFGR_MAGIC||shared->version!=RFGR_PROTOCOL||!shared->calibrationReady||shared->bridgePid<=0)return false;auto now=GetTickCount64();LONG current=shared->bridgeHeartbeat,process=shared->bridgePid;if(current!=beat||process!=pid){beat=current;pid=process;tick=now;}return tick&&now-tick<=1500;}
static DWORD neutralState(XINPUT_STATE* state){ZeroMemory(state,sizeof(*state));state->dwPacketNumber=polls.load();return ERROR_SUCCESS;}
static bool snapshot(RFGRGamepad& pad){
 if(!shared||shared->magic!=RFGR_MAGIC||shared->version!=RFGR_PROTOCOL)return false;
 for(int i=0;i<3;++i){LONG a=shared->inputSequence;if(a&1)continue;
  MemoryBarrier();RFGRGamepad copy=shared->gamepad;LONG sample=shared->inputSamples,active=shared->gamepadActive;
  MemoryBarrier();if(a!=shared->inputSequence)continue;
  auto now=GetTickCount64();if(sample!=previousSamples){previousSamples=sample;changed=now;}
  if(!active||!sample||!changed||now-changed>250)return false;
  pad=copy;return true;
 }return false;
}
static vrquest::CommandState questCommands;
static std::atomic<bool> physicalCrouchView{false};static RFGRVRPhysicalCrouch physicalCrouch,seatCrouch;static std::atomic<bool> vehicleSitting{false};static LARGE_INTEGER crouchClock{};static LONG crouchSample=0;static ULONGLONG crouchFresh=0;
static RFGRVRPhysicalJump physicalJump;static bool jumpHeld=false;static LONG gestureSample=0;static LARGE_INTEGER gestureClock{};
static bool physicalCrouchHeld(){
 RFGRPose head{};float standing=0;bool valid=false;auto now=GetTickCount64();
 if(shared)for(int i=0;i<3;++i){LONG seq=shared->poseSequence;if(seq&1)continue;MemoryBarrier();head=shared->hmd;standing=shared->calibratedHeadHeight;LONG sample=shared->poseSamples;bool calibrated=shared->calibrationReady&&shared->calibrationFloorValid;MemoryBarrier();if(seq!=shared->poseSequence)continue;
  if(sample!=crouchSample){crouchSample=sample;crouchFresh=now;}valid=calibrated&&sample&&crouchFresh&&now-crouchFresh<250&&(head.validFlags&3)==3;break;}
 LARGE_INTEGER clock{},frequency{};QueryPerformanceCounter(&clock);QueryPerformanceFrequency(&frequency);float dt=crouchClock.QuadPart?float(double(clock.QuadPart-crouchClock.QuadPart)/frequency.QuadPart):0;crouchClock=clock;
 unsigned seatState=RFGRVR_HeadCam_PlayerState();if(valid&&seatState>=7&&seatState<=10)vehicleSitting=seatCrouch.update(vrheadmotion::uprightHeight(head),standing,dt,true);else if(seatState<7||seatState>10){seatCrouch.reset();vehicleSitting=false;}bool allowed=valid&&!RFGRVR_NativeParented()&&RFGRVR_HeadCam_PlayerState()==0;
 if(!allowed){physicalJump.reset();jumpHeld=false;gestureClock.QuadPart=0;gestureSample=0;}
 else if(crouchSample!=gestureSample){float elapsed=gestureClock.QuadPart?float(double(clock.QuadPart-gestureClock.QuadPart)/frequency.QuadPart):0;gestureClock=clock;gestureSample=crouchSample;jumpHeld=physicalJump.update(vrheadmotion::uprightHeight(head),standing,elapsed,true);}
 auto config=vrsettings::get();allowed=allowed&&!config.value[vrsettings::Seated];float threshold=config.value[vrsettings::Crouch]==0?.55f:config.value[vrsettings::CrouchDepth]/100.f;
 bool crouched=physicalCrouch.update(vrheadmotion::uprightHeight(head),standing,dt,allowed&&config.value[vrsettings::Crouch]!=2,threshold);physicalCrouchView=allowed&&crouched;return crouched;
}
// Native keyboard/mouse pause input can take ownership without a neutral
// synthetic gamepad continually forcing the game's controller menu mode.
static bool desktopPauseInput(const RFGRGamepad& pad){
 static bool desktop=false;static POINT previous{};static bool mouseKnown=false;
 if(!vrsettings::paused()||!foreground()){desktop=false;mouseKnown=false;return false;}
 POINT current{};GetCursorPos(&current);bool mouse=mouseKnown&&(abs(current.x-previous.x)>2||abs(current.y-previous.y)>2);previous=current;mouseKnown=true;
 bool keys=false;for(int key:{VK_ESCAPE,VK_RETURN,VK_UP,VK_DOWN,VK_LEFT,VK_RIGHT,VK_TAB,VK_LBUTTON,VK_RBUTTON})keys=keys||((GetAsyncKeyState(key)&0x8000)!=0);
 bool controller=pad.buttons||abs(int(pad.leftX))>12000||abs(int(pad.leftY))>12000||abs(int(pad.rightX))>12000||abs(int(pad.rightY))>12000||pad.leftTrigger>100||pad.rightTrigger>100;
 if(controller)desktop=false;else if(keys||mouse)desktop=true;return desktop;
}
static DWORD WINAPI OnGet(DWORD index,XINPUT_STATE* state){
 if(index||!state)return realGet?realGet(index,state):ERROR_DEVICE_NOT_CONNECTED;
 ++polls;AcquireSRWLockExclusive(&lock);RFGRGamepad pad{};const bool active=snapshot(pad);const bool connected=active||bridgeConnected();
 auto* settingsBus=vrsettings::bus();bool nativeMenu=foreground()&&vrsettings::pauseMenu()&&settingsBus&&settingsBus->nativeSettings;static bool releaseMenuControls=false;if(nativeMenu){releaseMenuControls=true;ReleaseSRWLockExclusive(&lock);return neutralState(state);}if(releaseMenuControls){bool held=pad.buttons||abs(int(pad.leftX))>12000||abs(int(pad.leftY))>12000||abs(int(pad.rightX))>12000||abs(int(pad.rightY))>12000||pad.leftTrigger>100||pad.rightTrigger>100;if(held){ReleaseSRWLockExclusive(&lock);return neutralState(state);}releaseMenuControls=false;}
 // A modal UI owns native navigation, not VR locomotion, weapon filtering or
 // vehicle controls. Its pause/acknowledge button must not become a gameplay
 // action when the tutorial closes while it is still held.
 static unsigned menuButtons=0;
 const bool modal=vrsettings::paused();
 if(active&&modal){
  questCommands={};physicalCrouch.reset();physicalCrouchView=false;physicalJump.reset();jumpHeld=false;
  RFGRVR_HeadCam_MoveForward(0);RFGRVR_HeadCam_Locomotion(false,false);RFGRVR_NativeTurnAxis(0);RFGRVR_TurretStick(0);
  menuButtons|=pad.buttons;
  const bool desktop=desktopPauseInput(pad);
  pad.buttons&=~vrquest::Commands;
  // Preserve native START. The base game's salvage/PAUSED popup explicitly
  // requests START, not A/Confirm. Menu navigation must stay profile-neutral.
  if(!foreground()||desktop){ReleaseSRWLockExclusive(&lock);return neutralState(state);}
  ZeroMemory(state,sizeof(*state));state->dwPacketNumber=polls.load();memcpy(&state->Gamepad,&pad,sizeof(pad));
  ReleaseSRWLockExclusive(&lock);return ERROR_SUCCESS;
 }
 if(!modal){desktopPauseInput(pad);menuButtons&=pad.buttons;pad.buttons&=~menuButtons;}
 if(active&&desktopPauseInput(pad)){ReleaseSRWLockExclusive(&lock);return neutralState(state);}
 if(!active)questCommands={};
 if(active){const float rawRightY=pad.rightY/32767.f;bool heightGrip=false;if(shared)for(unsigned attempt=0;attempt<3;++attempt){LONG sequence=shared->inputSequence;if(sequence&1)continue;MemoryBarrier();float squeeze=shared->gripValue[1];MemoryBarrier();if(sequence==shared->inputSequence){heightGrip=std::isfinite(squeeze)&&squeeze>.65f;break;}}static bool resetHeld=false;bool seated=RFGRVR_HeadCam_PlayerState()>=7&&RFGRVR_HeadCam_PlayerState()<=10;bool reset=(pad.buttons&XINPUT_GAMEPAD_LEFT_THUMB)!=0;if(seated&&reset&&!resetHeld&&foreground()){RFGRVR_VehicleResetView();RFGRVR_Temporal_Recenter();}resetHeld=reset;if(seated)pad.buttons&=~XINPUT_GAMEPAD_LEFT_THUMB;RFGRVR_HeadCam_MoveForward(pad.leftY/32767.f);
  if(!foreground()){RFGRVR_HeadCam_MoveForward(0);physicalCrouch.reset();physicalCrouchView=false;physicalJump.reset();jumpHeld=false;RFGRVR_HeadCam_Locomotion(false,false);pad={};RFGRVR_NativeTurnAxis(0);}
  else {bool controllerMoving=abs(int(pad.leftX))>7000||abs(int(pad.leftY))>7000;bool stickTurning=abs(int(pad.rightX))>7000;bool physicalDuck=physicalCrouchHeld();if(!vrsettings::paused()&&shared&&shared->gameplayActive&&RFGRVR_HeadCam_PlayerState()<=2&&!vrsettings::get().value[vrsettings::Seated]&&vrsettings::get().value[vrsettings::Crouch]!=2)pad.buttons&=~XINPUT_GAMEPAD_LEFT_THUMB;if(physicalDuck)pad.buttons|=XINPUT_GAMEPAD_LEFT_THUMB;auto settings=vrsettings::get();if(!vrsettings::paused()&&shared&&shared->gameplayActive&&settings.value[vrsettings::Jump]==0)pad.buttons&=~XINPUT_GAMEPAD_A;if(!vrsettings::paused()&&jumpHeld&&settings.value[vrsettings::Jump]!=2&&!settings.value[vrsettings::Seated])pad.buttons|=XINPUT_GAMEPAD_A;bool turret=RFGRVR_HeadCam_TurretMounted();unsigned seatState=RFGRVR_HeadCam_PlayerState();bool vehicle=seatState>=7&&seatState<=10;RFGRVR_NativeTurnAxis((turret||vehicle)?0.f:pad.rightX/32767.f);RFGRVR_TurretStick(turret?pad.leftX/32767.f:0.f);float yaw=0,pitch=0;if(turret){pad.leftX=pad.leftY=pad.rightX=pad.rightY=0;RFGRVR_HeadCam_MoveForward(0);controllerMoving=stickTurning=false;}else if(vehicle){if(!vrsettings::paused()&&seatState==9)RFGRVR_TankDriverInput(&pad,heightGrip);RFGRVR_VehicleDriverAxes(&pad.leftX,&pad.leftY,pad.rightX);pad.rightX=pad.rightY=0;controllerMoving=stickTurning=false;}else if(RFGRVR_NativeFacing(&yaw,&pitch)){
   // Move in the rendered head direction, independent of native camera yaw.
   bool stickMoving=abs(int(pad.leftX))>7000||abs(int(pad.leftY))>7000;
   RFGRVR_ViewRelativeMove(pad.leftX,pad.leftY,yaw);
   RFGRVR_HeadCam_RoomAxes(RFGRVR_HeadCam_ViewYaw()-yaw,!stickMoving&&!RFGRVR_NativeParented()&&RFGRVR_HeadCam_PlayerState()==0,&pad.leftX,&pad.leftY);
   // Head rotation is render tracking, not native look/stance input.
   pad.rightX=pad.rightY=0;
  }else if(RFGRVR_NativeParented()){pad.rightX=pad.rightY=0;}RFGRVR_HeadCam_Locomotion(controllerMoving,stickTurning);}
  unsigned vehicleState=RFGRVR_HeadCam_PlayerState();RFGRVR_VehicleControlsInput((vehicleState==3||(vehicleState>=7&&vehicleState<=10))&&heightGrip&&foreground()&&!vrsettings::paused()?rawRightY:0,(pad.buttons&0x80)!=0||(RFGRVR_VehicleFlamer()&&!heightGrip&&rawRightY<-.65f));
  // Sprint is a modifier, never an autonomous forward command. Leave menu
  // navigation and every vehicle's bumper binding unchanged.
  if(shared&&shared->gameplayActive&&!shared->theaterMode&&!vrsettings::paused()&&RFGRVR_HeadCam_PlayerState()<=2&&abs(int(pad.leftX))<=7000&&abs(int(pad.leftY))<=7000)pad.buttons&=~XINPUT_GAMEPAD_LEFT_SHOULDER;
  questCommands.apply(pad,shared&&shared->gameplayActive&&!shared->theaterMode&&!vrsettings::paused(),vrinteraction::available(GetTickCount()),RFGRVRWeaponInput::fresh()&&RFGRVRWeaponInput::c4Controlled.load());
  RFGRVRWeaponInput::filterFocus(pad,RFGRVR_HeadCam_Enabled()&&shared&&shared->calibrationReady&&shared->gameplayActive&&!shared->theaterMode);
  RFGRVRWeaponInput::filter(pad,RFGRVR_HeadCam_Enabled()&&shared&&shared->calibrationReady&&shared->gameplayActive&&!shared->theaterMode&&RFGRVR_HeadCam_PlayerState()<=2);
  if(vrtraining::active.load()&&shared&&shared->gameplayActive&&!shared->theaterMode&&RFGRVR_HeadCam_PlayerState()==0){auto menu=pad.buttons&(XINPUT_GAMEPAD_START|XINPUT_GAMEPAD_BACK);pad={};pad.buttons=menu;}
  ZeroMemory(state,sizeof(*state));state->dwPacketNumber=polls.load();
  static_assert(sizeof(pad)==sizeof(state->Gamepad),"XInput gamepad ABI");memcpy(&state->Gamepad,&pad,sizeof(pad));
  ReleaseSRWLockExclusive(&lock);return ERROR_SUCCESS;
 }
 physicalCrouch.reset();physicalCrouchView=false;physicalJump.reset();jumpHeld=false;RFGRVR_HeadCam_Locomotion(false,false);RFGRVR_NativeTurnAxis(0);ReleaseSRWLockExclusive(&lock);if(connected)return neutralState(state);return realGet?realGet(index,state):ERROR_DEVICE_NOT_CONNECTED;
}
static DWORD WINAPI OnSet(DWORD index,XINPUT_VIBRATION* vibration){
 if(index==0&&shared&&shared->gamepadActive){if(!vibration)return ERROR_BAD_ARGUMENTS;static RFGRHapticWriter haptics;haptics.publish(vibration->wLeftMotorSpeed,vibration->wRightMotorSpeed);return ERROR_SUCCESS;}
 return realSet?realSet(index,vibration):ERROR_DEVICE_NOT_CONNECTED;
}
}
extern "C" bool RFGRVR_Gamepad_Install(RFGRShared* data){
 shared=data;RFGRVRWeaponInput::source=data;auto* base=(unsigned char*)GetModuleHandleW(nullptr);auto* dos=(IMAGE_DOS_HEADER*)base;
 auto* nt=(IMAGE_NT_HEADERS32*)(base+dos->e_lfanew);auto dir=nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
 auto* imp=(IMAGE_IMPORT_DESCRIPTOR*)(base+dir.VirtualAddress);
 for(;imp->Name;++imp){if(_stricmp((char*)base+imp->Name,"XINPUT1_3.dll")||!imp->OriginalFirstThunk)continue;
  auto* names=(IMAGE_THUNK_DATA32*)(base+imp->OriginalFirstThunk);auto* slots=(IMAGE_THUNK_DATA32*)(base+imp->FirstThunk);
  for(unsigned i=0;names[i].u1.AddressOfData;++i){unsigned ordinal=(names[i].u1.Ordinal&IMAGE_ORDINAL_FLAG32)?IMAGE_ORDINAL32(names[i].u1.Ordinal):0;
   const char* name=ordinal?"":(char*)((IMAGE_IMPORT_BY_NAME*)(base+names[i].u1.AddressOfData))->Name;
   void* hook=nullptr;if(ordinal==2||!strcmp(name,"XInputGetState")){realGet=(GetState)slots[i].u1.Function;hook=(void*)&OnGet;}
   if(ordinal==3||!strcmp(name,"XInputSetState")){realSet=(SetState)slots[i].u1.Function;hook=(void*)&OnSet;}
   if(!hook)continue;DWORD old=0;if(!VirtualProtect(&slots[i].u1.Function,4,PAGE_READWRITE,&old))continue;
   InterlockedExchange((volatile LONG*)&slots[i].u1.Function,(LONG)hook);DWORD ignored=0;VirtualProtect(&slots[i].u1.Function,4,old,&ignored);
  }
 }installed=realGet!=nullptr;return installed;
}
extern "C" bool RFGRVR_Gamepad_Installed(){return installed;}
extern "C" unsigned RFGRVR_Gamepad_Polls(){return polls.load();}


extern "C" bool RFGRVR_PhysicalCrouchView(){return physicalCrouchView.load();}

extern "C" bool RFGRVR_VehicleSitting(){return vehicleSitting.load();}
