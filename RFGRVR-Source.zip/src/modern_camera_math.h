#pragma once
#include <cmath>
#include <cstring>
namespace moderncamera {
// Native matrices are column-major. Return the inverse in the row-major GPU ABI.
inline bool inverse(const float* columnMajor,float* output){
 double a[4][8]{};
 for(unsigned r=0;r<4;++r)for(unsigned c=0;c<4;++c){float v=columnMajor[c*4+r];if(!std::isfinite(v))return false;a[r][c]=v;a[r][c+4]=r==c;}
 for(unsigned c=0;c<4;++c){unsigned pivot=c;for(unsigned r=c+1;r<4;++r)if(std::abs(a[r][c])>std::abs(a[pivot][c]))pivot=r;if(std::abs(a[pivot][c])<1e-12)return false;
  if(pivot!=c)for(unsigned k=0;k<8;++k){double t=a[pivot][k];a[pivot][k]=a[c][k];a[c][k]=t;}double scale=a[c][c];for(unsigned k=0;k<8;++k)a[c][k]/=scale;
  for(unsigned r=0;r<4;++r)if(r!=c){double f=a[r][c];for(unsigned k=0;k<8;++k)a[r][k]-=f*a[c][k];}
 }
 float result[16];for(unsigned r=0;r<4;++r)for(unsigned c=0;c<4;++c){double v=a[r][c+4];if(!std::isfinite(v)||std::abs(v)>1e10)return false;result[r*4+c]=float(v);}memcpy(output,result,sizeof(result));return true;
}
}
