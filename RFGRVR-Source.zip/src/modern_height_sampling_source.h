#pragma once
namespace modernheight {inline constexpr char samplingSource[]=
R"HEIGHTS(// Shallow world-scaled relief. Geometry/collision/silhouette remain native.
cbuffer ModernHeights:register(b12){float4 modernHeightAmplitude;float4 modernHeightLimits;};
Texture2D<float> modernHeight0:register(t21),modernHeight1:register(t22),modernHeight2:register(t23),modernHeight3:register(t24);
float modernHeight(int layer,float2 uv,float2 dx,float2 dy,SamplerState state){
 [branch]if(layer==0)return modernHeight0.SampleGrad(state,uv,dx,dy);
 [branch]if(layer==1)return modernHeight1.SampleGrad(state,uv,dx,dy);
 [branch]if(layer==2)return modernHeight2.SampleGrad(state,uv,dx,dy);
 return modernHeight3.SampleGrad(state,uv,dx,dy);
}
float2 modernRelief(float4 pixel,float2 uv,int layer,float weight,SamplerState state){
 float2 du=ddx(uv),dv=ddy(uv);
 float4 locationH=mul(modernInverseClip,float4(pixel.xy/max(modernViewport.xy,1)*float2(2,-2)+float2(-1,1),pixel.z,1));
 float3 position=locationH.xyz/(abs(locationH.w)>1e-8?locationH.w:1);float3 dx=ddx(position),dy=ddy(position);
 [branch]if(modernEye.w<.5||modernHeightAmplitude[layer]<=0||weight<.03||abs(locationH.w)<1e-8)return uv;
 float3 view=modernEye.xyz-position;float distance=length(view);
 float fade=1-smoothstep(modernHeightLimits.x,modernHeightLimits.y,distance);
 [branch]if(fade<=0||distance<.01)return uv;view/=distance;
 float xx=dot(dx,dx),yy=dot(dy,dy),xy=dot(dx,dy),det=xx*yy-xy*xy;
 [branch]if(det<1e-14)return uv;
 float3 gradientU=((du.x*yy-dv.x*xy)*dx+(dv.x*xx-du.x*xy)*dy)/det;
 float3 gradientV=((du.y*yy-dv.y*xy)*dx+(dv.y*xx-du.y*xy)*dy)/det;
 float3 normal=modernUnit(cross(dx,dy));float incidence=abs(dot(view,normal));
 float amplitude=modernHeightAmplitude[layer]*fade*smoothstep(.1,.25,incidence);
 float2 shift=float2(dot(view,gradientU),dot(view,gradientV))*amplitude/max(incidence,.25);
 int steps=clamp((int)lerp(modernHeightLimits.z,8,saturate(incidence)),8,24);float stepDepth=1.0/steps;
 float2 at=uv+shift*.5;float depth=0,surface=1-saturate(modernHeight(layer,at,du,dv,state));float prior=surface;
 [loop]for(int n=0;n<steps&&depth<surface;++n){prior=surface-depth;at-=shift*stepDepth;depth+=stepDepth;surface=1-saturate(modernHeight(layer,at,du,dv,state));}
 if(depth<=0)return at;
 float crossed=surface-depth;float mix=prior/(max(prior-crossed,1e-6));
 return at+shift*stepDepth*(1-saturate(mix));
}
)HEIGHTS";}
