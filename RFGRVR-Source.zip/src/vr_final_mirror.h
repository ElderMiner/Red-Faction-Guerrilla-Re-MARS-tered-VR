#pragma once
#include <cstdint>
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wrl/client.h>
#include "vr_desktop_menu.h"
#include "vr_projection_viewport.h"
namespace vrfinalmirror {
using Microsoft::WRL::ComPtr;
struct alignas(8) Packet {volatile LONG sequence=0;DWORD owner=0,tick=0,generation=0;uint64_t handle=0;};
inline Packet* packet(){static HANDLE h=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Packet),L"Local\\RFGRVR_FinalLeftEye_v1");static auto* p=h?(Packet*)MapViewOfFile(h,FILE_MAP_ALL_ACCESS,0,0,sizeof(Packet)):nullptr;return p;}
inline bool fresh(DWORD game,DWORD now=GetTickCount()){auto* p=packet();if(!p)return false;LONG seq=InterlockedCompareExchange(&p->sequence,0,0);if(seq&1)return false;DWORD owner=p->owner,tick=p->tick;uint64_t handle=p->handle;MemoryBarrier();return seq==p->sequence&&owner==game&&handle&&DWORD(now-tick)<500;}
struct Producer {
 ComPtr<ID3D11Device> owner;ComPtr<ID3D11Texture2D> image;ComPtr<IDXGIKeyedMutex> mutex;DWORD generation=0;HANDLE handle=nullptr;
 bool copy(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* source,DWORD game){
  if(!d||!c||!source||!game)return false;auto* p=packet();if(!p)return false;D3D11_TEXTURE2D_DESC desc{},old{};source->GetDesc(&desc);auto active=vrprojection::viewport(desc.Width,desc.Height);desc.Width=unsigned(active.Width);desc.Height=unsigned(active.Height);if(image)image->GetDesc(&old);
  if(owner.Get()!=d||!image||!mutex||!handle||desc.Width!=old.Width||desc.Height!=old.Height||desc.Format!=old.Format){image.Reset();mutex.Reset();owner=d;handle=nullptr;auto td=desc;td.ArraySize=td.MipLevels=td.SampleDesc.Count=1;td.SampleDesc.Quality=0;td.Usage=D3D11_USAGE_DEFAULT;td.CPUAccessFlags=0;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;td.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
   if(FAILED(d->CreateTexture2D(&td,nullptr,&image))||FAILED(image.As(&mutex)))return false;ComPtr<IDXGIResource> resource;if(FAILED(image.As(&resource))||FAILED(resource->GetSharedHandle(&handle)))return false;generation=GetTickCount();if(!generation)generation=1;}
  if(mutex->AcquireSync(0,0)!=S_OK)return false;D3D11_BOX region{0,0,0,desc.Width,desc.Height,1};c->CopySubresourceRegion(image.Get(),0,0,0,0,source,0,&region);c->Flush();mutex->ReleaseSync(1);
  InterlockedIncrement(&p->sequence);p->owner=game;p->handle=(uint64_t)(uintptr_t)handle;p->generation=generation;p->tick=GetTickCount();MemoryBarrier();InterlockedIncrement(&p->sequence);return true;
 }
};
struct Consumer {
 ComPtr<ID3D11Device> owner;ComPtr<ID3D11Texture2D> image;ComPtr<IDXGIKeyedMutex> mutex;uint64_t handle=0;DWORD generation=0;RFGRVRDesktopMenu blit;
 bool present(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* back){auto* p=packet();if(!p||!d||!c||!back)return false;LONG seq=InterlockedCompareExchange(&p->sequence,0,0);if(seq&1)return false;DWORD game=p->owner,tick=p->tick,gen=p->generation;uint64_t h=p->handle;MemoryBarrier();if(seq!=p->sequence||game!=GetCurrentProcessId()||!h)return false;
  if(owner.Get()!=d||handle!=h||generation!=gen){image.Reset();mutex.Reset();owner=d;if(FAILED(d->OpenSharedResource((HANDLE)(uintptr_t)h,IID_PPV_ARGS(&image)))||FAILED(image.As(&mutex)))return false;handle=h;generation=gen;}
  if(mutex->AcquireSync(1,0)!=S_OK)return false;bool ok=blit.draw(d,c,back,image.Get(),true);c->Flush();mutex->ReleaseSync(0);return ok;
 }
};
}
