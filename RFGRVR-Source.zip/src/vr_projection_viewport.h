#pragma once
#include <d3d11.h>
namespace vrprojection {
// Gameplay may use a smaller OpenXR image rectangle inside a menu-sized allocation.
inline thread_local unsigned width=0,height=0;
struct ViewportScope {
 unsigned oldWidth=width,oldHeight=height;
 ViewportScope(unsigned w,unsigned h){width=w;height=h;}
 ViewportScope(const ViewportScope&)=delete;ViewportScope& operator=(const ViewportScope&)=delete;
 ~ViewportScope(){width=oldWidth;height=oldHeight;}
};
inline D3D11_VIEWPORT viewport(unsigned w,unsigned h){return {0,0,float(width&&width<=w?width:w),float(height&&height<=h?height:h),0,1};}
inline bool fits(unsigned w,unsigned h,unsigned allocatedWidth,unsigned allocatedHeight){return w&&h&&w<=allocatedWidth&&h<=allocatedHeight;}
inline bool activeSize(bool menu,unsigned desiredWidth,unsigned desiredHeight,unsigned allocatedWidth,unsigned allocatedHeight,unsigned* w,unsigned* h){
 if(!w||!h||!fits(desiredWidth,desiredHeight,allocatedWidth,allocatedHeight))return false;
 *w=menu?allocatedWidth:desiredWidth;*h=menu?allocatedHeight:desiredHeight;return true;
}
}
