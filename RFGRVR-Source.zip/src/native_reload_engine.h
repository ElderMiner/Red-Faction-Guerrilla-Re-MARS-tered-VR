#include "vr_user_settings.h"
#pragma once
// Included inside RFGRVRWeaponPhysics after native ownership helpers.
namespace Reload {
using Start=bool(__cdecl*)(void*,unsigned,void*);inline Start originalStart=nullptr;
using Refill=void(__thiscall*)(void*);inline Refill originalRefill=nullptr;
using Capacity=int(__thiscall*)(void*);inline Capacity capacity=nullptr;
using Descriptor=void*(__thiscall*)(void*,void*,const V*,const M*,unsigned*,unsigned,float,unsigned);inline Descriptor descriptor=nullptr;
using DescriptorFree=void(__thiscall*)(void*);inline DescriptorFree descriptorFree=nullptr;
using RegistryCreate=void*(__thiscall*)(void*,void*,void*,bool,unsigned);inline RegistryCreate create=nullptr;
using RegistryDelete=void(__thiscall*)(void*,void*,bool);inline RegistryDelete destroy=nullptr;
using ItemLookup=void*(__cdecl*)(const char*);inline ItemLookup itemLookup=nullptr;inline std::atomic<bool> captureRocket{false};
inline bool rocket(const Target& t){void* info=(void*)(uintptr_t)word(t.weapon,0x148);const char* name=(const char*)(uintptr_t)word(info,0);return memory(name,32)&&(!strncmp(name,"rpg_launcher",12)||!strncmp(name,"thermobaric_rockets",18)||!strcmp(name,"missilepod"));}
inline bool pod(const Target& t){auto* name=(const char*)(uintptr_t)word((void*)(uintptr_t)word(t.weapon,0x148),0);return memory(name,11)&&!strcmp(name,"missilepod");}
inline void* manager=nullptr;inline bool enabled=false;
struct Object {void* ptr=nullptr;unsigned handle=~0u;};
inline bool validObject(Object o){return memory(o.ptr,0x104)&&word(o.ptr,0x6c)==o.handle;}
using Stack=std::array<Object,vrpod::Maximum-1>;
struct Entry {void* weapon=nullptr;unsigned handle=~0u,owner=~0u;vrreload::State state;vrreload::PickupHint pickupHint;vrreload::Seating seating;Object source{},held{},ghost{},loaded{};void* info=nullptr;DWORD last=0,ghostTry=0,loadedTry=0;int retainedRounds=0;Stack heldStack{},ghostStack{};unsigned heldRounds=1;float podSpacing=.08f;bool spacingReady=false;DWORD stackTry=0;bool rocketReady=false,captureGrip=false,magGripReady=false;Pose magGrip{};Pose rocketLocal{M{{1,0,0},{0,1,0},{0,0,1}},V{0,0,-.25f}};};
inline Entry entries[32];inline unsigned next=0;inline SRWLOCK visualLock=SRWLOCK_INIT;
struct Visual {Object held{},ghost{},source{};Pose handLocal{};bool grip=false,removed=false,empty=false;unsigned weapon=~0u;DWORD tick=0;bool rocket=false;Pose wellLocal{};bool magazinePose=false;float fingerCurl[5]{};vrreload::Seating seating;Object loaded{};Stack heldStack{},ghostStack{};unsigned heldCount=0,ghostCount=0;float stackSpacing=.08f,stackScale=1;};inline Visual visual;
inline Object dropped[24];inline DWORD droppedTick[24]{};inline unsigned droppedNext=0;
inline Entry* find(const Target& t){for(auto& e:entries)if(e.weapon==t.weapon&&e.handle==t.handle&&e.owner==t.playerHandle)return &e;return nullptr;}
inline bool eligible(const Target& t){return enabled&&!vrsettings::get().value[vrsettings::Reload]&&(rocket(t)||t.magazine&&t.weaponClass!=3&&t.weaponClass!=4&&t.weaponClass!=7&&word(t.magazine,0x6c)==t.magazineHandle&&word(t.magazine,0x70)==t.handle&&word(t.magazine,0xe4)==1)&&t.weaponClass!=3&&t.weaponClass!=4&&t.weaponClass!=7;}
inline void alpha(Object o,float value){if(validObject(o))memcpy((char*)o.ptr+0xc0,&value,4);}
inline void erase(Object& o){if(destroy&&validObject(o))destroy(base+0x2b98490,o.ptr,false);o={};}
inline void clearStack(Stack& stack){for(auto& item:stack)erase(item);}
inline Object spawn(void* info,const Pose& pose,bool physics){manager=(void*)(uintptr_t)word(base,0x2c6654c);if(!descriptor||!descriptorFree||!create||!manager||!memory(info,0x98)||!valid(pose.b)||!finite(pose.p))return {};
 alignas(16) unsigned char data[0x200]{};unsigned flags=physics?0x6024u:0x6026u;
 descriptor(data,info,&pose.p,&pose.b,&flags,word(base,0x125fe30),-1.f,~0u);void* item=create(base+0x2b98490,manager,data,false,~0u);descriptorFree(data);
 if(!memory(item,0x104)||*((unsigned char*)item+0x7e)!=1)return {};return {item,word(item,0x6c)};}
inline void move(Object o,const Pose& pose){if(!validObject(o))return;void* table=(void*)(uintptr_t)word(o.ptr,0);auto fn=(Move)(uintptr_t)word(table,0x30);if(fn)fn(o.ptr,&pose.p,&pose.b,true);}
inline void updateStack(Stack& stack,unsigned count,void* info,const Pose& root,float gap,float scale,float opacity,bool retry){
 for(unsigned i=0;i<stack.size();++i){if(i+1>=count){erase(stack[i]);continue;}Pose at=vrpod::at(root,i+1,gap,scale);if(!validObject(stack[i])&&retry)stack[i]=spawn(info,at,false);alpha(stack[i],opacity);move(stack[i],at);}
}
inline void drop(Entry& e,const Pose& pose,V velocity={}){Object item=spawn(e.info,pose,true);if(!validObject(item))return;char line[140];sprintf_s(line,"Manual magazine dropped: object=%p handle=%08x body=%u",item.ptr,item.handle,word(item.ptr,0x4c));log(line);unsigned body=word(item.ptr,0x4c);if(body<65536&&word(base,0x236e980+body*4)){if(movable)movable(body,true);if(linearVelocity)linearVelocity(body,&velocity);}unsigned i=droppedNext++%24;erase(dropped[i]);dropped[i]=item;droppedTick[i]=GetTickCount();}
inline void sound(const Target& t,unsigned phase){void* info=(void*)(uintptr_t)word(t.weapon,0x148);const char* name=(const char*)(uintptr_t)word(info,0);bool pistol=memory(name,11)&&!strncmp(name,"edf_pistol",10),rpg=memory(name,4)&&!strncmp(name,"rpg",3);const char* cueName=phase==1?(pistol?"MOV_FOLEY_PISTOL_CLIP_POUND":rpg?"MOV_FOLEY_RPG_CLIP_POUND":"MOV_FOLEY_RIFLE_CLIP_INSERT"):"MOV_FOLEY_RIFLE_CLIP_SLIDE";int cue=-1;if(cueId)cueId(cueName,&cue);if(cue<0)cue=(int)word(info,0x90);if(cue>=0&&playCue){V p=t.magazine&&finite(t.magazinePose.p)&&length(sub(t.magazinePose.p,t.grip.p))<3*t.motion.scale?t.magazinePose.p:t.grip.p;int error=0;playCue(cue,&p,nullptr,nullptr,&error);}}

inline bool controls(void* player,void* weapon){if(!enabled||vrsettings::get().value[vrsettings::Reload]||!memory(player,0xc94)||!memory(weapon,0x150)||word(weapon,0x13c)!=word(player,0x6c))return false;Target t{};snapshot(t);void* local=(void*)(uintptr_t)word(base,0x2c23874);if(local?player!=local:player!=t.player||word(player,0x6c)!=t.playerHandle)return false;void* info=(void*)(uintptr_t)word(weapon,0x148);unsigned type=word(info,0x10);if(type==3||type==4||type==7)return false;
 for(auto& e:entries)if(e.weapon==weapon&&e.handle==word(weapon,0x6c)&&e.owner==word(player,0x6c))return true;
 void* itemInfo=(void*)(uintptr_t)word(weapon,0xa4);unsigned count=word(itemInfo,0x30);if(count>6||!memory(itemInfo,0x34+count*16))return false;for(unsigned i=0;i<count;++i)if(word(itemInfo,0x3c+i*16)==1)return true;return false;}
inline bool __cdecl onStart(void* player,unsigned mode,void* weapon){Target t{};snapshot(t);if(!weapon&&player==t.player&&word((void*)(uintptr_t)word(player,0xc90),24)==t.handle)weapon=t.weapon;if(!weapon&&resolveObject)weapon=resolveObject(base+0x2b98490,word((void*)(uintptr_t)word(player,0xc90),24));if(controls(player,weapon))return false;return originalStart(player,mode,weapon);}
inline void __fastcall onRefill(void* weapon,void*){Target t{};snapshot(t);void* local=(void*)(uintptr_t)word(base,0x2c23874);if(controls(local?local:t.player,weapon))return;originalRefill(weapon);}
inline bool sourceHidden(void* source){AcquireSRWLockShared(&visualLock);bool matching=visual.source.ptr==source&&visual.source.handle==word(source,0x6c);bool rocketAmmo=visual.rocket&&word(source,0x70)==visual.weapon&&word(source,0xe4)==0;bool hidden=(matching||rocketAmmo)&&visual.removed&&DWORD(GetTickCount()-visual.tick)<250;ReleaseSRWLockShared(&visualLock);return hidden;}

inline char profileOverride[MAX_PATH]{};
inline bool profileLocation(const Target& t,char (&path)[MAX_PATH],char (&name)[96]){
 GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,92);if(!slash)return false;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-reload-positions.ini");if(profileOverride[0])strcpy_s(path,profileOverride);
 const char* text=(const char*)(uintptr_t)word((void*)(uintptr_t)word(t.weapon,0x148),0);if(!memory(text,96)||!memchr(text,0,96))return false;strcpy_s(name,text);return true;
}
inline bool spacingProfile(const Target& t,float& gap,bool save){char path[MAX_PATH]{},name[96]{},value[40];if(!profileLocation(t,path,name))return false;
 if(save){sprintf_s(value,"%.6f",vrpod::spacing(gap));return WritePrivateProfileStringA(name,"StackSpacing",value,path)!=0;}
 GetPrivateProfileStringA(name,"StackSpacing","",value,sizeof(value),path);float parsed=0;if(sscanf_s(value,"%f",&parsed)!=1||!std::isfinite(parsed))return false;gap=vrpod::spacing(parsed);return true;
}
inline std::atomic<unsigned> wellCapture{~0u};inline std::atomic<int> spacingRequest{0};inline vrgrip::Placement wellPlacement;inline Pose wellHandLocal{},originalWell{};
inline void cancelWellPlacement(){if(wellPlacement.active)for(auto& e:entries)if((uintptr_t)e.weapon==wellPlacement.weapon&&e.handle==wellPlacement.handle){e.rocketLocal=originalWell;erase(e.ghost);clearStack(e.ghostStack);}wellPlacement.cancel();wellCapture=~0u;}

inline bool rocketProfile(const Target& t,Pose& pose,bool save,const char* suffix=""){
 char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,92);if(!slash)return false;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-reload-positions.ini");
 if(profileOverride[0])strcpy_s(path,profileOverride);const char* name=(const char*)(uintptr_t)word((void*)(uintptr_t)word(t.weapon,0x148),0);if(!memory(name,32))return false;
 char section[160];sprintf_s(section,"%s%s",name,suffix);bool complete=true;Pose result=pose;for(unsigned i=0;i<12;++i){char key[32],value[64];sprintf_s(key,"Pose%u",i);if(save){sprintf_s(value,"%.8f",((float*)&pose)[i]);if(!WritePrivateProfileStringA(section,key,value,path))complete=false;}else{GetPrivateProfileStringA(section,key,"",value,64,path);float v=0;if(sscanf_s(value,"%f",&v)!=1||!std::isfinite(v))complete=false;((float*)&result)[i]=v;}}
 if(!save&&complete&&valid(result.b)&&finite(result.p)&&length(result.p)<3)pose=result;else if(!save)return false;return complete;
}
inline std::atomic<unsigned> magazineCapture{~0u};inline vrgrip::Placement magazinePlacement;inline Object magazinePreview;inline Stack previewStack{};inline DWORD previewTry=0;
inline void magazineFingers(Visual& v,const Target& t,bool preview=false){v.magazinePose=preview||v.grip;if(!v.magazinePose)return;float dimensions[3]={fabsf(t.magazineExtent.x),fabsf(t.magazineExtent.y),fabsf(t.magazineExtent.z)};std::sort(dimensions,dimensions+3);float width=v.rocket?.06f:dimensions[1];float curl=(std::max)(.25f,(std::min)(.9f,1.f-width*4.f));v.fingerCurl[0]=.65f;for(unsigned finger=1;finger<5;++finger)v.fingerCurl[finger]=(std::min)(1.f,curl+(int(finger)-2)*.025f);}
inline void cancelMagazinePlacement(){previewTry=0;clearStack(previewStack);erase(magazinePreview);magazinePlacement.cancel();magazineCapture=~0u;}
inline void retireVisuals(Entry& e){if(wellPlacement.active&&wellPlacement.weapon==(uintptr_t)e.weapon&&wellPlacement.handle==e.handle)cancelWellPlacement();clearStack(e.heldStack);clearStack(e.ghostStack);if(e.retainedRounds>0&&memory(e.weapon,0x210)&&word(e.weapon,0x6c)==e.handle){memcpy((char*)e.weapon+0x20c,&e.retainedRounds,4);e.retainedRounds=0;e.state.stage=vrreload::Stage::Locked;}erase(e.held);erase(e.ghost);erase(e.loaded);e.loadedTry=0;alpha(e.source,1);e.state.held=vrreload::Held::None;e.state.extracting=false;e.pickupHint={};e.seating={};e.last=0;}
inline void suspend(const Target& t){cancelWellPlacement();cancelMagazinePlacement();RFGRVRWeaponInput::reloadControlled=false;AcquireSRWLockExclusive(&visualLock);visual={};ReleaseSRWLockExclusive(&visualLock);for(auto& e:entries)if(e.last||e.loaded.ptr||e.held.ptr||e.ghost.ptr)retireVisuals(e);}
inline void update(const Target& t,bool allowed){
 RFGRVRWeaponInput::manualReloadEnabled=enabled&&!vrsettings::get().value[vrsettings::Reload];
 if(!eligible(t)||!allowed){suspend(t);return;}RFGRVRWeaponInput::reloadControlled=true;RFGRVRWeaponInput::reloadLease=GetTickCount();
 // Inactive weapon props must not leak hidden state or retain a held object.
 for(auto& old:entries)if(old.weapon&&(old.weapon!=t.weapon||old.handle!=t.handle||old.owner!=t.playerHandle)&&(old.last||old.loaded.ptr||old.held.ptr||old.ghost.ptr))retireVisuals(old);
 Entry* e=find(t);if(!e){e=&entries[next++%32];erase(e->held);erase(e->ghost);erase(e->loaded);alpha(e->source,1);clearStack(e->heldStack);clearStack(e->ghostStack);*e={};e->weapon=t.weapon;e->handle=t.handle;e->owner=t.playerHandle;}
 e->last=GetTickCount();e->source={t.magazine,t.magazineHandle};e->info=(void*)(uintptr_t)word(t.magazine,0xa4);bool isRocket=rocket(t);if(isRocket){if(!e->rocketReady){rocketProfile(t,e->rocketLocal,false);e->rocketReady=true;}if(itemLookup){void* info=(void*)(uintptr_t)word(t.weapon,0x148);const char* name=(const char*)(uintptr_t)word(info,0);e->info=itemLookup(memory(name,19)&&!strncmp(name,"thermobaric_rockets",18)?"thermobaric_rocket_projectile":memory(name,11)&&!strcmp(name,"missilepod")?"rpg_projectile":"rpg_clip");}}if(t.rocketMountValid)e->rocketLocal=t.rocketMount;if(!memory(e->info,0x98))return;bool isPod=pod(t);if(isPod&&!e->spacingReady){spacingProfile(t,e->podSpacing,false);e->spacingReady=true;}
 RFGRGamepad pad{};auto* source=RFGRVRWeaponInput::source.load();bool input=false;if(source)for(int i=0;i<3;++i){LONG seq=source->inputSequence;if(seq&1)continue;MemoryBarrier();pad=source->gamepad;bool active=source->gamepadActive!=0;MemoryBarrier();if(seq==source->inputSequence){input=active;break;}}if(!input){suspend(t);return;}
 int off=1-int(t.physicalHand);if(off<0||off>1)return;vrreload::Input in;in.reload=(pad.buttons&0x4000)&&!(pad.buttons&0x200);in.squeeze=float(pad.leftTrigger)/255.f;in.rocket=isRocket;in.hand=t.hand[off];in.magazine=isRocket?vrgrip::worldPose(t.motion.pose,e->rocketLocal):t.magazinePose;in.scale=t.motion.scale;in.rounds=(int)word(t.weapon,0x20c);in.reserve=(int)word(t.weapon,0x210);in.capacity=capacity?capacity(t.weapon):0;const char* reloadName=(const char*)(uintptr_t)word((void*)(uintptr_t)word(t.weapon,0x148),0);in.autoEjectEmpty=memory(reloadName,16)&&(!strncmp(reloadName,"grinder",7)||!strncmp(reloadName,"disc",4));in.freshLocal=isRocket?vrreload::gripForBounds({-.03f,-.03f,-.22f},{.03f,.03f,.22f}):t.magazineGrip;in.magazineCenter=isRocket?V{}:t.magazineCenter;
 if(!e->magGripReady){e->magGrip=in.freshLocal;rocketProfile(t,e->magGrip,false,".MagazineGrip");e->magGripReady=true;}in.freshLocal=e->magGrip;
 if(magazineCapture.load()==t.handle&&wellPlacement.active)cancelWellPlacement();
 unsigned wellRequest=wellCapture.exchange(~0u);if(wellRequest==t.handle&&isRocket){cancelMagazinePlacement();cancelWellPlacement();erase(e->held);clearStack(e->heldStack);e->state.held=vrreload::Held::None;e->seating.active=false;e->stackTry=0;originalWell=e->rocketLocal;wellHandLocal=vrgrip::relativePose(in.hand,in.magazine);wellPlacement.begin((uintptr_t)t.weapon,t.handle,in.magazine);vrstatus::notify("Move reload ghost with off hand; release then squeeze its GRIP to save");}
 if(wellPlacement.active){if(wellPlacement.weapon!=(uintptr_t)t.weapon||wellPlacement.handle!=t.handle)cancelWellPlacement();else{
  Pose ghost=vrgrip::worldPose(in.hand,wellHandLocal);e->rocketLocal=vrgrip::relativePose(t.motion.pose,ghost);in.magazine=ghost;
  if(!validObject(e->ghost))e->ghost=spawn(e->info,ghost,false);move(e->ghost,ghost);alpha(e->ghost,.6f);
  unsigned count=isPod?unsigned((std::clamp)(in.capacity,1,int(vrpod::Maximum))):1;bool retry=!e->stackTry||DWORD(GetTickCount()-e->stackTry)>500;updateStack(e->ghostStack,count,e->info,ghost,e->podSpacing,in.scale,.6f,retry);if(retry)e->stackTry=GetTickCount();
  if(wellPlacement.update((uintptr_t)t.weapon,t.handle,t.squeeze[off])){bool saved=rocketProfile(t,e->rocketLocal,true);if(saved){wellPlacement.cancel();vrstatus::notify("Reload ghost position AND rotation SAVED");}else{cancelWellPlacement();vrstatus::notify("Reload ghost save failed; old placement restored");}}
  AcquireSRWLockExclusive(&visualLock);visual={};visual.ghost=e->ghost;visual.weapon=t.handle;visual.tick=GetTickCount();visual.rocket=true;visual.wellLocal=e->rocketLocal;visual.ghostStack=e->ghostStack;visual.ghostCount=count;visual.stackSpacing=e->podSpacing;visual.stackScale=in.scale;ReleaseSRWLockExclusive(&visualLock);return;
 }}
 unsigned request=magazineCapture.exchange(~0u);if(request==t.handle){if(isPod){erase(e->held);erase(e->ghost);clearStack(e->heldStack);clearStack(e->ghostStack);e->state.held=vrreload::Held::None;e->seating.active=false;}cancelWellPlacement();cancelMagazinePlacement();Pose fixed{t.motion.body.b,add(t.motion.body.p,world(t.motion.body.b,{0,1.3f*in.scale,.5f*in.scale}))};magazinePreview=spawn(e->info,fixed,false);if(validObject(magazinePreview)){magazinePlacement.begin((uintptr_t)t.weapon,t.handle,fixed);vrstatus::notify("Magazine placement: release off-hand grip, place hand, squeeze to SAVE");}else vrstatus::notify("Magazine preview could not be created");}
 int spacingDelta=spacingRequest.exchange(0);if(isPod&&magazinePlacement.active&&spacingDelta){e->podSpacing=vrpod::spacing(e->podSpacing+float(spacingDelta)*.005f);bool saved=spacingProfile(t,e->podSpacing,true);char message[120];sprintf_s(message,"Rocket stack spacing %.1f cm%s",e->podSpacing*100,saved?" (saved)":" (save failed)");vrstatus::notify(message);}
 if(magazinePlacement.active){if(magazinePlacement.weapon!=(uintptr_t)t.weapon||magazinePlacement.handle!=t.handle){cancelMagazinePlacement();}else{Pose local=vrgrip::relativePose(in.hand,magazinePlacement.fixed);move(magazinePreview,magazinePlacement.fixed);unsigned previewCount=isPod?unsigned((std::clamp)(in.capacity,1,int(vrpod::Maximum))):1;bool previewRetry=!previewTry||DWORD(GetTickCount()-previewTry)>500;updateStack(previewStack,previewCount,e->info,magazinePlacement.fixed,e->podSpacing,in.scale,1,previewRetry);if(previewRetry)previewTry=GetTickCount();if(magazinePlacement.update((uintptr_t)t.weapon,t.handle,t.squeeze[off])){e->magGrip=local;if(e->state.held!=vrreload::Held::None)e->state.handLocal=local;bool saved=rocketProfile(t,e->magGrip,true,".MagazineGrip");cancelMagazinePlacement();vrstatus::notify(saved?"Magazine held position AND orientation SAVED":"Magazine grip save failed");}else{AcquireSRWLockExclusive(&visualLock);visual={magazinePreview,{},e->source,local,false,e->state.stage==vrreload::Stage::Removed,false,t.handle,GetTickCount(),isRocket,e->rocketLocal};visual.heldStack=previewStack;visual.heldCount=previewCount;visual.stackSpacing=e->podSpacing;visual.stackScale=in.scale;magazineFingers(visual,t,true);ReleaseSRWLockExclusive(&visualLock);return;}}}
 V localHand=mul(local(t.motion.body.b,sub(in.hand.p,t.motion.body.p)),1/in.scale);in.hip=vrreload::nearHip(localHand);
 if(isRocket&&captureRocket.load()&&e->state.held==vrreload::Held::Fresh){bool pressed=t.squeeze[off]>.65f;if(pressed&&!e->captureGrip){e->rocketLocal=vrgrip::relativePose(t.motion.pose,vrgrip::worldPose(in.hand,e->state.handLocal));bool saved=rocketProfile(t,e->rocketLocal,true);captureRocket=false;vrstatus::notify(saved?"Rocket insertion position AND orientation SAVED":"Rocket insertion position could not save");}e->captureGrip=pressed;}else e->captureGrip=t.squeeze[off]>.65f;
 if(e->seating.active){if(e->seating.complete(GetTickCount())){erase(e->held);e->seating.active=false;}else in.hip=false;}
 if(e->pickupHint.update(e->state.canFetch(in)&&!e->seating.active&&!magazinePlacement.active,in.hip)){static RFGRHapticWriter hint(RFGR_MAG_HINT_MAP);hint.publish(12000,0);}
 if(isPod&&e->state.held==vrreload::Held::Fresh)e->heldRounds=vrpod::quantity(in.capacity,in.rounds,in.reserve);
 auto previousStage=e->state.stage;unsigned event=e->state.update(in);if(isRocket&&previousStage==vrreload::Stage::Locked&&e->state.stage!=vrreload::Stage::Locked)e->retainedRounds=in.rounds>0?in.rounds:0;
 if(event&vrreload::Eject){unsigned zero=0;memcpy((char*)t.weapon+0x20c,&zero,4);sound(t,0);if(e->state.held==vrreload::Held::Spent)e->held=spawn(e->info,e->state.heldPose,false);vrstatus::notify("Magazine removed: grab a fresh magazine at either hip");}
 if(event&vrreload::Drop){erase(e->held);clearStack(e->heldStack);for(unsigned i=0;i<(isPod?e->heldRounds:1u);++i)drop(*e,vrpod::at(e->state.heldPose,i,e->podSpacing,in.scale));}
 if(event&vrreload::Fetch){e->heldRounds=isPod?vrpod::quantity(in.capacity,in.rounds,in.reserve):1;e->stackTry=0;e->ghostTry=0;e->held=spawn(e->info,e->state.heldPose,false);if(!validObject(e->held)){e->state.held=vrreload::Held::None;vrstatus::notify("Magazine could not be created");}else vrstatus::notify("Insert magazine into the weapon's ghost guide");}
 if(event&vrreload::Insert){e->seating.begin(in.magazine,e->state.heldPose,GetTickCount());erase(e->ghost);sound(t,1);if(isRocket){int rounds=(int)word(t.weapon,0x20c),reserve=(int)word(t.weapon,0x210);unsigned amount=vrpod::insert(isPod?e->heldRounds:1,in.capacity,rounds,reserve);if(amount){rounds+=int(amount);reserve-=int(amount);memcpy((char*)t.weapon+0x20c,&rounds,4);memcpy((char*)t.weapon+0x210,&reserve,4);sound(t,2);vrstatus::notify(isPod?"Rocket stack loaded: ready to fire":"One rocket loaded: ready to fire");}}else vrstatus::notify("Magazine seated: press reload to chamber");}
 if(!isRocket&&(event&vrreload::Chamber)){if(originalRefill&&capacity&&(in.reserve>0||e->retainedRounds>0)){if(isRocket)memcpy((char*)t.weapon+0x20c,&e->retainedRounds,4);originalRefill(t.weapon);e->retainedRounds=0;sound(t,2);vrstatus::notify("Weapon ready");}else{e->state.stage=vrreload::Stage::Removed;vrstatus::notify("No reserve ammunition");}}
 if(event){char line[140];sprintf_s(line,"Manual reload: weapon=%08x event=%u stage=%u mag=%u reserve=%u",t.handle,event,unsigned(e->state.stage),word(t.weapon,0x20c),word(t.weapon,0x210));log(line);}
 // Native firing removes the thermobaric clip child. Recreate only its visual,
 // keeping ammo accounting and the insertion prop independent.
 bool loadedVisible=t.rocketMountValid&&word(t.weapon,0x20c)>0&&!e->seating.active&&!validObject(e->source);
 if(loadedVisible){if(!validObject(e->loaded)&&(!e->loadedTry||DWORD(GetTickCount()-e->loadedTry)>1000)){e->loadedTry=GetTickCount();e->loaded=spawn(e->info,vrgrip::worldPose(t.motion.pose,e->rocketLocal),false);}move(e->loaded,vrgrip::worldPose(t.motion.pose,e->rocketLocal));}else erase(e->loaded);
 unsigned ghostCount=isPod?vrpod::quantity(in.capacity,(int)word(t.weapon,0x20c),(int)word(t.weapon,0x210)):1;
 bool removed=e->state.stage==vrreload::Stage::Removed||e->seating.active;alpha(e->source,removed?0.f:1.f);
 if(e->state.ghost()){if(!validObject(e->ghost)&&(!e->ghostTry||DWORD(GetTickCount()-e->ghostTry)>500)){e->ghostTry=GetTickCount();e->ghost=spawn(e->info,in.magazine,false);}alpha(e->ghost,.60f);move(e->ghost,in.magazine);}else erase(e->ghost);
 if(e->seating.active)move(e->held,e->seating.pose(in.magazine,GetTickCount()));else if(e->state.held!=vrreload::Held::None)move(e->held,e->state.heldPose);
 unsigned heldCount=validObject(e->held)&&(e->state.held!=vrreload::Held::None||e->seating.active)?(isPod?e->heldRounds:1):0;bool stackRetry=!e->stackTry||DWORD(GetTickCount()-e->stackTry)>500;
 Pose heldPose=e->seating.active?e->seating.pose(in.magazine,GetTickCount()):e->state.heldPose;
 updateStack(e->heldStack,heldCount,e->info,heldPose,e->podSpacing,in.scale,1,stackRetry);
 updateStack(e->ghostStack,validObject(e->ghost)?ghostCount:0,e->info,in.magazine,e->podSpacing,in.scale,.6f,stackRetry);if(stackRetry)e->stackTry=GetTickCount();
 // A staged magazine cannot fire before the chamber/bolt button press.
 if(e->state.stage!=vrreload::Stage::Locked){unsigned zero=0;memcpy((char*)t.weapon+0x20c,&zero,4);}
 AcquireSRWLockExclusive(&visualLock);visual={e->held,e->ghost,e->source,e->state.handLocal,e->state.held!=vrreload::Held::None||e->state.extracting,removed,e->state.empty((int)word(t.weapon,0x20c)),t.handle,GetTickCount(),isRocket,e->rocketLocal};visual.seating=e->seating;visual.loaded=e->loaded;visual.heldStack=e->heldStack;visual.ghostStack=e->ghostStack;visual.heldCount=heldCount;visual.ghostCount=validObject(e->ghost)?ghostCount:0;visual.stackSpacing=e->podSpacing;visual.stackScale=in.scale;magazineFingers(visual,t);ReleaseSRWLockExclusive(&visualLock);
 for(unsigned i=0;i<24;++i)if(dropped[i].ptr&&DWORD(GetTickCount()-droppedTick[i])>20000)erase(dropped[i]);
}
inline bool readVisual(unsigned weapon,Visual& out){AcquireSRWLockShared(&visualLock);out=visual;ReleaseSRWLockShared(&visualLock);return out.weapon==weapon&&DWORD(GetTickCount()-out.tick)<200;}
inline bool install(){const unsigned char startSig[]={0x8b,0x44,0x24,0x0c,0x83,0xec,0x08,0x56,0x57},refillSig[]={0x56,0x8b,0xf1,0xe8};if(memcmp(base+0x69d970,startSig,sizeof(startSig))||memcmp(base+0x7e2850,refillSig,sizeof(refillSig)))return false;
 if(MH_CreateHook(base+0x69d970,(void*)onStart,(void**)&originalStart)!=MH_OK)return false;if(MH_CreateHook(base+0x7e2850,(void*)onRefill,(void**)&originalRefill)!=MH_OK){MH_RemoveHook(base+0x69d970);return false;}
 itemLookup=(ItemLookup)(base+0x618d30);descriptor=(Descriptor)(base+0x63bd80);descriptorFree=(DescriptorFree)(base+0x521950);create=(RegistryCreate)(base+0x53e6b0);destroy=(RegistryDelete)(base+0x51d070);manager=(void*)(uintptr_t)word(base,0x2c6654c);capacity=(Capacity)(base+0x7dcee0);
 if(MH_EnableHook(base+0x69d970)!=MH_OK||MH_EnableHook(base+0x7e2850)!=MH_OK){MH_DisableHook(base+0x69d970);MH_DisableHook(base+0x7e2850);MH_RemoveHook(base+0x69d970);MH_RemoveHook(base+0x7e2850);return false;}enabled=true;RFGRVRWeaponInput::manualReloadEnabled=true;log("Manual magazine reload installed; native player auto reload blocked only for magazine weapons.");return true;}
}






