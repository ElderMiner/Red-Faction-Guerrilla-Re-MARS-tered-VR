#pragma once
#include <atomic>
namespace vrvisual {
// Artistic visual changes only. VR projection/tracking and gameplay remain on.
inline std::atomic<bool> vanilla{false};
inline bool enhanced(){return !vanilla.load(std::memory_order_acquire);}
}
