// RFGR-VR v4.8: one complete D3D11 immediate-context frame survey.
// NO scene replay, camera edits, or render-state mutation. One frame only.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include "com_method_count.h"
#include "main_menu_capture.h"
#include <dxgi.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <atomic>
#include <algorithm>
#include <vector>
#include <cmath>
#include <intrin.h>
#include "vr_eye_resources.h"
#include "vr_eye_pipeline.h"
#include "vr_pixel_probe.h"
#include <memory>
#include "apc_render_targets.h"
#include "vr_corona_depth.h"
extern "C" unsigned RFGRVR_HeadCam_HeadSamples();
extern "C" bool RFGRVR_HeadCam_Recent();
extern "C" bool RFGRVR_GPUCapture_Export();
extern "C" void RFGRVR_Survey_Capture(bool);
static DWORD WINAPI ExportSurvey(void*){RFGRVR_GPUCapture_Export();return 0;}
namespace {
using DrawFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT);
using IndexedFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT,INT);
using InstFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT,UINT,UINT);
using IndexedInstFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT,UINT,INT,UINT);
using AutoFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*);
using IndirectFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11Buffer*,UINT);
using ExecuteFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11CommandList*,BOOL);
using DispatchFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT,UINT);
using OMFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,ID3D11RenderTargetView*const*,ID3D11DepthStencilView*);
using ClearRTFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11RenderTargetView*,const FLOAT[4]);
using ClearDSFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11DepthStencilView*,UINT8,FLOAT,UINT8);
using CBFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT,ID3D11Buffer*const*);
using ShaderFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11VertexShader*,ID3D11ClassInstance*const*,UINT);
using PSShaderFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11PixelShader*,ID3D11ClassInstance*const*,UINT);
using UpdateFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11Resource*,UINT,const D3D11_BOX*,const void*,UINT,UINT);
using MapFn=HRESULT(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11Resource*,UINT,D3D11_MAP,UINT,D3D11_MAPPED_SUBRESOURCE*);
using UnmapFn=void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11Resource*,UINT);
static AutoFn oldAuto=nullptr;static IndirectFn oldIndexedIndirect=nullptr,oldInstIndirect=nullptr,oldDispatchIndirect=nullptr;static ExecuteFn oldExecute=nullptr;static DispatchFn oldDispatch=nullptr;
static DrawFn oldDraw=nullptr; static IndexedFn oldIndexed=nullptr;
static InstFn oldInst=nullptr; static IndexedInstFn oldIndexedInst=nullptr;
static OMFn oldOM=nullptr; static ClearRTFn oldClearRT=nullptr; static ClearDSFn oldClearDS=nullptr;
static CBFn oldVS=nullptr,oldPS=nullptr; static ShaderFn oldVSShader=nullptr; static PSShaderFn oldPSShader=nullptr;
static UpdateFn oldUpdate=nullptr; static MapFn oldMap=nullptr; static UnmapFn oldUnmap=nullptr;
static ID3D11DeviceContext* tracked=nullptr;
static RFGRVREyeResources eyeResources;
static std::unique_ptr<RFGRVREyePipeline> eyePipeline;
static volatile LONG state=0; // 0 idle, 1 armed, 2 recording, 3 completed, 4 export in progress, 5 exported
static bool CaptureRecording(){return ReadAcquire(&state)==2;}
static volatile LONG installed=0,installErrors=0, overflow=0, writesDropped=0;
static volatile LONG used=0, payloadUsed=0, sequence=0;
static const LONG CAPACITY=360000, PAYLOAD_CAP=8*1024*1024;
// One 360K-event frame covers well beyond observed ~1.6K geometry submissions and ~10K bindings.
struct Event { unsigned seq,kind,count,aux,format,width,height,sample; uintptr_t ptr,ptr2,site; unsigned payloadOffset,payloadSize; };
static Event* events=nullptr;
static unsigned char* payload=nullptr;
static volatile LONG draws=0,renderTargets=0,constantBindings=0,resourceWrites=0,clears=0,shaderBindings=0;
static DWORD capturePid=0, captureTick=0;
static thread_local unsigned long long nativeDrawCount=0;
static uintptr_t CodeSite(){
 // Call arguments are evaluated before Record can reject an inactive survey.
 // Avoid thousands of stack walks per normal frame after the one-frame export.
 if(!CaptureRecording())return 0;
 // Search a bounded caller chain for the game module, not a fixed stack slot.
 // Wrapper and trampoline frames previously produced KERNEL32 addresses.
 struct GameRange {uintptr_t lo=0,hi=0;};
 static GameRange range=[](){GameRange r{};HMODULE h=GetModuleHandleA("rfg.exe");
  if(!h)return r;auto* dos=reinterpret_cast<const IMAGE_DOS_HEADER*>(h);
  if(dos->e_magic!=IMAGE_DOS_SIGNATURE)return r;
  auto* nt=reinterpret_cast<const IMAGE_NT_HEADERS*>(reinterpret_cast<const unsigned char*>(h)+dos->e_lfanew);
  if(nt->Signature!=IMAGE_NT_SIGNATURE)return r;
  r.lo=reinterpret_cast<uintptr_t>(h);r.hi=r.lo+nt->OptionalHeader.SizeOfImage;return r;
 }();
 void* frames[12]{};USHORT n=RtlCaptureStackBackTrace(1,12,frames,nullptr);
 for(USHORT i=0;i<n;i++){uintptr_t p=reinterpret_cast<uintptr_t>(frames[i]);if(p>=range.lo&&p<range.hi)return p;}
 // Optimized native UI callers omit frame pointers. During the single-frame
 // survey only, accept bounded stack candidates whose preceding bytes encode
 // an x86 CALL. These are leads, not a reliable ordered unwind.
 auto* stack=(uintptr_t*)_AddressOfReturnAddress();MEMORY_BASIC_INFORMATION region{};
 if(VirtualQuery(stack,&region,sizeof(region))&&region.State==MEM_COMMIT&&!(region.Protect&(PAGE_NOACCESS|PAGE_GUARD))){
  size_t available=((uintptr_t)region.BaseAddress+region.RegionSize-(uintptr_t)stack)/sizeof(uintptr_t);
  for(size_t i=0;i<(std::min<size_t>)(available,128);++i){uintptr_t candidate=stack[i];if(candidate<range.lo+8||candidate>=range.hi)continue;auto* pc=(unsigned char*)candidate;
   if(pc[-5]==0xe8||(pc[-2]==0xff&&(pc[-1]&0x38)==0x10))return candidate;
  }
 }
 return 0; // no validated game-call candidate
}
static void ResourceInfo(ID3D11Resource* resource,Event& e){
 if(!resource)return;
 D3D11_RESOURCE_DIMENSION dim=D3D11_RESOURCE_DIMENSION_UNKNOWN;
 resource->GetType(&dim);
 if(dim==D3D11_RESOURCE_DIMENSION_TEXTURE2D){
  ID3D11Texture2D* t=nullptr;
  if(SUCCEEDED(resource->QueryInterface(__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(&t))) && t){
   D3D11_TEXTURE2D_DESC d{};t->GetDesc(&d);e.width=d.Width;e.height=d.Height;e.format=d.Format;e.sample=d.SampleDesc.Count;t->Release();
  }
 }else if(dim==D3D11_RESOURCE_DIMENSION_BUFFER){
  ID3D11Buffer* b=nullptr;
  if(SUCCEEDED(resource->QueryInterface(__uuidof(ID3D11Buffer),reinterpret_cast<void**>(&b))) && b){D3D11_BUFFER_DESC d{};b->GetDesc(&d);e.width=d.ByteWidth;e.format=d.BindFlags;b->Release();}
 }
}
static void ViewInfo(ID3D11View* v,Event& e){if(!v)return;ID3D11Resource* r=nullptr;v->GetResource(&r);if(r){ResourceInfo(r,e);r->Release();}}
static Event* Record(unsigned kind,unsigned count,uintptr_t a,uintptr_t b,uintptr_t site){
 if(!CaptureRecording())return nullptr;
 LONG idx=InterlockedIncrement(&used)-1;
 if(idx<0||idx>=CAPACITY){InterlockedIncrement(&overflow);return nullptr;}
 Event& e=events[idx];e={};e.seq=static_cast<unsigned>(InterlockedIncrement(&sequence));e.kind=kind;e.count=count;e.ptr=a;e.ptr2=b;e.site=site;
 return &e;
}
static void Payload(Event* e,const void* data,unsigned n){
 if(!e||!data||!n)return;
 n=(std::min)(n,4096u);
 LONG offset=InterlockedExchangeAdd(&payloadUsed,static_cast<LONG>(n));
 if(offset<0||offset>PAYLOAD_CAP-static_cast<LONG>(n)){InterlockedIncrement(&writesDropped);return;}
 // Bytes are sourced from CPU-visible UpdateSubresource/Map writes, never from GPU readback.
 memcpy(payload+offset,data,n); e->payloadOffset=static_cast<unsigned>(offset);e->payloadSize=n;
}
static void STDMETHODCALLTYPE HDraw(ID3D11DeviceContext*c,UINT count,UINT start){++nativeDrawCount;if(CaptureRecording())InterlockedIncrement(&draws);Record(1,count,start,0,CodeSite());RFGRAPCTargets::geometry(c,count);oldDraw(c,count,start);RFGRVRPixelProbe::record(c,1,count,0,start);}
static void STDMETHODCALLTYPE HIndexed(ID3D11DeviceContext*c,UINT count,UINT start,INT base){++nativeDrawCount;if(CaptureRecording())InterlockedIncrement(&draws);Event* e=Record(2,count,start,static_cast<uintptr_t>(base),CodeSite());if(e)e->aux=static_cast<unsigned>(base);RFGRAPCTargets::geometry(c,count);if(vrcoronadepth::drawing){vrcoronadepth::DepthGuard glow(c);oldIndexed(c,count,start,base);}else oldIndexed(c,count,start,base);RFGRVRPixelProbe::record(c,2,count,0,start,unsigned(base));}
static void STDMETHODCALLTYPE HInst(ID3D11DeviceContext*c,UINT count,UINT inst,UINT start,UINT first){++nativeDrawCount;if(CaptureRecording())InterlockedIncrement(&draws);Event*e=Record(3,count,inst,start,CodeSite());if(e)e->aux=first;RFGRAPCTargets::geometry(c,uint64_t(count)*inst);oldInst(c,count,inst,start,first);RFGRVRPixelProbe::record(c,3,count,inst,start,first);}
static void STDMETHODCALLTYPE HIndexedInst(ID3D11DeviceContext*c,UINT count,UINT inst,UINT start,INT base,UINT first){++nativeDrawCount;if(CaptureRecording())InterlockedIncrement(&draws);Event*e=Record(4,count,inst,start,CodeSite());if(e)e->aux=first;RFGRAPCTargets::geometry(c,uint64_t(count)*inst);oldIndexedInst(c,count,inst,start,base,first);RFGRVRPixelProbe::record(c,4,count,inst,start,unsigned(base));}
static void STDMETHODCALLTYPE HAuto(ID3D11DeviceContext* c){++nativeDrawCount;RFGRAPCTargets::geometry(c,64);oldAuto(c);RFGRVRPixelProbe::record(c,38,0);}
static void STDMETHODCALLTYPE HIndexedIndirect(ID3D11DeviceContext* c,ID3D11Buffer* b,UINT offset){++nativeDrawCount;RFGRAPCTargets::geometry(c,64);oldIndexedIndirect(c,b,offset);RFGRVRPixelProbe::record(c,39,offset);}
static void STDMETHODCALLTYPE HInstIndirect(ID3D11DeviceContext* c,ID3D11Buffer* b,UINT offset){++nativeDrawCount;RFGRAPCTargets::geometry(c,64);oldInstIndirect(c,b,offset);RFGRVRPixelProbe::record(c,40,offset);}
static void STDMETHODCALLTYPE HDispatch(ID3D11DeviceContext* c,UINT x,UINT y,UINT z){oldDispatch(c,x,y,z);RFGRVRPixelProbe::record(c,41,x,y,z);}
static void STDMETHODCALLTYPE HDispatchIndirect(ID3D11DeviceContext* c,ID3D11Buffer* b,UINT offset){oldDispatchIndirect(c,b,offset);RFGRVRPixelProbe::record(c,42,offset);}
static void STDMETHODCALLTYPE HExecute(ID3D11DeviceContext* c,ID3D11CommandList* list,BOOL restore){RFGRVRPixelProbe::note(58,c,list,restore);oldExecute(c,list,restore);RFGRVRPixelProbe::record(c,58,restore,unsigned((uintptr_t)list));}
static void STDMETHODCALLTYPE HOM(ID3D11DeviceContext*c,UINT n,ID3D11RenderTargetView*const* views,ID3D11DepthStencilView* depth){
 if(c==tracked){for(UINT i=0;i<n&&i<8;++i)eyeResources.observe(views?views[i]:nullptr);eyeResources.observe(depth);}
 if(CaptureRecording())InterlockedIncrement(&renderTargets);
 if(!CaptureRecording()){oldOM(c,n,views,depth);return;}
 // Separate events for each RTV and DSV, including dimensions/format.
 for(UINT i=0;i<n && i<8;i++){auto*v=views?views[i]:nullptr;Event*e=Record(10,i,reinterpret_cast<uintptr_t>(v),0,CodeSite());if(e)ViewInfo(v,*e);}
 Event* e=Record(11,n,reinterpret_cast<uintptr_t>(depth),0,CodeSite());if(e)ViewInfo(depth,*e);
 oldOM(c,n,views,depth);
}
static void STDMETHODCALLTYPE HClearRT(ID3D11DeviceContext*c,ID3D11RenderTargetView*v,const FLOAT rgba[4]){if(c==tracked)eyeResources.observe(v);if(CaptureRecording())InterlockedIncrement(&clears);Event*e=Record(12,0,reinterpret_cast<uintptr_t>(v),0,CodeSite());if(e)ViewInfo(v,*e);oldClearRT(c,v,rgba);RFGRVRPixelProbe::record(c,12,0,0,0,0,v);}
static void STDMETHODCALLTYPE HClearDS(ID3D11DeviceContext*c,ID3D11DepthStencilView*v,UINT f,FLOAT d,UINT8 stencil){if(c==tracked)eyeResources.observe(v);if(CaptureRecording())InterlockedIncrement(&clears);Event*e=Record(13,f,reinterpret_cast<uintptr_t>(v),0,CodeSite());if(e)ViewInfo(v,*e);oldClearDS(c,v,f,d,stencil);vrcoronadepth::recordClear(v,f,d);RFGRVRPixelProbe::record(c,13,f,stencil);}
static void Bind(unsigned kind,UINT start,UINT n,ID3D11Buffer*const* bs){
 if(!CaptureRecording()&&!eyeResources.observingBuffers())return;
 for(UINT i=0;i<n&&i<14;++i)eyeResources.observeBuffer(bs?bs[i]:nullptr);
 if(CaptureRecording())InterlockedIncrement(&constantBindings);
 for(UINT i=0;i<n && i<14;++i){ID3D11Buffer*b=bs?bs[i]:nullptr;Event*e=Record(kind,start+i,reinterpret_cast<uintptr_t>(b),0,CodeSite());if(e)ResourceInfo(b,*e);}
}
static void STDMETHODCALLTYPE HVS(ID3D11DeviceContext*c,UINT s,UINT n,ID3D11Buffer*const* bs){Bind(20,s,n,bs);oldVS(c,s,n,bs);}
static void STDMETHODCALLTYPE HPS(ID3D11DeviceContext*c,UINT s,UINT n,ID3D11Buffer*const* bs){Bind(21,s,n,bs);oldPS(c,s,n,bs);}
static void STDMETHODCALLTYPE HVSShader(ID3D11DeviceContext*c,ID3D11VertexShader* s,ID3D11ClassInstance*const* a,UINT n){if(CaptureRecording())InterlockedIncrement(&shaderBindings);Record(22,n,reinterpret_cast<uintptr_t>(s),0,CodeSite());oldVSShader(c,s,a,n);}
static void STDMETHODCALLTYPE HPSShader(ID3D11DeviceContext*c,ID3D11PixelShader* s,ID3D11ClassInstance*const* a,UINT n){if(CaptureRecording())InterlockedIncrement(&shaderBindings);Record(23,n,reinterpret_cast<uintptr_t>(s),0,CodeSite());oldPSShader(c,s,a,n);}
static void STDMETHODCALLTYPE HUpdate(ID3D11DeviceContext*c,ID3D11Resource*r,UINT sub,const D3D11_BOX* box,const void* data,UINT row,UINT depth){
 if(c==tracked)eyeResources.observeBuffer(r);
 if(CaptureRecording())InterlockedIncrement(&resourceWrites);
 Event* e=Record(30,sub,reinterpret_cast<uintptr_t>(r),row,CodeSite());
 if(e){ResourceInfo(r,*e);if(e->height==0 && !box)Payload(e,data,e->width);}
 oldUpdate(c,r,sub,box,data,row,depth);
}
// Dynamic constant buffers are often written via Map/Unmap. Track the CPU-visible write region.
struct PendingMap { ID3D11Resource* r; void* ptr; UINT size; DWORD thread; };
static PendingMap pending[32]{}; static SRWLOCK pendingLock=SRWLOCK_INIT;
static HRESULT STDMETHODCALLTYPE HMap(ID3D11DeviceContext*c,ID3D11Resource*r,UINT sub,D3D11_MAP typ,UINT flags,D3D11_MAPPED_SUBRESOURCE*out){
 if(c==tracked&&typ!=D3D11_MAP_READ)eyeResources.observeBuffer(r);
 HRESULT h=oldMap(c,r,sub,typ,flags,out);
 if(SUCCEEDED(h)&&out&&out->pData&&sub==0&&CaptureRecording()&& (typ==D3D11_MAP_WRITE_DISCARD||typ==D3D11_MAP_WRITE_NO_OVERWRITE||typ==D3D11_MAP_WRITE)){
  Event temp{};ResourceInfo(r,temp); if(temp.height==0 && temp.width>0){
   AcquireSRWLockExclusive(&pendingLock);
   for(auto& p:pending)if(!p.r){p={r,out->pData,(std::min)(temp.width,4096u),GetCurrentThreadId()};break;}
   ReleaseSRWLockExclusive(&pendingLock);
  }
 }
 return h;
}
static void STDMETHODCALLTYPE HUnmap(ID3D11DeviceContext*c,ID3D11Resource*r,UINT sub){
 PendingMap found{};
 if(CaptureRecording()){
  AcquireSRWLockExclusive(&pendingLock);
  for(auto& p:pending)if(p.r==r && p.thread==GetCurrentThreadId()){found=p;p={};break;}
  ReleaseSRWLockExclusive(&pendingLock);
  if(found.ptr){if(CaptureRecording())InterlockedIncrement(&resourceWrites);Event*e=Record(31,sub,reinterpret_cast<uintptr_t>(r),0,CodeSite());if(e){ResourceInfo(r,*e);Payload(e,found.ptr,found.size);}}
 }
 oldUnmap(c,r,sub);
}
static bool VtableOK(void** t,size_t n){
 if(!t)return false;MEMORY_BASIC_INFORMATION m{};if(!VirtualQuery(t,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 uintptr_t a=reinterpret_cast<uintptr_t>(t),b=reinterpret_cast<uintptr_t>(m.BaseAddress);
 return a>=b && n*sizeof(void*)<=m.RegionSize && a-b<=m.RegionSize-n*sizeof(void*);
}
static bool ReportRoot(char* p,size_t len){DWORD n=GetModuleFileNameA(nullptr,p,static_cast<DWORD>(len));if(!n||n>=len)return false;char* slash=strrchr(p,92);if(!slash)return false;slash[1]=0;if(strlen(p)+32>=len)return false;strcat_s(p,len,"vr-research\\output");return true;}
static const char* Kind(unsigned k){switch(k){case 1:return "Draw";case 2:return "DrawIndexed";case 3:return "DrawInstanced";case 4:return "DrawIndexedInstanced";case 10:return "RTV";case 11:return "DSV";case 12:return "ClearRTV";case 13:return "ClearDSV";case 20:return "VSConstant";case 21:return "PSConstant";case 22:return "VSShader";case 23:return "PSShader";case 30:return "UpdateSubresource";case 31:return "UnmapWrite";case 40:return "SceneBegin";case 41:return "SceneEnd";case 42:return "SceneBoundRT";default:return "Unknown";}}
}
// v4.9 read-only, bounded post-capture inference. This never calls candidate game functions.
struct PassLead { unsigned begin=0,end=0,draws=0,clears=0,bindings=0; uintptr_t target=0,depth=0; unsigned width=0,height=0; double score=0; };
struct BufferLead { uintptr_t resource=0; unsigned samples=0,affine=0,projection=0,boundVS=0,boundPS=0; double score=0; };
static bool FiniteFloat(float v){return std::isfinite(static_cast<double>(v)) && std::abs(static_cast<double>(v))<1.0e7;}
static bool AffineAt(const float* m){
 for(int i=0;i<16;i++)if(!FiniteFloat(m[i]))return false;
 // row-vector affine matrix. Strong structural check; not proof of view semantics.
 if(std::abs(m[3])>.01 || std::abs(m[7])>.01 || std::abs(m[11])>.01 || std::abs(m[15]-1.0f)>.01)return false;
 for(int r=0;r<3;r++){
  double len=0;for(int c=0;c<3;c++)len+=static_cast<double>(m[r*4+c])*m[r*4+c];
  if(len<.65||len>1.35)return false;
 }
 for(int a=0;a<3;a++)for(int b=a+1;b<3;b++){
  double dot=0;for(int c=0;c<3;c++)dot+=static_cast<double>(m[a*4+c])*m[b*4+c];
  if(std::abs(dot)>.15)return false;
 }
 return true;
}
static bool ProjectionAt(const float* m){
 for(int i=0;i<16;i++)if(!FiniteFloat(m[i]))return false;
 // Generic perspective matrices (row-major or column-major), allow reversed Z.
 if(std::abs(m[0])<.1f||std::abs(m[5])<.1f||std::abs(m[0])>12||std::abs(m[5])>12)return false;
 if(std::abs(m[15])>.03f)return false;
 bool row=std::abs(std::abs(m[11])-1.0f)<.12f;
 bool col=std::abs(std::abs(m[14])-1.0f)<.12f;
 if(!row&&!col)return false;
 return std::abs(m[1])<.12f&&std::abs(m[4])<.12f;
}
static bool AutomaticDig(const char* root,DWORD pid,DWORD tick,const Event* ev,LONG n,const unsigned char* bytes,LONG bytesValid,LONG lostEvents,LONG lostPayload){
 if(!root||!ev||n<=0)return false;
 char path[MAX_PATH]{};
 sprintf_s(path,"%s\\GPU-AutoDig-%lu-%lu.txt",root,pid,tick);
 FILE* f=nullptr;if(fopen_s(&f,path,"wb")||!f)return false;
 fprintf(f,"RFGR-VR v4.9 automatic evidence chain (READ-ONLY)\n");
 fprintf(f,"Capture: %ld events, dropped_events=%ld, dropped_payloads=%ld, CPU_bytes=%ld\n",n,lostEvents,lostPayload,bytesValid);
 fprintf(f,"Claim policy: stage findings are hypotheses. No engine replay, VR stereo, or semantic camera ownership is verified.\n\n");
 // Stage 1: Split by complete OMSetRenderTargets bindings (recorded as one or more RTVs and a DSV).
 std::vector<PassLead> passes;PassLead current{};current.begin=ev[0].seq;
 for(LONG i=0;i<n;i++){
  const Event& e=ev[i];
  if(e.kind==10 && e.count==0){
   if(current.draws||current.clears||current.bindings){current.end=e.seq;passes.push_back(current);}
   current=PassLead{};current.begin=e.seq;current.target=e.ptr;current.width=e.width;current.height=e.height;
  } else if(e.kind==11){current.depth=e.ptr;}
  if(e.kind>=1 && e.kind<=4)current.draws++;
  else if(e.kind==12||e.kind==13)current.clears++;
  else if(e.kind==20||e.kind==21)current.bindings++;
 }
 current.end=ev[n-1].seq;passes.push_back(current);
 for(auto& p:passes){p.score=static_cast<double>(p.draws)+0.01*p.bindings;
  if(p.width>=640 && p.height>=360)p.score*=1.2;
  if(!p.target)p.score*=.5;
 }
 std::sort(passes.begin(),passes.end(),[](const PassLead&a,const PassLead&b){return a.score>b.score;});
 fprintf(f,"STAGE 1 — GPU pass segmentation\nRender-target segments: %zu\n",passes.size());
 for(size_t i=0;i<passes.size()&&i<16;i++){
  const auto&p=passes[i];fprintf(f,"rank=%zu seq=%u..%u draws=%u cb_bindings=%u size=%ux%u rtv=0x%llX dsv=0x%llX score=%.1f\n",i+1,p.begin,p.end,p.draws,p.bindings,p.width,p.height,static_cast<unsigned long long>(p.target),static_cast<unsigned long long>(p.depth),p.score);
 }
 fprintf(f,"Interpretation: these are render-target segments, NOT independently callable world passes.\n\n");
 // Stage 2: Find affine and perspective matrices only in actually captured CPU buffer writes.
 std::vector<BufferLead> buffers;
 auto GetLead=[&buffers](uintptr_t resource)->BufferLead&{
  for(auto& b:buffers)if(b.resource==resource)return b;
  buffers.push_back(BufferLead{});buffers.back().resource=resource;return buffers.back();
 };
 for(LONG i=0;i<n;i++){
  const Event&e=ev[i]; if((e.kind!=30&&e.kind!=31)||!e.ptr||e.payloadSize<64||!bytes)continue;
  if(e.payloadOffset>static_cast<unsigned>(bytesValid) || e.payloadSize>static_cast<unsigned>(bytesValid)-e.payloadOffset)continue;
  auto& b=GetLead(e.ptr);b.samples++;
  // Float-aligned sliding windows, copied via memcpy rather than unaligned float casts.
  for(unsigned off=0;off+64<=e.payloadSize;off+=4){float m[16];memcpy(m,bytes+e.payloadOffset+off,sizeof(m));
   if(AffineAt(m)){b.affine++;break;}
  }
  for(unsigned off=0;off+64<=e.payloadSize;off+=4){float m[16];memcpy(m,bytes+e.payloadOffset+off,sizeof(m));
   if(ProjectionAt(m)){b.projection++;break;}
  }
 }
 for(LONG i=0;i<n;i++){const Event&e=ev[i];if(e.kind!=20&&e.kind!=21)continue;
  for(auto& b:buffers)if(b.resource==e.ptr){if(e.kind==20)b.boundVS++;else b.boundPS++;break;}
 }
 for(auto& b:buffers)b.score=3.0*b.affine+5.0*b.projection+.01*b.boundVS+.005*b.boundPS;
 std::sort(buffers.begin(),buffers.end(),[](const BufferLead&a,const BufferLead&b){return a.score>b.score;});
 fprintf(f,"STAGE 2 — Captured GPU constant-data leads\nBuffers containing sampled writes: %zu\n",buffers.size());
 for(size_t i=0;i<buffers.size()&&i<20;i++){
  const auto& b=buffers[i];fprintf(f,"rank=%zu resource=0x%llX samples=%u affine_candidates=%u perspective_candidates=%u VS_bindings=%u PS_bindings=%u score=%.2f\n",i+1,static_cast<unsigned long long>(b.resource),b.samples,b.affine,b.projection,b.boundVS,b.boundPS,b.score);
 }
 fprintf(f,"Interpretation: heuristic float patterns, not proof of a camera or correct matrix layout. Resource pointers change between runs.\n\n");
 // Stage 3: Link near-sequence buffer binds and draw calls to top pass segments.
 fprintf(f,"STAGE 3 — Cross-correlation for leading pass segments\n");
 for(size_t pi=0;pi<passes.size()&&pi<8;pi++){
  const auto&p=passes[pi]; unsigned matches=0;uintptr_t returnAddress=0;unsigned callerCount=0;
  for(LONG i=0;i<n;i++){const Event&e=ev[i];if(e.seq<p.begin||e.seq>p.end)continue;
   if((e.kind==20||e.kind==21)&&!buffers.empty())for(size_t k=0;k<buffers.size()&&k<5;k++)if(e.ptr==buffers[k].resource){matches++;break;}
   // Only return sites within the game's PE address space are worth ranking; unresolved library sites not promoted.
   if(e.site && e.kind>=1&&e.kind<=4){if(!returnAddress||e.site==returnAddress){returnAddress=e.site;callerCount++;}}
  }
  fprintf(f,"pass_rank=%zu seq=%u..%u top_buffer_bindings=%u predominant_raw_return=0x%llX matched_draw_sites=%u\n",pi+1,p.begin,p.end,matches,static_cast<unsigned long long>(returnAddress),callerCount);
 }
 fprintf(f,"Note: raw return addresses are NOT stable RVAs and may point to a wrapper; consult the per-event CSV module/RVA fields.\n\n");
 fprintf(f,"STAGE 4 — Evidence-gated continuation\n");
 bool sufficient=(lostEvents==0 && lostPayload==0 && !passes.empty());
 fprintf(f,"Complete_for_instrumented_events: %s\n",sufficient?"YES":"NO");
 bool matrixLeads=false;for(const auto& b:buffers)if(b.affine||b.projection){matrixLeads=true;break;}
 fprintf(f,"Captured_matrix_candidates: %s\n",matrixLeads?"YES — UNVERIFIED":"NO");
 fprintf(f,"Safe_callable_full_scene_function: NOT ESTABLISHED\nIndependent_stereo_scene_render: NOT IMPLEMENTED\n");
 if(!sufficient)fprintf(f,"STOP: Capture incomplete. Correct event/payload losses before using the ranking.\n");
 else if(!matrixLeads)fprintf(f,"STOP: No strong matrix lead in the intercepted CPU writes; GPU readback/shader-bytecode coverage is needed.\n");
 else fprintf(f,"STOP: Candidate rendering passes/buffers found. Next inference requires game-code ownership analysis and safe nonmutating verification; DO NOT automatically invoke unknown functions.\n");
 fprintf(f,"Known blind spots: deferred contexts, shader bytecode, GPU-only updates, multi-frame persistence, complete CPU stacks.\n");
 bool ok=ferror(f)==0;if(fclose(f))ok=false;return ok;
}

extern "C" bool RFGRVR_GPUCapture_Attach(ID3D11DeviceContext* ctx){
 if(!ctx)return false;
 if(InterlockedCompareExchange(&installed,1,0)!=0)return tracked==ctx;
 void*** obj=reinterpret_cast<void***>(ctx);void** old=*obj;const size_t n=RFGRVR_ContextMethods(ctx);
 if(!VtableOK(old,n)){InterlockedIncrement(&installErrors);InterlockedExchange(&installed,0);return false;}
 // Driver extensions may use private entries beyond ID3D11DeviceContext4.
 // Preserve the bounded readable tail and preceding metadata just as the
 // deferred-context shadow does; only public slots are replaced below.
 MEMORY_BASIC_INFORMATION region{};if(!VirtualQuery(old,&region,sizeof(region))){InterlockedExchange(&installed,0);return false;}
 const size_t available=((uintptr_t)region.BaseAddress+region.RegionSize-(uintptr_t)old)/sizeof(void*);
 const size_t copyCount=(std::max)(n,(std::min)(size_t(512),available));
 void** allocation=reinterpret_cast<void**>(VirtualAlloc(nullptr,(copyCount+1)*sizeof(void*),MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
 if(!allocation){InterlockedIncrement(&installErrors);InterlockedExchange(&installed,0);return false;}void** v=allocation+1;
 MEMORY_BASIC_INFORMATION metadata{};if(VirtualQuery(old-1,&metadata,sizeof(metadata))&&metadata.State==MEM_COMMIT&&!(metadata.Protect&(PAGE_NOACCESS|PAGE_GUARD)))v[-1]=old[-1];
 memcpy(v,old,copyCount*sizeof(void*));
 oldVS=reinterpret_cast<CBFn>(old[7]); oldPS=reinterpret_cast<CBFn>(old[16]);
 oldVSShader=reinterpret_cast<ShaderFn>(old[11]);oldPSShader=reinterpret_cast<PSShaderFn>(old[9]);
 oldAuto=(AutoFn)old[38];oldIndexedIndirect=(IndirectFn)old[39];oldInstIndirect=(IndirectFn)old[40];oldDispatch=(DispatchFn)old[41];oldDispatchIndirect=(IndirectFn)old[42];oldExecute=(ExecuteFn)old[58];
 oldIndexed=reinterpret_cast<IndexedFn>(old[12]);oldDraw=reinterpret_cast<DrawFn>(old[13]);
 oldIndexedInst=reinterpret_cast<IndexedInstFn>(old[20]);oldInst=reinterpret_cast<InstFn>(old[21]);
 oldMap=reinterpret_cast<MapFn>(old[14]);oldUnmap=reinterpret_cast<UnmapFn>(old[15]);
 oldOM=reinterpret_cast<OMFn>(old[33]);oldUpdate=reinterpret_cast<UpdateFn>(old[48]);
 oldClearRT=reinterpret_cast<ClearRTFn>(old[50]);oldClearDS=reinterpret_cast<ClearDSFn>(old[53]);
 v[7]=reinterpret_cast<void*>(&HVS);v[16]=reinterpret_cast<void*>(&HPS);v[11]=reinterpret_cast<void*>(&HVSShader);v[9]=reinterpret_cast<void*>(&HPSShader);
 v[38]=(void*)&HAuto;v[39]=(void*)&HIndexedIndirect;v[40]=(void*)&HInstIndirect;v[41]=(void*)&HDispatch;v[42]=(void*)&HDispatchIndirect;v[58]=(void*)&HExecute;
 v[12]=reinterpret_cast<void*>(&HIndexed);v[13]=reinterpret_cast<void*>(&HDraw);v[20]=reinterpret_cast<void*>(&HIndexedInst);v[21]=reinterpret_cast<void*>(&HInst);
 v[14]=reinterpret_cast<void*>(&HMap);v[15]=reinterpret_cast<void*>(&HUnmap);
 v[33]=reinterpret_cast<void*>(&HOM);v[48]=reinterpret_cast<void*>(&HUpdate);v[50]=reinterpret_cast<void*>(&HClearRT);v[53]=reinterpret_cast<void*>(&HClearDS);
 RFGRAPCTargets::attach(ctx,v,unsigned(n));
 void* prev=InterlockedCompareExchangePointer(reinterpret_cast<PVOID volatile*>(obj),v,old);
 if(prev!=old){VirtualFree(allocation,0,MEM_RELEASE);InterlockedIncrement(&installErrors);InterlockedExchange(&installed,0);return false;}
 tracked=ctx;return true;
}
extern "C" bool RFGRVR_GPUCapture_Start(){
 if(InterlockedCompareExchange(&installed,0,0)!=1)return false;
 if(InterlockedCompareExchange(&state,1,0)!=0)return false;
 events=reinterpret_cast<Event*>(VirtualAlloc(nullptr,sizeof(Event)*CAPACITY,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
 payload=reinterpret_cast<unsigned char*>(VirtualAlloc(nullptr,PAYLOAD_CAP,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
 if(!events||!payload){InterlockedExchange(&state,0);return false;}
 used=0;payloadUsed=0;sequence=0;overflow=0;writesDropped=0;
 draws=0;renderTargets=0;constantBindings=0;resourceWrites=0;clears=0;shaderBindings=0;
 capturePid=GetCurrentProcessId();captureTick=GetTickCount();return true;
}
extern "C" void RFGRVR_GPUCapture_Present(){
 // Production runs do not allocate/export a full survey automatically.
 // An explicit one-shot request retains the diagnostic path.
 static ULONGLONG nextSurveyCheck=0;
 if(ReadAcquire(&state)==0&&GetTickCount64()>=nextSurveyCheck){nextSurveyCheck=GetTickCount64()+1000;wchar_t request[MAX_PATH]{};GetModuleFileNameW(nullptr,request,MAX_PATH);auto* slash=wcsrchr(request,L'\\');if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-request),L"RFGRVR-gpu-survey.enable");if(GetFileAttributesW(request)!=INVALID_FILE_ATTRIBUTES&&!GetModuleHandleW(L"renderdoc.dll")&&RFGRVR_HeadCam_Recent()&&RFGRVR_GPUCapture_Start())DeleteFileW(request);}}

 // The first Present arms the NEXT full frame; second Present ends it.
 if(InterlockedCompareExchange(&state,0,0)==1){InterlockedCompareExchange(&state,2,1);return;}
 if(InterlockedCompareExchange(&state,3,2)==2){RFGRVR_Survey_Capture(true);QueueUserWorkItem(&ExportSurvey,nullptr,WT_EXECUTEDEFAULT);return;}
}
extern "C" bool RFGRVR_GPUCapture_Export(){
 LONG was=InterlockedCompareExchange(&state,4,3);
 if(was!=3){ // Do not claim partial-frame success.
  return false;
 }
 char root[MAX_PATH]{};if(!ReportRoot(root,sizeof(root)))return false;
 char csv[MAX_PATH]{},bin[MAX_PATH]{},txt[MAX_PATH]{};
 sprintf_s(csv,"%s\\GPU-SingleFrame-%lu-%lu.csv",root,capturePid,captureTick);
 sprintf_s(bin,"%s\\GPU-BufferWrites-%lu-%lu.bin",root,capturePid,captureTick);
 sprintf_s(txt,"%s\\GPU-Capture-Status-%lu-%lu.txt",root,capturePid,captureTick);
 FILE* f=nullptr; if(fopen_s(&f,csv,"wb")||!f)return false;
 fprintf(f,"seq,kind,kindId,count,aux,resource,secondary,codeReturn,codeModule,codeRVA,format,widthOrBytes,height,samples,payloadOffset,payloadBytes\n");
 const LONG n=(std::min)(InterlockedCompareExchange(&used,0,0),CAPACITY);
 for(LONG i=0;i<n;++i){const auto&e=events[i];
  HMODULE mod=nullptr;uintptr_t rva=0;char name[MAX_PATH]="";
  if(e.site&&GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCSTR>(e.site),&mod)){
   rva=e.site-reinterpret_cast<uintptr_t>(mod);GetModuleFileNameA(mod,name,MAX_PATH);
   const char*slash=strrchr(name,'\\');if(slash)memmove(name,slash+1,strlen(slash+1)+1);
  }
  fprintf(f,"%u,%s,%u,%u,%u,0x%llX,0x%llX,0x%llX,%s,0x%llX,%u,%u,%u,%u,%u,%u\n",e.seq,Kind(e.kind),e.kind,e.count,e.aux,
   static_cast<unsigned long long>(e.ptr),static_cast<unsigned long long>(e.ptr2),static_cast<unsigned long long>(e.site),name,
   static_cast<unsigned long long>(rva),e.format,e.width,e.height,e.sample,e.payloadOffset,e.payloadSize);
 }
 bool ok=ferror(f)==0; if(fclose(f))ok=false;
 f=nullptr;if(fopen_s(&f,bin,"wb")||!f)return false;
 LONG bytes=(std::min)(InterlockedCompareExchange(&payloadUsed,0,0),PAYLOAD_CAP);
 if(bytes>0 && fwrite(payload,1,bytes,f)!=static_cast<size_t>(bytes))ok=false;
 if(fclose(f))ok=false;
 f=nullptr;if(fopen_s(&f,txt,"wb")||!f)return false;
 fprintf(f,"RFGR-VR v4.8 one-frame GPU survey (not stereo rendering)\nCapture state: one Present-delimited frame\nProcess: %lu\nCaptured events: %ld\nTotal attempted events: %ld\nEvent overflow: %ld\nCPU buffer write bytes: %ld\nPayload drops: %ld\nDraw calls: %ld\nRT target changes: %ld\nConstant-buffer bindings: %ld\nCPU resource writes: %ld\nClear operations: %ld\nShader bindings: %ld\nHook installation errors: %ld\nGPU readback: NOT CAPTURED\nDeferred contexts/ExecuteCommandList: NOT INSTRUMENTED\nShader bytecode: NOT CAPTURED\nFull GPU command buffers: NOT CAPTURED\nComplete call stacks: NOT CAPTURED (one immediate return address only)\nReplayable world pass: NOT VERIFIED\n",
 capturePid,n,used,overflow,bytes,writesDropped,draws,renderTargets,constantBindings,resourceWrites,clears,shaderBindings,installErrors);
 fprintf(f,"RESULT=%s\n",overflow==0&&writesDropped==0?"COMPLETE_FOR_INSTRUMENTED_EVENTS":"INCOMPLETE_SEE_DROPS");
 if(fclose(f))ok=false;
 bool digOK=AutomaticDig(root,capturePid,captureTick,events,n,payload,bytes,overflow,writesDropped);
 InterlockedExchange(&state,5);
 return ok && digOK;
}

extern "C" unsigned long long RFGRVR_GPU_DrawCount(){return nativeDrawCount;}
extern "C" bool RFGRVR_EyeResources_Begin(unsigned kinds){
 if(!tracked)return false;
 eyeResources.begin(tracked,kinds);
 ID3D11RenderTargetView* targets[8]{};ID3D11DepthStencilView* depth=nullptr;
 tracked->OMGetRenderTargets(8,targets,&depth);
 for(auto* target:targets){eyeResources.observe(target);if(target)target->Release();}
 eyeResources.observe(depth);if(depth)depth->Release();
 ID3D11Buffer* buffers[14]{};
 tracked->VSGetConstantBuffers(0,14,buffers);for(auto* buffer:buffers){eyeResources.observeBuffer(buffer);if(buffer)buffer->Release();}
 tracked->PSGetConstantBuffers(0,14,buffers);for(auto* buffer:buffers){eyeResources.observeBuffer(buffer);if(buffer)buffer->Release();}
 return eyeResources.valid();
}
extern "C" bool RFGRVR_EyeResources_Between(unsigned mask){return eyeResources.between(mask);}
extern "C" unsigned RFGRVR_EyeResources_Count(){return eyeResources.count();}
extern "C" void RFGRVR_EyeResources_End(){eyeResources.end();}
extern "C" bool RFGRVR_EyePipeline_Begin(){if(!tracked)return false;eyePipeline=std::make_unique<RFGRVREyePipeline>();eyePipeline->save(tracked);return true;}
extern "C" void RFGRVR_EyePipeline_Between(unsigned mask){if(eyePipeline)eyePipeline->restore(tracked,mask);}
extern "C" void RFGRVR_EyePipeline_End(){eyePipeline.reset();}
extern "C" void RFGRVR_GPUCapture_Mark(unsigned kind,void* renderer,void* secondary){
 Event* e=Record(kind,GetCurrentThreadId(),(uintptr_t)renderer,(uintptr_t)secondary,CodeSite());
 if(!e)return;
 MEMORY_BASIC_INFORMATION m{};if(renderer&&VirtualQuery(renderer,&m,sizeof(m))&&m.State==MEM_COMMIT&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&
  (uintptr_t)renderer+0x4b0<=(uintptr_t)m.BaseAddress+m.RegionSize)Payload(e,renderer,0x4b0);
 if(tracked){ID3D11RenderTargetView* target=nullptr;ID3D11DepthStencilView* depth=nullptr;
  tracked->OMGetRenderTargets(1,&target,&depth);
  Event* rt=Record(42,kind,(uintptr_t)target,(uintptr_t)depth,0);if(rt)ViewInfo(target,*rt);
  if(target)target->Release();if(depth)depth->Release();
 }
 if(kind==41)RFGRVR_Survey_Capture(false);
}



extern "C" void RFGRVR_PixelProbe_Begin(){
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-pixel-probe.enable");
 if(GetFileAttributesW(path)!=INVALID_FILE_ATTRIBUTES)RFGRVRPixelProbe::begin(tracked);
}
extern "C" void RFGRVR_PixelProbe_Select(unsigned eye){if(RFGRVRPixelProbe::active)RFGRVRPixelProbe::eye=eye;}
extern "C" void RFGRVR_PixelProbe_End(){
 if(!RFGRVRPixelProbe::active)return;char prefix[MAX_PATH]{};GetModuleFileNameA(nullptr,prefix,MAX_PATH);auto* slash=strrchr(prefix,92);if(!slash)return;
 sprintf_s(slash+1,MAX_PATH-(slash+1-prefix),"vr-research\\output\\PixelProbe-%lu",GetCurrentProcessId());RFGRVRPixelProbe::finish(prefix);
}




