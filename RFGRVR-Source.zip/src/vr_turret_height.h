#pragma once
#include "vr_arm_math.h"
#include <windows.h>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>
namespace vrturretheight {
inline vrarm::V eyePosition(vrarm::V eye,float height){if(std::isfinite(height))eye.y+=height;return eye;}
struct Profile {
 std::atomic<float> value{0};char path[MAX_PATH]{},type[96]{};bool dirty=false;
 void save(){if(!dirty||!type[0])return;char text[32];sprintf_s(text,"%.6f",value.load());if(WritePrivateProfileStringA(type,"EyeOnlyHeight",text,path))dirty=false;}
 void update(const char* name,float axis,float dt){
  if(!name||!name[0]){save();type[0]=0;value=0;return;}
  if(!path[0]){GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,92);if(slash)strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-standing-turret-heights.ini");}
  if(!type[0]){save();strcpy_s(type,"FreeStanding");char text[40]{};GetPrivateProfileStringA(type,"EyeOnlyHeight","0",text,sizeof(text),path);float height=0;if(sscanf_s(text,"%f",&height)!=1||!std::isfinite(height))height=0;value=(std::clamp)(height,-.6f,.6f);}
  if(!std::isfinite(axis)||!std::isfinite(dt)||dt<=0)return;
  float a=fabsf(axis)>.2f?(axis-(axis>0?.2f:-.2f))/.8f:0;
  if(a){value=(std::clamp)(value.load()+a*.3f*(std::min)(dt,.05f),-.6f,.6f);dirty=true;}else save();
 }
};
}
