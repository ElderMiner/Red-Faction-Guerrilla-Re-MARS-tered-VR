#pragma once
#include "modern_sky_source.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <cmath>
#include <cstring>
namespace modernsky {
struct Frame {float direction[2][4]{{0,1,0,20},{0,-1,0,0}};// colour[0].w = observer altitude (km), colour[1].w = authored dust blend.
 float colour[2][4]{{1,1,1,.002f},{.6f,.7f,1,0}};};
inline bool valid(const Frame& frame){const float* p=(const float*)&frame;for(unsigned i=0;i<16;++i)if(!std::isfinite(p[i]))return false;for(unsigned i=0;i<2;++i){float norm=0;for(unsigned k=0;k<3;++k){norm+=frame.direction[i][k]*frame.direction[i][k];if(frame.colour[i][k]<0||frame.colour[i][k]>1e6f)return false;}if(frame.direction[i][3]<0||frame.direction[i][3]>10000||(frame.direction[i][3]>0&&(norm<.5f||norm>1.5f)))return false;}return frame.colour[0][3]>=0&&frame.colour[0][3]<60&&frame.colour[1][3]>=0&&frame.colour[1][3]<=1;}
class Lookup {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> worker;Ptr<ID3D11ComputeShader> shader;Ptr<ID3D11Buffer> constants;Ptr<ID3D11Texture2D> output;Ptr<ID3D11ShaderResourceView> view;Ptr<ID3D11UnorderedAccessView> target;Frame last{};unsigned width=0;bool populated=false;
 bool init(ID3D11Device* d,unsigned size){if(owner.Get()==d&&view&&shader&&constants&&worker&&target&&width==size)return true;if(!d||d->GetFeatureLevel()<D3D_FEATURE_LEVEL_11_0||size<32||size>512||(size&(size-1)))return false;*this={};owner=d;width=size;Ptr<ID3DBlob> code,error;if(FAILED(D3DCompile(skySource,sizeof(skySource)-1,"RFGRVR world atmosphere",nullptr,nullptr,"main","cs_5_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error)))return false;if(FAILED(d->CreateComputeShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&shader))||FAILED(d->CreateDeferredContext(0,&worker)))return false;D3D11_BUFFER_DESC bd{};bd.ByteWidth=sizeof(Frame);bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;if(FAILED(d->CreateBuffer(&bd,nullptr,&constants)))return false;D3D11_TEXTURE2D_DESC td{};td.Width=size;td.Height=size/2;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R16G16B16A16_FLOAT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_UNORDERED_ACCESS;return SUCCEEDED(d->CreateTexture2D(&td,nullptr,&output))&&SUCCEEDED(d->CreateShaderResourceView(output.Get(),nullptr,&view))&&SUCCEEDED(d->CreateUnorderedAccessView(output.Get(),nullptr,&target));}
public:
 bool update(ID3D11Device* d,ID3D11DeviceContext* c,const Frame& frame,unsigned size=128){if(!c||c->GetType()!=D3D11_DEVICE_CONTEXT_IMMEDIATE||!valid(frame))return false;Ptr<ID3D11Device> cd;c->GetDevice(&cd);if(cd.Get()!=d||!init(d,size))return false;if(populated&&!memcmp(&last,&frame,sizeof(frame)))return true;worker->ClearState();worker->UpdateSubresource(constants.Get(),0,nullptr,&frame,0,0);auto* cb=constants.Get();worker->CSSetConstantBuffers(0,1,&cb);worker->CSSetShader(shader.Get(),nullptr,0);auto* uav=target.Get();worker->CSSetUnorderedAccessViews(0,1,&uav,nullptr);worker->Dispatch((size+7)/8,(size/2+7)/8,1);Ptr<ID3D11CommandList> commands;if(FAILED(worker->FinishCommandList(FALSE,&commands)))return false;c->ExecuteCommandList(commands.Get(),TRUE);last=frame;populated=true;return true;}
 ID3D11ShaderResourceView* resource()const{return view.Get();}
};
}
