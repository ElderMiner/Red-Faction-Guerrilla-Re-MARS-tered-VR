#pragma once
#include "modern_reflection_brdf_source.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
namespace modernreflection {
class BRDF {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11Texture2D> texture;Ptr<ID3D11ShaderResourceView> view;
public:
 bool ensure(ID3D11Device* d,ID3D11DeviceContext* c){if(!d||!c||c->GetType()!=D3D11_DEVICE_CONTEXT_IMMEDIATE||d->GetFeatureLevel()<D3D_FEATURE_LEVEL_11_0)return false;Ptr<ID3D11Device> cd;c->GetDevice(&cd);if(cd.Get()!=d)return false;if(owner.Get()==d&&view)return true;Ptr<ID3DBlob> code,error;Ptr<ID3D11ComputeShader> shader;Ptr<ID3D11DeviceContext> worker;Ptr<ID3D11Texture2D> next;Ptr<ID3D11ShaderResourceView> nextView;Ptr<ID3D11UnorderedAccessView> output;
  if(FAILED(D3DCompile(brdfSource,sizeof(brdfSource)-1,"RFGRVR split-sum BRDF",nullptr,nullptr,"main","cs_5_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error))||FAILED(d->CreateComputeShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&shader))||FAILED(d->CreateDeferredContext(0,&worker)))return false;D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=128;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R16G16_FLOAT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_UNORDERED_ACCESS;if(FAILED(d->CreateTexture2D(&td,nullptr,&next))||FAILED(d->CreateShaderResourceView(next.Get(),nullptr,&nextView))||FAILED(d->CreateUnorderedAccessView(next.Get(),nullptr,&output)))return false;
  worker->CSSetShader(shader.Get(),nullptr,0);auto* target=output.Get();worker->CSSetUnorderedAccessViews(0,1,&target,nullptr);worker->Dispatch(16,16,1);Ptr<ID3D11CommandList> commands;if(FAILED(worker->FinishCommandList(FALSE,&commands)))return false;c->ExecuteCommandList(commands.Get(),TRUE);owner=d;texture=next;view=nextView;return true;
 }
 ID3D11ShaderResourceView* resource()const{return view.Get();}
};
}
