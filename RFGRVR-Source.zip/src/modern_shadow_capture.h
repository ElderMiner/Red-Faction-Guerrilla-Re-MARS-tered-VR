#pragma once
namespace modernshadow {
using Native=uintptr_t(__thiscall*)(void*,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);
inline Native native=nullptr;
using Notice=void(*)(void*,void*,const float*,unsigned);
inline std::atomic<Notice> notice{nullptr};
inline void evidence(void* self,const uintptr_t* args,unsigned record,const char* phase){
 char root[MAX_PATH]{};GetModuleFileNameA(nullptr,root,MAX_PATH);auto* slash=strrchr(root,92);if(!slash)return;slash[1]=0;
 char path[MAX_PATH]{};sprintf_s(path,"%svr-research\\output\\Modern-shadow-%lu-%u-%s.txt",root,GetCurrentProcessId(),record,phase);FILE* f=nullptr;if(!fopen_s(&f,path,"w")&&f){fprintf(f,"self=%p\n",self);for(unsigned i=0;i<13;++i)fprintf(f,"argument%u=%p\n",i+1,(void*)args[i]);fclose(f);}
 for(unsigned i=0;i<13;++i){const void* p=(void*)args[i];if(!vrmemory::check(p,256))continue;sprintf_s(path,"%svr-research\\output\\Modern-shadow-%lu-%u-%s-arg%u.bin",root,GetCurrentProcessId(),record,phase,i+1);f=nullptr;if(!fopen_s(&f,path,"wb")&&f){fwrite(p,1,256,f);fclose(f);}}
}
inline uintptr_t __fastcall invoke(void* self,void*,uintptr_t a1,uintptr_t a2,uintptr_t a3,uintptr_t a4,uintptr_t a5,uintptr_t a6,uintptr_t a7,uintptr_t a8,uintptr_t a9,uintptr_t a10,uintptr_t a11,uintptr_t a12,uintptr_t a13){
 static std::atomic<unsigned> claimed{0};unsigned record=~0u;
 if(modernlight::enabled()&&moderncatalog::enabled()&&RFGRVR_HeadCam_FirstPersonVehicle()&&claimed.load()<3){record=claimed.fetch_add(1);}
 const uintptr_t args[]={a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13};if(record<3)evidence(self,args,record,"before");
 auto result=native(self,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13);if(record<3)evidence(self,args,record,"after");
 if(auto callback=notice.load(std::memory_order_relaxed))callback(self,(void*)a1,(const float*)a5,unsigned(a13));return result;
}
// The optimized engine caller can keep XMM6/7 across this call. Preserve them
// explicitly, and forward all thirteen stack arguments without repurposing ECX.
__declspec(naked) inline void entry(){__asm {
 sub esp,32
 movups [esp],xmm6
 movups [esp+16],xmm7
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 push [esp+84]
 call invoke
 movups xmm6,[esp]
 movups xmm7,[esp+16]
 add esp,32
 ret 52
}}
}
