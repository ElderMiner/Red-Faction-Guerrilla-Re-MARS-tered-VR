#pragma once
#include "modern_scene_lights.h"
#include <array>
namespace modernpolicy {
enum class Quality {Low,Default,High};
// Diffuse-grid filling must not replace the local reflection with every outer
// cell. Keep the closest capture, with a bounded refresh at that location.
inline bool updateReflection(bool valid,uint64_t age,float currentDistanceSquared,float candidateDistanceSquared){
 if(!std::isfinite(candidateDistanceSquared)||candidateDistanceSquared<0)return false;
 if(!valid)return true;
 if(!std::isfinite(currentDistanceSquared)||currentDistanceSquared<0)return true;
 return candidateDistanceSquared+1.f<currentDistanceSquared||(age>=600&&candidateDistanceSquared<=currentDistanceSquared+.25f);
}
struct Budget {unsigned localLights,shadowResolution,shadowFaces,probeUpdates,reflectionResolution,reflectionSamples,volumeSteps,volumeDivisor;};
inline Budget budget(Quality q){if(q==Quality::Low)return {2,256,6,1,64,32,16,4};if(q==Quality::High)return {4,1024,12,2,256,128,32,4};return {3,512,6,1,128,64,24,4};}
// Rendering work budgets are separate from visible light energy. Dropping a
// cache update must never dim an existing valid light or change eye exposure.
struct Environment {
 float night=0,directional=1,ambient=1,bloom=1;
 float exposureMinimum=.02f,exposureMaximum=4;
 float probeRadianceScale=1,reflectionRadianceScale=1;
};
inline Environment environment(float nativeHour){auto native=modernscene::environment(nativeHour);Environment e;e.night=native.night;e.directional=native.main;e.ambient=native.ambient;e.bloom=native.bloom;e.exposureMaximum=4*(1-native.night)+(.18f/.35f)*native.night;return e;}
using Histogram=std::array<uint32_t,256>;
inline unsigned bin(float luminance){if(!std::isfinite(luminance)||luminance<=0)return 0;float log=std::log2(luminance);return unsigned((std::clamp)((log+12)/28*256,0.f,255.f));}
inline float luminance(unsigned bin){return std::exp2(-12+(bin+.5f)*28/256);}
class StereoExposure {
 uint64_t pending=~uint64_t(0),finished=~uint64_t(0);unsigned mask=0;Histogram pair[2]{};float value=1;bool seeded=false;
public:
 // Submit a matching pair only once. Exposure advances once per pair, never
 // once per eye. No HUD, menu, display-encoded image or post-exposure source
 // belongs in these histograms.
 bool submit(uint64_t frame,unsigned eye,const Histogram& histogram,float seconds,const Environment& environment){
  if(eye>1||frame==finished||(finished!=~uint64_t(0)&&frame<finished)||(pending!=~uint64_t(0)&&frame<pending)||!std::isfinite(seconds)||seconds<0||!std::isfinite(environment.exposureMinimum)||!std::isfinite(environment.exposureMaximum)||environment.exposureMinimum<=0||environment.exposureMaximum<environment.exposureMinimum)return false;if(frame!=pending){pending=frame;mask=0;}if(mask&(1u<<eye))return false;pair[eye]=histogram;mask|=1u<<eye;if(mask!=3)return false;
  uint64_t count=0;for(unsigned i=0;i<256;++i)count+=uint64_t(pair[0][i])+pair[1][i];if(!count){finished=frame;return false;}
  // Trim the darkest and brightest deciles. A small explosion or a headlight
  // highlight cannot force the entire scene to meter as that bright source.
  double first=count*.1,last=count*.9,seen=0,weighted=0,weight=0;
  for(unsigned i=0;i<256;++i){double amount=double(pair[0][i])+pair[1][i],end=seen+amount,take=(std::max)(0.,(std::min)(end,last)-(std::max)(seen,first));weighted+=take*std::log2(luminance(i));weight+=take;seen=end;}
  float metered=weight>0?std::exp2(float(weighted/weight)):.18f;float target=(std::clamp)(.18f/(std::max)(metered,.0001f),environment.exposureMinimum,environment.exposureMaximum);
  if(!seeded){value=target;seeded=true;}else {float rate=target<value?3.f:1.f;float blend=1-std::exp(-rate*(std::min)(seconds,.1f));value=std::exp2(std::log2(value)+(std::log2(target)-std::log2(value))*blend);}
  finished=frame;return true;
 }
 float exposure()const{return value;}
 bool ready()const{return seeded;}
};
}

