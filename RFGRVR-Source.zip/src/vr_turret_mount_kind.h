#pragma once
#include <cstring>
inline bool RFGRVR_StandingVehicleTurret(const char* name){
 return name&&(!strcmp(name,"turret_vehicle_raider_harpoon")||!strcmp(name,"turret_stomper_mg"));
}
