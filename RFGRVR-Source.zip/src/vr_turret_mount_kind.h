#pragma once
#include <cstring>
#include <algorithm>
#include "vr_arm_math.h"
inline bool RFGRVR_HeadAimedVehicleTurret(const char* name){return name&&!strcmp(name,"turret_vehicle_jetter_rocket_mg");}
inline bool RFGRVR_HeadTurretAim(const vrarm::Pose& mount,const vrarm::Pose& head,vrarm::V gun,float scale,const float limits[4],float& yaw,float& pitch){
 using namespace vrarm;if(!valid(mount.b)||!valid(head.b)||!finite(head.p)||!finite(gun)||!std::isfinite(scale)||scale<=0||!limits)return false;
 for(unsigned i=0;i<4;++i)if(!std::isfinite(limits[i]))return false;if(limits[1]>limits[0]||limits[3]>limits[2])return false;
 V delta=sub(add(head.p,mul(head.b.f,100.f*scale)),gun);if(!finite(delta)||length(delta)<.001f)return false;V direction=local(mount.b,unit(delta));
 // Apply yaw limits after adding stick traverse.
 yaw=atan2f(direction.x,direction.z);pitch=(std::clamp)(atan2f(direction.y,std::hypot(direction.x,direction.z)),limits[3],limits[2]);return true;
}
inline float RFGRVR_HeadTurretTurn(float lookYaw,float& offset,float axis,float dt,float rate,float low,float high){
 if(!std::isfinite(axis))axis=0;axis=(std::clamp)(axis,-1.f,1.f);axis=fabsf(axis)>.22f?(axis-(axis>0?.22f:-.22f))/.78f:0;
 if(!std::isfinite(dt)||dt<0)dt=0;if(!std::isfinite(rate)||rate<0)rate=0;
 float step=axis*rate*(std::min)(dt,.05f);float yaw=lookYaw+offset+step;
 // Full-circle vehicle motors take continuous targets, not a +/-pi clamp or wrap.
 if(high-low<6.2f)yaw=(std::clamp)(yaw,low,high);if(step!=0)offset=yaw-lookYaw;return yaw;
}
struct RFGRVRHeadYaw {
 bool ready=false;float previous=0,value=0;
 float update(float angle){if(!std::isfinite(angle))return value;if(!ready){ready=true;previous=value=angle;}else{value+=std::remainder(angle-previous,6.28318530718f);previous=angle;}return value;}
};
inline bool RFGRVR_StandingVehicleTurret(const char* name){
 return name&&(!strcmp(name,"turret_vehicle_raider_harpoon")||!strcmp(name,"turret_stomper_mg"));
}
