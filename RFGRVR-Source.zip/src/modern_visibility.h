#pragma once
#include <cmath>
#include <algorithm>
namespace modernvisibility {
// Conservative D3D clip-volume sphere test, with an angular guard band.
// It culls light influence volumes, never just light-source points.
struct Frustum {
 float planes[6][4]{};bool valid=false;
 bool set(const float* rowMajor,float margin=1.2f){
  valid=false;if(!rowMajor||!std::isfinite(margin)||margin<1||margin>2)return false;
  for(unsigned i=0;i<16;++i)if(!std::isfinite(rowMajor[i]))return false;
  for(unsigned k=0;k<4;++k){planes[0][k]=rowMajor[12+k]*margin+rowMajor[k];planes[1][k]=rowMajor[12+k]*margin-rowMajor[k];planes[2][k]=rowMajor[12+k]*margin+rowMajor[4+k];planes[3][k]=rowMajor[12+k]*margin-rowMajor[4+k];planes[4][k]=rowMajor[8+k];planes[5][k]=rowMajor[12+k]-rowMajor[8+k];}
  for(auto& p:planes){float n=std::sqrt(p[0]*p[0]+p[1]*p[1]+p[2]*p[2]);if(n<1e-8f)return false;for(float& v:p)v/=n;}valid=true;return true;
 }
 bool intersects(const float* centre,float radius)const{
  if(!valid||!centre||!std::isfinite(radius)||radius<0)return true;
  for(unsigned k=0;k<3;++k)if(!std::isfinite(centre[k]))return true;
  for(auto& p:planes)if(p[0]*centre[0]+p[1]*centre[1]+p[2]*centre[2]+p[3]<-radius-.1f)return false;return true;
 }
};
}
