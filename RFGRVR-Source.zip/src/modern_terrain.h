#pragma once
#include <string>
#include "modern_world_sampling_source.h"
#include "modern_height_sampling_source.h"
// Original terrain shading; verified native binding identifiers only.
namespace modernterrain {
struct Identity {unsigned char hash[16];size_t bytes;unsigned mode;};
inline constexpr Identity identities[]={
{{0x24,0xc8,0x3b,0xbb,0x20,0xc2,0x3e,0x02,0x84,0x3c,0x53,0xbb,0x7b,0x73,0xf1,0x83},7212,0},
{{0xad,0xe5,0xf7,0xfd,0x39,0xff,0xb5,0x89,0x4b,0xcb,0x8f,0x26,0x05,0x11,0x03,0xcb},7060,1},
{{0x17,0x17,0xfb,0x25,0xa4,0x63,0xb3,0xca,0x04,0x9d,0x07,0x7d,0x36,0x2c,0xdc,0x3b},7212,0},
{{0x0f,0x13,0x5a,0x64,0x2d,0x25,0x61,0xee,0x47,0xfc,0xd0,0xcf,0x55,0xc6,0x7d,0xaf},7060,1},
};
inline constexpr char source[]=R"TERRAIN(
// OPTICAL_HELPERS_BEGIN
// Shared optical response for verified material interfaces. All radiance is HDR.
float3 modernFresnel(float3 f0,float cosine){return saturate(f0)+(1-saturate(f0))*pow(1-saturate(cosine),5);}
float modernDielectric(float cosine,float etaI,float etaT){
 float c=saturate(abs(cosine)),eta=etaI/max(etaT,.001),k=1-eta*eta*(1-c*c);if(k<=0)return 1;
 float t=sqrt(k),s=(etaI*c-etaT*t)/max(etaI*c+etaT*t,1e-7),p=(etaT*c-etaI*t)/max(etaT*c+etaI*t,1e-7);return saturate((s*s+p*p)*.5);
}
float3 modernBeer(float3 absorption,float distance){return exp(-max(absorption,0)*max(distance,0));}
float modernLightRange(float distance,float range){float q=saturate(distance/max(range,.001)),window=1-q*q*q*q;return window*window/max(distance*distance,1);}
float modernNativeLightRange(float distance,float offset,float scale){return scale>1e-7&&offset>0?modernLightRange(distance,offset/scale):saturate(offset-distance*scale);}
// Preserve authored normal-incidence opacity, increasing optical path at grazing.
float modernGlassOpacity(float opacity,float cosine,float ior){
 if(opacity>=1)return 1;float eta=1/max(ior,1.001),ct=sqrt(max(1-eta*eta*(1-saturate(cosine*cosine)),.0001));
 float base=pow(max(1-saturate(opacity),1e-6),1/ct);float f=modernDielectric(cosine,1,ior),normal=modernDielectric(1,1,ior);
 return saturate(1-base*(1-f)/max(1-normal,.001));
}

Texture2D<float2> modernMaterial0:register(t25),modernMaterial1:register(t26),modernMaterial2:register(t27),modernMaterial3:register(t28);
float3 modernMaterialMap(float2 uv,int layer,SamplerState state){
 uint w,h;float2 value;
 if(layer==0){modernMaterial0.GetDimensions(w,h);if(!w)return 0;value=modernMaterial0.Sample(state,uv);}
 else if(layer==1){modernMaterial1.GetDimensions(w,h);if(!w)return 0;value=modernMaterial1.Sample(state,uv);}
 else if(layer==2){modernMaterial2.GetDimensions(w,h);if(!w)return 0;value=modernMaterial2.Sample(state,uv);}
 else {modernMaterial3.GetDimensions(w,h);if(!w)return 0;value=modernMaterial3.Sample(state,uv);}
 return float3(value,1);
}
void modernApplyMaterialMap(float3 estimate,inout float roughness,inout float reflectivity){
 if(estimate.z<=0)return;float2 value=estimate.xy/max(estimate.z,1e-5);float confidence=saturate(estimate.z);
 // Authored material response bounds the texture-derived approximation.
 roughness=lerp(roughness,max(roughness*.65,value.y),confidence*.5);
 reflectivity=lerp(reflectivity,max(reflectivity*.5,value.x*.35),confidence);
}

// OPTICAL_HELPERS_END























































































































cbuffer Common:register(b0){float4 common[11];};
cbuffer Light:register(b1){float4 lighting[3];};
cbuffer Material:register(b2){float4 material[10];};
cbuffer Instance:register(b6){float4 tint;float4 alphaControl;};
Texture2D<float4> n0:register(t0),n1:register(t1),n2:register(t2),n3:register(t3);
Texture2D<float4> d0:register(t4),d1:register(t5),d2:register(t6),d3:register(t7),mask:register(t8),shadowMap:register(t15);
SamplerState s0:register(s0),s1:register(s1),s2:register(s2),s3:register(s3),s4:register(s4),s5:register(s5),s6:register(s6),s7:register(s7),s8:register(s8),s15:register(s15);
struct In {float4 position:SV_Position;float2 uv3:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float4 upSpotFog:TEXCOORD3;float4 uv0Mask:TEXCOORD4;float4 uv12:TEXCOORD5;};
float3 unit(float3 v){return v*rsqrt(max(dot(v,v),1e-8));}
float3 normal(float4 p){float2 xy=float2((p.r*2-1)*(p.a*2-1),p.g*2-1);return float3(xy,sqrt(saturate(1-dot(xy,xy))));}
float4 main(In i):SV_Target {
 float3 m=saturate(mask.Sample(s8,i.uv0Mask.zw).rgb);
 // Native ordered alpha layers, not a normalized RGB weight map.
 float4 w=float4((1-m.b)*(1-m.g)*(1-m.r),m.b*(1-m.g)*(1-m.r),m.g*(1-m.r),m.r);
 float2 u0=modernRelief(i.position,i.uv0Mask.xy,0,w.x,s0),u1=modernRelief(i.position,i.uv12.xy,1,w.y,s1),u2=modernRelief(i.position,i.uv12.zw,2,w.z,s2),u3=modernRelief(i.position,i.uv3,3,w.w,s3);
 float4 a=d0.SampleGrad(s4,u0,ddx(i.uv0Mask.xy),ddy(i.uv0Mask.xy)),b=d1.SampleGrad(s5,u1,ddx(i.uv12.xy),ddy(i.uv12.xy)),c=d2.SampleGrad(s6,u2,ddx(i.uv12.zw),ddy(i.uv12.zw)),d=d3.SampleGrad(s7,u3,ddx(i.uv3),ddy(i.uv3));
 float3 base=max(a.rgb*material[0].rgb*w.x+b.rgb*material[1].rgb*w.y+c.rgb*material[2].rgb*w.z+d.rgb*material[3].rgb*w.w,0);
 float3 N=unit(normal(n0.SampleGrad(s0,u0,ddx(i.uv0Mask.xy),ddy(i.uv0Mask.xy)))*w.x+normal(n1.SampleGrad(s1,u1,ddx(i.uv12.xy),ddy(i.uv12.xy)))*w.y+normal(n2.SampleGrad(s2,u2,ddx(i.uv12.zw),ddy(i.uv12.zw)))*w.z+normal(n3.SampleGrad(s3,u3,ddx(i.uv3),ddy(i.uv3)))*w.w);
 float3 L=unit(i.toLight),V=unit(i.toEye),H=unit(L+V);
 float nl=saturate(dot(N,L)),nv=max(saturate(dot(N,V)),.001),nh=saturate(dot(N,H)),vh=saturate(dot(V,H));
 float roughness=lerp(.35,.95,saturate(dot(float4(a.a,b.a,c.a,d.a),w)));
 float mapStrength=1;modernApplyMaterialMap(modernMaterialMap(u0,0,s4)*w.x+modernMaterialMap(u1,1,s5)*w.y+modernMaterialMap(u2,2,s6)*w.z+modernMaterialMap(u3,3,s7)*w.w,roughness,mapStrength);
 float alpha=roughness*roughness,a2=alpha*alpha,den=nh*nh*(a2-1)+1;
 float distribution=a2/(3.14159265*max(den*den,1e-7));
 float visibility=.5/max(nl*sqrt(nv*nv*(1-a2)+a2)+nv*sqrt(nl*nl*(1-a2)+a2),1e-5);
 float F=modernFresnel(.04,vh).x*mapStrength;
 float3 radiance=((1-F)*base/3.14159265+distribution*visibility*F)*nl*max(lighting[0].rgb,0);
 float2 shadow=shadowMap.Sample(s15,i.position.xy*common[6].zw).rg;
 radiance*=saturate(shadow.y);
 #if LOCAL_LIGHT
 float atten=modernNativeLightRange(length(i.toLight),lighting[1].x,lighting[1].y);
 float spot=max(min(dot(-L,i.upSpotFog.xyz),lighting[2].x)-lighting[2].y,0)*lighting[2].z;
 radiance*=atten*(lighting[2].w>0?saturate(spot):1)*(1-saturate(i.upSpotFog.w));
 #else
 float hemi=saturate(dot(N,unit(i.upSpotFog.xyz))*.5+.5);
 float3 irradiance=lerp(max(common[3].rgb,0),max(common[2].rgb,0),hemi);
 radiance+=modernAmbient(i.position,i.uv0Mask.xy,N,0,base*.96*irradiance,base*.96)*saturate(shadow.x);
 radiance=lerp(radiance,max(common[4].rgb,0),saturate(i.upSpotFog.w));
 #endif
 return float4(max(radiance,0),1)*tint;
}
)TERRAIN";

using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11PixelShader**);
inline int identify(const void* b,size_t n){if(!b||n<32||memcmp(b,"DXBC",4))return -1;for(auto i:identities)if(n==i.bytes&&!memcmp((const char*)b+4,i.hash,16))return int(i.mode);return -1;}
inline HRESULT create(Create native,ID3D11Device* device,const void* original,SIZE_T size,ID3D11PixelShader** shader,int mode,bool& substituted){
 substituted=false;
 static std::mutex mutex;static Microsoft::WRL::ComPtr<ID3DBlob> code[2];std::lock_guard<std::mutex> lock(mutex);
 HRESULT hr=S_OK;if(!code[mode]){D3D_SHADER_MACRO macros[]={{"LOCAL_LIGHT",mode?"1":"0"},{nullptr,nullptr}};Microsoft::WRL::ComPtr<ID3DBlob> errors;std::string complete=std::string(modernmaterial::samplingSource)+modernheight::samplingSource+source;hr=D3DCompile(complete.c_str(),complete.size(),"RFGRVR modern terrain",macros,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code[mode],&errors);}
 if(SUCCEEDED(hr))hr=native(device,code[mode]->GetBufferPointer(),code[mode]->GetBufferSize(),nullptr,shader);
 if(SUCCEEDED(hr)){substituted=true;return hr;}
 return native(device,original,size,nullptr,shader);
}
}
