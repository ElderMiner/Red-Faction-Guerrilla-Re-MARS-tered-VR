#pragma once
#include "vr_grip_placement.h"
#include <algorithm>
namespace vrpod {
inline constexpr unsigned Maximum=9;
inline unsigned quantity(int capacity,int rounds,int reserve){return unsigned((std::clamp)((std::min)(capacity-rounds,reserve),0,int(Maximum)));}
inline unsigned insert(unsigned held,int capacity,int rounds,int reserve){return (std::min)(held,quantity(capacity,rounds,reserve));}
inline float spacing(float value){return std::isfinite(value)?(std::clamp)(value,.015f,.30f):.08f;}
inline vrarm::Pose at(const vrarm::Pose& root,unsigned index,float gap,float scale){auto result=root;result.p=vrarm::add(root.p,vrarm::world(root.b,{0,-spacing(gap)*float(index)*scale,0}));return result;}
}
