#ifndef MATERIAL_ROWS
#define MATERIAL_ROWS 9
#endif
#ifndef DIFF_T
#define DIFF_T t0
#endif
#ifndef DIFF_S
#define DIFF_S s0
#endif
#ifndef NORMAL_T
#define NORMAL_T t1
#endif
#ifndef NORMAL_S
#define NORMAL_S s1
#endif
#ifndef SPEC_T
#define SPEC_T t2
#endif
#ifndef SPEC_S
#define SPEC_S s2
#endif
#ifndef HAS_SPEC
#define HAS_SPEC 1
#endif
#ifndef M_COLOUR
#define M_COLOUR material[6]
#endif
#ifndef M_NORMAL
#define M_NORMAL material[7].z
#endif
#ifndef M_OPACITY
#define M_OPACITY material[7].w
#endif
#ifndef M_EMISSIVE
#define M_EMISSIVE material[8].x
#endif
#ifndef M_SPEC_ALPHA
#define M_SPEC_ALPHA material[8].y
#endif
#ifndef M_SPEC_POWER
#define M_SPEC_POWER material[8].z
#endif

// Original replacement material shading. Native texture/constant interfaces
// were verified locally; no native shader bytecode is embedded here.
cbuffer Common : register(b0) { float4 common[11]; };
cbuffer Lighting : register(b1) { float4 lighting[3]; };
cbuffer Material : register(b2) { float4 material[MATERIAL_ROWS]; };
cbuffer Instance : register(b6) { float4 tint; float4 alphaControl; };
Texture2D<float4> diffuseMap:register(DIFF_T),normalMap:register(NORMAL_T),specularMap:register(SPEC_T),shadowMap:register(t15);
SamplerState diffuseSampler:register(DIFF_S),normalSampler:register(NORMAL_S),specularSampler:register(SPEC_S),shadowSampler:register(s15);
struct In {float4 position:SV_Position;float2 uv:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float4 upOrSpotFog:TEXCOORD3;};
float3 safeUnit(float3 v){return v*rsqrt(max(dot(v,v),1e-8));}
float3 fresnel(float3 f0,float voh){float f=pow(1-saturate(voh),5);return f0+(1-f0)*f;}
float4 main(In i):SV_Target {
 float4 texel=diffuseMap.Sample(diffuseSampler,i.uv);
 float alpha=lerp(texel.a,1,saturate(M_OPACITY));
 if(alphaControl.y!=0)clip(alpha-alphaControl.x);
 float4 encoded=normalMap.Sample(normalSampler,i.uv);
 float2 xy=float2((encoded.r*2-1)*(encoded.a*2-1),encoded.g*2-1);
 float3 N=safeUnit(lerp(float3(0,0,1),float3(xy,sqrt(saturate(1-dot(xy,xy)))),saturate(M_NORMAL)));
 float3 L=safeUnit(i.toLight),V=safeUnit(i.toEye),H=safeUnit(L+V);
 float noL=saturate(dot(N,L)),noV=max(saturate(dot(N,V)),.001),noH=saturate(dot(N,H)),voH=saturate(dot(V,H));
 float3 base=max(texel.rgb*M_COLOUR.rgb,0);
 #if HAS_SPEC
 float3 legacySpec=specularMap.Sample(specularSampler,i.uv).rgb*max(M_SPEC_ALPHA,0);
 #else
 float3 legacySpec=0;
 #endif
 // Legacy assets have specular maps rather than authored metal/rough textures.
 float roughness=clamp(sqrt(2/(max(M_SPEC_POWER,1)+2)),.12,.95);
 float3 f0=clamp(.04+legacySpec*.36,.02,.8);
 float a=roughness*roughness,a2=a*a,den=noH*noH*(a2-1)+1;
 float distribution=a2/(3.14159265*max(den*den,1e-7));
 float visibility=.5/max(noL*sqrt(noV*noV*(1-a2)+a2)+noV*sqrt(noL*noL*(1-a2)+a2),1e-5);
 float3 F=fresnel(f0,voH);
 float3 direct=((1-F)*base/3.14159265+distribution*visibility*F)*noL;
 float2 screenUV=i.position.xy*common[6].zw;
 float2 shadow=shadowMap.Sample(shadowSampler,screenUV).rg;
 float3 colour=direct*max(lighting[0].rgb,0)*saturate(shadow.y);
 #if LOCAL_LIGHT
 float distance=length(i.toLight),attenuation=modernNativeLightRange(distance,lighting[1].x,lighting[1].y);
 float spot=max(min(dot(-L,i.upOrSpotFog.xyz),lighting[2].x)-lighting[2].y,0)*lighting[2].z;
 colour*=attenuation*(lighting[2].w>0?saturate(spot):1);
 colour*=1-saturate(i.upOrSpotFog.w);
 #else
 float hemisphere=saturate(dot(N,safeUnit(i.upOrSpotFog.xyz))*.5+.5);
 float3 irradiance=lerp(max(common[3].rgb,0),max(common[2].rgb,0),hemisphere);
 colour+=base*(1-fresnel(f0,noV))*irradiance*saturate(shadow.x);
 colour+=base*(1-texel.a)*max(M_EMISSIVE,0);
 colour=lerp(colour,max(common[4].rgb,0),saturate(i.upOrSpotFog.w));
 #endif
 return float4(max(colour,0),alpha)*tint;
}
