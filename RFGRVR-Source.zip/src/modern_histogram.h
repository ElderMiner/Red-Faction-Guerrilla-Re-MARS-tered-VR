#pragma once
#include "modern_lighting_policy.h"
#include "modern_compute_scope.h"
#include "modern_histogram_source.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <optional>
namespace modernpolicy {
class Meter {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> worker;Ptr<ID3D11ComputeShader> shader;Ptr<ID3D11Buffer> data,constants;Ptr<ID3D11UnorderedAccessView> bins;
 bool init(ID3D11Device* d){if(owner.Get()==d&&shader&&worker&&data&&constants&&bins)return true;if(!d||d->GetFeatureLevel()<D3D_FEATURE_LEVEL_11_0)return false;*this={};owner=d;Ptr<ID3DBlob> code,error;if(FAILED(D3DCompile(histogramSource,sizeof(histogramSource)-1,"RFGRVR luminance histogram",nullptr,nullptr,"main","cs_5_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error)))return false;if(FAILED(d->CreateComputeShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&shader))||FAILED(d->CreateDeferredContext(0,&worker)))return false;
  D3D11_BUFFER_DESC bd{};bd.ByteWidth=1024;bd.BindFlags=D3D11_BIND_UNORDERED_ACCESS;bd.MiscFlags=D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;bd.StructureByteStride=4;if(FAILED(d->CreateBuffer(&bd,nullptr,&data)))return false;D3D11_UNORDERED_ACCESS_VIEW_DESC ud{};ud.ViewDimension=D3D11_UAV_DIMENSION_BUFFER;ud.Buffer.NumElements=256;if(FAILED(d->CreateUnorderedAccessView(data.Get(),&ud,&bins)))return false;bd={};bd.ByteWidth=16;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;return SUCCEEDED(d->CreateBuffer(&bd,nullptr,&constants));
 }
public:
 bool measure(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11ShaderResourceView* input,float scale,unsigned stride=4){
  if(!c||!input||!std::isfinite(scale)||scale<=0||!stride||stride>16)return false;Ptr<ID3D11Device> cd,vd;c->GetDevice(&cd);input->GetDevice(&vd);if(cd.Get()!=d||vd.Get()!=d)return false;D3D11_SHADER_RESOURCE_VIEW_DESC sd{};input->GetDesc(&sd);if(sd.ViewDimension!=D3D11_SRV_DIMENSION_TEXTURE2D||sd.Texture2D.MostDetailedMip||(sd.Format!=DXGI_FORMAT_R11G11B10_FLOAT&&sd.Format!=DXGI_FORMAT_R16G16B16A16_FLOAT&&sd.Format!=DXGI_FORMAT_R32G32B32A32_FLOAT))return false;Ptr<ID3D11Resource> resource;Ptr<ID3D11Texture2D> texture;input->GetResource(&resource);if(FAILED(resource.As(&texture)))return false;D3D11_TEXTURE2D_DESC td{};texture->GetDesc(&td);if(td.SampleDesc.Count!=1||!init(d))return false;
  const bool deferred=c->GetType()==D3D11_DEVICE_CONTEXT_DEFERRED;auto* commands=deferred?c:worker.Get();std::optional<moderncompute::Scope> previous;if(deferred)previous.emplace(c);else commands->ClearState();UINT zero[4]{};commands->ClearUnorderedAccessViewUint(bins.Get(),zero);struct Constants{float scale;unsigned stride,padding[2];}values{scale,stride,{0,0}};commands->UpdateSubresource(constants.Get(),0,nullptr,&values,0,0);auto* cb=constants.Get();commands->CSSetConstantBuffers(0,1,&cb);commands->CSSetShader(shader.Get(),nullptr,0);commands->CSSetShaderResources(0,1,&input);auto* output=bins.Get();commands->CSSetUnorderedAccessViews(0,1,&output,nullptr);commands->Dispatch((td.Width+stride*8-1)/(stride*8),(td.Height+stride*8-1)/(stride*8),1);if(deferred){previous.reset();return true;}Ptr<ID3D11CommandList> list;if(FAILED(commands->FinishCommandList(FALSE,&list)))return false;c->ExecuteCommandList(list.Get(),TRUE);return true;
 }
 ID3D11Buffer* buffer()const{return data.Get();}
};
}
