#pragma once
#include "modern_local_shadows.h"
#include <vector>
#include <array>
#include <cstdint>
namespace modernindirect {
using modernlocal::V;
inline std::array<float,9> basis(V n){n=modernlocal::unit(n);return {.2820947918f,.4886025119f*n.y,.4886025119f*n.z,.4886025119f*n.x,1.0925484306f*n.x*n.y,1.0925484306f*n.y*n.z,.3153915653f*(3*n.z*n.z-1),1.0925484306f*n.x*n.z,.5462742153f*(n.x*n.x-n.y*n.y)};}
// Irradiance SH, already convolved with the cosine kernel. Six world-space
// distance moments provide a bounded visibility estimate, not a guarantee
// against thin-wall leakage. Probes never contain camera-relative lighting.
struct Probe {float coefficients[9][4]{};float distance[6][4]{};};
struct GPUProbe {Probe lighting;float ready[4]{};};
static_assert(sizeof(GPUProbe)==256,"GPU grid row");
static_assert(sizeof(Probe)==240,"GPU probe layout");
inline bool valid(const Probe& p){for(auto& c:p.coefficients)for(float v:c)if(!std::isfinite(v))return false;for(auto& m:p.distance)if(!std::isfinite(m[0])||!std::isfinite(m[1])||m[0]<0||m[1]<m[0]*m[0]-.001f)return false;return true;}
inline V irradiance(const Probe& p,V normal){auto b=basis(normal);V rgb{};for(unsigned i=0;i<9;++i){rgb.x+=p.coefficients[i][0]*b[i];rgb.y+=p.coefficients[i][1]*b[i];rgb.z+=p.coefficients[i][2]*b[i];}return {(std::max)(rgb.x,0.f),(std::max)(rgb.y,0.f),(std::max)(rgb.z,0.f)};}
inline float visibility(const Probe& p,V delta){float d=std::sqrt(modernlocal::dot(delta,delta));auto& moment=p.distance[modernlocal::face(delta)];if(d<=moment[0]+.05f)return 1;float variance=(std::max)(moment[1]-moment[0]*moment[0],0.f),difference=d-moment[0];float chance=variance/(variance+difference*difference);return chance*chance*chance;}
class Grid {
 struct Node {Probe probe{};bool ready=false;uint64_t revision=0,updated=0;};
 std::vector<Node> nodes;V origin{};float spacing=1;unsigned side=0;uint64_t serial=0,updates=0;
 unsigned index(unsigned x,unsigned y,unsigned z)const{return (z*side+y)*side+x;}
public:
 void clear(){bool changed=false;for(auto& node:nodes){changed|=node.ready;node.ready=false;}if(changed)++serial;}
 uint64_t version()const{return serial;}
 bool layout(V& position,float& step,unsigned& size)const{position=origin;step=spacing;size=side;return side>=2;}
 void gpu(std::vector<GPUProbe>& output)const{output.resize(nodes.size());for(unsigned i=0;i<nodes.size();++i){output[i].lighting=nodes[i].probe;output[i].ready[0]=nodes[i].ready?1.f:0.f;}}
 bool contains(unsigned x,unsigned y,unsigned z)const{return x<side&&y<side&&z<side;}
 bool configure(V position,float step,unsigned size){if(size<2||size>16||!std::isfinite(step)||step<.25f||!std::isfinite(position.x)||!std::isfinite(position.y)||!std::isfinite(position.z))return false;origin=position;spacing=step;side=size;nodes.assign(size*size*size,{});++serial;return true;}
 // Shift an integer number of cells, retaining lighting at identical world
 // positions. This is unrelated to the renderer's floating-origin rebasing.
 bool relocate(V next,float step,unsigned size){
  if(!side||step!=spacing||size!=side)return configure(next,step,size);
  float delta[3]={(next.x-origin.x)/spacing,(next.y-origin.y)/spacing,(next.z-origin.z)/spacing};int shift[3];
  for(unsigned k=0;k<3;++k){if(!std::isfinite(delta[k])||std::abs(delta[k])>float(side))return configure(next,step,size);shift[k]=int(std::round(delta[k]));if(std::abs(delta[k]-shift[k])>.0001f)return configure(next,step,size);}
  if(!shift[0]&&!shift[1]&&!shift[2])return true;
  std::vector<Node> retained(nodes.size());
  for(unsigned z=0;z<side;++z)for(unsigned y=0;y<side;++y)for(unsigned x=0;x<side;++x){int old[3]={int(x)+shift[0],int(y)+shift[1],int(z)+shift[2]};if(old[0]>=0&&old[1]>=0&&old[2]>=0&&old[0]<int(side)&&old[1]<int(side)&&old[2]<int(side))retained[index(x,y,z)]=nodes[index(old[0],old[1],old[2])];}
  nodes.swap(retained);origin=next;++serial;return true;
 }
 bool coordinate(V world,unsigned& x,unsigned& y,unsigned& z)const{
  if(!side)return false;float q[3]={(world.x-origin.x)/spacing,(world.y-origin.y)/spacing,(world.z-origin.z)/spacing};unsigned at[3];
  for(unsigned k=0;k<3;++k){if(!std::isfinite(q[k])||q[k]<-.0001f||q[k]>float(side-1)+.0001f)return false;float rounded=std::round(q[k]);if(std::abs(q[k]-rounded)>.0001f)return false;at[k]=unsigned((std::max)(rounded,0.f));}
  x=at[0];y=at[1];z=at[2];return true;
 }
 // Missing nearest nodes first, then oldest valid data. No allocations or
 // scene traversal in selection; each grid is bounded to 16 cubed nodes.
 bool next(V eye,V& where,bool& missing,const modernvisibility::Frustum* view=nullptr,const float* renderOrigin=nullptr)const{
  if(!side||!std::isfinite(eye.x)||!std::isfinite(eye.y)||!std::isfinite(eye.z))return false;
  bool chosen=false;float distance=0;uint64_t oldest=0;bool chosenVisible=false;
  for(unsigned z=0;z<side;++z)for(unsigned y=0;y<side;++y)for(unsigned x=0;x<side;++x){const auto& node=nodes[index(x,y,z)];auto p=position(x,y,z),v=modernlocal::sub(p,eye);float d=modernlocal::dot(v,v);bool absent=!node.ready;float relative[3]={p.x-(renderOrigin?renderOrigin[0]:0),p.y-(renderOrigin?renderOrigin[1]:0),p.z-(renderOrigin?renderOrigin[2]:0)};bool visible=!view||view->intersects(relative,spacing*.5f);
   if(!chosen||(absent&&!missing)||(absent==missing&&(absent?(visible!=chosenVisible?visible:d<distance):node.updated<oldest))){chosen=true;chosenVisible=visible;missing=absent;distance=d;oldest=node.updated;where=p;}}
  return chosen;
 }
 V position(unsigned x,unsigned y,unsigned z)const{return {origin.x+x*spacing,origin.y+y*spacing,origin.z+z*spacing};}
 bool update(unsigned x,unsigned y,unsigned z,const Probe& probe,uint64_t revision){if(x>=side||y>=side||z>=side||!valid(probe))return false;auto& n=nodes[index(x,y,z)];n.probe=probe;n.ready=true;n.revision=revision;n.updated=++updates;++serial;return true;}
 // Destruction invalidates only probes whose support reaches the changed box.
 // No scan of scene objects or allocation occurs during a lighting query.
 unsigned invalidate(V lo,V hi){unsigned count=0;for(unsigned z=0;z<side;++z)for(unsigned y=0;y<side;++y)for(unsigned x=0;x<side;++x){V p=position(x,y,z);if(p.x>=lo.x-spacing&&p.x<=hi.x+spacing&&p.y>=lo.y-spacing&&p.y<=hi.y+spacing&&p.z>=lo.z-spacing&&p.z<=hi.z+spacing){auto& n=nodes[index(x,y,z)];if(n.ready){n.ready=false;++count;}}}if(count)++serial;return count;}
 struct Result {V irradiance{};float confidence=0;};
 Result query(V world,V normal)const{
  Result result;if(!side||!std::isfinite(world.x)||!std::isfinite(world.y)||!std::isfinite(world.z))return result;
  float q[3]={(world.x-origin.x)/spacing,(world.y-origin.y)/spacing,(world.z-origin.z)/spacing};int cell[3];float fraction[3];for(unsigned i=0;i<3;++i){if(!std::isfinite(q[i])||q[i]<0||q[i]>side-1)return result;cell[i]=(std::min)(int(std::floor(q[i])),int(side)-2);fraction[i]=q[i]-cell[i];}
  float total=0;for(unsigned z=0;z<2;++z)for(unsigned y=0;y<2;++y)for(unsigned x=0;x<2;++x){unsigned ix=cell[0]+x,iy=cell[1]+y,iz=cell[2]+z;const auto& n=nodes[index(ix,iy,iz)];if(!n.ready)continue;V delta=modernlocal::sub(world,position(ix,iy,iz));float weight=(x?fraction[0]:1-fraction[0])*(y?fraction[1]:1-fraction[1])*(z?fraction[2]:1-fraction[2]);weight*=visibility(n.probe,delta);V sample=irradiance(n.probe,normal);result.irradiance.x+=weight*sample.x;result.irradiance.y+=weight*sample.y;result.irradiance.z+=weight*sample.z;total+=weight;}
  if(total>1e-6f){result.irradiance.x/=total;result.irradiance.y/=total;result.irradiance.z/=total;result.confidence=(std::min)(total,1.f);}return result;
 }
};
}
