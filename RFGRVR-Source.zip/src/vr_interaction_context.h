#pragma once
#include <atomic>
#include <cstdint>
#include <cmath>
namespace vrinteraction {
// Native messages document has separate use and weapon-swap trees.
inline bool group(uint32_t hash){return hash==0xd603f74bu||hash==0x2828844eu;}
inline bool visible(bool shown,float own,float parent){return shown&&std::isfinite(own)&&std::isfinite(parent)&&own*parent>.05f;}
inline std::atomic<uint32_t> visibleTick{0};
inline void sample(bool visible,uint32_t now){visibleTick.store(visible?now:0,std::memory_order_relaxed);}
inline bool available(uint32_t now){auto tick=visibleTick.load(std::memory_order_relaxed);return tick&&uint32_t(now-tick)<250;}
}
