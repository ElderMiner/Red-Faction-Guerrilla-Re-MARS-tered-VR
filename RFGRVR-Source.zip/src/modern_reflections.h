#pragma once
#include "modern_reflections_source.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <algorithm>
namespace modernreflection {
class Filter {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> worker;Ptr<ID3D11ComputeShader> shader;Ptr<ID3D11Buffer> constants;Ptr<ID3D11SamplerState> sampler;
 Ptr<ID3D11Texture2D> output;Ptr<ID3D11ShaderResourceView> view;Ptr<ID3D11UnorderedAccessView> mips[10];unsigned size=0,levels=0;
 bool init(ID3D11Device* d,unsigned width){bool ready=owner.Get()==d&&size==width&&view&&shader&&constants&&sampler&&worker;for(unsigned i=0;i<levels;++i)ready=ready&&bool(mips[i]);if(ready)return true;if(!d||d->GetFeatureLevel()<D3D_FEATURE_LEVEL_11_0||width<8||width>512||(width&(width-1)))return false;*this={};owner=d;size=width;for(unsigned n=width;n;n>>=1)++levels;
  Ptr<ID3DBlob> code,error;if(FAILED(D3DCompile(reflectionSource,sizeof(reflectionSource)-1,"RFGRVR GGX environment filter",nullptr,nullptr,"main","cs_5_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error)))return false;
  if(FAILED(d->CreateComputeShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&shader))||FAILED(d->CreateDeferredContext(0,&worker)))return false;D3D11_BUFFER_DESC bd{};bd.ByteWidth=16;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;if(FAILED(d->CreateBuffer(&bd,nullptr,&constants)))return false;D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.MaxLOD=D3D11_FLOAT32_MAX;if(FAILED(d->CreateSamplerState(&sd,&sampler)))return false;
  D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=width;td.MipLevels=levels;td.ArraySize=6;td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R16G16B16A16_FLOAT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_UNORDERED_ACCESS;td.MiscFlags=D3D11_RESOURCE_MISC_TEXTURECUBE;if(FAILED(d->CreateTexture2D(&td,nullptr,&output)))return false;D3D11_SHADER_RESOURCE_VIEW_DESC vd{};vd.Format=td.Format;vd.ViewDimension=D3D11_SRV_DIMENSION_TEXTURECUBE;vd.TextureCube.MipLevels=levels;if(FAILED(d->CreateShaderResourceView(output.Get(),&vd,&view)))return false;
  for(unsigned i=0;i<levels;++i){D3D11_UNORDERED_ACCESS_VIEW_DESC ud{};ud.Format=td.Format;ud.ViewDimension=D3D11_UAV_DIMENSION_TEXTURE2DARRAY;ud.Texture2DArray.MipSlice=i;ud.Texture2DArray.ArraySize=6;if(FAILED(d->CreateUnorderedAccessView(output.Get(),&ud,&mips[i])))return false;}return true;
 }
public:
 bool filter(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11ShaderResourceView* input,unsigned resolution=128,unsigned samples=64){
  if(!c||!input||c->GetType()!=D3D11_DEVICE_CONTEXT_IMMEDIATE||samples<16||samples>256)return false;Ptr<ID3D11Device> cd,vd;c->GetDevice(&cd);input->GetDevice(&vd);if(cd.Get()!=d||vd.Get()!=d)return false;D3D11_SHADER_RESOURCE_VIEW_DESC sd{};input->GetDesc(&sd);if(sd.ViewDimension!=D3D11_SRV_DIMENSION_TEXTURECUBE||(sd.Format!=DXGI_FORMAT_R11G11B10_FLOAT&&sd.Format!=DXGI_FORMAT_R16G16B16A16_FLOAT&&sd.Format!=DXGI_FORMAT_R32G32B32A32_FLOAT))return false;Ptr<ID3D11Resource> resource;Ptr<ID3D11Texture2D> texture;input->GetResource(&resource);if(FAILED(resource.As(&texture))||!init(d,resolution)||resource.Get()==output.Get())return false;D3D11_TEXTURE2D_DESC td{};texture->GetDesc(&td);
  worker->ClearState();worker->CSSetShader(shader.Get(),nullptr,0);worker->CSSetShaderResources(0,1,&input);auto* s=sampler.Get();worker->CSSetSamplers(0,1,&s);auto* cb=constants.Get();worker->CSSetConstantBuffers(0,1,&cb);
  for(unsigned mip=0;mip<levels;++mip){unsigned n=(std::max)(resolution>>mip,1u);struct Settings{unsigned size,samples;float roughness,sourceSize;}settings{n,samples,float(mip)/(levels-1),float(td.Width>>sd.TextureCube.MostDetailedMip)};worker->UpdateSubresource(constants.Get(),0,nullptr,&settings,0,0);auto* target=mips[mip].Get();worker->CSSetUnorderedAccessViews(0,1,&target,nullptr);worker->Dispatch((n+7)/8,(n+7)/8,6);}
  Ptr<ID3D11CommandList> commands;if(FAILED(worker->FinishCommandList(FALSE,&commands)))return false;c->ExecuteCommandList(commands.Get(),TRUE);return true;
 }
 ID3D11ShaderResourceView* resource()const{return view.Get();}
 unsigned mipLevels()const{return levels;}
};
}
