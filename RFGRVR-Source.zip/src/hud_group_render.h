#include "vr_native_reticles.h"
#include "vr_hud_visibility.h"
#include "vr_mission_timer.h"
#include "vr_interaction_context.h"
#include "vr_menu_aspect.h"
#include "vr_memory_access.h"
#include "vr_user_settings.h"
// Reusable isolated native HUD-group capture; configured by wrist_map_render.h.
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <atomic>
#include <vector>
#include <cmath>
#include <cstring>
#include <cstdio>
#include "wrist_map_geometry.h"
#include "wrist_map_protocol.h"
#include "vr_eye_pipeline.h"
#include "main_menu_capture.h"
#include "weapon_scope.h"
#include "../vendor/MinHook.h"
extern "C" bool RFGRVR_HeadCam_IsAuxiliary();
namespace RFGR_HUD_NAMESPACE {
using Microsoft::WRL::ComPtr;using vrwrist::Vertex;using vrwrist::Bounds;
inline constexpr bool MissionCapture=RFGR_HUD_FIRST==87376u;
inline constexpr bool ScopeCapture=RFGR_HUD_FIRST==152908u;inline std::atomic<int> scopeContentKind{-1};inline std::atomic<DWORD> scopeDrawTick{0};inline ComPtr<ID3D11ShaderResourceView> nativeScopeView;
inline constexpr bool MainMenuCapture=RFGR_HUD_FIRST==196596u||RFGR_HUD_FIRST==218440u;inline constexpr bool MenuCapture=RFGR_HUD_FIRST==152908u||MainMenuCapture;inline constexpr unsigned CanvasWidth=RFGR_HUD_FIRST==218440u?3840u:RFGR_HUD_FIRST==196596u?1920u:MenuCapture?1024u:RFGR_WRIST_SIZE;inline constexpr unsigned CanvasHeight=RFGR_HUD_FIRST==218440u?2160u:RFGR_HUD_FIRST==196596u?1080u:MenuCapture?1024u:RFGR_WRIST_SIZE;inline constexpr unsigned VertexBytes=MenuCapture?2097152u:65536u;
using Draw=void(__thiscall*)(void*,const void*,void*,unsigned);using Alloc=void*(__thiscall*)(void*,unsigned,const void*);using Emit=void(__thiscall*)(void*,unsigned,unsigned,const void*,unsigned);using Flush=void(__thiscall*)(void*,const void*,void*);
inline Draw originalDraw=nullptr;inline Alloc originalAlloc=nullptr;inline Emit originalEmit=nullptr;inline Flush originalFlush=nullptr;
inline void log(const char* text){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* s=strrchr(path,92);if(!s)return;strcpy_s(s+1,MAX_PATH-(s+1-path),"RFGRVR-WristMap.log");FILE* f=nullptr;if(!fopen_s(&f,path,"a")&&f){fprintf(f,"%lu %s\n",GetTickCount(),text);fclose(f);}}
inline bool installed=false;inline thread_local bool inside=false,replaying=false;
struct Chunk {Vertex* data;unsigned count,flags;};inline thread_local Chunk chunks[512];inline thread_local unsigned chunkCount=0;
struct Meta {unsigned epoch=0;Bounds bounds{};float width=0,height=0;int nativeKind=-1;unsigned canvasFrame=0;};inline thread_local int matchingScopeKind=-1;inline Meta metadata[16];inline SRWLOCK metaLock=SRWLOCK_INIT,gpuLock=SRWLOCK_INIT;inline std::atomic<unsigned> sequence{0};inline std::atomic<unsigned> menuFrameEpoch{0};
inline ComPtr<ID3D11Texture2D> canvas,depth,sharedTexture;inline ComPtr<ID3D11RenderTargetView> target;inline ComPtr<ID3D11DepthStencilView> depthView;inline ComPtr<IDXGIKeyedMutex> mutex;inline ComPtr<ID3D11Device> owner;
struct PrivateVertices {ID3D11DeviceContext* context=nullptr;ComPtr<ID3D11Buffer> buffer;unsigned epoch=0,writeOffset=0,discards=0,noOverwrite=0;};inline std::vector<PrivateVertices> privateVertices;inline std::atomic<bool> uploadsExist{false};
struct AlphaBlend {ComPtr<ID3D11BlendState> native,corrected;};inline std::vector<AlphaBlend> alphaBlends;
inline ID3D11BlendState* captureBlend(ID3D11BlendState* native){if((RFGR_HUD_FIRST!=43688u&&RFGR_HUD_FIRST!=65532u&&RFGR_HUD_FIRST!=87376u&&RFGR_HUD_FIRST!=109220u&&RFGR_HUD_FIRST!=174752u&&RFGR_HUD_FIRST!=240284u&&RFGR_HUD_FIRST!=262128u&&!MenuCapture)||!native)return native;for(auto& entry:alphaBlends)if(entry.native.Get()==native)return entry.corrected.Get();if(alphaBlends.size()>=32)return native;D3D11_BLEND_DESC d{};native->GetDesc(&d);for(auto& rt:d.RenderTarget){if(!rt.BlendEnable)continue;rt.SrcBlendAlpha=D3D11_BLEND_ONE;rt.DestBlendAlpha=D3D11_BLEND_INV_SRC_ALPHA;rt.BlendOpAlpha=D3D11_BLEND_OP_ADD;}AlphaBlend entry;entry.native=native;if(FAILED(owner->CreateBlendState(&d,&entry.corrected)))return native;alphaBlends.push_back(entry);return alphaBlends.back().corrected.Get();}
inline unsigned capturedWidth=0,capturedHeight=0;
inline HANDLE mapping=nullptr;inline RFGRGpuShared* channel=nullptr;inline unsigned drawnEpoch=0,publishedEpoch=0;inline LONG lastAck=0;inline DWORD ackTick=0;inline std::atomic<DWORD> consumerTick{0};inline thread_local DWORD lastGroupUpdate=0;
inline bool readable(const void* p,size_t n){return vrmemory::check(p,n); }
inline void* pointer(const void* p,unsigned off){void* out=nullptr;if(readable((const char*)p+off,4))memcpy(&out,(const char*)p+off,4);return out;}
inline bool enabled(){static DWORD checked=0;static bool value=false;DWORD now=GetTickCount();if(now-checked>1000||!checked){checked=now;wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* s=wcsrchr(path,L'\\');if(s){wcscpy_s(s+1,MAX_PATH-(s+1-path),L"RFGRVR-wrist-map.enable");value=GetFileAttributesW(path)!=INVALID_FILE_ATTRIBUTES;}}return value;}
inline unsigned activeCanvasWidth=CanvasWidth,activeCanvasHeight=CanvasHeight;inline DWORD resizeRetry=0;
inline bool setup(ID3D11DeviceContext* ctx){ComPtr<ID3D11Device> device;ctx->GetDevice(&device);
 unsigned width=CanvasWidth,height=CanvasHeight;
 if constexpr(RFGR_HUD_FIRST==218440u){if(RFGRVRMenuLayout::active.load()||RFGRVRMenuLayout::popupActive.load()){width=6144;height=3456;}}
 if(canvas&&owner!=device)return false;
 if(canvas&&activeCanvasWidth==width&&activeCanvasHeight==height)return target.Get()&&depthView.Get()&&mutex.Get()&&channel;
 if(resizeRetry&&GetTickCount()-resizeRetry<5000)return canvas.Get()!=nullptr;
 ComPtr<ID3D11Texture2D> nextCanvas,nextDepth,nextShared;ComPtr<ID3D11RenderTargetView> nextTarget;ComPtr<ID3D11DepthStencilView> nextDepthView;ComPtr<IDXGIKeyedMutex> nextMutex;
 auto failed=[&](){resizeRetry=GetTickCount();return canvas.Get()!=nullptr;};
 D3D11_TEXTURE2D_DESC d{};d.Width=width;d.Height=height;d.MipLevels=d.ArraySize=d.SampleDesc.Count=1;d.Format=DXGI_FORMAT_B8G8R8A8_UNORM;d.Usage=D3D11_USAGE_DEFAULT;d.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;
 if(FAILED(device->CreateTexture2D(&d,nullptr,&nextCanvas))||FAILED(device->CreateRenderTargetView(nextCanvas.Get(),nullptr,&nextTarget)))return failed();
 d.Format=DXGI_FORMAT_D24_UNORM_S8_UINT;d.BindFlags=D3D11_BIND_DEPTH_STENCIL;if(FAILED(device->CreateTexture2D(&d,nullptr,&nextDepth))||FAILED(device->CreateDepthStencilView(nextDepth.Get(),nullptr,&nextDepthView)))return failed();
 d.Format=DXGI_FORMAT_B8G8R8A8_UNORM;d.BindFlags=D3D11_BIND_SHADER_RESOURCE;d.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;if(FAILED(device->CreateTexture2D(&d,nullptr,&nextShared))||FAILED(nextShared.As(&nextMutex)))return failed();
 ComPtr<IDXGIResource> resource;HANDLE handle=nullptr;if(FAILED(nextShared.As(&resource))||FAILED(resource->GetSharedHandle(&handle)))return failed();
 if(!mapping)mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRGpuShared),RFGR_HUD_CHANNEL);if(!mapping)return failed();if(!channel)channel=(RFGRGpuShared*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRGpuShared));if(!channel)return failed();
 InterlockedExchange(&channel->ready,0);canvas=nextCanvas;depth=nextDepth;sharedTexture=nextShared;target=nextTarget;depthView=nextDepthView;mutex=nextMutex;owner=device;activeCanvasWidth=width;activeCanvasHeight=height;resizeRetry=0;drawnEpoch=publishedEpoch=0;lastAck=0;consumerTick.store(0);
 ZeroMemory(channel,sizeof(*channel));channel->magic=RFGR_GPU_MAGIC;channel->version=1;channel->width=width;channel->height=height;channel->format=DXGI_FORMAT_B8G8R8A8_UNORM;channel->legacyShareHandle=(uint64_t)(uintptr_t)handle;MemoryBarrier();InterlockedExchange(&channel->ready,1);char message[100];sprintf_s(message,"HUD texture ready: %ux%u",width,height);log(message);return true;
}
inline bool consumerFresh(){if(!channel)return false;LONG ack=channel->acknowledged;if(ack!=lastAck){lastAck=ack;ackTick=GetTickCount();consumerTick.store(ackTick);}return ack&&GetTickCount()-ackTick<500;}
inline thread_local Chunk pending{};inline thread_local bool pendingValid=false,activeGroup=false;inline thread_local Meta currentMeta{};inline thread_local void* allocationOwner=nullptr;inline thread_local const void* allocationState=nullptr;inline Bounds cachedBounds{};inline bool boundsReady=false;
inline Bounds missionBounds[4]{};inline bool missionBoundsReady[4]{};inline thread_local vrwrist::FrameGate missionGate{};inline thread_local unsigned missionKind=0;inline unsigned drawnCanvasFrame=0;
inline Bounds groupBounds{};inline bool groupBoundsReady=false;
inline void completePending(){if(!inside||!pendingValid)return;pendingValid=false;auto& c=pending;if(!readable(c.data,c.count*sizeof(Vertex)))return;
 bool fullScreenClip=false;if constexpr(RFGR_HUD_FIRST==109220u){if(c.count==4&&currentMeta.width>0&&currentMeta.height>0){Bounds b{c.data[0].x,c.data[0].y,c.data[0].x,c.data[0].y};for(unsigned j=1;j<4;++j){b.left=(std::min)(b.left,c.data[j].x);b.right=(std::max)(b.right,c.data[j].x);b.top=(std::min)(b.top,c.data[j].y);b.bottom=(std::max)(b.bottom,c.data[j].y);}fullScreenClip=b.right-b.left>=currentMeta.width*.9f&&b.bottom-b.top>=currentMeta.height*.9f;}}
 if(RFGR_HUD_FIRST&&!fullScreenClip){for(unsigned j=0;j<c.count;++j){const auto& v=c.data[j];if(!std::isfinite(v.x)||!std::isfinite(v.y)||vrwrist::epoch(v)||(v.color>>24)==0)continue;if(!groupBoundsReady){groupBounds={v.x,v.y,v.x,v.y};groupBoundsReady=true;}else{groupBounds.left=(std::min)(groupBounds.left,v.x);groupBounds.right=(std::max)(groupBounds.right,v.x);groupBounds.top=(std::min)(groupBounds.top,v.y);groupBounds.bottom=(std::max)(groupBounds.bottom,v.y);}}}
 if(!RFGR_HUD_FIRST&&(c.flags&0xffffu)==0x202u&&c.count==4){Bounds b{c.data[0].x,c.data[0].y,c.data[0].x,c.data[0].y};for(unsigned j=1;j<4;++j){b.left=(std::min)(b.left,c.data[j].x);b.top=(std::min)(b.top,c.data[j].y);b.right=(std::max)(b.right,c.data[j].x);b.bottom=(std::max)(b.bottom,c.data[j].y);}if(b.right-b.left>80&&b.bottom-b.top>80){float padding=(b.right-b.left)*.13f;cachedBounds={b.left-padding,b.top-padding,b.right+padding,b.bottom+padding};if(!boundsReady)log("Native map mask located; wrist routing begins next traversal");boundsReady=true;}}
 if(activeGroup)for(unsigned j=0;j<c.count;++j)if(!vrwrist::epoch(c.data[j]))vrwrist::mark(c.data[j],currentMeta.epoch);
}
inline void __fastcall flush(void* self,void*,const void* state,void* renderer){completePending();originalFlush(self,state,renderer);}
inline void* __fastcall alloc(void* self,void*,unsigned n,const void* state){completePending();void* result=originalAlloc(self,n,state);if(inside&&n&&n<(MenuCapture?65536u:4096u)&&readable(result,n*sizeof(Vertex))&&readable(state,64)){unsigned flags=0;memcpy(&flags,(const char*)state+60,4);pending={(Vertex*)result,n,flags};pendingValid=true;allocationOwner=self;allocationState=state;}return result;}
inline unsigned wordDocHash(void* object){void* doc=pointer(object,0x28);unsigned hash=0;if(readable((char*)doc+0x2c,4))memcpy(&hash,(char*)doc+0x2c,4);return hash;}
inline void __fastcall draw(void* object,void*,const void* state,void* scratch,unsigned capacity){vrmemory::Scope memoryScope;if constexpr(RFGR_HUD_FIRST==0u){if(object){unsigned hash=0;memcpy(&hash,(char*)object+0x24,4);if(vrreticles::crosshairHash(hash)&&enabled()){void* doc=pointer(object,0x28);if(readable((char*)doc+9,sizeof("rfg_ui_hud_reticles"))&&vrreticles::flatCrosshair(hash,(char*)doc+9))return;}}}if(RFGRVR_HeadCam_IsAuxiliary())return;
 if constexpr(RFGR_HUD_FIRST==218440u)if(vrsettings::uiOpen())return;
 if constexpr(ScopeCapture){if(inside&&matchingScopeKind==1&&object){unsigned hash=0;memcpy(&hash,(char*)object+0x24,4);if(hash==0x25122346u||hash==0x81feeedbu||hash==0x5f5abbe8u||hash==0xf2fce70eu||hash==0x94714eb3u||hash==0x97208a21u||hash==0x9f168ec5u||hash==0xba4f208bu||hash==0x23467131u||hash==0x544141a7u||hash==0xca25d404u)return;}}
 // Native traversal already owns a valid object (it reads +16C). Do not
 // make a kernel memory query for every UI node, including unrelated HUD.
 if((ScopeCapture&&vrscope::nativeVisualKind.load()<0)||((RFGR_HUD_FIRST!=218440u&&RFGR_HUD_FIRST!=196596u)&&RFGRVRMenuLayout::active.load(std::memory_order_relaxed))||(RFGR_HUD_FIRST!=218440u&&RFGRVRMenuLayout::popupActive.load(std::memory_order_relaxed))||(MenuCapture&&!MainMenuCapture&&!ScopeCapture)||!installed||inside||!object||(MainMenuCapture&&!RFGRVR_HeadCam_MenuScene()&&!RFGRVR_HeadCam_PopupMenu())){originalDraw(object,state,scratch,capacity);return;}
 unsigned hash=0;memcpy(&hash,(char*)object+0x24,4);
 bool match=hash==RFGR_HUD_HASH;if constexpr(MissionCapture){missionKind=hash==0x6b70456eu?1u:hash==0x183d2fe6u?2u:hash==vrmissiontimer::Group&&vrmissiontimer::active(object)?3u:0u;match=match||missionKind!=0;}if constexpr(ScopeCapture){void* doc=pointer(object,0x28);int kind=-1;
 if(readable((char*)doc+9,32)){const char* name=(char*)doc+9;if(!memcmp(name,"rfg_ui_sniper",sizeof("rfg_ui_sniper")))kind=0;else if(!memcmp(name,"rfg_ui_raildriver",sizeof("rfg_ui_raildriver")))kind=1;}
 match=kind>=0;if(match)matchingScopeKind=kind;
 if constexpr(ScopeCapture){static std::atomic<unsigned> reports{0};static thread_local void* previous=nullptr;if(doc!=previous&&reports.load()<12){previous=doc;if(reports.fetch_add(1)<12){char note[180];if(readable((char*)doc+9,32))sprintf_s(note,"Native scope document: ptr=%p hash=%08X name=%.31s kind=%d",doc,wordDocHash(object),(char*)doc+9,kind);else sprintf_s(note,"Native scope document: ptr=%p unreadable kind=%d",doc,kind);log(note);}}}

 }else if constexpr(MenuCapture&&!MainMenuCapture){void* document=nullptr;memcpy(&document,(char*)object+0x28,4);struct DocCache{void* doc=nullptr;unsigned hash=0;DWORD tick=0;};static thread_local DocCache docs[16]{};unsigned docHash=0;DWORD now=GetTickCount();auto& cache=docs[((uintptr_t)document>>5)%16];if(cache.doc!=document||DWORD(now-cache.tick)>1000){cache={document,0,now};if(readable((char*)document+0x2c,4))memcpy(&cache.hash,(char*)document+0x2c,4);}docHash=cache.hash;match=docHash==0x72610944u||docHash==0x6b3f6619u;}if constexpr(MainMenuCapture){if constexpr(RFGR_HUD_FIRST==196596u)match=RFGRVR_HeadCam_MenuScene()&&hash==0x9be242beu;else if(RFGRVR_HeadCam_PopupMenu())match=true;else if(wordDocHash(object)!=0x5b385f05u)match=true;else match=pointer(object,0x14)==nullptr&&hash!=0x9be242beu&&hash!=0x1332cff0u&&hash!=0xfaa82ec6u&&hash!=0x54cfe0acu&&hash!=0x0;}
 if constexpr(RFGR_HUD_FIRST==65532u){match=vrinteraction::group(hash);if(match&&readable((char*)object+0x160,13)&&readable((char*)state+0x50,4)){float own=0,parent=0;memcpy(&own,(char*)object+0x160,4);memcpy(&parent,(char*)state+0x50,4);if(!vrinteraction::visible(*((unsigned char*)object+0x16c)!=0,own,parent)){originalDraw(object,state,scratch,capacity);return;}vrinteraction::sample(true,GetTickCount());}}
 if(!match||!enabled()){originalDraw(object,state,scratch,capacity);return;}
#ifdef RFGRVR_DEVELOPER_TOOLS
 const bool showNative=!MenuCapture&&RFGR_HUD_FIRST!=131064u&&vrsettings::hudPreview();
 RFGRHudVisibility previewVisibility(object,state,showNative&&readable((char*)object+0x160,13)&&readable(state,0x94));state=previewVisibility.input;
#endif
 // Map contents need 30Hz; its OpenXR wrist pose still updates every XR frame.
 DWORD now=GetTickCount(),confirmed=consumerTick.load();bool fresh=confirmed&&now-confirmed<500;
 if constexpr(MissionCapture){auto* base=(char*)GetModuleHandleW(nullptr);void* frame=pointer(base,0x1637910);if(!readable((char*)frame+0x6dc,4))return;unsigned frameId=0;memcpy(&frameId,(char*)frame+0x6dc,4);if(!missionGate.update(frameId,now,fresh))return;}
 else {if(!MenuCapture&&!vrwrist::updateDue(now,lastGroupUpdate,fresh))return;lastGroupUpdate=now;}
 activeGroup=false;currentMeta={};if constexpr(MissionCapture)currentMeta.nativeKind=int(missionKind);if constexpr(ScopeCapture)currentMeta.nativeKind=matchingScopeKind;auto* base=(char*)GetModuleHandleW(nullptr);void* frame=pointer(base,0x1637910);if(readable((char*)frame+0x73c,8)){int sizes[2];memcpy(sizes,(char*)frame+0x73c,8);currentMeta.width=float(sizes[0]);currentMeta.height=float(sizes[1]);if(currentMeta.width>=320&&currentMeta.height>=200&&((MissionCapture?missionBoundsReady[missionKind]:boundsReady)||MenuCapture)){currentMeta.bounds=MenuCapture?Bounds{0,0,currentMeta.width,currentMeta.height}:MissionCapture?missionBounds[missionKind]:cachedBounds;if constexpr(MissionCapture){unsigned frameId=0;memcpy(&frameId,(char*)frame+0x6dc,4);currentMeta.canvasFrame=frameId+1;}currentMeta.epoch=MenuCapture?menuFrameEpoch.load():0;if(!currentMeta.epoch){currentMeta.epoch=sequence.fetch_add(1)%21844+1+RFGR_HUD_FIRST;if(MenuCapture)menuFrameEpoch=currentMeta.epoch;}AcquireSRWLockExclusive(&metaLock);metadata[currentMeta.epoch%16]=currentMeta;ReleaseSRWLockExclusive(&metaLock);activeGroup=true;}}
 // Preserve native visibility and tween alpha: these are transient updates, not persistent gauges.
 groupBoundsReady=false;inside=true;pendingValid=false;allocationOwner=nullptr;allocationState=nullptr;originalDraw(object,state,scratch,capacity);completePending();
 // Seal the group's last queued batch while its marker metadata is current.
 // This is the same flush call (state,nullptr) made by the native allocator.
 if(activeGroup&&allocationOwner&&allocationState)originalFlush(allocationOwner,allocationState,nullptr);inside=false;
 if constexpr(RFGR_HUD_FIRST==65532u)if(!groupBoundsReady)vrinteraction::sample(false,GetTickCount());
 if(!MenuCapture&&RFGR_HUD_FIRST&&groupBoundsReady&&groupBounds.right-groupBounds.left>1&&groupBounds.bottom-groupBounds.top>1){float pad=4;cachedBounds={groupBounds.left-pad,groupBounds.top-pad,groupBounds.right+pad,groupBounds.bottom+pad};float ratio=RFGR_HUD_FIRST==131064u?1.f:RFGR_HUD_FIRST==21844u?3.f:RFGR_HUD_FIRST==65532u?2.f:MissionCapture&&missionKind==1?2.5f:4.f;float width=cachedBounds.right-cachedBounds.left,height=cachedBounds.bottom-cachedBounds.top,cx=(cachedBounds.left+cachedBounds.right)*.5f,cy=(cachedBounds.top+cachedBounds.bottom)*.5f;if(width<height*ratio)width=height*ratio;else height=width/ratio;cachedBounds={cx-width*.5f,cy-height*.5f,cx+width*.5f,cy+height*.5f};boundsReady=true;if constexpr(MissionCapture){missionBounds[missionKind]=cachedBounds;missionBoundsReady[missionKind]=true;}}

}
inline void __fastcall emit(void* renderer,void*,unsigned type,unsigned primitives,const void* data,unsigned stride){
 vrmemory::Scope memoryScope;
 if(replaying||stride!=sizeof(Vertex)||!data||primitives>16384){originalEmit(renderer,type,primitives,data,stride);return;}
 unsigned n=vrwrist::vertexCount(type,primitives);if(!n||!readable(data,n*stride)){originalEmit(renderer,type,primitives,data,stride);return;}const auto* vertices=(const Vertex*)data;unsigned epoch=0;for(unsigned i=0;i<n;++i)if((epoch=vrwrist::epoch(vertices[i])))break;if(!epoch||epoch<=RFGR_HUD_FIRST||epoch>RFGR_HUD_FIRST+21844){originalEmit(renderer,type,primitives,data,stride);return;}
 Meta meta;AcquireSRWLockShared(&metaLock);meta=metadata[epoch%16];ReleaseSRWLockShared(&metaLock);if(meta.epoch!=epoch){std::vector<Vertex> restored(vertices,vertices+n);float width=meta.width>=320?meta.width:1920.f;for(auto& v:restored)if(vrwrist::epoch(v))v=vrwrist::restore(v,width);originalEmit(renderer,type,primitives,restored.data(),stride);return;}
 void* writer=pointer(renderer,0x440);void* commands=pointer(writer,0);auto* ctx=(ID3D11DeviceContext*)pointer(commands,0);if(!ctx){originalEmit(renderer,type,primitives,data,stride);return;}
 AcquireSRWLockExclusive(&gpuLock);bool ready=setup(ctx);std::vector<Vertex> selected;vrwrist::triangles(vertices,type,primitives,epoch,selected);if(selected.size()*sizeof(Vertex)>VertexBytes)selected.clear();bool isolatedPopup=RFGR_HUD_FIRST==218440u&&RFGRVRMenuLayout::popupActive.load(std::memory_order_relaxed);bool hide=(!MainMenuCapture||isolatedPopup)&&ready&&!selected.empty()&&(ScopeCapture||consumerFresh());std::vector<Vertex> normal;if(!hide){normal.assign(vertices,vertices+n);for(auto& v:normal)if(vrwrist::epoch(v))v=vrwrist::restore(v,meta.width);}
 originalEmit(renderer,type,primitives,hide?data:normal.data(),stride);
 if(ready&&!selected.empty()){
  RFGRVRBindings<ID3D11RenderTargetView,8> oldTargets;ComPtr<ID3D11DepthStencilView> oldDepth;ctx->OMGetRenderTargets(8,oldTargets.p,&oldDepth);D3D11_VIEWPORT viewports[16]{};UINT views=16;ctx->RSGetViewports(&views,viewports);D3D11_RECT clips[16]{};UINT clipCount=16;ctx->RSGetScissorRects(&clipCount,clips);
  if(MissionCapture?(!drawnEpoch||drawnCanvasFrame!=meta.canvasFrame):drawnEpoch!=epoch){if(!drawnEpoch){char text[180];sprintf_s(text,"First native wrist draw: primitive=%u triangles=%u canvas=%.0fx%.0f bounds=%.1f/%.1f/%.1f/%.1f",type,unsigned(selected.size()/3),meta.width,meta.height,meta.bounds.left,meta.bounds.top,meta.bounds.right,meta.bounds.bottom);log(text);}FLOAT clear[4]{};ctx->ClearRenderTargetView(target.Get(),clear);ctx->ClearDepthStencilView(depthView.Get(),D3D11_CLEAR_DEPTH|D3D11_CLEAR_STENCIL,1,0);drawnCanvasFrame=meta.canvasFrame;capturedWidth=unsigned(meta.width);capturedHeight=unsigned(meta.height);}
  drawnEpoch=epoch;ID3D11RenderTargetView* rt=target.Get();ctx->OMSetRenderTargets(1,&rt,depthView.Get());D3D11_VIEWPORT viewport{0,0,float(activeCanvasWidth),float(activeCanvasHeight),0,1};if constexpr(MissionCapture){viewport.TopLeftY=meta.nativeKind>=2?0.f:meta.nativeKind==1?128.f:384.f;viewport.Height=meta.nativeKind==1?204.8f:128.f;}ctx->RSSetViewports(1,&viewport);
  D3D11_RECT remapped[16]{};for(unsigned i=0;i<clipCount;++i){auto scaleX=[&](LONG x){return LONG(std::floor((float(x)-meta.bounds.left)/(meta.bounds.right-meta.bounds.left)*activeCanvasWidth));};auto scaleY=[&](LONG y){return LONG(std::floor(viewport.TopLeftY+(float(y)-meta.bounds.top)/(meta.bounds.bottom-meta.bounds.top)*viewport.Height));};remapped[i]={scaleX(clips[i].left),scaleY(clips[i].top),scaleX(clips[i].right),scaleY(clips[i].bottom)};}ctx->RSSetScissorRects(clipCount,remapped);
  // Replaying through the engine emitter advances its shared scratch pool.
  // Wrist geometry owns a dynamic buffer instead; the native draw runs once.
  PrivateVertices* storage=nullptr;for(auto& entry:privateVertices)if(entry.context==ctx){storage=&entry;break;}
  if(!storage&&privateVertices.size()<32){PrivateVertices entry;entry.context=ctx;D3D11_BUFFER_DESC bd{};bd.ByteWidth=VertexBytes;bd.Usage=D3D11_USAGE_DYNAMIC;bd.BindFlags=D3D11_BIND_VERTEX_BUFFER;bd.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;if(SUCCEEDED(owner->CreateBuffer(&bd,nullptr,&entry.buffer))){privateVertices.push_back(entry);storage=&privateVertices.back();uploadsExist=true;}}
  if(storage){unsigned bytes=unsigned(selected.size()*sizeof(Vertex));bool discard=storage->epoch!=epoch||storage->writeOffset+bytes>VertexBytes;unsigned offset=discard?0:storage->writeOffset;D3D11_MAP mode=discard?D3D11_MAP_WRITE_DISCARD:D3D11_MAP_WRITE_NO_OVERWRITE;D3D11_MAPPED_SUBRESOURCE mapped{};if(SUCCEEDED(ctx->Map(storage->buffer.Get(),0,mode,0,&mapped))){for(auto& v:selected){v=vrwrist::project(v,meta.bounds,meta.width,meta.height);if(RFGR_HUD_FIRST==43688u){unsigned alpha=v.color>>24;if(alpha&&alpha<90)v.color=(v.color&0x00ffffffu)|(90u<<24);}}memcpy((char*)mapped.pData+offset,selected.data(),bytes);ctx->Unmap(storage->buffer.Get(),0);storage->epoch=epoch;storage->writeOffset=offset+bytes;if(discard)++storage->discards;else ++storage->noOverwrite;
   ComPtr<ID3D11Buffer> oldVertices;UINT oldStride=0,oldOffset=0;ctx->IAGetVertexBuffers(0,1,&oldVertices,&oldStride,&oldOffset);D3D11_PRIMITIVE_TOPOLOGY oldTopology{};ctx->IAGetPrimitiveTopology(&oldTopology);ID3D11Buffer* privateBuffer=storage->buffer.Get();ctx->IASetVertexBuffers(0,1,&privateBuffer,&stride,&offset);ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);ComPtr<ID3D11BlendState> oldBlend;FLOAT oldFactor[4]{};UINT oldMask=0;ctx->OMGetBlendState(&oldBlend,oldFactor,&oldMask);auto* blend=captureBlend(oldBlend.Get());if(blend!=oldBlend.Get())ctx->OMSetBlendState(blend,oldFactor,oldMask);ctx->Draw(unsigned(selected.size()),0);if constexpr(ScopeCapture){scopeContentKind.store(meta.nativeKind);scopeDrawTick.store(GetTickCount());}if(blend!=oldBlend.Get())ctx->OMSetBlendState(oldBlend.Get(),oldFactor,oldMask);ID3D11Buffer* previous=oldVertices.Get();ctx->IASetVertexBuffers(0,1,&previous,&oldStride,&oldOffset);ctx->IASetPrimitiveTopology(oldTopology);
  }}
  ctx->OMSetRenderTargets(8,oldTargets.p,oldDepth.Get());ctx->RSSetViewports(views,viewports);ctx->RSSetScissorRects(clipCount,clips);
 }
 ReleaseSRWLockExclusive(&gpuLock);
}
inline void endCommandList(ID3D11DeviceContext* ctx){if(!uploadsExist.load())return;AcquireSRWLockExclusive(&gpuLock);for(auto& entry:privateVertices)if(entry.context==ctx){entry.epoch=0;entry.writeOffset=0;break;}ReleaseSRWLockExclusive(&gpuLock);}
inline void present(IDXGISwapChain* swap){if(MenuCapture)menuFrameEpoch=0;AcquireSRWLockExclusive(&gpuLock);if(channel&&mutex&&drawnEpoch&&drawnEpoch!=publishedEpoch){ComPtr<ID3D11Device> device;if(SUCCEEDED(swap->GetDevice(IID_PPV_ARGS(&device)))&&device==owner&&mutex->AcquireSync(0,0)==S_OK){ComPtr<ID3D11DeviceContext> ctx;device->GetImmediateContext(&ctx);ctx->CopyResource(sharedTexture.Get(),canvas.Get());ctx->Flush();if(SUCCEEDED(mutex->ReleaseSync(1))){publishedEpoch=drawnEpoch;if constexpr(RFGR_HUD_FIRST==218440u)vrmenuaspect::publish(capturedWidth,capturedHeight);LONG frames=InterlockedIncrement(&channel->frames);if(frames==1||frames%300==0){char text[100];sprintf_s(text,"Wrist frames published=%ld accepted=%ld",frames,channel->acknowledged);log(text);}}}}ReleaseSRWLockExclusive(&gpuLock);}
inline ID3D11ShaderResourceView* scopeOverlay(int kind){if constexpr(!ScopeCapture)return nullptr;
 AcquireSRWLockExclusive(&gpuLock);ID3D11ShaderResourceView* view=nullptr;
 if(scopeContentKind.load()==kind&&canvas&&owner&&scopeDrawTick.load()&&GetTickCount()-scopeDrawTick.load()<700){if(!nativeScopeView)owner->CreateShaderResourceView(canvas.Get(),nullptr,&nativeScopeView);view=nativeScopeView.Get();if(view)view->AddRef();}
 ReleaseSRWLockExclusive(&gpuLock);return view;
}
inline bool install(void* emitHook=nullptr,bool enable=true){auto* base=(unsigned char*)GetModuleHandleW(nullptr);if(base[0x78520]!=0x81||base[0x1505c0]!=0xa1||base[0x12d690]!=0x83)return false;void* targets[4]={base+0x78520,base+0x1505c0,base+0x12d690,base+0x150480};void* hooks[4]={(void*)draw,(void*)alloc,emitHook?emitHook:(void*)emit,(void*)flush};void** originals[4]={(void**)&originalDraw,(void**)&originalAlloc,(void**)&originalEmit,(void**)&originalFlush};for(int i=0;i<4;++i)if(MH_CreateHook(targets[i],hooks[i],originals[i])!=MH_OK){for(int j=0;j<i;++j)MH_RemoveHook(targets[j]);return false;}if(enable)for(int i=0;i<4;++i)if(MH_EnableHook(targets[i])!=MH_OK){for(auto* t:targets){MH_DisableHook(t);MH_RemoveHook(t);}return false;}installed=true;return true;}
}





