#pragma once
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include "weapon_laser.h"
#include "vr_world_scale.h"
// Small world-space mesh, drawn against the same depth buffer as the eye.
struct RFGRWeaponLaserGpu {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> deferred;
 Ptr<ID3D11VertexShader> vs;Ptr<ID3D11PixelShader> ps;Ptr<ID3D11InputLayout> layout;
 Ptr<ID3D11Buffer> buffer;Ptr<ID3D11BlendState> blend;Ptr<ID3D11RasterizerState> raster,reverseRaster;Ptr<ID3D11DepthStencilState> depth,reverseDepth;
 Ptr<ID3D11Texture2D> output;Ptr<ID3D11RenderTargetView> target;
 struct Vertex{float clip[4],uv[2],beam,emission;};
 bool init(ID3D11Device* d){if(owner.Get()==d&&buffer)return true;*this={};owner=d;
 const char shader[]=R"(struct V{float4 p:POSITION;float2 uv:TEXCOORD0;float beam:TEXCOORD1;float emission:TEXCOORD2;};struct O{float4 p:SV_POSITION;float2 uv:TEXCOORD0;float beam:TEXCOORD1;float emission:TEXCOORD2;};O VS(V v){O o;o.p=v.p;o.uv=v.uv;o.beam=v.beam;o.emission=v.emission;return o;}float4 PS(O i):SV_Target{float r=length(i.uv);float edge=max(fwidth(r),.01);if(r>1+edge)discard;float a=i.beam>0?.35*(1-abs(i.uv.x))*smoothstep(0,.3,1-abs(i.uv.y)):(1-smoothstep(.2-edge,1+edge,r))*saturate(-i.beam);return float4(float3(1,.015,.008)*i.emission,a);})";
 Ptr<ID3DBlob> v,p;if(FAILED(D3DCompile(shader,sizeof(shader),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&v,nullptr))||FAILED(D3DCompile(shader,sizeof(shader),nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&p,nullptr)))return false;
 D3D11_INPUT_ELEMENT_DESC fields[]={{"POSITION",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,16,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",1,DXGI_FORMAT_R32_FLOAT,0,24,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",2,DXGI_FORMAT_R32_FLOAT,0,28,D3D11_INPUT_PER_VERTEX_DATA,0}};
 if(FAILED(d->CreateVertexShader(v->GetBufferPointer(),v->GetBufferSize(),nullptr,&vs))||FAILED(d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,&ps))||FAILED(d->CreateInputLayout(fields,4,v->GetBufferPointer(),v->GetBufferSize(),&layout))||FAILED(d->CreateDeferredContext(0,&deferred)))return false;
 D3D11_BUFFER_DESC b{};b.ByteWidth=12*sizeof(Vertex);b.Usage=D3D11_USAGE_DYNAMIC;b.BindFlags=D3D11_BIND_VERTEX_BUFFER;b.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;
 D3D11_BLEND_DESC bl{};auto& rt=bl.RenderTarget[0];rt.BlendEnable=TRUE;rt.SrcBlend=D3D11_BLEND_SRC_ALPHA;rt.DestBlend=D3D11_BLEND_ONE;rt.BlendOp=D3D11_BLEND_OP_ADD;rt.SrcBlendAlpha=D3D11_BLEND_ZERO;rt.DestBlendAlpha=D3D11_BLEND_ONE;rt.BlendOpAlpha=D3D11_BLEND_OP_ADD;rt.RenderTargetWriteMask=7;
 D3D11_RASTERIZER_DESC r{};r.FillMode=D3D11_FILL_SOLID;r.CullMode=D3D11_CULL_NONE;r.DepthClipEnable=TRUE;r.DepthBias=-4;r.SlopeScaledDepthBias=-.25f;r.DepthBiasClamp=-.00001f;
 D3D11_DEPTH_STENCIL_DESC z{};z.DepthEnable=TRUE;z.DepthWriteMask=D3D11_DEPTH_WRITE_MASK_ZERO;z.DepthFunc=D3D11_COMPARISON_LESS_EQUAL;
 bool ok=SUCCEEDED(d->CreateDepthStencilState(&z,&depth));z.DepthFunc=D3D11_COMPARISON_GREATER_EQUAL;ok=ok&&SUCCEEDED(d->CreateDepthStencilState(&z,&reverseDepth));
 ok=ok&&SUCCEEDED(d->CreateRasterizerState(&r,&raster));r.DepthBias=4;r.SlopeScaledDepthBias=.25f;r.DepthBiasClamp=.00001f;
 return ok&&SUCCEEDED(d->CreateBuffer(&b,nullptr,&buffer))&&SUCCEEDED(d->CreateBlendState(&bl,&blend))&&SUCCEEDED(d->CreateRasterizerState(&r,&reverseRaster));
 }
 bool draw(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* back,ID3D11DepthStencilView* sceneDepth,const vrarm::Pose& eye,const float projection[16],D3D11_COMPARISON_FUNC comparison,float minimum,float maximum,const vrarm::Pose* mounted=nullptr,vrarm::V visualShift={},const vrlaser::State* frameState=nullptr){
 using namespace vrarm;auto s=frameState?*frameState:vrlaser::snapshot();if(!s.active||!sceneDepth||!back||!init(d))return false;
 if(mounted&&valid(mounted->b)&&finite(mounted->p))vrlaser::reproject(s,*mounted);
 if(output.Get()!=back){output=back;target.Reset();D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);D3D11_RENDER_TARGET_VIEW_DESC view{};view.Format=desc.Format==DXGI_FORMAT_R8G8B8A8_TYPELESS?DXGI_FORMAT_R8G8B8A8_UNORM_SRGB:desc.Format==DXGI_FORMAT_B8G8R8A8_TYPELESS?DXGI_FORMAT_B8G8R8A8_UNORM_SRGB:desc.Format;view.ViewDimension=D3D11_RTV_DIMENSION_TEXTURE2D;if(FAILED(d->CreateRenderTargetView(back,&view,&target)))return false;}
 auto appearance=vrlaser::settings();Vertex vertices[12]{};unsigned count=0;const unsigned corners[6]={0,1,2,2,1,3};
 auto quad=[&](V center,V right,V up,float beam){V p[4]={sub(sub(center,right),up),add(sub(center,up),right),add(sub(center,right),up),add(add(center,right),up)};
  for(unsigned i:corners){auto& o=vertices[count++];V localPoint=local(eye.b,sub(p[i],eye.p));float v[4]={localPoint.x,localPoint.y,localPoint.z,1};for(unsigned r=0;r<4;++r)for(unsigned col=0;col<4;++col)o.clip[r]+=projection[col*4+r]*v[col];o.uv[0]=(i&1)?1.f:-1.f;o.uv[1]=(i&2)?1.f:-1.f;o.beam=beam;o.emission=beam>0?1.f:appearance.emission;}
 };
 V direction=unit(sub(s.end,s.origin));float beamLength=(std::min)(.18f*s.scale,s.distance);V center=add(add(s.origin,visualShift),mul(direction,beamLength*.5f));V side=unit(cross(direction,sub(eye.p,center)),eye.b.r);
 quad(center,mul(side,.0012f*s.scale),mul(direction,beamLength*.5f),1);
 if(s.hit){V normal=unit(s.normal),right=unit(cross(normal,fabsf(normal.y)<.9f?V{0,1,0}:V{1,0,0})),up=cross(normal,right);float radius=vrlaser::radius(s.distance,s.scale)*appearance.size;V atEye=local(eye.b,sub(s.end,eye.p));D3D11_TEXTURE2D_DESC image{};back->GetDesc(&image);float pixelRadius=fabsf(atEye.z)*2.f/((std::max)(1.f,image.Height*fabsf(projection[5])));radius=(std::max)(radius,(std::min)(.0375f*s.scale*appearance.size,pixelRadius));
 float bias=(std::min)(.012f*s.scale,.002f*s.scale+s.distance*.00015f);quad(add(add(s.end,mul(normal,bias)),mul(unit(sub(eye.p,s.end)),bias*.5f)),mul(right,radius),mul(up,radius),-vrlaser::visibility(s.distance,s.scale));}
 D3D11_MAPPED_SUBRESOURCE mapped{};if(FAILED(deferred->Map(buffer.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&mapped)))return false;memcpy(mapped.pData,vertices,count*sizeof(Vertex));deferred->Unmap(buffer.Get(),0);
 auto* rt=target.Get();deferred->OMSetRenderTargets(1,&rt,sceneDepth);bool reverse=comparison==D3D11_COMPARISON_GREATER||comparison==D3D11_COMPARISON_GREATER_EQUAL;deferred->OMSetDepthStencilState(reverse?reverseDepth.Get():depth.Get(),0);deferred->OMSetBlendState(blend.Get(),nullptr,~0u);deferred->RSSetState(reverse?reverseRaster.Get():raster.Get());D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);D3D11_VIEWPORT vp{0,0,float(desc.Width),float(desc.Height),minimum,maximum};deferred->RSSetViewports(1,&vp);deferred->IASetInputLayout(layout.Get());deferred->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);UINT stride=sizeof(Vertex),offset=0;auto* vb=buffer.Get();deferred->IASetVertexBuffers(0,1,&vb,&stride,&offset);deferred->VSSetShader(vs.Get(),nullptr,0);deferred->PSSetShader(ps.Get(),nullptr,0);deferred->GSSetShader(nullptr,nullptr,0);deferred->HSSetShader(nullptr,nullptr,0);deferred->DSSetShader(nullptr,nullptr,0);deferred->Draw(count,0);
 Ptr<ID3D11CommandList> list;if(FAILED(deferred->FinishCommandList(FALSE,&list)))return false;c->ExecuteCommandList(list.Get(),TRUE);return true;
 }
 void releaseOutput(){output.Reset();target.Reset();if(deferred){deferred->ClearState();Ptr<ID3D11CommandList> discarded;deferred->FinishCommandList(FALSE,&discarded);}}
};
