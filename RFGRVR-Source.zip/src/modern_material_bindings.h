#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <mutex>
#include <cmath>
#include <cstring>
#include <atomic>
#include <cstdint>
#include "modern_height_bindings.h"
#include "modern_reflectivity_bindings.h"
namespace modernmaterial {
struct Frame {float reflection[4]{},inverseClip[16]{},eye[4]{},viewport[4]{},origin[4]{},grid[4]{},layout[4]{},reflectionCenter[4]{},reflectionBounds[4]{};};
static_assert(sizeof(Frame)==192,"Material world-space GPU ABI");
template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
inline Ptr<ID3D11Device> constantOwner;inline Ptr<ID3D11Buffer> constantCache[16];inline std::mutex constantMutex;
struct ViewBuffer {ID3D11DeviceContext* key=nullptr;Ptr<ID3D11Buffer> buffer;};inline ViewBuffer viewCache[128];
inline void device(ID3D11Device* d){if(constantOwner.Get()!=d){for(auto& c:constantCache)c.Reset();for(auto& c:viewCache)c={};constantOwner=d;}}
inline ID3D11Buffer* controls(ID3D11Device* d,unsigned levels){
 if(!d||!levels||levels>16)return nullptr;std::lock_guard<std::mutex> held(constantMutex);device(d);
 auto& cached=constantCache[levels-1];if(!cached){Frame frame;frame.reflection[0]=1;frame.reflection[1]=.125f;frame.reflection[2]=float(levels-1);D3D11_BUFFER_DESC desc{};desc.ByteWidth=sizeof(Frame);desc.BindFlags=D3D11_BIND_CONSTANT_BUFFER;desc.Usage=D3D11_USAGE_IMMUTABLE;D3D11_SUBRESOURCE_DATA data{&frame,0,0};if(FAILED(d->CreateBuffer(&desc,&data,&cached)))return nullptr;}return cached.Get();
}
inline ID3D11Buffer* viewBuffer(ID3D11Device* d,ID3D11DeviceContext* c){
 std::lock_guard<std::mutex> held(constantMutex);device(d);ViewBuffer* slot=nullptr;for(auto& item:viewCache){if(item.key==c)return item.buffer.Get();if(!item.key&&!slot)slot=&item;}if(!slot)return nullptr;
 D3D11_BUFFER_DESC desc{};desc.ByteWidth=sizeof(Frame);desc.BindFlags=D3D11_BIND_CONSTANT_BUFFER;desc.Usage=D3D11_USAGE_DYNAMIC;desc.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;Ptr<ID3D11Buffer> next;if(FAILED(d->CreateBuffer(&desc,nullptr,&next)))return nullptr;slot->key=c;slot->buffer=next;return next.Get();
}
// Scoped to a native world view. No native texture/sampler slots are changed.
// Per-context dynamic buffers use DISCARD so queued views keep their own data.
class Bindings {
 Ptr<ID3D11DeviceContext> context;Ptr<ID3D11ShaderResourceView> saved[5];Ptr<ID3D11Buffer> prior,constants;
 Ptr<ID3D11ShaderResourceView> activeInputs[5];
public:
 bool bind(ID3D11DeviceContext* c,ID3D11ShaderResourceView* cube,ID3D11ShaderResourceView* brdf,const Frame* world=nullptr,ID3D11ShaderResourceView* probes=nullptr,ID3D11ShaderResourceView* sky=nullptr){
  if(context||!c||bool(cube)!=bool(brdf)||(!cube&&(!world||(!probes&&!sky&&world->reflection[3]<=0&&world->eye[3]<.5f))))return false;Ptr<ID3D11Device> owner;c->GetDevice(&owner);unsigned levels=0;
  for(auto* input:{cube,brdf,probes,sky})if(input){Ptr<ID3D11Device> d;input->GetDevice(&d);if(d.Get()!=owner.Get())return false;}
  if(cube){D3D11_SHADER_RESOURCE_VIEW_DESC view{},lookup{};cube->GetDesc(&view);brdf->GetDesc(&lookup);if(view.ViewDimension!=D3D11_SRV_DIMENSION_TEXTURECUBE||!view.TextureCube.MipLevels||view.TextureCube.MipLevels>16)return false;if(view.Format!=DXGI_FORMAT_R16G16B16A16_FLOAT&&view.Format!=DXGI_FORMAT_R32G32B32A32_FLOAT&&view.Format!=DXGI_FORMAT_R11G11B10_FLOAT)return false;if(lookup.ViewDimension!=D3D11_SRV_DIMENSION_TEXTURE2D||(lookup.Format!=DXGI_FORMAT_R16G16_FLOAT&&lookup.Format!=DXGI_FORMAT_R32G32_FLOAT))return false;levels=view.TextureCube.MipLevels;}
  if(probes){D3D11_SHADER_RESOURCE_VIEW_DESC view{};probes->GetDesc(&view);if(view.ViewDimension!=D3D11_SRV_DIMENSION_TEXTURE2D||view.Format!=DXGI_FORMAT_R32G32B32A32_FLOAT)return false;}
  if(world){Frame frame=*world;for(unsigned i=0;i<sizeof(Frame)/4;++i)if(!std::isfinite(((const float*)&frame)[i]))return false;if(frame.eye[3]>.5f&&(frame.viewport[0]<=0||frame.viewport[1]<=0))return false;frame.reflection[0]=cube?1.f:0.f;frame.reflection[1]=.125f;frame.reflection[2]=cube?float(levels-1):0;frame.layout[1]=probes?frame.layout[1]:0;frame.layout[2]=sky?1.f:0.f;
   constants=viewBuffer(owner.Get(),c);if(!constants)return false;D3D11_MAPPED_SUBRESOURCE mapped{};if(FAILED(c->Map(constants.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&mapped)))return false;memcpy(mapped.pData,&frame,sizeof(frame));c->Unmap(constants.Get(),0);
  }else {constants=controls(owner.Get(),levels);if(!constants)return false;}
  ID3D11ShaderResourceView* old[5]{};c->PSGetShaderResources(16,5,old);for(unsigned i=0;i<5;++i)saved[i].Attach(old[i]);c->PSGetConstantBuffers(13,1,&prior);context=c;activeInputs[0]=cube;activeInputs[1]=brdf;activeInputs[2]=probes;activeInputs[4]=sky;reapply();return true;
 }
 void reapply(){if(context){ID3D11ShaderResourceView* inputs[]={activeInputs[0].Get(),activeInputs[1].Get(),activeInputs[2].Get(),nullptr,activeInputs[4].Get()};context->PSSetShaderResources(16,5,inputs);auto* cb=constants.Get();context->PSSetConstantBuffers(13,1,&cb);}}
 ~Bindings(){if(context){ID3D11ShaderResourceView* inputs[]={saved[0].Get(),saved[1].Get(),saved[2].Get(),saved[3].Get(),saved[4].Get()};context->PSSetShaderResources(16,5,inputs);auto* cb=prior.Get();context->PSSetConstantBuffers(13,1,&cb);}}
};
// Shader identity travels with the object; never classify a draw by colour or
// by a native pointer address which can be reused after a resource is retired.
inline constexpr GUID shaderTag={0x940f9162,0x9754,0x49be,{0x94,0x21,0x52,0x51,0x37,0x0c,0x71,0xd9}};
inline void tag(ID3D11PixelShader* shader,int mode){if(shader&&mode>=0){unsigned value=unsigned(mode)+1;shader->SetPrivateData(shaderTag,sizeof(value),&value);}}
inline int mode(ID3D11PixelShader* shader){unsigned value=0,size=sizeof(value);return shader&&SUCCEEDED(shader->GetPrivateData(shaderTag,&size,&value))&&size==sizeof(value)&&value?int(value-1):-1;}
inline bool tagged(ID3D11PixelShader* shader){return mode(shader)>=0;}
class WorldScope;
inline std::atomic<WorldScope*> activeWorld{nullptr};inline std::atomic<uint64_t> worldEpoch{0},nextEpoch{0};
// Native secondary renderer contexts are selected INSIDE the scene function.
// Bind on the actual command context at its first replacement-material draw,
// and rebind after command-list state resets. No GPU Get calls per draw.
class WorldScope {
 Frame frame;Ptr<ID3D11ShaderResourceView> cube,brdf,probes,sky;
 struct Slot {ID3D11DeviceContext* context=nullptr;Bindings binding;modernheight::Bindings heights;modernreflectivity::Bindings materials;};Slot slots[8];
 std::mutex mutex;WorldScope* previous=nullptr;uint64_t priorEpoch=0,id=0;
public:
 WorldScope(const Frame& f,ID3D11ShaderResourceView* c,ID3D11ShaderResourceView* b,ID3D11ShaderResourceView* p,ID3D11ShaderResourceView* s):frame(f),cube(c),brdf(b),probes(p),sky(s){id=++nextEpoch;priorEpoch=worldEpoch.load();previous=activeWorld.exchange(this);worldEpoch=id;}
 WorldScope(const WorldScope&)=delete;
 uint64_t apply(ID3D11DeviceContext* c){std::lock_guard<std::mutex> lock(mutex);Slot* empty=nullptr;for(auto& slot:slots){if(slot.context==c){slot.binding.reapply();return id;}if(!slot.context&&!empty)empty=&slot;}if(!empty||!empty->binding.bind(c,cube.Get(),brdf.Get(),&frame,probes.Get(),sky.Get()))return 0;empty->context=c;return id;}
 bool heights(ID3D11DeviceContext* c,ID3D11ShaderResourceView*const* normals,unsigned count){std::lock_guard<std::mutex> lock(mutex);for(auto& slot:slots)if(slot.context==c)return slot.heights.apply(c,normals,count);return false;}
 bool materialMaps(ID3D11DeviceContext* c,ID3D11ShaderResourceView*const* inputs,unsigned count){std::lock_guard<std::mutex> lock(mutex);for(auto& slot:slots)if(slot.context==c)return slot.materials.apply(c,inputs,count);return false;}
 ~WorldScope(){worldEpoch=priorEpoch;activeWorld=previous;}
};
inline bool applyHeights(ID3D11DeviceContext* c,ID3D11ShaderResourceView*const* normals,unsigned count){auto* active=activeWorld.load();return active&&active->heights(c,normals,count);}
inline bool applyMaterialMaps(ID3D11DeviceContext* c,ID3D11ShaderResourceView*const* inputs,unsigned count){auto* active=activeWorld.load();return active&&active->materialMaps(c,inputs,count);}
inline uint64_t applyWorld(ID3D11DeviceContext* c){auto* active=activeWorld.load();return active?active->apply(c):0;}
}


