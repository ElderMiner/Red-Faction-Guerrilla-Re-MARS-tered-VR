#pragma once
#include "modern_indirect.h"
#include "modern_probe_projection_source.h"
#include <d3dcompiler.h>
namespace modernindirect {
class Projector {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> worker;Ptr<ID3D11ComputeShader> shader;
 Ptr<ID3D11Buffer> coefficients;Ptr<ID3D11UnorderedAccessView> output;Ptr<ID3D11SamplerState> sampler;
 bool init(ID3D11Device* d){if(owner.Get()==d&&shader&&worker&&coefficients&&output&&sampler)return true;if(!d||d->GetFeatureLevel()<D3D_FEATURE_LEVEL_11_0)return false;
  Ptr<ID3DBlob> code,error;Ptr<ID3D11ComputeShader> nextShader;Ptr<ID3D11DeviceContext> nextWorker;Ptr<ID3D11Buffer> nextBuffer;Ptr<ID3D11UnorderedAccessView> nextOutput;Ptr<ID3D11SamplerState> nextSampler;
  if(FAILED(D3DCompile(projectionSource,sizeof(projectionSource)-1,"RFGRVR irradiance projection",nullptr,nullptr,"main","cs_5_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error)))return false;
  if(FAILED(d->CreateComputeShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&nextShader))||FAILED(d->CreateDeferredContext(0,&nextWorker)))return false;
  D3D11_BUFFER_DESC bd{};bd.ByteWidth=sizeof(Probe);bd.BindFlags=D3D11_BIND_UNORDERED_ACCESS;bd.MiscFlags=D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;bd.StructureByteStride=16;if(FAILED(d->CreateBuffer(&bd,nullptr,&nextBuffer)))return false;
  D3D11_UNORDERED_ACCESS_VIEW_DESC ud{};ud.ViewDimension=D3D11_UAV_DIMENSION_BUFFER;ud.Buffer.NumElements=15;if(FAILED(d->CreateUnorderedAccessView(nextBuffer.Get(),&ud,&nextOutput)))return false;
  D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_POINT;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.MaxLOD=D3D11_FLOAT32_MAX;if(FAILED(d->CreateSamplerState(&sd,&nextSampler)))return false;
  owner=d;worker=nextWorker;shader=nextShader;coefficients=nextBuffer;output=nextOutput;sampler=nextSampler;return true;
 }
public:
 bool project(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11ShaderResourceView* hdr,ID3D11ShaderResourceView* distance){
  if(!c||!hdr||!distance||c->GetType()!=D3D11_DEVICE_CONTEXT_IMMEDIATE)return false;Ptr<ID3D11Device> contextDevice;c->GetDevice(&contextDevice);if(contextDevice.Get()!=d)return false;
  for(auto* view:{hdr,distance}){D3D11_SHADER_RESOURCE_VIEW_DESC desc{};view->GetDesc(&desc);if(desc.ViewDimension!=D3D11_SRV_DIMENSION_TEXTURECUBE||(view==distance?desc.Format!=DXGI_FORMAT_R32_FLOAT:(desc.Format!=DXGI_FORMAT_R11G11B10_FLOAT&&desc.Format!=DXGI_FORMAT_R16G16B16A16_FLOAT&&desc.Format!=DXGI_FORMAT_R32G32B32A32_FLOAT)))return false;Ptr<ID3D11Device> device;view->GetDevice(&device);if(device.Get()!=d)return false;}
  if(!init(d))return false;worker->ClearState();worker->CSSetShader(shader.Get(),nullptr,0);ID3D11ShaderResourceView* inputs[]={hdr,distance};worker->CSSetShaderResources(0,2,inputs);auto* state=sampler.Get();worker->CSSetSamplers(0,1,&state);auto* uav=output.Get();worker->CSSetUnorderedAccessViews(0,1,&uav,nullptr);worker->Dispatch(15,1,1);
  Ptr<ID3D11CommandList> commands;if(FAILED(worker->FinishCommandList(FALSE,&commands)))return false;c->ExecuteCommandList(commands.Get(),TRUE);return true;
 }
 ID3D11Buffer* buffer()const{return coefficients.Get();}
};
}
