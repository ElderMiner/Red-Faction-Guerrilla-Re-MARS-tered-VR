#pragma once
#include "modern_optics.h"
#include <vector>
#include <limits>
namespace modernwave {
using modernoptics::V;
using namespace modernoptics;
inline V sub(V a,V b){return add(a,mul(b,-1));}
inline bool finite(V a){return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z);}
inline float strength(V a){return (std::max)({a.x,a.y,a.z});}
struct Surface {uint64_t id=0;V position,normal;float area=1;Profile material;bool visible=false;};
// Energy is integrated RGB power, not per-pixel brightness. A spherical radius
// bounds influence; direction/spread describes the energy inside that sphere.
struct Field {uint64_t source=0,surface=0;V origin,direction,energy;float range=20,spread=1;bool isotropic=true;};
struct Limits {unsigned bounces=8,fields=1024,queries=8192;float threshold=.0001f;};
struct Result {std::vector<V> received;std::vector<Field> emitted;uint64_t revision=0;unsigned bounces=0,queries=0,fields=0;bool truncated=false,valid=false;};
// Adapter returns RGB throughput for the OPEN segment between endpoints:
// zero for a solid blocker; Beer/Fresnel transmission for transparent layers.
// Missing/uncertain geometry must return false, never an unobstructed segment.
using Segment=bool(*)(void*,V,V,uint64_t,uint64_t,V&);
inline float angular(const Field& f,V outgoing){
 if(f.isotropic)return 1;
 float c=(std::max)(dot(unit(f.direction),outgoing),0.f);
 float spread=(std::clamp)(f.spread,.01f,1.f);
 return std::pow(c,(std::min)(2.f/(spread*spread)-1.f,20000.f));
}
inline Result solve(const std::vector<Surface>& surfaces,const std::vector<Field>& sources,Segment trace,void* user,Limits limits={}){
 Result out;out.received.resize(surfaces.size());
 if(!trace||surfaces.size()>128||sources.size()>64||!limits.bounces||limits.bounces>16||!limits.fields||limits.fields>65536||!limits.queries||limits.queries>1048576||!std::isfinite(limits.threshold)||limits.threshold<=0)return out;
 for(size_t i=0;i<surfaces.size();++i){const auto& s=surfaces[i];if(!s.id||!finite(s.position)||!finite(s.normal)||dot(s.normal,s.normal)<.5f||!std::isfinite(s.area)||s.area<=0)return out;for(size_t j=0;j<i;++j)if(surfaces[j].id==s.id)return out;}
 for(const auto& f:sources)if(!f.source||!finite(f.origin)||!finite(f.direction)||!finite(f.energy)||f.energy.x<0||f.energy.y<0||f.energy.z<0||!std::isfinite(f.range)||f.range<=0||!std::isfinite(f.spread)||(!f.isotropic&&dot(f.direction,f.direction)<.5f))return out;
 // Reverse relevance follows possible surface connections, not just visible
 // nodes. An offscreen reflector can still illuminate a visible receiver.
 std::vector<bool> needed(surfaces.size());for(size_t i=0;i<surfaces.size();++i)needed[i]=surfaces[i].visible;
 float range=0;for(const auto& f:sources)range=(std::max)(range,f.range);
 for(unsigned pass=1;pass<limits.bounces;++pass){auto previous=needed;for(size_t i=0;i<surfaces.size();++i)if(!needed[i])for(size_t j=0;j<surfaces.size();++j)if(previous[j]&&dot(sub(surfaces[i].position,surfaces[j].position),sub(surfaces[i].position,surfaces[j].position))<range*range){needed[i]=true;break;}}
 std::vector<Field> current=sources;unsigned generated=0;out.valid=true;
 for(unsigned bounce=0;bounce<limits.bounces&&!current.empty();++bounce){std::vector<Field> next;out.bounces=bounce+1;
  for(const auto& field:current){if(strength(field.energy)<limits.threshold)continue;std::vector<float> weights(surfaces.size());float total=0;
   for(size_t i=0;i<surfaces.size();++i){const auto& s=surfaces[i];if(!needed[i]||s.id==field.surface)continue;V delta=sub(s.position,field.origin);float d=std::sqrt(dot(delta,delta));if(d<.001f||d>=field.range)continue;V direction=mul(delta,1/d);float incidence=(std::max)(-dot(unit(s.normal),direction),0.f);weights[i]=s.area*incidence*angular(field,direction)*falloff(d,field.range)/(4*3.141592654f);total+=weights[i];}
   // Normalize BEFORE occlusion. Blocking must absorb energy, not redistribute
   // it into the remaining visible surfaces. No emitter can multiply power.
   if(!std::isfinite(total)){out.valid=false;return out;}
   float normalization=1/(std::max)(total,1.f);
   for(size_t i=0;i<surfaces.size();++i){if(weights[i]<=0)continue;const auto& s=surfaces[i];V incoming=mul(field.energy,weights[i]*normalization);if(strength(incoming)<limits.threshold)continue;if(out.queries>=limits.queries){out.truncated=true;return out;}++out.queries;V throughput{};
    if(!trace(user,field.origin,s.position,field.surface,s.id,throughput)||!finite(throughput))continue;
    incoming=product(incoming,{clamp(throughput.x),clamp(throughput.y),clamp(throughput.z)});if(strength(incoming)<limits.threshold)continue;out.received[i]=add(out.received[i],incoming);
    if(bounce+1==limits.bounces)continue;
    V direction=unit(sub(s.position,field.origin));float cosine=(std::max)(-dot(direction,unit(s.normal)),.00001f);
    // Geometric collection already includes incidence; interact expects power
    // before incidence, so remove it once to avoid applying cosine twice.
    auto response=interact(s.material,direction,s.normal,mul(incoming,1/cosine),0,field.source,s.id);
    for(unsigned k=0;k<response.count;++k){auto& lobe=response.lobes[k];if(lobe.kind==Kind::Transmission)continue; // segment adapter owns transmission, once
     if(strength(lobe.energy)<limits.threshold)continue;if(generated>=limits.fields){out.truncated=true;continue;}++generated;++out.fields;Field emitted{lobe.sourceId,lobe.surfaceId,s.position,lobe.direction,lobe.energy,field.range,lobe.spread,false};next.push_back(emitted);out.emitted.push_back(emitted);}
   }
  }current.swap(next);
 }return out;
}
// Evaluate a visible receiver toward its actual eye, using the same segment
// adapter as propagation. Sources and emitted fields are evaluated separately
// so the native direct-light pass can be retained without double counting it.
inline V evaluate(const std::vector<Field>& fields,const Surface& receiver,V eye,Segment trace,void* user,unsigned queryBudget=2048){
 V radiance{};if(!trace||!finite(eye)||!finite(receiver.position)||!finite(receiver.normal))return radiance;V view=unit(sub(eye,receiver.position));if(dot(view,view)<.5f||dot(view,unit(receiver.normal))<=0)return radiance;
 for(const auto& field:fields){if(!queryBudget--)break;if(field.surface==receiver.id)continue;V delta=sub(receiver.position,field.origin);float distance=std::sqrt(dot(delta,delta));if(distance<.002f||!std::isfinite(distance))continue;V direction=mul(delta,1/distance);float incidence=-dot(direction,unit(receiver.normal));if(incidence<=0)continue;float weight=falloff(distance,field.range)*angular(field,direction)/(4*3.141592654f);if(weight<=0)continue;V throughput{};if(!trace(user,field.origin,receiver.position,field.surface,receiver.id,throughput)||!finite(throughput))continue;
  V incident=product(mul(field.energy,weight),{clamp(throughput.x),clamp(throughput.y),clamp(throughput.z)});auto response=interact(receiver.material,direction,receiver.normal,incident,0,field.source,receiver.id);
  for(unsigned k=0;k<response.count;++k){auto& lobe=response.lobes[k];if(lobe.kind==Kind::Transmission)continue;float distribution=1/3.141592654f;if(lobe.kind==Kind::Reflection){float spread=(std::clamp)(lobe.spread,.01f,1.f),exponent=(std::min)(2/(spread*spread)-1,20000.f);distribution=(exponent+2)/(2*3.141592654f)*std::pow((std::max)(dot(lobe.direction,view),0.f),exponent);}radiance=add(radiance,mul(lobe.energy,distribution));}
 }return finite(radiance)?radiance:V{};
}
}
