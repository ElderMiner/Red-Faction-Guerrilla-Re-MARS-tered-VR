#pragma once
#include "ipc.h"
#include "vr_arm_math.h"
#include <algorithm>
#include <cmath>
namespace vrtank {
inline float axis(short v){float a=v/32767.f;return fabsf(a)>.22f?(a-(a>0?.22f:-.22f))/.78f:0;}
// Native tank controls already use LS for driving, RT for cannon and A for MG.
inline void drive(RFGRGamepad& pad){pad.buttons&=~0x1000;pad.leftTrigger=0;}
// Medium cabins follow traversal. Heavy/artillery anchors are hull-local,
// captured once per occupied vehicle, so aiming cannot translate the seat.
struct Seat {
 unsigned identity=~0u;vrarm::V hullOffset{};
 bool update(unsigned id,const vrarm::Pose& hull,const vrarm::Pose& native,float height,vrarm::Pose& out,bool rotate=true){using namespace vrarm;if(!valid(hull.b)||!valid(native.b)||!finite(native.p))return false;
 if(identity!=id){identity=id;hullOffset=local(hull.b,sub(native.p,hull.p));}
 out=rotate?native:Pose{hull.b,add(hull.p,world(hull.b,hullOffset))};out.p=add(out.p,mul(out.b.u,height));return true;}
};
// A multi-tube launcher must not inherit its active firing tube's muzzle.
inline vrarm::Pose cameraMount(bool artillery,vrarm::Pose assembly,const vrarm::Pose& muzzle,const vrarm::V* pivot=nullptr){using namespace vrarm;if(artillery){if(pivot&&finite(*pivot))assembly.p=*pivot;return assembly;}if(valid(muzzle.b)&&finite(muzzle.p)&&length(sub(muzzle.p,assembly.p))<30)assembly=muzzle;assembly.p=add(assembly.p,world(assembly.b,{0,.15f,.15f}));return assembly;}
struct Feeds {
 unsigned vehicle=~0u,other=0;
 unsigned next(unsigned id,unsigned slot){if(vehicle!=id){vehicle=id;other=0;}if(slot%3<2)return slot%3;const unsigned views[3]={2,3,4};return views[other++%3];}
};
struct Secondary {bool held=false,pressed=false;unsigned long long stamp=0;
 void update(unsigned char trigger,unsigned long long now){bool next=trigger>30;pressed=pressed||next&&!held;held=next;if(!held)pressed=false;stamp=now;}
 bool down(unsigned long long now,bool paused)const{return !paused&&stamp&&now>=stamp&&now-stamp<60&&held;}
 bool edge(unsigned long long now,bool paused){bool result=down(now,paused)&&pressed;pressed=false;return result;}
};
inline bool inputFresh(unsigned long long now,unsigned long long stamp,bool paused){return !paused&&stamp&&now>=stamp&&now-stamp<60;}
inline void aim(float& yaw,float& pitch,short x,short y,float dt){dt=(std::clamp)(dt,0.f,.05f);yaw+=axis(x)*1.2f*dt;pitch+=axis(y)*.65f*dt;}
inline float yawLimit(float a,float low,float high){if(high-low>=6.f)return a;return (std::clamp)(a,low,high);}
struct Aim {unsigned handle=~0u;float yaw=0,pitch=0;bool ready=false;
 void update(unsigned id,float nativeYaw,float nativePitch,short x,short y,float dt){if(!ready||handle!=id){handle=id;yaw=nativeYaw;pitch=nativePitch;ready=true;}aim(yaw,pitch,x,y,dt);}
};

}
