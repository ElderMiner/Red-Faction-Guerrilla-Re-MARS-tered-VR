#pragma once
#include "modern_scene_lights.h"
namespace modernevidence {
inline void capture(void* sceneRenderer,void* renderer,void* scene,void* camera){
 if(!modernlight::enabled()||!moderncatalog::enabled()||!RFGRVR_HeadCam_FirstPersonVehicle())return;static unsigned frames=0;static bool done=false;if(done||++frames<30)return;done=true;
 char folder[MAX_PATH]{};GetModuleFileNameA(nullptr,folder,MAX_PATH);auto* slash=strrchr(folder,92);if(!slash)return;slash[1]=0;
 auto block=[&](const char* name,const void* address,size_t bytes){if(!vrmemory::check(address,bytes))return;char path[MAX_PATH]{};sprintf_s(path,"%svr-research\\output\\Modern-engine-%lu-%s.bin",folder,GetCurrentProcessId(),name);FILE* f=nullptr;if(!fopen_s(&f,path,"wb")&&f){fwrite(address,1,bytes,f);fclose(f);}};
 block("scene-renderer",sceneRenderer,0x600);block("renderer",renderer,0x480);block("scene",scene,0x208);block("camera",camera,0x380);
 const void* state=nullptr;if(vrmemory::check((char*)renderer+0x478,4)){unsigned p=0;memcpy(&p,(char*)renderer+0x478,4);state=(const void*)(uintptr_t)p;block("state",state,0x5c0);}
 auto lights=modernscene::collector.snapshot();char path[MAX_PATH]{};sprintf_s(path,"%svr-research\\output\\Modern-engine-%lu.json",folder,GetCurrentProcessId());FILE* f=nullptr;
 if(!fopen_s(&f,path,"w")&&f){fprintf(f,"{\"sceneRenderer\":%u,\"renderer\":%u,\"scene\":%u,\"camera\":%u,\"state\":%u,\"lights\":%u,\"droppedLights\":%u}\n",unsigned((uintptr_t)sceneRenderer),unsigned((uintptr_t)renderer),unsigned((uintptr_t)scene),unsigned((uintptr_t)camera),unsigned((uintptr_t)state),lights.count,lights.dropped);fclose(f);}
 block("lights",&lights,sizeof(lights));
 sprintf_s(path,"%sRFGRVR-pixel-probe.enable",folder);if(!fopen_s(&f,path,"w")&&f){fputs("One paired frame for modern renderer integration",f);fclose(f);}
 sprintf_s(path,"%sRFGRVR-modern-engine-capture.enable",folder);DeleteFileA(path);
}
}
