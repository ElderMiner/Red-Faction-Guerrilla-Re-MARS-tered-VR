#pragma once
#include <windows.h>
#include "vr_visual_mode.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <mutex>
#include <atomic>
#include <cstring>
#include <cstdio>
#include "modern_lighting_ids.h"
#include "modern_terrain.h"
#include "modern_surface.h"
#include "modern_generated.h"
#include "modern_hdr.h"
#include "modern_sky_material.h"
#include "modern_glass.h"
#include "modern_shader_catalog.h"
namespace modernlight {
inline std::atomic<unsigned> matched{0},replaced{0},failures{0};
inline auto& bypass=vrvisual::vanilla; inline bool toggleHeld=false;
inline bool available(){return true;}inline bool enabled(){return available()&&!bypass.load(std::memory_order_acquire);}
// Hybrid experiment retains native surface/sky shading and native exposure.
inline bool transportEnabled(){return false;}
inline bool nativeNightGrading(){return !transportEnabled();}
// Shipping visuals follow the existing persisted VR setting; no keyboard comparison controls.
inline void configure(bool improved){bypass.store(!improved,std::memory_order_release);}
inline void toggleInput(bool,bool){}
inline void pollToggle(){}
inline const GUID originalShaderTag={0x7653fa23,0x619b,0x4c89,{0x81,0x74,0x99,0xc1,0x42,0xb6,0x5a,0x80}};
inline Microsoft::WRL::ComPtr<ID3D11PixelShader> originalShader(ID3D11PixelShader* replacement){Microsoft::WRL::ComPtr<ID3D11PixelShader> original;if(replacement){UINT size=sizeof(ID3D11PixelShader*);ID3D11PixelShader* value=nullptr;if(SUCCEEDED(replacement->GetPrivateData(originalShaderTag,&size,&value))&&size==sizeof(value))original.Attach(value);}return original;}

inline int identify(const void* bytes,size_t count){if(!bytes||count<32||memcmp(bytes,"DXBC",4))return -1;for(const auto& i:identities)if(count==i.bytes&&!memcmp((const char*)bytes+4,i.hash,16))return int(i.mode);return -1;}
inline constexpr char source[]=R"MODERN(
// OPTICAL_HELPERS_BEGIN
// Shared optical response for verified material interfaces. All radiance is HDR.
float3 modernFresnel(float3 f0,float cosine){return saturate(f0)+(1-saturate(f0))*pow(1-saturate(cosine),5);}
float modernDielectric(float cosine,float etaI,float etaT){
 float c=saturate(abs(cosine)),eta=etaI/max(etaT,.001),k=1-eta*eta*(1-c*c);if(k<=0)return 1;
 float t=sqrt(k),s=(etaI*c-etaT*t)/max(etaI*c+etaT*t,1e-7),p=(etaT*c-etaI*t)/max(etaT*c+etaI*t,1e-7);return saturate((s*s+p*p)*.5);
}
float3 modernBeer(float3 absorption,float distance){return exp(-max(absorption,0)*max(distance,0));}
float modernLightRange(float distance,float range){float q=saturate(distance/max(range,.001)),window=1-q*q*q*q;return window*window/max(distance*distance,1);}
float modernNativeLightRange(float distance,float offset,float scale){return scale>1e-7&&offset>0?modernLightRange(distance,offset/scale):saturate(offset-distance*scale);}
// Preserve authored normal-incidence opacity, increasing optical path at grazing.
float modernGlassOpacity(float opacity,float cosine,float ior){
 if(opacity>=1)return 1;float eta=1/max(ior,1.001),ct=sqrt(max(1-eta*eta*(1-saturate(cosine*cosine)),.0001));
 float base=pow(max(1-saturate(opacity),1e-6),1/ct);float f=modernDielectric(cosine,1,ior),normal=modernDielectric(1,1,ior);
 return saturate(1-base*(1-f)/max(1-normal,.001));
}

Texture2D<float2> modernMaterial0:register(t25),modernMaterial1:register(t26),modernMaterial2:register(t27),modernMaterial3:register(t28);
float3 modernMaterialMap(float2 uv,int layer,SamplerState state){
 uint w,h;float2 value;
 if(layer==0){modernMaterial0.GetDimensions(w,h);if(!w)return 0;value=modernMaterial0.Sample(state,uv);}
 else if(layer==1){modernMaterial1.GetDimensions(w,h);if(!w)return 0;value=modernMaterial1.Sample(state,uv);}
 else if(layer==2){modernMaterial2.GetDimensions(w,h);if(!w)return 0;value=modernMaterial2.Sample(state,uv);}
 else {modernMaterial3.GetDimensions(w,h);if(!w)return 0;value=modernMaterial3.Sample(state,uv);}
 return float3(value,1);
}
void modernApplyMaterialMap(float3 estimate,inout float roughness,inout float reflectivity){
 if(estimate.z<=0)return;float2 value=estimate.xy/max(estimate.z,1e-5);float confidence=saturate(estimate.z);
 // Authored material response bounds the texture-derived approximation.
 roughness=lerp(roughness,max(roughness*.65,value.y),confidence*.5);
 reflectivity=lerp(reflectivity,max(reflectivity*.5,value.x*.35),confidence);
}

// OPTICAL_HELPERS_END





















































































#ifndef MATERIAL_ROWS
#define MATERIAL_ROWS 9
#endif
#ifndef DIFF_T
#define DIFF_T t0
#endif
#ifndef DIFF_S
#define DIFF_S s0
#endif
#ifndef NORMAL_T
#define NORMAL_T t1
#endif
#ifndef NORMAL_S
#define NORMAL_S s1
#endif
#ifndef SPEC_T
#define SPEC_T t2
#endif
#ifndef SPEC_S
#define SPEC_S s2
#endif
#ifndef HAS_SPEC
#define HAS_SPEC 1
#endif
#ifndef M_COLOUR
#define M_COLOUR material[6]
#endif
#ifndef M_NORMAL
#define M_NORMAL material[7].z
#endif
#ifndef M_OPACITY
#define M_OPACITY material[7].w
#endif
#ifndef M_EMISSIVE
#define M_EMISSIVE material[8].x
#endif
#ifndef M_SPEC_ALPHA
#define M_SPEC_ALPHA material[8].y
#endif
#ifndef M_SPEC_POWER
#define M_SPEC_POWER material[8].z
#endif

// Original replacement material shading. Native texture/constant interfaces
// were verified locally; no native shader bytecode is embedded here.
cbuffer Common : register(b0) { float4 common[11]; };
cbuffer Lighting : register(b1) { float4 lighting[3]; };
cbuffer Material : register(b2) { float4 material[MATERIAL_ROWS]; };
cbuffer Instance : register(b6) { float4 tint; float4 alphaControl; };
Texture2D<float4> diffuseMap:register(DIFF_T),normalMap:register(NORMAL_T),specularMap:register(SPEC_T),shadowMap:register(t15);
SamplerState diffuseSampler:register(DIFF_S),normalSampler:register(NORMAL_S),specularSampler:register(SPEC_S),shadowSampler:register(s15);
struct In {float4 position:SV_Position;float2 uv:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float4 upOrSpotFog:TEXCOORD3;};
float3 safeUnit(float3 v){return v*rsqrt(max(dot(v,v),1e-8));}
float3 fresnel(float3 f0,float voh){float f=pow(1-saturate(voh),5);return f0+(1-f0)*f;}
float4 main(In i):SV_Target {
 float4 texel=diffuseMap.Sample(diffuseSampler,i.uv);
 float alpha=lerp(texel.a,1,saturate(M_OPACITY));
 if(alphaControl.y!=0)clip(alpha-alphaControl.x);
 float4 encoded=normalMap.Sample(normalSampler,i.uv);
 float2 xy=float2((encoded.r*2-1)*(encoded.a*2-1),encoded.g*2-1);
 float3 N=safeUnit(lerp(float3(0,0,1),float3(xy,sqrt(saturate(1-dot(xy,xy)))),saturate(M_NORMAL)));
 float3 L=safeUnit(i.toLight),V=safeUnit(i.toEye),H=safeUnit(L+V);
 float noL=saturate(dot(N,L)),noV=max(saturate(dot(N,V)),.001),noH=saturate(dot(N,H)),voH=saturate(dot(V,H));
 float3 base=max(texel.rgb*M_COLOUR.rgb,0);
 #if HAS_SPEC
 float3 legacySpec=specularMap.Sample(specularSampler,i.uv).rgb*max(M_SPEC_ALPHA,0);
 #else
 float3 legacySpec=0;
 #endif
 // Legacy assets have specular maps rather than authored metal/rough textures.
 // Preserve the authored specular mask; it is not a metallic F0 map.
 float roughness=clamp(pow(2/(max(M_SPEC_POWER,1)+2),.25),.18,.98);
 float3 f0=.04;float3 specularMask=saturate(legacySpec);
 float mapStrength=1;modernApplyMaterialMap(modernMaterialMap(i.uv,0,diffuseSampler),roughness,mapStrength);specularMask*=mapStrength;
 float a=roughness*roughness,a2=a*a,den=noH*noH*(a2-1)+1;
 float distribution=a2/(3.14159265*max(den*den,1e-7));
 float visibility=.5/max(noL*sqrt(noV*noV*(1-a2)+a2)+noV*sqrt(noL*noL*(1-a2)+a2),1e-5);
 float3 F=fresnel(f0,voH)*specularMask;
 float3 direct=((1-F)*base/3.14159265+distribution*visibility*F)*noL;
 float2 screenUV=i.position.xy*common[6].zw;
 float2 shadow=shadowMap.Sample(shadowSampler,screenUV).rg;
 float3 colour=direct*max(lighting[0].rgb,0)*saturate(shadow.y);
 #if LOCAL_LIGHT
 float distance=length(i.toLight),attenuation=modernNativeLightRange(distance,lighting[1].x,lighting[1].y);
 float spot=max(min(dot(-L,i.upOrSpotFog.xyz),lighting[2].x)-lighting[2].y,0)*lighting[2].z;
 colour*=attenuation*(lighting[2].w>0?saturate(spot):1);
 colour*=1-saturate(i.upOrSpotFog.w);
 #else
 float hemisphere=saturate(dot(N,safeUnit(i.upOrSpotFog.xyz))*.5+.5);
 float3 irradiance=lerp(max(common[3].rgb,0),max(common[2].rgb,0),hemisphere);
 colour+=base*(1-fresnel(f0,noV)*specularMask)*irradiance*saturate(shadow.x);
 colour+=base*(1-texel.a)*max(M_EMISSIVE,0);
 colour=lerp(colour,max(common[4].rgb,0),saturate(i.upOrSpotFog.w));
 #endif
 return float4(max(colour,0),alpha)*tint;
}
)MODERN";
using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11PixelShader**);
inline void report(int mode,HRESULT result){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,'\\');if(!slash)return;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-Modern-Lighting.log");FILE* file=nullptr;if(!fopen_s(&file,path,"a")&&file){fprintf(file,"material mode=%d result=%08lx matched=%u replaced=%u failures=%u\n",mode,(unsigned long)result,matched.load(),replaced.load(),failures.load());fclose(file);}}
inline HRESULT createReplacement(Create native,ID3D11Device* device,const void* bytes,SIZE_T count,ID3D11ClassLinkage* linkage,ID3D11PixelShader** shader,bool active){int sky=active&&!linkage?modernskymaterial::identify(bytes,count):-1;if(sky>=0){++matched;bool substituted=false;auto hr=modernskymaterial::create(native,device,bytes,count,shader,sky,substituted);if(substituted)++replaced;else ++failures;report(600+sky,hr);if(substituted&&shader)moderncatalog::record(*shader,bytes,count,600+sky);return hr;}int generated=active&&!linkage?moderngenerated::identify(bytes,count):-1;if(generated>=0){++matched;bool substituted=false;auto hr=moderngenerated::create(native,device,bytes,count,shader,generated,substituted);if(substituted)++replaced;else ++failures;report(500+generated,hr);if(substituted&&shader)moderncatalog::record(*shader,bytes,count,500+generated);return hr;}int glass=active&&!linkage?modernglass::identify(bytes,count):-1;if(glass>=0){++matched;bool substituted=false;auto hr=modernglass::create(native,device,bytes,count,shader,glass,substituted);if(substituted)++replaced;else ++failures;report(400+glass,hr);if(substituted&&shader)moderncatalog::record(*shader,bytes,count,400+glass);return hr;}int hdr=active&&!linkage?modernhdr::identify(bytes,count):-1;if(hdr>=0){++matched;bool substituted=false;auto hr=modernhdr::create(native,device,bytes,count,shader,hdr,substituted);if(substituted)++replaced;else ++failures;report(300+hdr,hr);if(substituted&&shader)moderncatalog::record(*shader,bytes,count,300+hdr);return hr;}int surface=active&&!linkage?modernsurface::identify(bytes,count):-1;if(surface>=0){++matched;bool substituted=false;auto hr=modernsurface::create(native,device,bytes,count,shader,surface,substituted);if(substituted)++replaced;else ++failures;report(200+surface,hr);if(substituted&&shader)moderncatalog::record(*shader,bytes,count,200+surface);return hr;}int terrain=active&&!linkage?modernterrain::identify(bytes,count):-1;if(terrain>=0){++matched;bool substituted=false;auto hr=modernterrain::create(native,device,bytes,count,shader,terrain,substituted);if(substituted)++replaced;else ++failures;report(100+terrain,hr);if(substituted&&shader)moderncatalog::record(*shader,bytes,count,100+terrain);return hr;}int mode=active&&!linkage?identify(bytes,count):-1;if(mode<0){auto hr=native(device,bytes,count,linkage,shader);if(active&&SUCCEEDED(hr)&&shader)moderncatalog::record(*shader,bytes,count,-1);return hr;}++matched;
 static std::mutex guard;static Microsoft::WRL::ComPtr<ID3DBlob> code[sizeof(variants)/sizeof(variants[0])];std::lock_guard<std::mutex> lock(guard);
 HRESULT hr=S_OK;if(!code[mode]){auto v=variants[mode];D3D_SHADER_MACRO macros[]={{"LOCAL_LIGHT",v.local},{"MATERIAL_ROWS",v.rows},{"DIFF_T",v.diffT},{"DIFF_S",v.diffS},{"NORMAL_T",v.normalT},{"NORMAL_S",v.normalS},{"SPEC_T",v.specT},{"SPEC_S",v.specS},{"HAS_SPEC",v.hasSpec},{"M_COLOUR",v.colour},{"M_NORMAL",v.normalHeight},{"M_OPACITY",v.opacity},{"M_EMISSIVE",v.emissive},{"M_SPEC_ALPHA",v.specAlpha},{"M_SPEC_POWER",v.specPower},{nullptr,nullptr}};Microsoft::WRL::ComPtr<ID3DBlob> errors;hr=D3DCompile(source,sizeof(source)-1,"RFGRVR modern material",macros,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code[mode],&errors);}
 if(SUCCEEDED(hr)&&code[mode])hr=native(device,code[mode]->GetBufferPointer(),code[mode]->GetBufferSize(),nullptr,shader);
 if(SUCCEEDED(hr)){++replaced;report(mode,hr);if(shader)moderncatalog::record(*shader,bytes,count,mode);return hr;}++failures;report(mode,hr);return native(device,bytes,count,linkage,shader);
}
// Retain the exact native shader, not a reimplementation of the baseline.
inline HRESULT create(Create native,ID3D11Device* device,const void* bytes,SIZE_T count,ID3D11ClassLinkage* linkage,ID3D11PixelShader** shader,bool active){
 if(active&&!linkage&&modernhdr::identify(bytes,count)<0){auto hr=native(device,bytes,count,linkage,shader);if(SUCCEEDED(hr)&&shader)moderncatalog::record(*shader,bytes,count,-1);return hr;}
 int sky=active&&!linkage?modernskymaterial::identify(bytes,count):-1,generated=active&&!linkage?moderngenerated::identify(bytes,count):-1;if(sky>=0||(generated>=0&&atoi(moderngenerated::variants[generated].values[0])==3)){auto hr=native(device,bytes,count,linkage,shader);if(SUCCEEDED(hr)&&shader)moderncatalog::record(*shader,bytes,count,-1);return hr;}
 auto hr=createReplacement(native,device,bytes,count,linkage,shader,active);if(FAILED(hr)||!shader||!*shader||!active||!modernmaterial::tagged(*shader))return hr;
 Microsoft::WRL::ComPtr<ID3D11PixelShader> original;auto fallback=native(device,bytes,count,linkage,&original);if(FAILED(fallback)||!original){(*shader)->Release();*shader=nullptr;return fallback;}
 auto attached=(*shader)->SetPrivateDataInterface(originalShaderTag,original.Get());if(FAILED(attached)){(*shader)->Release();*shader=original.Detach();}return hr;
}}
