#pragma once
#include <cstring>
namespace vrdlc {
inline bool testingHandheld(const char* name){
 if(!name)return false;
 constexpr const char* names[]={"edf_pistol","m16","autoblaster","enforcer","gauss_rifle","sniper_rifle","rail_driver","mine_placer","charge_placer","rpg_launcher","thermobaric_rockets","nano_rifle","grinder","arc_welder","shotgun","gutter","marauder_shockade","royal_sword","pickaxe","mar_charge_placer","spiker","EDF_Super_Gauss","missilepod","edf_subverter"};
 for(auto* expected:names)if(!strcmp(name,expected))return true;return false;
}
inline bool accidentalGrant(const char* name,const char* inventory){
 return name&&((inventory&&!strcmp(inventory,"generic_inventory_item"))||!strncmp(name,"ab_rpg",6)||!strcmp(name,"satellite_rpg"));
}
struct ArsenalRecord {unsigned id;unsigned char enabled,padding[3];};
static_assert(sizeof(ArsenalRecord)==8,"Native arsenal record");
template<class Remove> unsigned compactAccidental(ArsenalRecord* records,unsigned count,Remove remove){
 unsigned kept=0;for(unsigned i=0;i<count;++i)if(!remove(records[i].id)){if(kept!=i)records[kept]=records[i];++kept;}return kept;
}
}
