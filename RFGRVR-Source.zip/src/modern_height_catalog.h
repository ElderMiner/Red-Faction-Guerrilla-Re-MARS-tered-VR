#pragma once
#include <windows.h>
#include <wincrypt.h>
#include <d3d11.h>
#include <wrl/client.h>
#include <atomic>
#include <vector>
#include <mutex>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <cmath>
#include <algorithm>
namespace modernheight {
template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
inline constexpr GUID attachmentId={0x15bd460c,0x7e24,0x436a,{0xb2,0xc4,0x29,0x84,0x61,0xa9,0x02,0x91}};
inline constexpr GUID reflectivityId={0x8a76407a,0x31bd,0x4b5b,{0xa9,0x15,0x7a,0x52,0x39,0x11,0x6b,0xcd}};
inline std::atomic<size_t> resident{0};inline constexpr size_t maxResident=64*1024*1024;
inline std::atomic<unsigned> attached{0},materialAttached{0},unmatched{0},rejected{0};
inline bool sha256(const void* bytes,size_t count,unsigned char* output){
 using Hash=BOOL(WINAPI*)(LPCWSTR,DWORD,void*,const BYTE*,DWORD,BYTE*,DWORD*);
 static HMODULE library=LoadLibraryExW(L"crypt32.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
 static auto hash=library?(Hash)GetProcAddress(library,"CryptHashCertificate2"):nullptr;
 DWORD size=32;return hash&&bytes&&count<=0xffffffffu&&hash(L"SHA256",0,nullptr,(const BYTE*)bytes,DWORD(count),output,&size)&&size==32;
}
// The normal texture/SRV owns this attachment. It owns only the independent
// height SRV, so there is no texture -> view -> same-texture COM cycle.
class Attachment final:public IUnknown {
 std::atomic<ULONG> refs{1};size_t bytes;
public:
 Ptr<ID3D11ShaderResourceView> view;
 explicit Attachment(ID3D11ShaderResourceView* v,size_t n):bytes(n),view(v){}
 ~Attachment(){resident.fetch_sub(bytes);}
 HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id,void** out)override{if(!out)return E_POINTER;*out=nullptr;if(id!=__uuidof(IUnknown))return E_NOINTERFACE;*out=(IUnknown*)this;AddRef();return S_OK;}
 ULONG STDMETHODCALLTYPE AddRef()override{return ++refs;}
 ULONG STDMETHODCALLTYPE Release()override{auto left=--refs;if(!left)delete this;return left;}
};
inline Ptr<Attachment> attachment(ID3D11DeviceChild* object,const GUID& id=attachmentId){Ptr<Attachment> result;IUnknown* value=nullptr;UINT size=sizeof(value);if(object&&SUCCEEDED(object->GetPrivateData(id,&size,&value))&&size==sizeof(value)&&value)result.Attach(static_cast<Attachment*>(value));return result;}
inline void tagView(ID3D11Resource* resource,ID3D11ShaderResourceView* view){for(auto id:{attachmentId,reflectivityId}){auto owner=attachment(resource,id);if(owner&&view)view->SetPrivateDataInterface(id,owner.Get());}}
// Inputs are validated normalized, finite, nonnegative half values.
inline float unpackHalf(uint16_t v){unsigned e=v>>10,m=v&1023;return std::ldexp(float(e?1024+m:m),e?int(e)-25:-24);}
inline uint16_t packHalf(float v){if(v<0x1p-14f)return uint16_t(v*0x1p24f+.5f);int e=0;float f=std::frexp(v,&e);unsigned m=unsigned((f*2-1)*1024+.5f);if(m==1024){m=0;++e;}return uint16_t(((e+14)<<10)|m);}
inline size_t mipBytes(unsigned w,unsigned h){size_t n=0;for(;;){n+=size_t(w)*h*2;if(w==1&&h==1)return n;w=(std::max)(w/2,1u);h=(std::max)(h/2,1u);}}
class Catalogue {
 bool reflectivity=false;
 struct Record {unsigned char hash[32];unsigned sourceWidth,sourceHeight,width,height;uint64_t bytes,offset;};
 std::vector<Record> records;FILE* file=nullptr;std::mutex mutex;bool attempted=false;
 bool loadLocked(const wchar_t* path){
  if(file)fclose(file);file=nullptr;records.clear();attempted=true;
  FILE* input=nullptr;if(_wfopen_s(&input,path,L"rb")||!input)return false;
  struct Close {FILE* f;~Close(){if(f)fclose(f);}} close{input};
  _fseeki64(input,0,SEEK_END);auto length=_ftelli64(input);if(length<16)return false;_fseeki64(input,0,SEEK_SET);
  char magic[8];uint32_t version=0,count=0;if(fread(magic,1,8,input)!=8||memcmp(magic,reflectivity?"RFGRMAT\0":"RFGRHGT\0",8)||fread(&version,4,1,input)!=1||version!=1||fread(&count,4,1,input)!=1||count>512)return false;
  std::vector<Record> next;for(unsigned i=0;i<count;++i){Record r{};if(fread(r.hash,1,32,input)!=32||fread(&r.sourceWidth,4,4,input)!=4||fread(&r.bytes,8,1,input)!=1)return false;
   if(r.sourceWidth<4||r.sourceHeight<4||r.sourceWidth>8192||r.sourceHeight>8192||r.width<4||r.height<4||r.width>2048||r.height>2048||r.bytes!=uint64_t(r.width)*r.height*2)return false;
   r.offset=_ftelli64(input);if(r.offset>uint64_t(length)||r.bytes>uint64_t(length)-r.offset)return false;_fseeki64(input,(__int64)r.bytes,SEEK_CUR);next.push_back(r);}
  if(_ftelli64(input)!=length)return false;records.swap(next);file=input;close.f=nullptr;return true;
 }
public:
 explicit Catalogue(bool material=false):reflectivity(material){}
 ~Catalogue(){if(file)fclose(file);}
 bool load(const wchar_t* path){std::lock_guard<std::mutex> lock(mutex);return loadLocked(path);}
 bool attach(ID3D11Device* d,ID3D11Texture2D* normal,const D3D11_TEXTURE2D_DESC& desc,const D3D11_SUBRESOURCE_DATA* input){
  if(!d||!normal||!input||!input->pSysMem||desc.ArraySize!=1||desc.SampleDesc.Count!=1||desc.Width<4||desc.Height<4||desc.Width>8192||desc.Height>8192||(desc.Format!=DXGI_FORMAT_BC1_UNORM&&desc.Format!=DXGI_FORMAT_BC1_UNORM_SRGB&&desc.Format!=DXGI_FORMAT_BC1_TYPELESS&&(!reflectivity||(desc.Format!=DXGI_FORMAT_BC3_UNORM&&desc.Format!=DXGI_FORMAT_BC3_UNORM_SRGB&&desc.Format!=DXGI_FORMAT_BC3_TYPELESS))))return false;
  std::lock_guard<std::mutex> lock(mutex);if(!attempted){wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(slash)wcscpy_s(slash+1,MAX_PATH-(slash+1-path),reflectivity?L"RFGRVR\\material-reflectivity.rfgo":L"RFGRVR\\terrain-heights.rfgh");loadLocked(path);}
  bool shape=false;for(auto& r:records)shape|=r.sourceWidth==desc.Width&&r.sourceHeight==desc.Height;if(!file||!shape)return false;
  bool bc3=desc.Format==DXGI_FORMAT_BC3_UNORM||desc.Format==DXGI_FORMAT_BC3_UNORM_SRGB||desc.Format==DXGI_FORMAT_BC3_TYPELESS;size_t pitch=((desc.Width+3)/4)*(bc3?16:8),rows=(desc.Height+3)/4;if(input->SysMemPitch<pitch)return false;
  std::vector<unsigned char> packed(pitch*rows);for(size_t y=0;y<rows;++y)memcpy(packed.data()+y*pitch,(const char*)input->pSysMem+y*input->SysMemPitch,pitch);
  unsigned char checksum[32];if(!sha256(packed.data(),packed.size(),checksum))return false;
  const Record* chosen=nullptr;for(auto& r:records)if(r.sourceWidth==desc.Width&&r.sourceHeight==desc.Height&&!memcmp(r.hash,checksum,32)){chosen=&r;break;}if(!chosen){++unmatched;return false;}
  auto& r=*chosen;size_t allocation=mipBytes(r.width,r.height),used=resident.load();do{if(used+allocation>maxResident)return false;}while(!resident.compare_exchange_weak(used,used+allocation));
  struct Budget {size_t n;~Budget(){if(n)resident.fetch_sub(n);}} claim{allocation};
  std::vector<uint16_t> pixels(size_t(r.bytes)/2);_fseeki64(file,(__int64)r.offset,SEEK_SET);if(fread(pixels.data(),1,size_t(r.bytes),file)!=r.bytes)return false;for(auto value:pixels)if(!reflectivity&&value>0x3c00){++rejected;return false;}
  std::vector<std::vector<uint16_t>> levels;levels.push_back(std::move(pixels));unsigned w=r.width,h=r.height;
  while(w>1||h>1){unsigned nw=(std::max)(w/2,1u),nh=(std::max)(h/2,1u);std::vector<uint16_t> next(size_t(nw)*nh);auto& prev=levels.back();
   for(unsigned y=0;y<nh;++y)for(unsigned x=0;x<nw;++x){float sum=0,second=0;unsigned count=0;for(unsigned sy=y*h/nh;sy<(y+1)*h/nh;++sy)for(unsigned sx=x*w/nw;sx<(x+1)*w/nw;++sx){auto value=prev[size_t(sy)*w+sx];sum+=reflectivity?float(value&255):unpackHalf(value);if(reflectivity)second+=float(value>>8);++count;}next[size_t(y)*nw+x]=reflectivity?uint16_t(unsigned(sum/count+.5f)|(unsigned(second/count+.5f)<<8)):packHalf(sum/count);}levels.push_back(std::move(next));w=nw;h=nh;}
  std::vector<D3D11_SUBRESOURCE_DATA> data;w=r.width;h=r.height;for(auto& level:levels){data.push_back({level.data(),w*2,0});w=(std::max)(w/2,1u);h=(std::max)(h/2,1u);}
  D3D11_TEXTURE2D_DESC td{};td.Width=r.width;td.Height=r.height;td.ArraySize=td.SampleDesc.Count=1;td.MipLevels=unsigned(levels.size());td.Format=reflectivity?DXGI_FORMAT_R8G8_UNORM:DXGI_FORMAT_R16_FLOAT;td.Usage=D3D11_USAGE_IMMUTABLE;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;Ptr<ID3D11Texture2D> height;Ptr<ID3D11ShaderResourceView> view;
  if(FAILED(d->CreateTexture2D(&td,data.data(),&height))||FAILED(d->CreateShaderResourceView(height.Get(),nullptr,&view)))return false;
  auto* owner=new Attachment(view.Get(),allocation);claim.n=0;HRESULT hr=normal->SetPrivateDataInterface(reflectivity?reflectivityId:attachmentId,owner);owner->Release();if(SUCCEEDED(hr)){++attached;if(reflectivity)++materialAttached;}return SUCCEEDED(hr);
 }
};
inline Catalogue catalogue;inline Catalogue materialCatalogue{true};
}
