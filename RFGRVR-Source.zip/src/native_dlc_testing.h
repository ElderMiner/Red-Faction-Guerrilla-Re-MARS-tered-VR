#pragma once
#include "vr_dlc.h"
// Deliberate DLC testing grants, through the engine's own locker list.
// Never grant from the campaign, menus, NPC updates, or a render callback.
namespace DlcTesting {
inline void update(void* player){
 static DWORD last=0;DWORD now=GetTickCount();if(DWORD(now-last)<2000)return;last=now;
 if(!vrdlc::active.load()||!RFGRVR_HeadCam_IsLocalPlayer(player)||word(player,0x2f4)>2||word(player,0x33c))return;
 constexpr unsigned char markSig[]={0x56,0x8b,0x74,0x24,0x08,0x85,0xf6};
 constexpr unsigned char grantSig[]={0x83,0xec,8,0x56,0x8b,0x74,0x24,0x10};
 if(memcmp(base+0x45b3b0,markSig,sizeof(markSig))||memcmp(base+0x477200,grantSig,sizeof(grantSig)))return;
 using Mark=bool(__cdecl*)(void*,bool);using Grant=void(__cdecl*)(void*,bool);
 unsigned count=word(base,0x3482c94);auto* definitions=(char*)(uintptr_t)word(base,0x3482c9c);
 if(!count||count>1024||!memory(definitions,count*0x230))return;
 auto nameOf=[&](void* info)->const char*{auto* name=(const char*)(uintptr_t)word(info,0);return memory(name,96)&&memchr(name,0,96)?name:nullptr;};
 // The old broad test grant filled the fixed 64-entry native array with
 // mounted/debug definitions. Remove only those verified accidental entries,
 // preserving every other full record and its original order/flags.
 unsigned before=word(base,0x1261edc),capacity=word(base,0x1261ed8);auto* records=(vrdlc::ArsenalRecord*)(uintptr_t)word(base,0x1261ed4);
 if(capacity!=64||before>capacity||!vrmemory::check(records,before*8,true)||!vrmemory::check(base+0x1261edc,4,true))return;
 unsigned kept=vrdlc::compactAccidental(records,before,[&](unsigned id){for(unsigned i=0;i<count;++i){auto* info=definitions+i*0x230;if(word(info,8)==id){auto* inventory=(void*)(uintptr_t)word(info,0x18);return vrdlc::accidentalGrant(nameOf(info),nameOf(inventory));}}return false;});
 if(kept!=before){memcpy(base+0x1261edc,&kept,4);char text[128];sprintf_s(text,"DLC locker repair: removed %u mounted/debug testing entries",before-kept);log(text);}
 unsigned added=0;
 for(unsigned i=0;i<count;++i){auto* info=definitions+i*0x230;
  unsigned kind=word(info,0x10),flags=word(info,0xc);
  if(kind>=17||(flags&0x8100)||!word(info,0x18)||!vrdlc::testingHandheld(nameOf(info)))continue;
  unsigned n=word(base,0x1261edc);void* data=(void*)(uintptr_t)word(base,0x1261ed4);
  if(n>256||(n&&!memory(data,n*8)))return;
  bool listed=false;for(unsigned j=0;j<n;++j)if(word(data,j*8)==word(info,8)&&*((unsigned char*)data+j*8+4)){listed=true;break;}
  if(!listed&&n<capacity){if(!((Mark)(base+0x45b3b0))(info,true))((Grant)(base+0x477200))(info,true);unsigned after=word(base,0x1261edc);if(after>n)++added;}
 }
 if(added){char text[128];sprintf_s(text,"DLC testing: %u native locker weapon grants",added);log(text);}
}
}
