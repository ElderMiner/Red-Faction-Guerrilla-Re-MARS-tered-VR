#pragma once
#include "vr_memory_access.h"
#include "vr_orbital_billboard.h"
#include <atomic>
extern "C" bool RFGRVR_HeadCam_Enabled();
namespace vrcoronabillboard {
inline std::atomic<unsigned> spinRemoved{0};
// Native vertex packet starts at 12AE1B (POSITION). TEXCOORD1.x is
// populated from source+64 at 12AE6E. rl_corona VS multiplies that value
// by dot(normalize(eye-light), camRot[0]) to rotate its flare image.
// Preserve authored TEXCOORD2.z rotation (+68), disable only view spin.
struct Source {
 alignas(16) unsigned char bytes[0x118]{};void* original=nullptr;
 unsigned adaptation=0;
 void* forDraw(void* source,uintptr_t pass,bool enabled){
  if(!enabled||pass||!vrmemory::check(source,sizeof(bytes),true))return source;
  float spin;memcpy(&spin,(char*)source+0x64,4);
  if(!std::isfinite(spin)||spin==0)return source;
  memcpy(bytes,source,sizeof(bytes));original=source;memcpy(&adaptation,bytes+0xc4,4);
  const float zero=0;memcpy(bytes+0x64,&zero,4);++spinRemoved;return bytes;
 }
 ~Source(){
  // Pass 0's only native source write is visibility adaptation (+C4).
  // Keep that evolving state, without copying private rendering overrides.
  if(original&&memcmp(bytes+0xc4,&adaptation,4))memcpy((char*)original+0xc4,bytes+0xc4,4);
 }
};
// Native 12ACA4 uploads camera+8 as the glow's billboard rotation; 12ACDB
// reads its position at +2C. Source position is copied from +14 at 12AE1B.
// Screen-aligned billboards visibly pivot with HMD yaw. Face the light-to-eye
// ray instead, retaining a world-up meridian and the actual eye translation.
struct Camera {
 alignas(16) unsigned char bytes[0x38]{};
 uintptr_t forDraw(uintptr_t camera,const void* source,uintptr_t pass,bool enabled){
  if(!enabled||pass||!vrmemory::check((void*)camera,sizeof(bytes))||!vrmemory::check(source,0x20))return camera;
  vrarm::V eye,light;memcpy(&eye,(char*)camera+0x2c,12);memcpy(&light,(const char*)source+0x14,12);
  vrarm::M axes;if(!RFGRVR_OrbitalBillboard(vrarm::sub(eye,light),axes))return camera;
  memcpy(bytes,(void*)camera,sizeof(bytes));memcpy(bytes+8,&axes,36);return uintptr_t(bytes);
 }
};
}
