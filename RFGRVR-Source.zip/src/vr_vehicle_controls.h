#pragma once
#include <cmath>
#include <algorithm>
#include <atomic>
#include <windows.h>
struct RFGRVRVehicleControls {
 unsigned identity=~0u;float height=0;bool held=false,reticle=false;
 void update(unsigned vehicle,float axis,bool button,float dt,float upper=.6f){
  if(vehicle!=identity){identity=vehicle;height=0;reticle=false;held=button;}
  if(vehicle==~0u){height=0;reticle=false;held=button;return;}
  if(button&&!held)reticle=!reticle;held=button;
  if(!std::isfinite(dt)||dt<=0||!std::isfinite(axis))return;if(dt>.05f)dt=.05f;
  float a=fabsf(axis)>.2f?(axis-(axis>0?.2f:-.2f))/.8f:0;
  height+=a*.3f*dt;if(!std::isfinite(upper)||upper<.6f||upper>1.2f)upper=.6f;if(height>upper)height=upper;if(height<-.6f)height=-.6f;
 }
};

inline short RFGRVR_MechSteering(short axis){int value=axis;int magnitude=value<0?-value:value;if(magnitude<=7000)return 0;int reduced=7000+int((magnitude-7000)*.065f);return short(value<0?-reduced:reduced);}


namespace RFGRVRMechInput {
inline std::atomic<short> turn{0};inline std::atomic<ULONGLONG> tick{0};
inline void publish(short axis){turn=axis;tick.store(GetTickCount64(),std::memory_order_release);}
inline float rate(float maximum=.75f){if(GetTickCount64()-tick.load(std::memory_order_acquire)>250||!std::isfinite(maximum)||maximum<0)return 0;float a=(std::clamp)(turn.load()/32767.f,-1.f,1.f);return fabsf(a)>.22f?(a-(a>0?.22f:-.22f))/.78f*maximum:0;}
}

struct RFGRVRVehicleHeightBlend {
 unsigned vehicle=~0u,seat=~0u;float value=0;
 float update(unsigned id,unsigned role,float target,float seconds){if(id!=vehicle||role!=seat||id==~0u){vehicle=id;seat=role;value=target;return value;}if(std::isfinite(seconds)&&seconds>0)value+=(target-value)*(1-std::exp(-(std::min)(seconds,.05f)/.18f));return value;}
};
