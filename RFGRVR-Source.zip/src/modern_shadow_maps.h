#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <cstdint>
#include <cmath>
#include <cstring>
namespace modernshadowmaps {
// Native cascade argument 5 is column-major world -> shadow texture space.
// Keep its half-texel/depth bias; the GPU volume constants are row-major.
inline bool matrix(const float* native,float* rowMajor){
 if(!native||!rowMajor)return false;
 for(unsigned i=0;i<16;++i)if(!std::isfinite(native[i]))return false;
 float determinant=native[0]*(native[5]*native[10]-native[6]*native[9])-native[4]*(native[1]*native[10]-native[2]*native[9])+native[8]*(native[1]*native[6]-native[2]*native[5]);
 if(std::abs(determinant)<1e-14f||std::abs(native[3])+std::abs(native[7])+std::abs(native[11])>1e-5f||std::abs(native[15]-1)>1e-5f)return false;
 float result[16];for(unsigned r=0;r<4;++r)for(unsigned c=0;c<4;++c)result[r*4+c]=native[c*4+r];memcpy(rowMajor,result,sizeof(result));return true;
}
// Record copies on the SAME context/command stream as the native depth draw,
// after unbinding its DSV and before the next cascade clears the shared target.
// This class never obtains an immediate context or retains native resources.
class Atlas {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11Texture2D> texture;Ptr<ID3D11ShaderResourceView> view;
 unsigned width=0,height=0,mask=0;DXGI_FORMAT format=DXGI_FORMAT_UNKNOWN;uint64_t frame=0;
public:
 void begin(uint64_t id){if(frame!=id){frame=id;mask=0;}}
 bool copy(ID3D11DeviceContext* context,ID3D11Texture2D* source,unsigned layer,uint64_t id){
  if(!context||!source||layer>=3||id!=frame)return false;
  D3D11_TEXTURE2D_DESC d{};source->GetDesc(&d);
  if(d.MipLevels!=1||d.ArraySize!=1||d.SampleDesc.Count!=1||!d.Width||!d.Height||d.Width>4096||d.Height>4096)return false;
  DXGI_FORMAT readable=d.Format==DXGI_FORMAT_R16_TYPELESS?DXGI_FORMAT_R16_UNORM:d.Format==DXGI_FORMAT_R32_TYPELESS?DXGI_FORMAT_R32_FLOAT:DXGI_FORMAT_UNKNOWN;
  if(readable==DXGI_FORMAT_UNKNOWN)return false;
  Ptr<ID3D11Device> device,sourceDevice;context->GetDevice(&device);source->GetDevice(&sourceDevice);if(device.Get()!=sourceDevice.Get())return false;
  Ptr<ID3D11DepthStencilView> bound;context->OMGetRenderTargets(0,nullptr,&bound);
  if(bound){Ptr<ID3D11Resource> resource;bound->GetResource(&resource);if(resource.Get()==source)return false;}
  if(owner.Get()!=device.Get()||width!=d.Width||height!=d.Height||format!=d.Format){
   d.ArraySize=3;d.Usage=D3D11_USAGE_DEFAULT;d.BindFlags=D3D11_BIND_SHADER_RESOURCE;d.CPUAccessFlags=d.MiscFlags=0;
   Ptr<ID3D11Texture2D> next;Ptr<ID3D11ShaderResourceView> nextView;D3D11_SHADER_RESOURCE_VIEW_DESC sd{};sd.Format=readable;sd.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2DARRAY;sd.Texture2DArray.MipLevels=1;sd.Texture2DArray.ArraySize=3;
   if(FAILED(device->CreateTexture2D(&d,nullptr,&next))||FAILED(device->CreateShaderResourceView(next.Get(),&sd,&nextView)))return false;
   texture=next;view=nextView;owner=device;width=d.Width;height=d.Height;format=d.Format;mask=0;
  }
  // A second eye can generate another cascade set within the same frame.
  // Its first copy invalidates the previous complete set immediately.
  if(layer==0)mask=0;else if(mask!=((1u<<layer)-1))return false;
  context->CopySubresourceRegion(texture.Get(),layer,0,0,0,source,0,nullptr);mask|=1u<<layer;return true;
 }
 ID3D11ShaderResourceView* complete(uint64_t id)const{return id==frame&&mask==7?view.Get():nullptr;}
};
}
