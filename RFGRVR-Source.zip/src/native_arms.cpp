#include "vr_tank_body_frame.h"
#include "vr_head_motion.h"
#include "vr_dlc.h"
#include "vr_crouch_visual.h"
#include "vr_pose_transition.h"
#include "vr_body_yaw.h"
#include "vr_crouch_torso.h"
#include "vr_world_scale.h"
extern "C" bool RFGRVR_HeadCam_IsLocalPlayer(void*);
#include "vr_user_settings.h"
#include "vr_body_visibility.h"
#include "vr_mapping.h"
#include "vr_launch_mode.h"
#include "vr_leg_stability.h"
#include "propane_markers.h"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <atomic>
#include <d3d11.h>
#include <wrl/client.h>
#include "ipc.h"
#include "vr_grip_snapshot.h"
#include "vr_arm_math.h"
#include "vr_weapon_recoil.h"
#include "vr_weapon_weight.h"
#include "vr_elbow_estimator.h"
#include "vr_arm_training.h"
#include "vr_two_hand.h"
#include "vr_charge_grip.h"
#include "vr_charge_trim.h"
#include "weapon_alignment.h"
#include "weapon_scope.h"
#include "weapon_hud_pose.h"
#include "reload_visual.h"
#include "hand_fingers.h"
#include "vr_free_finger.h"
#include "native_weapon_physics.h"
#include "vr_neutral_pose.h"
#include "vr_forward_lean.h"
#include "vr_body_height.h"
#include "../vendor/MinHook.h"
using namespace vrarm;
extern "C" bool RFGRVR_HeadCam_Enabled();
extern "C" bool RFGRVR_HeadCam_ControllerMoving();
extern "C" float RFGRVR_HeadCam_VehicleHeight();
extern "C" bool RFGRVR_HeadCam_TurretRenderRoot(void*,vrarm::Pose*);
extern "C" bool RFGRVR_HeadCam_TurretGunPose(void*,vrarm::Pose*,unsigned*,bool*);
static SRWLOCK turretGripLock=SRWLOCK_INIT;static unsigned turretGripId=~0u;static vrarm::Pose turretGripLocal[2]{};static ULONGLONG turretGripTick=0;static vrarm::V turretHandZero{};static bool turretHandZeroReady=false;static float turretZeroYaw=0,turretZeroHeight=0;
extern "C" float RFGRVR_HeadCam_WorldScale();
extern "C" void RFGRVR_HeadCam_AvatarEye(void*,const float[3]);
namespace {
using SetBone=void(__thiscall*)(void*,int,const V*,const M*);
using Muzzle=void(__thiscall*)(void*,V*,M*);
using FireVectors=void(__thiscall*)(void*,V*,V*,V*);
using SkinBuild=void(__thiscall*)(void*,void*,void*);
using BoneLocal=Pose*(__thiscall*)(void*,Pose*,int);
SkinBuild originalSkin=nullptr;BoneLocal originalLocal=nullptr;
using VisualUpdate=void(__thiscall*)(void*,void*);VisualUpdate originalVisual=nullptr;
using RenderVisibility=void(__thiscall*)(void*,bool);RenderVisibility renderVisibility=nullptr;
using Lookup=void*(__thiscall*)(void*,unsigned);
using PaletteCopy=void(__thiscall*)(void*,const Pose*,unsigned);PaletteCopy paletteCopy=nullptr;
using Expired=bool(__thiscall*)(void*);
using ItemTag=bool(__thiscall*)(void*,int,V*,M*,const V*,const M*);ItemTag originalItemTag=nullptr;
SetBone setBone=nullptr;Muzzle originalMuzzle=nullptr;FireVectors originalFire=nullptr;Lookup lookup=nullptr;Expired expired=nullptr;
unsigned char* base=nullptr;bool installed=false;
SRWLOCK handLock=SRWLOCK_INIT,rigLock=SRWLOCK_INIT;
struct Hands {Pose grip[2],aim[2];ULONGLONG tick=0;bool valid=false;float physicalRoomYaw=0,calibratedSpan=0,bodyOffset=0,gripValue[2]{};unsigned sample=0;Pose physical[2]{},physicalAim[2]{};V physicalBody{};bool physicalBodyValid=false;bool floorFit=false;} hands;
struct WeaponBinding {void* weapon=nullptr;M rootInMuzzle{},wristInMuzzle{};V gripInRoot{},muzzleFromGrip{};int hand=1;void* rig=nullptr;void* attachment=nullptr;unsigned handle=0;int parentTag=-1,childTag=-1;bool gripReady=false,supportReady=false;int supportTag=-1;Pose supportLocal{},primaryWristLocal{};} binding;
extern "C" float RFGRVR_HeadCam_BodyYaw();
extern "C" float RFGRVR_HeadCam_ForwardLean();
extern "C" void RFGRVR_HeadCam_AvatarPelvis(const float[3]);
static RFGRVRWeaponAlignments baseWeaponAlignments,dlcWeaponAlignments;
static RFGRVRWeaponAlignments& activeWeaponAlignments(){return vrdlc::active.load()?dlcWeaponAlignments:baseWeaponAlignments;}
#define weaponAlignments activeWeaponAlignments()
static SRWLOCK weaponTrimLock=SRWLOCK_INIT;static bool weaponTrimsReady=false;
static void initWeaponTrims(){if(weaponTrimsReady)return;weaponTrimsReady=true;
 GetModuleFileNameA(nullptr,baseWeaponAlignments.path,MAX_PATH);char* slash=strrchr(baseWeaponAlignments.path,92);if(slash)strcpy_s(slash+1,MAX_PATH-(slash+1-baseWeaponAlignments.path),"RFGRVR-weapon-alignment.ini");
 GetModuleFileNameA(nullptr,baseWeaponAlignments.legacy,MAX_PATH);slash=strrchr(baseWeaponAlignments.legacy,92);if(slash)strcpy_s(slash+1,MAX_PATH-(slash+1-baseWeaponAlignments.legacy),"RFGRVR-c4-alignment.ini");
 GetModuleFileNameA(nullptr,dlcWeaponAlignments.path,MAX_PATH);slash=strrchr(dlcWeaponAlignments.path,92);if(slash)strcpy_s(slash+1,MAX_PATH-(slash+1-dlcWeaponAlignments.path),"RFGRVR-dlc-weapon-alignment.ini");
 CopyFileA(baseWeaponAlignments.path,dlcWeaponAlignments.path,TRUE);
}
static void log(const char*);
static RFGRVRChargeTrim weaponTrim(const char* name,bool support=false){AcquireSRWLockExclusive(&weaponTrimLock);initWeaponTrims();auto* e=weaponAlignments.find(name);static bool reported[64]{};if(e&&!reported[e-weaponAlignments.entries]){reported[e-weaponAlignments.entries]=true;char text[300];sprintf_s(text,"Loaded saved profile %s itemRot=%.2f/%.2f/%.2f itemPos=%.4f/%.4f/%.4f supportRot=%.2f/%.2f/%.2f supportPos=%.4f/%.4f/%.4f absolute=%d",name,e->trim.rotation[0],e->trim.rotation[1],e->trim.rotation[2],e->trim.position[0],e->trim.position[1],e->trim.position[2],e->support.rotation[0],e->support.rotation[1],e->support.rotation[2],e->support.position[0],e->support.position[1],e->support.position[2],e->supportAbsolute?1:0);log(text);}auto trim=e?(support?e->support:e->trim):RFGRVRChargeTrim{};ReleaseSRWLockExclusive(&weaponTrimLock);return trim;}
static Pose trimmedCharge(M orientation,V grip,V hand){auto trim=weaponTrim("charge_placer");auto pose=trim.apply(RFGRVR_ChargeGrip(orientation,grip,hand),orientation,grip,hand);return RFGRVR_ChargeLift(pose,grip,orientation.r);}
static std::atomic<bool> supportEditing{false};
static constexpr const char* chargeProfile="charge_placer_charge";
static std::atomic<unsigned> chargeCapture{~0u};static vrgrip::Placement chargePlacement;
static std::atomic<unsigned> primaryCapture{~0u};static vrgrip::Placement primaryPlacement;
static std::atomic<unsigned> supportCapture{~0u};static bool supportCaptureReleased=false;
static SRWLOCK recoilLock=SRWLOCK_INIT;static vrrecoil::State weaponRecoil;static vrrecoil::Ballistics weaponBallistics;static vrweight::State weaponWeight;static std::atomic<ULONGLONG> recoilShotTick{0};static std::atomic<unsigned> recoilShotHandle{~0u};
static RFGRVRTwoHand supportHold;static float handPitchUpDegrees=12,weaponPitchDownDegrees=12;
std::atomic<unsigned> playerHandle{0xffffffffu};std::atomic<bool> controlling{false};
unsigned long updates=0,shots=0;void* lastRig=nullptr;
void* alignmentRig=nullptr;M gripAlignment[2]{};V gripCenterInWrist[2]{};bool alignmentReady=false;
extern "C" bool RFGRVR_HeadCam_LandingRecovery();
Pose bodyReturnShoulder[2]{},bodyReturnClavicle[2]{};bool bodyReturnReady=false;RFGRVRCrouchVisual crouchVisual;std::atomic<bool> physicalCrouchVisual{false};
struct ArmRest {void* rig=nullptr;void* weapon=nullptr;unsigned count=0;Pose pose[128]{},solver[128]{};RFGRVRBodyChain body;bool ready=false;} armRest;
static vrtraining::Session armTraining;static RFGRVRElbowEstimator elbowEstimator[2];static RFGRVRElbowProfile elbowProfile;static void* elbowPlayer=nullptr;static void* elbowRig=nullptr;
struct SeatedTurretScaffold {void* player=nullptr;void* rig=nullptr;unsigned turret=~0u,count=0;Pose pose[128]{};
 void reset(){player=rig=nullptr;turret=~0u;count=0;}
 void capture(void* p,void* r,unsigned id,const Pose* native,unsigned n){if(player==p&&rig==r&&turret==id&&count==n)return;player=p;rig=r;turret=id;count=n;memcpy(pose,native,n*sizeof(Pose));}
};static SeatedTurretScaffold seatedTurretScaffold;
static RFGRVRNeutralPose neutralPose;static void* neutralPlayer=nullptr;static LARGE_INTEGER neutralCounter{};
SRWLOCK skinBuildLock=SRWLOCK_INIT;
ULONGLONG requestChecked=0,preflightChecked=0,publishChecked=0;bool requestCached=false;
static std::atomic<bool> cinematicArms{false};
static std::atomic<void*> controlledPlayer{nullptr};
struct VisualPart {void* object=nullptr;Pose pose{};unsigned handle=~0u,parent=~0u;};
struct ArmCommand {void* player=nullptr;void* character=nullptr;void* rootCharacter=nullptr;void* instance=nullptr;void* rigIdentity=nullptr;void* modelIdentity=nullptr;void* skinIdentity=nullptr;int handle=-1;unsigned count=0;int eye[2]{-1,-1};int physical[2]{},tag[2]{};int side[128]{};unsigned total=0,visualCount=0;VisualPart visual[32]{};Pose root{},pose[128]{},desired[2]{};V nativeEye{};bool nativeEyeValid=false;bool changed[128]{},rootRelative[128]{};ULONGLONG tick=0;V referenceEye{};bool referenceEyeValid=false,crouchVisual=false;bool alignBodyYaw=false;int yawRoot=-1;float targetBodyYaw=0;};
static constexpr unsigned PlayerMeshSlots=8,SupplementalSlots=PlayerMeshSlots-1;
SRWLOCK commandLock=SRWLOCK_INIT;ArmCommand command,supplemental[SupplementalSlots];std::atomic<void*> supplementalInstances[SupplementalSlots]{},supplementalRenderables[SupplementalSlots]{};std::atomic<void*> commandedRenderable{nullptr};std::atomic<void*> commandedInstance{nullptr};unsigned skinApplications=0;std::atomic<unsigned> guardedBoneWrites{0},renderSkinRefreshes{0};std::atomic<void*> watchedVisuals[32]{};
using BoundsUpdate=void(__cdecl*)(void*);BoundsUpdate updateBounds=nullptr;
struct Cost {std::atomic<long long> ticks{0},calls{0};};Cost playerCost,skinCost,attachmentCost;
struct Measure {Cost& cost;LARGE_INTEGER start{};Measure(Cost& c):cost(c){QueryPerformanceCounter(&start);}~Measure(){LARGE_INTEGER end{};QueryPerformanceCounter(&end);cost.ticks.fetch_add(end.QuadPart-start.QuadPart,std::memory_order_relaxed);cost.calls.fetch_add(1,std::memory_order_relaxed);}};
static double average(Cost& cost,long long& count){LARGE_INTEGER frequency{};QueryPerformanceFrequency(&frequency);count=cost.calls.exchange(0);auto ticks=cost.ticks.exchange(0);return count?1e6*double(ticks)/double(frequency.QuadPart)/double(count):0;}
struct BatchMemory {vrmemory::Scope scope;};
static bool memory(const void* ptr,size_t n,bool write=false){return vrmemory::check(ptr,n,write);}

static unsigned word(const void* ptr,size_t off){unsigned value=0;if(memory((const char*)ptr+off,4))memcpy(&value,(const char*)ptr+off,4);return value;}
static void* pointer(const void* p,size_t o){return (void*)(uintptr_t)word(p,o);}
static bool requested(){auto now=GetTickCount64();if(requestChecked&&now-requestChecked<500)return requestCached;requestChecked=now;return requestCached=RFGRVR_IsVRLaunch();}
static void log(const char* message){wchar_t p[MAX_PATH]{};GetModuleFileNameW(nullptr,p,MAX_PATH);auto* slash=wcsrchr(p,L'\\');if(!slash)return;wcscpy_s(slash+1,MAX_PATH-(slash+1-p),L"RFGRVR-Controller-Arms.log");FILE* f=nullptr;if(!_wfopen_s(&f,p,L"a")&&f){fprintf(f,"%llu %s\n",GetTickCount64(),message);fclose(f);}}
static bool getHands(Hands& out){AcquireSRWLockShared(&handLock);out=hands;ReleaseSRWLockShared(&handLock);return out.valid&&GetTickCount64()-out.tick<200;}
static V quaternion(float x,float y,float z,float w,V v){V q{x,y,z};return add(v,add(mul(cross(q,v),2*w),mul(cross(q,cross(q,v)),2)));}
static bool poseWorld(const RFGRPose& input,const RFGRPose& reference,V anchor,M frame,const float zero[4],Pose& out){
 if((input.validFlags&3)!=3||!input.active)return false;float x=input.orientation[0],y=input.orientation[1],z=input.orientation[2],w=input.orientation[3],n=x*x+y*y+z*z+w*w;if(!std::isfinite(n)||fabsf(n-1)>.05f)return false;
 auto unzero=[&](V v){return quaternion(-zero[0],-zero[1],-zero[2],zero[3],v);};
 V delta{input.position[0]-reference.position[0],input.position[1]-reference.position[1],input.position[2]-reference.position[2]};delta=mul(unzero(delta),RFGRVR_HeadCam_WorldScale());delta.z=-delta.z;out.p=add(anchor,world(frame,delta));
 auto axis=[&](V v){v=unzero(quaternion(x,y,z,w,v));v.z=-v.z;return world(frame,v);};out.b={axis({1,0,0}),axis({0,1,0}),axis({0,0,-1})};return finite(out.p)&&valid(out.b)&&length(delta)<3;
}
// Detect only an engine-attached propane item, not nearby/owned world props.
static void* nativePropObject(void* player){
 unsigned handle=word(player,0x6c);void* child=pointer(player,0x34);void* first=child;
 for(unsigned n=0;child&&n<64;++n){if(!memory(child,0xa8))break;void* next=pointer(child,0x38);void* def=pointer(child,0xa4);const char* name=(const char*)pointer(def,0);
  if(word(child,0x70)==handle&&pointer(child,0x48)&&memory(name,13)&&!strcmp(name,"propane_tank"))return child;if(next==child||next==first)break;child=next;}
 return nullptr;
}
static bool nativePropCarry(void* player){return nativePropObject(player)!=nullptr;}
static bool eligible(void* player){if(!RFGRVR_HeadCam_IsLocalPlayer(player)||!installed||!RFGRVR_HeadCam_Enabled()||!memory(player,0xc94))return false;unsigned state=word(player,0x2f4),rag=word(player,0x33c);Pose mount{};bool mounted=(state==3||state==8||state==9)&&RFGRVR_HeadCam_TurretRenderRoot(player,&mount);bool propCarry=state<=2&&nativePropCarry(player);if(state==8||(state>2&&!mounted)||rag||((word(player,0x338)&(1u<<13))&&!propCarry))return false;if(propCarry||RFGRVRWeaponInput::restoringWeapon())return true;
 int timer=(int)word(player,0xa4c);if(timer<0||expired&&expired((char*)player+0xa4c))return true;
 // Native firearm action timers animate fingers, not the tracked torso/head.
 // Retain ownership for the verified equipped item throughout firing/reload.
 if(state<=2){WeaponBinding firing{};AcquireSRWLockShared(&rigLock);firing=binding;ReleaseSRWLockShared(&rigLock);void* info=pointer(firing.weapon,0x148);unsigned kind=word(info,0x10);bool firearm=kind==0||kind==1||kind==9||kind==10||kind==11||kind==12||kind==13||kind==16;if(firearm&&memory(firing.weapon,0x210)&&word(firing.weapon,0x6c)==firing.handle&&word(firing.weapon,0x13c)==word(player,0x6c)&&word(pointer(player,0xc90),24)==firing.handle)return true;}
 if(state<=2&&RFGRVRWeaponPhysics::Reload::enabled){WeaponBinding held{};AcquireSRWLockShared(&rigLock);held=binding;ReleaseSRWLockShared(&rigLock);void* info=pointer(held.weapon,0x148);unsigned type=word(info,0x10);if(memory(info,0x14)&&type!=3&&type!=4&&type!=7&&memory(held.weapon,0x210)&&word(held.weapon,0x6c)==held.handle&&word(held.weapon,0x13c)==word(player,0x6c)&&word(pointer(player,0xc90),24)==held.handle&&(RFGRVRWeaponPhysics::Reload::controls(player,held.weapon)||(supportHold.active&&word(held.weapon,0x20c)==0)))return true;}
 return false;}
static bool owned(void* weapon){return !cinematicArms&&RFGRVR_HeadCam_IsLocalPlayer(controlledPlayer.load())&&controlling.load()&&memory(weapon,0x150)&&word(weapon,0x13c)==playerHandle.load();}
static bool visualTarget(void* object,Pose& pose){
 if(cinematicArms||!RFGRVR_HeadCam_IsLocalPlayer(controlledPlayer.load())||!controlling.load(std::memory_order_relaxed))return false;
 bool watched=false;for(auto& item:watchedVisuals){void* p=item.load(std::memory_order_relaxed);if(p==object){watched=true;break;}if(!p)break;}if(!watched)return false;
 AcquireSRWLockShared(&commandLock);bool found=false;
 if(GetTickCount64()-command.tick<200)for(unsigned i=0;i<command.visualCount;++i)if(command.visual[i].object==object&&word(object,0x6c)==command.visual[i].handle&&word(object,0x70)==command.visual[i].parent){pose=command.visual[i].pose;found=true;break;}
 ReleaseSRWLockShared(&commandLock);return found;
}
static bool __fastcall OnItemTag(void* object,void*,int tag,V* position,M* orientation,const V* overridePosition,const M* overrideOrientation){
 Pose rendered{};
 if(!overridePosition&&!overrideOrientation&&visualTarget(object,rendered))return originalItemTag(object,tag,position,orientation,&rendered.p,&rendered.b);
 return originalItemTag(object,tag,position,orientation,overridePosition,overrideOrientation);
}
static void setVisualPose(void* entity,const Pose& pose){
 if(!memory((char*)entity+8,0x3a,true))return;
 memcpy((char*)entity+8,&pose,sizeof(pose));unsigned short flags=0;memcpy(&flags,(char*)entity+0x40,2);flags=(flags&~0x10u)|1u;memcpy((char*)entity+0x40,&flags,2);
 if(updateBounds)updateBounds(entity);
}
static std::atomic<void*> depletedCharge{nullptr};static std::atomic<unsigned> depletedChargeHandle{~0u};
static bool emptyChargeVisual(void* item){return item&&item==depletedCharge.load()&&word(item,0x6c)==depletedChargeHandle.load()&&RFGRVR_HeadCam_IsLocalPlayer(controlledPlayer.load())&&word(item,0x70)==word(controlledPlayer.load(),0x6c);}
struct NativeVisualState {void* object=nullptr;unsigned handle=0,values[13]{};};
NativeVisualState nativeVisualStates[32]{};SRWLOCK visualStateLock=SRWLOCK_INIT;std::atomic<unsigned> nativeVisualRefreshes{0},controlledVisuals{0};
static void forgetNativeVisual(void* object){AcquireSRWLockExclusive(&visualStateLock);for(auto& entry:nativeVisualStates)if(entry.object==object)entry={};ReleaseSRWLockExclusive(&visualStateLock);}
static bool nativeVisibilityPending(void* object){
 // Mirror the native attached/dropped choice, rather than making both meshes
 // visible. Other equip callbacks can hide these after our last cached update.
 if((word(object,0xb8)&255u)!=1)return false;
 bool visible=!emptyChargeVisual(object)&&(word(object,0x54)&0x00800000u)!=0&&!RFGRVRWeaponPhysics::Reload::sourceHidden(object)&&!RFGRVRWeaponPhysics::Propane::hidden(object)&&!RFGRVRWeaponInput::carrying()&&!RFGRVRWeaponInput::restoringWeapon();
 void* attached=pointer(object,0xac);void* dropped=pointer(object,0xb4);
 void* skin=pointer(object,0xbc);void* skinned=(word(skin,0x34)&255u)==1?pointer(skin,0x30):nullptr;
 bool useDropped=word(object,0x70)==~0u&&dropped;
 auto differs=[&](void* renderable,bool expected){return renderable&&memory((char*)renderable+0x40,2)&&((word(renderable,0x40)&2u)==0)!=expected;};
 return differs(attached,visible&&!useDropped)||differs(dropped,visible&&useDropped)||differs(skinned,visible&&!useDropped);
}
static bool nativeVisualChanged(void* object){
 unsigned values[13]={word(object,0x54)&0x00800000u,word(object,0xc0),word(object,0xc4),word(object,0xc8)&255u,word(object,0x100)&0xe000u,word(object,0x12c)&16u,word(object,0x138)&0x00ffff00u,word(object,0xac),word(object,0xb4),word(object,0xbc),word(object,0x70),word(object,0xb8)&255u,unsigned(emptyChargeVisual(object))};
 unsigned handle=word(object,0x6c);AcquireSRWLockExclusive(&visualStateLock);NativeVisualState* slot=nullptr;
 for(auto& entry:nativeVisualStates){if(entry.object==object&&entry.handle==handle){slot=&entry;break;}if(!slot&&!entry.object)slot=&entry;}
 if(!slot)slot=&nativeVisualStates[((uintptr_t)object>>4)%32];
 bool changed=slot->object!=object||slot->handle!=handle||memcmp(slot->values,values,sizeof(values));slot->object=object;slot->handle=handle;memcpy(slot->values,values,sizeof(values));ReleaseSRWLockExclusive(&visualStateLock);return changed||nativeVisibilityPending(object);
}
#include "gutter_cloth.h"
struct DrawnWeaponPose {void* weapon=nullptr;unsigned handle=0;Pose root{};ULONGLONG tick=0;};static DrawnWeaponPose drawnWeapon;static SRWLOCK drawnWeaponLock=SRWLOCK_INIT;
static void __fastcall OnVisual(void* object,void*,void* renderer){
 vrmemory::Scope memoryScope;
 Pose desired{};if(!visualTarget(object,desired)){forgetNativeVisual(object);originalVisual(object,renderer);return;}
 // A controlled item has one pose writer. Preserve native visibility/material
 // changes, but do not publish the simulation pose again on every callback.
 ++controlledVisuals;if(nativeVisualChanged(object)){++nativeVisualRefreshes;originalVisual(object,renderer);}
 // Override render data only. The weapon and every child retain their native
 // simulation transforms, while all parts consume one published hand pose.
 float displayScale=1;{AcquireSRWLockShared(&commandLock);if(command.visualCount&&GetTickCount64()-command.tick<200){char name[96]{};void* info=pointer(command.visual[0].object,0x148);const char* text=(const char*)pointer(info,0);if(memory(text,96)){strncpy_s(name,text,_TRUNCATE);displayScale=vrscope::weaponScale(name);}}ReleaseSRWLockShared(&commandLock);}Pose display=desired;display.p=add(display.p,vrworldview::draw);if(object==watchedVisuals[0].load(std::memory_order_relaxed)){AcquireSRWLockExclusive(&drawnWeaponLock);drawnWeapon={object,word(object,0x6c),display,GetTickCount64()};ReleaseSRWLockExclusive(&drawnWeaponLock);}display.b={mul(display.b.r,displayScale),mul(display.b.u,displayScale),mul(display.b.f,displayScale)};
 void* entities[3]={pointer(object,0xac),pointer(object,0xb4),pointer(pointer(object,0xbc),0x30)};
 for(unsigned i=0;i<3;++i){if(!entities[i])continue;bool duplicate=false;for(unsigned j=0;j<i;++j)if(entities[j]==entities[i])duplicate=true;if(!duplicate){setVisualPose(entities[i],display);if((emptyChargeVisual(object)||RFGRVRWeaponPhysics::Reload::sourceHidden(object)||RFGRVRWeaponPhysics::Propane::hidden(object)||RFGRVRWeaponInput::carrying()||RFGRVRWeaponInput::restoringWeapon()||vrtraining::active.load())&&renderVisibility)renderVisibility(entities[i],false);}}
 GutterCloth::update(object,display);
}
static bool itemTagPose(void* object,int tag,const Pose& root,Pose& out){
 if(tag<0){out=root;return true;}void* table=pointer(object,0);if(!memory((char*)table+0x38,4))return false;
 using Query=bool(__thiscall*)(void*,int,V*,M*,const V*,const M*);auto query=(Query)pointer(table,0x38);out={};
 return query&&query(object,tag,&out.p,&out.b,&root.p,&root.b)&&valid(out.b)&&finite(out.p);
}
static bool weaponTrimName(void* weapon,char name[96]){void* info=pointer(weapon,0x148);const char* source=(const char*)pointer(info,0);if(!source)return false;for(unsigned i=0;i<96;++i){if(!memory(source+i,1))return false;char c=source[i];if(!c){name[i]=0;return i>0;}if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='.'))return false;name[i]=c;}return false;}
static bool attachedVisualPose(void* parent,void* child,const Pose& parentPose,Pose& out){
 void* attach=pointer(child,0x48);if(!memory(attach,64)||(word(attach,60)&1u))return false;
 Pose anchor{},childGrip{};const M identity{{1,0,0},{0,1,0},{0,0,1}};Pose zero{identity,{}};
 if(!itemTagPose(parent,(int)word(attach,4),parentPose,anchor)||!itemTagPose(child,(int)word(attach,8),zero,childGrip))return false;
 out.b=compose(anchor.b,relative(childGrip.b,identity));out.p=sub(anchor.p,world(out.b,childGrip.p));return finite(out.p)&&valid(out.b);
}
static void publishWeaponHud(const ArmCommand& next,const WeaponBinding& wb,const Hands& h,const M controllerBasis[2],const Pose* support=nullptr){
 static HANDLE mapping=nullptr;static RFGRWeaponHudPose* shared=nullptr;
 if(!shared){if(!mapping)mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRWeaponHudPose),RFGR_WEAPON_HUD_POSE);if(mapping)shared=(RFGRWeaponHudPose*)RFGRVR_MapViewOrClose(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRWeaponHudPose));}if(!shared)return;
 RFGRWeaponHudPose value{};value.tick=GetTickCount();value.weapon=wb.handle;
 if(h.sample&&valid(h.physical[1].b)&&armRest.body.spine>=0&&armRest.body.spine<int(next.count)){
  float scale=RFGRVR_HeadCam_WorldScale();V chest=add(next.root.p,world(next.root.b,add(armRest.body.head>=0&&armRest.body.head<int(next.count)?next.pose[armRest.body.head].p:next.pose[armRest.body.spine].p,V{0,-.38f*scale,.5f*scale})));V stage=add(h.physical[1].p,world(h.physical[1].b,mul(local(controllerBasis[1],sub(chest,h.grip[1].p)),1/scale)));V forward=world(h.physical[1].b,local(controllerBasis[1],next.root.b.f));
  if(finite(stage)&&finite(forward)){value.chestPosition[0]=stage.x;value.chestPosition[1]=stage.y;value.chestPosition[2]=-stage.z;value.chestYaw=atan2f(-forward.x,forward.z);value.chestValid=1;}
 }

 auto anchor=[&](int hand,const Pose& pose,bool right){return RFGRVR_HudAnchor(hand,Pose{controllerBasis[hand],h.grip[hand].p},pose,RFGRVR_HeadCam_WorldScale(),right);};
 if(wb.weapon&&next.visualCount){Pose receiver=next.visual[0].pose;receiver.p=add(receiver.p,world(receiver.b,wb.gripInRoot));value.ammo=anchor(wb.hand,receiver,false);
 // The inventory charge_placer is the left-held detonator. The throwable
 // charge is a separate player sibling; it must never become the HUD host.
 void* info=pointer(wb.weapon,0x148);const char* name=(const char*)pointer(info,0);
 bool charges=memory(name,14)&&(!strcmp(name,"charge_placer")||!strcmp(name,"mine_placer"));
 if(support){V point=add(next.visual[0].pose.p,world(next.visual[0].pose.b,support->p));V localPoint=mul(local(controllerBasis[wb.hand],sub(point,h.grip[wb.hand].p)),1/RFGRVR_HeadCam_WorldScale());value.supportHand=wb.hand;value.supportPoint[0]=localPoint.x;value.supportPoint[1]=localPoint.y;value.supportPoint[2]=-localPoint.z;value.supportHeld=(supportHold.active?1u:0u)|(supportEditing.load(std::memory_order_relaxed)?2u:0u);
 // Freeze the point in STAGE at the controller sample that produced the gun.
 // A late controller pose would move the hint away from a delayed scene image.
 if(h.sample&&valid(h.physical[wb.hand].b)){V stagePoint=add(h.physical[wb.hand].p,world(h.physical[wb.hand].b,localPoint));value.supportPoint[0]=stagePoint.x;value.supportPoint[1]=stagePoint.y;value.supportPoint[2]=-stagePoint.z;value.supportHeld|=4u;}}
 if(charges){value.ammo=RFGRVR_PalmHudAnchor(wb.hand);value.charges=RFGRVR_PalmHudAnchor(wb.hand,true);}
 }
 RFGRPropMarkers propMarkers{};propMarkers.tick=GetTickCount();
 RFGRVRWeaponPhysics::Propane::Visual propHud{};if(RFGRVRWeaponPhysics::Propane::readVisual(propHud)){if(propHud.heldMask||propHud.editing){value.ammo={};value.charges={};value.supportHeld=1;}if(propHud.editing){propMarkers.count=propHud.markerCount;propMarkers.selected=propHud.selected;for(unsigned i=0;i<propMarkers.count;++i){V delta=mul(local(controllerBasis[0],sub(propHud.markers[i],h.grip[0].p)),1/RFGRVR_HeadCam_WorldScale());V point=add(h.physical[0].p,world(h.physical[0].b,delta));propMarkers.point[i][0]=point.x;propMarkers.point[i][1]=point.y;propMarkers.point[i][2]=-point.z;}}if(!propHud.editing&&propHud.markerValid&&propHud.nearHand>=0&&propHud.nearHand<2){unsigned hand=unsigned(propHud.nearHand);V delta=mul(local(controllerBasis[hand],sub(propHud.marker,h.grip[hand].p)),1/RFGRVR_HeadCam_WorldScale());V stagePoint=add(h.physical[hand].p,world(h.physical[hand].b,delta));value.supportHand=1-hand;value.supportPoint[0]=stagePoint.x;value.supportPoint[1]=stagePoint.y;value.supportPoint[2]=-stagePoint.z;value.supportHeld=12;}}
 if(vrtraining::active){value.ammo={};value.charges={};value.supportHeld=0;value.supportHand=-1;}RFGRVR_PublishPropMarkers(propMarkers);InterlockedIncrement(&shared->sequence);MemoryBarrier();shared->magic=value.magic;shared->tick=value.tick;shared->weapon=value.weapon;shared->ammo=value.ammo;shared->charges=value.charges;shared->supportHand=value.supportHand;memcpy(shared->supportPoint,value.supportPoint,12);shared->supportHeld=value.supportHeld;memcpy(shared->chestPosition,value.chestPosition,12);shared->chestYaw=value.chestYaw;shared->chestValid=value.chestValid;MemoryBarrier();InterlockedIncrement(&shared->sequence);
}
static float scopedWeaponScale(void*);
static Pose pistolLaserPose(const Pose& item,const WeaponBinding& wb,float){
 static SRWLOCK mountLock=SRWLOCK_INIT;static vrlaser::Mount mount;
 const M identity{{1,0,0},{0,1,0},{0,0,1}};M basis=relative(wb.rootInMuzzle,identity);
 Pose candidate{basis,add(wb.gripInRoot,world(basis,wb.muzzleFromGrip))},localMount=candidate;
 AcquireSRWLockExclusive(&mountLock);if(wb.gripReady)mount.resolve((uintptr_t)wb.weapon,wb.handle,candidate,localMount);ReleaseSRWLockExclusive(&mountLock);
 float itemScale=scopedWeaponScale(wb.weapon);Pose localEmitter=vrlaser::emitter(localMount,1,vrlaser::settings());
 return {compose(item.b,localEmitter.b),add(item.p,world(item.b,mul(localEmitter.p,itemScale)))};
}
static void publishWeaponPhysics(const ArmCommand& next,const WeaponBinding& wb,const Hands& h,const M controllerBasis[2],const Pose& unblockedWeapon,V chargeBlocking){
 RFGRVRWeaponPhysics::Target t{};if(auto* input=RFGRVRWeaponInput::source.load())if(input->version==RFGR_PROTOCOL)t.attackTrigger=input->gamepad.rightTrigger/255.f;for(int side=0;side<2;++side){t.hand[side]=h.grip[side];t.aim[side]=h.aim[side];t.squeeze[side]=h.gripValue[side];}t.nativePropCarry=nativePropCarry(next.player);t.focusEligible=!primaryPlacement.active&&!chargePlacement.active&&supportCapture.load()==~0u;t.player=next.player;t.playerHandle=word(next.player,0x6c);t.weapon=wb.weapon;t.handle=wb.handle;t.tick=GetTickCount();t.occupiedMask=(wb.weapon?(1u<<wb.hand):0u)|(supportHold.active?(1u<<(1-wb.hand)):0u);t.motion.body=next.root;t.motion.scale=RFGRVR_HeadCam_WorldScale();t.motion.tracked=h.valid&&!vrtraining::active.load();t.motion.sample=h.sample;LARGE_INTEGER propClock{},propFrequency{};QueryPerformanceCounter(&propClock);QueryPerformanceFrequency(&propFrequency);t.motion.seconds=double(propClock.QuadPart)/propFrequency.QuadPart;
 if(wb.weapon&&next.visualCount){void* info=pointer(wb.weapon,0x148);t.weaponClass=word(info,0x10);if(t.weaponClass==3)t.occupiedMask=3;RFGRVRWeaponPhysics::Reload::Visual propReload{};if(RFGRVRWeaponPhysics::Reload::readVisual(wb.handle,propReload)&&propReload.grip)t.occupiedMask=3;t.primary=(int)word(info,0x218);t.secondary=(int)word(info,0x21c);void* boundsObject=wb.weapon;Pose pose=unblockedWeapon;int physicalHand=wb.hand;
 if(t.weaponClass==3)for(unsigned i=1;i<next.visualCount;++i){void* item=next.visual[i].object;void* attach=pointer(item,0x48);int tag=(int)word(attach,4);if(word(item,0x70)==t.playerHandle&&tag>=0&&tag<(int)next.total&&next.side[tag]==1){pose=next.visual[i].pose;pose.p=sub(pose.p,chargeBlocking);boundsObject=item;physicalHand=1;break;}}
 LARGE_INTEGER clock{},frequency{};QueryPerformanceCounter(&clock);QueryPerformanceFrequency(&frequency);t.motion={(uintptr_t)t.weapon,t.handle,h.sample,double(clock.QuadPart)/frequency.QuadPart,pose,next.root,RFGRVR_HeadCam_WorldScale(),h.valid,supportHold.active};
 M physicalFrame=h.physical[physicalHand].b;M relativeWeapon=relative(controllerBasis[physicalHand],pose.b);V relativePosition=mul(local(controllerBasis[physicalHand],sub(pose.p,h.grip[physicalHand].p)),1/t.motion.scale);
 t.motion.physical={compose(physicalFrame,relativeWeapon),add(h.physical[physicalHand].p,world(physicalFrame,relativePosition))};t.motion.physicalValid=h.valid&&h.sample!=0;t.grip=h.grip[physicalHand];t.physicalHand=physicalHand;t.motion.grip={controllerBasis[physicalHand],h.grip[physicalHand].p};t.motion.physicalGrip=h.physical[physicalHand];t.motion.gripValid=t.motion.physicalValid;
 // Use the authored held-mesh bounds, including submesh offsets. Cache only
 // immutable geometry; the controller pose is republished every frame.
 static void* cachedWeapon=nullptr;static unsigned cachedHandle=0;static V cachedA{},cachedB{};static float cachedRadius=.05f;
 if(cachedWeapon!=boundsObject||cachedHandle!=word(boundsObject,0x6c)){V lo{-.04f,-.04f,-.12f},hi{.04f,.04f,.5f};bool found=false;void* mesh=pointer(boundsObject,0xa8);void* renderMesh=pointer(mesh,8);unsigned count=word(renderMesh,0x34);void* subs=pointer(renderMesh,0x38);
 if(count&&count<=64&&memory(subs,count*0x2c))for(unsigned i=0;i<count;++i){auto* submesh=(char*)subs+i*0x2c;V offset{},a{},b{};memcpy(&offset,submesh+4,12);memcpy(&a,submesh+0x10,12);memcpy(&b,submesh+0x1c,12);a=add(a,offset);b=add(b,offset);if(!finite(a)||!finite(b)||length(sub(b,a))>4||a.x>b.x||a.y>b.y||a.z>b.z)continue;if(!found){lo=a;hi=b;found=true;}else{lo={(std::min)(lo.x,a.x),(std::min)(lo.y,a.y),(std::min)(lo.z,a.z)};hi={(std::max)(hi.x,b.x),(std::max)(hi.y,b.y),(std::max)(hi.z,b.z)};}}
 // Gutter is a character mesh; its blade is on the authored Y shaft, not the static-mesh Z fallback.
 if(!found&&t.weaponClass==8){lo={-.11f,-.34f,-.21f};hi={.09f,1.901f,.27f};}
 V center=mul(add(lo,hi),.5f),half=mul(sub(hi,lo),.5f);int axis=half.x>half.y?(half.x>half.z?0:2):(half.y>half.z?1:2);cachedA=cachedB=center;((float*)&cachedA)[axis]=((float*)&lo)[axis];((float*)&cachedB)[axis]=((float*)&hi)[axis];float radius=0;for(int i=0;i<3;++i)if(i!=axis)radius=(std::max)(radius,((float*)&half)[i]);cachedRadius=(std::max)(.025f,(std::min)(.12f,radius));cachedWeapon=boundsObject;cachedHandle=word(boundsObject,0x6c);
 }
 // Resolve the thermobaric prop from its authored skeletal mount even after firing deleted the native child.
 const char* weaponName=(const char*)pointer(pointer(wb.weapon,0x148),0);
 if(memory(weaponName,11)&&!strcmp(weaponName,"edf_pistol")){
  t.laserMuzzle=pistolLaserPose(next.visual[0].pose,wb,t.motion.scale);t.laserValid=wb.gripReady&&valid(t.laserMuzzle.b)&&finite(t.laserMuzzle.p);
 }
 if(memory(weaponName,19)&&!strcmp(weaponName,"thermobaric_rockets")){
  void* character=pointer(wb.weapon,0xbc);int handle=(int)word(character,0);void* inst=handle>=0?base+0x35acbd0+(handle%356)*0x410:nullptr;
  void* rig=pointer(inst,0x18);unsigned count=word(rig,0x24);auto* bones=(unsigned char*)pointer(rig,0x38);
  if(count&&count<=128&&memory(bones,count*36))for(unsigned i=0;i<count;++i){auto* entry=bones+i*36;const char* name=(const char*)(entry+(int)word(entry,0));
   if(memory(name,29)&&!strcmp(name,"therm_rocket_projectile_bone")){Pose zero{M{{1,0,0},{0,1,0},{0,0,1}},V{}};t.rocketMountValid=itemTagPose(wb.weapon,int(i),zero,t.rocketMount)&&length(t.rocketMount.p)<2;break;}}
 }
 float itemScale=scopedWeaponScale(boundsObject);t.extentA=mul(cachedA,itemScale);t.extentB=mul(cachedB,itemScale);t.radius=cachedRadius*itemScale;if(memory(weaponName,7)&&!strcmp(weaponName,"gutter")){t.pointCount=24;t.radius=vrgutter::radius*itemScale;for(unsigned point=0;point<24;++point)t.points[point]=mul(vrgutter::points[point],itemScale);}
 for(unsigned i=1;i<next.visualCount;++i){void* item=next.visual[i].object;if(word(item,0x70)==wb.handle&&word(item,0xe4)==1){t.magazine=item;t.magazineHandle=word(item,0x6c);t.magazinePose=next.visual[i].pose;V lo{-.025f,-.06f,-.02f},hi{.025f,.06f,.02f};void* mesh=pointer(item,0xa8);void* data=pointer(mesh,8);void* subs=pointer(data,0x38);unsigned n=word(data,0x34);bool have=false;if(n&&n<=64&&memory(subs,n*0x2c))for(unsigned part=0;part<n;++part){auto* submesh=(char*)subs+part*0x2c;V a{},b{},offset{};memcpy(&offset,submesh+4,12);memcpy(&a,submesh+0x10,12);memcpy(&b,submesh+0x1c,12);a=add(a,offset);b=add(b,offset);if(!finite(a)||!finite(b)||length(sub(b,a))>1)continue;if(!have){lo=a;hi=b;have=true;}else{lo={(std::min)(lo.x,a.x),(std::min)(lo.y,a.y),(std::min)(lo.z,a.z)};hi={(std::max)(hi.x,b.x),(std::max)(hi.y,b.y),(std::max)(hi.z,b.z)};}}t.magazineCenter=mul(add(lo,hi),.5f);t.magazineExtent=sub(hi,lo);t.magazineGrip=vrreload::gripForBounds(lo,hi);break;}}

 }
 RFGRVRWeaponPhysics::publish(t);
}
// A seated magazine has a fixed receiver-local pose. Native animated tags
// include reload/pump/recoil motion; those must not move a VR magazine.
struct MagazineMount{void* parent=nullptr;void* child=nullptr;unsigned parentHandle=0,childHandle=0;Pose local{};};
MagazineMount magazineMounts[64]{};unsigned magazineMountNext=0;
static Pose fixedMagazinePose(void* parent,void* child,const Pose& root,const Pose& animated,bool authored=true){
 if(word(child,0xe4)!=1)return animated;
 unsigned ph=word(parent,0x6c),ch=word(child,0x6c);
 Pose candidate=vrgrip::relativePose(root,animated);
 // On save load a clip tag can temporarily equal the weapon root.
 // Never freeze that uninitialized zero mount, or a fallback simulation pose.
 auto pending=[&](const Pose& pose){return !finite(pose.p)||!valid(pose.b)||length(pose.p)<.005f;};
 for(auto& m:magazineMounts)if(m.parent==parent&&m.child==child&&m.parentHandle==ph&&m.childHandle==ch){
  if(pending(m.local)){m={};break;}
  return vrgrip::worldPose(root,m.local);
 }
 if(!authored||pending(candidate))return animated;
 auto& m=magazineMounts[magazineMountNext++%64];m={parent,child,ph,ch,candidate};return animated;
}

static void queueVisuals(ArmCommand& next,void* weapon,const Pose& desired){
 if(!weapon||!valid(desired.b)||!finite(desired.p))return;
 Pose source{};memcpy(&source.p,(char*)weapon+4,12);memcpy(&source.b,(char*)weapon+0x10,36);if(!valid(source.b)||!finite(source.p))return;
 next.visual[next.visualCount++]={weapon,desired,word(weapon,0x6c),word(weapon,0x70)};
 // Child lists are circular. Bound traversal, reject duplicates, and validate
 // each native parent link before including a magazine or other component.
 for(unsigned index=0;index<next.visualCount&&next.visualCount<32;++index){void* parent=next.visual[index].object;void* child=pointer(parent,0x34);
  for(unsigned step=0;child&&step<32&&next.visualCount<32;++step){bool seen=false;for(unsigned j=0;j<next.visualCount;++j)if(next.visual[j].object==child)seen=true;if(seen)break;
   if(!memory(child,0xc0)||word(child,0x70)!=word(parent,0x6c))break;
   unsigned char type=0;memcpy(&type,(char*)child+0x7e,1);if(type!=1){child=pointer(child,0x38);continue;}
   Pose native{};memcpy(&native.p,(char*)child+4,12);memcpy(&native.b,(char*)child+0x10,36);
   if(!valid(native.b)||!finite(native.p))break;
   Pose relativePose{relative(source.b,native.b),local(source.b,sub(native.p,source.p))};
   Pose childPose{compose(desired.b,relativePose.b),add(desired.p,world(desired.b,relativePose.p))};
   const bool authored=attachedVisualPose(parent,child,next.visual[index].pose,childPose);
   childPose=fixedMagazinePose(parent,child,next.visual[index].pose,childPose,authored);
   next.visual[next.visualCount++]={child,childPose,word(child,0x6c),word(child,0x70)};
   child=pointer(child,0x38);
  }
 }
}
static bool bindNativeGrip(WeaponBinding& wb,void* weapon,void* rig,const Pose* model,unsigned count,int wrist){
 void* attach=pointer(weapon,0x48);if(!memory(attach,12)||wrist<0||wrist>=(int)count)return false;
 int parentTag=(int)word(attach,4),childTag=(int)word(attach,8);if(parentTag<0||childTag<0)return false;
 Pose parent{};if(parentTag<(int)count)parent=model[parentTag];else{
  unsigned tag=unsigned(parentTag)-count;void* tags=pointer(rig,0x3c);if(tag>=word(rig,0x30)||!memory((char*)tags+tag*60,60))return false;
  unsigned physical=word((char*)tags+tag*60,52);Pose offset{};memcpy(&offset,(char*)tags+tag*60+4,48);if(physical>=count||!valid(offset.b)||!finite(offset.p))return false;
  parent={compose(model[physical].b,offset.b),add(model[physical].p,world(model[physical].b,offset.p))};
 }
 void* table=pointer(weapon,0);if(!memory((char*)table+0x38,4))return false;
 using TagPose=bool(__thiscall*)(void*,int,V*,M*,const V*,const M*);auto tag=(TagPose)pointer(table,0x38);if(!tag)return false;
 Pose grip{},gun{};memcpy(&gun.p,(char*)weapon+4,12);memcpy(&gun.b,(char*)weapon+0x10,36);if(!tag(weapon,childTag,&grip.p,&grip.b,&gun.p,&gun.b))return false;
 if(!valid(gun.b)||!finite(gun.p)||!valid(grip.b)||!finite(grip.p)||length(sub(grip.p,gun.p))>2)return false;
 Pose gripLocal{relative(gun.b,grip.b),local(gun.b,sub(grip.p,gun.p))};Pose tagOffset{relative(model[wrist].b,parent.b),local(model[wrist].b,sub(parent.p,model[wrist].p))};
 const M identity{{1,0,0},{0,1,0},{0,0,1}};
 Pose muzzle=gun;int muzzleTag=(int)word(weapon,0x254);Pose measured{};
 if(muzzleTag>=0&&muzzleTag<4096&&tag(weapon,muzzleTag,&measured.p,&measured.b,&gun.p,&gun.b)&&valid(measured.b)&&finite(measured.p))muzzle=measured;
 wb.rootInMuzzle=relative(muzzle.b,gun.b);
 wb.wristInMuzzle=compose(compose(wb.rootInMuzzle,gripLocal.b),relative(tagOffset.b,identity));
 // The XR grip is the palm centre, not the wrist joint. The child hold tag
 // belongs at that point; subtracting the wrist-to-prop offset again shifted
 // this rifle sideways by 9.5 cm when aiming independently of the wrist.
 wb.gripInRoot=gripLocal.p;
 wb.primaryWristLocal.b=compose(gripLocal.b,relative(tagOffset.b,identity));
 wb.primaryWristLocal.p=sub(gripLocal.p,world(wb.primaryWristLocal.b,tagOffset.p));
 wb.muzzleFromGrip=local(muzzle.b,sub(muzzle.p,add(gun.p,world(gun.b,wb.gripInRoot))));
 return true;
}
static float scopedWeaponScale(void* weapon){void* info=pointer(weapon,0x148);const char* name=(const char*)pointer(info,0);return memory(name,32)?vrscope::weaponScale(name):1.f;}
static Pose firingPose(void* weapon,const Hands& h,const WeaponBinding& b,bool shot=false){
 Pose item{};M muzzleBasis=h.aim[1].b;V wrist=h.grip[b.hand].p;
  if(visualTarget(weapon,item)){if(shot){char name[96]{};if(weaponTrimName(weapon,name)&&vrrecoil::profile(word(pointer(weapon,0x148),0x10),name).perRound){AcquireSRWLockExclusive(&recoilLock);item=weaponBallistics.shot((uintptr_t)weapon,b.handle,(int)word(weapon,0x20c),item,GetTickCount64());ReleaseSRWLockExclusive(&recoilLock);}}muzzleBasis=compose(item.b,relative(b.rootInMuzzle,M{{1,0,0},{0,1,0},{0,0,1}}));wrist=add(item.p,world(item.b,mul(b.gripInRoot,scopedWeaponScale(weapon))));}
 return {muzzleBasis,add(wrist,world(muzzleBasis,mul(b.muzzleFromGrip,scopedWeaponScale(weapon))))};
}
static void __fastcall OnMuzzle(void* weapon,void*,V* position,M* orientation){originalMuzzle(weapon,position,orientation);if(!owned(weapon))return;Hands h;if(!getHands(h))return;
 AcquireSRWLockShared(&rigLock);auto b=binding;ReleaseSRWLockShared(&rigLock);if(b.weapon!=weapon)return;Pose firing=firingPose(weapon,h,b);if(position)*position=firing.p;if(orientation)*orientation=firing.b;}
static void __fastcall OnFire(void* weapon,void*,V* origin,V* direction,V* muzzle){originalFire(weapon,origin,direction,muzzle);if(!owned(weapon)||!origin||!direction||!muzzle)return;Hands h;if(!getHands(h))return;
 AcquireSRWLockShared(&rigLock);auto b=binding;ReleaseSRWLockShared(&rigLock);if(b.weapon!=weapon)return;recoilShotHandle=b.handle;recoilShotTick=GetTickCount64();Pose firing=firingPose(weapon,h,b,true);*muzzle=firing.p;*origin=*muzzle;*direction=firing.b.f;auto optic=vrscope::snapshot();if(optic.kind>=0&&optic.alpha>.1f){float alignment=(std::clamp)(dot(unit(firing.b.f),unit(optic.camera.b.f)),-1.f,1.f);char evidence[240];sprintf_s(evidence,"Scope shot kind=%d angularErrorDeg=%.5f cameraToMuzzle=%.4f origin=%.3f,%.3f,%.3f direction=%.5f,%.5f,%.5f",optic.kind,acosf(alignment)*57.2957795f,length(sub(optic.camera.p,firing.p)),firing.p.x,firing.p.y,firing.p.z,firing.b.f.x,firing.b.f.y,firing.b.f.z);log(evidence);}if(++shots==1||shots%30==0){char line[180];sprintf_s(line,"Right-hand firing: shots=%lu origin=%.3f,%.3f,%.3f direction=%.3f,%.3f,%.3f",shots,origin->x,origin->y,origin->z,direction->x,direction->y,direction->z);log(line);}}
static bool boneNamed(unsigned char* bones,int bone,const char* name){
 auto* entry=bones+bone*36;int offset=(int)word(entry,0);auto* text=entry+offset;size_t n=strlen(name)+1;return memory(text,n)&&!memcmp(text,name,n);
}
// OpenXR grip forward runs little-finger to index; +X is the palm normal.
// Use the grip frame for anatomical hands and the separate aim frame for guns.
// Derive the mapping in wrist-local coordinates, never from controller/world
// orientation or the currently equipped item's muzzle.
static bool anatomicalGrip(unsigned char* bones,const Pose* model,unsigned count,int side,int wrist,M& alignment,V& center){
 int index=-1,little=-1,prop=-1;
 for(unsigned i=0;i<count;++i){if(boneNamed(bones,i,side?"r-finger1":"l-finger1"))index=i;if(boneNamed(bones,i,side?"r-finger4":"l-finger4"))little=i;if(boneNamed(bones,i,side?"r-handprop":"l-handprop"))prop=i;}
 if(index<0||little<0||!valid(model[wrist].b))return false;
 V a=local(model[wrist].b,sub(model[index].p,model[wrist].p)),b=local(model[wrist].b,sub(model[little].p,model[wrist].p));
 V across=sub(a,b),longitudinal=mul(add(a,b),.5f);if(length(across)<.015f||length(longitudinal)<.025f)return false;
 V f=unit(across),u=unit(mul(sub(longitudinal,mul(f,dot(longitudinal,f))),-1)),r=unit(cross(u,f));u=unit(cross(f,r));
 M gripInWrist{r,u,f};if(!valid(gripInWrist))return false;
 alignment=relative(gripInWrist,M{{1,0,0},{0,1,0},{0,0,1}});
 center=prop>=0?local(model[wrist].b,sub(model[prop].p,model[wrist].p)):mul(longitudinal,.5f);
 return finite(center)&&length(center)<.2f;
}
static bool armChain(void* player,void* rig,unsigned char* bones,const int* parents,int count,int side,int& wrist,int& elbow,int& upper){
 wrist=(int)word(player,side?0xa70:0xa6c);
 if(wrist>=count){int tag=wrist-count;unsigned tags=word(rig,0x30);auto* data=(unsigned char*)pointer(rig,0x3c);if(tag<0||tag>=(int)tags||!memory(data+tag*60,60))return false;wrist=(int)word(data+tag*60,52);
  const char* hand=side?"r-hand":"l-hand";int steps=0;while(wrist>=0&&wrist<count&&!boneNamed(bones,wrist,hand)&&steps++<count)wrist=parents[wrist];if(wrist<0||wrist>=count||!boneNamed(bones,wrist,hand))return false;
  upper=(int)word(player,side?0xa68:0xa64);elbow=parents[wrist];const char* fore=side?"r-foretwist":"l-foretwist";steps=0;while(elbow>=0&&elbow<count&&!boneNamed(bones,elbow,fore)&&steps++<count)elbow=parents[elbow];
  if(elbow<0||elbow>=count||upper<0||upper>=count)return false;int ancestor=elbow;steps=0;while(ancestor>=0&&ancestor<count&&ancestor!=upper&&steps++<count)ancestor=parents[ancestor];return ancestor==upper;
 }
 if(wrist<0||wrist>=count)return false;elbow=parents[wrist];if(elbow<0||elbow>=count)return false;upper=parents[elbow];return upper>=0&&upper<count;
}
struct RigRemap {void* source=nullptr;void* target=nullptr;unsigned count=0;int sourceBone[128]{};void* instance=nullptr;int handle=-1;ULONGLONG tick=0;Pose clothLocal[128]{};bool clothReady[128]{};};
static bool mapSupplemental(const ArmCommand& source,void* instance,void* character,ArmCommand& out,RigRemap& remap){
 void* rig=pointer(instance,0x18);unsigned count=word(rig,0x24);auto* bones=(unsigned char*)pointer(rig,0x38);auto* model=(Pose*)pointer(instance,4);
 void* sourceRig=pointer(source.instance,0x18);auto* sourceBones=(unsigned char*)pointer(sourceRig,0x38);
 if(count<1||count>128||!memory(bones,count*36)||!memory(model,count*48)||!memory(sourceBones,source.count*36))return false;
 if(remap.source!=sourceRig||remap.target!=rig||remap.count!=count||remap.instance!=instance||remap.handle!=int(word(character,0))){
  remap={};remap.source=sourceRig;remap.target=rig;remap.count=count;remap.instance=instance;remap.handle=int(word(character,0));
  for(unsigned i=0;i<count;++i){remap.sourceBone[i]=-1;auto* name=bones+i*36+(int)word(bones+i*36,0);if(!memory(name,64)||!memchr(name,0,64))continue;
   for(unsigned j=0;j<source.count;++j)if(boneNamed(sourceBones,j,(const char*)name)){remap.sourceBone[i]=(int)j;break;}}
 }
 out=source;out.instance=instance;out.character=character;out.handle=int(word(character,0));out.count=count;out.total=count;out.visualCount=0;memcpy(out.pose,model,count*48);memset(out.changed,0,sizeof(out.changed));memset(out.rootRelative,0,sizeof(out.rootRelative));for(int& side:out.side)side=-1;
 float clothDt=remap.tick&&source.tick>=remap.tick?(std::min)(.05f,float(source.tick-remap.tick)/1000.f):0;
 unsigned controlled=0;for(unsigned i=0;i<count;++i){int bone=remap.sourceBone[i];if(bone>=0&&source.changed[bone]){out.pose[i]=source.pose[bone];out.changed[i]=true;out.rootRelative[i]=source.rootRelative[bone];++controlled;}}
 // Scarf/coat simulation bones have no names in the main body rig. Carry
 // their native local deformation with the nearest corrected named ancestor.
 auto* mapping=(signed char*)pointer(instance,0x124);
 if(memory(mapping,count+12))for(unsigned i=0;i<count;++i)if(!out.changed[i]){
  int physical=mapping[i+12];if(physical<0||physical>=(int)count)continue;
  int ancestor=(int)word(bones+i*36,28);
  for(unsigned steps=0;steps<count&&ancestor>=0&&ancestor<(int)count;++steps){
   int sourceBone=remap.sourceBone[ancestor];
   if(sourceBone>=0&&source.changed[sourceBone]){
    const Pose& from=model[ancestor];const Pose& to=out.pose[ancestor];
    if(valid(from.b)&&valid(to.b)&&valid(model[i].b)&&finite(model[i].p)){
     Pose localPose{relative(from.b,model[i].b),local(from.b,sub(model[i].p,from.p))};
     if(remap.clothReady[i]){auto& previous=remap.clothLocal[i];float amount=1-expf(-clothDt*14.f);if(length(sub(localPose.p,previous.p))<.75f){localPose.p=add(previous.p,mul(sub(localPose.p,previous.p),amount));V r=unit(add(previous.b.r,mul(sub(localPose.b.r,previous.b.r),amount))),u=unit(add(previous.b.u,mul(sub(localPose.b.u,previous.b.u),amount)));V f=unit(cross(r,u));u=unit(cross(f,r));M filtered{r,u,f};if(valid(filtered))localPose.b=filtered;}}
     remap.clothLocal[i]=localPose;remap.clothReady[i]=true;out.pose[i]={compose(to.b,localPose.b),add(to.p,world(to.b,localPose.p))};
     out.changed[i]=true;out.rootRelative[i]=source.rootRelative[sourceBone];++controlled;
    }break;
   }ancestor=(int)word(bones+ancestor*36,28);
  }
 }
 out.rigIdentity=rig;out.modelIdentity=model;out.skinIdentity=pointer(instance,0);remap.tick=source.tick;return controlled!=0;
}
// CharacterInstance records live in a GLOBAL circular list. Adjacent records
// may be NPCs. Only the full native animation-parent handle proves attachment.
static bool playerPart(void* player,void* character,void* instance){
 if(!RFGRVR_HeadCam_IsLocalPlayer(player)||!memory(character,0x38)||!memory(instance,0x20))return false;
 void* root=pointer(player,0x32c);if(!root)return false;
 if(character==root)return true;
 return word(instance,0x1c)==word(root,0);
}
struct PlayerParts {void* part[PlayerMeshSlots]{};unsigned count=0;};
static PlayerParts playerParts(void* player){
 static void* previousPlayer=nullptr;static void* previousRoot=nullptr;static unsigned previousHandle=~0u;static ULONGLONG tick=0;static PlayerParts cached;
 void* root=pointer(player,0x32c);unsigned handle=word(root,0);auto now=GetTickCount64();
 if(player==previousPlayer&&root==previousRoot&&handle==previousHandle&&now-tick<500)return cached;
 cached={};previousPlayer=player;previousRoot=root;previousHandle=handle;tick=now;
 if(!RFGRVR_HeadCam_IsLocalPlayer(player)||!memory(root,0x38))return cached;
 void* part=root;for(unsigned visited=0;visited<356&&part&&memory(part,0x38);++visited){int id=int(word(part,0));if(id>=0){void* instance=base+0x35acbd0+(id%356)*0x410;if(playerPart(player,part,instance)&&cached.count<PlayerMeshSlots)cached.part[cached.count++]=part;}part=pointer(part,0x1c);if(part==root)break;}
 return cached;
}
static bool controlledInstance(void* instance){if(!instance)return false;if(commandedInstance.load()==instance)return true;for(auto& part:supplementalInstances)if(part.load()==instance)return true;return false;}
static bool getCommand(void* instance,ArmCommand& out){if(cinematicArms.load()||!controlledInstance(instance))return false;AcquireSRWLockShared(&commandLock);bool found=false;if(command.instance==instance){out=command;found=true;}else for(auto& c:supplemental)if(c.instance==instance){out=c;found=true;break;}ReleaseSRWLockShared(&commandLock);
 if(!found||word(out.player,0x2f4)==8||out.rootCharacter!=pointer(out.player,0x32c)||pointer(instance,0x18)!=out.rigIdentity||pointer(instance,4)!=out.modelIdentity||pointer(instance,0)!=out.skinIdentity||!RFGRVR_HeadCam_IsLocalPlayer(out.player)||!memory(out.character,0x38)||int(word(out.character,0))!=out.handle||!playerPart(out.player,out.character,instance))return false;
 return controlling.load()&&GetTickCount64()-out.tick<200;
}
static bool renderRoot(void* player,void* character,Pose& root){
 Pose mount{};bool mounted=RFGRVR_HeadCam_TurretRenderRoot(player,&mount);
 if(!memory((char*)player+4,48))return false;
 memcpy(&root.p,(char*)player+4,12);memcpy(&root.b,(char*)player+0x10,36);
 if(!valid(root.b)||!finite(root.p))return false;
 // CharacterInstance::rdd.RenderableInstance owns the interpolated world
 // matrix consumed by skin rendering (basis +8, position +0x2c).
 void* renderable=pointer(character,0x30);Pose rendered{};
 if(memory((char*)renderable+8,48)){memcpy(&rendered,(char*)renderable+8,48);
  if(valid(rendered.b)&&finite(rendered.p)&&(mounted||length(sub(rendered.p,root.p))<2))root=rendered;}
 return true;
}
static Pose rebasePose(const Pose& pose,const Pose& from,const Pose& to){
 return {relative(to.b,compose(from.b,pose.b)),local(to.b,sub(add(from.p,world(from.b,pose.p)),to.p))};
}
static Pose currentRoot(const ArmCommand& c){Pose root=c.root;renderRoot(c.player,c.character,root);return root;}
static Pose commandBone(const ArmCommand& c,unsigned bone,const Pose& root){
 if(!c.rootRelative[bone])return rebasePose(c.pose[bone],c.root,root);
 if(c.rootCharacter&&c.character!=c.rootCharacter){Pose bodyRoot=c.root;if(renderRoot(c.player,c.rootCharacter,bodyRoot))return rebasePose(c.pose[bone],bodyRoot,root);}
 return c.pose[bone];
}
struct HeadMesh {void* player=nullptr;void* ownerRoot=nullptr;void* character=nullptr;int handle=-1;void* instance=nullptr;void* rig=nullptr;void* model=nullptr;void* skin=nullptr;void* renderable=nullptr;unsigned count=0;int head=-1;V bind{};int eyes[2]{-1,-1};V eyeBind[2]{};bool glove[128]{};ULONGLONG tick=0;};
static HeadMesh headMeshes[PlayerMeshSlots];static std::atomic<void*> headInstances[PlayerMeshSlots]{},headRenderables[PlayerMeshSlots]{};static std::atomic<int> headIndices[PlayerMeshSlots]{};static SRWLOCK headMeshLock=SRWLOCK_INIT;
static int headSlot(void* instance){if(!instance)return -1;for(unsigned i=0;i<PlayerMeshSlots;++i)if(headInstances[i].load(std::memory_order_relaxed)==instance)return i;return -1;}
static void rememberPlayerMeshes(void* player){
 BatchMemory batch;
 if(cinematicArms||!RFGRVR_HeadCam_IsLocalPlayer(player)||!base||!RFGRVR_HeadCam_Enabled()||!memory(player,0x330))return;void* character=pointer(player,0x32c);if(!character)return;
 PlayerParts owned=playerParts(player);for(unsigned slot=0;slot<PlayerMeshSlots;++slot){void* part=slot<owned.count?owned.part[slot]:nullptr;HeadMesh next{};int handle=part?(int)word(part,0):-1;
  if(handle>=0&&memory(part,0x38)){void* instance=base+0x35acbd0+(handle%356)*0x410;void* rig=pointer(instance,0x18);unsigned count=word(rig,0x24);
   auto* bones=(unsigned char*)pointer(rig,0x38);auto* map=(signed char*)pointer(instance,0x124);
   if(playerPart(player,part,instance)&&count&&count<=128&&memory(bones,count*36)&&memory(map,count+12)){
    AcquireSRWLockShared(&headMeshLock);next=headMeshes[slot];ReleaseSRWLockShared(&headMeshLock);
    if(next.instance!=instance||next.rig!=rig||next.count!=count){next={};next.instance=instance;next.rig=rig;next.count=count;
     for(unsigned bone=0;bone<count;++bone){int physical=map[bone+12];if(physical<0||physical>=(int)count)continue;
      const char* boneName=(const char*)(bones+physical*36+(int)word(bones+physical*36,0));if(memory(boneName,16))next.glove[bone]=vrbody::handBone(boneName);
      if(boneNamed(bones,physical,"head")){next.head=int(bone);memcpy(&next.bind,bones+physical*36+4,12);if(!finite(next.bind))next.head=-1;}
      for(int side=0;side<2;++side)if(boneNamed(bones,physical,side?"r-eye":"l-eye")){next.eyes[side]=int(bone);memcpy(&next.eyeBind[side],bones+physical*36+4,12);if(!finite(next.eyeBind[side]))next.eyes[side]=-1;}
     }
     // Eye-only meshes must receive the same private-palette treatment.
     if(next.head<0)for(int side=0;side<2;++side)if(next.eyes[side]>=0){next.head=next.eyes[side];next.bind=next.eyeBind[side];break;}

    }next.model=pointer(instance,4);next.skin=pointer(instance,0);next.player=player;next.ownerRoot=character;next.character=part;next.handle=handle;next.renderable=pointer(part,0x30);next.tick=GetTickCount64();
   }
  }
  AcquireSRWLockExclusive(&headMeshLock);headMeshes[slot]=next;ReleaseSRWLockExclusive(&headMeshLock);
  headIndices[slot]=next.head;headRenderables[slot]=next.count?next.renderable:nullptr;headInstances[slot]=next.count?next.instance:nullptr;
 }
}
static bool validHeadOwner(const HeadMesh& mesh){
 if(cinematicArms||!RFGRVR_HeadCam_Enabled()||!RFGRVR_HeadCam_IsLocalPlayer(mesh.player)||GetTickCount64()-mesh.tick>=500)return false;
 return mesh.ownerRoot==pointer(mesh.player,0x32c)&&playerPart(mesh.player,mesh.character,mesh.instance)&&memory(mesh.character,0x38)&&int(word(mesh.character,0))==mesh.handle&&pointer(mesh.character,0x30)==mesh.renderable&&pointer(mesh.instance,0x18)==mesh.rig&&pointer(mesh.instance,4)==mesh.model&&pointer(mesh.instance,0)==mesh.skin;
}
#include "local_body_geometry.h"
static bool hiddenHeadBone(int slot,int bone){if(slot<0)return false;AcquireSRWLockShared(&headMeshLock);const auto& m=headMeshes[slot];bool hide=validHeadOwner(m)&&(bone==m.head||bone==m.eyes[0]||bone==m.eyes[1]);ReleaseSRWLockShared(&headMeshLock);return hide;}
static bool shrinkHeadPalette(void* instance,Pose* output,unsigned count,const ArmCommand* command=nullptr,const Pose* root=nullptr){
 int slot=headSlot(instance);if(slot<0||!output||!RFGRVR_HeadCam_Enabled())return false;
 AcquireSRWLockShared(&headMeshLock);HeadMesh mesh=headMeshes[slot];ReleaseSRWLockShared(&headMeshLock);
 if(!validHeadOwner(mesh)||mesh.instance!=instance||mesh.count!=count)return false;
 if(mesh.head<0)return false;
 auto* model=(Pose*)pointer(instance,4);if(!memory(model,count*48))return false;
 bool hidden=false;for(int part=0;part<3;++part){int bone=part?mesh.eyes[part-1]:mesh.head;V bind=part?mesh.eyeBind[part-1]:mesh.bind;if(bone<0||unsigned(bone)>=count)continue;
 Pose pose=model[bone];if(command&&root&&command->changed[bone])pose=commandBone(*command,unsigned(bone),*root);
 if(!valid(pose.b)||!finite(pose.p))continue;
 constexpr float scale=.001f;Pose tiny{{mul(pose.b.r,scale),mul(pose.b.u,scale),mul(pose.b.f,scale)},pose.p};tiny.p=add(pose.p,world(tiny.b,bind));output[bone]=tiny;hidden=true;}return hidden;
}
static void nativeSkinAndHideHead(void* instance,void* first,void* second){
 int slot=headSlot(instance);HeadMesh owner{};
 if(slot>=0||controlledInstance(instance)){unsigned n=word(pointer(instance,0x18),0x24);if(!n||n>4096||!memory(pointer(instance,0),n*48,true))return;}
 if(slot>=0){AcquireSRWLockShared(&headMeshLock);owner=headMeshes[slot];ReleaseSRWLockShared(&headMeshLock);}if(slot<0||!validHeadOwner(owner)||(headIndices[slot].load()<0&&!vrsettings::get().value[vrsettings::Body])){originalSkin(instance,first,second);return;}
 // Retired character instances can retain their rig while their output palette
 // has already been released. The native CPU builder does not allocate it.
 unsigned liveCount=word(pointer(instance,0x18),0x24);if(!liveCount||liveCount>4096||!memory(pointer(instance,0),liveCount*48,true))return;
 unsigned count=word(pointer(instance,0x18),0x24);auto* skin=(Pose*)pointer(instance,0);auto* model=(Pose*)pointer(instance,4);
 if(!count||count>128||!memory(instance,0x410)||!memory(skin,count*48,true)||!memory(model,count*48)){originalSkin(instance,first,second);return;}
 AcquireSRWLockExclusive(&skinBuildLock);alignas(16) unsigned char header[0x410];Pose privateModel[128],privateSkin[128];
 memcpy(header,instance,sizeof(header));memcpy(privateModel,model,count*48);memcpy(privateSkin,skin,count*48);Pose* output=privateSkin;Pose* input=privateModel;
 memcpy(header,&output,sizeof(void*));memcpy(header+4,&input,sizeof(void*));originalSkin(header,first,second);shrinkHeadPalette(instance,privateSkin,count);memcpy(skin,privateSkin,count*48);ReleaseSRWLockExclusive(&skinBuildLock);
}
static void nativePaletteAndHideHead(void* renderable,const Pose* source,unsigned count){
 void* instance=nullptr;for(unsigned i=0;i<PlayerMeshSlots;++i)if(headRenderables[i].load(std::memory_order_relaxed)==renderable){instance=headInstances[i].load();break;}
 if(instance&&count&&count<=128&&memory(source,count*48)){Pose output[128];memcpy(output,source,count*48);bool hidden=shrinkHeadPalette(instance,output,count);HeadMesh owner{};int slot=headSlot(instance);if(slot>=0){AcquireSRWLockShared(&headMeshLock);owner=headMeshes[slot];ReleaseSRWLockShared(&headMeshLock);}bool local=slot>=0&&validHeadOwner(owner);if(local){Pose root{};if(renderRoot(owner.player,owner.character,root))vrworldview::shiftPalette(output,count,root);}if(hidden||local){paletteCopy(renderable,output,count);return;}}
 paletteCopy(renderable,source,count);
}
// Native per-bone writes bypass the full palette builder. Preserve their
// animation model output, but never publish that competing pose to a tracked
// arm's skin. 88AFF0 only writes the addressed model and palette entries.
static void __fastcall OnSetBone(void* instance,void*,int bone,const V* position,const M* orientation){
 ArmCommand c;
 if(!position||!orientation||!getCommand(instance,c)||bone<0||bone>=(int)c.count||!c.changed[bone]){
  int slot=headSlot(instance);if(position&&orientation&&slot>=0&&hiddenHeadBone(slot,bone)){auto* skin=(Pose*)pointer(instance,0);auto* model=(Pose*)pointer(instance,4);unsigned count=word(pointer(instance,0x18),0x24);
   if(bone>=0&&unsigned(bone)<count&&count<=128&&memory(skin,count*48,true)&&memory(model,count*48,true)){
    AcquireSRWLockExclusive(&skinBuildLock);model[bone]={*orientation,*position};bool hidden=shrinkHeadPalette(instance,skin,count);ReleaseSRWLockExclusive(&skinBuildLock);if(hidden)return;
   }
  }setBone(instance,bone,position,orientation);return;}
 auto* model=(Pose*)pointer(instance,4);auto* skin=(Pose*)pointer(instance,0);
 if(!memory(instance,0x410)||!memory(model,c.count*48,true)||!memory(skin,c.count*48,true)){setBone(instance,bone,position,orientation);return;}
 Pose native{*orientation,*position},tracked=commandBone(c,bone,currentRoot(c));
 AcquireSRWLockExclusive(&skinBuildLock);
 // Do not call the native setter on the real instance: that would publish a
 // native skin pose before correcting it. Its native model write is retained.
 model[bone]=native;
 alignas(16) unsigned char privateInstance[0x410];Pose privateModel[128];
 memcpy(privateInstance,instance,sizeof(privateInstance));Pose* scratch=privateModel;memcpy(privateInstance+4,&scratch,sizeof(scratch));
 setBone(privateInstance,bone,&tracked.p,&tracked.b);
 int slot=headSlot(instance);if(slot>=0&&hiddenHeadBone(slot,bone)){Pose root=currentRoot(c);shrinkHeadPalette(instance,skin,c.count,&c,&root);}
 ReleaseSRWLockExclusive(&skinBuildLock);++guardedBoneWrites;
}
// The renderable owns a separate palette at +124. Updating the animation
// instance alone leaves that draw cache at a previous simulation pose.
static void __fastcall OnPaletteCopy(void* renderable,void*,const Pose* source,unsigned count){
 if(GutterCloth::copy(renderable,source,count))return;
 BatchMemory batch;vrmemory::Scope memoryScope;
 ArmCommand c;void* instance=renderable==commandedRenderable.load()?commandedInstance.load():nullptr;
 for(unsigned i=0;i<SupplementalSlots;++i)if(renderable==supplementalRenderables[i].load())instance=supplementalInstances[i].load();
 if(!instance){nativePaletteAndHideHead(renderable,source,count);return;}
 if(!getCommand(instance,c)||pointer(c.character,0x30)!=renderable||count!=c.count||!memory(source,count*48)){nativePaletteAndHideHead(renderable,source,count);return;}
 Pose output[128];memcpy(output,source,count*48);Pose root=currentRoot(c);
 void* rig=pointer(instance,0x18);auto* bones=(unsigned char*)pointer(rig,0x38);auto* map=(signed char*)pointer(instance,0x124);
 if(!memory(bones,count*36)||!memory(map,count+12)){nativePaletteAndHideHead(renderable,source,count);return;}
 for(unsigned i=0;i<count;++i)if(c.changed[i]){int physical=map[i+12];if(physical<0||physical>=(int)count){nativePaletteAndHideHead(renderable,source,count);return;}
  V bind{};memcpy(&bind,bones+physical*36+4,12);if(!finite(bind)){nativePaletteAndHideHead(renderable,source,count);return;}
  Pose pose=commandBone(c,i,root);output[i]={pose.b,add(pose.p,world(pose.b,bind))};
 }
 shrinkHeadPalette(instance,output,count,&c,&root);
 vrworldview::shiftPalette(output,count,root);paletteCopy(renderable,output,count);
}
static void __fastcall OnSkin(void* instance,void*,void* first,void* second){
 BatchMemory batch;vrmemory::Scope memoryScope;
 if(!controlledInstance(instance)){nativeSkinAndHideHead(instance,first,second);return;}
 ArmCommand c;if(!getCommand(instance,c)){nativeSkinAndHideHead(instance,first,second);return;}Measure measured(skinCost);
 auto* poses=(Pose*)pointer(instance,4);auto* skin=(Pose*)pointer(instance,0);void* mapping=pointer(instance,0x124);
 if(!memory(instance,0x410)||!memory(mapping,12)||word(mapping,4)!=c.count||!memory(poses,c.count*48)||!memory(skin,c.count*48,true)){nativeSkinAndHideHead(instance,first,second);return;}
 AcquireSRWLockExclusive(&skinBuildLock);
 // 88C940 is a CPU palette builder (no calls or identity lookups). Build on
 // a private instance header and private model/palette arrays. Native walking
 // animation never publishes an intermediate palette or sees VR model poses.
 alignas(16) unsigned char privateInstance[0x410];Pose privateModel[128],privateSkin[128];
 memcpy(privateInstance,instance,sizeof(privateInstance));memcpy(privateModel,poses,c.count*48);memcpy(privateSkin,skin,c.count*48);
 Pose* skinPointer=privateSkin;memcpy(privateInstance,&skinPointer,sizeof(void*));Pose* modelPointer=privateModel;memcpy(privateInstance+4,&modelPointer,sizeof(void*));
 originalSkin(privateInstance,first,second);Pose root=currentRoot(c);
 for(unsigned i=0;i<c.count;++i)if(c.changed[i]){Pose pose=commandBone(c,i,root);setBone(privateInstance,i,&pose.p,&pose.b);}
 shrinkHeadPalette(instance,privateSkin,c.count,&c,&root);
 memcpy(skin,privateSkin,c.count*48);unsigned published=++skinApplications;ReleaseSRWLockExclusive(&skinBuildLock);
 if(published==1||published%600==0){char line[120];sprintf_s(line,"Completed VR skin palette published: passes=%u",published);log(line);}
}
static Pose* __fastcall OnLocal(void* instance,void*,Pose* output,int bone){
 vrmemory::Scope memoryScope;
 Pose* result=originalLocal(instance,output,bone);
 // Reject other characters before copying or locking any arm state.
 if(!output||!controlling.load(std::memory_order_relaxed)||commandedInstance.load(std::memory_order_relaxed)!=instance)return result;
 Measure measured(attachmentCost);ArmCommand c;if(!getCommand(instance,c)||bone<0||bone>=(int)c.total)return result;
 int side=c.side[bone];if(side<0){return result;}
 Pose root=currentRoot(c);
 if(bone<(int)c.count||c.changed[bone]){*output=rebasePose(c.pose[bone],c.root,root);return result;}
 // Virtual hand tags retain their native offset relative to the physical hand.
 auto* poses=(Pose*)pointer(instance,4);int hand=c.physical[side];
 if(memory(poses,c.count*48)&&valid(poses[hand].b)){
 Pose native=poses[hand],desired=rebasePose(c.pose[hand],c.root,root);V offset=local(native.b,sub(output->p,native.p));M rotation=relative(native.b,output->b);
 output->p=add(desired.p,world(desired.b,offset));output->b=compose(desired.b,rotation);
 }
 return result;
}
static bool descendant(int bone,int ancestor,const int* parents,int count){for(int i=0;i<count&&bone>=0&&bone<count;++i){if(bone==ancestor)return true;bone=parents[bone];}return false;}
static void buildSolverReference(unsigned char* bones,const int* parents,unsigned count,const int upper[2],const Pose* native,Pose* result){
 memcpy(result,native,count*sizeof(Pose));int root=-1;for(unsigned i=0;i<count;++i)if(boneNamed(bones,i,"root")){root=int(i);break;}
 if(root<0||!valid(native[root].b))return;
 for(unsigned i=0;i<count;++i)result[i]=RFGRVR_NeutralBone(native[i],native[root],1);
 V shoulder[2]{};for(int arm=0;arm<2;++arm){memcpy(&shoulder[arm],bones+upper[arm]*36+4,12);shoulder[arm]=mul(shoulder[arm],-1);}
 if(!finite(shoulder[0])||!finite(shoulder[1])||shoulder[0].y<.5f||shoulder[1].y<.5f||shoulder[0].y>2.2f||shoulder[1].y>2.2f||fabsf(shoulder[0].x+shoulder[1].x)>.03f||fabsf(shoulder[0].z-shoulder[1].z)>.03f)return;
 for(int arm=0;arm<2;++arm){V delta=sub(shoulder[arm],result[upper[arm]].p);
  for(unsigned i=0;i<count;++i)if(descendant(i,upper[arm],parents,count))result[i].p=add(result[i].p,delta);
  int clavicle=parents[upper[arm]];if(clavicle>=0&&boneNamed(bones,clavicle,arm?"r-clavicle":"l-clavicle")){V bind{};memcpy(&bind,bones+clavicle*36+4,12);if(finite(bind))result[clavicle].p=mul(bind,-1);}
 }
}
static RFGRVRBodyChain findBodyChain(unsigned char* bones,unsigned count){
 RFGRVRBodyChain body;for(unsigned i=0;i<count;++i){
  if(boneNamed(bones,i,"root"))body.root=int(i);if(boneNamed(bones,i,"pelvis"))body.pelvis=int(i);if(boneNamed(bones,i,"spine"))body.spine=int(i);if(boneNamed(bones,i,"head"))body.head=int(i);
  for(int side=0;side<2;++side){if(boneNamed(bones,i,side?"r-eye":"l-eye"))body.eye[side]=int(i);if(boneNamed(bones,i,side?"r-thigh":"l-thigh"))body.thigh[side]=int(i);if(boneNamed(bones,i,side?"r-calf":"l-calf"))body.calf[side]=int(i);if(boneNamed(bones,i,side?"r-foot":"l-foot"))body.foot[side]=int(i);}
 }return body;
}
}
extern "C" bool RFGRVR_Arms_Install(){
 char trimPath[MAX_PATH]{};GetModuleFileNameA(nullptr,trimPath,MAX_PATH);auto* trimSlash=strrchr(trimPath,92);if(trimSlash){strcpy_s(trimSlash+1,MAX_PATH-(trimSlash+1-trimPath),"RFGRVR-hand-alignment.ini");int up=GetPrivateProfileIntA("Alignment","HandPitchUpDegrees",12,trimPath),down=GetPrivateProfileIntA("Alignment","WeaponPitchDownDegrees",12,trimPath);if(up>=-45&&up<=45)handPitchUpDegrees=float(up);if(down>=-45&&down<=45)weaponPitchDownDegrees=float(down);}
 char profilePath[MAX_PATH]{};GetModuleFileNameA(nullptr,profilePath,MAX_PATH);auto* profileSlash=strrchr(profilePath,'\\');if(profileSlash){strcpy_s(profileSlash+1,MAX_PATH-(profileSlash+1-profilePath),"RFGRVR-elbow-profile.txt");if(elbowProfile.load(profilePath))log("Measured elbow reference profile loaded; wrist targets remain unfiltered.");}
 base=(unsigned char*)GetModuleHandleW(nullptr);unsigned char fireSig[]={0x81,0xec,0x84,0,0,0,0x53,0x55},muzzleSig[]={0x8b,0x81,0x48,1,0,0},setterSig[]={0x8b,0x41,4,0x83,0xec,0x18};
 if(!base||memcmp(base+0x7eaaf0,fireSig,sizeof(fireSig))||memcmp(base+0x7dca70,muzzleSig,sizeof(muzzleSig))||memcmp(base+0x88aff0,setterSig,sizeof(setterSig)))return false;
 setBone=(SetBone)(base+0x88aff0);lookup=(Lookup)(base+0x53c050);expired=(Expired)(base+0x18e720);
 if(MH_CreateHook(base+0x7dca70,(void*)&OnMuzzle,(void**)&originalMuzzle)!=MH_OK)return false;
 if(MH_CreateHook(base+0x7eaaf0,(void*)&OnFire,(void**)&originalFire)!=MH_OK){MH_RemoveHook(base+0x7dca70);return false;}
 if(MH_EnableHook(base+0x7dca70)!=MH_OK)return false;if(MH_EnableHook(base+0x7eaaf0)!=MH_OK){MH_DisableHook(base+0x7dca70);return false;}
 unsigned char skinSig[]={0x83,0xec,0x5c,0x83,0x7c,0x24,0x60,0},localSig[]={0x8b,0x44,0x24,8,0x56,0x57};
 if(memcmp(base+0x88c940,skinSig,sizeof(skinSig))||memcmp(base+0x88af10,localSig,sizeof(localSig)))return false;
 if(MH_CreateHook(base+0x88aff0,(void*)&OnSetBone,(void**)&setBone)!=MH_OK||MH_EnableHook(base+0x88aff0)!=MH_OK)return false;
 if(MH_CreateHook(base+0x88c940,(void*)&OnSkin,(void**)&originalSkin)!=MH_OK||MH_CreateHook(base+0x88af10,(void*)&OnLocal,(void**)&originalLocal)!=MH_OK)return false;
 if(MH_EnableHook(base+0x88c940)!=MH_OK||MH_EnableHook(base+0x88af10)!=MH_OK)return false;
 unsigned char visualSig[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x83,0xec,0x54};
 const unsigned char notifySig[]={0x8b,0x44,0x24,4,0x85,0xc0,0x74,0x1d};
 if(memcmp(base+0x3c28f0,notifySig,sizeof(notifySig)))return false;
 updateBounds=(BoundsUpdate)(base+0x3c28f0);
 const unsigned char visibilitySig[]={0x53,0x8a,0x5c,0x24,0x08,0x56};if(memcmp(base+0xc4910,visibilitySig,sizeof(visibilitySig)))return false;renderVisibility=(RenderVisibility)(base+0xc4910);
 if(memcmp(base+0x665190,visualSig,sizeof(visualSig))||MH_CreateHook(base+0x665190,(void*)&OnVisual,(void**)&originalVisual)!=MH_OK||MH_EnableHook(base+0x665190)!=MH_OK)return false;
 const unsigned char paletteSig[]={0x8b,0x44,0x24,8,0x3b,0x81,0x20,1,0,0};
 if(memcmp(base+0xd1380,paletteSig,sizeof(paletteSig))||MH_CreateHook(base+0xd1380,(void*)&OnPaletteCopy,(void**)&paletteCopy)!=MH_OK||MH_EnableHook(base+0xd1380)!=MH_OK)return false;
 const unsigned char tagSig[]={0x83,0xec,0x60,0x8d,0x81,0xa8,0,0,0};
 if(memcmp(base+0x63c390,tagSig,sizeof(tagSig))||MH_CreateHook(base+0x63c390,(void*)&OnItemTag,(void**)&originalItemTag)!=MH_OK||MH_EnableHook(base+0x63c390)!=MH_OK)return false;
 RFGRVRWeaponPhysics::install();installed=true;log("Controller-first wrists installed: weapon-independent wrist rotation and rig reference; items follow wrist. Live validation pending.");return true;
}
extern "C" void RFGRVR_Arms_RenderWeapon(void* renderer){
 BatchMemory batch;vrmemory::Scope memoryScope;
 if(!originalVisual||!controlling.load())return;
 // The engine's public 8911C0 wrapper calls 88C940 with (nullptr,nullptr).
 // Rebuild after render-time targets are published, before either eye draws.
 // Waiting for a simulation-side palette rebuild leaves the previous target
 // visible even when the item has already advanced to the current hand pose.
 void* instances[PlayerMeshSlots]={commandedInstance.load()};for(unsigned i=0;i<SupplementalSlots;++i)instances[i+1]=supplementalInstances[i].load();
 for(void* instance:instances){if(!instance)continue;OnSkin(instance,nullptr,nullptr,nullptr);++renderSkinRefreshes;
  ArmCommand current;if(paletteCopy&&getCommand(instance,current)){void* body=pointer(current.character,0x30);auto* skin=(Pose*)pointer(instance,0);void* cache=pointer(body,0x124);
   if(memory(body,0x12c)&&word(body,0x120)>=current.count&&memory(cache,current.count*48,true)&&memory(skin,current.count*48))OnPaletteCopy(body,nullptr,skin,current.count);
  }
 }
 VisualPart objects[32]{};unsigned count=0;
 AcquireSRWLockShared(&commandLock);if(GetTickCount64()-command.tick<200){count=command.visualCount;for(unsigned i=0;i<count;++i)objects[i]=command.visual[i];}ReleaseSRWLockShared(&commandLock);
 for(unsigned i=0;i<count;++i)if(memory(objects[i].object,0xc0)&&word(objects[i].object,0x6c)==objects[i].handle&&word(objects[i].object,0x70)==objects[i].parent&&!(word(objects[i].object,0x54)&0x8000u))OnVisual(objects[i].object,nullptr,renderer);
}
extern "C" void RFGRVR_Arms_Publish(RFGRShared* shared,const float anchor[3],const float frame[9],const float zero[4],const RFGRPose* reference){
 static RFGRShared* previousShared=nullptr;auto now=GetTickCount64();if(shared==previousShared&&publishChecked&&!requested()&&now-publishChecked<100u)return;publishChecked=now;previousShared=shared;
 Hands result{};if(zero){V forward=quaternion(zero[0],zero[1],zero[2],zero[3],{0,0,-1});result.physicalRoomYaw=atan2f(forward.x,-forward.z);}
 if(shared&&reference&&shared->version==RFGR_PROTOCOL){RFGRPose grip[2]{},aim[2]{},head{};bool snapshot=false;
 for(int i=0;i<3;++i){LONG a=shared->poseSequence;if(a&1)continue;MemoryBarrier();grip[0]=shared->left;grip[1]=shared->right;aim[0]=shared->leftAim;aim[1]=shared->rightAim;head=shared->hmd;result.sample=shared->poseSamples;MemoryBarrier();if(a==shared->poseSequence){snapshot=true;break;}}
 if(snapshot&&(head.validFlags&3)==3){V neck=quaternion(head.orientation[0],head.orientation[1],head.orientation[2],head.orientation[3],vrheadmotion::eyeFromPivot());result.physicalBody={head.position[0]-neck.x,head.position[1]-neck.y,-head.position[2]+neck.z};result.physicalBodyValid=finite(result.physicalBody);}
 if(snapshot&&shared->calibrationReady&&shared->calibrationFloorValid&&(head.validFlags&3)==3&&std::isfinite(head.position[1])&&shared->calibratedHeadHeight>=1&&shared->calibratedHeadHeight<=2.4f){
  result.floorFit=true;result.bodyOffset=(vrheadmotion::uprightHeight(head)-(vrsettings::get().value[vrsettings::Seated]?vrsettings::get().seatHeightCm/100.f:shared->calibratedHeadHeight))*RFGRVR_HeadCam_WorldScale();if(result.bodyOffset< -1.1f)result.bodyOffset=-1.1f;if(result.bodyOffset>.2f)result.bodyOffset=.2f;
 }
 if(snapshot){if(shared->calibrationReady&&std::isfinite(shared->calibratedArmSpan))result.calibratedSpan=shared->calibratedArmSpan*RFGRVR_HeadCam_WorldScale();V center{};M basis{};memcpy(&center,anchor,12);memcpy(&basis,frame,36);result.valid=valid(basis);for(int i=0;i<2;++i)result.valid=poseWorld(grip[i],*reference,center,basis,zero,result.grip[i])&&poseWorld(aim[i],*reference,center,basis,zero,result.aim[i])&&result.valid;result.tick=GetTickCount64();}}
 if(result.valid&&shared){RFGRPose raw[2]{},rawAim[2]{};bool captured=false;for(int attempt=0;attempt<3;++attempt){LONG seq=shared->poseSequence;if(seq&1)continue;MemoryBarrier();raw[0]=shared->left;raw[1]=shared->right;rawAim[0]=shared->leftAim;rawAim[1]=shared->rightAim;unsigned sample=shared->poseSamples;MemoryBarrier();if(seq==shared->poseSequence&&sample==result.sample){captured=true;break;}}if(captured)for(int hand=0;hand<2;++hand){auto& p=raw[hand];auto axis=[&](V v){v=quaternion(p.orientation[0],p.orientation[1],p.orientation[2],p.orientation[3],v);v.z=-v.z;return v;};result.physical[hand]={M{axis({1,0,0}),axis({0,1,0}),axis({0,0,-1})},{p.position[0],p.position[1],-p.position[2]}};p=rawAim[hand];result.physicalAim[hand]={M{axis({1,0,0}),axis({0,1,0}),axis({0,0,-1})},{p.position[0],p.position[1],-p.position[2]}};}else result.sample=0;}
 RFGRVR_CopyGripInput(shared,result.gripValue);
 AcquireSRWLockExclusive(&handLock);hands=result;ReleaseSRWLockExclusive(&handLock);
}
static void publishCommand(const ArmCommand& next){
 void* player=next.player;void* character=next.character;void* instance=next.instance;
 ArmCommand parts[SupplementalSlots]{};static RigRemap remaps[SupplementalSlots];PlayerParts ownedParts=playerParts(player);
 for(unsigned i=0;i<SupplementalSlots;++i){void* partCharacter=i+1<ownedParts.count?ownedParts.part[i+1]:nullptr;void* renderable=pointer(partCharacter,0x30);int partHandle=(int)word(partCharacter,0);
  if(partHandle<0||!memory(renderable,0x12c)||pointer(renderable,0)!=pointer(pointer(character,0x30),0))continue;
  void* partInstance=base+0x35acbd0+(partHandle%356)*0x410;
  if(partInstance!=instance&&playerPart(player,partCharacter,partInstance)&&!mapSupplemental(next,partInstance,partCharacter,parts[i],remaps[i]))parts[i]={};
 }
 AcquireSRWLockExclusive(&commandLock);command=next;for(unsigned i=0;i<SupplementalSlots;++i)supplemental[i]=parts[i];ReleaseSRWLockExclusive(&commandLock);commandedInstance=instance;commandedRenderable=pointer(character,0x30);for(unsigned i=0;i<SupplementalSlots;++i){supplementalInstances[i]=parts[i].instance;supplementalRenderables[i]=parts[i].instance?pointer(parts[i].character,0x30):nullptr;}
 for(unsigned i=0;i<32;++i)watchedVisuals[i]=i<next.visualCount?next.visual[i].object:nullptr;
}
extern "C" void RFGRVR_Arms_Player(void* player){
 if(cinematicArms||!RFGRVR_HeadCam_IsLocalPlayer(player))return;
 vrmemory::Scope memoryScope;rememberPlayerMeshes(player);
 Measure measured(playerCost);BatchMemory batch;auto now=GetTickCount64();bool enabled=requested();if(!enabled){supportHold.cancel();controlling=false;commandedInstance=nullptr;}if(!enabled&&preflightChecked&&now-preflightChecked<1000)return;preflightChecked=now;static ULONGLONG diagnostic=0;if(now-diagnostic>10000){diagnostic=now;Hands sample{};char line[300];sprintf_s(line,"Arm preflight state: player=%p state=%u rag=%u flags=%08x reload=%d eligible=%d hands=%d age=%llu",player,word(player,0x2f4),word(player,0x33c),word(player,0x338),(int)word(player,0xa4c),eligible(player)?1:0,getHands(sample)?1:0,now-sample.tick);log(line);long long pc=0,sc=0,ac=0;double pt=average(playerCost,pc),st=average(skinCost,sc),at=average(attachmentCost,ac);sprintf_s(line,"Arm own CPU average us: player=%.2f/%lld skin=%.2f/%lld attachment=%.2f/%lld visual_refresh=%u/%u bone_guard=%u render_skin=%u",pt,pc,st,sc,at,ac,nativeVisualRefreshes.exchange(0),controlledVisuals.exchange(0),guardedBoneWrites.exchange(0),renderSkinRefreshes.exchange(0));log(line);}if(!eligible(player)){seatedTurretScaffold.reset();supportHold.cancel();primaryPlacement.cancel();chargePlacement.cancel();chargeCapture.store(~0u);primaryCapture.store(~0u);supportCapture.store(~0u);controlling=false;commandedInstance=nullptr;AcquireSRWLockExclusive(&rigLock);binding={};ReleaseSRWLockExclusive(&rigLock);return;}
 void* character=pointer(player,0x32c);int handle=(int)word(character,0);if(handle<0)return;
 void* instance=base+0x35acbd0+(handle%356)*0x410;void* rig=pointer(instance,0x18);unsigned count=word(rig,0x24);
 auto* bones=(unsigned char*)pointer(rig,0x38);auto* poses=(Pose*)pointer(instance,4);auto* skin=pointer(instance,0);auto* map=(signed char*)pointer(instance,0x124);
 if(count<12||count>128||!memory(bones,count*36)||!memory(poses,count*48,true)||!memory(skin,count*48,true)||!memory(map,count+12)){
 static bool reported=false;if(!reported){reported=true;char text[220];sprintf_s(text,"Skeleton preflight rejected: handle=%d instance=%p rig=%p count=%u pose=%p skin=%p map=%p",handle,instance,rig,count,poses,skin,map);log(text);}return;}
 Pose old[128],nativeFingers[128];int parents[128];memcpy(old,poses,count*48);memcpy(nativeFingers,old,count*48);for(unsigned i=0;i<count;++i)memcpy(&parents[i],bones+i*36+28,4);
 int wrists[2]={(int)word(player,0xa6c),(int)word(player,0xa70)},elbows[2]{},upper[2]{};
 for(int i=0;i<2;++i)if(!armChain(player,rig,bones,parents,count,i,wrists[i],elbows[i],upper[i]))return;
 if(lastRig!=rig){lastRig=rig;char message[300];sprintf_s(message,"Skeleton preflight: handle=%d instance=%p rig=%p bones=%u left=%d/%d/%d right=%d/%d/%d lengths=%.3f/%.3f,%.3f/%.3f",handle,instance,rig,count,upper[0],elbows[0],wrists[0],upper[1],elbows[1],wrists[1],length(sub(old[elbows[0]].p,old[upper[0]].p)),length(sub(old[wrists[0]].p,old[elbows[0]].p)),length(sub(old[elbows[1]].p,old[upper[1]].p)),length(sub(old[wrists[1]].p,old[elbows[1]].p)));log(message);}
 if(!enabled)return;Pose root{};if(!RFGRVR_HeadCam_TurretRenderRoot(player,&root)&&!renderRoot(player,character,root))return;
 void* inventory=pointer(player,0xc90);unsigned weaponHandle=word(inventory,24);void* weapon=memory(inventory,28)?lookup(base+0x2b98490,weaponHandle):nullptr;
 if(void* carried=nativePropObject(player)){weapon=carried;weaponHandle=word(carried,0x6c);}
 if(!armRest.ready||armRest.rig!=rig||armRest.count!=count){armRest.rig=rig;armRest.count=count;memcpy(armRest.pose,old,count*48);buildSolverReference(bones,parents,count,upper,old,armRest.solver);armRest.body=findBodyChain(bones,count);armRest.ready=true;alignmentReady=false;crouchVisual.reset();physicalCrouchVisual=false;bodyReturnReady=false;}
 if(armRest.body.eye[0]>=0&&armRest.body.eye[1]>=0){V a{},b{};memcpy(&a,bones+armRest.body.eye[0]*36+4,12);memcpy(&b,bones+armRest.body.eye[1]*36+4,12);V eye=mul(add(a,b),-.5f);if(finite(eye)&&eye.y>=1&&eye.y<=2.4f)RFGRVR_HeadCam_AvatarEye(player,&eye.x);}
 Pose mountRoot{};bool mountedVR=RFGRVR_HeadCam_TurretRenderRoot(player,&mountRoot);
 const unsigned poseState=word(player,0x2f4);const bool seatedPose=poseState>=7&&poseState<=10;
 // Preserve the authored seated ENTRY scaffold, not the gun's ongoing
 // third-person aim animation. The current seat/root still supplies movement.
 if(mountedVR&&seatedPose){seatedTurretScaffold.capture(player,rig,word(player,0xa08),nativeFingers,count);memcpy(old,seatedTurretScaffold.pose,count*48);}else seatedTurretScaffold.reset();
 if(mountedVR){if(!seatedPose)memcpy(old,armRest.solver,count*48);weapon=nullptr;supportHold.cancel();}
 const Pose* armReference=seatedPose?(mountedVR?seatedTurretScaffold.pose:nativeFingers):armRest.solver;
 Hands h;if(!getHands(h)){supportHold.cancel();return;}
 if(nativePropCarry(player))supportHold.cancel();
 if(armRest.body.pelvis>=0)RFGRVR_HeadCam_AvatarPelvis(&armRest.solver[armRest.body.pelvis].p.x);
 unsigned trainingCommand=vrtraining::request.exchange(0);if(trainingCommand==1||trainingCommand==2){bool ok=armTraining.begin();if(ok){armTraining.phase=trainingCommand;vrstatus::notify(trainingCommand==1?"ARM: arm forward, handshake hand, elbow down; hold still until targets appear":"WRIST recording: hold elbow steady near each target; bend and twist RIGHT wrist");}else vrstatus::notify("Arm recording could not open its output file");}
 if(trainingCommand==3&&armTraining.phase){bool fitted=armTraining.finish();bool loaded=fitted&&elbowProfile.load(armTraining.profilePath);for(auto& e:elbowEstimator)e={};vrtraining::Markers empty;empty.pid=GetCurrentProcessId();empty.tick=GetTickCount();vrtraining::publish(empty);if(armTraining.error)vrstatus::notify("Arm recording write error: previous elbow profile retained");else if(loaded)vrstatus::notify("Arm recording saved; measured wrist-independent elbow profile applied");else{char note[180];sprintf_s(note,"Raw arm data saved; previous profile retained: %s",armTraining.saveReason);vrstatus::notify(note);}}
 if(vrtraining::active){supportHold.cancel();primaryPlacement.cancel();chargePlacement.cancel();primaryCapture=chargeCapture=supportCapture=~0u;}
 WeaponBinding wb{};AcquireSRWLockShared(&rigLock);wb=binding;ReleaseSRWLockShared(&rigLock);
 if(weapon&&memory(weapon,0x150)&&word(weapon,0x13c)==word(player,0x6c)){
 void* attachment=pointer(weapon,0x48);int parentTag=memory(attachment,12)?(int)word(attachment,4):-1,childTag=memory(attachment,12)?(int)word(attachment,8):-1;
 bool manualBinding=wb.weapon==weapon&&wb.handle==word(weapon,0x6c)&&wb.rig==rig&&wb.gripReady&&RFGRVRWeaponPhysics::Reload::controls(player,weapon);
 if(!manualBinding&&(wb.weapon!=weapon||wb.handle!=word(weapon,0x6c)||wb.rig!=rig||wb.attachment!=attachment||wb.parentTag!=parentTag||wb.childTag!=childTag||wb.supportTag!=(int)word(weapon,0x248)||(!wb.gripReady&&parentTag>=0&&childTag>=0))){Pose gun{},nativeMuzzle{};memcpy(&gun.p,(char*)weapon+4,12);memcpy(&gun.b,(char*)weapon+0x10,36);originalMuzzle(weapon,&nativeMuzzle.p,&nativeMuzzle.b);
 // Simulation item and native model belong to the same native pose domain.
 // Never recapture a grip against the preceding VR command on weapon changes.
 int hand=1,physical=parentTag;
 if(physical>=(int)count){unsigned virtualTag=unsigned(physical)-count;void* tags=pointer(rig,0x3c);physical=virtualTag<word(rig,0x30)&&memory((char*)tags+virtualTag*60,60)?(int)word((char*)tags+virtualTag*60,52):-1;}
 if(descendant(physical,wrists[0],parents,count))hand=0;
 const Pose* reference=armRest.pose;
 Pose nativeWrist{compose(root.b,reference[wrists[hand]].b),add(root.p,world(root.b,reference[wrists[hand]].p))};
 if(!valid(gun.b)||!finite(gun.p)){wb={};}else{
// Melee and placeable tools may have no muzzle tag. Their valid item root
// still defines hand alignment; a missing muzzle must not reject both arms.
if(!valid(nativeMuzzle.b)||!finite(nativeMuzzle.p))nativeMuzzle=gun;
wb.weapon=weapon;wb.hand=hand;wb.rig=rig;wb.handle=word(weapon,0x6c);wb.attachment=attachment;wb.parentTag=parentTag;wb.childTag=childTag;wb.rootInMuzzle=relative(nativeMuzzle.b,gun.b);wb.wristInMuzzle=relative(nativeMuzzle.b,nativeWrist.b);wb.primaryWristLocal={relative(gun.b,nativeWrist.b),local(gun.b,sub(nativeWrist.p,gun.p))};wb.gripInRoot=local(gun.b,sub(nativeWrist.p,gun.p));wb.muzzleFromGrip=local(nativeMuzzle.b,sub(nativeMuzzle.p,nativeWrist.p));if(length(wb.muzzleFromGrip)>2)wb.muzzleFromGrip={};wb.gripReady=bindNativeGrip(wb,weapon,rig,reference,count,wrists[hand]);wb.supportTag=(int)word(weapon,0x248);Pose itemIdentity{M{{1,0,0},{0,1,0},{0,0,1}},V{}};wb.supportReady=wb.gripReady&&wb.supportTag>=0&&wb.supportTag<4096&&wb.supportTag!=childTag&&itemTagPose(weapon,wb.supportTag,itemIdentity,wb.supportLocal)&&length(sub(wb.supportLocal.p,wb.gripInRoot))>.08f&&length(sub(wb.supportLocal.p,wb.gripInRoot))<1.2f;}}
 }else wb={};
 M controllerBasis[2]={h.grip[0].b,h.grip[1].b};
 for(unsigned hand=0;hand<2;++hand){h.grip[hand].b=turnAround(h.grip[hand].b,h.grip[hand].b.r,-handPitchUpDegrees*.01745329252f);h.aim[hand].b=turnAround(h.aim[hand].b,h.aim[hand].b.r,weaponPitchDownDegrees*.01745329252f);}

 LARGE_INTEGER neutralNow{},neutralFrequency{};QueryPerformanceCounter(&neutralNow);QueryPerformanceFrequency(&neutralFrequency);
 if(neutralPlayer!=player){crouchVisual.reset();physicalCrouchVisual=false;bodyReturnReady=false;neutralPlayer=player;neutralPose.reset();neutralCounter.QuadPart=0;}
 float neutralSeconds=neutralCounter.QuadPart?float(double(neutralNow.QuadPart-neutralCounter.QuadPart)/neutralFrequency.QuadPart):0;neutralCounter=neutralNow;
 const unsigned bodyState=word(player,0x2f4),bodyStance=word(player,0x2fc);
 const auto crouchConfig=vrsettings::get();const bool physicalSource=h.floorFit&&crouchConfig.value[vrsettings::Crouch]!=2&&!crouchConfig.value[vrsettings::Seated];
 const bool crouchAllowed=bodyState==0&&!mountedVR&&!seatedPose&&!RFGRVR_HeadCam_LandingRecovery();
 bool fittedCrouch=false;float crouchDesired=0;bool crouchChainReady=true;
 for(int bone:{armRest.body.root,armRest.body.pelvis,armRest.body.spine,armRest.body.head,armRest.body.thigh[0],armRest.body.thigh[1],armRest.body.calf[0],armRest.body.calf[1],armRest.body.foot[0],armRest.body.foot[1]})if(bone<0||unsigned(bone)>=count)crouchChainReady=false;
 if(armRest.body.eye[0]>=0&&armRest.body.eye[1]>=0){
  float rest=(armRest.solver[armRest.body.eye[0]].p.y+armRest.solver[armRest.body.eye[1]].p.y)*.5f;
  float native=(old[armRest.body.eye[0]].p.y+old[armRest.body.eye[1]].p.y)*.5f-rest;
  crouchDesired=physicalSource?(std::min)(0.f,h.bodyOffset):native;
  bool request=physicalSource?crouchDesired<-.01f:(bodyStance==1||bodyStance==4);
  float desired=crouchVisual.update(crouchDesired,native,neutralSeconds,crouchAllowed&&crouchChainReady,request,physicalSource);
  if(crouchVisual.active&&crouchAllowed&&crouchChainReady){bool trackedBody[128]{};float pelvis=armRest.body.pelvis>=0?armRest.solver[armRest.body.pelvis].p.y+desired*.65f-old[armRest.body.pelvis].p.y:100.f;
   fittedCrouch=RFGRVR_FitBodyHeight(old,count,parents,armRest.body,trackedBody,desired-native,pelvis,false);
  }
 }else crouchVisual.reset();
 physicalCrouchVisual=physicalSource&&crouchAllowed&&crouchChainReady;
 const bool crouchedStance=bodyStance==1||bodyStance==4;
 const bool nativeBodyPose=fittedCrouch||bodyState==1||bodyState==2||crouchedStance||RFGRVR_HeadCam_LandingRecovery();
 float neutralWeight=neutralPose.update(root.p,neutralSeconds,bodyState==0&&!crouchedStance&&!nativeBodyPose);
 if(nativeBodyPose)neutralWeight=0;
 float facing=RFGRVR_HeadCam_BodyYaw(),fc=cosf(facing),fs=sinf(facing);M desiredWorld{{fc,0,-fs},{0,1,0},{fs,0,fc}},neutralBasis=relative(root.b,desiredWorld);
 if(mountedVR||seatedPose){neutralWeight=0;neutralBasis=M{{1,0,0},{0,1,0},{0,0,1}};}
 int animationRoot=armRest.body.root;
 // Native crouch/jump and partial physical dips still carry the authored
 // sideways weapon stance. Remove only its yaw from the upper chain.
 const bool alignBodyYaw=!mountedVR&&!seatedPose&&bodyState<=2&&animationRoot>=0&&armRest.body.spine>=0&&(nativeBodyPose||(bodyReturnReady&&neutralWeight<1));
 const float targetBodyYaw=RFGRVR_BodyYaw(neutralBasis);
 if(alignBodyYaw){Pose pivot=old[animationRoot];for(unsigned i=0;i<count;++i)if(descendant(i,armRest.body.spine,parents,count))old[i]=RFGRVR_AlignBodyYaw(old[i],pivot,targetBodyYaw);}

 // Grounded crouch torso height is independent of native pelvis/foot
 // corrections, including after the native crouch stance starts. Native
 // firing and foot-placement pitch/roll/translation must not leak upward.
 const bool stablePhysicalTorso=fittedCrouch&&bodyState==0&&animationRoot>=0;
 if(stablePhysicalTorso){
  float pelvisY=armRest.solver[armRest.body.pelvis].p.y,headY=armRest.solver[armRest.body.head].p.y;
  for(unsigned i=0;i<count;++i)if(descendant(i,armRest.body.spine,parents,count))old[i]=RFGRVR_StableCrouchTorso(armRest.solver[i],armRest.solver[animationRoot],pelvisY,headY,crouchVisual.offset,neutralBasis);
 }
 float bodyOffset=0;
 if(!mountedVR&&armRest.body.head>=0&&animationRoot>=0&&crouchedStance){
  Pose nativeHead=RFGRVR_NeutralBone(old[armRest.body.head],old[animationRoot],1);
  bodyOffset=nativeHead.p.y-armRest.solver[armRest.body.head].p.y;
  if(bodyOffset>0)bodyOffset=0;if(bodyOffset< -1.1f)bodyOffset=-1.1f;
 }
 // Native animation already blends the crouch stance; do not use raw eye
 // height for torso elevation (head nodding must leave the body stationary).
 bodyOffset*=neutralWeight;
 // The native spine contains locomotion bob as well as stance animation.
 // Feeding that translation into IK animates the upper arms even with fixed
 // controller targets. Controlled shoulders use the stable rig reference;
 // world movement is supplied by the render root, never the walking pose.
 V shoulders[2]={armReference[upper[0]].p,armReference[upper[1]].p};if(nativeBodyPose&&!mountedVR&&!seatedPose){shoulders[0]=old[upper[0]].p;shoulders[1]=old[upper[1]].p;for(unsigned side=0;side<2;++side)bodyReturnShoulder[side]=old[upper[side]];bodyReturnReady=true;bodyOffset=0;neutralBasis=M{{1,0,0},{0,1,0},{0,0,1}};}
 if(!nativeBodyPose&&!mountedVR&&!seatedPose&&bodyReturnReady&&neutralWeight<1)for(unsigned side=0;side<2;++side)shoulders[side]=add(bodyReturnShoulder[side].p,mul(sub(shoulders[side],bodyReturnShoulder[side].p),neutralWeight));
 if(mountedVR&&!seatedPose)bodyOffset=h.floorFit?h.bodyOffset:0;
 for(auto& shoulder:shoulders)shoulder.y+=bodyOffset;
 // Cancel native locomotion turn-to-travel at the render root for every
 // weapon, independent of support grip. Hands remain tracked world targets.
 if(animationRoot>=0){V pivot=armRest.solver[animationRoot].p;for(auto& shoulder:shoulders)shoulder=add(pivot,world(neutralBasis,sub(shoulder,pivot)));}
 int clavicles[2]={-1,-1};for(int arm=0;arm<2;++arm){int parent=parents[upper[arm]];if(parent>=0&&boneNamed(bones,parent,arm?"r-clavicle":"l-clavicle")){clavicles[arm]=parent;if(nativeBodyPose&&!mountedVR&&!seatedPose)bodyReturnClavicle[arm]=old[parent];else if(bodyReturnReady&&neutralWeight<1&&!mountedVR&&!seatedPose)old[parent]=RFGRVR_BlendPose(bodyReturnClavicle[arm],armReference[parent],neutralWeight);else old[parent]=armReference[parent];}}
 for(int clavicle:clavicles)if(clavicle>=0){old[clavicle].p.y+=bodyOffset;if(animationRoot>=0){V pivot=armRest.solver[animationRoot].p;old[clavicle].p=add(pivot,world(neutralBasis,sub(old[clavicle].p,pivot)));old[clavicle].b=compose(neutralBasis,old[clavicle].b);}}
 if(!nativeBodyPose&&neutralWeight>=1)bodyReturnReady=false;
 for(int arm=0;arm<2;++arm)for(unsigned bone=0;bone<count;++bone)if(descendant(bone,upper[arm],parents,count)){
  old[bone].p=add(shoulders[arm],world(neutralBasis,sub(armReference[bone].p,armReference[upper[arm]].p)));old[bone].b=compose(neutralBasis,armReference[bone].b);
 }
 float lean=mountedVR?0:RFGRVR_HeadCam_ForwardLean();V leanPivot=armRest.body.pelvis>=0?armRest.solver[armRest.body.pelvis].p:V{0,.9f,0};leanPivot=world(neutralBasis,leanPivot);
 if(lean!=0)for(unsigned bone=0;bone<count;++bone){bool upperBody=false;for(int side=0;side<2;++side)upperBody=upperBody||descendant(bone,upper[side],parents,count)||int(bone)==clavicles[side];if(upperBody)old[bone]=RFGRVR_LeanPose(old[bone],leanPivot,lean,neutralBasis.r);}
 if(stablePhysicalTorso&&lean!=0)for(unsigned bone=0;bone<count;++bone){bool armBone=false;for(int side=0;side<2;++side)armBone=armBone||descendant(bone,upper[side],parents,count)||int(bone)==clavicles[side];if(!armBone&&descendant(bone,armRest.body.spine,parents,count))old[bone]=RFGRVR_LeanPose(old[bone],leanPivot,lean,neutralBasis.r);}
 if(!alignmentReady||alignmentRig!=rig){for(int i=0;i<2;++i){gripCenterInWrist[i]={};if(!anatomicalGrip(bones,old,count,i,wrists[i],gripAlignment[i],gripCenterInWrist[i]))gripAlignment[i]=relative(h.grip[i].b,compose(root.b,old[wrists[i]].b));}alignmentRig=rig;alignmentReady=true;}
 Pose targets[2];for(int i=0;i<2;++i){M worldWrist=compose(h.grip[i].b,gripAlignment[i]);V wristWorld=sub(h.grip[i].p,world(worldWrist,gripCenterInWrist[i]));targets[i].p=local(root.b,sub(wristWorld,root.p));targets[i].b=relative(root.b,worldWrist);}
 if(mountedVR){Pose gun{},nativeRoot{};unsigned gunId=~0u;bool entering=false;
  if(RFGRVR_HeadCam_TurretGunPose(player,&gun,&gunId,&entering)&&renderRoot(player,character,nativeRoot)){
   AcquireSRWLockExclusive(&turretGripLock);
   bool newTurret=turretGripId!=gunId;
   if(newTurret||entering){bool validGrips=true;Pose captured[2]{};
    for(int side=0;side<2;++side){Pose wrist=vrgrip::worldPose(nativeRoot,nativeFingers[wrists[side]]);captured[side]=vrgrip::relativePose(gun,wrist);validGrips=validGrips&&valid(captured[side].b)&&finite(captured[side].p)&&length(captured[side].p)<2;}
    void* nativeGun=lookup(base+0x2b98490,gunId);const Pose identityPose{M{{1,0,0},{0,1,0},{0,0,1}},V{}};
    if(memory(nativeGun,0x25c)&&word(nativeGun,0x6c)==gunId)for(int side=0;side<2;++side){int tag=(int)word(nativeGun,side?0x244:0x248);Pose grip{};
     if(tag>=0&&tag<4096&&itemTagPose(nativeGun,tag,identityPose,grip)){
      // Native hand targets can be virtual rig tags, absent from the bone-name list.
      Pose wristToProp{M{{1,0,0},{0,1,0},{0,0,1}},gripCenterInWrist[side]},handTarget{};bool haveTarget=false;int nativeTag=(int)word(player,side?0xa70:0xa6c);
      if(nativeTag>=0&&nativeTag<(int)count){handTarget=nativeFingers[nativeTag];haveTarget=true;}
      else if(nativeTag>=(int)count){unsigned index=unsigned(nativeTag)-count;auto* tags=(unsigned char*)pointer(rig,0x3c);if(index<word(rig,0x30)&&memory(tags+index*60,60)){unsigned physical=word(tags+index*60,52);Pose offset{};memcpy(&offset,tags+index*60+4,48);if(physical<count&&valid(offset.b)&&finite(offset.p)){handTarget=vrgrip::worldPose(nativeFingers[physical],offset);haveTarget=true;}}}
      if(haveTarget)wristToProp=vrgrip::relativePose(nativeFingers[wrists[side]],handTarget);

      captured[side].b=compose(grip.b,relative(wristToProp.b,identityPose.b));captured[side].p=sub(grip.p,world(captured[side].b,wristToProp.p));
     }
    }
    if(validGrips){turretGripId=gunId;memcpy(turretGripLocal,captured,sizeof(captured));}
   }
   if(turretGripId==gunId){
    if(newTurret||!turretHandZeroReady||fabsf(std::remainder(h.physicalRoomYaw-turretZeroYaw,6.28318530718f))>.001f){turretZeroYaw=h.physicalRoomYaw;turretZeroHeight=RFGRVR_HeadCam_VehicleHeight();Pose wrist=vrgrip::worldPose(gun,turretGripLocal[1]);V palm=add(wrist.p,world(wrist.b,gripCenterInWrist[1]));M physicalToWorld=compose(controllerBasis[1],relative(h.physical[1].b,M{{1,0,0},{0,1,0},{0,0,1}}));turretHandZero=add(h.physical[1].p,mul(local(physicalToWorld,sub(palm,h.grip[1].p)),1/RFGRVR_HeadCam_WorldScale()));turretHandZeroReady=h.sample&&valid(h.physical[1].b)&&valid(h.grip[1].b)&&finite(turretHandZero);}
    float seatHeight=RFGRVR_HeadCam_VehicleHeight();if(turretHandZeroReady)turretHandZero.y-=(seatHeight-turretZeroHeight)/RFGRVR_HeadCam_WorldScale();turretZeroHeight=seatHeight;
    for(int side=0;side<2;++side)targets[side]=vrgrip::relativePose(root,vrgrip::worldPose(gun,turretGripLocal[side]));turretGripTick=GetTickCount64();
   }
   ReleaseSRWLockExclusive(&turretGripLock);
  }
 }else{AcquireSRWLockExclusive(&turretGripLock);turretGripId=~0u;turretGripTick=0;turretHandZeroReady=false;ReleaseSRWLockExclusive(&turretGripLock);}
 Pose chargeWeapon{};void* chargeObject=nullptr;
 float itemScale=wb.weapon?scopedWeaponScale(wb.weapon):1.f;
 Pose heldWeapon{},unblockedWeapon{},supportForHud{};V chargeBlocking{};bool haveHeldWeapon=false,supportForHudReady=false;
 if(wb.weapon){
  Pose wristWorld{compose(root.b,targets[wb.hand].b),add(root.p,world(root.b,targets[wb.hand].p))};
  M orientation=compose(wristWorld.b,relative(wb.wristInMuzzle,wb.rootInMuzzle));
  if(wb.hand==1&&(int)word(wb.weapon,0x254)>=0&&(int)word(wb.weapon,0x254)<4096)orientation=compose(h.aim[1].b,wb.rootInMuzzle);
  heldWeapon={orientation,sub(wb.gripReady?h.grip[wb.hand].p:wristWorld.p,world(orientation,mul(wb.gripInRoot,itemScale)))};
  if(word(pointer(wb.weapon,0x148),0x10)!=3){char name[96]{};if(weaponTrimName(wb.weapon,name)){auto trim=weaponTrim(name);V scaledPoint=mul(wb.gripInRoot,itemScale);V gripPoint=add(heldWeapon.p,world(heldWeapon.b,scaledPoint));heldWeapon=trim.apply(heldWeapon,heldWeapon.b,scaledPoint,gripPoint);}}
  V mainGripLocal=mul(wb.gripInRoot,itemScale);char profileName[96]{};bool namedProfile=weaponTrimName(wb.weapon,profileName);
  if(namedProfile){AcquireSRWLockExclusive(&weaponTrimLock);initWeaponTrims();auto* e=weaponAlignments.find(profileName);if(e&&e->primaryCaptured){Pose scaledGrip=e->drivePrimaryGrip?weaponAlignments.primaryControllerPose(profileName,wb.primaryWristLocal,gripAlignment[wb.hand],gripCenterInWrist[wb.hand]):e->primaryGrip;scaledGrip.p=mul(scaledGrip.p,itemScale);heldWeapon=vrgrip::weaponAtGrip(h.grip[wb.hand],scaledGrip);mainGripLocal=scaledGrip.p;}ReleaseSRWLockExclusive(&weaponTrimLock);}
  static unsigned primarySeen=~0u;unsigned primaryRequest=primaryCapture.load();
  if(primaryRequest!=primarySeen){if(primaryRequest!=~0u&&primaryRequest==wb.handle){primaryPlacement.begin((uintptr_t)wb.weapon,wb.handle,heldWeapon);supportHold.cancel();supportCapture.store(~0u);}else primaryPlacement.cancel();primarySeen=primaryRequest;}
  if(primaryPlacement.active){
   if(primaryPlacement.weapon!=(uintptr_t)wb.weapon||primaryPlacement.handle!=wb.handle){primaryPlacement.cancel();primaryCapture.store(~0u);}
   else{heldWeapon=primaryPlacement.fixed;
    if(primaryPlacement.update((uintptr_t)wb.weapon,wb.handle,h.gripValue[wb.hand])){bool saved=false;if(namedProfile){AcquireSRWLockExclusive(&weaponTrimLock);initWeaponTrims();Pose captured=vrgrip::relativePose(heldWeapon,h.grip[wb.hand]);captured.p=mul(captured.p,1/itemScale);saved=weaponAlignments.capturePrimary(profileName,captured);mainGripLocal=mul(captured.p,itemScale);ReleaseSRWLockExclusive(&weaponTrimLock);}primaryPlacement.cancel();primaryCapture.store(~0u);vrstatus::notify(saved?"PRIMARY hand position AND orientation SAVED":"Primary grip capture failed");}
   }
  }
  V primaryAnchor=add(heldWeapon.p,world(heldWeapon.b,mainGripLocal));
  Pose effectiveSupport=wb.supportLocal;if(!wb.supportReady){M barrel=relative(wb.rootInMuzzle,M{{1,0,0},{0,1,0},{0,0,1}});effectiveSupport={M{{1,0,0},{0,1,0},{0,0,1}},add(wb.gripInRoot,mul(barrel.f,.12f))};}
  
  {char name[96]{};if(weaponTrimName(wb.weapon,name)){AcquireSRWLockExclusive(&weaponTrimLock);initWeaponTrims();effectiveSupport=weaponAlignments.supportPose(name,effectiveSupport);ReleaseSRWLockExclusive(&weaponTrimLock);}}
  effectiveSupport.p=mul(effectiveSupport.p,itemScale);
  static unsigned captureSeen=~0u;unsigned capture=supportCapture.load();if(capture!=captureSeen){if(capture!=~0u){supportCaptureReleased=false;supportHold.cancel();}captureSeen=capture;}if(capture!=~0u){
   if(capture!=wb.handle){supportCapture.store(~0u);supportCaptureReleased=false;}
   else{int freeHand=1-wb.hand;float squeeze=h.gripValue[freeHand];if(squeeze<.35f)supportCaptureReleased=true;
    if(squeeze>.65f&&supportCaptureReleased){V point=local(heldWeapon.b,sub(h.grip[freeHand].p,heldWeapon.p));char name[96]{};bool saved=false;
     if(length(sub(h.grip[freeHand].p,primaryAnchor))<1.5f*RFGRVR_HeadCam_WorldScale()&&weaponTrimName(wb.weapon,name)){AcquireSRWLockExclusive(&weaponTrimLock);initWeaponTrims();Pose captured{relative(heldWeapon.b,h.grip[freeHand].b),mul(point,1/itemScale)};saved=weaponAlignments.captureSupportPose(name,captured);effectiveSupport=captured;effectiveSupport.p=point;ReleaseSRWLockExclusive(&weaponTrimLock);supportHold=RFGRVRTwoHand{};}
     supportCapture.store(~0u);supportCaptureReleased=false;vrstatus::notify(saved?"Second-hand grip position AND orientation SAVED":"Grip capture failed: keep hand near weapon");
    }
   }
  }
  unsigned heldClass=word(pointer(wb.weapon,0x148),0x10);bool isCharge=heldClass==3,isMine=heldClass==4||nativePropCarry(player);
  supportForHud=effectiveSupport;if(heldClass==7){V span=sub(effectiveSupport.p,mainGripLocal);float distance=(std::clamp)(length(sub(h.grip[1-wb.hand].p,primaryAnchor)),.08f,(std::max)(.08f,length(span)));supportForHud.p=add(mainGripLocal,mul(unit(span),distance));}supportForHudReady=!isCharge&&!isMine;
  Pose offHand{};int other=1-wb.hand;
  RFGRVRWeaponPhysics::Reload::Visual reloadVisual{};bool reloadKnown=RFGRVRWeaponPhysics::Reload::readVisual(wb.handle,reloadVisual);bool magazineBusy=reloadKnown&&reloadVisual.grip;
  bool supportAttached=supportHold.update((uintptr_t)wb.weapon,wb.handle,!primaryPlacement.active&&!isCharge&&!isMine&&!magazineBusy&&!RFGRVRWeaponInput::carrying(),h.gripValue[other],.14f*RFGRVR_HeadCam_WorldScale(),heldWeapon,mainGripLocal,effectiveSupport,primaryAnchor,h.grip[other],heldWeapon,offHand,(heldClass==7||heldClass==8),!(namedProfile&&!strncmp(profileName,"edf_pistol",10)),heldClass==7);
  AcquireSRWLockExclusive(&recoilLock);heldWeapon=weaponWeight.apply((uintptr_t)wb.weapon,wb.handle,now,heldWeapon,mainGripLocal,vrweight::response(heldClass,namedProfile?profileName:nullptr),supportAttached||primaryPlacement.active||supportCapture.load()!=~0u||magazineBusy);ReleaseSRWLockExclusive(&recoilLock);
  Pose beforeRecoil=heldWeapon;bool recentShot=recoilShotHandle.load()==wb.handle&&now-recoilShotTick.load()<150;bool recoilBlocked=primaryPlacement.active||supportCapture.load()!=~0u||(reloadKnown&&(reloadVisual.removed||reloadVisual.grip));
  AcquireSRWLockExclusive(&recoilLock);weaponRecoil.observe((uintptr_t)wb.weapon,wb.handle,(int)word(wb.weapon,0x20c),recentShot,recoilBlocked,now,vrrecoil::profile(heldClass,namedProfile?profileName:nullptr),supportHold.active);
  if(!recoilBlocked){M barrel=compose(heldWeapon.b,relative(wb.rootInMuzzle,M{{1,0,0},{0,1,0},{0,0,1}}));if(weaponRecoil.roundObserved&&vrrecoil::profile(heldClass,namedProfile?profileName:nullptr).perRound)weaponBallistics.drop((uintptr_t)wb.weapon,wb.handle,weaponRecoil.ammoBefore,weaponRecoil.ammo,weaponRecoil.beforeShot(heldWeapon,mainGripLocal,barrel,RFGRVR_HeadCam_WorldScale()),now);heldWeapon=weaponRecoil.apply(heldWeapon,mainGripLocal,barrel,RFGRVR_HeadCam_WorldScale());}ReleaseSRWLockExclusive(&recoilLock);
  if(supportAttached){offHand=vrgrip::worldPose(heldWeapon,vrgrip::relativePose(beforeRecoil,offHand));
   M wrist=compose(offHand.b,gripAlignment[other]);V position=sub(offHand.p,world(wrist,gripCenterInWrist[other]));
   targets[other]={relative(root.b,wrist),local(root.b,sub(position,root.p))};
  }
  // Every held primary model hand uses the same authored weapon-local pose,
  // in single- and two-hand modes. Controller motion steers the item; it does
  // not independently rotate the skin away from that item's grip.
  if(!primaryPlacement.active&&valid(wb.primaryWristLocal.b)&&finite(wb.primaryWristLocal.p)){
   Pose primaryLocal=wb.primaryWristLocal;if(namedProfile){AcquireSRWLockExclusive(&weaponTrimLock);initWeaponTrims();primaryLocal=weaponAlignments.primaryPose(profileName,primaryLocal,gripAlignment[wb.hand],gripCenterInWrist[wb.hand]);ReleaseSRWLockExclusive(&weaponTrimLock);}
   primaryLocal=vrscope::scaledWrist(primaryLocal,gripCenterInWrist[wb.hand],itemScale);Pose wrist=vrgrip::worldPose(heldWeapon,primaryLocal);
   targets[wb.hand]={relative(root.b,wrist.b),local(root.b,sub(wrist.p,root.p))};
  }
  unblockedWeapon=heldWeapon;
  if(isCharge)chargeBlocking=RFGRVRWeaponPhysics::blockingForGrip(wb.weapon,wb.handle,h.grip[1],1);
  V blocked=primaryPlacement.active||word(pointer(wb.weapon,0x148),0x10)==3?V{}:RFGRVRWeaponPhysics::blockingOffset(wb.weapon,wb.handle,heldWeapon);
  heldWeapon.p=add(heldWeapon.p,blocked);targets[wb.hand].p=add(targets[wb.hand].p,local(root.b,blocked));
  if(supportHold.active)targets[other].p=add(targets[other].p,local(root.b,blocked));
  haveHeldWeapon=true;
 }else supportHold.update(0,0,false,h.gripValue[0],.14f,Pose{},V{},Pose{},V{},Pose{},heldWeapon,heldWeapon);
 depletedCharge=nullptr;depletedChargeHandle=~0u;
 // C4's charge and detonator have independent fixed hand frames. Resolve
 // the right-owned sibling before IK so placement drives both skin and item.
 if(wb.weapon&&word(pointer(wb.weapon,0x148),0x10)==3){
  void* item=pointer(player,0x34);void* seen[32]{};unsigned n=0;
  const Pose zero{M{{1,0,0},{0,1,0},{0,0,1}},V{}};
  while(item&&n<32){bool repeat=false;for(unsigned i=0;i<n;++i)if(seen[i]==item)repeat=true;if(repeat)break;seen[n++]=item;
   if(!memory(item,0xc0)||word(item,0x70)!=word(player,0x6c))break;
   void* attach=pointer(item,0x48);int tag=memory(attach,12)?(int)word(attach,4):-1,physical=tag;Pose offset=zero;
   if(tag>=(int)count){unsigned index=unsigned(tag)-count;void* tags=pointer(rig,0x3c);if(index<word(rig,0x30)&&memory((char*)tags+index*60,60)){physical=(int)word((char*)tags+index*60,52);memcpy(&offset,(char*)tags+index*60+4,48);}else physical=-1;}
   if(item!=wb.weapon&&*((unsigned char*)item+0x7e)==1&&physical>=0&&physical<(int)count&&descendant(physical,wrists[1],parents,count)&&valid(offset.b)&&finite(offset.p)){
    if(word(wb.weapon,0x20c)==0&&word(wb.weapon,0x210)==0){depletedChargeHandle=word(item,0x6c);depletedCharge=item;chargePlacement.cancel();chargeCapture.store(~0u);break;}
    Pose child{};if(itemTagPose(item,(int)word(attach,8),zero,child)){
     Pose nativeTag=vrgrip::worldPose(nativeFingers[physical],offset),tagInWrist=vrgrip::relativePose(nativeFingers[wrists[1]],nativeTag);
     Pose wristWorld{compose(root.b,targets[1].b),add(root.p,world(root.b,targets[1].p))},anchor=vrgrip::worldPose(wristWorld,tagInWrist);
     chargeWeapon=vrgrip::weaponAtGrip(anchor,child);chargeWeapon=trimmedCharge(chargeWeapon.b,child.p,anchor.p);
     Pose authored=vrgrip::weaponAtGrip(child,tagInWrist);
     AcquireSRWLockExclusive(&weaponTrimLock);initWeaponTrims();auto* entry=weaponAlignments.find(chargeProfile);if(entry&&entry->primaryCaptured)chargeWeapon=vrgrip::weaponAtGrip(h.grip[1],entry->primaryGrip);ReleaseSRWLockExclusive(&weaponTrimLock);
     static unsigned chargeSeen=~0u;unsigned request=chargeCapture.load();if(request!=chargeSeen){if(request==wb.handle){chargePlacement.begin((uintptr_t)item,word(item,0x6c),chargeWeapon);primaryCapture.store(~0u);primaryPlacement.cancel();}else chargePlacement.cancel();chargeSeen=request;}
     if(chargePlacement.active){if(chargePlacement.weapon!=(uintptr_t)item||chargePlacement.handle!=word(item,0x6c)){chargePlacement.cancel();chargeCapture.store(~0u);}else{chargeWeapon=chargePlacement.fixed;if(chargePlacement.update((uintptr_t)item,word(item,0x6c),h.gripValue[1])){AcquireSRWLockExclusive(&weaponTrimLock);bool saved=weaponAlignments.capturePrimary(chargeProfile,vrgrip::relativePose(chargeWeapon,h.grip[1]));ReleaseSRWLockExclusive(&weaponTrimLock);chargePlacement.cancel();chargeCapture.store(~0u);vrstatus::notify(saved?"C4 RIGHT charge pose SAVED":"C4 charge save failed");}}}
     if(!chargePlacement.active){AcquireSRWLockExclusive(&weaponTrimLock);Pose localHand=weaponAlignments.primaryPose(chargeProfile,authored,gripAlignment[1],gripCenterInWrist[1]);ReleaseSRWLockExclusive(&weaponTrimLock);Pose wrist=vrgrip::worldPose(chargeWeapon,localHand);targets[1]=vrgrip::relativePose(root,wrist);}
     else chargeBlocking={};
     chargeWeapon.p=add(chargeWeapon.p,chargeBlocking);targets[1].p=add(targets[1].p,local(root.b,chargeBlocking));chargeObject=item;break;
    }
   }item=pointer(item,0x38);
  }
  if(!chargeObject){chargePlacement.cancel();chargeCapture.store(~0u);}
 }else{chargePlacement.cancel();chargeCapture.store(~0u);}
 RFGRVRWeaponPhysics::Propane::Visual propaneVisual{};bool propaneCurrent=RFGRVRWeaponPhysics::Propane::readVisual(propaneVisual);if(propaneCurrent&&propaneVisual.heldMask)for(int side=0;side<2;++side)if(propaneVisual.heldMask&(1u<<side)){const Pose& palm=propaneVisual.hand[side];M wrist=compose(palm.b,gripAlignment[side]);V position=sub(palm.p,world(wrist,gripCenterInWrist[side]));targets[side]={relative(root.b,wrist),local(root.b,sub(position,root.p))};}
 if(vrtraining::active&&word(player,0x2f4)==0){
  for(int i=0;i<2;++i){M wristBasis=compose(h.grip[i].b,gripAlignment[i]);V wristWorld=sub(h.grip[i].p,world(wristBasis,gripCenterInWrist[i]));targets[i]={relative(root.b,wristBasis),local(root.b,sub(wristWorld,root.p))};}
  V shoulder=add(root.p,world(root.b,old[upper[1]].p)),hand=add(root.p,world(root.b,targets[1].p));
  armTraining.observe(h.sample,GetTickCount64(),shoulder,hand,h.grip[0].p,controllerBasis[1],h.physical[1],h.physical[0],root.b,RFGRVR_HeadCam_WorldScale());armTraining.packet(h.physical[1],Pose{controllerBasis[1],h.grip[1].p},RFGRVR_HeadCam_WorldScale());
  static ULONGLONG nextTrainingNotice=0;if(GetTickCount64()>=nextTrainingNotice){nextTrainingNotice=GetTickCount64()+2500;char note[180];sprintf_s(note,"%s: %u saved samples; arm %u/16, wrist %u/16; ENTER saves",armTraining.phase==1?"ARM":"WRIST",armTraining.rows,armTraining.complete(false),armTraining.complete(true));vrstatus::notify(armTraining.anchored?note:"Waiting for valid controller tracking; no samples yet");}
 }
 if(elbowPlayer!=player||elbowRig!=rig){elbowPlayer=player;elbowRig=rig;for(auto& estimator:elbowEstimator)estimator={};}
 Pose updated[128];memcpy(updated,old,count*48);bool changed[128]{};if(alignBodyYaw&&neutralWeight<=0)for(unsigned i=0;i<count;++i)if(descendant(i,armRest.body.spine,parents,count))changed[i]=true;if(fittedCrouch)for(unsigned i=0;i<count;++i)changed[i]=true;if(mountedVR&&seatedPose)for(unsigned i=0;i<count;++i)changed[i]=true;if(mountedVR&&!seatedPose){bool trackedBody[128]{};RFGRVR_FitBodyHeight(updated,count,parents,armRest.body,trackedBody,bodyOffset);for(unsigned i=0;i<count;++i)changed[i]=true;}for(int clavicle:clavicles)if(clavicle>=0)changed[clavicle]=true;
 for(int arm=0;arm<2;++arm){int a=upper[arm],b=elbows[arm],c=wrists[arm];if(!valid(old[a].b)||!valid(old[b].b)||!valid(old[c].b))return;V elbow{},wrist{};float reach=calibratedReachScale(h.calibratedSpan,length(sub(old[upper[0]].p,old[upper[1]].p)),length(sub(old[b].p,old[a].p)),length(sub(old[c].p,old[b].p)));
 V fittedElbow=add(old[a].p,mul(sub(old[b].p,old[a].p),reach)),fittedWrist=add(fittedElbow,mul(sub(old[c].p,old[b].p),reach));
 int outwardSide=old[a].p.x>=(old[upper[0]].p.x+old[upper[1]].p.x)*.5f?1:0;
 M controller=relative(root.b,controllerBasis[arm]);elbowEstimator[arm].profile=&elbowProfile;
 V pole=elbowEstimator[arm].update(outwardSide,old[a].p,targets[arm],neutralSeconds,&controller,length(sub(fittedElbow,old[a].p)),length(sub(fittedWrist,fittedElbow)),RFGRVR_HeadCam_WorldScale());
 if(!solveTracked(old[a].p,fittedElbow,fittedWrist,targets[arm].p,pole,elbow,wrist))return;
 // Preserve the solved triangle; no post-solve sideways elbow displacement.
 updated[a].b=rotateTo(old[a].b,sub(old[b].p,old[a].p),sub(elbow,old[a].p));updated[b]={rotateTo(old[b].b,sub(old[c].p,old[b].p),sub(wrist,elbow)),elbow};updated[c]={targets[arm].b,wrist};changed[a]=changed[b]=changed[c]=true;
 for(unsigned bone=0;bone<count;++bone){if((int)bone==a||(int)bone==b||(int)bone==c)continue;int ancestor=descendant(bone,c,parents,count)?c:descendant(bone,b,parents,count)?b:descendant(bone,a,parents,count)?a:-1;if(ancestor<0)continue;
 if(ancestor==a)updated[bone]=segmentHelper(old[a],old[b],old[bone],updated[a],updated[b],false);
 else if(ancestor==b)updated[bone]=cuffHelper(old[b],old[c],old[bone],updated[b],updated[c]);
 else {const Pose* source=old;
  // The native animation retains each equipped weapon's actual finger curl.
  // Sample relative to its native wrist, then carry that shape with VR IK.
  // This also previews the correct grip posture during either placement mode.
  if((wb.weapon||mountedVR)&&valid(nativeFingers[ancestor].b)&&valid(nativeFingers[bone].b)&&finite(nativeFingers[bone].p)&&length(sub(nativeFingers[bone].p,nativeFingers[ancestor].p))<.35f)source=nativeFingers;
  updated[bone].p=add(updated[ancestor].p,world(updated[ancestor].b,local(source[ancestor].b,sub(source[bone].p,source[ancestor].p))));updated[bone].b=compose(updated[ancestor].b,relative(source[ancestor].b,source[bone].b));}changed[bone]=true;}}
 // Free hands own their finger chain; held hands retain authored weapon postures.
 bool occupied[2]={false,false};if(propaneCurrent)for(unsigned side=0;side<2;++side)if(propaneVisual.heldMask&(1u<<side))occupied[side]=true;if(wb.weapon&&!(propaneCurrent&&(propaneVisual.heldMask||propaneVisual.editing)))occupied[wb.hand]=true;if(supportHold.active||supportCapture.load()==wb.handle)occupied[1-wb.hand]=true;if(chargeObject&&!(propaneCurrent&&(propaneVisual.heldMask||propaneVisual.editing)))occupied[1]=true;
 RFGRVRWeaponPhysics::Reload::Visual fingerReload{};if(wb.weapon&&RFGRVRWeaponPhysics::Reload::readVisual(wb.handle,fingerReload)&&fingerReload.grip)occupied[1-wb.hand]=true;
 static RFGRFingerReader fingerReader;RFGRHandFingers fingerData{};bool haveFingers=fingerReader.read(fingerData);
 struct FingerMap{void* rig=nullptr;unsigned count=0;int finger[128]{},side[128]{},index[2]{-1,-1},little[2]{-1,-1};bool thumb[128]{},tip[128]{},bindValid[128]{};Pose bindLocal[128]{};V bindPosition[128]{};};static FingerMap fingerMap;
 if(fingerMap.rig!=rig||fingerMap.count!=count){fingerMap={};fingerMap.rig=rig;fingerMap.count=count;for(unsigned b=0;b<count;++b){fingerMap.finger[b]=fingerMap.side[b]=-1;auto* entry=bones+b*36;const char* name=(const char*)(entry+(int)word(entry,0));if(!memory(name,12)||(name[0]!='l'&&name[0]!='r')||name[1]!='-')continue;bool thumb=!strncmp(name+2,"thumb",5);int finger=thumb?0:!strncmp(name+2,"finger",6)&&name[8]>='1'&&name[8]<='4'?name[8]-'0':-1;if(finger<0)continue;unsigned side=name[0]=='r';bool tip=thumb?name[8]=='1':name[9]=='1';fingerMap.side[b]=side;fingerMap.finger[b]=finger;fingerMap.thumb[b]=thumb;fingerMap.tip[b]=tip;int parent=parents[b];V bind{},parentBind{};memcpy(&bind,bones+b*36+4,12);if(parent>=0&&parent<(int)count)memcpy(&parentBind,bones+parent*36+4,12);V offset=sub(parentBind,bind);fingerMap.bindPosition[b]=mul(bind,-1);fingerMap.bindValid[b]=parent>=0&&parent<(int)count&&finite(offset)&&length(offset)<.25f;fingerMap.bindLocal[b]=RFGRVR_OpenFingerLocal(parentBind,bind);if(!tip&&finger==1)fingerMap.index[side]=b;if(!tip&&finger==4)fingerMap.little[side]=b;}}
 for(unsigned side=0;side<2;++side)if((!occupied[side]||(propaneCurrent&&(propaneVisual.heldMask&(1u<<side)))||(fingerReload.magazinePose&&int(side)==1-wb.hand))&&!mountedVR){int wrist=wrists[side];V across=updated[wrist].b.r;int index=fingerMap.index[side],little=fingerMap.little[side];if(index>=0&&little>=0){V axis=sub(fingerMap.bindPosition[index],fingerMap.bindPosition[little]);across=world(updated[wrist].b,unit(axis));}
 for(unsigned b=0;b<count;++b){if(fingerMap.side[b]!=(int)side)continue;int parent=parents[b];if(parent<0||parent>=(int)count)continue;unsigned finger=fingerMap.finger[b];bool magazineHand=fingerReload.magazinePose&&int(side)==1-wb.hand;float curl=magazineHand?fingerReload.fingerCurl[finger]:haveFingers&&(fingerData.valid&(1u<<side))?fingerData.curl[side][finger]:h.gripValue[side];Pose localPose=fingerMap.bindValid[b]?fingerMap.bindLocal[b]:vrgrip::relativePose(armRest.pose[parent],armRest.pose[b]);Pose current=vrgrip::worldPose(updated[parent],localPose);updated[b]=RFGRVR_FreeFinger(current,across,RFGRVR_FingerCurl(curl,finger),fingerMap.thumb[b],fingerMap.tip[b],side==1);changed[b]=true;}
 }

 for(unsigned bone=0;bone<count;++bone)if(changed[bone]){int mapped=map[bone+12];if(mapped<0||mapped>=(int)count||!finite(updated[bone].p)||!valid(updated[bone].b))return;}

 // Cancel the native diagonal/leaning root animation during upright VR movement.
 // This is a render-palette correction; physics and controller targets stay
 // untouched. All independent clothing rigs receive these named bones too.
 bool tracked[128]{};memcpy(tracked,changed,count*sizeof(bool));
 if(neutralWeight>0&&animationRoot>=0&&valid(old[animationRoot].b))for(unsigned i=0;i<count;++i)if(!changed[i]){
  int mapped=map[i+12];if(mapped<0||mapped>=(int)count||!finite(old[i].p)||!valid(old[i].b))continue;
  if(armRest.body.spine>=0&&descendant(i,armRest.body.spine,parents,count)){
   Pose target=RFGRVR_NeutralBone(armRest.solver[i],armRest.solver[animationRoot],1,neutralBasis);target.p.y+=bodyOffset;target=RFGRVR_LeanPose(target,leanPivot,lean,neutralBasis.r);updated[i]=RFGRVR_BlendPose(old[i],target,neutralWeight);
  changed[i]=true;}
  // Keep root, pelvis and every native leg/foot palette unchanged. Rotating
  // these around the neutral root lifts ground contacts while walking.
 }
 // Preserve the engine's complete walking/strafe leg chains. Do not rebuild
 // legs from a synthetic gait or mix cached foot targets across body meshes.
 // Standing legs use the calibrated neutral stance, not the native weapon
 // idle (which extends one leg). During crouch, walking, jumping and landing,
 // the complete native lower-body animation remains authoritative. Neither
 // branch writes the root, torso, head or eye-height goals.
 if(bodyState==0&&!mountedVR&&!seatedPose&&!crouchedStance&&!RFGRVR_HeadCam_LandingRecovery()&&!RFGRVR_HeadCam_ControllerMoving()&&animationRoot>=0){
  for(unsigned i=0;i<count;++i)if(descendant(i,armRest.body.thigh[0],parents,count)||descendant(i,armRest.body.thigh[1],parents,count)){
   int physical=map[i+12];V bind{};if(physical>=0&&physical<int(count)){memcpy(&bind,bones+physical*36+4,12);if(finite(bind)){updated[i]=RFGRVR_IdleLegBind(bind,neutralBasis);changed[i]=true;}}
  }
 }
 // Native locomotion owns pelvis, knees and crouch transition. The former
 // height fitter competed with those animations and could bend knees twice.
 ArmCommand next{};next.alignBodyYaw=alignBodyYaw;next.yawRoot=animationRoot;next.targetBodyYaw=targetBodyYaw;next.player=player;next.character=character;next.rootCharacter=character;next.instance=instance;next.rigIdentity=rig;next.modelIdentity=poses;next.skinIdentity=skin;next.handle=handle;next.count=count;next.eye[0]=armRest.body.eye[0];next.eye[1]=armRest.body.eye[1];next.root=root;next.tick=GetTickCount64();if(next.eye[0]>=0&&next.eye[1]>=0){const Pose* eyeReference=mountedVR&&seatedPose?seatedTurretScaffold.pose:(mountedVR||word(player,0x2f4)<=2)?updated:nativeFingers;next.nativeEye=mul(add(eyeReference[next.eye[0]].p,eyeReference[next.eye[1]].p),.5f);next.nativeEyeValid=finite(next.nativeEye);next.crouchVisual=fittedCrouch;next.referenceEye=mul(add(armRest.solver[next.eye[0]].p,armRest.solver[next.eye[1]].p),.5f);next.referenceEyeValid=finite(next.referenceEye);}memcpy(next.pose,updated,count*48);memcpy(next.changed,changed,count*sizeof(bool));
 if((neutralWeight>0||fittedCrouch||alignBodyYaw)&&animationRoot>=0)for(unsigned i=0;i<count;++i)if(changed[i]){bool trackedArm=false;
  for(int side=0;side<2;++side)if(descendant(i,upper[side],parents,count)||int(i)==clavicles[side])trackedArm=true;
  next.rootRelative[i]=!trackedArm;
 }
 for(int i=0;i<2;++i){next.physical[i]=wrists[i];next.tag[i]=(int)word(player,i?0xa70:0xa6c);next.desired[i]={compose(root.b,updated[wrists[i]].b),add(root.p,world(root.b,updated[wrists[i]].p))};}
 unsigned virtualCount=word(rig,0x30);next.total=count+(virtualCount<=128-count?virtualCount:0);for(int& side:next.side)side=-1;
 auto* tags=(unsigned char*)pointer(rig,0x3c);bool tagsReadable=virtualCount&&virtualCount<=128-count&&memory(tags,virtualCount*60);
 for(unsigned bone=0;bone<next.total;++bone){int physical=bone<count?(int)bone:tagsReadable?(int)word(tags+(bone-count)*60,52):-1;
 for(int side=0;side<2;++side)if(descendant(physical,wrists[side],parents,count)){next.side[bone]=side;break;}
 if(bone>=count&&next.side[bone]>=0&&physical>=0&&physical<(int)count){Pose offset{};memcpy(&offset,tags+(bone-count)*60+4,sizeof(offset));if(valid(offset.b)&&finite(offset.p)){next.pose[bone]={compose(updated[physical].b,offset.b),add(updated[physical].p,world(updated[physical].b,offset.p))};next.changed[bone]=true;}}}
 if(wb.weapon&&haveHeldWeapon){queueVisuals(next,wb.weapon,heldWeapon);if(itemScale!=1)for(unsigned i=1;i<next.visualCount;++i)next.visual[i].pose.p=add(heldWeapon.p,mul(sub(next.visual[i].pose.p,heldWeapon.p),itemScale));}
 {char scopeName[96]{};if(wb.weapon&&haveHeldWeapon)weaponTrimName(wb.weapon,scopeName);Pose muzzle{compose(heldWeapon.b,relative(wb.rootInMuzzle,M{{1,0,0},{0,1,0},{0,0,1}})),{}};muzzle.p=add(add(heldWeapon.p,world(heldWeapon.b,mul(wb.gripInRoot,itemScale))),world(muzzle.b,mul(wb.muzzleFromGrip,itemScale)));vrscope::publish(scopeName,heldWeapon,muzzle,RFGRVR_HeadCam_WorldScale(),vrscope::nativeVisualKind.load()==vrscope::index(scopeName)&&word(player,0xd58)==2,wb.weapon&&haveHeldWeapon&&!primaryPlacement.active&&supportCapture.load()==~0u&&!vrtraining::active.load());}

 if(chargeObject)queueVisuals(next,chargeObject,chargeWeapon);
 RFGRVRWeaponPhysics::Reload::Visual magazineVisual{};if(wb.weapon&&RFGRVRWeaponPhysics::Reload::readVisual(wb.handle,magazineVisual)){
  Pose well=magazineVisual.rocket?vrgrip::worldPose(heldWeapon,magazineVisual.wellLocal):Pose{};bool haveWell=magazineVisual.rocket;if(!magazineVisual.rocket)for(unsigned i=1;i<next.visualCount;++i)if(next.visual[i].object==magazineVisual.source.ptr&&word(next.visual[i].object,0x6c)==magazineVisual.source.handle){well=next.visual[i].pose;haveWell=true;break;}
  if(RFGRVRWeaponPhysics::Reload::validObject(magazineVisual.loaded))queueVisuals(next,magazineVisual.loaded.ptr,vrgrip::worldPose(heldWeapon,magazineVisual.wellLocal));
  for(unsigned i=0;i<magazineVisual.ghostStack.size();++i)if(i+1<magazineVisual.ghostCount&&haveWell&&RFGRVRWeaponPhysics::Reload::validObject(magazineVisual.ghostStack[i]))queueVisuals(next,magazineVisual.ghostStack[i].ptr,vrpod::at(well,i+1,magazineVisual.stackSpacing,magazineVisual.stackScale));
  Pose heldMagazine=magazineVisual.seating.active&&haveWell?magazineVisual.seating.pose(well,GetTickCount()):vrgrip::worldPose(h.grip[1-wb.hand],magazineVisual.handLocal);
  for(unsigned i=0;i<magazineVisual.heldStack.size();++i)if(i+1<magazineVisual.heldCount&&RFGRVRWeaponPhysics::Reload::validObject(magazineVisual.heldStack[i]))queueVisuals(next,magazineVisual.heldStack[i].ptr,vrpod::at(heldMagazine,i+1,magazineVisual.stackSpacing,magazineVisual.stackScale));
  if(haveWell&&RFGRVRWeaponPhysics::Reload::validObject(magazineVisual.ghost))queueVisuals(next,magazineVisual.ghost.ptr,well);
  if(RFGRVRWeaponPhysics::Reload::validObject(magazineVisual.held))queueVisuals(next,magazineVisual.held.ptr,magazineVisual.seating.active&&haveWell?magazineVisual.seating.pose(well,GetTickCount()):vrgrip::worldPose(h.grip[1-wb.hand],magazineVisual.handLocal));
 }

 // Dual-item tools attach their second held prop directly to the player.
 // Only wrist descendants qualify; holsters and unrelated attachments stay native.
 void* sibling=mountedVR?nullptr:pointer(player,0x34);void* visited[32]{};unsigned visitedCount=0;
 while(sibling&&visitedCount<32&&next.visualCount<32){bool seen=false;for(unsigned i=0;i<visitedCount;++i)if(visited[i]==sibling)seen=true;if(seen)break;visited[visitedCount++]=sibling;
  if(!memory(sibling,0xc0)||word(sibling,0x70)!=word(player,0x6c))break;
  bool queued=false;for(unsigned i=0;i<next.visualCount;++i)if(next.visual[i].object==sibling)queued=true;
  void* attach=pointer(sibling,0x48);int tag=memory(attach,12)?(int)word(attach,4):-1;unsigned char type=0;memcpy(&type,(char*)sibling+0x7e,1);
  if(!queued&&type==1&&tag>=0&&tag<(int)next.total&&next.side[tag]>=0&&next.changed[tag]){
   Pose anchor{compose(root.b,next.pose[tag].b),add(root.p,world(root.b,next.pose[tag].p))},grip{};const Pose zero{M{{1,0,0},{0,1,0},{0,0,1}},V{0,0,0}};
   if(itemTagPose(sibling,(int)word(attach,8),zero,grip)){M orientation=compose(anchor.b,relative(grip.b,zero.b));Pose item{orientation,sub(anchor.p,world(orientation,grip.p))};if(wb.weapon&&word(pointer(wb.weapon,0x148),0x10)==3&&next.side[tag]==1)item=trimmedCharge(orientation,grip.p,anchor.p);queueVisuals(next,sibling,item);}
  }
  sibling=pointer(sibling,0x38);
 }
 // Character clothing/armour use independent animation instances, not body
 // palette indices. Match named bones once per rig and publish one shared pose.
 RFGRReloadCue reloadCue{};if(wb.weapon&&RFGRVRWeaponPhysics::Reload::readVisual(wb.handle,magazineVisual)&&magazineVisual.empty){
  for(unsigned i=1;i<next.visualCount;++i)if(next.visual[i].object==magazineVisual.source.ptr){void* mesh=pointer(magazineVisual.source.ptr,0xa8);void* data=pointer(mesh,8);void* subs=pointer(data,0x38);V center{};float radius=.055f;unsigned subsCount=word(data,0x34);if(subsCount&&subsCount<=64&&memory(subs,0x2c)){V a{},b{},offset{};memcpy(&offset,(char*)subs+4,12);memcpy(&a,(char*)subs+0x10,12);memcpy(&b,(char*)subs+0x1c,12);if(finite(a)&&finite(b)&&length(sub(b,a))<.5f){center=add(offset,mul(add(a,b),.5f));radius=(std::max)(.03f,(std::min)(.10f,length(sub(b,a))*.45f));}}
   V location=add(next.visual[i].pose.p,world(next.visual[i].pose.b,center));V delta=mul(local(controllerBasis[wb.hand],sub(location,h.grip[wb.hand].p)),1/RFGRVR_HeadCam_WorldScale());V stage=add(h.physical[wb.hand].p,world(h.physical[wb.hand].b,delta));reloadCue.active=h.sample!=0;reloadCue.center[0]=stage.x;reloadCue.center[1]=stage.y;reloadCue.center[2]=-stage.z;reloadCue.radius=radius/RFGRVR_HeadCam_WorldScale();break;
  }
 }RFGRVR_PublishReloadCue(reloadCue);
 vrstatus::hold(supportHold.active);publishWeaponHud(next,wb,h,controllerBasis,supportForHudReady?&supportForHud:nullptr);publishWeaponPhysics(next,wb,h,controllerBasis,unblockedWeapon,chargeBlocking);
 if(poseState==9&&mountedVR)vrtankbodyframe::publish(player,character,word(player,0xac4),next.root);
 publishCommand(next);
 AcquireSRWLockExclusive(&rigLock);binding=wb;ReleaseSRWLockExclusive(&rigLock);playerHandle=word(player,0x6c);controlledPlayer=player;controlling=true;

 if(++updates==1||updates%240==0){char text[300];sprintf_s(text,"Controller arm targets queued: updates=%lu weapon=%p palm_errors=%.5f/%.5f support=%d ready=%d tag=%d squeeze=%.3f/%.3f",updates,wb.weapon,length(sub(add(next.desired[0].p,world(next.desired[0].b,gripCenterInWrist[0])),h.grip[0].p)),length(sub(add(next.desired[1].p,world(next.desired[1].b,gripCenterInWrist[1])),h.grip[1].p)),supportHold.active?1:0,wb.supportReady?1:0,wb.supportTag,h.gripValue[0],h.gripValue[1]);log(text);}
}




extern "C" bool RFGRVR_Arms_PhysicalCrouchBlend(){return physicalCrouchVisual.load();}
extern "C" bool RFGRVR_Arms_EyeReference(void* player,float out[3]){
 if(!player||!out||!controlling.load())return false;AcquireSRWLockShared(&commandLock);bool ok=command.player==player&&command.referenceEyeValid&&GetTickCount64()-command.tick<200;if(ok)memcpy(out,&command.referenceEye,12);ReleaseSRWLockShared(&commandLock);return ok;
}

static bool nativeAnimatedHead(void* player,vrarm::Pose* out,vrarm::V* localEye=nullptr){
 if(!out||!RFGRVR_HeadCam_IsLocalPlayer(player))return false;
 BatchMemory batch;void* character=pointer(player,0x32c);int handle=int(word(character,0));if(handle<0)return false;
 void* instance=base+0x35acbd0+(handle%356)*0x410;if(!playerPart(player,character,instance))return false;
 void* rig=pointer(instance,0x18);unsigned count=word(rig,0x24);auto* bones=(unsigned char*)pointer(rig,0x38);auto* poses=(Pose*)pointer(instance,4);
 if(!count||count>128||!memory(bones,count*36)||!memory(poses,count*48))return false;
 int head=-1,eyes[2]{-1,-1};for(unsigned i=0;i<count;++i){if(boneNamed(bones,i,"head"))head=i;if(boneNamed(bones,i,"l-eye"))eyes[0]=i;if(boneNamed(bones,i,"r-eye"))eyes[1]=i;}
 if(head<0||!valid(poses[head].b)||!finite(poses[head].p))return false;Pose root{};if(!renderRoot(player,character,root))return false;
 V point=poses[head].p;if(eyes[0]>=0&&eyes[1]>=0&&finite(poses[eyes[0]].p)&&finite(poses[eyes[1]].p))point=mul(add(poses[eyes[0]].p,poses[eyes[1]].p),.5f);
 if(localEye)*localEye=point;
 *out={compose(root.b,poses[head].b),add(root.p,world(root.b,point))};return valid(out->b)&&finite(out->p);
}
extern "C" bool RFGRVR_Arms_RagdollHead(void* player,vrarm::Pose* out){
 if(!word(player,0x33c)&&!(word(player,0x2f4)==10&&vrsettings::get().value[vrsettings::Vehicles]))return false;
 return nativeAnimatedHead(player,out);
}
extern "C" bool RFGRVR_Arms_NativeSeatHead(void* player,vrarm::Pose* out){
 if(word(player,0x2f4)!=8||word(player,0x33c))return false;
 return nativeAnimatedHead(player,out);
}
extern "C" bool RFGRVR_Arms_EyeLocal(void* player,float out[3]){
 vrmemory::Scope memoryScope;if(!player||!out)return false;
 if(word(player,0x2f4)==8){Pose native{};V eye{};if(!nativeAnimatedHead(player,&native,&eye))return false;memcpy(out,&eye,12);return true;}
 if(!controlling.load())return false;
 AcquireSRWLockShared(&commandLock);bool ok=command.player==player&&GetTickCount64()-command.tick<200;V cached=command.nativeEye;bool cachedValid=command.nativeEyeValid;bool visualCrouch=command.crouchVisual;bool alignYaw=command.alignBodyYaw;int yawRoot=command.yawRoot;float targetYaw=command.targetBodyYaw;
 void* instance=command.instance;void* modelIdentity=command.modelIdentity;unsigned count=command.count;int eyes[2]={command.eye[0],command.eye[1]};bool modified[2]={eyes[0]>=0&&eyes[0]<128?command.changed[eyes[0]]:true,eyes[1]>=0&&eyes[1]<128?command.changed[eyes[1]]:true};
 if(!cachedValid&&eyes[0]>=0&&eyes[1]>=0&&unsigned(eyes[0])<count&&unsigned(eyes[1])<count&&modified[0]&&modified[1]){cached=mul(add(command.pose[eyes[0]].p,command.pose[eyes[1]].p),.5f);cachedValid=finite(cached);}
 ReleaseSRWLockShared(&commandLock);if(!ok)return false;
 unsigned state=word(player,0x2f4),stance=word(player,0x2fc);bool animated=state<=2&&(state==1||state==2||stance==1||stance==4||RFGRVR_HeadCam_LandingRecovery());
 // Animation can advance between the controller command and eye rendering.
 // Read its current unhidden model palette; never read the shrunken eye mesh.
 if(!visualCrouch&&state<=2&&(animated||(!modified[0]&&!modified[1]))&&count&&count<=128&&eyes[0]>=0&&eyes[1]>=0&&unsigned(eyes[0])<count&&unsigned(eyes[1])<count&&pointer(instance,4)==modelIdentity&&memory(modelIdentity,count*48)){
  AcquireSRWLockShared(&skinBuildLock);auto* poses=(Pose*)modelIdentity;V eye=mul(add(poses[eyes[0]].p,poses[eyes[1]].p),.5f);if(alignYaw&&yawRoot>=0&&unsigned(yawRoot)<count){Pose point{M{{1,0,0},{0,1,0},{0,0,1}},eye};eye=RFGRVR_AlignBodyYaw(point,poses[yawRoot],targetYaw).p;}ReleaseSRWLockShared(&skinBuildLock);
  if(finite(eye)){memcpy(out,&eye,12);return true;}
 }
 if(!cachedValid||!finite(cached))return false;memcpy(out,&cached,12);return true;
}

extern "C" void RFGRVR_RequestVehicle(unsigned index){if(index<2){RFGRVRWeaponPhysics::vehicleRequestTick=GetTickCount();RFGRVRWeaponPhysics::vehicleRequests.fetch_or(1u<<index);}}

extern "C" void RFGRVR_AdjustWeapon(unsigned axis,bool rotate,int direction,bool secondary){WeaponBinding wb;AcquireSRWLockShared(&rigLock);wb=binding;ReleaseSRWLockShared(&rigLock);char name[96]{};if(!wb.weapon||word(wb.weapon,0x6c)!=wb.handle||!weaponTrimName(wb.weapon,name)){vrstatus::notify("Equip a weapon before adjusting");return;}AcquireSRWLockExclusive(&weaponTrimLock);initWeaponTrims();RFGRVRChargeTrim trim;bool c4=word(pointer(wb.weapon,0x148),0x10)==3;bool saved=c4?weaponAlignments.adjustPrimary(secondary?name:chargeProfile,axis,rotate,direction,trim):(secondary?weaponAlignments.adjust(name,axis,rotate,direction,trim,true):weaponAlignments.adjustPrimary(name,axis,rotate,direction,trim));ReleaseSRWLockExclusive(&weaponTrimLock);char text[192];sprintf_s(text,"%s %s %s rot %.0f %.0f %.0f / pos %.0f %.0f %.0f cm%s",name,secondary?"support hand":"primary hand",direction<0?"-":"+",trim.rotation[0],trim.rotation[1],trim.rotation[2],trim.position[0]*100,trim.position[1]*100,trim.position[2]*100,saved?"":" (save failed)");vrstatus::notify(text);}
extern "C" void RFGRVR_WeaponDirection(int sign){vrstatus::notify(sign<0?"Weapon direction: NEGATIVE (-)":"Weapon direction: POSITIVE (+)");}

static void captureDetonatorOrPrimary(){WeaponBinding wb;AcquireSRWLockShared(&rigLock);wb=binding;ReleaseSRWLockShared(&rigLock);if(!wb.weapon||word(wb.weapon,0x6c)!=wb.handle){vrstatus::notify("Equip a weapon before primary placement");return;}if(primaryCapture.load()==wb.handle){primaryCapture.store(~0u);vrstatus::notify("Primary placement cancelled");return;}supportCapture.store(~0u);primaryCapture.store(wb.handle);vrstatus::notify("Weapon FROZEN: release primary grip, place hand, then squeeze to save");}
extern "C" void RFGRVR_CapturePrimary(){WeaponBinding wb;AcquireSRWLockShared(&rigLock);wb=binding;ReleaseSRWLockShared(&rigLock);if(wb.weapon&&word(wb.weapon,0x6c)==wb.handle&&word(pointer(wb.weapon,0x148),0x10)==3){primaryCapture.store(~0u);supportCapture.store(~0u);chargeCapture.store(chargeCapture.load()==wb.handle?~0u:wb.handle);vrstatus::notify("C4 frozen: release RIGHT grip, place hand, squeeze to save");return;}chargeCapture.store(~0u);captureDetonatorOrPrimary();}
extern "C" void RFGRVR_CaptureSupport(){AcquireSRWLockShared(&turretGripLock);bool mounted=turretGripId!=~0u&&GetTickCount64()-turretGripTick<250;ReleaseSRWLockShared(&turretGripLock);if(mounted){vrstatus::notify("Turret hands use their native control grips");return;}WeaponBinding wb;AcquireSRWLockShared(&rigLock);wb=binding;ReleaseSRWLockShared(&rigLock);if(!wb.weapon||word(wb.weapon,0x6c)!=wb.handle){vrstatus::notify("Equip a weapon before grip capture");return;}if(word(pointer(wb.weapon,0x148),0x10)==4){vrstatus::notify("Mines have no second-hand grip");return;}if(word(pointer(wb.weapon,0x148),0x10)==3){chargeCapture.store(~0u);captureDetonatorOrPrimary();return;}primaryCapture.store(~0u);supportCapture.store(wb.handle);vrstatus::notify("Place free hand at new grip, then squeeze its grip button");}
extern "C" void RFGRVR_WeaponEditTarget(bool support){supportEditing.store(support,std::memory_order_relaxed);vrstatus::notify(support?"Editing SECOND HAND grip":"Editing PRIMARY HAND grip");}

extern "C" void RFGRVR_CaptureRocketReload(){RFGRVRWeaponPhysics::Target t{};RFGRVRWeaponPhysics::snapshot(t);if(!RFGRVRWeaponPhysics::Reload::rocket(t))return;RFGRVRWeaponPhysics::Reload::captureRocket=true;vrstatus::notify("Hold rocket with left trigger; release then squeeze LEFT grip to save insertion point");}



extern "C" bool RFGRVR_Arms_TurretHandleTarget(float target[3],float handle[3]){Hands h{};if(!target||!handle||!getHands(h)||!h.sample||!finite(h.grip[1].p))return false;AcquireSRWLockShared(&turretGripLock);bool ok=turretGripId!=~0u&&GetTickCount64()-turretGripTick<250;if(ok){Pose wrist=turretGripLocal[1];V palm=add(wrist.p,world(wrist.b,gripCenterInWrist[1]));memcpy(handle,&palm,12);memcpy(target,&h.grip[1].p,12);ok=finite(palm)&&length(palm)>.08f;}ReleaseSRWLockShared(&turretGripLock);return ok;}
extern "C" bool RFGRVR_Arms_TurretHand(float out[3],float aim[3]){Hands h{};if(!out||!aim||!getHands(h)||!h.sample||!valid(h.physicalAim[1].b))return false;memcpy(out,&h.physical[1].p,12);aim[0]=sinf(h.physicalRoomYaw);aim[1]=0;aim[2]=cosf(h.physicalRoomYaw);return finite(h.physical[1].p);}

extern "C" float RFGRVR_Arms_TurretLever(const float pivot[3]){Hands h{};if(!pivot||!getHands(h))return .55f;V p{};memcpy(&p,pivot,12);float scale=RFGRVR_HeadCam_WorldScale();float radius=length(sub(h.grip[1].p,p))/scale;return std::isfinite(radius)&&radius>=.15f&&radius<=1.5f?radius:.55f;}

extern "C" bool RFGRVR_Arms_TurretBody(float out[3]){Hands h{};if(!out||!getHands(h)||!h.physicalBodyValid)return false;memcpy(out,&h.physicalBody,12);return true;}

extern "C" float RFGRVR_Arms_TurretGripLever(unsigned id){AcquireSRWLockShared(&turretGripLock);float result=turretGripId==id&&GetTickCount64()-turretGripTick<250?length(turretGripLocal[1].p):0;ReleaseSRWLockShared(&turretGripLock);return result;}

extern "C" bool RFGRVR_Arms_TurretHandZero(float out[3]){AcquireSRWLockShared(&turretGripLock);bool ok=out&&turretHandZeroReady&&GetTickCount64()-turretGripTick<250;if(ok)memcpy(out,&turretHandZero,12);ReleaseSRWLockShared(&turretGripLock);return ok;}

extern "C" void RFGRVR_CaptureMagazineGrip(){WeaponBinding wb;AcquireSRWLockShared(&rigLock);wb=binding;ReleaseSRWLockShared(&rigLock);if(!wb.weapon||word(wb.weapon,0x6c)!=wb.handle){vrstatus::notify("Equip a magazine-fed weapon first");return;}RFGRVRWeaponPhysics::Reload::magazineCapture.store(wb.handle);vrstatus::notify("Magazine grip placement requested");}

extern "C" void RFGRVR_CaptureReloadGhost(){RFGRVRWeaponPhysics::Target t{};RFGRVRWeaponPhysics::snapshot(t);if(!t.weapon||!RFGRVRWeaponPhysics::Reload::rocket(t)){vrstatus::notify("Equip a rocket-loading weapon for ghost placement");return;}RFGRVRWeaponPhysics::Reload::wellCapture=t.handle;vrstatus::notify("Reload ghost placement requested; off-hand GRIP confirms");}
extern "C" void RFGRVR_ToggleVehicleMenu(){RFGRVRWeaponPhysics::toggleVehicleMenu();}
extern "C" bool RFGRVR_PollVehicleMenu(bool foreground){return RFGRVRWeaponPhysics::pollVehicleMenu(foreground);}



extern "C" bool RFGRVR_SaveVehicleCalibration();
extern "C" void RFGRVR_VehicleCalibrationKey(bool save){RFGRVRWeaponPhysics::VehicleCalibration::save=&RFGRVR_SaveVehicleCalibration;RFGRVRWeaponPhysics::VehicleCalibration::commands.fetch_or(save?2u:1u);}



extern "C" void RFGRVR_AudioListener(const float p[3],const float b[9]){RFGRVRWeaponPhysics::SpatialAudio::listener(p,b);}

extern "C" void RFGRVR_Arms_Cinematic(bool active){cinematicArms=active;}

static bool sledgeGripContext(const WeaponBinding& wb){return wb.weapon&&word(wb.weapon,0x6c)==wb.handle&&word(pointer(wb.weapon,0x148),0x10)==7;}
static void captureSledgeHand(const WeaponBinding& wb,int side){if(wb.hand==side)captureDetonatorOrPrimary();else RFGRVR_CaptureSupport();vrstatus::notify(side?"RIGHT hand placement: release RIGHT grip, place hand, squeeze to save":"LEFT hand placement: release LEFT grip, place hand, squeeze to save");}
static void captureZeroGrip(const WeaponBinding& wb){if(sledgeGripContext(wb))captureSledgeHand(wb,0);else RFGRVR_CaptureMagazineGrip();}
static void captureDecimalGrip(const WeaponBinding& wb){if(sledgeGripContext(wb))captureSledgeHand(wb,1);else RFGRVR_CaptureSupport();}

// Returns context/trim/scale ownership to the shared key router. No key is
// simultaneously allowed to edit a grip, move a scope, or start a vehicle tour.
extern "C" void RFGRVR_HeadCam_AdjustDlcEye(int,int);
extern "C" unsigned RFGRVR_WeaponSetupInput(bool){return 0;}

extern "C" void RFGRVR_Arms_BodyGeometryBegin(){vrworldview::draw=vrworldview::prepared;LocalBodyGeometry::begin();}
extern "C" void RFGRVR_Arms_BodyGeometryEnd(){LocalBodyGeometry::end();vrworldview::draw={};}


extern "C" bool RFGRVR_Arms_PistolLaser(vrarm::Pose* out){
 using namespace vrarm;WeaponBinding wb{};AcquireSRWLockShared(&rigLock);wb=binding;ReleaseSRWLockShared(&rigLock);Pose item{};char name[96]{};
 AcquireSRWLockShared(&drawnWeaponLock);auto drawn=drawnWeapon;ReleaseSRWLockShared(&drawnWeaponLock);if(!out||!wb.gripReady||!owned(wb.weapon)||!weaponTrimName(wb.weapon,name)||strcmp(name,"edf_pistol")||drawn.weapon!=wb.weapon||drawn.handle!=wb.handle||GetTickCount64()-drawn.tick>=200)return false;item=drawn.root;
 *out=pistolLaserPose(item,wb,RFGRVR_HeadCam_WorldScale());return valid(out->b)&&finite(out->p);
}

