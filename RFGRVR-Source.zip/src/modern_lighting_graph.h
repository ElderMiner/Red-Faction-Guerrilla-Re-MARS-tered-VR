#pragma once
#include "modern_histogram.h"
#include "modern_probe_projector.h"
#include "modern_reflections.h"
#include "modern_reflection_brdf.h"
#include "modern_sky.h"
#include "modern_cube_capture.h"
#include "modern_grid_gpu.h"
namespace moderngraph {
// Once-per-world-frame coordinator. Native adapters supply verified world-only
// HDR/depth/caster inputs. It never searches object registries, borrows UI
// surfaces, assumes a native mesh ABI, or blocks for GPU readback completion.
class Graph {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> device;Ptr<ID3D11DeviceContext> context;
 modernlocal::Atlas shadowAtlas;modernindirect::Projector projector;modernindirect::Grid grid;modernindirect::GPUGrid gridGpu;
 modernreflection::Filter reflections;modernreflection::BRDF brdf;modernsky::Lookup atmosphere;modernpolicy::Meter meter;modernpolicy::StereoExposure exposure;
 struct Packet {Ptr<ID3D11Buffer> histogram,probe;Ptr<ID3D11Query> query;bool pending=false,isProbe=false;uint64_t frame=0,revision=0;unsigned eye=0,x=0,y=0,z=0;modernlocal::V location{};float seconds=0;modernpolicy::Environment environment;};
 std::array<Packet,8> packets{};uint64_t scene=0,frame=~uint64_t(0),revision=0,reflectionKey=0,reflectionRevision=0;modernpolicy::Budget limits{};modernpolicy::Environment environment{};float seconds=0;unsigned probes=0,meterMask=0;bool reflected=false,skyUpdated=false;
 unsigned completedProbes=0,completedMeters=0,discarded=0;float exposureMix=0;modernlocal::V reflectionOrigin{};bool reflectionLocated=false;uint64_t reflectionFrame=0;
 Packet* available(){for(auto& packet:packets)if(!packet.pending)return &packet;return nullptr;}
 bool prepare(Packet& packet,bool probe){auto& buffer=probe?packet.probe:packet.histogram;if(!buffer){D3D11_BUFFER_DESC bd{};bd.ByteWidth=probe?sizeof(modernindirect::Probe):sizeof(modernpolicy::Histogram);bd.Usage=D3D11_USAGE_STAGING;bd.CPUAccessFlags=D3D11_CPU_ACCESS_READ;if(FAILED(device->CreateBuffer(&bd,nullptr,&buffer)))return false;}if(!packet.query){D3D11_QUERY_DESC q{};q.Query=D3D11_QUERY_EVENT;if(FAILED(device->CreateQuery(&q,&packet.query)))return false;}return true;}
 void queue(Packet& packet,ID3D11Buffer* source,bool probe,ID3D11DeviceContext* stream=nullptr){if(!stream)stream=context.Get();stream->CopyResource(probe?packet.probe.Get():packet.histogram.Get(),source);stream->End(packet.query.Get());packet.frame=frame;packet.revision=revision;packet.isProbe=probe;packet.pending=true;packet.seconds=seconds;packet.environment=environment;}
public:
 bool begin(ID3D11Device* d,ID3D11DeviceContext* c,uint64_t sceneId,uint64_t frameId,uint64_t geometryRevision,modernpolicy::Quality quality,float hour,float dt){
  if(!d||!c||!sceneId||c->GetType()!=D3D11_DEVICE_CONTEXT_IMMEDIATE||!std::isfinite(dt)||dt<0)return false;Ptr<ID3D11Device> cd;c->GetDevice(&cd);if(cd.Get()!=d)return false;
  if(device.Get()!=d||scene!=sceneId){*this={};device=d;context=c;scene=sceneId;}
  if(frame==frameId||(frame!=~uint64_t(0)&&frameId<frame))return false;if(revision!=geometryRevision)grid.clear();revision=geometryRevision;frame=frameId;limits=modernpolicy::budget(quality);environment=modernpolicy::environment(hour);seconds=dt;probes=meterMask=0;reflected=skyUpdated=false;shadowAtlas.begin(frameId,limits.shadowFaces);poll();if(exposure.ready())exposureMix=(std::min)(exposureMix+dt,1.f);gridGpu.update(c,grid);return true;
 }
 bool configureProbes(modernlocal::V origin,float spacing,unsigned side){return grid.configure(origin,spacing,side);}
 bool planProbe(modernlocal::V eye,modernlocal::V& position,bool& missing,const float* nativeClip=nullptr,const float* renderOrigin=nullptr){
  if(!std::isfinite(eye.x)||!std::isfinite(eye.y)||!std::isfinite(eye.z)||std::abs(eye.x)>1e7f||std::abs(eye.y)>1e7f||std::abs(eye.z)>1e7f)return false;
  constexpr float spacing=4;modernlocal::V origin{std::round(eye.x/spacing)*spacing-spacing,std::round(eye.y/spacing)*spacing-spacing,std::round(eye.z/spacing)*spacing-spacing};
  modernvisibility::Frustum view;float rowMajor[16];if(nativeClip){for(unsigned r=0;r<4;++r)for(unsigned c=0;c<4;++c)rowMajor[r*4+c]=nativeClip[c*4+r];view.set(rowMajor);}return grid.relocate(origin,spacing,3)&&grid.next(eye,position,missing,view.valid?&view:nullptr,renderOrigin);
 }
 bool probeCoordinate(modernlocal::V position,unsigned& x,unsigned& y,unsigned& z)const{return grid.coordinate(position,x,y,z);}
 bool needsReflection(modernlocal::V candidate,modernlocal::V eye)const{
  auto old=modernlocal::sub(reflectionOrigin,eye),next=modernlocal::sub(candidate,eye);
  return modernpolicy::updateReflection(reflectionLocated&&reflections.resource(),frame>=reflectionFrame?frame-reflectionFrame:0,modernlocal::dot(old,old),modernlocal::dot(next,next));
 }

 unsigned invalidate(modernlocal::V lo,modernlocal::V hi,uint64_t geometryRevision){revision=geometryRevision;return grid.invalidate(lo,hi);}
 void poll(){if(!context)return;for(auto& packet:packets){if(!packet.pending)continue;BOOL complete=FALSE;HRESULT ready=context->GetData(packet.query.Get(),&complete,sizeof(complete),D3D11_ASYNC_GETDATA_DONOTFLUSH);if(FAILED(ready)){packet.pending=false;++discarded;continue;}if(ready==S_FALSE||!complete)continue;if(packet.isProbe&&packet.revision!=revision){packet.pending=false;++discarded;continue;}
   auto* buffer=packet.isProbe?packet.probe.Get():packet.histogram.Get();D3D11_MAPPED_SUBRESOURCE data{};HRESULT mapped=context->Map(buffer,0,D3D11_MAP_READ,D3D11_MAP_FLAG_DO_NOT_WAIT,&data);if(mapped==DXGI_ERROR_WAS_STILL_DRAWING)continue;if(FAILED(mapped)){packet.pending=false;++discarded;continue;}
   if(packet.isProbe){modernindirect::Probe result;memcpy(&result,data.pData,sizeof(result));unsigned x=0,y=0,z=0;if(grid.coordinate(packet.location,x,y,z)&&grid.update(x,y,z,result,packet.revision))++completedProbes;else ++discarded;}
   else {modernpolicy::Histogram result;memcpy(result.data(),data.pData,sizeof(result));exposure.submit(packet.frame,packet.eye,result,packet.seconds,packet.environment);++completedMeters;}context->Unmap(buffer,0);packet.pending=false;
  }}
 int shadow(uint64_t key,const modernscene::Light& light,modernlocal::Atlas::Draw draw,void* casters){if(!device)return -1;return shadowAtlas.update(device.Get(),context.Get(),key,light,revision,limits.shadowResolution,draw,casters);}
 bool sky(const modernsky::Frame& sky){if(!device||skyUpdated)return false;if(!atmosphere.update(device.Get(),context.Get(),sky,limits.reflectionResolution))return false;skyUpdated=true;return true;}
 bool reflect(uint64_t captureKey,uint64_t lightingRevision,ID3D11ShaderResourceView* linearHDRCube){if(!device||!captureKey||reflected)return false;if(reflectionKey==captureKey&&reflectionRevision==lightingRevision&&reflections.resource()){reflected=true;return true;}if(!brdf.ensure(device.Get(),context.Get())||!reflections.filter(device.Get(),context.Get(),linearHDRCube,limits.reflectionResolution,limits.reflectionSamples))return false;reflectionKey=captureKey;reflectionRevision=lightingRevision;reflected=true;reflectionLocated=false;return true;}
 bool probe(unsigned x,unsigned y,unsigned z,ID3D11ShaderResourceView* linearHDRCube,ID3D11ShaderResourceView* worldDistanceCube){if(!device||probes>=limits.probeUpdates)return false;auto* packet=available();if(!packet||!prepare(*packet,true)||!projector.project(device.Get(),context.Get(),linearHDRCube,worldDistanceCube))return false;packet->x=x;packet->y=y;packet->z=z;packet->location=grid.position(x,y,z);queue(*packet,projector.buffer(),true);++probes;return true;}
 bool probeCapture(unsigned x,unsigned y,unsigned z,const moderncapture::Cube& capture,uint64_t id){modernlocal::V origin;uint64_t geometryRevision=0;if(!grid.contains(x,y,z)||!capture.descriptor(id,origin,geometryRevision)||geometryRevision!=revision)return false;auto expected=grid.position(x,y,z);auto difference=modernlocal::sub(origin,expected);if(modernlocal::dot(difference,difference)>.0001f)return false;return probe(x,y,z,capture.radiance(id),capture.distance(id));}
 bool reflectionCapture(uint64_t captureKey,uint64_t lightingRevision,const moderncapture::Cube& capture,uint64_t id){modernlocal::V origin;uint64_t geometryRevision=0;if(!capture.descriptor(id,origin,geometryRevision)||geometryRevision!=revision)return false;if(!reflect(captureKey,lightingRevision,capture.radiance(id)))return false;reflectionOrigin=origin;reflectionLocated=true;reflectionFrame=frame;return true;}
 bool meterEye(unsigned eye,ID3D11ShaderResourceView* preExposureWorld,float nativeRadianceScale,bool verifiedWorldOnly,ID3D11DeviceContext* stream=nullptr){if(!stream)stream=context.Get();if(!device||eye>1||!verifiedWorldOnly||(meterMask&(1u<<eye)))return false;auto* packet=available();if(!packet||!prepare(*packet,false)||!meter.measure(device.Get(),stream,preExposureWorld,nativeRadianceScale))return false;packet->eye=eye;queue(*packet,meter.buffer(),false,stream);meterMask|=1u<<eye;return true;}
 modernindirect::Grid::Result indirect(modernlocal::V world,modernlocal::V normal)const{return grid.query(world,normal);}
 ID3D11ShaderResourceView* materialProbes()const{return gridGpu.current(grid)?gridGpu.resource():nullptr;}
 bool materialGrid(modernlocal::V& origin,float& spacing,unsigned& side)const{return grid.layout(origin,spacing,side);}
 float sceneExposure()const{return exposure.exposure();}
 bool exposureReady()const{return exposure.ready();}
 float exposureBlend()const{return exposureMix;}
 ID3D11ShaderResourceView* skyResource()const{return atmosphere.resource();}
 bool reflectionPosition(modernlocal::V& position)const{position=reflectionOrigin;return reflectionLocated&&reflections.resource();}
 ID3D11ShaderResourceView* reflectionResource()const{return reflections.resource();}
 ID3D11ShaderResourceView* reflectionBRDFResource()const{return brdf.resource();}
 ID3D11ShaderResourceView* shadowResource()const{return shadowAtlas.resource();}
 struct Status {unsigned pending,probes,meters,discarded,remainingShadowFaces;bool sky,reflection;};
 Status status()const{unsigned count=0;for(auto& p:packets)count+=p.pending;return {count,completedProbes,completedMeters,discarded,shadowAtlas.remaining(),atmosphere.resource()!=nullptr,reflections.resource()!=nullptr};}
};
}

