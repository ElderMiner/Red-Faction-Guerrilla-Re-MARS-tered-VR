#pragma once
#include "vr_effect_geometry.h"
#include "vr_corona_depth.h"
namespace RFGRVREffectViewCache {
inline std::atomic<unsigned long long> prepareTicks{0},renderTicks{0};
struct Entry {void* object=nullptr;unsigned generation=0;};
inline Entry entries[4096]{};inline unsigned generation=0;inline std::atomic<int> eye{-1};
inline unsigned* frame=nullptr;inline std::mutex guard;
inline void select(int value){std::lock_guard<std::mutex> lock(guard);eye=value;if(value>=0&&++generation==0){for(auto& entry:entries)entry={};generation=1;}}
inline bool prepare(void* source,unsigned currentFrame){
 if(eye.load(std::memory_order_relaxed)!=1)return false;
 std::lock_guard<std::mutex> lock(guard);
 if(eye.load(std::memory_order_relaxed)!=1||!source)return false;
 unsigned slot=RFGRVREffectGeometry::slotFor(source);
 for(unsigned i=0;i<4096;++i){auto& entry=entries[(slot+i)&4095];
  if(entry.generation==generation){if(entry.object==source)return false;continue;}
  if(!RFGRVREffectGeometry::readable(source,0xe0))return false;
  entry={source,generation};bool changed=false;
  // These are view-query frame stamps, not simulation time or query handles.
  // Keep both handles intact and expire each stamp once for the second eye.
  for(unsigned offset:{0xd4u,0xdcu})if(RFGRVREffectGeometry::word(source,offset)==currentFrame){unsigned stale=currentFrame-1;memcpy((char*)source+offset,&stale,4);changed=true;}
  return changed;
 }return false;
}
using Render=void(__thiscall*)(void*,uintptr_t,uintptr_t,void*,uintptr_t);
inline Render render=nullptr;
inline void __fastcall onRender(void* self,void*,uintptr_t a,uintptr_t b,void* source,uintptr_t pass){vrmemory::Scope memoryScope;vrcoronadepth::Scope glow(pass==0&&vrcoronadepth::enabled.load(std::memory_order_relaxed));if(!RFGRVREffectGeometry::profiling){if(frame)prepare(source,*frame);render(self,a,b,source,pass);return;}LARGE_INTEGER start{},prepared{},done{};QueryPerformanceCounter(&start);if(frame)prepare(source,*frame);QueryPerformanceCounter(&prepared);render(self,a,b,source,pass);QueryPerformanceCounter(&done);prepareTicks+=prepared.QuadPart-start.QuadPart;renderTicks+=done.QuadPart-prepared.QuadPart;}
}
