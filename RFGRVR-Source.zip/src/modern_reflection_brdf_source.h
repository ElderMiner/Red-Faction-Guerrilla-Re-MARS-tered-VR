#pragma once
namespace modernreflection {inline constexpr char brdfSource[]=
R"BRDF(RWTexture2D<float2> response:register(u0);
float radicalInverse(uint bits){bits=(bits<<16)|(bits>>16);bits=((bits&0x55555555)<<1)|((bits&0xaaaaaaaa)>>1);bits=((bits&0x33333333)<<2)|((bits&0xcccccccc)>>2);bits=((bits&0x0f0f0f0f)<<4)|((bits&0xf0f0f0f0)>>4);bits=((bits&0x00ff00ff)<<8)|((bits&0xff00ff00)>>8);return bits*2.3283064365386963e-10;}
float masking(float cosine,float a2){return 2*cosine/max(cosine+sqrt(a2+(1-a2)*cosine*cosine),1e-6);}
[numthreads(8,8,1)]void main(uint3 id:SV_DispatchThreadID){uint width,height;response.GetDimensions(width,height);if(id.x>=width||id.y>=height)return;float nv=max((id.x+.5)/width,.001),roughness=(id.y+.5)/height,alpha=roughness*roughness,a2=alpha*alpha;float3 V=float3(sqrt(saturate(1-nv*nv)),0,nv);float2 sum=0;
 [loop]for(uint i=0;i<256;++i){float2 xi=float2((i+.5)/256,radicalInverse(i));float phi=6.28318530718*xi.x,nh=sqrt((1-xi.y)/max(1+(a2-1)*xi.y,1e-8)),sine=sqrt(saturate(1-nh*nh));float3 H=float3(cos(phi)*sine,sin(phi)*sine,nh),L=normalize(2*dot(V,H)*H-V);float nl=saturate(L.z),vh=saturate(dot(V,H));if(nl<=0)continue;float visibility=masking(nv,a2)*masking(nl,a2)*vh/max(nh*nv,1e-6);float fresnel=pow(1-vh,5);sum+=float2(1-fresnel,fresnel)*visibility;
 }response[id.xy]=max(sum/256,0);
}
)BRDF";}
