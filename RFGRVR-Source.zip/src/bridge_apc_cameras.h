#pragma once
#include "apc_camera_state.h"
#include "weapon_hud_pose.h"
#include "vr_apc_display_format.h"
struct RFGRAPCDisplay {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 RFGRAPCChannel channel;RFGRAPCCameras state{};bool active=false;int64_t format=0;uint64_t handle=0;unsigned epoch=0;
 Ptr<ID3D11Texture2D> shared;Ptr<IDXGIKeyedMutex> mutex;XrSwapchain swapchain=XR_NULL_HANDLE;
 std::vector<XrSwapchainImageD3D11KHR> images;XrCompositionLayerQuad quads[5]{};bool visible[5]{};
 bool read(DWORD pid){active=channel.read(pid,state);return active;}
 static XrPosef pose(const vrarm::Pose& p){RFGRPose identity{},out{};identity.active=1;identity.validFlags=3;identity.orientation[3]=1;RFGRHudAnchor a;a.hand=0;a.local=p;RFGRVR_HudPose(identity,a,out);XrPosef result{};memcpy(&result.position,out.position,12);memcpy(&result.orientation,out.orientation,16);return result;}
 bool init(ID3D11Device* d,XrSession session,PFN_xrCreateSwapchain create,PFN_xrEnumerateSwapchainImages enumerate){
 if(!state.texture||!format)return false;if(state.texture!=handle||state.epoch!=epoch){shared.Reset();mutex.Reset();handle=0;if(FAILED(d->OpenSharedResource((HANDLE)(uintptr_t)state.texture,__uuidof(ID3D11Texture2D),(void**)shared.GetAddressOf()))||FAILED(shared.As(&mutex)))return false;handle=state.texture;epoch=state.epoch;}
 if(swapchain)return !images.empty();XrSwapchainCreateInfo c{XR_TYPE_SWAPCHAIN_CREATE_INFO};c.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT|XR_SWAPCHAIN_USAGE_SAMPLED_BIT;c.format=format;c.sampleCount=c.faceCount=c.arraySize=c.mipCount=1;c.width=1024;c.height=768;if(XR_FAILED(create(session,&c,&swapchain)))return false;uint32_t n=0;if(XR_FAILED(enumerate(swapchain,0,&n,nullptr))||!n)return false;images.resize(n);for(auto& image:images)image.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;return XR_SUCCEEDED(enumerate(swapchain,n,&n,(XrSwapchainImageBaseHeader*)images.data()));
 }
 void frame(ID3D11Device* d,ID3D11DeviceContext* context,XrSession session,XrSpace stage,PFN_xrCreateSwapchain create,PFN_xrEnumerateSwapchainImages enumerate,PFN_xrAcquireSwapchainImage acquire,PFN_xrWaitSwapchainImage wait,PFN_xrReleaseSwapchainImage release){
 memset(visible,0,sizeof(visible));if(!active||(state.active&4)||!(state.active&2)||!state.valid||!init(d,session,create,enumerate)||mutex->AcquireSync(0,0)!=S_OK)return;
 uint32_t ix=0;XrSwapchainImageAcquireInfo a{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};bool copied=false;
 if(XR_SUCCEEDED(acquire(swapchain,&a,&ix))){XrSwapchainImageWaitInfo w{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};w.timeout=XR_INFINITE_DURATION;if(wait(swapchain,&w)==XR_SUCCESS&&ix<images.size()){context->OMSetRenderTargets(0,nullptr,nullptr);context->CopyResource(images[ix].texture,shared.Get());context->Flush();copied=true;}XrSwapchainImageReleaseInfo r{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};release(swapchain,&r);}mutex->ReleaseSync(0);if(!copied)return;
 using namespace vrarm;for(unsigned i=0;i<((state.active&8)?5u:4u);++i){if(!(state.valid&(1u<<i))||GetTickCount()-state.feedTick[i]>1500)continue;Pose p=state.screens;V offset=i==1?V{0,.47f,0}:i==2?V{.31f,.47f,0}:i==3?V{-.31f,.47f,0}:V{};p.p=add(p.p,world(p.b,offset));auto& q=quads[i];q={XR_TYPE_COMPOSITION_LAYER_QUAD};q.space=stage;q.eyeVisibility=XR_EYE_VISIBILITY_BOTH;q.pose=pose(p);q.size=i==0?XrExtent2Df{.9f,.675f}:XrExtent2Df{.29f,.2175f};q.subImage.swapchain=swapchain;q.subImage.imageRect.offset={int(i%2)*512,int(i/2)*384};q.subImage.imageRect.extent={512,384};visible[i]=true;}
 }
 void close(PFN_xrDestroySwapchain destroy){if(swapchain)destroy(swapchain);swapchain=XR_NULL_HANDLE;images.clear();mutex.Reset();shared.Reset();}
};
