#pragma once
#include <d3d11.h>
#include "modern_geometry_capture.h"
#include "modern_material_bindings.h"
#include <wrl/client.h>
#include <vector>
#include <cstdio>
#include <cstdint>
#include <algorithm>
#include <atomic>
#include <mutex>
#include <intrin.h>
// One paired-scene diagnostic. Copies sparse color samples into unbound GPU
// atlases; does not replace shaders, draw calls, targets, or depth state.
namespace RFGRVRPixelProbe {
using Microsoft::WRL::ComPtr;
inline constexpr unsigned sampleCount=16,atlasWidth=1024,atlasHeight=256,maxEvents=60000;
inline constexpr float points[sampleCount][2]={{.125f,.125f},{.375f,.125f},{.625f,.125f},{.875f,.125f},{.125f,.375f},{.375f,.375f},{.625f,.375f},{.875f,.375f},{.125f,.625f},{.375f,.625f},{.625f,.625f},{.875f,.625f},{.125f,.875f},{.375f,.875f},{.625f,.875f},{.875f,.875f}};
struct Source {ComPtr<ID3D11Texture2D> texture,atlas;unsigned sub=0,width=0,height=0,format=0,bpp=0,entries=0;};
inline constexpr unsigned srvSlots=D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT;
struct Input {ComPtr<ID3D11ShaderResourceView> view;ComPtr<ID3D11Resource> resource;unsigned mip=0,slice=0;};
inline std::vector<Input> inputs;
inline void registerInput(ID3D11ShaderResourceView* view){if(!view)return;for(const auto& i:inputs)if(i.view.Get()==view)return;Input i{};i.view=view;view->GetResource(i.resource.GetAddressOf());D3D11_SHADER_RESOURCE_VIEW_DESC d{};view->GetDesc(&d);if(d.ViewDimension==D3D11_SRV_DIMENSION_TEXTURE2D)i.mip=d.Texture2D.MostDetailedMip;else if(d.ViewDimension==D3D11_SRV_DIMENSION_TEXTURE2DARRAY){i.mip=d.Texture2DArray.MostDetailedMip;i.slice=d.Texture2DArray.FirstArraySlice;}inputs.push_back(std::move(i));}
struct Event {uintptr_t context;unsigned contextType;unsigned sequence,eye,kind,count,instances,start,base,target,entry,slot;uintptr_t vs,ps,depth,blend,ib,vb;unsigned stencil,stride,offset,indexOffset;uintptr_t predicate,dsv;unsigned predicateValue;uintptr_t srv[srvSlots];};
inline std::vector<Source> sources;inline std::vector<Event> events;
inline ComPtr<ID3D11DeviceContext> context;inline ComPtr<ID3D11Device> device;
inline bool finishing=false;inline std::atomic<bool> active{false};inline std::atomic<unsigned> eye{0};inline unsigned sequence=0,dropped=0,unsupported=0;inline std::recursive_mutex guard;
struct Note {unsigned kind,eye,value,thread;uintptr_t context,list;void* frames[12];unsigned count;};inline std::vector<Note> notes;
inline void note(unsigned kind,ID3D11DeviceContext* c,void* list,unsigned value){if(!active)return;std::lock_guard<std::recursive_mutex> lock(guard);if(!active||notes.size()>=256)return;Note n{};n.kind=kind;n.eye=eye;n.context=(uintptr_t)c;n.list=(uintptr_t)list;n.value=value;n.thread=GetCurrentThreadId();n.count=RtlCaptureStackBackTrace(1,12,n.frames,nullptr);// Optimized engine workers omit frame pointers; supplement the unwind with
// bounded stack candidates that point immediately after executable CALLs.
 auto* module=(unsigned char*)GetModuleHandleW(nullptr);
 auto* dos=(IMAGE_DOS_HEADER*)module;auto* nt=(IMAGE_NT_HEADERS*)(module+dos->e_lfanew);
 const uintptr_t low=(uintptr_t)module+nt->OptionalHeader.BaseOfCode,high=low+nt->OptionalHeader.SizeOfCode;
 auto* stack=(uintptr_t*)_AddressOfReturnAddress();MEMORY_BASIC_INFORMATION region{};
 if(VirtualQuery(stack,&region,sizeof(region))&&region.State==MEM_COMMIT&&!(region.Protect&(PAGE_NOACCESS|PAGE_GUARD))){
  const size_t words=(std::min<size_t>)(size_t(256),((uintptr_t)region.BaseAddress+region.RegionSize-(uintptr_t)stack)/sizeof(uintptr_t));
  for(size_t i=0;i<words&&n.count<12;++i){uintptr_t candidate=stack[i];if(candidate<low+8||candidate>=high)continue;
   auto* pc=(unsigned char*)candidate;
   // Direct E8 and register/memory FF call forms, treated as candidates only.
   if(pc[-5]!=0xe8&&!(pc[-2]==0xff&&(pc[-1]&0x38)==0x10)&&!(pc[-3]==0xff&&(pc[-2]&0x38)==0x10))continue;
   bool duplicate=false;for(unsigned j=0;j<n.count;++j)if((uintptr_t)n.frames[j]==candidate)duplicate=true;
   if(!duplicate)n.frames[n.count++]=(void*)candidate;
  }
 }
 notes.push_back(n);}
inline void instancedSite(ID3D11DeviceContext* c,unsigned count,unsigned kind=420){
 if(!active)return;
 std::lock_guard<std::recursive_mutex> lock(guard);if(!active)return;
 ComPtr<ID3D11PixelShader> shader;c->PSGetShader(shader.GetAddressOf(),nullptr,nullptr);
 // One call site per shader per eye, only during the bounded capture.
 for(const auto& n:notes)if(n.kind==kind&&n.eye==eye&&n.context==(uintptr_t)c&&n.list==(uintptr_t)shader.Get())return;
 note(kind,c,shader.Get(),count);
}
inline unsigned pixelBytes(DXGI_FORMAT f){switch(f){
 case DXGI_FORMAT_R32G32B32A32_FLOAT:case DXGI_FORMAT_R32G32B32A32_TYPELESS:return 16;
 case DXGI_FORMAT_R16G16B16A16_FLOAT:case DXGI_FORMAT_R16G16B16A16_UNORM:case DXGI_FORMAT_R16G16B16A16_TYPELESS:case DXGI_FORMAT_R32G32_FLOAT:return 8;
 case DXGI_FORMAT_R8G8B8A8_TYPELESS:case DXGI_FORMAT_R8G8B8A8_UNORM:case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB:case DXGI_FORMAT_B8G8R8A8_TYPELESS:case DXGI_FORMAT_B8G8R8A8_UNORM:case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB:case DXGI_FORMAT_R10G10B10A2_UNORM:case DXGI_FORMAT_R11G11B10_FLOAT:case DXGI_FORMAT_R16G16_FLOAT:case DXGI_FORMAT_R16G16_UNORM:case DXGI_FORMAT_R32_FLOAT:case DXGI_FORMAT_R32_TYPELESS:return 4;
 case DXGI_FORMAT_R16_FLOAT:case DXGI_FORMAT_R16_UNORM:case DXGI_FORMAT_R8G8_UNORM:return 2;
 case DXGI_FORMAT_R8_UNORM:return 1;default:return 0;}}
inline bool begin(ID3D11DeviceContext* c){std::lock_guard<std::recursive_mutex> lock(guard);if(active||finishing||!c)return false;moderngeometrycapture::reset();notes.clear();sources.clear();inputs.clear();events.clear();events.reserve(maxEvents);context=c;c->GetDevice(device.ReleaseAndGetAddressOf());eye=sequence=dropped=unsupported=0;active=true;return true;}
inline int sourceFor(ID3D11RenderTargetView* view){
 ComPtr<ID3D11Resource> resource;view->GetResource(&resource);ComPtr<ID3D11Texture2D> texture;if(FAILED(resource.As(&texture))){++unsupported;return -1;}
 D3D11_TEXTURE2D_DESC d{};texture->GetDesc(&d);D3D11_RENDER_TARGET_VIEW_DESC v{};view->GetDesc(&v);
 unsigned mip=0,slice=0;
 if(v.ViewDimension==D3D11_RTV_DIMENSION_TEXTURE2D)mip=v.Texture2D.MipSlice;
 else if(v.ViewDimension==D3D11_RTV_DIMENSION_TEXTURE2DARRAY&&v.Texture2DArray.ArraySize==1){mip=v.Texture2DArray.MipSlice;slice=v.Texture2DArray.FirstArraySlice;}else{++unsupported;return -1;}
 if(d.SampleDesc.Count!=1||!pixelBytes(v.Format)||mip>=d.MipLevels){++unsupported;return -1;}
 const unsigned sub=D3D11CalcSubresource(mip,slice,d.MipLevels);
 for(unsigned i=0;i<sources.size();++i)if(sources[i].texture.Get()==texture.Get()&&sources[i].sub==sub)return int(i);
 if(sources.size()>=64){++dropped;return -1;}
 Source s{};s.texture=texture;s.sub=sub;s.width=(std::max)(1u,d.Width>>mip);s.height=(std::max)(1u,d.Height>>mip);s.format=v.Format;s.bpp=pixelBytes(v.Format);
 d.Width=atlasWidth;d.Height=atlasHeight;d.MipLevels=d.ArraySize=1;d.SampleDesc.Count=1;d.SampleDesc.Quality=0;d.BindFlags=d.MiscFlags=d.CPUAccessFlags=0;d.Usage=D3D11_USAGE_DEFAULT;
 if(FAILED(device->CreateTexture2D(&d,nullptr,&s.atlas))){++unsupported;return -1;}
 sources.push_back(std::move(s));return int(sources.size()-1);
}
inline void record(ID3D11DeviceContext* c,unsigned kind,unsigned count,unsigned instances=0,unsigned start=0,unsigned base=0,ID3D11RenderTargetView* cleared=nullptr,bool deferred=false){
 if(!active)return;
 std::lock_guard<std::recursive_mutex> lock(guard);if(!active||(!deferred&&c!=context.Get()))return;
 if(events.size()+8>=maxEvents){++dropped;return;}
 const unsigned seq=++sequence;ID3D11RenderTargetView* targets[8]{};ComPtr<ID3D11DepthStencilView> dsv;c->OMGetRenderTargets(8,targets,&dsv);
 if(cleared){for(auto*& t:targets){if(t)t->Release();t=nullptr;}targets[0]=cleared;cleared->AddRef();}
 Event metadata{};metadata.context=(uintptr_t)c;metadata.contextType=c->GetType();metadata.sequence=seq;metadata.eye=eye;metadata.kind=kind;metadata.count=count;metadata.instances=instances;metadata.start=start;metadata.base=base;metadata.dsv=(uintptr_t)dsv.Get();ComPtr<ID3D11Predicate> predicate;BOOL value=FALSE;c->GetPredication(&predicate,&value);metadata.predicate=(uintptr_t)predicate.Get();metadata.predicateValue=value;
 ComPtr<ID3D11VertexShader> vs;ComPtr<ID3D11PixelShader> ps;ComPtr<ID3D11DepthStencilState> depth;ComPtr<ID3D11BlendState> blend;ComPtr<ID3D11Buffer> ib,vb;
 c->VSGetShader(&vs,nullptr,nullptr);c->PSGetShader(&ps,nullptr,nullptr);c->OMGetDepthStencilState(&depth,&metadata.stencil);c->OMGetBlendState(&blend,nullptr,nullptr);DXGI_FORMAT indexFormat{};
 c->IAGetIndexBuffer(&ib,&indexFormat,&metadata.indexOffset);c->IAGetVertexBuffers(0,1,&vb,&metadata.stride,&metadata.offset);
 if(eye==0&&(kind==2||kind==4)&&modernmaterial::tagged(ps.Get()))moderngeometrycapture::record(c,seq,count,start,base,instances);metadata.vs=(uintptr_t)vs.Get();metadata.ps=(uintptr_t)ps.Get();metadata.depth=(uintptr_t)depth.Get();metadata.blend=(uintptr_t)blend.Get();metadata.ib=(uintptr_t)ib.Get();metadata.vb=(uintptr_t)vb.Get();
 ID3D11ShaderResourceView* srvs[srvSlots]{};c->PSGetShaderResources(0,srvSlots,srvs);for(unsigned j=0;j<srvSlots;++j){metadata.srv[j]=(uintptr_t)srvs[j];registerInput(srvs[j]);if(srvs[j])srvs[j]->Release();}
 const size_t before=events.size();
 for(unsigned slot=0;slot<8;++slot){auto* view=targets[slot];if(!view)continue;const int index=sourceFor(view);view->Release();if(index<0)continue;auto& source=sources[index];
  if((source.entries+1)*sampleCount>atlasWidth*atlasHeight){++dropped;continue;}
  Event e=metadata;e.target=index;e.entry=source.entries++;e.slot=slot;events.push_back(e);
  for(unsigned p=0;p<sampleCount;++p){const unsigned x=(std::min)(source.width-1,unsigned(points[p][0]*source.width)),y=(std::min)(source.height-1,unsigned(points[p][1]*source.height));const D3D11_BOX box{x,y,0,x+1,y+1,1};const unsigned pixel=e.entry*sampleCount+p;
   c->CopySubresourceRegion(source.atlas.Get(),0,pixel%atlasWidth,pixel/atlasWidth,0,source.texture.Get(),source.sub,&box);
  }
 }
 if(events.size()==before){metadata.target=~0u;events.push_back(metadata);}
}
inline bool finish(const char* prefix){
 std::unique_lock<std::recursive_mutex> lock(guard);if(!active)return false;active=false;finishing=true;lock.unlock();bool ok=true;char path[MAX_PATH]{};FILE* f=nullptr;
 sprintf_s(path,"%s-events.csv",prefix);if(fopen_s(&f,path,"w")||!f)ok=false;
 if(f){fputs("context,context_type,sequence,eye,kind,count,instances,start,base,target,entry,slot,vs,ps,depth,blend,ib,vb,stencil,stride,offset,index_offset,predicate,predicate_value,dsv",f);for(unsigned i=0;i<srvSlots;++i)fprintf(f,",srv%u",i);fputc('\n',f);for(const auto& e:events){fprintf(f,"%p,%u,",(void*)e.context,e.contextType);fprintf(f,"%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%p,%p,%p,%p,%p,%p,%u,%u,%u,%u",e.sequence,e.eye,e.kind,e.count,e.instances,e.start,e.base,e.target,e.entry,e.slot,(void*)e.vs,(void*)e.ps,(void*)e.depth,(void*)e.blend,(void*)e.ib,(void*)e.vb,e.stencil,e.stride,e.offset,e.indexOffset);fprintf(f,",%p,%u,%p",(void*)e.predicate,e.predicateValue,(void*)e.dsv);for(auto s:e.srv)fprintf(f,",%p",(void*)s);fputc('\n',f);}fclose(f);}
 for(unsigned i=0;i<sources.size();++i){auto& s=sources[i];D3D11_TEXTURE2D_DESC d{};s.atlas->GetDesc(&d);d.Usage=D3D11_USAGE_STAGING;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> staging;
  if(FAILED(device->CreateTexture2D(&d,nullptr,&staging))){ok=false;continue;}context->CopyResource(staging.Get(),s.atlas.Get());D3D11_MAPPED_SUBRESOURCE map{};if(FAILED(context->Map(staging.Get(),0,D3D11_MAP_READ,0,&map))){ok=false;continue;}
  sprintf_s(path,"%s-target-%u.bin",prefix,i);f=nullptr;if(!fopen_s(&f,path,"wb")&&f){unsigned left=s.entries*sampleCount;for(unsigned row=0;left;++row){unsigned n=(std::min)(left,atlasWidth);if(fwrite((char*)map.pData+row*map.RowPitch,s.bpp,n,f)!=n)ok=false;left-=n;}fclose(f);}else ok=false;context->Unmap(staging.Get(),0);
 }
 sprintf_s(path,"%s-targets.csv",prefix);f=nullptr;if(!fopen_s(&f,path,"w")&&f){fputs("target,resource,subresource,width,height,format,bytes_per_pixel,entries,samples\n",f);for(unsigned i=0;i<sources.size();++i){auto& s=sources[i];fprintf(f,"%u,%p,%u,%u,%u,%u,%u,%u,%u\n",i,s.texture.Get(),s.sub,s.width,s.height,s.format,s.bpp,s.entries,sampleCount);}fclose(f);}else ok=false;
 sprintf_s(path,"%s-inputs.csv",prefix);f=nullptr;if(!fopen_s(&f,path,"w")&&f){fputs("view,resource,mip,slice\n",f);for(const auto& i:inputs)fprintf(f,"%p,%p,%u,%u\n",i.view.Get(),i.resource.Get(),i.mip,i.slice);fclose(f);}else ok=false;
 sprintf_s(path,"%s-status.txt",prefix);f=nullptr;if(!fopen_s(&f,path,"w")&&f){fprintf(f,"events=%zu targets=%zu dropped=%u unsupported=%u success=%u\n",events.size(),sources.size(),dropped,unsupported,ok?1:0);fclose(f);}else ok=false;
 sprintf_s(path,"%s-notes.csv",prefix);f=nullptr;if(!fopen_s(&f,path,"w")&&f){fputs("kind,eye,context,list,value,thread,frames\n",f);for(const auto& n:notes){fprintf(f,"%u,%u,%p,%p,%u,%u,",n.kind,n.eye,(void*)n.context,(void*)n.list,n.value,n.thread);for(unsigned i=0;i<n.count;++i){HMODULE module=nullptr;if(GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCSTR)n.frames[i],&module)){char name[MAX_PATH]{};GetModuleFileNameA(module,name,MAX_PATH);auto* slash=strrchr(name,92);fprintf(f,"%s+%p;",slash?slash+1:name,(void*)((uintptr_t)n.frames[i]-(uintptr_t)module));}else fprintf(f,"%p;",n.frames[i]);}fputc('\n',f);}fclose(f);}else ok=false;
 if(!moderngeometrycapture::finish(context.Get(),prefix))ok=false;sources.clear();inputs.clear();events.clear();notes.clear();context.Reset();device.Reset();lock.lock();finishing=false;return ok;
}
}








