#pragma once
#include "modern_glass_ids.h"
namespace modernglass {
inline constexpr char source[]=R"GLASS(
// OPTICAL_HELPERS_BEGIN
// Shared optical response for verified material interfaces. All radiance is HDR.
float3 modernFresnel(float3 f0,float cosine){return saturate(f0)+(1-saturate(f0))*pow(1-saturate(cosine),5);}
float modernDielectric(float cosine,float etaI,float etaT){
 float c=saturate(abs(cosine)),eta=etaI/max(etaT,.001),k=1-eta*eta*(1-c*c);if(k<=0)return 1;
 float t=sqrt(k),s=(etaI*c-etaT*t)/max(etaI*c+etaT*t,1e-7),p=(etaT*c-etaI*t)/max(etaT*c+etaI*t,1e-7);return saturate((s*s+p*p)*.5);
}
float3 modernBeer(float3 absorption,float distance){return exp(-max(absorption,0)*max(distance,0));}
float modernLightRange(float distance,float range){float q=saturate(distance/max(range,.001)),window=1-q*q*q*q;return window*window/max(distance*distance,1);}
float modernNativeLightRange(float distance,float offset,float scale){return scale>1e-7&&offset>0?modernLightRange(distance,offset/scale):saturate(offset-distance*scale);}
// Preserve authored normal-incidence opacity, increasing optical path at grazing.
float modernGlassOpacity(float opacity,float cosine,float ior){
 if(opacity>=1)return 1;float eta=1/max(ior,1.001),ct=sqrt(max(1-eta*eta*(1-saturate(cosine*cosine)),.0001));
 float base=pow(max(1-saturate(opacity),1e-6),1/ct);float f=modernDielectric(cosine,1,ior),normal=modernDielectric(1,1,ior);
 return saturate(1-base*(1-f)/max(1-normal,.001));
}

Texture2D<float2> modernMaterial0:register(t25),modernMaterial1:register(t26),modernMaterial2:register(t27),modernMaterial3:register(t28);
float3 modernMaterialMap(float2 uv,int layer,SamplerState state){
 uint w,h;float2 value;
 if(layer==0){modernMaterial0.GetDimensions(w,h);if(!w)return 0;value=modernMaterial0.Sample(state,uv);}
 else if(layer==1){modernMaterial1.GetDimensions(w,h);if(!w)return 0;value=modernMaterial1.Sample(state,uv);}
 else if(layer==2){modernMaterial2.GetDimensions(w,h);if(!w)return 0;value=modernMaterial2.Sample(state,uv);}
 else {modernMaterial3.GetDimensions(w,h);if(!w)return 0;value=modernMaterial3.Sample(state,uv);}
 return float3(value,1);
}
void modernApplyMaterialMap(float3 estimate,inout float roughness,inout float reflectivity){
 if(estimate.z<=0)return;float2 value=estimate.xy/max(estimate.z,1e-5);float confidence=saturate(estimate.z);
 // Authored material response bounds the texture-derived approximation.
 roughness=lerp(roughness,max(roughness*.65,value.y),confidence*.5);
 reflectivity=lerp(reflectivity,max(reflectivity*.5,value.x*.35),confidence);
}

// OPTICAL_HELPERS_END
























































































cbuffer Common:register(b0){float4 common[11];};cbuffer Light:register(b1){float4 lighting[3];};cbuffer Material:register(b2){float4 material[3];};cbuffer Instance:register(b6){float4 tint;float4 alphaControl;};
Texture2D<float4> diffuseMap:register(t0),specularMap:register(t1);SamplerState diffuseSampler:register(s0),specularSampler:register(s1);
#if LOCAL_LIGHT
struct In{float4 position:SV_Position;float2 uv:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float3 normal:TEXCOORD3;float4 spotFog:TEXCOORD4;};
#else
struct In{float4 position:SV_Position;float2 uv:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float4 normalFog:TEXCOORD3;};
#endif
float3 unit(float3 v){return v*rsqrt(max(dot(v,v),1e-8));}
float4 main(In input):SV_Target{
 #if LOCAL_LIGHT
 float3 N=unit(input.normal);float fog=input.spotFog.w;
 #else
 float3 N=unit(input.normalFog.xyz);float fog=input.normalFog.w;
 #endif
 float4 glass=diffuseMap.Sample(diffuseSampler,input.uv);float3 V=unit(input.toEye),L=unit(input.toLight);N*=dot(N,V)<0?-1:1;
 float3 H=unit(V+L);float nl=saturate(dot(N,L)),nv=max(saturate(dot(N,V)),.001),nh=saturate(dot(N,H)),vh=saturate(dot(V,H));
 float roughness=clamp(pow(2/(max(material[2].w,1)+2),.25),.18,.95);float mapStrength=1;modernApplyMaterialMap(modernMaterialMap(input.uv,0,diffuseSampler),roughness,mapStrength);float a=roughness*roughness,a2=a*a,den=nh*nh*(a2-1)+1;
 float D=a2/(3.14159265*max(den*den,1e-7));float G=.5/max(nl*sqrt(nv*nv*(1-a2)+a2)+nv*sqrt(nl*nl*(1-a2)+a2),1e-5);
 float F=modernDielectric(vh,1,1.5);float3 spec=specularMap.Sample(specularSampler,input.uv*material[2].yz).rgb*max(material[1].rgb,0)*max(material[2].x,0);
 float3 colour=D*G*F*nl*spec*mapStrength*max(lighting[0].rgb,0);
 #if LOCAL_LIGHT
 float attenuation=modernNativeLightRange(length(input.toLight),lighting[1].x,lighting[1].y);float cone=max(min(dot(-L,input.spotFog.xyz),lighting[2].x)-lighting[2].y,0)*lighting[2].z;colour*=attenuation*(lighting[2].w>0?saturate(cone):1);colour*=1-saturate(fog);
 #else
 float3 ambient=lerp(max(common[3].rgb,0),max(common[2].rgb,0),saturate(N.y*.5+.5));colour+=max(glass.rgb*material[0].rgb,0)*ambient;colour=lerp(colour,max(common[4].rgb,0),saturate(fog));
 #endif
 // Preserve authored opacity and reflection amount, including windshield fixes.
 return float4(max(colour,0)*tint.rgb,modernGlassOpacity(glass.a*tint.a,nv,1.5));
}
)GLASS";
using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11PixelShader**);
inline int identify(const void* p,size_t n){if(!p||n<32||memcmp(p,"DXBC",4))return -1;for(auto i:identities)if(n==i.bytes&&!memcmp((const char*)p+4,i.hash,16))return i.mode;return -1;}
inline HRESULT create(Create native,ID3D11Device* device,const void* original,SIZE_T size,ID3D11PixelShader** shader,int mode,bool& substituted){
 substituted=false;static std::mutex mutex;static Microsoft::WRL::ComPtr<ID3DBlob> codes[2];std::lock_guard<std::mutex> lock(mutex);HRESULT hr=S_OK;
 if(mode<0||mode>1)return native(device,original,size,nullptr,shader);
 if(!codes[mode]){D3D_SHADER_MACRO macros[]={{"LOCAL_LIGHT",mode?"1":"0"},{nullptr,nullptr}};hr=D3DCompile(source,sizeof(source)-1,"RFGRVR glass GGX",macros,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&codes[mode],nullptr);}
 if(SUCCEEDED(hr))hr=native(device,codes[mode]->GetBufferPointer(),codes[mode]->GetBufferSize(),nullptr,shader);
 if(SUCCEEDED(hr)){substituted=true;return hr;}return native(device,original,size,nullptr,shader);
}
}
