#pragma once
#include "vr_eye_pipeline.h"
namespace moderncompute {
// Inline compute work for the engine's deferred HDR stream. Preserve compute
// bindings and all OM outputs, including hidden append/consume UAV counters.
// No command list is executed on a deferred context.
class Scope {
 RFGRVRShaderBindings<ID3D11ComputeShader> cs;RFGRVRBindings<ID3D11UnorderedAccessView,8> computeOutputs,graphicsOutputs;
 RFGRVRBindings<ID3D11RenderTargetView,8> targets;Microsoft::WRL::ComPtr<ID3D11DepthStencilView> depth;Microsoft::WRL::ComPtr<ID3D11Predicate> predicate;BOOL predicateValue=FALSE;unsigned targetCount=0;
 ID3D11DeviceContext* context;
 static void clear(ID3D11DeviceContext* c){ID3D11UnorderedAccessView* empty[8]{};UINT keep[8];for(auto& x:keep)x=~0u;c->CSSetUnorderedAccessViews(0,8,empty,keep);c->OMSetRenderTargetsAndUnorderedAccessViews(0,nullptr,nullptr,0,8,empty,keep);}
public:
 explicit Scope(ID3D11DeviceContext* c):context(c){c->CSGetShader(&cs.shader,cs.classes.p,&cs.count);c->CSGetConstantBuffers(0,14,cs.buffers.p);c->CSGetShaderResources(0,128,cs.resources.p);c->CSGetSamplers(0,16,cs.samplers.p);c->CSGetUnorderedAccessViews(0,8,computeOutputs.p);c->OMGetRenderTargets(8,targets.p,&depth);for(unsigned i=0;i<8;++i)if(targets.p[i])targetCount=i+1;if(targetCount<8)c->OMGetRenderTargetsAndUnorderedAccessViews(0,nullptr,nullptr,targetCount,8-targetCount,graphicsOutputs.p+targetCount);c->GetPredication(&predicate,&predicateValue);c->SetPredication(nullptr,FALSE);clear(c);}
 ~Scope(){auto* c=context;clear(c);UINT keep[8];for(auto& x:keep)x=~0u;if(targetCount==8)c->OMSetRenderTargets(8,targets.p,depth.Get());else c->OMSetRenderTargetsAndUnorderedAccessViews(targetCount,targets.p,depth.Get(),targetCount,8-targetCount,graphicsOutputs.p+targetCount,keep);c->CSSetShader(cs.shader.Get(),cs.classes.p,cs.count);c->CSSetConstantBuffers(0,14,cs.buffers.p);c->CSSetShaderResources(0,128,cs.resources.p);c->CSSetSamplers(0,16,cs.samplers.p);c->CSSetUnorderedAccessViews(0,8,computeOutputs.p,keep);c->SetPredication(predicate.Get(),predicateValue);}
};
}
