#pragma once
#include "vr_memory_access.h"
#include <cmath>
#include <cstring>
namespace vrvehicleexposure {
inline bool eligible(bool vr,unsigned state,bool firstPerson){return vr&&firstPerson&&(state==8||state==9||state==10);}
// Verified rl_hdr_state layout. Change only the luminance-sampling floor;
// retain native adaptation, bloom, colour and light-source parameters.
struct alignas(16) Parameters {
 unsigned char bytes[0x68]{};
 bool copy(const void* native,bool active){
  if(!active||!vrmemory::check(native,sizeof(bytes)))return false;
  float maximum=0,minimum=0;memcpy(&maximum,(const char*)native+0x20,4);memcpy(&minimum,(const char*)native+0x24,4);
  if(!std::isfinite(maximum)||!std::isfinite(minimum)||maximum<=0||maximum>10000||minimum<0||minimum>maximum)return false;
  float floor=maximum<.5f?maximum:.5f;if(minimum>=floor)return false;
  memcpy(bytes,native,sizeof(bytes));memcpy(bytes+0x24,&floor,4);return true;
 }
};
}
