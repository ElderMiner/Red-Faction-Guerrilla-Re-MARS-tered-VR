#pragma once
#include "modern_cube_capture.h"
#include "vr_arm_math.h"
#include <mutex>
namespace modernaux {
// A producer owns one complete six-face generation. Completion is a GPU event,
// not the CPU return from the native deferred scene function. No waits/flushes.
class Producer {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 moderncapture::Cube cube;Ptr<ID3D11Device> device;Ptr<ID3D11Query> event;Ptr<ID3D11DeviceContext> recordingStream;
 uint64_t scene=0,generation=0,revision=0,ready=0,lastFrame=0;unsigned face=0;
 modernlocal::V origin{};bool recording=false,pending=false,accepted=false,submitted=false,awaitSubmission=false;
public:
 bool begin(ID3D11Device* d,uint64_t sceneId,uint64_t id,uint64_t geometryRevision,modernlocal::V position,unsigned size=128){
  if(!d||!sceneId||!id||recording||pending)return false;
  if(device.Get()!=d||scene!=sceneId){cube={};event.Reset();ready=0;device=d;scene=sceneId;}
  if(!event){D3D11_QUERY_DESC desc{};desc.Query=D3D11_QUERY_EVENT;if(FAILED(d->CreateQuery(&desc,&event)))return false;}
  if(!cube.begin(d,position,id,geometryRevision,size))return false;
  generation=id;revision=geometryRevision;origin=position;face=0;recording=true;accepted=false;awaitSubmission=false;lastFrame=0;recordingStream.Reset();return true;
 }
 bool next(uint64_t frame,vrarm::Pose& pose){
  if(!recording||accepted||awaitSubmission||frame<=lastFrame||face>=6)return false;lastFrame=frame;
  const vrarm::V forward[]={{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
  const vrarm::V up[]={{0,1,0},{0,1,0},{0,0,-1},{0,0,1},{0,1,0},{0,1,0}};
  pose={{vrarm::cross(up[face],forward[face]),up[face],forward[face]}, {origin.x,origin.y,origin.z}};return true;
 }
 bool capture(ID3D11DeviceContext* c,ID3D11ShaderResourceView* hdr,ID3D11ShaderResourceView* depth,const float* clip,const float* eye,const float* renderOrigin=nullptr){
  if(!recording||accepted||awaitSubmission||(recordingStream&&recordingStream.Get()!=c)||!cube.capture(c,face,generation,revision,hdr,depth,clip,eye,8,true,renderOrigin))return false;
  recordingStream=c;accepted=true;if(face==5)c->End(event.Get());return true;
 }
 bool finishFace(ID3D11DeviceContext* stream){
  if(!recording||!accepted||!stream||stream!=recordingStream.Get())return false;accepted=false;awaitSubmission=true;
  if(++face==6){pending=true;submitted=false;recording=false;}return true;
 }
 bool finishFace(){return finishFace(recordingStream.Get());}
 // Call only after the owner has submitted this native command stream.
 void markSubmitted(){if(awaitSubmission){awaitSubmission=false;recordingStream.Reset();if(pending)submitted=true;}}
 bool poll(ID3D11DeviceContext* immediate){
  if(!pending||!submitted||!immediate||immediate->GetType()!=D3D11_DEVICE_CONTEXT_IMMEDIATE)return false;
  Ptr<ID3D11Device> owner;immediate->GetDevice(&owner);if(owner.Get()!=device.Get())return false;
  BOOL completed=FALSE;auto result=immediate->GetData(event.Get(),&completed,sizeof(completed),D3D11_ASYNC_GETDATA_DONOTFLUSH);
  if(FAILED(result)){pending=false;ready=0;return false;}
  if(result!=S_OK||!completed)return false;pending=false;ready=generation;return true;
 }
 void cancel(){recording=accepted=awaitSubmission=false;recordingStream.Reset();}
 bool busy()const{return recording||pending;}
 uint64_t completed()const{return ready;}
 unsigned currentFace()const{return face;}
 const moderncapture::Cube& result()const{return cube;}
 modernlocal::V position()const{return origin;}
};
inline Producer producer;
inline void* nativeScene=nullptr;
inline void* nativeRenderer=nullptr;
inline void* nativeSecondary=nullptr;
inline bool active=false;
inline unsigned captured=0,failed=0;
inline unsigned lastWidth=0,lastHeight=0,lastStage=0;
}

