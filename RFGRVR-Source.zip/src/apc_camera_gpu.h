#pragma once
#include <cstdint>
#include "bridge_wrist_atlas.h"
#include <dxgi.h>
#include "apc_screen_layout.h"
struct RFGRAPCGpu {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 WristAtlas atlas;Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> deferred;Ptr<ID3D11Texture2D> sources[5];Ptr<IDXGIKeyedMutex> mutex;uint64_t handle=0;unsigned epoch=0;
 bool init(ID3D11Device* d){if(owner.Get()==d&&mutex)return true;if(owner.Get()!=d){atlas={};for(auto& source:sources)source.Reset();mutex.Reset();deferred.Reset();owner=d;handle=0;}if(!atlas.init(d))return false;
 D3D11_TEXTURE2D_DESC td{};td.Width=RFGRAPCScreen::atlasWidth;td.Height=RFGRAPCScreen::atlasHeight;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;td.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
 atlas.texture.Reset();atlas.target.Reset();if(FAILED(d->CreateTexture2D(&td,nullptr,&atlas.texture))||FAILED(d->CreateRenderTargetView(atlas.texture.Get(),nullptr,&atlas.target))||FAILED(atlas.texture.As(&mutex))||FAILED(d->CreateDeferredContext(0,&deferred)))return false;
 Ptr<IDXGIResource> resource;if(FAILED(atlas.texture.As(&resource)))return false;HANDLE shared=nullptr;if(FAILED(resource->GetSharedHandle(&shared)))return false;handle=(uint64_t)(uintptr_t)shared;++epoch;return true;
 }
 bool capture(ID3D11Device* d,ID3D11DeviceContext* immediate,ID3D11Texture2D* back,unsigned index){
 if(index>=5||!back||!init(d)||mutex->AcquireSync(0,0)!=S_OK)return false;
 auto& source=sources[index];D3D11_TEXTURE2D_DESC td{};back->GetDesc(&td);bool ready=true;
 if(source){D3D11_TEXTURE2D_DESC old{};source->GetDesc(&old);if(old.Width!=td.Width||old.Height!=td.Height||old.Format!=td.Format){source.Reset();atlas.views[index]={};}}
 if(!source){td.BindFlags=D3D11_BIND_SHADER_RESOURCE;td.MiscFlags=0;td.Usage=D3D11_USAGE_DEFAULT;td.CPUAccessFlags=0;ready=SUCCEEDED(d->CreateTexture2D(&td,nullptr,&source));}
 if(ready){immediate->CopyResource(source.Get(),back);auto tile=RFGRAPCScreen::tile(index);atlas.draw(d,deferred.Get(),index,source.Get(),float(tile.x),float(tile.y),float(tile.width),float(tile.height));Ptr<ID3D11CommandList> list;ready=SUCCEEDED(deferred->FinishCommandList(FALSE,&list));if(ready)immediate->ExecuteCommandList(list.Get(),TRUE);}
 immediate->Flush();mutex->ReleaseSync(0);return ready;
 }
};
