#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "vr_arm_math.h"
#include "vr_render_anchor.h"
#include <windows.h>
namespace vrtankbodyframe {
inline SRWLOCK lock=SRWLOCK_INIT;inline void* owner=nullptr;inline void* character=nullptr;inline unsigned vehicle=~0u;inline ULONGLONG tick=0;inline vrarm::Pose root{};
inline void publish(void* p,void* c,unsigned id,const vrarm::Pose& pose){AcquireSRWLockExclusive(&lock);owner=p;character=c;vehicle=id;root=pose;tick=GetTickCount64();ReleaseSRWLockExclusive(&lock);}
inline bool read(void* p,void* c,unsigned id,vrarm::Pose& pose){AcquireSRWLockShared(&lock);bool ok=p&&p==owner&&c==character&&id==vehicle&&tick&&GetTickCount64()-tick<200;if(ok)pose=root;ReleaseSRWLockShared(&lock);return ok;}
}
