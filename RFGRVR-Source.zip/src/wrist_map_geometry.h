#pragma once
#include <cmath>
#include <cstdint>
#include <vector>
#include <algorithm>
namespace vrwrist {
struct Vertex {float x,y,z,w,u,v;uint32_t color;};
static_assert(sizeof(Vertex)==28,"Native HUD vertex contract");
struct Bounds {float left=0,top=0,right=0,bottom=0;};
inline bool updateDue(uint32_t now,uint32_t previous,bool consumerFresh){return !consumerFresh||!previous||uint32_t(now-previous)>=33u;}
// Select a whole native frame together so sibling HUD groups never alternate.
struct FrameGate {uint32_t frame=0,tick=0;bool initialized=false,accepted=false;
 bool update(uint32_t next,uint32_t now,bool fresh){if(!initialized||next!=frame){initialized=true;frame=next;accepted=updateDue(now,tick,fresh);if(accepted)tick=now;}return accepted;}
};
constexpr float Marker=1048576.f,Shift=65536.f;
inline unsigned epoch(const Vertex& v){return v.z>Marker&&v.z<Marker+524288.f?unsigned(v.z-Marker):0;}
inline void mark(Vertex& v,unsigned sequence){v.x+=Shift;v.z=Marker+float(sequence);}
inline Vertex restore(Vertex v,float width){v.x-=Shift*2.f/width;v.z=0;return v;}
inline Vertex project(Vertex v,Bounds b,float width,float height){v=restore(v,width);float px=(v.x+1)*.5f*width,py=(1-v.y)*.5f*height;v.x=2*(px-b.left)/(b.right-b.left)-1;v.y=1-2*(py-b.top)/(b.bottom-b.top);return v;}
inline unsigned vertexCount(unsigned type,unsigned primitives){switch(type){case 0:return primitives+2;case 1:return primitives*2;case 2:return primitives;case 3:return primitives*3;default:return 0;}}
inline void triangles(const Vertex* v,unsigned type,unsigned primitives,unsigned sequence,std::vector<Vertex>& out){
 out.clear();if(type!=0&&type!=3)return;
 for(unsigned t=0;t<primitives;++t){unsigned a=type==0?t:t*3,b=a+1,c=a+2;if(type==0&&(t&1))std::swap(a,b);if(epoch(v[a])==sequence&&epoch(v[b])==sequence&&epoch(v[c])==sequence){out.push_back(v[a]);out.push_back(v[b]);out.push_back(v[c]);}}
}
}
