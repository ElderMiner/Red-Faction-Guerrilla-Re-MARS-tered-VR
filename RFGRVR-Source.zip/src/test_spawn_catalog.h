#pragma once
#include <cstring>
namespace vrtestspawn {
struct Entry {const char* name;const char* label;bool turret;};
inline constexpr Entry entries[]={
 {"Mar_Jetter_1","Marauder Jetter",false},{"Mar_Raider_1","Marauder Raider",false},
 {"turret_machinegun","Standing machine gun",true},{"turret_gauss","Standing Gauss",true},
 {"turret_rocket","Standing rocket launcher",true},{"turret_harpoon","Standing harpoon",true},{"artillery_gun","Standing artillery",true}};
inline constexpr Entry tanks[]={
 {"EDF_HeavyTank-A_1","EDF Heavy Tank 1",false},{"EDF_HeavyTank-A_2","EDF Heavy Tank 2",false},{"EDF_HeavyTank-A_3","EDF Heavy Tank 3",false},{"EDF_HeavyTank-A_4","EDF Heavy Tank 4",false},
 {"EDF_MediumTank-A_1","EDF Medium Tank 1",false},{"EDF_MediumTank-A_2","EDF Medium Tank 2",false},{"EDF_MediumTank-A_3","EDF Medium Tank 3",false},{"EDF_MediumTank-A_4","EDF Medium Tank 4",false},
 {"EDF_ArtTank_1","EDF Artillery Tank 1",false},{"EDF_ArtTank_2","EDF Artillery Tank 2",false}};
inline bool tank(const char* name){if(name)for(auto& e:tanks)if(!strcmp(e.name,name))return true;return false;}
inline bool artilleryTank(const char* name){return tank(name)&&strncmp(name,"EDF_ArtTank_",12)==0;}
 inline bool rotatingTankCabin(const char* name){return tank(name)&&strncmp(name,"EDF_MediumTank-A_",17)==0;}
 inline bool heavyTank(const char* name){return tank(name)&&strncmp(name,"EDF_HeavyTank-A_",16)==0;}
inline const Entry* find(const char* name){if(name){for(auto& e:entries)if(!strcmp(e.name,name))return &e;for(auto& e:tanks)if(!strcmp(e.name,name))return &e;}return nullptr;}
}
