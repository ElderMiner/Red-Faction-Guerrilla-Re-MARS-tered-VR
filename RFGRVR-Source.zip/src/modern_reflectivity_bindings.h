#pragma once
#include "modern_height_catalog.h"
namespace modernreflectivity {
class Bindings {
 modernheight::Ptr<ID3D11DeviceContext> context;
 modernheight::Ptr<ID3D11ShaderResourceView> previous[4],current[4];modernheight::Ptr<modernheight::Attachment> owners[4];
public:
 bool apply(ID3D11DeviceContext* c,ID3D11ShaderResourceView*const* inputs,unsigned count){
  if(!c||count>4)return false;
  if(!context){ID3D11ShaderResourceView* old[4]{};c->PSGetShaderResources(25,4,old);for(unsigned i=0;i<4;++i)previous[i].Attach(old[i]);context=c;}
  if(context.Get()!=c)return false;
  for(unsigned i=0;i<4;++i){owners[i]=i<count?modernheight::attachment(inputs[i],modernheight::reflectivityId):modernheight::Ptr<modernheight::Attachment>{};current[i]=owners[i]?owners[i]->view.Get():nullptr;}
  ID3D11ShaderResourceView* values[]={current[0].Get(),current[1].Get(),current[2].Get(),current[3].Get()};c->PSSetShaderResources(25,4,values);return true;
 }
 ~Bindings(){if(context){ID3D11ShaderResourceView* values[]={previous[0].Get(),previous[1].Get(),previous[2].Get(),previous[3].Get()};context->PSSetShaderResources(25,4,values);}}
};
}
