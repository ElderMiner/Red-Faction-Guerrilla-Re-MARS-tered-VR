#pragma once
#include "vr_mapping.h"
#include "vr_arm_math.h"
#include <windows.h>
#include <cstdint>
#include <cstring>
#include <cstddef>
struct RFGRAPCCameras {
 unsigned magic=0x41504332;volatile LONG sequence=0;DWORD pid=0,tick=0;unsigned vehicle=~0u,active=0; // active bit0: visible mounts, bit1: occupied APC driver/screens/feeds; bit2: game-world depth-tested screens
 vrarm::Pose vehicleStage{},screens{},mounts[5]{};
 uint64_t texture=0;unsigned epoch=0,valid=0,grabbed=0;DWORD feedTick[5]{};
};
static_assert(sizeof(RFGRAPCCameras)==400,"APC camera IPC must match x86 and x64");
static constexpr wchar_t RFGR_APC_CAMERAS[]=L"Local\\RFGRVR_APCCameras_v2";
struct RFGRAPCChannel {
 HANDLE map=nullptr;RFGRAPCCameras* shared=nullptr;
 ~RFGRAPCChannel(){if(shared)UnmapViewOfFile(shared);if(map)CloseHandle(map);}
 bool open(bool writer){if(shared)return true;if(!map)map=writer?CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRAPCCameras),RFGR_APC_CAMERAS):OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_APC_CAMERAS);if(map)shared=(RFGRAPCCameras*)RFGRVR_MapViewOrClose(map,writer?FILE_MAP_ALL_ACCESS:FILE_MAP_READ,0,0,sizeof(RFGRAPCCameras));return shared;}
 void publish(RFGRAPCCameras p){if(!open(true))return;p.pid=GetCurrentProcessId();p.tick=GetTickCount();InterlockedIncrement(&shared->sequence);MemoryBarrier();memcpy(&shared->pid,&p.pid,sizeof(p)-offsetof(RFGRAPCCameras,pid));shared->magic=p.magic;MemoryBarrier();InterlockedIncrement(&shared->sequence);}
 bool read(DWORD pid,RFGRAPCCameras& p){if(!open(false))return false;for(unsigned i=0;i<3;++i){LONG s=shared->sequence;if(s&1)continue;MemoryBarrier();p=*shared;MemoryBarrier();if(s==shared->sequence)return p.magic==0x41504332&&p.pid==pid&&GetTickCount()-p.tick<300&&p.active;}return false;}
};
