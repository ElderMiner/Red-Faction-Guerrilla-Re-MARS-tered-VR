#pragma once
#include "vr_memory_access.h"
#include <algorithm>
#include <cmath>
#include <cstring>
extern "C" bool RFGRVR_HeadCam_Enabled();
namespace vrnight {
inline float smooth(float x){x=(std::clamp)(x,0.f,1.f);return x*x*(3-2*x);}
inline float weight(float hour){
 if(!std::isfinite(hour)||hour<0||hour>24)return 0;
 if(hour<5||hour>=19)return 1;
 // GameClockGetTimeOfDay partitions from 06:00 in four-hour blocks:
 // first three are GC_DAY, last three GC_NIGHT. Never grade GC_DAY.
 if(hour<6)return 1-smooth(hour-5);
 if(hour<=18)return 0;
 return smooth(hour-18);
}
struct Plan {
 float exposure=1,bloom=1;
 float mainLight=1,ambient=1,saturation=1,tint[3]{1,1,1};
 static Plan at(float hour,int sceneExposure,int bloomPercent,int mainPercent=100,int ambientPercent=100,int saturationPercent=100,int red=100,int green=100,int blue=100){
  const float night=weight(hour);auto amount=[&](int v){return 1+night*((std::clamp)(v,0,200)/100.f-1);};
  Plan p;p.exposure=1+night*((std::clamp)(sceneExposure,5,100)/100.f-1);p.bloom=1+night*((std::clamp)(bloomPercent,0,100)/100.f-1);p.mainLight=amount(mainPercent);p.ambient=amount(ambientPercent);p.saturation=amount(saturationPercent);p.tint[0]=amount(red);p.tint[1]=amount(green);p.tint[2]=amount(blue);return p;
 }
};
inline thread_local const Plan* current=nullptr;
// One clock/settings snapshot for both eyes and auxiliary feeds. Nested work
// inherits its parent; no native scene, sky, camera or clock state is written.
struct Frame {
 Plan value;const Plan* previous;
 explicit Frame(Plan p):value(p),previous(current){if(!previous)current=&value;}
 ~Frame(){current=previous;}
};
struct alignas(16) Parameters {
 unsigned char bytes[0x68]{};
 bool copy(const void* native){
  if(!current||!vrmemory::check(native,sizeof(bytes)))return false;
  float maximum,minimum,amount;
  memcpy(&maximum,(const char*)native+0x20,4);memcpy(&minimum,(const char*)native+0x24,4);memcpy(&amount,(const char*)native+0x48,4);
  if(!std::isfinite(maximum)||!std::isfinite(minimum)||!std::isfinite(amount)||maximum<=0||maximum>10000||minimum<0||minimum>maximum||amount<0||amount>10000)return false;
  float glow=amount*current->bloom;
  if(glow==amount)return false;
  memcpy(bytes,native,sizeof(bytes));memcpy(bytes+0x48,&glow,4);return true;
 }
};
inline bool bloomLimit(const void* native,float& limit){
 if(!current||current->bloom>=1||!vrmemory::check(native,0x4c))return false;
 float amount;memcpy(&amount,(const char*)native+0x48,4);
 if(!std::isfinite(amount)||amount<0||amount>10000)return false;
 limit=amount*current->bloom;return true;
}
inline float expose(float value,float gain){value=(std::clamp)(value,0.f,1.f);return value*gain/(1-value+value*gain);}
inline void grade(float rgb[3],const Plan& p){float c[3];for(int i=0;i<3;++i)c[i]=expose(rgb[i],p.exposure);const float l=c[0]*.2126f+c[1]*.7152f+c[2]*.0722f;for(int i=0;i<3;++i)rgb[i]=(std::clamp)((l+(c[i]-l)*p.saturation)*p.tint[i],0.f,1.f);}
}
