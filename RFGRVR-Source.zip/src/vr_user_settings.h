#pragma once
#include <windows.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include "ipc.h"
namespace vrsettings {
enum Option {Crouch,Jump,Reload,Throw,Vehicles,Seated,Turn,TurnSpeed,SnapAngle,CrouchDepth,Haptics,FocusVignette,PPD,Body,Desktop,Count};
inline const char* keys[Count]={"Crouch","Jump","Reload","Throw","FirstPersonVehicles","Seated","Turn","TurnSpeed","SnapAngle","CrouchDepthCm","Haptics","FocusVignette","PixelsPerDegree","PlayerBody","ShowOnDesktop"};
inline const char* titles[Count]={"Crouching","Jumping","Reloading","Throwing","Vehicle view","Play mode","Turning","Smooth turn speed","Snap turn angle","Half crouch threshold","Controller vibration","Focus vignette","Scene resolution (PPD)","Player visibility","Show on desktop"};
inline const int defaults[Count]={1,1,0,0,1,0,0,90,30,30,100,1,0,1,1};
inline const int limits[Count]={2,2,1,1,1,1,1,180,90,60,100,1,20,1,1};
// Canonical physical sources. Pose tracking is never remapped.
enum Source {LT,RT,LG,RG,A,B,X,Y,Start,Back,LS,RS,LB,RB,DU,DD,DL,DR,LUp,LDown,LLeft,LRight,RUp,RDown,RLeft,RRight,SourceCount};
inline const char* sourceNames[SourceCount]={"Left trigger","Right trigger","Left grip","Right grip","A / right primary","B / right secondary","X / left primary","Y / left secondary","Menu","View / back","Left stick press","Right stick press","Left bumper","Right bumper","D-pad up","D-pad down","D-pad left","D-pad right","Left stick up","Left stick down","Left stick left","Left stick right","Right stick up","Right stick down","Right stick left","Right stick right"};
inline const unsigned masks[18]={0,0,0,0,0x1000,0x2000,0x4000,0x8000,0x10,0x20,0x40,0x80,0x100,0x200,1,2,4,8};
inline const char* actionNames[SourceCount]={"Secondary fire / magazine grab","Fire / prepare throw","Support-hand grip","Primary-hand grip / vehicle height","Jump / confirm","Interact / back","Reload / chamber","Switch weapon","Pause","Map / back","Crouch / vehicle recenter","Vehicle aiming overlay","Left bumper","Weapon selector","Select up","Select down","Select left","Select right","Move forward / accelerate","Move backward / brake","Strafe / steer left","Strafe / steer right","Vehicle height up","Vehicle height down","Turn left","Turn right"};
struct Config {int value[Count];int binding[SourceCount];int seatHeightCm=120;Config(){memcpy(value,defaults,sizeof(value));for(int i=0;i<SourceCount;++i)binding[i]=i;}void validate(){for(int i=0;i<Count;++i)value[i]=(std::clamp)(value[i],0,limits[i]);if(value[PPD])value[PPD]=value[PPD]<14?11:value[PPD]<19?0:20;value[TurnSpeed]=(std::max)(15,value[TurnSpeed]);value[SnapAngle]=(std::max)(5,value[SnapAngle]);value[CrouchDepth]=(std::max)(10,value[CrouchDepth]);for(int i=0;i<SourceCount;++i)if(binding[i]<0||binding[i]>=SourceCount)binding[i]=i;}};
inline char path[MAX_PATH]{};inline SRWLOCK lock=SRWLOCK_INIT;inline Config cached;inline DWORD checked=0;
inline void initPath(){if(path[0])return;
#ifdef RFGR_TEST_USER_SETTINGS
 GetTempPathA(MAX_PATH,path);char name[64];sprintf_s(name,"RFGRVR-test-settings-%lu.ini",GetCurrentProcessId());strcat_s(path,name);return;
#endif
GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* p=strstr(path,"\\vr-research\\project\\"))*p=0;else if(auto* p=strrchr(path,'\\'))*p=0;strcat_s(path,"\\RFGRVR-settings.ini");}
inline Config read(){initPath();Config c;for(int i=0;i<Count;++i)c.value[i]=GetPrivateProfileIntA("VR",keys[i],defaults[i],path);for(int i=0;i<SourceCount;++i){char key[32];sprintf_s(key,"Action%d",i);c.binding[i]=GetPrivateProfileIntA("Controls",key,i,path);}c.seatHeightCm=(std::clamp)(int(GetPrivateProfileIntA("VR","SeatHeightCm",120,path)),60,200);c.validate();return c;}
inline Config get(){AcquireSRWLockExclusive(&lock);DWORD now=GetTickCount();if(!checked||DWORD(now-checked)>500){initPath();static WIN32_FILE_ATTRIBUTE_DATA previous{};static bool loaded=false,existed=false;WIN32_FILE_ATTRIBUTE_DATA current{};bool exists=GetFileAttributesExA(path,GetFileExInfoStandard,&current)!=0;if(!loaded||exists!=existed||(exists&&(CompareFileTime(&current.ftLastWriteTime,&previous.ftLastWriteTime)||current.nFileSizeLow!=previous.nFileSizeLow||current.nFileSizeHigh!=previous.nFileSizeHigh))){cached=read();previous=current;existed=exists;loaded=true;}checked=now;}Config c=cached;ReleaseSRWLockExclusive(&lock);return c;}
inline bool save(Config c){c.validate();AcquireSRWLockExclusive(&lock);initPath();char temporary[MAX_PATH];sprintf_s(temporary,"%s.tmp",path);FILE* f=nullptr;bool ok=!fopen_s(&f,temporary,"w")&&f;if(ok){fprintf(f,"[VR]\n");for(int i=0;i<Count;++i)fprintf(f,"%s=%d\n",keys[i],c.value[i]);fprintf(f,"SeatHeightCm=%d\n[Controls]\n",c.seatHeightCm);for(int i=0;i<SourceCount;++i)fprintf(f,"Action%d=%d\n",i,c.binding[i]);ok=!ferror(f);if(fclose(f))ok=false;if(ok)ok=MoveFileExA(temporary,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;}if(ok){cached=c;checked=GetTickCount();}ReleaseSRWLockExclusive(&lock);return ok;}
inline void label(const Config& c,int i,char* text,size_t size){int v=c.value[i];const char* named=nullptr;switch(i){case Desktop:named=v?"On (right eye)":"Off (black window)";break;case Body:named=v?"Gloves only (default)":"Full body";break;case PPD:named=v==11?"Low (11 PPD)":v==20?"High (20 PPD)":"Default (~16.8 PPD)";break;case Crouch:named=v==0?"Full physical crouch":v==1?"Half physical crouch":"Button only";break;case Jump:named=v==0?"Physical only":v==1?"Physical or button":"Button only";break;case Reload:case Throw:named=v==0?"Immersive":"Button";break;case Vehicles:named=v?"First person":"Third person";break;case Seated:named=v?"Seated":"Standing";break;case Turn:named=v?"Snap":"Smooth";break;case FocusVignette:named=v?"On":"Off";break;}if(named)strcpy_s(text,size,named);else sprintf_s(text,size,"%d%s",v,i==TurnSpeed?" deg/sec":i==SnapAngle?" degrees":i==CrouchDepth?" cm":i==PPD?" PPD":"%");}
struct Bus {DWORD magic=0x56525331;volatile LONG gamePid=0,pauseTick=0,open=0,recalibrated=0,pauseMenuTick=0,openRequest=0,notificationEdit=0,recalibrateRequest=0,calibrationGeneration=0,nativeSettings=0,eyeElevationRequest=0,hudPreviewTick=0;};
#ifdef RFGR_TEST_USER_SETTINGS
inline constexpr wchar_t busName[]=L"Local\\RFGRVR_TEST_UserSettings_v1";
#else
inline constexpr wchar_t busName[]=L"Local\\RFGRVR_UserSettings_v1";
#endif
inline Bus* bus(){static HANDLE mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Bus),busName);static Bus* p=mapping?(Bus*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Bus)):nullptr;return p;}
inline bool paused(){auto* b=bus();return b&&b->pauseTick&&DWORD(GetTickCount()-DWORD(b->pauseTick))<300;}
inline bool pauseMenu(){auto* b=bus();return b&&b->pauseMenuTick&&DWORD(GetTickCount()-DWORD(b->pauseMenuTick))<300;}
inline bool hudPreviewFresh(DWORD tick,DWORD now,DWORD owner,DWORD process){return tick&&owner==process&&DWORD(now-tick)<500;}
inline bool hudPreview(){auto* b=bus();return b&&hudPreviewFresh(DWORD(b->hudPreviewTick),GetTickCount(),DWORD(b->gamePid),GetCurrentProcessId());}
inline bool notificationEditing(){auto* b=bus();return b&&b->notificationEdit;}
inline bool uiOpen(){auto* b=bus();return pauseMenu()&&b&&b->open;}
inline void physical(const RFGRGamepad& p,const float grip[2],float* raw){for(int i=0;i<SourceCount;++i)raw[i]=i<18&&masks[i]&&(p.buttons&masks[i])?1.f:0;raw[LT]=p.leftTrigger/255.f;raw[RT]=p.rightTrigger/255.f;raw[LG]=grip[0];raw[RG]=grip[1];raw[LUp]=(std::max)(0.f,p.leftY/32767.f);raw[LDown]=(std::max)(0.f,-p.leftY/32767.f);raw[LLeft]=(std::max)(0.f,-p.leftX/32767.f);raw[LRight]=(std::max)(0.f,p.leftX/32767.f);raw[RUp]=(std::max)(0.f,p.rightY/32767.f);raw[RDown]=(std::max)(0.f,-p.rightY/32767.f);raw[RLeft]=(std::max)(0.f,-p.rightX/32767.f);raw[RRight]=(std::max)(0.f,p.rightX/32767.f);}
inline RFGRGamepad remap(const Config& c,const float* raw,float* grip){RFGRGamepad p{};for(int i=4;i<18;++i)if(raw[c.binding[i]]>.65f)p.buttons|=masks[i];p.leftTrigger=(unsigned char)((std::clamp)(raw[c.binding[LT]],0.f,1.f)*255);p.rightTrigger=(unsigned char)((std::clamp)(raw[c.binding[RT]],0.f,1.f)*255);grip[0]=raw[c.binding[LG]];grip[1]=raw[c.binding[RG]];auto axis=[&](int plus,int minus){return short((std::clamp)(raw[c.binding[plus]]-raw[c.binding[minus]],-1.f,1.f)*32767);};p.leftX=axis(LRight,LLeft);p.leftY=axis(LUp,LDown);p.rightX=axis(RRight,RLeft);p.rightY=axis(RUp,RDown);return p;}
struct Turning {bool latched=false;float apply(float axis,float dt,const Config& c){if(!c.value[Turn]){latched=false;float a=fabsf(axis)>.22f?(axis-(axis>0?.22f:-.22f))/.78f:0;return a*c.value[TurnSpeed]*dt;}if(fabsf(axis)<.3f)latched=false;if(!latched&&fabsf(axis)>.7f){latched=true;return (axis>0?1:-1)*c.value[SnapAngle];}return 0;}};
// The standalone panel edits the existing eye-offset setting, preserving all
// other calibrated dimensions and vehicle offsets.
inline void eyePath(char (&out)[MAX_PATH]){initPath();strcpy_s(out,path);
#ifdef RFGR_TEST_USER_SETTINGS
 strcat_s(out,".eye.ini");
#else
 if(auto* slash=strrchr(out,'\\'))strcpy_s(slash+1,MAX_PATH-(slash+1-out),"RFGRVR-eye-offset.ini");
#endif
}
struct EyeCache {SRWLOCK lock=SRWLOCK_INIT;char previous[MAX_PATH]{};WIN32_FILE_ATTRIBUTE_DATA info{};DWORD checked=0;int value=0;};inline EyeCache eyeCache;
inline int eyeElevation(){auto& c=eyeCache;AcquireSRWLockExclusive(&c.lock);DWORD now=GetTickCount();if(!c.checked||DWORD(now-c.checked)>500){c.checked=now;char file[MAX_PATH];eyePath(file);WIN32_FILE_ATTRIBUTE_DATA fresh{};if(strcmp(c.previous,file)||!GetFileAttributesExA(file,GetFileExInfoStandard,&fresh)||CompareFileTime(&c.info.ftLastWriteTime,&fresh.ftLastWriteTime)||c.info.nFileSizeLow!=fresh.nFileSizeLow){c.value=(std::clamp)(int(GetPrivateProfileIntA("EyeOffset","OnFootUpCm",0,file)),-50,50);c.info=fresh;strcpy_s(c.previous,file);}}int value=c.value;ReleaseSRWLockExclusive(&c.lock);return value;}
inline bool setEyeElevation(int value){value=(std::clamp)(value,-50,50);char file[MAX_PATH],text[24];eyePath(file);sprintf_s(text,"%d",value);if(!WritePrivateProfileStringA("EyeOffset","OnFootUpCm",text,file))return false;AcquireSRWLockExclusive(&eyeCache.lock);eyeCache.value=value;eyeCache.checked=0;ReleaseSRWLockExclusive(&eyeCache.lock);if(auto* b=bus())InterlockedExchange(&b->eyeElevationRequest,value+1000);return true;}

// Independent render translation: moves the local avatar and both eyes equally.
// Does not change calibrated eye anatomy, scale, simulation or vehicle seats.
inline int& playerElevationStorage(){static int cm=[](){char file[MAX_PATH];eyePath(file);return (std::clamp)(int(GetPrivateProfileIntA("PlayerElevation","Cm",0,file)),-100,100);}();return cm;}
inline volatile LONG playerElevationCm=0;
inline float playerElevation(){static bool loaded=[](){InterlockedExchange(&playerElevationCm,playerElevationStorage());return true;}();(void)loaded;return InterlockedCompareExchange(&playerElevationCm,0,0)*.01f;}
inline bool adjustPlayerElevation(int direction){playerElevation();int value=(std::clamp)(int(InterlockedCompareExchange(&playerElevationCm,0,0))+direction,-100,100);char file[MAX_PATH],text[24];eyePath(file);sprintf_s(text,"%d",value);if(!WritePrivateProfileStringA("PlayerElevation","Cm",text,file))return false;InterlockedExchange(&playerElevationCm,value);return true;}

}
