#pragma once
#include <cstring>
#include <cstdlib>
#include "ipc.h"
namespace vrcontrollers {
enum Kind {Unknown,Frame,QuestTouch,Index};
inline Kind detect(const char* path){if(!path)return Unknown;if(strstr(path,"frame_controller"))return Frame;if(strstr(path,"index_controller"))return Index;if(strstr(path,"touch_controller"))return QuestTouch;return Unknown;}
inline const char* name(Kind kind){return kind==Frame?"Steam Frame":kind==QuestTouch?"Quest Touch / Touch Plus":kind==Index?"Valve Index":"Controller detecting";}
inline const char* gripComponent(Kind kind){return kind==Index?"force":"value";}
inline float grip(Kind kind,float value){return kind==Index?(value<0?0:value>.5f?1:value*2):value;}
// Preserve pose actions and analog grip. Supply missing gamepad buttons only
// for profiles without physical bumpers/menu equivalents.
inline void fallback(Kind left,Kind right,RFGRGamepad& p){
 if(left!=QuestTouch&&left!=Index)return;
 if(left==Index){if(p.buttons&0x8000){p.buttons&=~0x8000u;p.buttons|=0x200;}return;}
 if((p.buttons&0xc000)==0xc000){p.buttons&=~0xc000u;p.buttons|=0x20;} // X+Y / left A+B: map.
 else if(p.buttons&0x8000){p.buttons&=~0x8000u;p.buttons|=0x200;} // Y / left B: quick switch / hold wheel.

}
inline const char* hint(Kind kind){return kind==Index?"L pad up pause/down map | R pad tap swap/hold weapons | LS sprint, RS crouch":kind==QuestTouch?"B tap reload/hold use | X tap C4/hold mission | Y weapons | Menu tap map/hold pause":"D-pad: select / change   A: confirm   B: back   LB/RB: tabs";}
}
