#pragma once
#include <algorithm>
namespace vrboot {
struct Sequence {
 bool existingGame=false,calibrated=false,released=false,ready=false,roomPresented=false;unsigned long long began=0;
 void reset(bool resume=false){*this={};existingGame=resume;}
 bool canRelease(bool running,bool sourceReady)const{return ready&&running&&(existingGame||sourceReady);}
 void match(unsigned long long now){calibrated=true;began=now;}
 float blend(unsigned long long now)const{return calibrated?(std::min)(1.f,float(now-began)/700.f):0;}
 float visibility(unsigned long long now)const{return calibrated?1-(std::clamp)((float(now-began)-400.f)/700.f,0.f,1.f):1;}
 bool mayLaunch(unsigned long long now)const{return calibrated&&now>=began+1100;}
};
}

