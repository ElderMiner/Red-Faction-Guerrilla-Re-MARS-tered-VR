#pragma once
#include "vr_user_settings.h"
#include "vr_weapon_selector.h"
namespace vrhudlayout {
enum Id {Map,Ammo,Charges,Interact,Controls,Offer,Health,Heat,EDF,Morale,Control,Timer,Count};
inline const char* names[Count]={"Wrist map","Weapon ammo","Charges","Interact prompt","Vehicle controls","Mission offer","Health","Turret heat","EDF power update","Guerrilla morale update","EDF / Guerrilla control","Mission timer"};
inline constexpr unsigned fromHud[9]={Ammo,Charges,Interact,Controls,Offer,Health,Heat,EDF,Morale};
struct Item {vrarm::V offset{};float scale=1;};
struct Layout {
 Item item[Count]{};bool vehicle=false;bool editing=false,moving=false,dragging=false,previousGrip=false,closed=false,dirty=false;unsigned selected=0,page=0,revision=1;float grip=0;vrarm::V startHand{},startOffset{};bool keys[256]{};ULONGLONG repeats[256]{};char path[MAX_PATH]{};
 Layout(bool disk=true){if(disk){vrsettings::initPath();strcpy_s(path,vrsettings::path);if(auto* s=strrchr(path,'\\'))strcpy_s(s+1,MAX_PATH-(s+1-path),"RFGRVR-hud-layout.ini");load();}}
 void load(){for(unsigned i=0;i<Count;++i){char text[128]{};GetPrivateProfileStringA(names[i],"Layout","",text,sizeof(text),path);Item a;if(sscanf_s(text,"%f %f %f %f",&a.offset.x,&a.offset.y,&a.offset.z,&a.scale)==4&&vrarm::finite(a.offset)&&vrarm::length(a.offset)<=2&&std::isfinite(a.scale)&&a.scale>=.25f&&a.scale<=3)item[i]=a;}}
 bool save(){if(!dirty||!path[0])return !dirty;bool ok=true;for(unsigned i=0;i<Count;++i){auto& a=item[i];char text[128];sprintf_s(text,"%.7g %.7g %.7g %.7g",a.offset.x,a.offset.y,a.offset.z,a.scale);ok=WritePrivateProfileStringA(names[i],"Layout",text,path)&&ok;}if(ok)dirty=false;return ok;}
 void finish(){if(!editing)return;editing=moving=dragging=false;closed=true;save();++revision;}
 void key(int code){if(code==VK_NUMPAD0){if(editing)finish();else{editing=true;moving=dragging=false;previousGrip=grip>.65f;++revision;}return;}if(!editing)return;
 if(code==VK_ADD){if(vehicle)return;page=1-page;dragging=false;++revision;return;}
 if(code>=VK_NUMPAD1&&code<=VK_NUMPAD9){static constexpr unsigned vehicleKeys[9]={Map,Health,Controls,Heat,Timer,Control,Offer,EDF,Morale};unsigned n=vehicle?vehicleKeys[code-VK_NUMPAD1]:page*9+code-VK_NUMPAD1;if(n<Count){selected=n;dragging=false;previousGrip=grip>.65f;++revision;}return;}
 if(code==VK_DECIMAL){moving=!moving;dragging=false;if(!moving)save();++revision;return;}
 if(code==VK_MULTIPLY||code==VK_SUBTRACT){auto& s=item[selected].scale;s=(std::clamp)(s*(code==VK_MULTIPLY?1.05f:1/1.05f),.25f,3.f);dirty=true;save();++revision;}}
#ifdef RFGRVR_DEVELOPER_TOOLS
 void input(bool allowed,float squeeze){grip=squeeze;if(!allowed)finish();int codes[]={VK_NUMPAD0,VK_NUMPAD1,VK_NUMPAD2,VK_NUMPAD3,VK_NUMPAD4,VK_NUMPAD5,VK_NUMPAD6,VK_NUMPAD7,VK_NUMPAD8,VK_NUMPAD9,VK_ADD,VK_DECIMAL,VK_MULTIPLY,VK_SUBTRACT};auto now=GetTickCount64();for(int code:codes){bool down=(GetAsyncKeyState(code)&0x8000)!=0;bool edge=down&&!keys[code];keys[code]=down;if(allowed&&down&&(edge||((code==VK_MULTIPLY||code==VK_SUBTRACT)&&now>=repeats[code]))){key(code);repeats[code]=now+(edge?300:65);}}}
#else
 // Finalized public layout: no keyboard placement shortcuts.
 void input(bool,float squeeze){grip=squeeze;finish();}
#endif
 // Translation is expressed in the original anchor's frame, not global room coordinates.
 void drag(unsigned id,const RFGRPose& base,const RFGRPose& hand,bool planar){using namespace vrarm;if(!editing||!moving||selected!=id)return;bool held=moving;bool validHand=hand.active&&(hand.validFlags&3)==3;auto b=RFGRVRWeaponSelector::basis(base);if(!valid(b)||!validHand){dragging=false;previousGrip=held;return;}auto p=local(b,sub({hand.position[0],hand.position[1],hand.position[2]},{base.position[0],base.position[1],base.position[2]}));
 if(held&&!dragging){dragging=true;startHand=p;startOffset=item[id].offset;}
 if(held&&dragging){auto delta=sub(p,startHand);if(planar)delta.z=0;auto v=add(startOffset,delta);if(length(v)<2){item[id].offset=v;dirty=true;}}
 if(!held&&dragging){dragging=false;save();}previousGrip=held;}
 bool editorHud(unsigned hud)const{return !vehicle||hud>=3;}
 void apply(unsigned id,RFGRPose& base,const RFGRPose& hand){drag(id,base,hand,false);auto d=vrarm::world(RFGRVRWeaponSelector::basis(base),item[id].offset);base.position[0]+=d.x;base.position[1]+=d.y;base.position[2]+=d.z;}
 void rect(unsigned id,const RFGRPose& base,const RFGRPose& hand,float& x,float& y,float& w,float& h){drag(id,base,hand,true);auto a=item[id];float cx=x+w*.5f+a.offset.x*512/(.17f*item[Map].scale),cy=y+h*.5f-a.offset.y*512/(.17f*item[Map].scale);float fit=(std::min)(1.f,(std::min)(768.f/(w*a.scale),1280.f/(h*a.scale)));w*=a.scale*fit;h*=a.scale*fit;x=(std::clamp)(cx-w*.5f,0.f,768.f-w);y=(std::clamp)(cy-h*.5f,0.f,1280.f-h);}
};
struct Profiles {
 Layout foot,vehicle;bool lastVehicle=false,initialized=false;
 Profiles(bool disk=true):foot(disk),vehicle(false){vehicle.vehicle=true;for(unsigned i=0;i<Count;++i)vehicle.item[i]=foot.item[i];if(disk){strcpy_s(vehicle.path,foot.path);if(auto* s=strrchr(vehicle.path,'\\'))strcpy_s(s+1,MAX_PATH-(s+1-vehicle.path),"RFGRVR-vehicle-hud-layout.ini");vehicle.load();}}
 Layout& select(bool inVehicle){if(initialized&&lastVehicle!=inVehicle){(lastVehicle?vehicle:foot).finish();(inVehicle?vehicle:foot).closed=true;}initialized=true;lastVehicle=inVehicle;return inVehicle?vehicle:foot;}
 void save(){foot.save();vehicle.save();}
};
}
