#pragma once
namespace modernsurface {inline constexpr char source[]=
R"SURFACE(// Shared optical response for verified material interfaces. All radiance is HDR.
float3 modernFresnel(float3 f0,float cosine){return saturate(f0)+(1-saturate(f0))*pow(1-saturate(cosine),5);}
float modernDielectric(float cosine,float etaI,float etaT){
 float c=saturate(abs(cosine)),eta=etaI/max(etaT,.001),k=1-eta*eta*(1-c*c);if(k<=0)return 1;
 float t=sqrt(k),s=(etaI*c-etaT*t)/max(etaI*c+etaT*t,1e-7),p=(etaT*c-etaI*t)/max(etaT*c+etaI*t,1e-7);return saturate((s*s+p*p)*.5);
}
float3 modernBeer(float3 absorption,float distance){return exp(-max(absorption,0)*max(distance,0));}
float modernLightRange(float distance,float range){float q=saturate(distance/max(range,.001)),window=1-q*q*q*q;return window*window/max(distance*distance,1);}
float modernNativeLightRange(float distance,float offset,float scale){return scale>1e-7&&offset>0?modernLightRange(distance,offset/scale):saturate(offset-distance*scale);}
// Preserve authored normal-incidence opacity, increasing optical path at grazing.
float modernGlassOpacity(float opacity,float cosine,float ior){
 if(opacity>=1)return 1;float eta=1/max(ior,1.001),ct=sqrt(max(1-eta*eta*(1-saturate(cosine*cosine)),.0001));
 float base=pow(max(1-saturate(opacity),1e-6),1/ct);float f=modernDielectric(cosine,1,ior),normal=modernDielectric(1,1,ior);
 return saturate(1-base*(1-f)/max(1-normal,.001));
}

Texture2D<float2> modernMaterial0:register(t25),modernMaterial1:register(t26),modernMaterial2:register(t27),modernMaterial3:register(t28);
float3 modernMaterialMap(float2 uv,int layer,SamplerState state){
 uint w,h;float2 value;
 if(layer==0){modernMaterial0.GetDimensions(w,h);if(!w)return 0;value=modernMaterial0.Sample(state,uv);}
 else if(layer==1){modernMaterial1.GetDimensions(w,h);if(!w)return 0;value=modernMaterial1.Sample(state,uv);}
 else if(layer==2){modernMaterial2.GetDimensions(w,h);if(!w)return 0;value=modernMaterial2.Sample(state,uv);}
 else {modernMaterial3.GetDimensions(w,h);if(!w)return 0;value=modernMaterial3.Sample(state,uv);}
 return float3(value,1);
}
void modernApplyMaterialMap(float3 estimate,inout float roughness,inout float reflectivity){
 if(estimate.z<=0)return;float2 value=estimate.xy/max(estimate.z,1e-5);float confidence=saturate(estimate.z);
 // Authored material response bounds the texture-derived approximation.
 roughness=lerp(roughness,max(roughness*.65,value.y),confidence*.5);
 reflectivity=lerp(reflectivity,max(reflectivity*.5,value.x*.35),confidence);
}

// Shared by replacement materials. Camera math stays renderer-relative;
// probe locations are absolute world positions. No headset-space lighting.
cbuffer ModernWorld:register(b13){float4 reflectionControl;row_major float4x4 modernInverseClip;float4 modernEye;float4 modernViewport;float4 modernOrigin;float4 modernGrid;float4 modernGridLayout;float4 modernReflectionCenter;float4 modernReflectionBounds;};
TextureCube<float4> modernEnvironment:register(t16);
Texture2D<float2> modernBRDF:register(t17);
Texture2D<float4> modernProbes:register(t18);
float3 modernUnit(float3 v){return v*rsqrt(max(dot(v,v),1e-12));}
float4 modernIrradiance(float3 world,float3 normal){
 float size=modernGridLayout.x;float3 q=(world-modernGrid.xyz)/max(modernGrid.w,.25);
 if(modernGridLayout.y<.5||size<2||any(q<0)||any(q>size-1))return 0;
 int3 cell=min(int3(floor(q)),int(size)-2);float3 f=q-float3(cell);normal=modernUnit(normal);
 float basis[9]={.2820947918,.4886025119*normal.y,.4886025119*normal.z,.4886025119*normal.x,1.0925484306*normal.x*normal.y,1.0925484306*normal.y*normal.z,.3153915653*(3*normal.z*normal.z-1),1.0925484306*normal.x*normal.z,.5462742153*(normal.x*normal.x-normal.y*normal.y)};
 float3 sum=0;float total=0;
 [unroll]for(int z=0;z<2;++z)[unroll]for(int y=0;y<2;++y)[unroll]for(int x=0;x<2;++x){
  int3 node=cell+int3(x,y,z);int row=(node.z*int(size)+node.y)*int(size)+node.x;
  if(modernProbes.Load(int3(15,row,0)).x<.5)continue;
  float weight=(x?f.x:1-f.x)*(y?f.y:1-f.y)*(z?f.z:1-f.z);float3 delta=world-(modernGrid.xyz+float3(node)*modernGrid.w);float distance=length(delta);float3 axis=abs(delta);int face=axis.x>=axis.y&&axis.x>=axis.z?(delta.x>=0?0:1):axis.y>=axis.z?(delta.y>=0?2:3):(delta.z>=0?4:5);
  float2 moment=modernProbes.Load(int3(9+face,row,0)).xy;
  if(distance>moment.x+.05){float variance=max(moment.y-moment.x*moment.x,0);float difference=distance-moment.x;float p=variance/max(variance+difference*difference,1e-10);weight*=p*p*p;}
  float3 light=0;[unroll]for(int k=0;k<9;++k)light+=modernProbes.Load(int3(k,row,0)).rgb*basis[k];sum+=max(light,0)*weight;total+=weight;
 }
 return total>1e-6?float4(sum/total,saturate(total)):0;
}
float3 modernAmbient(float4 pixel,float2 uv,float3 tangentNormal,float4 normalHint,float3 nativeAmbient,float3 diffuseFactor){
 [branch]if(modernEye.w<.5||modernGridLayout.y<.5)return nativeAmbient;
 float4 locationH=mul(modernInverseClip,float4(pixel.xy/modernViewport.xy*float2(2,-2)+float2(-1,1),pixel.z,1));if(abs(locationH.w)<1e-8)return nativeAmbient;
 float3 relative=locationH.xyz/locationH.w;float3 dx=ddx(relative),dy=ddy(relative);float3 N=modernUnit(cross(dx,dy));if(dot(N,modernEye.xyz-relative)<0)N=-N;
 float2 tx=ddx(uv),ty=ddy(uv);float3 a=cross(dy,N),b=cross(N,dx);float3 T=a*tx.x+b*ty.x,B=a*tx.y+b*ty.y;float scale=rsqrt(max(max(dot(T,T),dot(B,B)),1e-12));
 float3 worldNormal=normalHint.w>.5?modernUnit(normalHint.xyz):modernUnit((T*tangentNormal.x+B*tangentNormal.y)*scale+N*tangentNormal.z);
 float4 probe=modernIrradiance(relative+modernOrigin.xyz,worldNormal);
 // Captures contain true HDR radiance; native material targets store 1/8.
 float3 bounce=max(diffuseFactor,0)*probe.rgb*(.125/3.14159265359);
 return lerp(nativeAmbient,bounce,probe.a);
}
// Finite local box projection is an approximation, not a scene ray query.
float3 modernReflectionDirection(float4 pixel,float3 direction){
 [branch]if(modernEye.w<.5||modernReflectionCenter.w<.5||any(modernReflectionBounds.xyz<=0))return direction;
 float4 locationH=mul(modernInverseClip,float4(pixel.xy/max(modernViewport.xy,1)*float2(2,-2)+float2(-1,1),pixel.z,1));
 if(abs(locationH.w)<1e-8)return direction;
 float3 relative=locationH.xyz/locationH.w+(modernOrigin.xyz-modernReflectionCenter.xyz),bounds=modernReflectionBounds.xyz;
 if(any(abs(relative)>=bounds))return direction;
 float3 safe=float3(abs(direction.x)<1e-6?(direction.x<0?-1e-6:1e-6):direction.x,abs(direction.y)<1e-6?(direction.y<0?-1e-6:1e-6):direction.y,abs(direction.z)<1e-6?(direction.z<0?-1e-6:1e-6):direction.z);
 float3 distance=(sign(safe)*bounds-relative)/safe;
 float exitDistance=min(distance.x,min(distance.y,distance.z));
 return modernUnit(relative+direction*exitDistance);
}
float3 modernSpecular(float4 position,float3 direction,float roughness,float nv,float3 f0,SamplerState state){
 uint width,height;modernBRDF.GetDimensions(width,height);int2 pixel=min(int2(saturate(float2(nv,roughness))*float2(width,height)),int2(width,height)-1);float2 brdf=modernBRDF.Load(int3(max(pixel,0),0));return max(modernEnvironment.SampleLevel(state,modernReflectionDirection(position,direction),roughness*reflectionControl.z).rgb,0)*(f0*brdf.x+brdf.y)*reflectionControl.y;
}



cbuffer Common:register(b0){float4 common[11];};cbuffer Light:register(b1){float4 lighting[3];};cbuffer Material:register(b2){float4 material[MATERIAL_ROWS];};cbuffer Instance:register(b6){float4 tint;float4 alphaControl;};
Texture2D<float4> diffuseMap:register(DIFF_T),normalMap:register(NORMAL_T),specularMap:register(SPEC_T),decal1:register(DECAL1_T),decal2:register(DECAL2_T),environmentMap:register(ENV_T),shadowMap:register(t15);
SamplerState diffuseSampler:register(DIFF_S),normalSampler:register(NORMAL_S),specularSampler:register(SPEC_S),decal1Sampler:register(DECAL1_S),decal2Sampler:register(DECAL2_S),environmentSampler:register(ENV_S),shadowSampler:register(s15);
#if LAYOUT==1
struct In{float4 position:SV_Position;float3 toLight:TEXCOORD0;float3 toEye:TEXCOORD1;float4 up)SURFACE"
R"SURFACE(Fog:TEXCOORD2;float4 uvCombined:TEXCOORD3;};
#elif LAYOUT==2
struct In{float4 position:SV_Position;float2 decalUV:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float4 upFog:TEXCOORD3;float4 uvCombined:TEXCOORD4;};
#else
struct In{float4 position:SV_Position;float2 uv:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float4 upFog:TEXCOORD3;};
#endif
float3 unit(float3 v){return v*rsqrt(max(dot(v,v),1e-8));}float3 fresnel(float3 f0,float nv){return modernFresnel(f0,nv);}
float2 tiling(float u,float v){
#if ZERO_TILING_DEFAULT
return float2(u==0?1:u,v==0?1:v);
#else
return float2(u,v);
#endif
}
float4 main(In i):SV_Target{
#if LAYOUT==0
 float2 uv=i.uv;
#else
 float2 uv=i.uvCombined.xy;
#endif
 float4 texel=diffuseMap.Sample(diffuseSampler,uv*tiling(M_DIFF_U,M_DIFF_V));float3 base=max(texel.rgb*M_COLOUR.rgb,0);
#if DECALS>0
 #if LAYOUT==2
 float2 uv1=i.decalUV;
 #else
 float2 uv1=i.uvCombined.zw;
 #endif
 float4 overlay=decal1.Sample(decal1Sampler,uv1);base=lerp(base,overlay.rgb,saturate(overlay.a*M_DECAL1));
#endif
#if DECALS>1
 float4 overlay2=decal2.Sample(decal2Sampler,i.uvCombined.zw);base=lerp(base,overlay2.rgb,saturate(overlay2.a*M_DECAL2));
#endif
 if(alphaControl.y!=0)clip(texel.a-alphaControl.x);
 float4 encoded=normalMap.Sample(normalSampler,uv*tiling(M_NORMAL_U,M_NORMAL_V));float2 xy=float2((encoded.r*2-1)*(encoded.a*2-1),encoded.g*2-1);float3 N=unit(lerp(float3(0,0,1),float3(xy,sqrt(saturate(1-dot(xy,xy)))),M_NORMAL));
 float3 L=unit(i.toLight),V=unit(i.toEye),H=unit(L+V);float nl=saturate(dot(N,L)),nv=max(saturate(dot(N,V)),.001),nh=saturate(dot(N,H)),vh=saturate(dot(V,H));
#if HAS_SPEC
 float3 specular=specularMap.Sample(specularSampler,uv*tiling(M_SPEC_U,M_SPEC_V)).rgb*M_SPEC_COLOUR.rgb*max(M_SPEC_ALPHA,0);
#else
 float3 specular=0;
#endif
 // Blinn power maps to GGX alpha, not perceptual roughness. GGX squares
 // perceptual roughness below, so use the fourth root exactly once here.
 float metal=saturate(M_METAL);float3 specularMask=lerp(saturate(specular),1,metal);float3 f0=lerp(float3(.04,.04,.04),min(base,.95),metal);float roughness=clamp(pow(2/(max(M_POWER,1)+2),.25),.18,.98);float mapStrength=1;modernApplyMaterialMap(modernMaterialMap(uv*tiling(M_DIFF_U,M_DIFF_V),0,diffuseSampler),roughness,mapStrength);specularMask*=lerp(mapStrength,1,metal);float a=roughness*roughness,a2=a*a,den=nh*nh*(a2-1)+1;
 float distribution=a2/(3.14159265*max(den*den,1e-7));float visibility=.5/max(nl*sqrt(nv*nv*(1-a2)+a2)+nv*sqrt(nl*nl*(1-a2)+a2),1e-5);float3 F=fresnel(f0,vh)*specularMask;float3 colour=((1-F)*(1-metal)*base/3.14159265+distribution*visibility*F)*nl*max(lighting[0].rgb,0);
 #if HAS_SHADOW
 float2 shadow=shadowMap.Sample(shadowSampler,i.position.xy*common[6].zw).rg;
 #else
 float2 shadow=1;
 #endif
 colour*=saturate(shadow.y);
#if LOCAL_LIGHT
 float attenuation=modernNativeLightRange(length(i.toLight),lighting[1].x,lighting[1].y);float spot=max(min(dot(-L,i.upFog.xyz),lighting[2].x)-lighting[2].y,0)*lighting[2].z;colour*=attenuation*(lighting[2].w>0?saturate(spot):1);colour*=1-saturate(i.upFog.w);
#else
 float hemi=saturate(dot(N,unit(i.upFog.xyz))*.5+.5);float3 irradiance=lerp(max(common[3].rgb,0),max(common[2].rgb,0),hemi);float3 ambientF=fresnel(f0,nv)*specularMask;colour+=modernAmbient(i.position,uv,N,float4(0,0,0,0),((1-ambientF)*(1-metal)*base+ambientF*(1-.7*roughness))*irradiance*saturate(shadow.x),(1-ambientF)*(1-metal)*base*saturate(shadow.x));colour+=base*max(M_SELF,0)*4;
 #if ENVIRONMENT
 uint w,h,levels;environmentMap.GetDimensions(0,w,h,levels);float4 reflection=environmentMap.SampleLevel(environmentSampler,i.uvCombined.zw,roughness*max(float(levels)-1,0));colour+=max(reflection.rgb,0)*ambientF*saturate(M_ENV_ALPHA*reflection.a)*saturate(shadow.x);
 #endif
 colour=lerp(colour,max(common[4].rgb,0),saturate(i.upFog.w));
#endif
 return float4(max(colour,0),texel.a)*tint;
}

)SURFACE";}
