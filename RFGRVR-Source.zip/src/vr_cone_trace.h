#pragma once
#include <d3d11_1.h>
#include <wrl/client.h>
#include <atomic>
#include <mutex>
#include <vector>
#include <cstdio>
#include <cstring>
#include <algorithm>
// Bounded, opt-in observation of the native light-cone draw. No replacement
// shader, light changes, pipeline rebinding or GPU waits in the render worker.
namespace vrconetrace {
using Microsoft::WRL::ComPtr;
inline constexpr GUID shaderTag={0x68f77d19,0x6ab4,0x4a09,{0x82,0x77,0x63,0x6f,0x6e,0x65,0x01,0x01}};
inline unsigned kind(const void* bytes,SIZE_T size){
 if(!bytes||size<32||memcmp(bytes,"DXBC",4))return 0;
 struct Signature{SIZE_T size;unsigned digest[4];};
 static constexpr Signature signatures[]={{2456,{200586908,1414673262,1319785125,2826508402}},{2416,{3288495962,1750389382,2146197923,849536815}},{2564,{3576496279,2906461499,1516766257,4001310062}}};
 for(unsigned i=0;i<3;++i)if(size==signatures[i].size&&!memcmp((const char*)bytes+4,signatures[i].digest,16))return i+1;
 return 0;
}
inline void tag(ID3D11VertexShader* shader,const void* bytes,SIZE_T size){unsigned k=kind(bytes,size);if(shader&&k)shader->SetPrivateData(shaderTag,4,&k);}
inline std::atomic<unsigned> shaders{0},draws{0};inline std::atomic<int> eye{-1};
inline std::atomic<bool> active{false};inline float expected[2][3]{};
struct Copy {ComPtr<ID3D11Buffer> buffer;UINT first=0,count=0;};
struct Row {DWORD tick;int eye;unsigned kind;float expected[3];Copy common,instance;};
inline std::mutex guard;inline std::vector<Row> pending;inline unsigned accepted=0,completed=0;inline DWORD nextDraw=0,deadline=0,nextCheck=0;
inline Copy copy(ID3D11DeviceContext* c,UINT slot){
 Copy result;ComPtr<ID3D11Buffer> source;ComPtr<ID3D11DeviceContext1> newer;
 if(SUCCEEDED(c->QueryInterface(IID_PPV_ARGS(&newer))))newer->VSGetConstantBuffers1(slot,1,&source,&result.first,&result.count);else c->VSGetConstantBuffers(slot,1,&source);
 if(!source)return result;D3D11_BUFFER_DESC desc{};source->GetDesc(&desc);
 if(desc.ByteWidth<16||desc.ByteWidth>1024*1024)return result;
 if(result.first>=desc.ByteWidth/16)return result;
 result.count=result.count?(std::min)(result.count,desc.ByteWidth/16-result.first):desc.ByteWidth/16-result.first;
 desc.Usage=D3D11_USAGE_STAGING;desc.BindFlags=desc.MiscFlags=desc.StructureByteStride=0;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
 ComPtr<ID3D11Device> d;c->GetDevice(&d);if(FAILED(d->CreateBuffer(&desc,nullptr,&result.buffer)))return result;
 c->CopyResource(result.buffer.Get(),source.Get());return result;
}
inline void draw(ID3D11DeviceContext* c){
 if(!active.load(std::memory_order_relaxed)||eye.load()<0)return;
 ComPtr<ID3D11VertexShader> shader;c->VSGetShader(&shader,nullptr,nullptr);unsigned k=0;UINT n=4;
 if(!shader||FAILED(shader->GetPrivateData(shaderTag,&n,&k))||!k)return;
 ++draws;std::lock_guard<std::mutex> lock(guard);DWORD now=GetTickCount();int e=eye.load();
 if(e<0||e>1||accepted>=32||LONG(now-nextDraw)<0)return;
 Row r{};r.tick=now;r.eye=e;r.kind=k;memcpy(r.expected,expected[e],12);r.common=copy(c,0);r.instance=copy(c,6);
 if(!r.common.buffer)return;pending.push_back(std::move(r));++accepted;nextDraw=now+150;
}
inline bool read(ID3D11DeviceContext* c,Copy& copy,float* out,unsigned floats){
 if(!copy.buffer)return true;D3D11_MAPPED_SUBRESOURCE mapped{};
 if(FAILED(c->Map(copy.buffer.Get(),0,D3D11_MAP_READ,D3D11_MAP_FLAG_DO_NOT_WAIT,&mapped)))return false;
 const unsigned available=copy.count*4;memcpy(out,(char*)mapped.pData+copy.first*16,(std::min)(floats,available)*4);c->Unmap(copy.buffer.Get(),0);return true;
}
inline void present(ID3D11DeviceContext* c){
 DWORD now=GetTickCount();if(!active.load()&&LONG(now-nextCheck)>=0){nextCheck=now+500;
  if(GetFileAttributesW(L"RFGRVR-cone-trace.enable")!=INVALID_FILE_ATTRIBUTES){DeleteFileW(L"RFGRVR-cone-trace.enable");std::lock_guard<std::mutex> lock(guard);pending.clear();accepted=completed=0;nextDraw=now;deadline=now+30000;DeleteFileW(L"RFGRVR-Cone-Trace.csv");active=true;}
 }
 if(!active.load())return;std::lock_guard<std::mutex> lock(guard);if(!c&&!pending.empty())return;
 for(size_t i=0;i<pending.size();){auto& r=pending[i];float common[64]{},instance[20]{};
  if(!read(c,r.common,common,64)||!read(c,r.instance,instance,20)){++i;continue;}
  FILE* f=nullptr;if(!fopen_s(&f,"RFGRVR-Cone-Trace.csv","a")&&f){
   if(!completed)fputs("tick,eye,shader,expected_x,expected_y,expected_z,common_first,instance_first,common64_then_instance20\n",f);
   fprintf(f,"%lu,%d,%u,%.6f,%.6f,%.6f,%u,%u",r.tick,r.eye,r.kind,r.expected[0],r.expected[1],r.expected[2],r.common.first,r.instance.first);
   for(float x:common)fprintf(f,",%.7g",x);for(float x:instance)fprintf(f,",%.7g",x);fputc('\n',f);fclose(f);
  }++completed;pending.erase(pending.begin()+i);
 }
 if((accepted>=32&&pending.empty())||LONG(now-deadline)>=0){pending.clear();active=false;}
}
}
