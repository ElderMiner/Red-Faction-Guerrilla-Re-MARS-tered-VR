#pragma once
#include "modern_scene_lights.h"
#include <array>
namespace modernoptics {
struct V {float x=0,y=0,z=0;};
inline V add(V a,V b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
inline V mul(V a,float b){return {a.x*b,a.y*b,a.z*b};}
inline V product(V a,V b){return {a.x*b.x,a.y*b.y,a.z*b.z};}
inline float dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline V unit(V a){float d=std::sqrt(dot(a,a));return d>1e-7f?mul(a,1/d):V{};}
inline float clamp(float v){return (std::clamp)(v,0.f,1.f);}
enum class Material {Rock,Sand,Concrete,Paint,Metal,Glass,Water};
// Optical properties describe a surface response, not replacement geometry.
// Authoring values are defaults; verified per-material maps override them.
struct Profile {float ior=1.5f,roughness=.8f,metal=0,transmission=0;V albedo{.5f,.5f,.5f},f0{.04f,.04f,.04f},absorption{};};
inline Profile profile(Material material){Profile p;switch(material){
 case Material::Sand:p.roughness=.95f;break;
 case Material::Rock:p.roughness=.85f;break;
 case Material::Concrete:p.roughness=.9f;break;
 case Material::Paint:p.roughness=.45f;break;
 case Material::Metal:p.roughness=.3f;p.metal=1;p.f0={.7f,.7f,.7f};break;
 case Material::Glass:p.roughness=.08f;p.transmission=1;p.absorption={.02f,.01f,.005f};break;
 case Material::Water:p.ior=1.333f;p.roughness=.1f;p.transmission=1;p.absorption={.2f,.06f,.025f};break;
 }return p;}
inline float dielectric(float cosine,float incidentIOR,float transmittedIOR){
 if(!std::isfinite(cosine)||!std::isfinite(incidentIOR)||!std::isfinite(transmittedIOR)||incidentIOR<=0||transmittedIOR<=0)return 1;
 float c=clamp(std::abs(cosine)),eta=incidentIOR/transmittedIOR,k=1-eta*eta*(1-c*c);if(k<=0)return 1;float t=std::sqrt(k);
 float s=(incidentIOR*c-transmittedIOR*t)/(incidentIOR*c+transmittedIOR*t),p=(transmittedIOR*c-incidentIOR*t)/(transmittedIOR*c+incidentIOR*t);return clamp((s*s+p*p)*.5f);
}
inline V beer(V absorption,float distance){distance=(std::max)(distance,0.f);return {std::exp(-(std::max)(absorption.x,0.f)*distance),std::exp(-(std::max)(absorption.y,0.f)*distance),std::exp(-(std::max)(absorption.z,0.f)*distance)};}
inline float falloff(float distance,float range){if(!std::isfinite(distance)||!std::isfinite(range)||range<=0||distance>=range)return 0;distance=(std::max)(distance,0.f);float q=distance/range,window=clamp(1-q*q*q*q);return window*window/(std::max)(distance*distance,1.f);}
enum class Kind {Reflection,Diffuse,Transmission};
struct Lobe {Kind kind;V direction,energy;float spread;uint64_t sourceId=0,surfaceId=0;};
struct Interaction {std::array<Lobe,3> lobes{};unsigned count=0;V absorbed{};};
// A bounded transport description. The native renderer must supply verified
// surface hits and occlusion before turning these into cached secondary lights.
inline Interaction interact(const Profile& p,V incident,V normal,V incomingEnergy,float thickness,uint64_t sourceId=0,uint64_t surfaceId=0){
 Interaction out;incident=unit(incident);normal=unit(normal);if(dot(incident,incident)<.5f||dot(normal,normal)<.5f)return out;
 if(!std::isfinite(thickness)||thickness<0||!std::isfinite(p.ior)||p.ior<1||p.ior>4)return out;
 for(float v:{incomingEnergy.x,incomingEnergy.y,incomingEnergy.z,p.roughness,p.metal,p.transmission,p.albedo.x,p.albedo.y,p.albedo.z,p.f0.x,p.f0.y,p.f0.z,p.absorption.x,p.absorption.y,p.absorption.z})if(!std::isfinite(v)||v<0)return out;
 bool entering=dot(incident,normal)<0;if(!entering)normal=mul(normal,-1);float cosine=clamp(-dot(incident,normal));
 V energy=mul(incomingEnergy,cosine);float etaI=entering?1:p.ior,etaT=entering?p.ior:1,eta=etaI/etaT;
 float f=dielectric(cosine,etaI,etaT),g=std::pow(1-cosine,5.f),metal=clamp(p.metal),transmission=clamp(p.transmission);
 V F{f*(1-metal)+(clamp(p.f0.x)+(1-clamp(p.f0.x))*g)*metal,f*(1-metal)+(clamp(p.f0.y)+(1-clamp(p.f0.y))*g)*metal,f*(1-metal)+(clamp(p.f0.z)+(1-clamp(p.f0.z))*g)*metal};
 V reflected=product(energy,F),remaining=product(energy,{1-F.x,1-F.y,1-F.z});
 auto push=[&](Kind kind,V direction,V value,float spread){if(value.x+value.y+value.z>1e-8f)out.lobes[out.count++]={kind,unit(direction),value,spread,sourceId,surfaceId};};
 push(Kind::Reflection,add(incident,mul(normal,2*cosine)),reflected,clamp(p.roughness));
 V diffuse=mul(product(remaining,{clamp(p.albedo.x),clamp(p.albedo.y),clamp(p.albedo.z)}),(1-metal)*(1-transmission));push(Kind::Diffuse,normal,diffuse,1);
 float k=1-eta*eta*(1-cosine*cosine);V transmitted{};if(k>0){float cosineT=std::sqrt(k);transmitted=mul(product(remaining,beer(p.absorption,thickness/(std::max)(cosineT,.02f))),(1-metal)*transmission);push(Kind::Transmission,add(mul(incident,eta),mul(normal,eta*cosine-cosineT)),transmitted,clamp(p.roughness));}
 out.absorbed={energy.x-reflected.x-diffuse.x-transmitted.x,energy.y-reflected.y-diffuse.y-transmitted.y,energy.z-reflected.z-diffuse.z-transmitted.z};return out;
}
}
