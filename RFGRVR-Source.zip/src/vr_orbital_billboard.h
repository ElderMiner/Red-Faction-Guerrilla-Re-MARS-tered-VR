#pragma once
#include "vr_arm_math.h"
// The native orbital record stores a sky-relative direction at +0x10.
// Its image plane must follow that world direction, never camera roll.
inline bool RFGRVR_OrbitalBillboard(vrarm::V direction,vrarm::M& out){
 using namespace vrarm;
 if(!finite(direction)||length(direction)<.001f)return false;
 V f=unit(direction),pole{0,1,0};
 if(fabsf(dot(f,pole))>.999f)pole={0,0,1};
 V r=unit(cross(pole,f)),u=unit(cross(f,r));out={r,u,f};return valid(out);
}
