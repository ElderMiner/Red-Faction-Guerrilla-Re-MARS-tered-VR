cbuffer Common:register(b0){float4 common[11];};cbuffer Light:register(b1){float4 lighting[3];};
#if TYPE==5
cbuffer Material:register(b7){float4 material[ROWS];};
#else
cbuffer Material:register(b2){float4 material[ROWS];};
#endif
cbuffer Instance:register(b6){float4 tint;float4 alphaControl;};
Texture2D<float4> maps[16]:register(t0);SamplerState samplers[16]:register(s0);
#if TYPE==5
struct In{float4 position:SV_Position;float4 edgeUV:TEXCOORD0;float4 light:TEXCOORD1;float4 eyeFog:TEXCOORD2;float4 uv0Mask:TEXCOORD4;float4 uv12:TEXCOORD5;float4 rotation:TEXCOORD6;float3 aux:TEXCOORD7;};
#elif TYPE==2
struct In{float4 position:SV_Position;float4 uv0:TEXCOORD0;float4 uv1:TEXCOORD1;float2 blendUV:TEXCOORD2;float4 light:TEXCOORD3;float4 upFog:TEXCOORD4;
 #if EYE
 float3 eye:TEXCOORD6;float4 geometry:TEXCOORD7;
 #endif
};
#elif TYPE==3
struct In{float4 position:SV_Position;float4 uv:TEXCOORD0;float2 blend:TEXCOORD1;float4 light:TEXCOORD2;float4 upFog:TEXCOORD4;float3 eye:TEXCOORD6;};
#elif TYPE==4
struct In{float4 position:SV_Position;float3 eye:TEXCOORD0;float4 light:TEXCOORD1;float4 uv:TEXCOORD2;
#if LOCAL
float4 upFog:TEXCOORD4;
#else
float4 upFog:TEXCOORD3;float3 worldNormal:TEXCOORD5;float3 worldBitangent:TEXCOORD6;float3 worldTangent:TEXCOORD7;
#endif
};
#else
struct In{float4 position:SV_Position;float4 uv:TEXCOORD0;float4 light:TEXCOORD1;float4 upFog:TEXCOORD4;float3 eye:TEXCOORD6;};
#endif
float3 unit(float3 v){return v*rsqrt(max(dot(v,v),1e-10));}
float3 unpack(float4 value){float2 xy=float2((value.r*2-1)*(value.a*2-1),value.g*2-1);return float3(xy,sqrt(saturate(1-dot(xy,xy))));}
#if TYPE==5
#define UP_FOG input.eyeFog
#define HEMI_AXIS input.aux
#else
#define UP_FOG input.upFog
#define HEMI_AXIS input.upFog.xyz
#endif
float4 main(In input):SV_Target{
 float3 estimate=0;float3 base,N;float specular=0,roughness=.8,alpha=1;float3 f0=.04;float3 specularMask=1;float3 L=unit(input.light.xyz),V;
 #if TYPE==5
 float2 uv[4]={input.uv0Mask.xy,input.uv12.xy,input.uv12.zw,abs(input.edgeUV.xy)};float4 albedo[4];float3 normals[4];
 [unroll]for(uint layer=0;layer<4;++layer){albedo[layer]=maps[4+layer].Sample(samplers[4+layer],uv[layer]);normals[layer]=unpack(maps[layer].Sample(samplers[layer],uv[layer]));}

 float3 paint=saturate(maps[8].Sample(samplers[8],input.uv0Mask.zw).rgb);float overlayAlpha=saturate(input.edgeUV.z)*saturate(albedo[3].a+material[8].z)*saturate((1-abs(input.edgeUV.w))*material[8].x+material[8].y);float4 weights;
 #if DECAL==0
 weights=float4((1-paint.b)*(1-paint.g)*(1-paint.r),paint.b*(1-paint.g)*(1-paint.r),paint.g*(1-paint.r),overlayAlpha);
 #elif DECAL==1
 weights=float4((1-paint.b)*(1-overlayAlpha)*(1-paint.g),paint.b*(1-overlayAlpha)*(1-paint.g),paint.g,overlayAlpha*(1-paint.g));
 #else
 weights=float4((1-overlayAlpha)*(1-paint.b)*(1-paint.g),paint.b*(1-paint.g),paint.g,overlayAlpha*(1-paint.b)*(1-paint.g));
 #endif
 float3 detail;[unroll]for(uint k=0;k<3;++k)detail[k]=saturate((maps[1+k].Sample(samplers[1+k],uv[1+k]*material[1].x).r+material[1].z-.5)*material[1].y+.5);float4 modulation=float4(1-saturate(detail.x+detail.y+detail.z),detail);float4 adjusted=lerp(2*weights*modulation,1-2*(1-weights)*(1-modulation),step(.5,weights));weights=max(lerp(weights,adjusted,saturate(material[1].w)),0);float total=dot(weights,1);weights=total>1e-6?weights/total:float4(1,0,0,0);
 [unroll]for(uint layer=0;layer<4;++layer){float2 gradX=ddx(uv[layer]),gradY=ddy(uv[layer]);float2 shifted=modernRelief(input.position,uv[layer],layer,weights[layer],samplers[layer]);[branch]if(any(shifted!=uv[layer])){albedo[layer]=maps[4+layer].SampleGrad(samplers[4+layer],shifted,gradX,gradY);normals[layer]=unpack(maps[layer].SampleGrad(samplers[layer],shifted,gradX,gradY));}}
 normals[3].xy=float2(normals[3].x*input.rotation.x+normals[3].y*input.rotation.z,normals[3].x*input.rotation.y+normals[3].y*input.rotation.w);
 base=0;float3 blendedNormal=0;float4 specularAlpha;[unroll]for(uint layer=0;layer<4;++layer){estimate+=modernMaterialMap(uv[layer],layer,samplers[4+layer])*weights[layer];base+=max(albedo[layer].rgb*material[4+layer].rgb,0)*weights[layer];blendedNormal+=normals[layer]*weights[layer];specularAlpha[layer]=1-saturate(layer==3?albedo[layer].a+material[8].z-1:albedo[layer].a);}
 N=unit(blendedNormal);specular=max(dot(specularAlpha*material[2],weights),0);roughness=clamp(pow(2/(max(dot(material[3],weights),1)+2),.25),.25,.98);
 #if LOCAL
 V=unit(input.aux);
 #else
 V=unit(input.eyeFog.xyz);
 #endif
 #elif TYPE==2
 float4 weights=float4(1,0,0,0);float4 albedo=0;float3 normal=0;
 #if LAYERS==4
 float3 paint=saturate(maps[8].Sample(samplers[8],input.blendUV).rgb);weights=float4((1-paint.r)*(1-paint.g)*(1-paint.b),(1-paint.r)*(1-paint.g)*paint.b,(1-paint.r)*paint.g,paint.r);
 float3 detail=float3(maps[NBASE+1].Sample(samplers[NBASE+1],input.uv0.zw*material[0].x).r,maps[NBASE+2].Sample(samplers[NBASE+2],input.uv1.xy*material[0].x).r,maps[NBASE+3].Sample(samplers[NBASE+3],input.uv1.zw*material[0].x).r);
 detail=saturate((detail+material[0].z-.5)*material[0].y+.5);float4 modulation=float4(1-saturate(detail.x+detail.y+detail.z),detail);
 float4 overlay=lerp(2*weights*modulation,1-2*(1-weights)*(1-modulation),step(.5,weights));weights=max(lerp(weights,overlay,saturate(material[0].w)),0);float total=dot(weights,1);weights=total>1e-6?weights/total:float4(1,0,0,0);
 float2 uv[4]={input.uv0.xy,input.uv0.zw,input.uv1.xy,input.uv1.zw};
 [unroll]for(int layer=0;layer<4;++layer){float2 sourceUV=modernRelief(input.position,uv[layer],layer,weights[layer],samplers[NBASE+layer]);float2 gradX=ddx(uv[layer]),gradY=ddy(uv[layer]);estimate+=modernMaterialMap(sourceUV,layer,samplers[DBASE+layer])*weights[layer];albedo+=maps[DBASE+layer].SampleGrad(samplers[DBASE+layer],sourceUV,gradX,gradY)*float4(material[3+layer].rgb,1)*weights[layer];normal+=unpack(maps[NBASE+layer].SampleGrad(samplers[NBASE+layer],sourceUV,gradX,gradY))*weights[layer];}
 #else
 float mixProjection=saturate((abs(input.geometry.x)/max(abs(input.geometry.x)+abs(input.geometry.z),1e-6)-.45)*10);
 #if LAYERS==2
 float layerBlend=saturate((maps[0].Sample(samplers[0],input.blendUV).a*255-1)/253);weights=float4(1-layerBlend,layerBlend,0,0);
 #endif
 float2 uvA[2]={input.uv0.xy,input.uv1.xy},uvB[2]={input.uv0.zw,input.uv1.zw};
 [unroll]for(int layer=0;layer<LAYERS;++layer){float2 sourceA=modernRelief(input.position,uvA[layer],layer,weights[layer]*(1-mixProjection),samplers[NBASE+layer]),sourceB=modernRelief(input.position,uvB[layer],layer,weights[layer]*mixProjection,samplers[NBASE+layer]);float2 ax=ddx(uvA[layer]),ay=ddy(uvA[layer]),bx=ddx(uvB[layer]),by=ddy(uvB[layer]);float4 a=maps[DBASE+layer].SampleGrad(samplers[DBASE+layer],sourceA,ax,ay),b=maps[DBASE+layer].SampleGrad(samplers[DBASE+layer],sourceB,bx,by);estimate+=lerp(modernMaterialMap(sourceA,layer,samplers[DBASE+layer]),modernMaterialMap(sourceB,layer,samplers[DBASE+layer]),mixProjection)*weights[layer];albedo+=lerp(a,b,mixProjection)*float4(material[3+layer].rgb,1)*weights[layer];float3 na=unpack(maps[NBASE+layer].SampleGrad(samplers[NBASE+layer],sourceA,ax,ay)),nb=unpack(maps[NBASE+layer].SampleGrad(samplers[NBASE+layer],sourceB,bx,by));normal+=lerp(na,nb,mixProjection)*weights[layer];}
 #endif
 N=unit(normal);base=max(albedo.rgb,0);specular=max(dot(material[1],weights),0)*saturate(1-albedo.a);roughness=clamp(pow(2/(max(dot(material[2],weights),1)+2),.25),.25,.98);
 #if COMBINE
 float distant=saturate((input.light.w-290)/30);float3 combined=max(maps[9].Sample(samplers[9],input.blendUV).rgb,0);base=lerp(base,combined*combined*combined,distant);N=unit(lerp(N,float3(0,0,1),distant));specular*=1-distant;
 #endif
 #if EYE
 V=unit(input.eye);alpha=input.geometry.w;
 #else
 V=float3(0,0,1);specular=0;
 #endif
 #else
 V=unit(input.eye);
 #if TYPE==4
 float2 tiling=float2(material[1].x==0?1:material[1].x,material[1].y==0?1:material[1].y);N=unit(lerp(float3(0,0,1),unpack(maps[0].Sample(samplers[0],input.uv.xy*tiling)),material[1].z));
 float4 environment=maps[1].Sample(samplers[1],input.uv.zw);base=max(environment.rgb*environment.a,0);roughness=clamp(pow(2/(max(material[2].x,1)+2),.25),.18,.98);f0=clamp(.04*material[0].rgb,.001,.85);specular=(1-saturate(environment.a))*max(material[1].w,0);
 #if DECAL
 f0=clamp(f0*maps[4].Sample(samplers[4],input.uv.xy*tiling).rgb,.001,.85);specular*=maps[4].Sample(samplers[4],input.uv.xy*tiling).a;
 #endif
 #elif TYPE==3
 float blend=saturate(input.blend.x);estimate=lerp(modernMaterialMap(input.uv.xy,0,samplers[0]),modernMaterialMap(input.uv.zw,1,samplers[2]),blend);float4 first=maps[0].Sample(samplers[0],input.uv.xy),second=maps[2].Sample(samplers[2],input.uv.zw);base=max(lerp(first.rgb*material[0].rgb,second.rgb*material[1].rgb,blend),0);
 float3 n0=lerp(float3(0,0,1),unpack(maps[1].Sample(samplers[1],input.uv.xy)),material[2].x),n1=lerp(float3(0,0,1),unpack(maps[3].Sample(samplers[3],input.uv.zw)),material[2].y);N=unit(lerp(unit(n0),unit(n1),blend));roughness=clamp(pow(2/(max(lerp(material[3].x,material[3].y,blend),1)+2),.25),.18,.98);specular=lerp((1-saturate(first.a))*max(material[2].z,0),(1-saturate(second.a))*max(material[2].w,0),blend);
 #elif TYPE==0
 estimate=modernMaterialMap(input.uv.xy,0,samplers[0]);float4 albedo=maps[0].Sample(samplers[0],input.uv.xy);base=max(albedo.rgb,0);alpha=albedo.a;N=unit(maps[1].Sample(samplers[1],input.uv.xy).rgb*2-1);float gloss=saturate(maps[3].Sample(samplers[3],input.uv.xy).r);roughness=clamp(pow(2/(max(gloss*max(common[8].y,1)*4,1)+2),.25),.18,.98);specularMask=saturate(maps[2].Sample(samplers[2],input.uv.xy).rgb);f0=.04;
 #if DECAL
 float4 decal=maps[4].Sample(samplers[4],input.uv.zw);base=lerp(base,max(decal.rgb,0),saturate(decal.a*material[0].y));
 #endif
 specular=saturate(max(material[0].x,0)*max(common[8].x,0));
 #else
 float2 tiling=float2(material[2].x==0?1:material[2].x,material[2].y==0?1:material[2].y);estimate=modernMaterialMap(input.uv.xy*tiling,0,samplers[0]);float4 albedo=maps[0].Sample(samplers[0],input.uv.xy*tiling);base=max(albedo.rgb*material[0].rgb,0);N=unit(lerp(float3(0,0,1),unpack(maps[1].Sample(samplers[1],input.uv.xy*tiling)),material[2].z));roughness=clamp(pow(2/(max(material[3].x,1)+2),.25),.18,.98);f0=clamp(.04*material[1].rgb,.001,.85);specular=saturate(1-albedo.a)*max(material[3].y,0);
 #endif
 #endif
 modernApplyMaterialMap(estimate,roughness,specular);
 float3 H=unit(L+V);float nl=saturate(dot(N,L)),nv=max(saturate(dot(N,V)),.001),nh=saturate(dot(N,H)),vh=saturate(dot(V,H));float a=roughness*roughness,a2=a*a,den=nh*nh*(a2-1)+1;
 float D=a2/(3.14159265*max(den*den,1e-7)),G=.5/max(nl*sqrt(nv*nv*(1-a2)+a2)+nv*sqrt(nl*nl*(1-a2)+a2),1e-5);float3 F=modernFresnel(f0,vh)*specularMask*saturate(specular);float3 colour=((1-F)*base/3.14159265+D*G*F)*nl*max(lighting[0].rgb,0);
 #if LOCAL
 float attenuation=modernNativeLightRange(length(input.light.xyz),lighting[1].x,lighting[1].y);float cone=max(min(dot(-L,UP_FOG.xyz),lighting[2].x)-lighting[2].y,0)*lighting[2].z;colour*=attenuation*(lighting[2].w>0?saturate(cone):1);colour*=1-saturate(UP_FOG.w);
 #else
 float2 shadow=saturate(maps[15].Sample(samplers[15],input.position.xy*common[6].zw).rg);colour*=shadow.y;float hemi;
 #if TYPE==4
 hemi=.5;
 #else
 hemi=saturate(dot(N,unit(HEMI_AXIS))*.5+.5);
 #endif
float2 indirectUV;float4 indirectNormal=0;
 #if TYPE==2
 indirectUV=input.uv0.xy;
 #elif TYPE==5
 indirectUV=input.uv0Mask.xy;
 #else
 indirectUV=input.uv.xy;
 #endif
 #if TYPE==4
 indirectNormal=float4(unit(N.x*unit(input.worldTangent)+N.y*unit(input.worldBitangent)+N.z*unit(input.worldNormal)),1);
 #endif
 float3 diffuseFactor=base*(1-f0*specularMask*saturate(specular))*shadow.x;
 colour+=modernAmbient(input.position,indirectUV,N,indirectNormal,diffuseFactor*lerp(max(common[3].rgb,0),max(common[2].rgb,0),hemi),diffuseFactor);
 #if TYPE==1
 colour+=base*max(material[2].w,0)*4;
 #endif
 #if TYPE==4
 // Reconstruct the native dual-paraboloid environment direction from the
 // actual tangent frame, then weight it with the same Fresnel energy budget.
 float3 reflected=reflect(-V,N);float3 worldReflection=unit(reflected.x*unit(input.worldTangent)+reflected.y*unit(input.worldBitangent)+reflected.z*unit(input.worldNormal));
 float2 reflectionUV=worldReflection.xz/max(2*(1+abs(worldReflection.y)),1e-5)+.5;float3 reflectedRadiance=max(maps[2].Sample(samplers[2],reflectionUV).rgb,0)*max(maps[3].Sample(samplers[3],input.uv.xy*tiling).rgb,0);
 if(reflectionControl.x>.5){colour+=modernSpecular(input.position,worldReflection,roughness,nv,f0,samplers[0])*max(maps[3].Sample(samplers[3],input.uv.xy*tiling).rgb,0)*(1-saturate(environment.a))*shadow.x;}
 else colour+=reflectedRadiance*(f0+(1-f0)*pow(1-nv,5))*(1-saturate(environment.a))*shadow.x;
 #endif
 colour=lerp(colour,max(common[4].rgb,0),saturate(UP_FOG.w));
 #endif
 #if TYPE==5
 return float4(max(colour,0),1)*material[0];
 #elif TYPE==4
 return float4(max(colour,0),1);
 #else
 return float4(max(colour,0),alpha)*tint;
 #endif
}

