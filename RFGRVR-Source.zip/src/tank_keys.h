#pragma once
#include <windows.h>
#include <atomic>
namespace vrtankkeys {
inline std::atomic<bool> keys[512]{};
inline void clear(){for(auto& k:keys)k=false;}
inline void message(UINT m,LPARAM p){if(m==WM_KILLFOCUS){clear();return;}if(m!=WM_KEYDOWN&&m!=WM_SYSKEYDOWN&&m!=WM_KEYUP&&m!=WM_SYSKEYUP)return;unsigned scan=(unsigned(p)>>16)&255,extended=(unsigned(p)>>24)&1;keys[scan+256*extended]=(m==WM_KEYDOWN||m==WM_SYSKEYDOWN);}
inline bool down(unsigned scan,bool extended=false){return scan<256&&keys[scan+(extended?256:0)].load();}
}
