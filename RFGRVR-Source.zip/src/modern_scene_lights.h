#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <mutex>
#include <cstring>
#include "modern_visibility.h"
namespace modernscene {
// Copies of engine-uploaded lights, never pointers to owned engine objects.
struct Light {
 uint32_t kind=0;float position[3]{};float direction[3]{0,0,1};
 float innerRange=0,range=0,innerCos=1,outerCos=0;float colour[3]{};
};
inline bool valid(const Light& l){
 if(l.kind>2)return false;
 for(float x:l.position)if(!std::isfinite(x)||std::abs(x)>1e7f)return false;
 float norm=0;for(float x:l.direction){if(!std::isfinite(x))return false;norm+=x*x;}
 for(float x:l.colour)if(!std::isfinite(x)||x<0||x>1e6f)return false;
 if(l.kind!=1&&(norm<.5f||norm>1.5f))return false;
 return !l.kind||(std::isfinite(l.range)&&std::isfinite(l.innerRange)&&l.innerRange>=0&&l.range>l.innerRange&&l.range<=10000&&std::isfinite(l.innerCos)&&std::isfinite(l.outerCos)&&l.innerCos>=l.outerCos&&l.innerCos<=1&&l.outerCos>=-1);
}
// The native colour upload multiplies source RGB by a per-draw scale.
// The transport collector must not inherit a last-material/visibility scale.
inline bool sourceRadiance(const float* uploaded,float scale,float* source){
 if(!uploaded||!source||!std::isfinite(scale)||scale<=1e-6f)return false;
 float values[3];for(unsigned i=0;i<3;++i){values[i]=uploaded[i]/scale;if(!std::isfinite(values[i])||values[i]<0||values[i]>1e6f)return false;}
 memcpy(source,values,12);return true;
}
struct Snapshot {uint64_t frame=0;unsigned count=0,dropped=0;std::array<Light,64> lights{};std::array<uintptr_t,64> sources{};};
class Collector {
 std::mutex mutex;Snapshot state{};std::array<uintptr_t,64> keys{};
public:
 void begin(uint64_t frame){std::lock_guard<std::mutex> lock(mutex);if(frame==state.frame)return;state={};state.frame=frame;keys.fill(0);}
 bool submit(uintptr_t key,Light light){if(!key||!valid(light))return false;std::lock_guard<std::mutex> lock(mutex);for(unsigned i=0;i<state.count;++i)if(keys[i]==key){state.lights[i]=light;state.sources[i]=key;return true;}if(state.count==state.lights.size()){++state.dropped;if(light.kind==0)for(unsigned i=state.count;i>0;--i)if(state.lights[i-1].kind!=0){keys[i-1]=key;state.lights[i-1]=light;state.sources[i-1]=key;return true;}return false;}keys[state.count]=key;state.sources[state.count]=key;state.lights[state.count++]=light;return true;}
 Snapshot snapshot(){std::lock_guard<std::mutex> lock(mutex);return state;}
};
inline Collector collector;
struct Selection {unsigned count=0;std::array<Light,4> lights{};std::array<uintptr_t,4> sources{};};
// One directional source and the three strongest nearby local sources.
// Fixed storage, no scene registry traversal or allocations in the eye pass.
inline Selection select(const Snapshot& input,const float* eye){
 Selection result;int directional=-1;float directionalScore=-1;unsigned candidates[3]{};float scores[3]{-1,-1,-1};
 for(unsigned i=0;i<input.count&&i<input.lights.size();++i){const auto& light=input.lights[i];if(!valid(light))continue;float energy=light.colour[0]*.2126f+light.colour[1]*.7152f+light.colour[2]*.0722f;
  if(!light.kind){if(energy>directionalScore){directionalScore=energy;directional=int(i);}continue;}
  float distanceSquared=0;for(unsigned k=0;k<3;++k){float delta=light.position[k]-eye[k];distanceSquared+=delta*delta;}if(distanceSquared>(light.range+100)*(light.range+100))continue;
  float score=energy/(std::max)(distanceSquared,1.f);for(unsigned at=0;at<3;++at)if(score>scores[at]){for(unsigned j=2;j>at;--j){scores[j]=scores[j-1];candidates[j]=candidates[j-1];}scores[at]=score;candidates[at]=i;break;}
 }
 if(directional>=0){result.sources[result.count]=input.sources[directional];result.lights[result.count++]=input.lights[directional];}for(unsigned i=0;i<3;++i)if(scores[i]>0){result.sources[result.count]=input.sources[candidates[i]];result.lights[result.count++]=input.lights[candidates[i]];}return result;
}
// The first eye freezes a conservative guard-banded influence set for both
// eyes. Off-screen source centres remain eligible when their range reaches view.
inline Selection selectForView(const Snapshot& input,const float* absoluteEye,const float* rowMajorClip,const float* renderOrigin){
 modernvisibility::Frustum view;if(!view.set(rowMajorClip)||!renderOrigin)return select(input,absoluteEye);Snapshot filtered;filtered.frame=input.frame;
 for(unsigned i=0;i<input.count&&i<input.lights.size();++i){const auto& l=input.lights[i];float relative[3];for(unsigned k=0;k<3;++k)relative[k]=l.position[k]-renderOrigin[k];if(l.kind&& !view.intersects(relative,l.range))continue;filtered.sources[filtered.count]=input.sources[i];filtered.lights[filtered.count++]=l;}return select(filtered,absoluteEye);
}
inline float smooth(float t){t=(std::clamp)(t,0.f,1.f);return t*t*(3-2*t);}
inline float nightWeight(float hour){if(!std::isfinite(hour)||hour<0||hour>24)return 0;if(hour<5||hour>=19)return 1;if(hour<6)return 1-smooth(hour-5);if(hour<=18)return 0;return smooth(hour-18);}
struct Environment {float night=0,main=1,ambient=1,minimumLuminance=0,bloom=1;};
inline Environment environment(float hour){float n=nightWeight(hour);return {n,1-.90f*n,1-.82f*n,.35f*n,1-.45f*n};}
inline thread_local const Environment* current=nullptr;
struct Frame {Environment value;const Environment* previous;Frame(bool active,float hour):value(environment(hour)),previous(current){if(active&&!previous)current=&value;}~Frame(){current=previous;}};
// Verified rl_hdr_state fields: maximum/minimum metered luminance at 0x20/24.
// A floor on measured luminance prevents adaptation from turning moonlight
// into daylight. Actual lamp/headlight intensities are never reduced here.
inline bool patchHDR(const float* input,float* output,const Environment& e){
 if(e.night<=0)return false;float maximum=input[8],minimum=input[9];
 if(!std::isfinite(maximum)||!std::isfinite(minimum)||maximum<=0||minimum<0||minimum>maximum)return false;
 memcpy(output,input,0x68);output[9]=(std::max)(minimum,e.minimumLuminance);output[8]=(std::max)(maximum,output[9]);return output[9]!=minimum;
}
inline float phase(float cosine,float anisotropy){float g=(std::clamp)(anisotropy,-.9f,.9f),den=(std::max)(1+g*g-2*g*(std::clamp)(cosine,-1.f,1.f),.001f);return (1-g*g)/(12.5663706144f*den*std::sqrt(den));}
inline float transmittance(float extinction,float distance){return std::exp(-(std::max)(extinction,0.f)*(std::max)(distance,0.f));}
}
