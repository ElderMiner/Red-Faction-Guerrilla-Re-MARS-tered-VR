#pragma once
// Verified native shader identities/bindings; no extracted bytecode.
namespace modernsurface {
inline constexpr const char* macroNames[]={"MATERIAL_ROWS","LAYOUT","LOCAL_LIGHT","DIFF_T","DIFF_S","NORMAL_T","NORMAL_S","SPEC_T","SPEC_S","HAS_SPEC","DECAL1_T","DECAL1_S","DECAL2_T","DECAL2_S","DECALS","ENV_T","ENV_S","ENVIRONMENT","M_COLOUR","M_SPEC_COLOUR","M_NORMAL","M_SELF","M_METAL","M_POWER","M_SPEC_ALPHA","M_DECAL1","M_DECAL2","M_ENV_ALPHA","M_DIFF_U","M_DIFF_V","M_NORMAL_U","M_NORMAL_V","M_SPEC_U","M_SPEC_V","ZERO_TILING_DEFAULT","HAS_SHADOW"};
struct Variant {const char* values[36];};
inline constexpr Variant variants[]={
 {{"5","0","0","t0","s0","t1","s1","t2","s2","1","t13","s13","t12","s12","0","t11","s11","0","material[0]","material[1]","material[2].z","material[3].y","0","material[4].y","material[3].z","0","0","0","material[2].x","material[2].y","material[2].w","material[3].x","material[3].w","material[4].x","1","1"}},
 {{"5","0","1","t0","s0","t1","s1","t2","s2","1","t13","s13","t12","s12","0","t11","s11","0","material[0]","material[1]","material[2].z","material[3].y","0","material[4].y","material[3].z","0","0","0","material[2].x","material[2].y","material[2].w","material[3].x","material[3].w","material[4].x","1","0"}},
 {{"3","0","0","t0","s0","t1","s1","t14","s14","0","t13","s13","t12","s12","0","t11","s11","0","material[0]","float4(1,1,1,1)","material[1].z","material[2].y","0","16","1","0","0","0","material[1].x","material[1].y","material[1].w","material[2].x","1","1","1","1"}},
 {{"3","0","1","t0","s0","t1","s1","t14","s14","0","t13","s13","t12","s12","0","t11","s11","0","material[0]","float4(1,1,1,1)","material[1].z","material[2].y","0","16","1","0","0","0","material[1].x","material[1].y","material[1].w","material[2].x","1","1","1","0"}},
 {{"4","0","0","t2","s2","t0","s0","t1","s1","1","t13","s13","t12","s12","0","t11","s11","0","material[0]","material[1]","material[2].w","0","material[2].z","material[3].y","material[3].x","0","0","0","1","1","1","1","1","1","0","1"}},
 {{"4","0","1","t2","s2","t0","s0","t1","s1","1","t13","s13","t12","s12","0","t11","s11","0","material[0]","material[1]","material[2].w","0","material[2].z","material[3].y","material[3].x","0","0","0","1","1","1","1","1","1","0","1"}},
 {{"4","1","0","t2","s2","t0","s0","t1","s1","1","t13","s13","t12","s12","0","t3","s3","1","material[0]","material[1]","material[3].x","0","material[2].w","material[3].z","material[3].y","0","0","material[2].z","1","1","1","1","1","1","0","1"}},
 {{"4","1","1","t2","s2","t0","s0","t1","s1","1","t13","s13","t12","s12","0","t3","s3","1","material[0]","material[1]","material[3].x","0","material[2].w","material[3].z","material[3].y","0","0","material[2].z","1","1","1","1","1","1","0","1"}},
 {{"5","2","0","t0","s0","t3","s3","t4","s4","1","t2","s2","t1","s1","2","t11","s11","0","material[0]","material[1]","material[3].x","material[3].w","0","material[4].w","material[4].x","material[2].x","material[2].w","0","1","1","material[3].y","material[3].z","material[4].y","material[4].z","0","1"}},
 {{"5","2","1","t0","s0","t3","s3","t4","s4","1","t2","s2","t1","s1","2","t11","s11","0","material[0]","material[1]","material[3].x","material[3].w","0","material[4].w","material[4].x","material[2].x","material[2].w","0","1","1","material[3].y","material[3].z","material[4].y","material[4].z","0","0"}},
 {{"5","1","0","t0","s0","t2","s2","t3","s3","1","t1","s1","t12","s12","1","t11","s11","0","material[0]","material[1]","material[2].w","material[3].z","0","material[4].z","material[3].w","material[2].x","0","0","1","1","material[3].x","material[3].y","material[4].x","material[4].y","0","1"}},
 {{"5","1","1","t0","s0","t2","s2","t3","s3","1","t1","s1","t12","s12","1","t11","s11","0","material[0]","material[1]","material[2].w","material[3].z","0","material[4].z","material[3].w","material[2].x","0","0","1","1","material[3].x","material[3].y","material[4].x","material[4].y","0","0"}},
};
struct Identity{unsigned char hash[16];size_t bytes;int mode;};
inline constexpr Identity identities[]={
 {{0x56,0xc6,0x7d,0x55,0xea,0xf1,0xd8,0xdd,0xe0,0xce,0x01,0x95,0xdb,0x46,0x55,0xb7},5992,0},
 {{0xdc,0xcd,0x66,0x16,0xa7,0xf6,0xcf,0x39,0x65,0x67,0x9d,0xe1,0x38,0xfd,0x29,0xbf},4304,1},
 {{0xdd,0x83,0x02,0xd9,0xdc,0x0e,0xf2,0x0e,0xc9,0x0b,0xa9,0x95,0xae,0x86,0xb1,0xfe},4380,2},
 {{0x29,0xa7,0x3b,0x32,0x28,0x00,0x60,0x64,0x1d,0x2d,0x88,0x9d,0x0e,0x73,0xfc,0xb5},3152,3},
 {{0x7e,0x1e,0x40,0x71,0x2d,0x2f,0xc1,0x83,0xb5,0xfc,0x5c,0x2d,0xe0,0x4f,0x5e,0x95},5004,4},
 {{0x69,0xe5,0x4e,0x9a,0x61,0x21,0x96,0x89,0x46,0x39,0xb1,0x41,0xe2,0x88,0xa0,0xcc},4880,5},
 {{0x5b,0x9b,0xda,0x84,0xcd,0x60,0x7f,0xa1,0x42,0xff,0xfc,0xab,0x26,0x26,0x2c,0x41},5484,6},
 {{0x80,0x76,0xd9,0x13,0x05,0xf0,0x0c,0xc1,0xd2,0x00,0xb0,0x89,0xb3,0x61,0x77,0x20},5360,7},
 {{0x88,0xb7,0xb7,0xff,0xc9,0xd7,0xb9,0x8e,0x25,0x1f,0x93,0xcd,0xb2,0xdd,0x72,0x4d},6404,8},
 {{0x16,0x5a,0x8b,0xc7,0x35,0xa2,0x28,0xee,0xca,0x77,0xd2,0xb5,0x58,0x7e,0xcc,0x7d},4716,9},
 {{0x90,0xc1,0xcb,0xbc,0x92,0x1c,0x67,0xbc,0x7f,0xd8,0xab,0xcf,0xfc,0x06,0x92,0xcc},6088,10},
 {{0xe1,0x05,0xa9,0x10,0x91,0xef,0x97,0x69,0x5b,0x53,0x91,0x0e,0x4d,0x40,0xed,0x1a},4400,11},
};
}
