#pragma once
#include "vr_memory_access.h"
#include <cstring>
namespace vrheadlightcones {
inline unsigned word(const void* p,unsigned offset){unsigned value=0;if(p&&vrmemory::check((const char*)p+offset,4))memcpy(&value,(const char*)p+offset,4);return value;}
inline bool nameEquals(const void* p,const char* name){size_t n=strlen(name)+1;return vrmemory::check(p,n)&&!memcmp(p,name,n);}
inline bool headlightName(const void* p){
 if(!vrmemory::check(p,15)||memcmp(p,"veh_headlight_",14))return false;
 // Bounded native resource name, never an arbitrary substring match.
 for(unsigned i=14;i<80;++i){if(!vrmemory::check((const char*)p+i,1))return false;char c=((const char*)p)[i];if(!c)return i>14;}
 return false;
}
// Verified vfx_data mesh layout: 8-byte sized pointers, 0xb0-byte records.
// ROD rotates the visible beam to face the camera. NORMAL retains its authored
// vehicle attachment transform; additive shading and illumination stay native.
inline bool patchTemplate(void* source,bool vr){
 if(!vr)return false;vrmemory::Scope scope;
 auto* data=(void*)(uintptr_t)word(source,0x10);
 if(!headlightName((void*)(uintptr_t)word(data,0x18)))return false;
 unsigned count=word(data,0x40);auto* meshes=(char*)(uintptr_t)word(data,0x48);
 if(!count||count>64||!vrmemory::check(meshes,count*0xb0))return false;
 bool changed=false;
 for(unsigned i=0;i<count;++i){char* mesh=meshes+i*0xb0;
  if(!nameEquals((void*)(uintptr_t)word(mesh,0),"g_light_cone_01"))continue;
  unsigned type=word(mesh,8);if(!(type&4)||!vrmemory::check(mesh+8,4,true))continue;
  type=(type&~4u)|1u;memcpy(mesh+8,&type,4);changed=true;
 }return changed;
}
}
