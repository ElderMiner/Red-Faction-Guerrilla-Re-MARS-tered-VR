#pragma once
#include "vr_memory_access.h"
#include "vr_visual_mode.h"
#include "vr_night_lighting.h"
#include "modern_scene_lights.h"
#include <atomic>
#include <cmath>
#include <cstring>
extern "C" bool RFGRVR_HeadCam_Enabled();
namespace vrvehiclebloom {
inline std::atomic<bool> active{false};
inline std::atomic<unsigned> adjustments{0};
inline bool eligible(bool vr,unsigned state,bool firstPerson){return vr&&firstPerson&&(state==8||state==9||state==10);}
// Verified rl_hdr_state::m_bloom_amount (+48), consumed by the final HDR
// shader-constant upload. A private argument copy leaves exposure/history and the
// scene's stored state intact. Do not change luminance minimum (+24).
struct alignas(16) Parameters {
 unsigned char bytes[0x68]{};
 bool copy(const void* native,bool enabled){
  if(!enabled||!vrmemory::check(native,sizeof(bytes)))return false;
  float amount=0;memcpy(&amount,(const char*)native+0x48,4);
  if(!std::isfinite(amount)||amount<=.5f||amount>10000)return false;
  memcpy(bytes,native,sizeof(bytes));const float limit=.5f;memcpy(bytes+0x48,&limit,4);return true;
 }
};
using Upload=void(__thiscall*)(void*,void*,const void*,const void*);
inline Upload upload=nullptr;
inline void __fastcall onUpload(void* self,void*,void* renderer,const void* native,const void* colour){
 alignas(16) float modernHDR[26]{};
 if(RFGRVR_HeadCam_Enabled()&&vrvisual::enhanced()&&modernscene::current&&vrmemory::check(native,sizeof(modernHDR))&&modernscene::patchHDR((const float*)native,modernHDR,*modernscene::current))native=modernHDR;
 vrnight::Parameters night;if(RFGRVR_HeadCam_Enabled()&&vrvisual::enhanced()&&night.copy(native))native=night.bytes;
 Parameters hdr;
 if(hdr.copy(native,RFGRVR_HeadCam_Enabled()&&vrvisual::enhanced()&&active.load(std::memory_order_relaxed))){++adjustments;upload(self,renderer,hdr.bytes,colour);return;}
 upload(self,renderer,native,colour);
}
// Right-eye work can reuse adaptation and restore the renderer's earlier
// constant cache. Bound the final bloom coefficient there too, then restore
// CPU ownership and mark constants dirty for the next native pass.
struct CompositeScope {
 float* slot=nullptr;unsigned* dirty=nullptr;float saved=0,written=0;
 CompositeScope(void* compositor,void* renderer,bool enabled,float limit=.5f){
  if(!std::isfinite(limit)||limit<0||limit>10000)return;
  if(!enabled||!vrmemory::check(compositor,0xb5c)||!vrmemory::check(renderer,0x448,true))return;
  unsigned index=0;memcpy(&index,(char*)compositor+0xb58,4);if(index>=84)return;
  auto* value=(float*)((char*)renderer+0x2c0+index*4);memcpy(&saved,value,4);
  if(!std::isfinite(saved)||saved<=limit||saved>10000)return;
  slot=value;dirty=(unsigned*)((char*)renderer+0x444);written=limit;*slot=written;*dirty|=0x20;
 }
 ~CompositeScope(){if(slot&&*slot==written){*slot=saved;*dirty|=0x20;}}
};
}
