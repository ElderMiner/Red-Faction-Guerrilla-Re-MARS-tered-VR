#include "vr_head_motion.h"
#include "vr_display_geometry.h"
#include "vr_user_settings.h"
#include "vr_desktop_mirror.h"
#include "apc_camera_gpu.h"
#include "apc_render_targets.h"
#include "apc_world_screens.h"
#include "weapon_laser_gpu.h"
extern "C" bool RFGRVR_Arms_PistolLaser(vrarm::Pose*);
#include "apc_camera_pipeline.h"
#include <memory>
#include "native_apc_cameras.h"
#include "vr_mapping.h"
extern "C" bool RFGRVR_VehicleSitting();
extern "C" bool RFGRVR_HeadCam_Cinematic();
extern "C" void RFGRVR_AudioListener(const float[3],const float[9]);
extern "C" bool RFGRVR_RenderWindow_Ready(unsigned,unsigned);
extern "C" bool RFGRVR_RenderWindow_Requested(unsigned*,unsigned*);
// EXPERIMENT: alternate real game camera viewpoints on successive frames.
// This avoids unsafe, recursive invocation of RFGR's multi-threaded scene renderer.
// Expected compromises: per-eye half game framerate, moving-object disparity,
// no independent render matrices/FOV, and no guarantee the camera offset is consumed.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include "vr_pair_mutex.h"
#include "vr_hud_heading.h"
#include <d3d11_1.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <atomic>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include "stereo_gpu_protocol.h"
#include "ipc.h"
#include "vr_grip_snapshot.h"
#include "vr_eye_projection.h"
#include "weapon_scope_gpu.h"
#include "vr_rig_math.h"
#include "vr_turn_clock.h"
#include "vr_vehicle_eye_anchor.h"
#include "vr_world_scale.h"
#include "vr_ragdoll_view.h"
#include "vr_room_motion.h"
#include "vr_mount_tracking.h"
#include "vr_frame_parent.h"
#include "vr_pair_timing.h"
#include "vr_turret_aim.h"
extern "C" bool RFGRVR_Arms_TurretHand(float[3],float[3]);
extern "C" float RFGRVR_Arms_TurretLever(const float[3]);
extern "C" bool RFGRVR_HeadCam_TurretPivot(float[3],unsigned*);
extern "C" bool RFGRVR_HeadCam_TurretMounted();
extern "C" bool RFGRVR_HeadCam_TurretAngles(float*,float*);
extern "C" bool RFGRVR_HeadCam_TurretRoom(float[3]);
extern "C" bool RFGRVR_HeadCam_Parent(float[9],unsigned*);
extern "C" void RFGRVR_HeadCam_SetBodyYaw(float);
extern "C" void RFGRVR_HeadCam_RenderBegin(const float[3],const float[9]);
extern "C" void RFGRVR_HeadCam_RenderEnd();
extern "C" void RFGRVR_HeadCam_RefreshArms();
extern "C" void RFGRVR_VehicleView(const float[3],const float[9],const RFGRPose*);
extern "C" void RFGRVR_HeadCam_CalibratedHeight(float);
extern "C" void RFGRVR_HeadCam_FloorCalibration(bool);
extern "C" float RFGRVR_HeadCam_WorldScale();
extern "C" float RFGRVR_HeadCam_SceneScale();
extern "C" void RFGRVR_HeadCam_RoomRequest(float,float,float,float);
extern "C" bool RFGRVR_HeadCam_ControllerMoving();
extern "C" void RFGRVR_HeadCam_RoomConsumed(float[3]);
extern "C" bool RFGRVR_HeadCam_GetPosition(float out[3]);
extern "C" bool RFGRVR_HeadCam_GetFrame(float[3],float[9],bool*,unsigned*,float*);
extern "C" bool RFGRVR_HeadCam_Enabled();
extern "C" bool RFGRVR_LegacyLook_Enabled();
extern "C" bool RFGRVR_GameplayProjection_Enabled();
extern "C" bool RFGRVR_HeadCam_MenuScene();
extern "C" bool RFGRVR_HeadCam_PopupMenu();
extern "C" void RFGRVR_Arms_Publish(RFGRShared*,const float[3],const float[9],const float[4],const RFGRPose*);
using Microsoft::WRL::ComPtr;
namespace {
constexpr float HALF_IPD=0.032f;
struct State {
 HANDLE mapping=nullptr;
 RFGRStereoGpuShared* ipc=nullptr;
 ComPtr<ID3D11Device> device;
 ComPtr<ID3D11DeviceContext> context;
 ComPtr<ID3D11Texture2D> texture[2];
 vrdesktop::Mirror desktop;
 ComPtr<IDXGIKeyedMutex> mutex[2];
 UINT width=0,height=0;DXGI_FORMAT format=DXGI_FORMAT_UNKNOWN;
 unsigned nextEye=0;
 bool enabled=true,wasF6=false; // VR startup default; F6 remains an override
 std::atomic<unsigned> recenterRequest{0}; unsigned recenterSeen=0;bool recenterYaw=false;
 unsigned long frameCount=0;
 std::atomic<unsigned> cameraCalls{0},copies{0},captureFailures{0},cameraFailures{0};
 bool fovOutstanding=false;float savedFov=0,writtenFov=0;
 void* camera=nullptr;float original[3]{};float shifted[3]{};bool outstanding=false;
 // The engine CONSUMES the packed 3x3 at +8 and REBUILDS +0x100.
 float savedMatrix[9]{},writtenMatrix[9]{};bool matrixOutstanding=false;
 HANDLE poseMapping=nullptr;RFGRShared* tracking=nullptr;
 RFGRVRRoomMotion roomMotion;RFGRVRMountTracking mountTracking;
 float calibration[4]{0,0,0,1};float origin[3]{};float worldBasis[3][3]{};bool calibrated=false;bool lastHeadMode=false;
 ComPtr<IDXGISwapChain> nativeSwap;
 RFGREye nativeEyes[2]{}; RFGRPose nativeCenter{};
 bool gameplayViewSaved=false;bool nativeGameFrameReady=false;RFGRVRFrameParent nativeGameParent;float nativeGameHead[3]{},nativeGameOrigin[3]{},nativeGameCalibration[4]{},nativeGameBasis[3][3]{},nativeGameScale=1,nativeGameSceneScale=1,nativeGameFloorEye=0;float nativeGameTurretRoom[3]{};
 RFGRShared nativeTracking{};
 RFGRPose renderedPose{};bool renderedPoseValid=false;float temporalProjection[16]{};bool temporalProjectionValid=false;
 float temporalEyeFov[4]{};bool temporalEyeFovValid=false;
 int64_t nativeTime=0;uint64_t nativeFrame=0;unsigned resourceGeneration=0;
 std::atomic<bool> nativeActive{false};bool nativeUsed=false,nativeEnabled=false; // Failed live test: do not re-enable without isolated target validation.
 unsigned nativeEye=0;std::atomic<unsigned> nativeProjectionCalls{0};bool nativeContinuous=false;
 float nativeSourceProjection[2][4]{};
 ComPtr<ID3D11Texture2D> evidence[2];bool evidenceWritten=false;unsigned evidenceMode=~0u,evidenceMask=~0u;
 std::atomic<float> turnAxis{0};std::atomic<ULONGLONG> turnAxisTick{0};RFGRVRTurnClock turnClock;unsigned previousParentState=0;bool wasParented=false;float parentEntry[3][3]{},lastEffective[3][3]{};std::atomic<bool> parentActive{false};std::atomic<unsigned> parentState{0};
 RFGRVRTurretOrbit turretOrbit;
 std::atomic<float> turretYaw{0},turretPitch{0},turretCoarseYaw{0};std::atomic<ULONGLONG> turretTick{0};
 std::atomic<int> turnMilliDegrees{0};std::atomic<float> facingYaw{0},facingPitch{0};std::atomic<ULONGLONG> facingTick{0};
 std::atomic<unsigned> trackedFrames{0},trackingRejected{0};
} g;
static RFGRVRPairTiming pairTiming;
static bool memoryReady(void* p,size_t bytes,bool writable){
 MEMORY_BASIC_INFORMATION m{};if(!p||!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||m.Protect&(PAGE_GUARD|PAGE_NOACCESS))return false;
 const DWORD prot=m.Protect&255;
 if(writable&&prot!=PAGE_READWRITE&&prot!=PAGE_WRITECOPY&&prot!=PAGE_EXECUTE_READWRITE&&prot!=PAGE_EXECUTE_WRITECOPY)return false;
 uintptr_t a=(uintptr_t)p,b=(uintptr_t)m.BaseAddress;
 return a>=b&&bytes<=m.RegionSize&&a-b<=m.RegionSize-bytes;
}
static bool finite(float a){return std::isfinite(a)&&fabsf(a)<1000000.f;}
// Calibrated OpenXR head-space delta, applied to the game's live camera basis.
// The engine's complete projection/culling update remains outside this hook.
struct Q {float x,y,z,w;};
static Q conjugate(Q q){return {-q.x,-q.y,-q.z,q.w};}
static Q multiply(Q a,Q b){return {a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,
 a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,
 a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z};}
static bool validQ(Q q){float n=q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w;
 return std::isfinite(n)&&n>.96f&&n<1.04f;}
static void rotate(Q q,const float in[3],float out[3]){
 Q v{in[0],in[1],in[2],0};Q r=multiply(multiply(q,v),conjugate(q));
 out[0]=r.x;out[1]=r.y;out[2]=r.z;
}
static bool trackedPose(RFGRPose& pose){
 if(!g.tracking){if(!g.poseMapping)g.poseMapping=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_MAP_NAME);
  if(g.poseMapping)g.tracking=(RFGRShared*)RFGRVR_MapViewOrClose(g.poseMapping,FILE_MAP_READ,0,0,sizeof(RFGRShared));}
 auto* t=g.tracking;
 if(!t||t->magic!=RFGR_MAGIC||t->version!=RFGR_PROTOCOL||t->openxrState<5)return false;
 for(int n=0;n<3;++n){
  LONG a=t->poseSequence;if(a&1)continue;
  MemoryBarrier();pose=t->hmd;MemoryBarrier();LONG b=t->poseSequence;
  if(a==b&&(pose.validFlags&3)==3){
   for(float v:pose.position)if(!finite(v))return false;
   Q q{pose.orientation[0],pose.orientation[1],pose.orientation[2],pose.orientation[3]};
   return validQ(q);
  }
 }
 return false;
}
static bool basisValid(const float m[9]){
 for(int i=0;i<9;++i)if(!std::isfinite(m[i]))return false;
 for(int k=0;k<3;++k){float n=0;for(int i=0;i<3;++i)n+=m[k*3+i]*m[k*3+i];if(n<.9f||n>1.1f)return false;}
 for(int a=0;a<3;++a)for(int b=a+1;b<3;++b){float dot=0;for(int i=0;i<3;++i)dot+=m[a*3+i]*m[b*3+i];if(fabsf(dot)>.05f)return false;}
 return true;
}
static void restore(){
 RFGRVR_HeadCam_RenderEnd();
 if(g.fovOutstanding&&g.camera){auto* f=(char*)g.camera+0x140;float now=0;
  if(memoryReady(f,4,true)){memcpy(&now,f,4);if(now==g.writtenFov)memcpy(f,&g.savedFov,4);}}
 g.fovOutstanding=false;
 if(g.outstanding&&g.camera){
  auto* p=(unsigned char*)g.camera+0x2c;
  // Restore only if the camera still contains our offset, not a game update.
  if(memoryReady(p,12,true)){
   float now[3];memcpy(now,p,12);
   if(memcmp(now,g.shifted,12)==0)memcpy(p,g.original,12);
  }
 }
 if(g.matrixOutstanding&&g.camera){auto* m=(unsigned char*)g.camera+8;
  if(memoryReady(m,36,true)&&memcmp(m,g.writtenMatrix,36)==0)memcpy(m,g.savedMatrix,36);
 }
 g.matrixOutstanding=false;g.outstanding=false;g.camera=nullptr;
}
static void release(){
 if(g.ipc)InterlockedExchange(&g.ipc->ready,0);
 restore();
 for(int e=0;e<2;++e){g.mutex[e].Reset();g.texture[e].Reset();}
 pairTiming.reset();g.context.Reset();g.device.Reset();
 if(g.ipc){UnmapViewOfFile(g.ipc);g.ipc=nullptr;}
 if(g.mapping){CloseHandle(g.mapping);g.mapping=nullptr;}
 g.width=g.height=0;g.format=DXGI_FORMAT_UNKNOWN;g.nextEye=0;g.calibrated=false;g.lastHeadMode=false;
}
static DXGI_FORMAT menuColorFormat(DXGI_FORMAT value){return value==DXGI_FORMAT_R8G8B8A8_TYPELESS?DXGI_FORMAT_R8G8B8A8_UNORM:value==DXGI_FORMAT_B8G8R8A8_TYPELESS?DXGI_FORMAT_B8G8R8A8_UNORM:value;}
static bool setup(IDXGISwapChain* swap,ID3D11Texture2D* back){
 D3D11_TEXTURE2D_DESC d{};back->GetDesc(&d);d.Format=menuColorFormat(d.Format);
 if(!d.Width||!d.Height||d.ArraySize!=1||d.SampleDesc.Count!=1||d.MipLevels!=1)return false;
 if(d.Format!=DXGI_FORMAT_B8G8R8A8_UNORM&&d.Format!=DXGI_FORMAT_R8G8B8A8_UNORM&&d.Format!=DXGI_FORMAT_B8G8R8A8_UNORM_SRGB&&d.Format!=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB)return false;
 if(g.ipc&&g.device&&g.width==d.Width&&g.height==d.Height&&g.format==d.Format)return true;
 release();
 if(FAILED(swap->GetDevice(__uuidof(ID3D11Device),(void**)g.device.GetAddressOf())))return false;
 g.device->GetImmediateContext(g.context.GetAddressOf());if(!g.context)return false;
 g.width=d.Width;g.height=d.Height;g.format=d.Format;
 g.mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRStereoGpuShared),RFGR_STEREO_GPU_MAP);
 if(!g.mapping){release();return false;}
 g.ipc=(RFGRStereoGpuShared*)MapViewOfFile(g.mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRStereoGpuShared));
 if(!g.ipc){release();return false;}
 // The companion may still hold this mapping through a menu/resize. Reuse
 // our own packet instead of making its lifetime block recreation forever.
 DWORD owner=g.ipc->ownerPid;if(owner&&owner!=GetCurrentProcessId()){HANDLE process=OpenProcess(SYNCHRONIZE,FALSE,owner);bool alive=process&&WaitForSingleObject(process,0)==WAIT_TIMEOUT;if(process)CloseHandle(process);if(alive){UnmapViewOfFile(g.ipc);g.ipc=nullptr;release();return false;}}
 InterlockedExchange(&g.ipc->ready,0);MemoryBarrier();ZeroMemory(g.ipc,sizeof(*g.ipc));
 for(int i=0;i<2;++i){
  D3D11_TEXTURE2D_DESC td=d;td.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_RENDER_TARGET;
  td.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;td.Usage=D3D11_USAGE_DEFAULT;td.CPUAccessFlags=0;
  if(FAILED(g.device->CreateTexture2D(&td,nullptr,g.texture[i].GetAddressOf()))||FAILED(g.texture[i].As(&g.mutex[i]))){release();return false;}
  ComPtr<IDXGIResource> resource;
  if(FAILED(g.texture[i].As(&resource))){release();return false;}
  HANDLE handle=nullptr;
  if(FAILED(resource->GetSharedHandle(&handle))||!handle){release();return false;}
  g.ipc->eyeHandle[i]=(uint64_t)(uintptr_t)handle;
 }
 if(g.ipc->eyeHandle[0]==g.ipc->eyeHandle[1]){release();return false;}
 g.ipc->magic=RFGR_STEREO_GPU_MAGIC;g.ipc->version=4;g.ipc->ownerPid=GetCurrentProcessId();g.ipc->generation=++g.resourceGeneration;
 g.ipc->width=d.Width;g.ipc->height=d.Height;g.ipc->format=(uint32_t)d.Format;
 MemoryBarrier();InterlockedExchange(&g.ipc->ready,1);return true;
}
}
// Indicates whether F6 temporal stereo is enabled; camera trial must never suppress its camera hook.
extern "C" void RFGRVR_PairGpuMarker(const wchar_t* label,bool begin){
 if(!g.context)return;ComPtr<ID3DUserDefinedAnnotation> annotation;
 if(SUCCEEDED(g.context.As(&annotation))){if(begin)annotation->BeginEvent(label);else annotation->EndEvent();}
}
extern "C" bool RFGRVR_Temporal_IsEnabled(){return g.enabled;}
extern "C" void RFGRVR_Temporal_Recenter(){g.recenterRequest.fetch_add(1,std::memory_order_release);}
namespace {bool auxiliaryCamera=false;vrarm::Pose auxiliaryPose{};RFGRAPCGpu auxiliaryGpu;RFGRAPCWorldScreens worldScreens;RFGRWeaponLaserGpu weaponLaser;uint64_t laserFrame=0;vrlaser::State laserFrameState;bool scopeAux=false;unsigned scopeAuxEye=0;vrscope::Optics scopeOptics[2];RFGRScopeFeed scopeGpu;RFGRWeaponScopeSurface scopeSurface;ULONGLONG scopeCapturedTick=0;int scopeCapturedKind=-1;unsigned scopeCaptures=0,scopeDraws=0;}
extern "C" void RFGRVR_HeadCam_Auxiliary(bool);
namespace {vrarm::V apcPlayerEye{};uint64_t apcLastDepthScore=0;unsigned apcLastDepthCompare=0;unsigned apcFrames=0,apcCaptures=0,apcFailures=0,apcScreenDraws=0;std::unique_ptr<RFGRAPCCameraPipeline> apcPipeline;}
extern "C" void RFGRVR_APC_Pipeline(bool save){if(!g.context)return;if(save){memcpy(&apcPlayerEye,g.shifted,12);apcPipeline=std::make_unique<RFGRAPCCameraPipeline>();apcPipeline->save(g.context.Get());}else if(apcPipeline){apcPipeline->restore(g.context.Get());apcPipeline.reset();ComPtr<ID3D11Texture2D> back;if(g.nativeSwap&&g.texture[1]&&SUCCEEDED(g.nativeSwap->GetBuffer(0,IID_PPV_ARGS(&back))))g.context->CopyResource(back.Get(),g.texture[1].Get());
 if(vrscope::visible()&&apcFrames%120==0){char scopePath[MAX_PATH]{};GetModuleFileNameA(nullptr,scopePath,MAX_PATH);if(auto* slash=strrchr(scopePath,92)){strcpy_s(slash+1,MAX_PATH-(slash+1-scopePath),"RFGRVR-Scope.log");FILE* file=nullptr;if(!fopen_s(&file,scopePath,"a")&&file){auto f=vrscope::snapshot();fprintf(file,"tick=%llu kind=%d alpha=%.3f editing=%u cut=%u radius=%.3f captured=%u drawn=%u source=%ux%u failure=%u overlay=%u\n",GetTickCount64(),f.kind,f.alpha,unsigned(f.editing),unsigned(f.cut),f.radius,scopeCaptures,scopeDraws,RFGRAPCTargets::width,RFGRAPCTargets::height,scopeSurface.lastFailure,unsigned(f.overlay));fclose(file);}}}
 if(++apcFrames%120==0){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* s=strrchr(path,92)){strcpy_s(s+1,MAX_PATH-(s+1-path),"RFGRVR-APC-Performance.log");FILE* f=nullptr;if(!fopen_s(&f,path,"a")&&f){fprintf(f,"tick=%llu frames=%u feeds=%u failures=%u eyeScreenDraws=%u lastSource=%ux%u atlas=%ux%u depth=%u cachedTextures=%zu cachedViews=%zu contexts=%u worldDepthScore=%llu worldCompare=%u\n",GetTickCount64(),apcFrames,apcCaptures,apcFailures,apcScreenDraws,RFGRAPCTargets::width,RFGRAPCTargets::height,RFGRAPCScreen::atlasWidth,RFGRAPCScreen::atlasHeight,RFGRAPCTargets::depthFound.load()?1u:0u,RFGRAPCTargets::textures.size(),RFGRAPCTargets::views.size(),RFGRAPCTargets::hookCount.load(),apcLastDepthScore,apcLastDepthCompare);fclose(f);}}}}}
extern "C" void RFGRVR_APC_BeforeResize(){RFGRAPCTargets::end();apcPipeline.reset();scopeSurface.beforeResize(); // Private scope feed survives window-buffer resize.
 laserFrame=0;laserFrameState={};weaponLaser.releaseOutput();worldScreens.output.Reset();worldScreens.target.Reset();if(worldScreens.deferred){worldScreens.deferred->ClearState();ComPtr<ID3D11CommandList> discarded;worldScreens.deferred->FinishCommandList(FALSE,&discarded);}RFGRAPCTargets::releaseAuxiliary();RFGRAPCTargets::beginDepth(false);}
extern "C" void RFGRVR_APC_AuxSet(const vrarm::Pose* pose){restore();auxiliaryCamera=pose!=nullptr;RFGRVR_HeadCam_Auxiliary(auxiliaryCamera);if(pose){auxiliaryPose=*pose;if(scopeAux){unsigned size=scopeOptics[scopeAuxEye].pixels;RFGRAPCTargets::begin(size,size);return;}AcquireSRWLockShared(&RFGRVRAPC::lock);unsigned index=RFGRVRAPC::renderIndex;auto monitor=RFGRVRAPC::monitors[index];float size=RFGRVRAPC::assemblyScale;
 auto center=vrarm::add(RFGRVRAPC::nativeScreens.p,vrarm::world(RFGRVRAPC::nativeScreens.b,vrarm::mul(RFGRVRAPC::monitorOffset(index),size*RFGRVRAPC::scale)));
 float distance=vrarm::length(vrarm::sub(center,apcPlayerEye))/RFGRVRAPC::scale;
 auto desired=RFGRAPCScreen::captureSize(index,distance,RFGRAPCScreen::width(index)*monitor.width*size,RFGRAPCScreen::height(index)*monitor.height*size,g.width*.5f*g.nativeSourceProjection[1][0],g.height*.5f*g.nativeSourceProjection[1][1]);ReleaseSRWLockShared(&RFGRVRAPC::lock);
 static RFGRAPCScreen::Size sizes[4]{};static ULONGLONG resized[4]{};auto now=GetTickCount64();auto prior=sizes[index];float oldAspect=prior.height?float(prior.width)/prior.height:0,newAspect=float(desired.width)/desired.height;
 if(!prior.width||fabsf(oldAspect-newAspect)>.015f||now-resized[index]>750&&(abs(int(desired.width)-int(prior.width))>=32||abs(int(desired.height)-int(prior.height))>=32)){sizes[index]=desired;resized[index]=now;}
 RFGRAPCTargets::begin(sizes[index].width,sizes[index].height);}else RFGRAPCTargets::end();}
extern "C" bool RFGRVR_APC_AuxProjection(void* camera,float out[16],float* fov){if(!auxiliaryCamera||!g.camera||!camera)return false;
 // Worker scene preparation clones the active camera. Permit its exact pose
 // and clip planes, while rejecting unrelated shadow/light cameras.
 if(camera!=g.camera){auto* c=(unsigned char*)camera;auto* source=(unsigned char*)g.camera;if(!memoryReady(c+8,48,false)||!memoryReady(c+0x590,8,false)||!memoryReady(source+0x590,8,false)||memcmp(c+8,g.writtenMatrix,36)||memcmp(c+0x2c,g.shifted,12)||memcmp(c+0x590,source+0x590,8))return false;}
float bounds[4]{};if(scopeAux){memcpy(bounds,scopeOptics[scopeAuxEye].angles,16);}else{AcquireSRWLockShared(&RFGRVRAPC::lock);RFGRVRAPC::bounds(RFGRVRAPC::renderIndex,bounds);ReleaseSRWLockShared(&RFGRVRAPC::lock);}RFGRVREyeProjection projection{};if(!RFGRVR_BuildEngineProjection(bounds,.1f,475.f,&projection))return false;memcpy(out,projection.columnMajor,64);*fov=2.f*(std::max)({fabsf(bounds[0]),fabsf(bounds[1]),fabsf(bounds[2]),fabsf(bounds[3])})*57.2957795f+5.f;return true;}
extern "C" bool RFGRVR_APC_AuxCapture(unsigned index){if(!auxiliaryCamera||!g.nativeSwap||!g.device||!g.context)return false;ComPtr<ID3D11Texture2D> back,reduced;if(FAILED(g.nativeSwap->GetBuffer(0,__uuidof(ID3D11Texture2D),(void**)back.GetAddressOf()))){RFGRAPCTargets::end();return false;}auto* output=RFGRAPCTargets::resource(back.Get());bool valid=SUCCEEDED(output->QueryInterface(IID_PPV_ARGS(&reduced)));valid=RFGRAPCTargets::end()&&valid;bool ok=valid&&(scopeAux?scopeGpu.capture(g.device.Get(),g.context.Get(),reduced.Get(),index):auxiliaryGpu.capture(g.device.Get(),g.context.Get(),reduced.Get(),index));if(ok){if(scopeAux){scopeGpu.optics[index]=scopeOptics[index];scopeGpu.opticsValid[index]=true;if(index==1){scopeCapturedTick=GetTickCount64();scopeCapturedKind=vrscope::snapshot().kind;}++scopeCaptures;}else{++apcCaptures;RFGRVRAPC::captured(auxiliaryGpu.handle,auxiliaryGpu.epoch,index);}}else ++apcFailures;return ok;}
extern "C" bool RFGRVR_Scope_AuxView(unsigned eye,vrarm::Pose* out){if(eye>1||!out)return false;scopeAuxEye=eye;static unsigned stableSize=0;static ULONGLONG changed=0;if(!eye){unsigned wanted=(std::max)(scopeOptics[0].pixels,scopeOptics[1].pixels);auto now=GetTickCount64();if(!stableSize||now-changed>750&&(wanted>stableSize+128||wanted+256<stableSize)){if(stableSize)RFGRAPCTargets::releaseAuxiliary();stableSize=wanted;changed=now;}scopeOptics[0].pixels=scopeOptics[1].pixels=stableSize;}*out=scopeOptics[eye].camera;return true;}
extern "C" void RFGRVR_Scope_AuxSet(const vrarm::Pose* pose){scopeAux=pose!=nullptr;RFGRVR_APC_AuxSet(pose);}


extern "C" void RFGRVR_Temporal_CameraBegin(void* camera){
 if(!g.enabled||!camera||g.outstanding||(!g.nativeActive&&!RFGRVR_GameplayProjection_Enabled()))return;
 // Head-anchored room-scale stereo mode. Both eyes use the SAME tracked
 // HMD pose, with per-eye physical offsets in the tracked head orientation.
 auto* p=(unsigned char*)camera+0x2c;
 auto* matrix=(unsigned char*)camera+8;
 if(!memoryReady(p,12,true)||!memoryReady(matrix,36,true)){++g.cameraFailures;return;}
 g.temporalProjectionValid=false;
 g.temporalEyeFovValid=false;
 float pos[3],m[9];memcpy(pos,p,12);memcpy(m,matrix,36);
 if(!basisValid(m)){++g.cameraFailures;return;}
 if(auxiliaryCamera){memcpy(g.original,p,12);memcpy(g.savedMatrix,matrix,36);memcpy(g.shifted,&auxiliaryPose.p,12);memcpy(g.writtenMatrix,&auxiliaryPose.b,36);memcpy(p,g.shifted,12);memcpy(matrix,g.writtenMatrix,36);g.camera=camera;g.outstanding=g.matrixOutstanding=true;RFGRVR_HeadCam_RenderBegin(g.shifted,g.writtenMatrix);return;}

 float basis[3][3]={{m[0],m[1],m[2]},{m[3],m[4],m[5]},{m[6],m[7],m[8]}};
 for(float v:pos)if(!finite(v)){++g.cameraFailures;return;}
 const bool popup=RFGRVR_HeadCam_PopupMenu();
 // Reuse the last normal gameplay anchor for BOTH eyes throughout a menu.
 // This keeps its scale, seat parent and calibrated origin; fresh HMD poses
 // still drive the view every frame. Menu animation cannot recenter/zoom it.
 const bool reuseGameFrame=(popup&&g.gameplayViewSaved)||(g.nativeActive&&g.nativeEye==1&&g.nativeGameFrameReady);
 const unsigned requested=g.recenterRequest.load(std::memory_order_acquire);
 if(!reuseGameFrame&&requested!=g.recenterSeen){g.calibrated=false;g.recenterYaw=true;g.recenterSeen=requested;}
 const bool headMode=RFGRVR_HeadCam_Enabled();static bool wasCinematic=false;bool cinematic=RFGRVR_HeadCam_Cinematic();if(cinematic)g.gameplayViewSaved=false;if(!reuseGameFrame&&cinematic!=wasCinematic){g.calibrated=false;g.recenterYaw=true;wasCinematic=cinematic;}
 // Reset the headset zero-point when entering/leaving native VR, rather than
 // retaining a stale room origin through a mode switch.
 if(!reuseGameFrame&&headMode!=g.lastHeadMode){g.calibrated=false;g.lastHeadMode=headMode;}
 float head[3]{},frameParent[9]{},floorEye=0;bool frameAttached=false;unsigned frameState=0;RFGRPose hmd{};
 RFGRVR_HeadCam_CalibratedHeight(g.tracking&&g.tracking->calibrationReady?g.tracking->calibratedHeadHeight:0);
 RFGRVR_HeadCam_FloorCalibration(g.tracking&&g.tracking->calibrationReady&&g.tracking->calibrationFloorValid);
 if(reuseGameFrame)memcpy(head,g.nativeGameHead,12);
 const bool trackingOK=headMode&&(reuseGameFrame||RFGRVR_HeadCam_GetFrame(head,frameParent,&frameAttached,&frameState,&floorEye))&&
  (g.nativeActive?(hmd=g.nativeEyes[g.nativeEye].pose,true):trackedPose(hmd));
 if(trackingOK&&frameState==0x103){
  vrworldview::prepared={};vrarm::Pose headPose{};memcpy(&headPose.p,head,12);memcpy(&headPose.b,frameParent,36);float optical[3]{};
  if(g.nativeActive){float delta[3];for(int j=0;j<3;++j)delta[j]=hmd.position[j]-g.nativeCenter.position[j];Q center{g.nativeCenter.orientation[0],g.nativeCenter.orientation[1],g.nativeCenter.orientation[2],g.nativeCenter.orientation[3]};rotate(conjugate(center),delta,optical);}else optical[0]=g.nextEye==0?-HALF_IPD:HALF_IPD;
  auto eye=RFGRVR_RagdollEye(headPose,{optical[0],optical[1],optical[2]},RFGRVR_HeadCam_SceneScale());memcpy(g.original,p,12);memcpy(g.savedMatrix,matrix,36);memcpy(g.shifted,&eye.p,12);memcpy(g.writtenMatrix,&eye.b,36);memcpy(p,g.shifted,12);memcpy(matrix,g.writtenMatrix,36);g.camera=camera;g.outstanding=g.matrixOutstanding=true;RFGRVR_HeadCam_RenderBegin(g.shifted,g.writtenMatrix);++g.cameraCalls;return;
 }
 if(trackingOK){
  static RFGRVRSeatOrigin seatOrigin;
  float consumed[3]{};if(!reuseGameFrame)RFGRVR_HeadCam_RoomConsumed(consumed);
  if(g.calibrated){g.origin[0]+=consumed[0];g.origin[2]+=consumed[2];}
  g.renderedPose=hmd;g.renderedPoseValid=true;
  Q q{hmd.orientation[0],hmd.orientation[1],hmd.orientation[2],hmd.orientation[3]};
  if(!g.calibrated){g.wasParented=false;const auto& center=g.nativeActive?g.nativeCenter:hmd;
    memcpy(g.origin,center.position,sizeof(g.origin));if(seatOrigin.seated){seatOrigin.target=center.position[1];seatOrigin.tick=GetTickCount64();}
    auto pivot=vrheadmotion::eyeFromPivot();float neck[3]={pivot.x,pivot.y,pivot.z},rotatedNeck[3];Q neckQ{center.orientation[0],center.orientation[1],center.orientation[2],center.orientation[3]};rotate(neckQ,neck,rotatedNeck);g.roomMotion.reset(rotatedNeck);
    // Room-space up stays vertical. Default forward comes from room setup;
    // explicit recenter changes yaw only and never levels a tilted head.
    Q zero{0,0,0,1};
    if(g.recenterYaw){Q orientation{center.orientation[0],center.orientation[1],center.orientation[2],center.orientation[3]};float forward[3]={0,0,-1},direction[3];rotate(orientation,forward,direction);
     float yaw=atan2f(-direction[0],-direction[2]);zero={0,sinf(yaw*.5f),0,cosf(yaw*.5f)};}
    memcpy(g.calibration,&zero,sizeof(zero));g.recenterYaw=false;
    float yaw=atan2f(basis[2][0],basis[2][2]),c=cosf(yaw),s=sinf(yaw);
    float upright[3][3]={{c,0,-s},{0,1,0},{s,0,c}};
    memcpy(g.worldBasis,upright,sizeof(upright));g.calibrated=true;}
  if(!reuseGameFrame){unsigned mount=~0u;float pivot[3]{};
   if(RFGRVR_HeadCam_TurretMounted())RFGRVR_HeadCam_TurretPivot(pivot,&mount);
   const auto& center=g.nativeActive?g.nativeCenter:hmd;
   if(g.mountTracking.update(mount,center.position,g.origin)){
    auto pivot=vrheadmotion::eyeFromPivot();float neck[3]={pivot.x,pivot.y,pivot.z},rotated[3];Q orientation{center.orientation[0],center.orientation[1],center.orientation[2],center.orientation[3]};rotate(orientation,neck,rotated);g.roomMotion.reset(rotated);RFGRVR_HeadCam_RoomRequest(0,0,0,0);
   }
  }
  const bool updateHeading=!g.nativeActive||g.nativeEye==0;
  auto now=GetTickCount64();LARGE_INTEGER counter{},frequency{};QueryPerformanceCounter(&counter);QueryPerformanceFrequency(&frequency);
  float seconds=g.turnClock.step(counter.QuadPart,frequency.QuadPart,updateHeading);
  static vrsettings::Turning userTurning;const float turn=popup||!updateHeading?0.f:userTurning.apply(now-g.turnAxisTick.load()<250?g.turnAxis.load():0.f,seconds,vrsettings::get());
  if(turn){const float angle=turn*(3.14159265358979323846f/180.f),c=cosf(angle),s=sinf(angle);
   for(int i=0;i<3;++i){float x=g.worldBasis[i][0],z=g.worldBasis[i][2];g.worldBasis[i][0]=c*x+s*z;g.worldBasis[i][2]=-s*x+c*z;}}
  bool attached=false;float effectiveBasis[3][3];
  if(reuseGameFrame){g.nativeGameParent.restore(frameState,attached);memcpy(effectiveBasis,g.nativeGameBasis,36);}
  else {
  float parent[3][3]{};memcpy(parent,frameParent,36);
  // Jump/fall follow animated translation only: feeding body yaw back into
  // the tracked view would recursively turn the same body from its own view.
  attached=frameAttached&&frameState>2&&basisValid(&parent[0][0]);
  g.parentActive.store(attached);g.parentState.store(frameState);
  if(attached&&(frameState==8||frameState==9||frameState==10)&&(!g.wasParented||g.previousParentState!=frameState)){
   const auto& center=g.nativeActive?g.nativeCenter:hmd;Q orientation{center.orientation[0],center.orientation[1],center.orientation[2],center.orientation[3]};float forward[3]={0,0,-1},direction[3];rotate(orientation,forward,direction);float yaw=atan2f(-direction[0],-direction[2]);Q seatZero{0,sinf(yaw*.5f),0,cosf(yaw*.5f)};memcpy(g.calibration,&seatZero,16);
  }
  if(attached&&(!g.wasParented||g.previousParentState!=frameState)){
   if(frameState==8||frameState==9||frameState==10)RFGRVR_UprightBasis(parent,g.worldBasis);else if(g.wasParented){RFGRVR_UprightBasis(g.lastEffective,g.worldBasis);}
   memcpy(g.parentEntry,parent,36);
  }
  memcpy(effectiveBasis,g.worldBasis,36);
  if(attached){if(frameState==8||frameState==9||(frameState==0x100||frameState==0x101)||RFGRVR_HeadCam_TurretMounted())memcpy(effectiveBasis,parent,36);else if(frameState!=3)RFGRVR_ParentBasis(g.parentEntry,parent,g.worldBasis,effectiveBasis); }
  else if(g.wasParented){
   // Returning to floor-based locomotion keeps heading, but vehicle roll and
   // pitch cannot tilt the room floor after detaching from the parent.
   float yaw=atan2f(g.lastEffective[2][0],g.lastEffective[2][2]),c=cosf(yaw),s=sinf(yaw);
   float upright[3][3]={{c,0,-s},{0,1,0},{s,0,c}};memcpy(g.worldBasis,upright,36);memcpy(effectiveBasis,upright,36);
  }
  if(attached&&frameState>=7&&frameState<=10&&!vrsettings::get().value[vrsettings::Vehicles]){float yaw=atan2f(effectiveBasis[2][0],effectiveBasis[2][2]),c=cosf(yaw),s=sinf(yaw);float upright[3][3]={{c,0,-s},{0,1,0},{s,0,c}};memcpy(effectiveBasis,upright,36);}
  memcpy(g.lastEffective,effectiveBasis,36);g.wasParented=attached;g.previousParentState=frameState;
  if(updateHeading)g.turretCoarseYaw=atan2f(effectiveBasis[2][0],effectiveBasis[2][2]);
  }
  // Native turret mount already positions the body around its swivel as
  // the gun rotates. Follow that anchor, never add a second camera-only orbit.
  if(!reuseGameFrame&&!attached&&frameState!=0x102){const auto& center=g.nativeActive?g.nativeCenter:hmd;auto pivot=vrheadmotion::eyeFromPivot();float neck[3]={pivot.x,pivot.y,pivot.z},rotated[3];Q orientation{center.orientation[0],center.orientation[1],center.orientation[2],center.orientation[3]};rotate(orientation,neck,rotated);g.roomMotion.anchorController(RFGRVR_HeadCam_ControllerMoving(),center.position,rotated,g.origin);}else if(!reuseGameFrame){g.roomMotion.controllerWasMoving=false;g.roomMotion.bodySampled=false;}
  if(!reuseGameFrame){bool seated=attached&&(frameState==8||frameState==9||frameState==10);const auto& center=g.nativeActive?g.nativeCenter:hmd;seatOrigin.update(seated,RFGRVR_VehicleSitting(),center.position[1],GetTickCount64(),g.origin[1]);}
  const float* calibration=reuseGameFrame?g.nativeGameCalibration:g.calibration;
  const float* origin=reuseGameFrame?g.nativeGameOrigin:g.origin;
  Q start{calibration[0],calibration[1],calibration[2],calibration[3]};
  Q delta=multiply(conjugate(start),q);
  // OpenXR right/up/back coordinate deltas mapped onto engine right/up/forward.
 float displacement[3]={hmd.position[0]-origin[0],hmd.position[1]-origin[1],hmd.position[2]-origin[2]};
 float mountedRoom[3]{};if(reuseGameFrame)memcpy(mountedRoom,g.nativeGameTurretRoom,12);else{RFGRVR_HeadCam_TurretRoom(mountedRoom);if(g.nativeActive)memcpy(g.nativeGameTurretRoom,mountedRoom,12);}displacement[0]-=mountedRoom[0];displacement[2]+=mountedRoom[2];
 float local[3];rotate(conjugate(start),displacement,local);
 float scale=reuseGameFrame?g.nativeGameScale:RFGRVR_HeadCam_WorldScale();
 if(reuseGameFrame)floorEye=g.nativeGameFloorEye;
 if(g.nativeActive&&!reuseGameFrame){memcpy(g.nativeGameHead,head,12);memcpy(g.nativeGameOrigin,g.origin,12);memcpy(g.nativeGameCalibration,g.calibration,16);memcpy(g.nativeGameBasis,effectiveBasis,36);g.nativeGameParent.capture(frameState,attached);g.nativeGameScale=scale;g.nativeGameSceneScale=RFGRVR_HeadCam_SceneScale();g.nativeGameFloorEye=floorEye;g.nativeGameFrameReady=true;if(!popup&&frameState<0x100)g.gameplayViewSaved=true;}
 // Preserve tracked center translation in occupied seats, including the
 // natural eye arc around the neck. Both eyes use the same mount origin;
 // removing the center X/Z displacement rotates around the optical center.
 float dx=local[0]*scale,dy=local[1]*scale,dz=local[2]*scale;
 if(floorEye<0)dy=g.nativeActive?(hmd.position[1]-g.nativeCenter.position[1])*scale:0;
 // Animation owns center-eye vertical travel, never the eye-to-eye offset.
 // Flattening both eye heights breaks binocular alignment when the head rolls.
 if(!attached&&floorEye>0){auto cfg=vrsettings::get();float height=hmd.position[1];if(cfg.value[vrsettings::Seated]&&g.tracking)height+=g.tracking->calibratedHeadHeight-cfg.seatHeightCm/100.f;dy=RFGRVR_FloorEyeOffset(height,floorEye,scale);}
 if(!popup&&frameState!=0x102&&!attached&&!RFGRVR_HeadCam_ControllerMoving()&&(!g.nativeActive||g.nativeEye==0)){
 float roomRaw[3];memcpy(roomRaw,displacement,12);if(g.nativeActive)for(int j=0;j<3;++j)roomRaw[j]=g.nativeCenter.position[j]-g.origin[j];
 const RFGRPose& center=g.nativeActive?g.nativeCenter:hmd;
 auto pivot=vrheadmotion::eyeFromPivot();float neck[3]={pivot.x,pivot.y,pivot.z},rotatedNeck[3],bodyRaw[3];Q neckQ{center.orientation[0],center.orientation[1],center.orientation[2],center.orientation[3]};rotate(neckQ,neck,rotatedNeck);
 g.roomMotion.displacement(roomRaw,rotatedNeck,bodyRaw);memcpy(roomRaw,bodyRaw,12);
 float roomLocal[3];rotate(conjugate(start),roomRaw,roomLocal);
 float wx=roomLocal[0]*effectiveBasis[0][0]-roomLocal[2]*effectiveBasis[2][0],wz=roomLocal[0]*effectiveBasis[0][2]-roomLocal[2]*effectiveBasis[2][2];
 RFGRVR_HeadCam_RoomRequest(wx*scale,wz*scale,roomRaw[0],roomRaw[2]);}
 else if(attached||RFGRVR_HeadCam_ControllerMoving())RFGRVR_HeadCam_RoomRequest(0,0,0,0);
  for(int j=0;j<3;++j)pos[j]=head[j]+dx*effectiveBasis[0][j]+dy*effectiveBasis[1][j]-dz*effectiveBasis[2][j];
  // Per-eye orientation is a calibrated rotation of the native camera's basis.
  float rotated[3][3];
  for(int k=0;k<3;++k){float vr[3]={0,0,0};
    // Convert engine basis vector to XR-local coordinates, rotate there,
    // then convert back to engine world-space basis.
    vr[k]=k==2?-1.f:1.f;
    float spun[3];rotate(delta,vr,spun);
    for(int j=0;j<3;++j)
      rotated[k][j]=spun[0]*effectiveBasis[0][j]+spun[1]*effectiveBasis[1][j]-spun[2]*effectiveBasis[2][j];
  }
  if(updateHeading){float optical[3]={0,0,0},eyeOffset[3]{};if(g.nativeActive)for(int j=0;j<3;++j)optical[j]=hmd.position[j]-g.nativeCenter.position[j];rotate(conjugate(start),optical,eyeOffset);float center[3];for(int j=0;j<3;++j)center[j]=pos[j]-scale*(eyeOffset[0]*effectiveBasis[0][j]+eyeOffset[1]*effectiveBasis[1][j]-eyeOffset[2]*effectiveBasis[2][j]);RFGRVR_AudioListener(center,&rotated[0][0]);}
  // If F8's HMD-to-mouse fallback owns camera yaw/pitch, do NOT also apply
  // tracked rotation to the render matrix. Both modes still use head position.
  if(!RFGRVR_LegacyLook_Enabled()){
   float yaw=atan2f(rotated[2][0],rotated[2][2])-atan2f(basis[2][0],basis[2][2]);
   while(yaw>3.141592654f)yaw-=6.283185307f;while(yaw< -3.141592654f)yaw+=6.283185307f;
   const auto clamp=[](float x){return x< -1.f?-1.f:(x>1.f?1.f:x);};
   if(updateHeading&&!popup){
    RFGRVRHudHeading::publish(atan2f(rotated[2][0],rotated[2][2]));
    if(!attached||frameState<=2)RFGRVR_HeadCam_SetBodyYaw(atan2f(rotated[2][0],rotated[2][2]));
    if(RFGRVR_HeadCam_TurretMounted()){g.turretYaw=atan2f(basis[2][0],basis[2][2]);g.turretPitch=asinf(clamp(basis[2][1]));g.turretTick=GetTickCount64();}
    g.facingYaw.store(yaw);g.facingPitch.store(asinf(clamp(rotated[2][1]))-asinf(clamp(basis[2][1])));
    g.facingTick.store(GetTickCount64(),std::memory_order_release);
   }
   memcpy(g.savedMatrix,m,sizeof(m));
   for(int k=0;k<3;++k)for(int j=0;j<3;++j)m[k*3+j]=rotated[k][j];
   memcpy(g.writtenMatrix,m,sizeof(m));memcpy(matrix,m,sizeof(m));g.matrixOutstanding=true;
  }
  ++g.trackedFrames;
 }else{
  // A transient invalid head/frame sample must not replace the established
  // room heading with the native camera yaw on the next valid sample.
  if(headMode)++g.trackingRejected;
 }
 if(!trackingOK)g.renderedPoseValid=false;
 if(trackingOK&&!g.nativeActive){
  // Freeze the selected eye's optical frustum with this camera input. The
  // stable alternating renderer can use the full source image per eye rather
  // than a wide symmetric view that the bridge crops down afterward.
  for(unsigned tries=0;tries<3;++tries){auto* t=g.tracking;LONG a=t->stereoSequence;if(a&1)continue;
   MemoryBarrier();float fov[4];memcpy(fov,t->eyes[g.nextEye].fov,16);LONG valid=t->stereoValid;MemoryBarrier();
   if(a!=t->stereoSequence||!valid)continue;
   RFGRVREyeProjection check{};if(RFGRVR_BuildEngineProjection(fov,.1f,475.f,&check)){memcpy(g.temporalEyeFov,fov,16);g.temporalEyeFovValid=true;}break;
  }
  Q q{hmd.orientation[0],hmd.orientation[1],hmd.orientation[2],hmd.orientation[3]};float local[3]={g.nextEye==0?-HALF_IPD:HALF_IPD,0,0},offset[3];rotate(q,local,offset);
  for(int j=0;j<3;++j)g.renderedPose.position[j]+=offset[j];
 }
 // Physical IPD, now measured along the oriented eye-right basis.
 const float sign=g.nextEye==0?-1.f:1.f;
 for(int j=0;j<3;++j)g.shifted[j]=pos[j]+(g.nativeActive?0.f:sign*HALF_IPD*RFGRVR_HeadCam_WorldScale()*m[j]);
 // Keep head/controller translations and avatar reach at the saved player
 // scale. The scene receives only the independent binocular world-scale delta.
 vrworldview::prepared={};if(trackingOK){float extra[3]={};float difference=(reuseGameFrame?g.nativeGameSceneScale:RFGRVR_HeadCam_SceneScale())-(reuseGameFrame?g.nativeGameScale:RFGRVR_HeadCam_WorldScale());
  if(g.nativeActive){float optical[3],localOptical[3];for(int j=0;j<3;++j)optical[j]=hmd.position[j]-g.nativeCenter.position[j];const float* c=reuseGameFrame?g.nativeGameCalibration:g.calibration;Q zero{c[0],c[1],c[2],c[3]};rotate(conjugate(zero),optical,localOptical);for(int j=0;j<3;++j)extra[j]=difference*(localOptical[0]*g.lastEffective[0][j]+localOptical[1]*g.lastEffective[1][j]-localOptical[2]*g.lastEffective[2][j]);}
  else for(int j=0;j<3;++j)extra[j]=sign*HALF_IPD*difference*m[j];
  vrworldview::prepared={extra[0],extra[1],extra[2]};for(int j=0;j<3;++j)g.shifted[j]+=extra[j];
 }
 // Apply a shared world-up translation after optical scaling. Publishing
 // subtracts prepared, so IK and inherited-motion calculations are unchanged.
 if(trackingOK&&!popup&&frameState<=2){float elevation=vrsettings::playerElevation();g.shifted[1]+=elevation;vrworldview::prepared.y+=elevation;}
 memcpy(g.original,(unsigned char*)camera+0x2c,12);
 memcpy(p,g.shifted,12);g.camera=camera;g.outstanding=true;
 if(trackingOK){
  float frame[3][3];memcpy(frame,g.lastEffective,36);
  if(!popup&&frameState!=0x101&&frameState!=0x102&&(!g.nativeActive||g.nativeEye==0)){
   float playerAnchor[3]={g.shifted[0]-vrworldview::prepared.x,g.shifted[1]-vrworldview::prepared.y,g.shifted[2]-vrworldview::prepared.z};RFGRVR_Arms_Publish(g.nativeActive?&g.nativeTracking:g.tracking,playerAnchor,&frame[0][0],g.calibration,&g.renderedPose);
   RFGRVR_VehicleView(g.shifted,m,&g.renderedPose);
   RFGRVR_HeadCam_RefreshArms();
  }
  RFGRVR_HeadCam_RenderBegin(g.shifted,m);
 }
 ++g.cameraCalls;
}
extern "C" void RFGRVR_Temporal_Present(IDXGISwapChain* swap){
 if(swap)g.nativeSwap=swap;
 const bool nativeUsed=g.nativeUsed;g.nativeUsed=false;
 bool pressed=false; // Final setup: diagnostic stereo toggle removed.
 if(pressed&&!g.wasF6){
  g.enabled=!g.enabled;
  OutputDebugStringA(g.enabled?"RFGR TEMPORAL: F6 enabled\n":"RFGR TEMPORAL: F6 disabled\n");
  if(!g.enabled){restore();if(g.ipc)InterlockedExchange(&g.ipc->ready,0);}
  else if(g.ipc){MemoryBarrier();InterlockedExchange(&g.ipc->ready,1);}
 }
 g.wasF6=pressed;
 if(nativeUsed){restore();return;}
 if(RFGRVR_HeadCam_MenuScene()){restore();return;}
 if(!g.enabled||!RFGRVR_GameplayProjection_Enabled()){
  restore();g.calibrated=false;g.lastHeadMode=false;
  if(g.ipc)InterlockedExchange(&g.ipc->ready,0);
  return;
 }
 // A busy consumer can make a native pair unavailable this frame. Retain the
 // last whole pair instead of replacing only one eye with a temporal image.
 if(g.nativeContinuous){
  // Gameplay/menu transitions clear ready. Re-advertise an existing complete
  // pair on resume so the consumer can drain key 1 and unblock the next pair.
  if(g.ipc&&g.nativeFrame&&g.texture[0]&&g.texture[1])InterlockedExchange(&g.ipc->ready,1);
  restore();return;
 }
 if(g.ipc)InterlockedExchange(&g.ipc->ready,1);
 ++g.frameCount;
 if(g.frameCount%180==0){
  static ULONGLONG previousReport=0;const auto reportTick=GetTickCount64();
  const double fps=previousReport&&reportTick>previousReport?180000.0/double(reportTick-previousReport):0;previousReport=reportTick;
  char line[256];
  sprintf_s(line,"RFGR TEMPORAL: camera=%u copies=%u failures=%u/%u eye=%u poseApplied=%u poseRejected=%u source=%ux%u gameFPS=%.1f\n",
   g.cameraCalls.load(),g.copies.load(),g.cameraFailures.load(),g.captureFailures.load(),g.nextEye,
   g.trackedFrames.load(),g.trackingRejected.load(),g.width,g.height,fps);
  OutputDebugStringA(line);
  wchar_t logfile[MAX_PATH]={};
  if(GetModuleFileNameW(nullptr,logfile,MAX_PATH)){
   wchar_t* slash=wcsrchr(logfile,L'\\');
   if(slash){wcscpy_s(slash+1,MAX_PATH-(size_t)(slash+1-logfile),L"RFGRVR-Temporal-Stereo-Stats.txt");
    FILE* f=nullptr;
    if(_wfopen_s(&f,logfile,L"a")==0&&f){fputs(line,f);fclose(f);}
   }
  }
 }
 if(!swap){restore();return;}
 ComPtr<ID3D11Texture2D> back;
 if(FAILED(swap->GetBuffer(0,__uuidof(ID3D11Texture2D),(void**)back.GetAddressOf()))){++g.captureFailures;restore();return;}
 if(!setup(swap,back.Get())){++g.captureFailures;restore();return;}
 // A frame with no verified camera mutation is not labelled an eye image.
 if(!g.outstanding){++g.cameraFailures;return;}
 const unsigned eye=g.nextEye;
 HRESULT hr=g.mutex[eye]->AcquireSync(0,0);
 if(hr==S_OK){
  float projection[16]{};
  const bool measured=g.renderedPoseValid&&memoryReady((char*)g.camera+0xc0,64,false);
  if(measured){if(g.temporalProjectionValid)memcpy(projection,g.temporalProjection,64);else memcpy(projection,(char*)g.camera+0xc0,64);}
  const bool optics=measured&&finite(projection[0])&&finite(projection[5])&&projection[0]>.01f&&projection[5]>.01f;
  g.ipc->renderMode=optics?2:0;
  if(optics){
   memcpy(g.ipc->eyePosition[eye],g.renderedPose.position,12);memcpy(g.ipc->eyeOrientation[eye],g.renderedPose.orientation,16);
   float coefficients[4]={projection[0],projection[5],projection[8],projection[9]};memcpy(g.ipc->sourceProjection[eye],coefficients,16);
  }
 g.context->CopyResource(g.texture[eye].Get(),back.Get());g.context->Flush();
  if(SUCCEEDED(g.mutex[eye]->ReleaseSync(1))){
   InterlockedIncrement(&g.ipc->eyeFrames[eye]);++g.copies;g.nextEye^=1;
  }else ++g.captureFailures;
 }
 // Do not accumulate offsets, and don't corrupt a position updated by the engine.
 restore();
}
extern "C" __declspec(dllexport) void __stdcall RFGRVR_Temporal_Stats(unsigned* cameraCalls,unsigned* eyeCopies,unsigned* failures){
 if(cameraCalls)*cameraCalls=g.cameraCalls.load();if(eyeCopies)*eyeCopies=g.copies.load();
 if(failures)*failures=g.captureFailures.load()+g.cameraFailures.load();
}

// Same-frame producer. Both keyed mutexes stay producer-owned until BOTH eye
// passes finish; a partial pass is never handed to the headset.
static thread_local bool pairBuffersBusy=false;
static std::atomic<unsigned> menuPairStage{0};
extern "C" bool RFGRVR_NativePair_BuffersBusy(){return pairBuffersBusy;}
extern "C" bool RFGRVR_NativePair_Begin(){
 pairBuffersBusy=false;menuPairStage=1;
 // The menu character framebuffer is valid, but forcing the gameplay scene's
 // camera preparation here dereferences an absent world/avatar (native crash
 // 3D67BF). A dedicated model render pass must own menu stereo instead.
 if(RFGRVR_HeadCam_MenuScene()){menuPairStage=0x100;return false;}
 if(!g.nativeEnabled||!g.enabled||!g.nativeSwap||!RFGRVR_GameplayProjection_Enabled()||
    !RFGRVR_HeadCam_Enabled()||RFGRVR_LegacyLook_Enabled())return false;
 menuPairStage=2;RFGRPose dummy{};if(!trackedPose(dummy))return false;menuPairStage=3;
 bool snapshot=false;
 for(int tries=0;tries<3;++tries){
  auto* t=g.tracking;LONG posesBefore=t->poseSequence;LONG before=t->stereoSequence;if((before|posesBefore)&1)continue;
  MemoryBarrier();RFGREye a=t->eyes[0],b=t->eyes[1];int64_t predicted=t->predictedDisplayTime;LONG valid=t->stereoValid;
  RFGRPose left=t->left,right=t->right,leftAim=t->leftAim,rightAim=t->rightAim;LONG poseSample=t->poseSamples;
  MemoryBarrier();LONG after=t->stereoSequence;
  if(before!=after||posesBefore!=t->poseSequence||!valid)continue;
  bool good=true;for(auto* eye:{&a,&b}){
   if((eye->pose.validFlags&3)!=3)good=false;
   Q q{eye->pose.orientation[0],eye->pose.orientation[1],eye->pose.orientation[2],eye->pose.orientation[3]};
   if(!validQ(q))good=false;
   for(float v:eye->pose.position)if(!finite(v))good=false;
   RFGRVREyeProjection p{};if(!RFGRVR_BuildEngineProjection(eye->fov,.1f,475.f,&p))good=false;
  }
  float distance=0;for(int j=0;j<3;++j){float d=a.pose.position[j]-b.pose.position[j];distance+=d*d;}
  if(!good||distance<.0001f||distance>.04f)return false;
  g.nativeEyes[0]=a;g.nativeEyes[1]=b;g.nativeTime=predicted;
  g.nativeTracking.calibratedHeadHeight=t->calibratedHeadHeight;g.nativeTracking.calibratedArmSpan=t->calibratedArmSpan;g.nativeTracking.calibrationReady=t->calibrationReady;g.nativeTracking.calibrationFloorValid=t->calibrationFloorValid;
  g.nativeTracking.version=RFGR_PROTOCOL;g.nativeTracking.poseSamples=poseSample;g.nativeTracking.left=left;g.nativeTracking.right=right;g.nativeTracking.leftAim=leftAim;g.nativeTracking.rightAim=rightAim;
  g.nativeTracking.gamepadActive=RFGRVR_CopyGripInput(t,g.nativeTracking.gripValue);g.nativeTracking.inputSequence=0;
  snapshot=true;break;
 }
 if(!snapshot)return false;menuPairStage=4;
 ComPtr<ID3D11Texture2D> back;
 if(FAILED(g.nativeSwap->GetBuffer(0,__uuidof(ID3D11Texture2D),(void**)back.GetAddressOf())))return false;
 menuPairStage=5;if(!setup(g.nativeSwap.Get(),back.Get()))return false;menuPairStage=6;
 // Only a temporal-to-native handoff may replace a pending eye. During native
 // playback keep a completed pair available until the consumer acquires it;
 // repeatedly taking key 1 back starves the compositor at its frame boundary.
 const bool handoff=g.ipc->renderMode!=1&&g.ipc->renderMode!=3&&g.ipc->renderMode!=4;
 // Nonblocking ownership: retain the established pacing path. Never reclaim
 // a pending native pair or wait on the second mutex while holding one.
 if(!RFGRVR_AcquirePair(g.mutex[0].Get(),g.mutex[1].Get(),handoff)){pairBuffersBusy=true;return false;}
 // Only replace the temporal camera after both eye buffers are ours. A busy
 // consumer must leave the already prepared fallback frame intact.
 restore();
 g.nativeCenter=g.nativeEyes[0].pose;
 for(int j=0;j<3;++j)g.nativeCenter.position[j]=(g.nativeEyes[0].pose.position[j]+g.nativeEyes[1].pose.position[j])*.5f;
 g.nativeTracking.hmd=g.nativeCenter;
 if(!g.nativeFrame){g.evidenceWritten=false;g.evidence[0].Reset();g.evidence[1].Reset();}
 menuPairStage=7;g.nativeActive=true;g.nativeUsed=true;++g.nativeFrame;pairTiming.begin(g.device.Get(),g.context.Get());return true;
}
extern "C" void RFGRVR_NativePair_SetRequested(bool on){
g.nativeEnabled=on;
}
extern "C" void RFGRVR_NativePair_TestMode(unsigned mode,unsigned mask){
 if(mode!=g.evidenceMode||mask!=g.evidenceMask){g.evidenceMode=mode;g.evidenceMask=mask;g.evidenceWritten=false;g.evidence[0].Reset();g.evidence[1].Reset();}
 // Diagnostic only: identical inputs prove whether a defect requires disparity.
 if(mode==1)g.nativeEyes[1]=g.nativeEyes[0];
}
extern "C" void RFGRVR_NativePair_Continuous(bool enabled){g.nativeContinuous=enabled;}
extern "C" bool RFGRVR_NativePair_ViewActive(){
 return g.enabled&&g.nativeContinuous&&g.nativeFrame&&g.ipc&&g.ipc->ready==1&&
  (!g.tracking||!g.tracking->theaterMode)&&RFGRVR_GameplayProjection_Enabled();
}
extern "C" void RFGRVR_NativeTurn(int degrees){g.turnMilliDegrees.fetch_add(degrees*1000);}
extern "C" void RFGRVR_NativeTurnAxis(float axis){g.turnAxis.store(std::isfinite(axis)?axis:0.f);g.turnAxisTick.store(GetTickCount64());}
extern "C" bool RFGRVR_NativeParented(){return g.parentActive.load();}
extern "C" bool RFGRVR_NativeTurretAxes(short* x,short* y){
 static RFGRVRTurretHandle handle;if(!x||!y)return false;*x=*y=0;float yaw=0,pitch=0,pivot[3]{},hand[3]{},aim[3]{};unsigned id=0;
 if(!RFGRVR_HeadCam_TurretMounted()||!RFGRVR_HeadCam_TurretPivot(pivot,&id)||!RFGRVR_HeadCam_TurretAngles(&yaw,&pitch)||!RFGRVR_Arms_TurretHand(hand,aim)){handle.reset();return false;}
 return handle.update(id,hand,aim,g.turretCoarseYaw.load(),yaw,pitch,GetTickCount64(),x,y,RFGRVR_Arms_TurretLever(pivot));
}

extern "C" bool RFGRVR_NativeFacing(float* yaw,float* pitch){
 if(g.parentActive.load()&&g.parentState.load()>2)return false;
 if(RFGRVR_HeadCam_MenuScene()||RFGRVR_HeadCam_PopupMenu())return false;
 if(!yaw||!pitch||RFGRVR_LegacyLook_Enabled()||!RFGRVR_HeadCam_Enabled()||!RFGRVR_GameplayProjection_Enabled())return false;
 auto tick=g.facingTick.load(std::memory_order_acquire);if(!tick||GetTickCount64()-tick>250)return false;
 *yaw=g.facingYaw.load();*pitch=g.facingPitch.load();return true;
}
extern "C" void RFGRVR_NativePair_Select(unsigned eye){vrworldview::prepared={};restore();g.nativeEye=eye;if(!eye){laserFrame=g.nativeFrame;laserFrameState=vrlaser::snapshot();g.nativeGameFrameReady=false;}g.nativeProjectionCalls=0;RFGRAPCTargets::configure(g.device.Get(),g.width,g.height);if(!eye){AcquireSRWLockShared(&RFGRVRAPC::lock);bool inAPC=(RFGRVRAPC::packet.active&4)!=0;ReleaseSRWLockShared(&RFGRVRAPC::lock);if(!inAPC&&!vrscope::visible())RFGRAPCTargets::releaseAuxiliary();}{AcquireSRWLockShared(&RFGRVRAPC::lock);bool inAPC=(RFGRVRAPC::packet.active&4)!=0;ReleaseSRWLockShared(&RFGRVRAPC::lock);RFGRAPCTargets::beginDepth(inAPC||vrscope::visible()||laserFrameState.active);}}
extern "C" bool RFGRVR_NativePair_Capture(unsigned eye){
 if(!g.nativeActive||!g.outstanding||!g.nativeProjectionCalls||eye!=g.nativeEye)return false;
 ComPtr<ID3D11Texture2D> back;
 if(FAILED(g.nativeSwap->GetBuffer(0,__uuidof(ID3D11Texture2D),(void**)back.GetAddressOf())))return false;
 D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);
 if(desc.Width!=g.width||desc.Height!=g.height||menuColorFormat(desc.Format)!=g.format)return false;
 if(g.nativeFrame==1||g.nativeFrame%300==0){char path[MAX_PATH]{};GetModuleFileNameA(nullptr,path,MAX_PATH);char* slash=strrchr(path,92);if(slash){strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-Stereo-Geometry.csv");FILE* f=nullptr;if(!fopen_s(&f,path,"a")&&f){const auto& pose=g.nativeEyes[eye].pose;fprintf(f,"%llu,%u,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f\n",g.nativeFrame,eye,g.shifted[0],g.shifted[1],g.shifted[2],g.nativeGameScale,pose.position[0],pose.position[1],pose.position[2],g.writtenMatrix[0],g.writtenMatrix[1],g.writtenMatrix[2],g.writtenMatrix[3],g.writtenMatrix[4],g.writtenMatrix[5],g.writtenMatrix[6],g.writtenMatrix[7],g.writtenMatrix[8],g.nativeSourceProjection[eye][0],g.nativeSourceProjection[eye][1]);fclose(f);}}}
  // Depth-tested monitor geometry is part of each eye, never an XR overlay.
 float screenProjection[16]{};if(g.camera)memcpy(screenProjection,(char*)g.camera+0xc0,64);vrarm::Pose eyePose{};memcpy(&eyePose.p,g.shifted,12);memcpy(&eyePose.b,g.writtenMatrix,36);scopeOptics[eye]=vrscope::optics(vrscope::snapshot(),eyePose,(std::max)(g.width*.5f*g.nativeSourceProjection[eye][0],g.height*.5f*g.nativeSourceProjection[eye][1]));ComPtr<ID3D11DepthStencilView> screenDepth;D3D11_COMPARISON_FUNC screenCompare;float screenMin,screenMax;uint64_t screenScore;{std::lock_guard<std::recursive_mutex> held(RFGRAPCTargets::guard);screenDepth=RFGRAPCTargets::sceneDepth;screenCompare=RFGRAPCTargets::depthCompare;screenMin=RFGRAPCTargets::depthMin;screenMax=RFGRAPCTargets::depthMax;screenScore=RFGRAPCTargets::depthScore;}RFGRAPCTargets::collectingDepth=false;
 if(GetTickCount64()-scopeCapturedTick<250&&scopeCapturedKind==vrscope::snapshot().kind&&scopeSurface.draw(g.device.Get(),g.context.Get(),back.Get(),screenDepth.Get(),scopeGpu,eyePose,screenProjection,vrscope::snapshot(),screenCompare,screenMin,screenMax,eye))++scopeDraws;
 apcLastDepthScore=screenScore;apcLastDepthCompare=unsigned(screenCompare);if(worldScreens.draw(g.device.Get(),g.context.Get(),back.Get(),screenDepth.Get(),auxiliaryGpu,eyePose,screenProjection,screenCompare,screenMin,screenMax,g.nativeFrame))++apcScreenDraws;
 if(laserFrame!=g.nativeFrame){laserFrame=g.nativeFrame;laserFrameState=vrlaser::snapshot();}
 vrarm::Pose laserEmitter{};if(RFGRVR_Arms_PistolLaser(&laserEmitter))weaponLaser.draw(g.device.Get(),g.context.Get(),back.Get(),screenDepth.Get(),eyePose,screenProjection,screenCompare,screenMin,screenMax,&laserEmitter,vrworldview::prepared,&laserFrameState);
 g.context->CopyResource(g.texture[eye].Get(),back.Get());
 pairTiming.eye(g.context.Get(),eye);
 if(!g.evidenceWritten){
  D3D11_TEXTURE2D_DESC staging=desc;staging.Usage=D3D11_USAGE_STAGING;staging.BindFlags=0;
  staging.MiscFlags=0;staging.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
  if(SUCCEEDED(g.device->CreateTexture2D(&staging,nullptr,g.evidence[eye].ReleaseAndGetAddressOf())))
   g.context->CopyResource(g.evidence[eye].Get(),back.Get());
 }
 return true;
}
static void saveNativeEvidence(bool survey=false){
 if(g.evidenceWritten||!g.evidence[0]||!g.evidence[1])return;
 for(int eye=0;eye<2;++eye){
  D3D11_MAPPED_SUBRESOURCE map{};if(FAILED(g.context->Map(g.evidence[eye].Get(),0,D3D11_MAP_READ,0,&map)))continue;
  wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');
  if(slash){const wchar_t* name=survey?(eye?L"RFGRVR-Survey-Frame-End.bmp":L"RFGRVR-Survey-Scene-End.bmp"):(eye?L"RFGRVR-Native-Eye-R.bmp":L"RFGRVR-Native-Eye-L.bmp");
   wchar_t testName[96]{};
   if(!survey&&g.evidenceMode!=0){swprintf_s(testName,L"RFGRVR-Eye-Test-%u-%c.bmp",g.evidenceMode,eye?L'R':L'L');name=testName;}
   wcscpy_s(slash+1,MAX_PATH-(slash+1-path),name);
   FILE* f=nullptr;if(_wfopen_s(&f,path,L"wb")==0&&f){
    constexpr int w=640,h=360;BITMAPFILEHEADER file{};BITMAPINFOHEADER info{};
    file.bfType=0x4d42;file.bfOffBits=sizeof(file)+sizeof(info);file.bfSize=file.bfOffBits+w*h*4;
    info.biSize=sizeof(info);info.biWidth=w;info.biHeight=-h;info.biPlanes=1;info.biBitCount=32;info.biSizeImage=w*h*4;
    fwrite(&file,sizeof(file),1,f);fwrite(&info,sizeof(info),1,f);
    const bool rgba=g.format==DXGI_FORMAT_R8G8B8A8_UNORM||g.format==DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){auto* pixel=(unsigned char*)map.pData+(y*g.height/h)*map.RowPitch+(x*g.width/w)*4;
     unsigned char bgra[4]={pixel[rgba?2:0],pixel[1],pixel[rgba?0:2],255};fwrite(bgra,4,1,f);}
    fclose(f);
   }
  }
  g.context->Unmap(g.evidence[eye].Get(),0);g.evidence[eye].Reset();
 }
 g.evidenceWritten=true;
}
extern "C" void RFGRVR_Survey_Capture(bool endFrame){
 if(g.evidenceWritten||!g.nativeSwap||!g.device||!g.context)return;
 unsigned index=endFrame?1:0;if(g.evidence[index])return;
 ComPtr<ID3D11Texture2D> back;if(FAILED(g.nativeSwap->GetBuffer(0,__uuidof(ID3D11Texture2D),(void**)back.GetAddressOf())))return;
 D3D11_TEXTURE2D_DESC d{};back->GetDesc(&d);d.Format=menuColorFormat(d.Format);
 if(d.Width!=g.width||d.Height!=g.height||d.Format!=g.format||d.SampleDesc.Count!=1)return;
 d.Usage=D3D11_USAGE_STAGING;d.BindFlags=0;d.MiscFlags=0;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
 if(FAILED(g.device->CreateTexture2D(&d,nullptr,g.evidence[index].GetAddressOf())))return;
 g.context->CopyResource(g.evidence[index].Get(),back.Get());if(endFrame)saveNativeEvidence(true);
}
extern "C" void RFGRVR_NativePair_End(bool complete){
 restore();if(!g.nativeActive)return;
 pairTiming.end(g.context.Get(),complete);
 if(complete){
  saveNativeEvidence();
  InterlockedIncrement(&g.ipc->pairSequence);MemoryBarrier();
  g.ipc->renderMode=g.evidenceMode==15?3:1;g.ipc->sceneFrame=g.nativeFrame;g.ipc->predictedTime=g.nativeTime;
  for(int i=0;i<2;++i){memcpy(g.ipc->eyePosition[i],g.nativeEyes[i].pose.position,12);
   memcpy(g.ipc->eyeOrientation[i],g.nativeEyes[i].pose.orientation,16);memcpy(g.ipc->eyeFov[i],g.nativeEyes[i].fov,16);
   if(g.evidenceMode==15)memcpy(g.ipc->sourceProjection[i],g.nativeSourceProjection[i],16);}
  MemoryBarrier();InterlockedIncrement(&g.ipc->pairSequence);g.context->Flush();InterlockedExchange(&g.ipc->ready,1);
 }
 // Capture while producer owns the completed eye; the desktop never reads a consumer-owned shared texture.
 if(complete&&g.texture[1]&&vrsettings::get().value[vrsettings::Desktop])g.desktop.capture(g.device.Get(),g.context.Get(),g.texture[1].Get());
 HRESULT a=g.mutex[0]->ReleaseSync(complete?1:0),b=g.mutex[1]->ReleaseSync(complete?1:0);
 if(complete&&SUCCEEDED(a)&&SUCCEEDED(b)){InterlockedIncrement(&g.ipc->eyeFrames[0]);InterlockedIncrement(&g.ipc->eyeFrames[1]);}
 else {g.nativeEnabled=false;InterlockedExchange(&g.ipc->ready,0);}
 g.nativeActive=false;
}
extern "C" void RFGRVR_NativePair_DiagnosticEnd(){
 // Save the comparison, but never submit a deliberately duplicated eye as VR.
 saveNativeEvidence();RFGRVR_NativePair_End(false);g.nativeUsed=false;
}
extern "C" bool RFGRVR_NativePair_Projection(void* camera,float out[16],float* conservativeFov){
 if(!g.nativeActive||!g.outstanding||g.evidenceMode==15)return false;
 // Scene preparation clones the primary camera. Match its exact input pose as
 // well as its original pointer, so worker-side clones retain the eye optics.
 if(g.camera!=camera){auto* candidate=(unsigned char*)camera;
  if(!memoryReady(candidate+8,48,false)||memcmp(candidate+8,g.writtenMatrix,36)||memcmp(candidate+0x2c,g.shifted,12))return false;
 }
 float nearZ=0,farZ=0;auto* c=(unsigned char*)camera;
 if(!memoryReady(c+0x590,8,false))return false;
 memcpy(&nearZ,c+0x590,4);memcpy(&farZ,c+0x594,4);
 RFGRVREyeProjection p{};const auto& e=g.nativeEyes[g.nativeEye];
 if(!RFGRVR_BuildEngineProjection(e.fov,nearZ,farZ,&p))return false;
 memcpy(out,p.columnMajor,64);
 float tx=(std::max)(fabsf(tanf(e.fov[0])),fabsf(tanf(e.fov[1])));
 float ty=(std::max)(fabsf(tanf(e.fov[2])),fabsf(tanf(e.fov[3])));
 float aspect=float(g.width)/float(g.height);
 *conservativeFov=2.f*atanf((std::max)(ty,tx/aspect))*57.295779513f;
 return std::isfinite(*conservativeFov)&&*conservativeFov>0&&*conservativeFov<175;
}
extern "C" void RFGRVR_NativePair_ProjectionApplied(){++g.nativeProjectionCalls;}
extern "C" bool RFGRVR_NativePair_CompatibilityFov(void* camera,float* fov){
 if(!g.nativeActive||!g.outstanding||g.evidenceMode!=15||!camera)return false;
 if(g.camera!=camera){auto* candidate=(unsigned char*)camera;
  if(!memoryReady(candidate+8,48,false)||memcmp(candidate+8,g.writtenMatrix,36)||memcmp(candidate+0x2c,g.shifted,12))return false;}
 float eyes[2][4];for(unsigned e=0;e<2;++e)memcpy(eyes[e],g.nativeEyes[e].fov,16);
 return RFGRVR_CenteredSourceFov(eyes,g.width,g.height,fov);
}
extern "C" void RFGRVR_NativePair_CompatibilityApplied(void* camera){
 if(!g.nativeActive||!g.outstanding||g.evidenceMode!=15||!memoryReady((char*)camera+0xc0,64,false))return;
 float p[16];memcpy(p,(char*)camera+0xc0,64);
 if(!finite(p[0])||!finite(p[5])||p[0]<=0||p[5]<=0)return;
 float coefficients[4]={p[0],p[5],p[8],p[9]};memcpy(g.nativeSourceProjection[g.nativeEye],coefficients,16);++g.nativeProjectionCalls;
}
extern "C" bool RFGRVR_Temporal_EyeProjection(void* camera,float out[16],float* conservativeFov){
 if(g.nativeActive||!g.outstanding||!g.renderedPoseValid||!g.temporalEyeFovValid||!out||!conservativeFov||!g.width||!g.height)return false;
 auto* c=(unsigned char*)camera;
 if(camera!=g.camera){if(!memoryReady(c+8,48,false)||memcmp(c+8,g.writtenMatrix,36)||memcmp(c+0x2c,g.shifted,12))return false;}
 if(!memoryReady(c+0x590,8,false))return false;
 float nearZ=0,farZ=0;memcpy(&nearZ,c+0x590,4);memcpy(&farZ,c+0x594,4);
 RFGRVREyeProjection projection{};if(!RFGRVR_BuildEngineProjection(g.temporalEyeFov,nearZ,farZ,&projection))return false;
 const float* f=g.temporalEyeFov;float tx=(std::max)(fabsf(tanf(f[0])),fabsf(tanf(f[1]))),ty=(std::max)(fabsf(tanf(f[2])),fabsf(tanf(f[3])));
 *conservativeFov=2.f*atanf((std::max)(ty,tx*float(g.height)/float(g.width)))*57.295779513f;
 if(!finite(*conservativeFov)||*conservativeFov<=0||*conservativeFov>=175)return false;
 memcpy(out,projection.columnMajor,64);return true;
}

extern "C" bool RFGRVR_Temporal_OpticsFov(void* camera,float* fov){

 // Coverage must remain correct even while the engine changes its source size.
 // Resolution controls detail; it must never gate headset ray coverage.
 unsigned requestedWidth=0,requestedHeight=0;
 if(!RFGRVR_RenderWindow_Requested(&requestedWidth,&requestedHeight))return false;
 if(!fov||g.nativeActive||!g.outstanding||!g.renderedPoseValid||!g.tracking||!g.width||!g.height)return false;
 if(camera!=g.camera){
  if(!memoryReady((char*)camera+8,36,false)||!memoryReady((char*)camera+0x2c,12,false))return false;
  if(memcmp((char*)camera+8,g.writtenMatrix,36)||memcmp((char*)camera+0x2c,g.shifted,12))return false;
 }
 auto* t=g.tracking;RFGREye eyes[2]{};bool ok=false;
 for(int i=0;i<3;++i){LONG a=t->stereoSequence;if(a&1)continue;MemoryBarrier();memcpy(eyes,t->eyes,sizeof(eyes));LONG valid=t->stereoValid;MemoryBarrier();if(a==t->stereoSequence&&valid){ok=true;break;}}
 if(!ok)return false;
 float aspect=float(g.width)/g.height,extent=0;
 for(auto& e:eyes){for(int i=0;i<4;++i){float angle=e.fov[i];if(!finite(angle)||fabsf(angle)>1.5f)return false;float tangent=fabsf(tanf(angle));if(i<2)tangent/=aspect;extent=(std::max)(extent,tangent);}}
 *fov=2.f*atanf(extent*1.03f)*180.f/3.14159265358979323846f;
 return finite(*fov)&&*fov>45&&*fov<160;
}


extern "C" void RFGRVR_Temporal_OpticsApplied(void* camera){
 if(!g.outstanding||!memoryReady((char*)camera+0xc0,64,false))return;
 memcpy(g.temporalProjection,(char*)camera+0xc0,64);g.temporalProjectionValid=true;
}

// Keep the primary camera optics consistent for secondary sky/weather work.
// Only retain the persistent tracked camera, never a worker's stack clone.
extern "C" bool RFGRVR_Temporal_HoldFov(void* camera,float original,float current){
 if(camera!=g.camera||!g.outstanding||!memoryReady((char*)camera+0x140,4,true))return false;
 if(!g.fovOutstanding)g.savedFov=original;
 g.writtenFov=current;g.fovOutstanding=true;return true;
}










extern "C" bool RFGRVR_Temporal_PPDSize(int ppd,unsigned* w,unsigned* h){float fovs[2][4];for(unsigned e=0;e<2;++e)memcpy(fovs[e],g.nativeEyes[e].fov,16);return RFGRVR_PPDSize(ppd,fovs,w,h);}


extern "C" void RFGRVR_DesktopPresent(IDXGISwapChain* swap){
 if(!swap||!RFGRVR_HeadCam_Enabled()||!g.context)return;
 ComPtr<ID3D11Texture2D> back;if(FAILED(swap->GetBuffer(0,IID_PPV_ARGS(&back))))return;
 g.desktop.present(g.device.Get(),g.context.Get(),back.Get(),vrsettings::get().value[vrsettings::Desktop]!=0);
}
