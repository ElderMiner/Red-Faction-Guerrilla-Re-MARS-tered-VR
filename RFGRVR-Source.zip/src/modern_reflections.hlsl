TextureCube<float4> source:register(t0);
SamplerState linearClamp:register(s0);
RWTexture2DArray<float4> filtered:register(u0);
cbuffer Settings:register(b0){uint outputSize;uint samples;float roughness;float sourceSize;};
float3 direction(uint face,float2 uv){return normalize(face==0?float3(1,-uv.y,-uv.x):face==1?float3(-1,-uv.y,uv.x):face==2?float3(uv.x,1,uv.y):face==3?float3(uv.x,-1,-uv.y):face==4?float3(uv.x,-uv.y,1):float3(-uv.x,-uv.y,-1));}
float inverseBits(uint bits){bits=(bits<<16)|(bits>>16);bits=((bits&0x55555555)<<1)|((bits&0xaaaaaaaa)>>1);bits=((bits&0x33333333)<<2)|((bits&0xcccccccc)>>2);bits=((bits&0x0f0f0f0f)<<4)|((bits&0xf0f0f0f0)>>4);bits=((bits&0x00ff00ff)<<8)|((bits&0xff00ff00)>>8);return bits*2.3283064365386963e-10;}
[numthreads(8,8,1)]void main(uint3 id:SV_DispatchThreadID){
 if(id.x>=outputSize||id.y>=outputSize||id.z>=6)return;float3 N=direction(id.z,(id.xy+.5)/outputSize*2-1);
 if(roughness<.001){float3 c=source.SampleLevel(linearClamp,N,0).rgb;filtered[id]=float4(all(isfinite(c))?clamp(c,0,65504):0,1);return;}
 float3 up=abs(N.z)<.999?float3(0,0,1):float3(1,0,0),T=normalize(cross(up,N)),B=cross(N,T);float alpha=roughness*roughness,a2=alpha*alpha;float3 sum=0;float weight=0;uint width,height,levels;source.GetDimensions(0,width,height,levels);
 [loop]for(uint i=0;i<samples;++i){float2 xi=float2((i+.5)/samples,inverseBits(i));float phi=6.28318530718*xi.x,cosTheta=sqrt((1-xi.y)/max(1+(a2-1)*xi.y,1e-6)),sinTheta=sqrt(saturate(1-cosTheta*cosTheta));float3 H=normalize(T*cos(phi)*sinTheta+B*sin(phi)*sinTheta+N*cosTheta);float vh=saturate(dot(N,H));float3 L=normalize(2*vh*H-N);float nl=saturate(dot(N,L));if(nl<=0)continue;
  float den=cosTheta*cosTheta*(a2-1)+1,D=a2/max(3.14159265359*den*den,1e-8),pdf=max(D*cosTheta/max(4*vh,1e-6),1e-6);float areaSample=1/(samples*pdf),areaTexel=12.5663706144/(6*sourceSize*sourceSize);float mip=clamp(.5*log2(areaSample/areaTexel),0,float(levels)-1);float3 c=source.SampleLevel(linearClamp,L,mip).rgb;sum+=(all(isfinite(c))?clamp(c,0,65504):0)*nl;weight+=nl;
 }
 filtered[id]=float4(sum/max(weight,1e-6),1);
}
