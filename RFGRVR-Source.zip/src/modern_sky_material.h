#pragma once
#include "modern_sky_material_source.h"
namespace modernskymaterial {
struct Identity{size_t bytes;unsigned char hash[16];int mode;};
inline constexpr Identity identities[]={
{1800, {0x80,0x00,0x79,0x80,0x83,0xb4,0xc2,0x13,0xbd,0x3f,0xeb,0x19,0xfc,0x44,0x7c,0xa2},0},
{1872, {0x11,0x56,0xc6,0x37,0xcb,0xce,0x22,0x52,0x0e,0x78,0xe9,0x3d,0x4d,0xdf,0x6a,0x41},1},
{4060,{0xc0,0x3c,0x7e,0x00,0x2b,0x0e,0x04,0xf7,0x2c,0xd5,0x4d,0xa2,0x42,0x5a,0xe5,0x6f},2},
{4184,{0x29,0xde,0x0a,0x46,0x94,0x0d,0x8f,0x2b,0x5b,0xe9,0xa2,0x19,0xb8,0x73,0x9d,0xd4},3}
};
using Create=HRESULT(STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11PixelShader**);
inline int identify(const void* p,size_t n){if(!p||n<32||memcmp(p,"DXBC",4))return -1;for(auto i:identities)if(n==i.bytes&&!memcmp((const char*)p+4,i.hash,16))return i.mode;return -1;}
inline HRESULT create(Create native,ID3D11Device* device,const void* original,SIZE_T size,ID3D11PixelShader** shader,int mode,bool& substituted){
 substituted=false;if(mode<0||mode>3)return native(device,original,size,nullptr,shader);
 static std::mutex mutex;static Microsoft::WRL::ComPtr<ID3DBlob> codes[4];std::lock_guard<std::mutex> lock(mutex);HRESULT hr=S_OK;
 if(!codes[mode]){const char* modes[]={"0","1","2","3"};D3D_SHADER_MACRO macros[]={{"MODE",modes[mode]},{nullptr,nullptr}};hr=D3DCompile(source,sizeof(source)-1,"RFGRVR atmospheric sky",macros,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&codes[mode],nullptr);}
 if(SUCCEEDED(hr))hr=native(device,codes[mode]->GetBufferPointer(),codes[mode]->GetBufferSize(),nullptr,shader);
 if(SUCCEEDED(hr)){substituted=true;return hr;}return native(device,original,size,nullptr,shader);
}
}
