
cbuffer Common:register(b0){float4 common[11];};cbuffer Light:register(b1){float4 lighting[3];};cbuffer Material:register(b2){float4 material[MATERIAL_ROWS];};cbuffer Instance:register(b6){float4 tint;float4 alphaControl;};
Texture2D<float4> diffuseMap:register(DIFF_T),normalMap:register(NORMAL_T),specularMap:register(SPEC_T),decal1:register(DECAL1_T),decal2:register(DECAL2_T),environmentMap:register(ENV_T),shadowMap:register(t15);
SamplerState diffuseSampler:register(DIFF_S),normalSampler:register(NORMAL_S),specularSampler:register(SPEC_S),decal1Sampler:register(DECAL1_S),decal2Sampler:register(DECAL2_S),environmentSampler:register(ENV_S),shadowSampler:register(s15);
#if LAYOUT==1
struct In{float4 position:SV_Position;float3 toLight:TEXCOORD0;float3 toEye:TEXCOORD1;float4 upFog:TEXCOORD2;float4 uvCombined:TEXCOORD3;};
#elif LAYOUT==2
struct In{float4 position:SV_Position;float2 decalUV:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float4 upFog:TEXCOORD3;float4 uvCombined:TEXCOORD4;};
#else
struct In{float4 position:SV_Position;float2 uv:TEXCOORD0;float3 toLight:TEXCOORD1;float3 toEye:TEXCOORD2;float4 upFog:TEXCOORD3;};
#endif
float3 unit(float3 v){return v*rsqrt(max(dot(v,v),1e-8));}float3 fresnel(float3 f0,float nv){return modernFresnel(f0,nv);}
float2 tiling(float u,float v){
#if ZERO_TILING_DEFAULT
return float2(u==0?1:u,v==0?1:v);
#else
return float2(u,v);
#endif
}
float4 main(In i):SV_Target{
#if LAYOUT==0
 float2 uv=i.uv;
#else
 float2 uv=i.uvCombined.xy;
#endif
 float4 texel=diffuseMap.Sample(diffuseSampler,uv*tiling(M_DIFF_U,M_DIFF_V));float3 base=max(texel.rgb*M_COLOUR.rgb,0);
#if DECALS>0
 #if LAYOUT==2
 float2 uv1=i.decalUV;
 #else
 float2 uv1=i.uvCombined.zw;
 #endif
 float4 overlay=decal1.Sample(decal1Sampler,uv1);base=lerp(base,overlay.rgb,saturate(overlay.a*M_DECAL1));
#endif
#if DECALS>1
 float4 overlay2=decal2.Sample(decal2Sampler,i.uvCombined.zw);base=lerp(base,overlay2.rgb,saturate(overlay2.a*M_DECAL2));
#endif
 if(alphaControl.y!=0)clip(texel.a-alphaControl.x);
 float4 encoded=normalMap.Sample(normalSampler,uv*tiling(M_NORMAL_U,M_NORMAL_V));float2 xy=float2((encoded.r*2-1)*(encoded.a*2-1),encoded.g*2-1);float3 N=unit(lerp(float3(0,0,1),float3(xy,sqrt(saturate(1-dot(xy,xy)))),M_NORMAL));
 float3 L=unit(i.toLight),V=unit(i.toEye),H=unit(L+V);float nl=saturate(dot(N,L)),nv=max(saturate(dot(N,V)),.001),nh=saturate(dot(N,H)),vh=saturate(dot(V,H));
#if HAS_SPEC
 float3 specular=specularMap.Sample(specularSampler,uv*tiling(M_SPEC_U,M_SPEC_V)).rgb*M_SPEC_COLOUR.rgb*max(M_SPEC_ALPHA,0);
#else
 float3 specular=0;
#endif
 // Blinn power maps to GGX alpha, not perceptual roughness. GGX squares
 // perceptual roughness below, so use the fourth root exactly once here.
 float metal=saturate(M_METAL);float3 specularMask=lerp(saturate(specular),1,metal);float3 f0=lerp(float3(.04,.04,.04),min(base,.95),metal);float roughness=clamp(pow(2/(max(M_POWER,1)+2),.25),.18,.98);float mapStrength=1;modernApplyMaterialMap(modernMaterialMap(uv*tiling(M_DIFF_U,M_DIFF_V),0,diffuseSampler),roughness,mapStrength);specularMask*=lerp(mapStrength,1,metal);float a=roughness*roughness,a2=a*a,den=nh*nh*(a2-1)+1;
 float distribution=a2/(3.14159265*max(den*den,1e-7));float visibility=.5/max(nl*sqrt(nv*nv*(1-a2)+a2)+nv*sqrt(nl*nl*(1-a2)+a2),1e-5);float3 F=fresnel(f0,vh)*specularMask;float3 colour=((1-F)*(1-metal)*base/3.14159265+distribution*visibility*F)*nl*max(lighting[0].rgb,0);
 #if HAS_SHADOW
 float2 shadow=shadowMap.Sample(shadowSampler,i.position.xy*common[6].zw).rg;
 #else
 float2 shadow=1;
 #endif
 colour*=saturate(shadow.y);
#if LOCAL_LIGHT
 float attenuation=modernNativeLightRange(length(i.toLight),lighting[1].x,lighting[1].y);float spot=max(min(dot(-L,i.upFog.xyz),lighting[2].x)-lighting[2].y,0)*lighting[2].z;colour*=attenuation*(lighting[2].w>0?saturate(spot):1);colour*=1-saturate(i.upFog.w);
#else
 float hemi=saturate(dot(N,unit(i.upFog.xyz))*.5+.5);float3 irradiance=lerp(max(common[3].rgb,0),max(common[2].rgb,0),hemi);float3 ambientF=fresnel(f0,nv)*specularMask;colour+=modernAmbient(i.position,uv,N,float4(0,0,0,0),((1-ambientF)*(1-metal)*base+ambientF*(1-.7*roughness))*irradiance*saturate(shadow.x),(1-ambientF)*(1-metal)*base*saturate(shadow.x));colour+=base*max(M_SELF,0)*4;
 #if ENVIRONMENT
 uint w,h,levels;environmentMap.GetDimensions(0,w,h,levels);float4 reflection=environmentMap.SampleLevel(environmentSampler,i.uvCombined.zw,roughness*max(float(levels)-1,0));colour+=max(reflection.rgb,0)*ambientF*saturate(M_ENV_ALPHA*reflection.a)*saturate(shadow.x);
 #endif
 colour=lerp(colour,max(common[4].rgb,0),saturate(i.upFog.w));
#endif
 return float4(max(colour,0),texel.a)*tint;
}

