#pragma once
#include "modern_height_catalog.h"
namespace modernheight {
struct Controls {float amplitude[4]{};float limits[4]{8,20,16,0};};
inline Ptr<ID3D11Device> bufferOwner;inline std::mutex bufferMutex;
struct BufferSlot {ID3D11DeviceContext* key=nullptr;Ptr<ID3D11Buffer> buffer;};inline BufferSlot buffers[128];
inline ID3D11Buffer* buffer(ID3D11Device* d,ID3D11DeviceContext* c){std::lock_guard<std::mutex> lock(bufferMutex);if(bufferOwner.Get()!=d){for(auto& slot:buffers)slot={};bufferOwner=d;}BufferSlot* empty=nullptr;for(auto& slot:buffers){if(slot.key==c)return slot.buffer.Get();if(!slot.key&&!empty)empty=&slot;}if(!empty)return nullptr;D3D11_BUFFER_DESC desc{};desc.ByteWidth=sizeof(Controls);desc.BindFlags=D3D11_BIND_CONSTANT_BUFFER;desc.Usage=D3D11_USAGE_DYNAMIC;desc.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;Ptr<ID3D11Buffer> next;if(FAILED(d->CreateBuffer(&desc,nullptr,&next)))return nullptr;empty->key=c;empty->buffer=next;return next.Get();}
class Bindings {
 Ptr<ID3D11DeviceContext> context;Ptr<ID3D11ShaderResourceView> previous[4];Ptr<Attachment> owners[4];Ptr<ID3D11ShaderResourceView> current[4];Ptr<ID3D11Buffer> prior,constants;
public:
 bool apply(ID3D11DeviceContext* c,ID3D11ShaderResourceView*const* normals,unsigned count){
  if(!c||count>4)return false;Ptr<ID3D11Device> d;c->GetDevice(&d);Controls values;
  for(unsigned i=0;i<4;++i){owners[i]=i<count?attachment(normals[i]):Ptr<Attachment>{};current[i]=owners[i]?owners[i]->view.Get():nullptr;values.amplitude[i]=current[i]?.02f:0;}
  if(!context){constants=buffer(d.Get(),c);if(!constants)return false;ID3D11ShaderResourceView* old[4]{};c->PSGetShaderResources(21,4,old);for(unsigned i=0;i<4;++i)previous[i].Attach(old[i]);c->PSGetConstantBuffers(12,1,&prior);context=c;}
  if(context.Get()!=c)return false;D3D11_MAPPED_SUBRESOURCE mapped{};if(FAILED(c->Map(constants.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&mapped)))return false;memcpy(mapped.pData,&values,sizeof(values));c->Unmap(constants.Get(),0);ID3D11ShaderResourceView* inputs[]={current[0].Get(),current[1].Get(),current[2].Get(),current[3].Get()};c->PSSetShaderResources(21,4,inputs);auto* cb=constants.Get();c->PSSetConstantBuffers(12,1,&cb);return true;
 }
 ~Bindings(){if(context){ID3D11ShaderResourceView* views[]={previous[0].Get(),previous[1].Get(),previous[2].Get(),previous[3].Get()};context->PSSetShaderResources(21,4,views);auto* cb=prior.Get();context->PSSetConstantBuffers(12,1,&cb);}}
};
}
