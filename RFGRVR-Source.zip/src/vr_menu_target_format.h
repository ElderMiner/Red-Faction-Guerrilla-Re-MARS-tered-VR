#pragma once
#include <dxgiformat.h>
inline DXGI_FORMAT RFGRMenuTargetFormat(DXGI_FORMAT storage,DXGI_FORMAT requested=DXGI_FORMAT_UNKNOWN){
 if(storage==DXGI_FORMAT_R8G8B8A8_TYPELESS)return requested==DXGI_FORMAT_R8G8B8A8_UNORM_SRGB?requested:DXGI_FORMAT_R8G8B8A8_UNORM;
 if(storage==DXGI_FORMAT_B8G8R8A8_TYPELESS)return requested==DXGI_FORMAT_B8G8R8A8_UNORM_SRGB?requested:DXGI_FORMAT_B8G8R8A8_UNORM;
 return storage;
}
