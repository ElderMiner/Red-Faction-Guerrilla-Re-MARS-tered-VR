// RFGR-VR Camera Lab: diagnostic panel drawn into the game's own D3D11 backbuffer.
// Controls use edge-triggered hotkeys only while the game has focus. Read-only camera data.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <cmath>
using Microsoft::WRL::ComPtr;
extern "C" bool RFGRVR_StereoTrace_Export();
extern "C" bool RFGRVR_StereoTrace_AutoStart();
extern "C" LONG RFGRVR_StereoTrace_AutoState();
extern "C" void RFGRVR_FP_SetEnabled(bool);
extern "C" bool RFGRVR_FP_GetEnabled();
extern "C" void RFGRVR_FP_AdjustForward(int);
extern "C" void RFGRVR_FP_AdjustUp(int);
extern "C" int RFGRVR_FP_GetForward();
extern "C" int RFGRVR_FP_GetUp();
extern "C" unsigned RFGRVR_FP_GetAttempts();
extern "C" unsigned RFGRVR_FP_GetApplied();
extern "C" unsigned RFGRVR_FP_GetRejected();
extern "C" bool RFGRVR_HeadCam_Ready();
extern "C" unsigned RFGRVR_HeadCam_HeadSamples();
namespace {
constexpr int W=820,H=448;
constexpr unsigned MAGIC=0x434D4652, CAPTURE=1024;
#pragma pack(push,4)
struct Telemetry {
 unsigned magic,version,status,processId;
 volatile LONG sequence;
 unsigned long long callbackCount;
 unsigned cameraPtr,rendererPtr,cameraChanges;
 unsigned lastTick,bytesValid;
 unsigned char cameraData[CAPTURE];
};
#pragma pack(pop)
struct Snapshot { bool present=false; DWORD tick=0; unsigned camera=0; unsigned valid=0; unsigned char bytes[CAPTURE]{}; };
struct Lab {
 bool visible=false, seen[256]{}; int offset=0; DWORD lastPaint=0;
 Snapshot current{},captures[5];
 wchar_t message[120]=L"F1 to toggle; no camera writes";
 HANDLE mapping=nullptr; Telemetry* shared=nullptr;
 ComPtr<ID3D11Device> device; ComPtr<ID3D11Texture2D> atlas;
 ComPtr<ID3D11ShaderResourceView> srv; ComPtr<ID3D11VertexShader> vs; ComPtr<ID3D11PixelShader> ps;
 ComPtr<ID3D11SamplerState> sampler; ComPtr<ID3D11RasterizerState> raster;
 ComPtr<ID3D11DepthStencilState> depth; ComPtr<ID3D11BlendState> blend;
 ComPtr<ID3D11Buffer> constants;
 HDC dc=nullptr; HBITMAP bitmap=nullptr, oldBitmap=nullptr; unsigned char* pixels=nullptr;
 unsigned width=0,height=0;
} g;
static bool Active(){ HWND h=GetForegroundWindow(); DWORD pid=0; if(h)GetWindowThreadProcessId(h,&pid); return pid==GetCurrentProcessId(); }
static bool Press(int code){
 const bool down=(GetAsyncKeyState(code)&0x8000)!=0;
 const bool hit=down&&!g.seen[code];g.seen[code]=down;return hit;
}
static void ReadCamera(){
 if(!g.shared){wchar_t name[96]; wsprintfW(name,L"Local\\RFGRVR_RSL_Camera_%lu",GetCurrentProcessId());
   g.mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);
   if(g.mapping)g.shared=(Telemetry*)MapViewOfFile(g.mapping,FILE_MAP_READ,0,0,sizeof(Telemetry));
 }
 if(!g.shared || g.shared->magic!=MAGIC)return;
 // Sequence lock from render_begin hook. Maximum 3 attempts; never wait on render thread.
 for(int retry=0;retry<3;++retry){
   LONG first=g.shared->sequence; if(first&1)continue;
   Snapshot next{};MemoryBarrier();
   next.camera=g.shared->cameraPtr;next.valid=g.shared->bytesValid;
   if(next.valid>CAPTURE)next.valid=CAPTURE;
   if(next.valid)memcpy(next.bytes,g.shared->cameraData,next.valid);
   next.tick=g.shared->lastTick;
   MemoryBarrier();LONG last=g.shared->sequence;
   if(first==last && !(last&1)){next.present=next.valid>0;g.current=next;break;}
 }
}
static void Export(){
 // Save into a stable, user-accessible location regardless of the DLL install directory.
 char base[MAX_PATH]={};
 DWORD n=GetEnvironmentVariableA("LOCALAPPDATA",base,MAX_PATH);
 if(!n || n>=MAX_PATH){
   wcscpy_s(g.message,L"Export failed: LOCALAPPDATA not found");return;
 }
 char folder[MAX_PATH]={};
 if(sprintf_s(folder,"%s\\RFGR-VR",base)<0 || !CreateDirectoryA(folder,nullptr) && GetLastError()!=ERROR_ALREADY_EXISTS){
   wcscpy_s(g.message,L"Export failed: cannot create RFGR-VR folder");return;
 }
 char reports[MAX_PATH]={};
 if(sprintf_s(reports,"%s\\Reports",folder)<0 || !CreateDirectoryA(reports,nullptr) && GetLastError()!=ERROR_ALREADY_EXISTS){
   wcscpy_s(g.message,L"Export failed: cannot create Reports folder");return;
 }
 char report[MAX_PATH]={};
 if(sprintf_s(report,"%s\\RFGR-Camera-Lab-%lu-%lu.csv",reports,GetCurrentProcessId(),GetTickCount())<0){
   wcscpy_s(g.message,L"Export failed: report path too long");return;
 }
 FILE* file=nullptr;
 if(fopen_s(&file,report,"w")!=0 || !file){wcscpy_s(g.message,L"Export failed: cannot write report file");return;}
 fprintf(file,"stage,tick,camera_ptr,offset,slot,value,bytes_valid\n");
 const char* names[]={"BASE","YAW","PITCH","WALK","STILL"};
 int exported=0;
 for(int i=0;i<5;++i){const auto& s=g.captures[i];if(!s.present)continue;++exported;
   for(unsigned o=0;o+4<=s.valid;o+=4){float v=0;memcpy(&v,s.bytes+o,4);
     fprintf(file,"%s,%lu,0x%08X,%u,%u,%.9g,%u\n",names[i],s.tick,s.camera,o,o/4,v,s.valid);
   }
 }
 if(fclose(file)!=0){wcscpy_s(g.message,L"Export failed: error closing report");return;}
 swprintf_s(g.message,L"Saved %d stages: %%LOCALAPPDATA%%\\RFGR-VR\\Reports",exported);
}

static bool Init(ID3D11Device* device){
 if(!device)return false;
 if(g.device.Get()==device && g.vs && g.ps)return true;
 g.device=device;g.vs.Reset();g.ps.Reset();g.srv.Reset();g.atlas.Reset();
 static const char* shader=R"(
 cbuffer Config : register(b0) { float4 dims; }
 struct OUT {float4 p:SV_Position;float2 uv:TEXCOORD0;};
 OUT VS(uint id:SV_VertexID){OUT o;
 float2 p=float2((id==1||id==3)?1:0,(id>=2)?1:0);
 float2 pix=float2(12,12)+p*dims.xy;
 o.p=float4(pix.x/dims.z*2-1,1-pix.y/dims.w*2,0,1);o.uv=p;return o;}
 Texture2D panel : register(t0);SamplerState smp:register(s0);
 float4 PS(OUT i):SV_Target {return panel.Sample(smp,i.uv);}
 )";
 ComPtr<ID3DBlob> vsCode,psCode,errors;
 if(FAILED(D3DCompile(shader,strlen(shader),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&vsCode,&errors)))return false;
 errors.Reset();
 if(FAILED(D3DCompile(shader,strlen(shader),nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&psCode,&errors)))return false;
 if(FAILED(device->CreateVertexShader(vsCode->GetBufferPointer(),vsCode->GetBufferSize(),nullptr,&g.vs)))return false;
 if(FAILED(device->CreatePixelShader(psCode->GetBufferPointer(),psCode->GetBufferSize(),nullptr,&g.ps)))return false;
 D3D11_TEXTURE2D_DESC td{};td.Width=W;td.Height=H;td.MipLevels=1;td.ArraySize=1;td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.SampleDesc.Count=1;
 td.Usage=D3D11_USAGE_DEFAULT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;
 if(FAILED(device->CreateTexture2D(&td,nullptr,&g.atlas)))return false;
 if(FAILED(device->CreateShaderResourceView(g.atlas.Get(),nullptr,&g.srv)))return false;
 D3D11_SAMPLER_DESC samp{};samp.Filter=D3D11_FILTER_MIN_MAG_MIP_POINT;samp.AddressU=D3D11_TEXTURE_ADDRESS_CLAMP;
 samp.AddressV=D3D11_TEXTURE_ADDRESS_CLAMP;samp.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;samp.MaxLOD=D3D11_FLOAT32_MAX;
 if(FAILED(device->CreateSamplerState(&samp,&g.sampler)))return false;
 D3D11_RASTERIZER_DESC rast{};rast.FillMode=D3D11_FILL_SOLID;rast.CullMode=D3D11_CULL_NONE;rast.DepthClipEnable=TRUE;
 if(FAILED(device->CreateRasterizerState(&rast,&g.raster)))return false;
 D3D11_DEPTH_STENCIL_DESC ds{};ds.DepthEnable=FALSE;ds.StencilEnable=FALSE;
 if(FAILED(device->CreateDepthStencilState(&ds,&g.depth)))return false;
 D3D11_BLEND_DESC bs{};bs.RenderTarget[0].RenderTargetWriteMask=D3D11_COLOR_WRITE_ENABLE_ALL;
 if(FAILED(device->CreateBlendState(&bs,&g.blend)))return false;
 D3D11_BUFFER_DESC bd{};bd.ByteWidth=16;bd.Usage=D3D11_USAGE_DEFAULT;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;
 if(FAILED(device->CreateBuffer(&bd,nullptr,&g.constants)))return false;
 if(!g.dc){BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=W;bi.bmiHeader.biHeight=-H;
  bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
  HDC screen=GetDC(nullptr);g.dc=CreateCompatibleDC(screen);ReleaseDC(nullptr,screen);
  g.bitmap=CreateDIBSection(g.dc,&bi,DIB_RGB_COLORS,(void**)&g.pixels,nullptr,0);
  if(g.bitmap)g.oldBitmap=(HBITMAP)SelectObject(g.dc,g.bitmap);
 }
 return g.pixels!=nullptr;
}
static void Text(int x,int y,const char* line,COLORREF color=RGB(235,240,248)){
 SetTextColor(g.dc,color);TextOutA(g.dc,x,y,line,(int)strlen(line));
}
static void Paint(){
 RECT r={0,0,W,H};HBRUSH bg=CreateSolidBrush(RGB(19,24,37));FillRect(g.dc,&r,bg);DeleteObject(bg);
 SetBkMode(g.dc,TRANSPARENT);
 HFONT font=CreateFontA(17,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,FF_DONTCARE,"Consolas");
 HGDIOBJ old=SelectObject(g.dc,font);
 Text(16,12,"RFGR  |  NATIVE CAMERA LAB     F1 hide",RGB(96,217,235));
 char buf[256];
 if(g.shared){sprintf_s(buf,"RSL hook: %u   callbacks: %llu   camera: 0x%08X   renderer: 0x%08X",g.shared->status,g.shared->callbackCount,g.shared->cameraPtr,g.shared->rendererPtr);}
 else strcpy_s(buf,"Waiting for RSL hook shared memory (check installation / native DLL log)");
 Text(16,43,buf);
 sprintf_s(buf,"Capture: %s   age: %lu ms   bytes: %u    selected byte offset: %d",g.current.present?"LIVE":"NONE",g.current.tick?GetTickCount()-g.current.tick:0,g.current.valid,g.offset);
 Text(16,67,buf);
 Text(16,101,"F10 SINGLE GPU FRAME + CAMERA SURVEY   F2-F6 MOVEMENT CAPTURES   F12 EXPORT",RGB(253,213,111));
 const LONG survey=RFGRVR_StereoTrace_AutoState();
 const char* surveyText= survey==1?"RECORDING (15 seconds)":survey==2?"WRITING REPORT":survey==3?"REPORT SAVED":survey==4?"REPORT FAILED":"PRESS F10 TO START";
 sprintf_s(buf,"AUTO RENDER SURVEY: %s",surveyText);
 Text(16,125,buf,survey==3?RGB(123,235,158):RGB(253,213,111));
 const char* names[]={"BASE","YAW","PITCH","WALK","STILL"};
 for(int i=0;i<5;++i){sprintf_s(buf,"%s: %s  0x%08X",names[i],g.captures[i].present?"captured":"missing",g.captures[i].camera);
  Text(16+i%3*255,157+(i/3)*25,buf,g.captures[i].present?RGB(123,235,158):RGB(182,183,190));}
 sprintf_s(buf,"HEAD CAMERA: %s [%s]  forward: %.2f rise: %.2f samples:%u writes:%u errors:%u",
   RFGRVR_FP_GetEnabled()?"ON":"OFF",RFGRVR_HeadCam_Ready()?"READY":"UNAVAILABLE",RFGRVR_FP_GetForward()/100.0f,RFGRVR_FP_GetUp()/100.0f,
   RFGRVR_HeadCam_HeadSamples(),RFGRVR_FP_GetApplied(),RFGRVR_FP_GetRejected());
 Text(16,210,buf,RFGRVR_FP_GetEnabled()?RGB(123,235,158):RGB(253,213,111));
 Text(16,233,"Ctrl+Shift+UP/DOWN: forward +/- 0.2  |  Ctrl+Shift+RIGHT/LEFT: rise +/- 0.1");
 Text(16,257,"Selected 4 x 4 FLOAT WINDOW (for inspection):",RGB(96,217,235));
 for(int row=0;row<4;++row){
  char line[220]="";int pos=0;
  for(int col=0;col<4;++col){float v=0;int o=g.offset+(row*4+col)*4;
    if(g.current.present && o+4 <= (int)g.current.valid){memcpy(&v,g.current.bytes+o,4);pos+=sprintf_s(line+pos,sizeof(line)-pos," %11.4f",v);}
    else pos+=sprintf_s(line+pos,sizeof(line)-pos," %11s","-");}
  Text(16,279+row*26,line);
 }
 char msg[150]={};WideCharToMultiByte(CP_UTF8,0,g.message,-1,msg,sizeof(msg),nullptr,nullptr);
 Text(16,404,msg,RGB(253,213,111));
 SelectObject(g.dc,old);DeleteObject(font);
 // BI_RGB DIB alpha channel isn't written by GDI: force opaque pixels.
 for(int p=0;p<W*H;++p)g.pixels[p*4+3]=255;
}
// Game render-thread entry point, called immediately before the real Present.
}
extern "C" void RFGRVR_DrawInGameCameraLab(IDXGISwapChain* swap){
 if(!swap)return;
 if(Active()){
  // These require modifiers to avoid interfering with normal game/VR hotkeys.
  const bool mod=(GetAsyncKeyState(VK_CONTROL)&0x8000) && (GetAsyncKeyState(VK_SHIFT)&0x8000);
  if(Press(VK_F1))g.visible=!g.visible;
  if(Press(VK_F10)){if(RFGRVR_StereoTrace_AutoStart())wcscpy_s(g.message,L"Single-frame GPU capture armed; play for 15 seconds. Reports save to LocalAppData\\RFGR-VR\\Reports.");else wcscpy_s(g.message,L"Auto survey already running or finished. Restart the game to repeat.");}
  if(g.visible){
   ReadCamera();
   if(!mod && Press(VK_LEFT) && g.offset>=16)g.offset-=16;
   if(!mod && Press(VK_RIGHT) && g.offset<=CAPTURE-80)g.offset+=16;
   for(int i=0;i<5;++i)if(Press(VK_F2+i)){
     g.captures[i]=g.current;swprintf_s(g.message,L"Captured %d/5: %s",i+1,g.current.present?L"OK":L"NO LIVE CAMERA DATA");
   }
   if(Press(VK_F12)){Export();RFGRVR_StereoTrace_Export();}
  }
 }else{for(int k=0;k<256;++k)g.seen[k]=false;}
 if(!g.visible)return;
 ComPtr<ID3D11Device> device;
 if(FAILED(swap->GetDevice(__uuidof(ID3D11Device),(void**)device.GetAddressOf())))return;
 if(!Init(device.Get()))return;
 ComPtr<ID3D11Texture2D> back;
 if(FAILED(swap->GetBuffer(0,__uuidof(ID3D11Texture2D),(void**)back.GetAddressOf())))return;
 D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);if(desc.SampleDesc.Count!=1)return;
 if(desc.Width==0 || desc.Height==0)return;
 ComPtr<ID3D11RenderTargetView> target;
 if(FAILED(device->CreateRenderTargetView(back.Get(),nullptr,&target)))return;
 ComPtr<ID3D11DeviceContext> ctx;device->GetImmediateContext(&ctx);if(!ctx)return;
 if(GetTickCount()-g.lastPaint>90){Paint();ctx->UpdateSubresource(g.atlas.Get(),0,nullptr,g.pixels,W*4,0);g.lastPaint=GetTickCount();}
 float dims[4]={(float)W,(float)H,(float)desc.Width,(float)desc.Height};ctx->UpdateSubresource(g.constants.Get(),0,nullptr,dims,0,0);
 // Preserve the application's current immediate-context pipeline state.
 ComPtr<ID3D11RenderTargetView> oldRT[8];ComPtr<ID3D11DepthStencilView> oldDS;
 ID3D11RenderTargetView* rtRaw[8]{};ID3D11DepthStencilView* dsRaw=nullptr;
 ctx->OMGetRenderTargets(8,rtRaw,&dsRaw);
 for(int i=0;i<8;++i)oldRT[i].Attach(rtRaw[i]);oldDS.Attach(dsRaw);
 ComPtr<ID3D11BlendState> oldBlend;FLOAT factor[4]{};UINT mask=0;ctx->OMGetBlendState(&oldBlend,factor,&mask);
 ComPtr<ID3D11DepthStencilState> oldDepth;UINT ref=0;ctx->OMGetDepthStencilState(&oldDepth,&ref);
 ComPtr<ID3D11RasterizerState> oldRaster;ctx->RSGetState(&oldRaster);
 D3D11_VIEWPORT viewports[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE]{};
 UINT viewportCount=D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;ctx->RSGetViewports(&viewportCount,viewports);
 D3D11_RECT scissors[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE]{};
 UINT scissorCount=D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;ctx->RSGetScissorRects(&scissorCount,scissors);
 ComPtr<ID3D11VertexShader> oldVS;ComPtr<ID3D11PixelShader> oldPS;
 ID3D11ClassInstance* vsc[256]{};ID3D11ClassInstance* psc[256]{};UINT vn=256,pn=256;
 ctx->VSGetShader(&oldVS,vsc,&vn);ctx->PSGetShader(&oldPS,psc,&pn);
 ComPtr<ID3D11ShaderResourceView> oldSRV;ComPtr<ID3D11SamplerState> oldSampler;
 ID3D11ShaderResourceView* srvRaw=nullptr;ctx->PSGetShaderResources(0,1,&srvRaw);oldSRV.Attach(srvRaw);
 ID3D11SamplerState* smRaw=nullptr;ctx->PSGetSamplers(0,1,&smRaw);oldSampler.Attach(smRaw);
 ComPtr<ID3D11Buffer> oldVSCB;ID3D11Buffer* cbRaw=nullptr;ctx->VSGetConstantBuffers(0,1,&cbRaw);oldVSCB.Attach(cbRaw);
 ComPtr<ID3D11InputLayout> oldLayout;ctx->IAGetInputLayout(&oldLayout);
 D3D11_PRIMITIVE_TOPOLOGY oldTopology{};ctx->IAGetPrimitiveTopology(&oldTopology);
 ID3D11Buffer* oldVB[1]{};UINT oldStride[1]{},oldOffset[1]{};ctx->IAGetVertexBuffers(0,1,oldVB,oldStride,oldOffset);
 ComPtr<ID3D11Buffer> oldIB;DXGI_FORMAT oldIBFmt{};UINT oldIBOff{};ID3D11Buffer* ibRaw=nullptr;
 ctx->IAGetIndexBuffer(&ibRaw,&oldIBFmt,&oldIBOff);oldIB.Attach(ibRaw);
 ID3D11RenderTargetView* targetRaw=target.Get();ctx->OMSetRenderTargets(1,&targetRaw,nullptr);
 ctx->OMSetBlendState(g.blend.Get(),nullptr,0xffffffff);ctx->OMSetDepthStencilState(g.depth.Get(),0);
 ctx->RSSetState(g.raster.Get());D3D11_VIEWPORT vp{0,0,(float)desc.Width,(float)desc.Height,0,1};ctx->RSSetViewports(1,&vp);
 ctx->VSSetShader(g.vs.Get(),nullptr,0);ctx->PSSetShader(g.ps.Get(),nullptr,0);
 ID3D11ShaderResourceView* srv=g.srv.Get();ctx->PSSetShaderResources(0,1,&srv);
 ID3D11SamplerState* sampler=g.sampler.Get();ctx->PSSetSamplers(0,1,&sampler);
 ID3D11Buffer* constants=g.constants.Get();ctx->VSSetConstantBuffers(0,1,&constants);
 ctx->IASetInputLayout(nullptr);ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
 ID3D11Buffer* nullVB=nullptr;UINT z=0;ctx->IASetVertexBuffers(0,1,&nullVB,&z,&z);ctx->IASetIndexBuffer(nullptr,DXGI_FORMAT_UNKNOWN,0);
 ctx->Draw(4,0);
 // Restore states and release COM interface references returned by getters.
 ctx->IASetVertexBuffers(0,1,oldVB,oldStride,oldOffset);if(oldVB[0])oldVB[0]->Release();
 ctx->IASetIndexBuffer(oldIB.Get(),oldIBFmt,oldIBOff);ctx->IASetInputLayout(oldLayout.Get());ctx->IASetPrimitiveTopology(oldTopology);
 ctx->VSSetConstantBuffers(0,1,oldVSCB.GetAddressOf());
 ID3D11ShaderResourceView* oldSRVRaw=oldSRV.Get();ctx->PSSetShaderResources(0,1,&oldSRVRaw);
 ID3D11SamplerState* oldSampRaw=oldSampler.Get();ctx->PSSetSamplers(0,1,&oldSampRaw);
 ctx->VSSetShader(oldVS.Get(),vsc,vn);ctx->PSSetShader(oldPS.Get(),psc,pn);
 for(UINT i=0;i<vn;++i)if(vsc[i])vsc[i]->Release();for(UINT i=0;i<pn;++i)if(psc[i])psc[i]->Release();
 ctx->RSSetState(oldRaster.Get());if(viewportCount)ctx->RSSetViewports(viewportCount,viewports);
 if(scissorCount)ctx->RSSetScissorRects(scissorCount,scissors);
 ctx->OMSetDepthStencilState(oldDepth.Get(),ref);ctx->OMSetBlendState(oldBlend.Get(),factor,mask);
 ID3D11RenderTargetView* saved[8]{};for(int i=0;i<8;++i)saved[i]=oldRT[i].Get();ctx->OMSetRenderTargets(8,saved,oldDS.Get());
}
