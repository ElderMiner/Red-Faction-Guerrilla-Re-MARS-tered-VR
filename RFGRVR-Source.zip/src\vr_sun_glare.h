#pragma once
#include <cstring>
#include <cmath>
#include <cstdint>
#include "vr_memory_access.h"
#include "vr_vehicle_bloom.h"
extern "C" bool RFGRVR_HeadCam_Enabled();
namespace vrglare {
struct Owned {
 unsigned char* record=nullptr;float saved[3]{};
 bool apply(unsigned char* entry,bool enabled){
  if(!enabled){if(record){const unsigned offsets[3]={0x28,0x2c,0x50};for(unsigned i=0;i<3;++i){float current=0;memcpy(&current,record+offsets[i],4);if(current==0)memcpy(record+offsets[i],&saved[i],4);}record=nullptr;}return false;}
  if(!entry||memcmp(entry,"SunGlare01\0",11))return false;
  if(record!=entry){float values[3];const unsigned offsets[3]={0x28,0x2c,0x50};for(unsigned i=0;i<3;++i){memcpy(&values[i],entry+offsets[i],4);if(!std::isfinite(values[i])||values[i]<0||values[i]>10000)return false;}record=entry;memcpy(saved,values,12);}
  float zero=0;for(unsigned offset:{0x28u,0x2cu,0x50u})memcpy(entry+offset,&zero,4);return true;
 }
};
// Final composite has its own sun_sampler, separate from SunGlare01/corona.
// The native pass explicitly accepts a null input. Only borrow the slot during
// the draw; never release or replace the engine-owned render texture.
struct CompositeSunScope {
 void** slot[2]{};void* saved[2]{};
 CompositeSunScope(void* owner,bool enabled){if(enabled&&vrmemory::check(owner,0xab0,true)){unsigned offsets[2]={0x978,0xaac};for(int i=0;i<2;++i){slot[i]=(void**)((char*)owner+offsets[i]);saved[i]=*slot[i];*slot[i]=nullptr;}}}
 ~CompositeSunScope(){for(int i=0;i<2;++i)if(slot[i]&&!*slot[i])*slot[i]=saved[i];}
};
// Native sun visibility/shaft generation uses this switch before the final
// composite. Nulling only the composite texture can leave generated glare in
// the scene colour. Borrow the verified switch for the entire VR frame.
struct SunGenerationScope {
 unsigned char* flag=nullptr;unsigned char saved=0;
 SunGenerationScope(unsigned char* value,bool enabled){if(enabled&&value&&vrmemory::check(value,1,true)){flag=value;saved=*flag;*flag=0;}}
 ~SunGenerationScope(){if(flag&&!*flag)*flag=saved;}
};
using Composite=void(__thiscall*)(void*,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);
inline Composite composite=nullptr;
inline void __fastcall onComposite(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h,uintptr_t i){
 const bool vr=RFGRVR_HeadCam_Enabled();CompositeSunScope sun(self,vr);
 bool limited=vrvehiclebloom::active.load(std::memory_order_relaxed);float limit=.5f,nightLimit=0;
 if(vrnight::bloomLimit((void*)h,nightLimit)){limit=limited?(std::min)(limit,nightLimit):nightLimit;limited=true;}
 vrvehiclebloom::CompositeScope bloom(self,(void*)a,vr&&limited,limit);
 composite(self,a,b,c,d,e,f,g,h,i);
}
// Native lens-ghost renderer, independent of the sun sprite and composite input.
using Lens=void(__thiscall*)(void*,void*,void*);inline Lens lens=nullptr;
inline void __fastcall onLens(void* self,void*,void* renderer,void* camera){if(!RFGRVR_HeadCam_Enabled())lens(self,renderer,camera);}
}
