#pragma once
#include <windows.h>
#include <cstdint>
#include <cwchar>
namespace vrframeclock {
struct Packet {volatile LONG sequence=0;DWORD pid=0,tick=0,render=0;int64_t predicted=0,period=0;};static_assert(sizeof(Packet)==32,"XR clock wire layout");
inline void name(wchar_t (&out)[128],bool event){
#ifdef RFGR_TEST_FRAMEPACER
 swprintf_s(out,L"Local\\RFGRVR_TEST_Frame%s_%lu",event?L"Pulse":L"Clock",GetCurrentProcessId());
#else
 wcscpy_s(out,event?L"Local\\RFGRVR_FramePulse_v1":L"Local\\RFGRVR_FrameClock_v1");
#endif
}
struct Channel {HANDLE mapping=nullptr,event=nullptr;Packet* packet=nullptr;DWORD retry=0;
 ~Channel(){if(packet)UnmapViewOfFile(packet);if(event)CloseHandle(event);if(mapping)CloseHandle(mapping);}
 bool attach(bool writer){if(packet&&event)return true;DWORD now=GetTickCount();if(retry&&DWORD(now-retry)<1000)return false;retry=now;wchar_t path[128]{};name(path,false);mapping=writer?CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Packet),path):OpenFileMappingW(FILE_MAP_READ,FALSE,path);if(!mapping)return false;packet=(Packet*)MapViewOfFile(mapping,writer?FILE_MAP_ALL_ACCESS:FILE_MAP_READ,0,0,sizeof(Packet));name(path,true);event=writer?CreateEventW(nullptr,FALSE,FALSE,path):OpenEventW(SYNCHRONIZE,FALSE,path);if(!packet||!event){if(packet)UnmapViewOfFile(packet);if(event)CloseHandle(event);CloseHandle(mapping);packet=nullptr;event=mapping=nullptr;return false;}return true;}
};
struct Publisher {Channel channel;bool initialized=false;
 void publish(int64_t predicted,int64_t period,bool render){if(!channel.attach(true))return;auto* p=channel.packet;if(!initialized){InterlockedExchange(&p->sequence,0);initialized=true;}InterlockedIncrement(&p->sequence);p->pid=GetCurrentProcessId();p->tick=GetTickCount();p->render=render;p->predicted=predicted;p->period=period;MemoryBarrier();InterlockedIncrement(&p->sequence);SetEvent(channel.event);}
};
struct Reader {Channel channel;DWORD owner=0;int64_t accepted=0,period=0;unsigned long long frames=0,waits=0,timeouts=0;
 bool snapshot(Packet& out){auto* p=channel.packet;if(!p)return false;for(int i=0;i<3;++i){LONG seq=ReadAcquire(&p->sequence);if(seq&1)continue;MemoryBarrier();out.pid=p->pid;out.tick=p->tick;out.render=p->render;out.predicted=p->predicted;out.period=p->period;MemoryBarrier();if(seq==ReadAcquire(&p->sequence))return out.pid&&out.render&&DWORD(GetTickCount()-out.tick)<250&&out.period>=2000000&&out.period<=50000000&&out.predicted>0;}return false;}
 bool pace(){if(!channel.attach(false))return false;Packet p;if(!snapshot(p))return false;if(owner!=p.pid){owner=p.pid;accepted=0;}period=p.period;DWORD began=GetTickCount(),budget=DWORD(period/1000000)+5;
  while(p.predicted==accepted){DWORD elapsed=GetTickCount()-began;if(elapsed>=budget){++timeouts;return false;}++waits;if(WaitForSingleObject(channel.event,budget-elapsed)!=WAIT_OBJECT_0){++timeouts;return false;}if(!snapshot(p))return false;}
  accepted=p.predicted;++frames;return true;
 }
};
}
