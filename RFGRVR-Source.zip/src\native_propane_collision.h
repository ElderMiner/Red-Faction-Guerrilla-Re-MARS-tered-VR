#pragma once
// Included inside RFGRVRWeaponPhysics. Only the carried tank/carrier pair is
// excluded. The tank's world, vehicle and NPC collisions retain native rules.
namespace PropaneCollision {
inline std::atomic<uintptr_t> tankCollider{0},tankObject{0},carrierObject{0},carrierCollider{0};
inline std::atomic<unsigned> tankHandle{~0u},carrierHandle{~0u};
inline std::atomic<uintptr_t> localPlayer{0},heldWeapon{0};
inline std::atomic<unsigned> heldWeaponHandle{~0u};
inline std::atomic<unsigned> pairHits{0},queryHits{0};
inline thread_local void* updatingPlayer=nullptr;
inline thread_local unsigned discoveryDepth=0;
struct DiscoveryScope {DiscoveryScope(){++discoveryDepth;}~DiscoveryScope(){--discoveryDepth;}};
struct PlayerScope {void* previous;PlayerScope(void* p):previous(updatingPlayer){updatingPlayer=p;}~PlayerScope(){updatingPlayer=previous;}};
inline void clear(){tankCollider=0;tankObject=0;carrierObject=0;carrierCollider=0;tankHandle=carrierHandle=~0u;}
inline void publish(const Target& t,void* item){
 unsigned id=word(item,0x4c);void* rb=id<65536?(void*)(uintptr_t)word(base,0x236e980+id*4):nullptr;
 if(!memory(rb,0x30)){clear();return;}
 tankObject=(uintptr_t)item;tankHandle=word(item,0x6c);carrierObject=(uintptr_t)t.player;carrierHandle=t.playerHandle;
 unsigned playerId=word(t.player,0x4c);uintptr_t playerBody=playerId<65536?word(base,0x236e980+playerId*4):0;
 carrierCollider=playerBody?playerBody+0x10:0;tankCollider=(uintptr_t)rb+0x10;
}
inline bool carrier(const void* collider){
 if(!collider)return false;if((uintptr_t)collider==carrierCollider.load())return true;
 // Verified hkpCollidable owner offset and hkpWorldObject::m_userData.
 if(!memory(collider,0x11))return false;signed char offset=*((const signed char*)collider+0x10);
 const void* owner=(const char*)collider+offset;unsigned user=word(owner,0xc);
 if(user&&(user==carrierObject.load()||user==carrierHandle.load()))return true;
 // RFGR leaves m_userData zero. Its native object pointer is Havok property
 // key 0, in the world object's 16-byte property records (live verified).
 unsigned count=word(owner,0x80);void* data=(void*)(uintptr_t)word(owner,0x7c);
 if(count>64||!memory(data,count*16))return false;
 for(unsigned i=0;i<count;++i)if(word(data,i*16)==0&&word(data,i*16+8)==carrierObject.load())return true;
 return false;
}
inline uintptr_t nativeObject(const void* collider){
 if(!collider||!memory(collider,0x11))return 0;signed char offset=*((const signed char*)collider+0x10);const void* owner=(const char*)collider+offset;
 if(!memory(owner,0x84))return 0;unsigned count=word(owner,0x80);void* data=(void*)(uintptr_t)word(owner,0x7c);if(!count||count>64||!memory(data,count*16))return word(owner,0xc);
 for(unsigned i=0;i<count;++i)if(word(data,i*16)==0)return word(data,i*16+8);return word(owner,0xc);
}
inline bool propaneObject(uintptr_t object){
 if(!object||!memory((void*)object,0xa8))return false;void* def=(void*)(uintptr_t)word((void*)object,0xa4);const char* name=(const char*)(uintptr_t)word(def,0);return memory(name,13)&&!strcmp(name,"propane_tank");
}
inline bool heldByPlayer(uintptr_t object){uintptr_t player=localPlayer.load(),held=heldWeapon.load();if(!player||!held||!object||!memory((void*)player,0x70)||!memory((void*)object,0x140)||!memory((void*)held,0x140)||word((void*)held,0x6c)!=heldWeaponHandle.load())return false;unsigned owner=word((void*)player,0x6c);return (object==held||word((void*)object,0x70)==heldWeaponHandle.load())&&(word((void*)held,0x13c)==owner||word((void*)held,0x70)==owner);}
inline bool excluded(const void* a,const void* b){
 uintptr_t tank=tankCollider.load(),held=tankObject.load();bool attached=held&&word((void*)held,0x70)==carrierHandle.load()&&word((void*)held,0x48)!=0;if(attached&&tank&&(((uintptr_t)a==tank&&carrier(b))||((uintptr_t)b==tank&&carrier(a))))return true;
 // Native carry only: loose tanks and pickup-discovery keep normal collisions.
 uintptr_t player=localPlayer.load();if(!player)return false;uintptr_t first=nativeObject(a),second=nativeObject(b);
 if((first==player&&heldByPlayer(second))||(second==player&&heldByPlayer(first)))return true;
 auto attachedNative=[&](uintptr_t object){return propaneObject(object)&&word((void*)object,0x70)==word((void*)player,0x6c)&&word((void*)object,0x48)!=0;};
 return (first==player&&attachedNative(second))||(second==player&&attachedNative(first));
}
using Pair=unsigned char*(__thiscall*)(void*,unsigned char*,const void*,const void*);
inline Pair originalPair=nullptr;
inline unsigned char* __fastcall pair(void* self,void*,unsigned char* result,const void* a,const void* b){if(result&&excluded(a,b)){++pairHits;*result=0;return result;}return originalPair(self,result,a,b);}
struct QueryContext {const SweepRequest* original;uintptr_t tank;unsigned handle;};
inline bool __cdecl filter(void* object,void* context){auto& c=*(QueryContext*)context;if(heldByPlayer((uintptr_t)object)||((uintptr_t)object==c.tank&&word(object,0x6c)==c.handle)||(localPlayer.load()&&propaneObject((uintptr_t)object)&&word(object,0x70)==word((void*)localPlayer.load(),0x6c)&&word(object,0x48)!=0)){++queryHits;return false;}using Filter=bool(__cdecl*)(void*,void*);return !c.original->filter||((Filter)c.original->filter)(object,c.original->context);}
inline Query originalQuery=nullptr;
inline bool __cdecl query(SweepRequest* request,void* result){
 uintptr_t tank=tankObject.load();if(discoveryDepth||!request||!updatingPlayer||((uintptr_t)updatingPlayer!=carrierObject.load()&&(uintptr_t)updatingPlayer!=localPlayer.load()))return originalQuery(request,result);
 QueryContext context{request,tank,tankHandle.load()};SweepRequest copy=*request;copy.context=&context;copy.filter=(void*)filter;return originalQuery(&copy,result);
}
inline void install(){
 const unsigned char pairSig[]={0x8b,0x44,0x24,0x0c,0x8b,0x50,0x1c};
 if(!memcmp(base+0xb28580,pairSig,sizeof(pairSig))&&MH_CreateHook(base+0xb28580,(void*)pair,(void**)&originalPair)==MH_OK){if(MH_EnableHook(base+0xb28580)!=MH_OK)MH_RemoveHook(base+0xb28580);else log("Propane carrier-only Havok pair filter installed.");}
 const unsigned char querySig[]={0x55,0x8b,0xec,0x83,0xe4,0xf0};
 if(!memcmp(base+0x436aa0,querySig,sizeof(querySig))&&MH_CreateHook(base+0x436aa0,(void*)query,(void**)&originalQuery)==MH_OK){if(MH_EnableHook(base+0x436aa0)!=MH_OK)MH_RemoveHook(base+0x436aa0);else log("Propane scoped player movement-query filter installed.");}
}
}

