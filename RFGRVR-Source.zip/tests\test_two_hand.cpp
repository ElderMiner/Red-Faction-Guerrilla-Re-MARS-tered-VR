#include "../src/vr_two_hand.h"
#include <cassert>
using namespace vrarm;
int main(){M identity{{1,0,0},{0,1,0},{0,0,1}};RFGRVRTwoHand grip;Pose gun{identity,{0,1,0}},tag{identity,{0,0,.3f}},other{identity,{0,1,.3f}},output{},support{};V primary{0,1,0};
 assert(!grip.update(1,7,true,0,.14f,gun,{},tag,primary,other,output,support));
 assert(grip.update(1,7,true,.9f,.14f,gun,{},tag,primary,other,output,support));
 other.p={.25f,1.2f,.3f};assert(grip.update(1,7,true,.9f,.14f,gun,{},tag,primary,other,output,support));
 assert(length(sub(output.p,primary))<.0001f&&dot(output.b.f,unit(sub(other.p,primary)))>.9999f);
 assert(length(sub(support.p,add(output.p,world(output.b,tag.p))))<.0001f);
 assert(!grip.update(1,7,true,0,.14f,gun,{},tag,primary,other,output,support)&&!grip.active);
 // Far press does not attach by sliding into the grip while still squeezing.
 other.p={1,1,1};assert(!grip.update(1,7,true,1,.14f,gun,{},tag,primary,other,output,support));other.p={0,1,.3f};
 assert(!grip.update(1,7,true,1,.14f,gun,{},tag,primary,other,output,support));
 grip.update(1,7,true,0,.14f,gun,{},tag,primary,other,output,support);assert(grip.update(1,7,true,1,.14f,gun,{},tag,primary,other,output,support));
 assert(!grip.update(2,8,true,1,.14f,gun,{},tag,primary,other,output,support));
 grip.update(2,8,true,0,.14f,gun,{},tag,primary,other,output,support);assert(grip.update(2,8,true,1,.14f,gun,{},tag,primary,other,output,support));
 assert(!grip.update(2,8,false,1,.14f,gun,{},tag,primary,other,output,support));
 // Sliding belongs only to the right-hand sledge support. Native rifle
 // grips remain fixed when the optional slide is disabled.
 RFGRVRTwoHand slide;other={identity,{0,1,.3f}};slide.update(4,9,true,0,.14f,gun,{},tag,primary,other,output,support,true);assert(slide.update(4,9,true,1,.14f,gun,{},tag,primary,other,output,support,true));other.p={0,1,.12f};assert(slide.update(4,9,true,1,.14f,gun,{},tag,primary,other,output,support,true));assert(length(sub(support.p,other.p))<.0001f&&length(sub(output.p,primary))<.0001f);other.p.z=.6f;assert(slide.update(4,9,true,1,.14f,gun,{},tag,primary,other,output,support,true));assert(fabsf(length(sub(support.p,output.p))-.6f)<.0001f);
 // Secondary grip rotation offsets affect only the attached hand frame.
 RFGRVRTwoHand rotated;other={identity,{0,1,.3f}};M trim=turnAround(identity,{0,0,1},.4f);Pose savedTag=tag;savedTag.b=trim;assert(rotated.update(5,10,true,1,.14f,gun,{},savedTag,primary,other,output,support,false));assert(length(sub(support.b.r,trim.r))<.0001f);assert(length(sub(output.p,primary))<.0001f);
 // Main grip remains at the rear controller, independent of support reach.
 RFGRVRTwoHand pivot;other={identity,{0,1,.3f}};assert(pivot.update(9,1,true,1,.14f,gun,{},tag,primary,other,output,support));
 other.p={.2f,1,.3f};assert(pivot.update(9,1,true,1,.14f,gun,{},tag,primary,other,output,support));
 assert(length(sub(output.p,primary))<.0001f&&fabsf(length(sub(support.p,output.p))-.3f)<.0001f);
 Pose alias=gun,aliasSupport{};assert(pivot.update(9,1,true,1,.14f,alias,{},tag,primary,other,alias,aliasSupport));assert(length(sub(alias.p,output.p))<.0001f);
 // Regripping at a different controller rotation cannot alter saved grip frame.
 Pose authored=tag;authored.b=turnAround(identity,{0,0,1},.4f);RFGRVRTwoHand stable;
 other={turnAround(identity,{0,0,1},1.f),{0,1,.3f}};assert(stable.update(10,1,true,1,.14f,gun,{},authored,primary,other,output,support));
 assert(length(sub(support.b.r,authored.b.r))<.0001f);
 stable.update(10,1,true,0,.14f,gun,{},authored,primary,other,output,support);other.b=identity;
 assert(stable.update(10,1,true,1,.14f,gun,{},authored,primary,other,output,support)&&length(sub(support.b.r,authored.b.r))<.0001f);
 // Support roll does not twist the primary grip. Main roll does.
 other.b=turnAround(identity,{0,0,1},.8f);assert(stable.update(10,1,true,1,.14f,gun,{},authored,primary,other,output,support)&&length(sub(output.b.r,identity.r))<.0001f);
 // Pistol support grips attach without steering either weapon axis or pivot.
 RFGRVRTwoHand passive;other={identity,{0,1,.3f}};assert(passive.update(99,1,true,1,.14f,gun,{},tag,primary,other,output,support,false,false));
 other={turnAround(identity,{0,1,0},1),{.5f,.5f,.2f}};assert(passive.update(99,1,true,1,.14f,gun,{},tag,primary,other,output,support,false,false));assert(length(sub(output.p,gun.p))<.0001f&&length(sub(output.b.f,gun.b.f))<.0001f);assert(length(sub(support.p,add(gun.p,world(gun.b,tag.p))))<.0001f);
 assert(!passive.update(99,1,true,0,.14f,gun,{},tag,primary,other,output,support,false,false));
 // Rapid A/B/A swaps while squeezed never transfer a support grip.
 RFGRVRTwoHand switching;other={identity,{0,1,.3f}};assert(switching.update(1,1,true,1,.14f,gun,{},tag,primary,other,output,support));
 assert(!switching.update(2,2,true,1,.14f,gun,{},tag,primary,other,output,support));assert(!switching.update(1,1,true,1,.14f,gun,{},tag,primary,other,output,support));assert(!switching.active&&switching.releaseRequired);
 switching.update(1,1,true,0,.14f,gun,{},tag,primary,other,output,support);assert(switching.update(1,1,true,1,.14f,gun,{},tag,primary,other,output,support));
 // Restored historical distance-based slide, capped at the saved upper grip.
 {RFGRVRTwoHand shaft;Pose top{identity,{.02f,.5f,.05f}};V line=unit(top.p);Pose hand{identity,{}};for(int cycle=0;cycle<5;++cycle)for(int n=0;n<=100;++n){float distance=.5f-(n<=50?n:100-n)*.007f;hand.p=add(primary,mul(line,distance));assert(shaft.update(500,1,true,1,.14f,gun,{},top,primary,hand,output,support,true,true,true));V point=local(output.b,sub(support.p,output.p));assert(fabsf(length(point)-distance)<.0001f&&length(sub(unit(point),line))<.0001f);assert(length(sub(support.p,hand.p))<.0001f);}hand.p=add(primary,mul(line,.8f));assert(shaft.update(500,1,true,1,.14f,gun,{},top,primary,hand,output,support,true,true,true));assert(fabsf(length(local(output.b,sub(support.p,output.p)))-length(top.p))<.0001f);}
}
