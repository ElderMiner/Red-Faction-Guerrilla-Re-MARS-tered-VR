"""Build LOCAL experimental height candidates from an owner's terrain normals.

Requires numpy and Pillow. Outputs are derived game data: keep them local;
distribute this generator, not its output. This does not install displacement.
Normal integration cannot recover absolute physical height or overhangs.
"""
import argparse
import hashlib
import io
import json
import struct
import zlib
import xml.etree.ElementTree as ET
from contextlib import ExitStack
from pathlib import Path

import numpy as np
from PIL import Image


class Pack:
    def __init__(self, file):
        self.file = file
        file.seek(332)
        flags = struct.unpack('<I', file.read(4))[0]
        if flags != 1:
            raise ValueError('Only verified individually compressed archives are supported')
        file.seek(340)
        count, _, entry_bytes, name_bytes = struct.unpack('<4I', file.read(16))
        if count > 10000 or entry_bytes != count * 28 or name_bytes > 8 * 1024 * 1024:
            raise ValueError('Invalid archive table')
        names_at = (2048 + entry_bytes + 2047) // 2048 * 2048
        self.start = (names_at + name_bytes + 2047) // 2048 * 2048
        file.seek(names_at)
        names = file.read(name_bytes)
        self.entries = {}
        offset = 0
        for index in range(count):
            file.seek(2048 + index * 28)
            name_at, _, _, _, size, compressed, _ = struct.unpack('<7I', file.read(28))
            if name_at >= len(names) or size > 512 * 1024 * 1024:
                raise ValueError('Invalid archive entry')
            name = names[name_at:].split(b'\0', 1)[0].decode('utf-8')
            self.entries[name.lower()] = (offset, size, compressed)
            offset = (offset + compressed + 2047) // 2048 * 2048

    def get(self, name):
        offset, size, compressed = self.entries[name.lower()]
        self.file.seek(self.start + offset)
        output = zlib.decompressobj().decompress(self.file.read(compressed), size + 1)
        if len(output) != size:
            raise ValueError('Archive entry length mismatch')
        return output


def integrate(px, py):
    """Periodic least-squares integration; gradients are per texel."""
    height, width = px.shape
    kx = 2 * np.pi * np.fft.fftfreq(width)[None, :]
    ky = 2 * np.pi * np.fft.fftfreq(height)[:, None]
    denominator = kx * kx + ky * ky
    denominator[0, 0] = 1
    spectrum = (-1j * kx * np.fft.fft2(px) - 1j * ky * np.fft.fft2(py)) / denominator
    spectrum[0, 0] = 0
    field = np.fft.ifft2(spectrum).real
    dx = np.fft.ifft2(1j * kx * spectrum).real
    dy = np.fft.ifft2(1j * ky * spectrum).real
    residual = float(np.sqrt(np.mean((dx - px) ** 2 + (dy - py) ** 2)))
    return field, residual


def decode(cpu, gpu, limit):
    if cpu[:8] != b'GEKV\x0a\x00\x00\x00':
        raise ValueError('Unverified bitmap header')
    width, height, format_code = struct.unpack_from('<3H', cpu, 28)
    if format_code != 400 or not (4 <= width <= 8192 and 4 <= height <= 8192):
        raise ValueError('Only verified BC1 normal textures are supported')
    top_bytes = ((width + 3) // 4) * ((height + 3) // 4) * 8
    if len(gpu) < top_bytes:
        raise ValueError('Incomplete texture')
    header = struct.pack('<7I', 124, 0x81007, height, width, top_bytes, 0, 1) + bytes(44)
    header += struct.pack('<8I', 32, 4, int.from_bytes(b'DXT1', 'little'), 0, 0, 0, 0, 0)
    header += struct.pack('<5I', 0x1000, 0, 0, 0, 0)
    image = Image.open(io.BytesIO(b'DDS ' + header + gpu[:top_bytes])).convert('RGBA')
    image.thumbnail((limit, limit), Image.Resampling.BOX)
    normal = np.asarray(image, dtype=np.float32) / 255
    # Verified native unpack: alpha participates in normal X, not height.
    nx = (normal[:, :, 0] * 2 - 1) * (normal[:, :, 3] * 2 - 1)
    ny = normal[:, :, 1] * 2 - 1
    nz = np.sqrt(np.maximum(1 - nx * nx - ny * ny, .04))
    return -nx / nz, -ny / nz, hashlib.sha256(gpu[:top_bytes]).hexdigest(), (width, height)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('game', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--resolution', type=int, default=1024, choices=(256, 512, 1024, 2048))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    results = []
    with ExitStack() as stack:
        misc = Pack(stack.enter_context((args.game / 'data' / 'misc.vpp_pc').open('rb')))
        table = ET.fromstring(misc.get('rfg_terrain_materials.xtbl'))
        names = sorted({node.text.lower().removesuffix('.tga') for node in table.findall('.//Terrain_Material/Normal/Filename') if node.text})
        packs = [(name, Pack(stack.enter_context((args.game / 'data' / name).open('rb')))) for name in ('terr01_precache.vpp_pc', 'dlc01_precache.vpp_pc') if (args.game / 'data' / name).is_file()]
        for stem in names:
            if Path(stem).name != stem or '\\' in stem or ':' in stem:
                raise ValueError('Unsafe texture name')
            match = next(((name, pack) for name, pack in packs if stem + '.cvbm_pc' in pack.entries and stem + '.gvbm_pc' in pack.entries), None)
            if match is None:
                results.append(dict(name=stem, status='rejected', reason='No verified bitmap in available precaches'))
                continue
            archive, pack = match
            try:
                px, py, checksum, original = decode(pack.get(stem + '.cvbm_pc'), pack.get(stem + '.gvbm_pc'), args.resolution)
                field, residual = integrate(px, py)
                lo, hi = np.percentile(field, [.1, 99.9])
                unit = np.clip((field - lo) / max(hi - lo, 1e-8), 0, 1)
                Image.fromarray(np.rint(unit * 65535).astype(np.uint16)).save(args.output / (stem + '.png'))
                unit.astype('<f2').tofile(args.output / (stem + '.r16f'))
                results.append(dict(name=stem, archive=archive, source_sha256=checksum, source_size=original,
                                    size=(unit.shape[1], unit.shape[0]), slope_residual=residual,
                                    inferred_height_span=float(hi - lo), status='candidate'))
            except (ValueError, KeyError) as error:
                results.append(dict(name=stem, status='rejected', reason=str(error)))
    (args.output / 'manifest.json').write_text(json.dumps(dict(
        installed=False, scope='Native terrain-material normal names resolved in base and DLC precaches',
        physical_scale_known=False, textures=results), indent=2))
    accepted = [r for r in results if r['status'] == 'candidate']
    with (args.output / 'terrain-heights.rfgh').open('wb') as bundle:
        bundle.write(struct.pack('<8sII', b'RFGRHGT\0', 1, len(accepted)))
        for record in accepted:
            payload = (args.output / (record['name'] + '.r16f')).read_bytes()
            bundle.write(struct.pack('<32s4IQ', bytes.fromhex(record['source_sha256']),
                                     *record['source_size'], *record['size'], len(payload)))
            bundle.write(payload)
    print(f"Generated {sum(x['status'] == 'candidate' for x in results)} local height candidates; no game files changed.")


if __name__ == '__main__':
    main()
