#pragma once
#include "vr_effect_geometry.h"
namespace RFGRVRBloomViewCache {
// The compositor's quarter-resolution scene image is cached by game frame,
// although its pixels depend on the eye. Exposure history must still advance
// only once. 13D4C0 generates the image; 13B9A0 advances that history.
using SourcePass=void(__thiscall*)(void*,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);
using ExposurePass=void(__thiscall*)(void*,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);
inline SourcePass downsample=nullptr;inline ExposurePass adaptation=nullptr;
inline void** manager=nullptr;
inline thread_local void* refreshing=nullptr;
inline std::atomic<unsigned> refreshes{0},retainedExposure{0};
inline unsigned currentFrame(){void* p=manager?*manager:nullptr;return RFGRVREffectGeometry::readable(p,0x6e0)?RFGRVREffectGeometry::word(p,0x6dc):0;}
inline void __fastcall onAdaptation(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f){
 if(refreshing==self){++retainedExposure;return;}
 adaptation(self,a,b,c,d,e,f);
}
inline void __fastcall onDownsample(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g){
 const unsigned frame=currentFrame();
 const bool repeat=RFGRVREffectGeometry::eye.load()==1&&manager&&*manager&&RFGRVREffectGeometry::readable(self,0xbac)&&RFGRVREffectGeometry::word(self,0xba8)==frame;
 if(!repeat){downsample(self,a,b,c,d,e,f,g);return;}
 const unsigned stale=frame-1;memcpy((char*)self+0xba8,&stale,4);
 void* previous=refreshing;refreshing=self;
 downsample(self,a,b,c,d,e,f,g);
 refreshing=previous;
 // The skipped adaptation normally publishes this stamp. Preserve the shared
 // exposure result and let subsequent bloom work consume the new eye image.
 if(RFGRVREffectGeometry::word(self,0xba8)==stale)memcpy((char*)self+0xba8,&frame,4);
 ++refreshes;
}
}
