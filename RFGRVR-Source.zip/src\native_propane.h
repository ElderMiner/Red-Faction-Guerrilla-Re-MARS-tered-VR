#pragma once
// Included inside RFGRVRWeaponPhysics, after Reload's verified item factory.
namespace Propane {
using Object=Reload::Object;
inline Object held{},preview{},nearby{};inline bool editing=false;inline unsigned heldMask=0,gripIndex[2]{};inline bool pressed[2]{};
inline unsigned editSlot=0;inline vrprop::Grips grips;inline bool profileReady=false;inline std::atomic<bool> captureRequest{false};inline DWORD lastSearch=0;inline void* info=nullptr;
inline vrprop::Motor motor;inline Pose heldGrip[2]{};
inline vrweapon::MotionEstimator releaseMotion[2];inline unsigned releaseHand=1;
inline void sampleRelease(const Target& t){for(unsigned h=0;h<2;++h)if(heldMask&(1u<<h)){auto sample=t.motion;sample.weapon=(uintptr_t)held.ptr;sample.handle=held.handle;sample.pose=vrprop::inverseGrip(t.hand[h],heldGrip[h]);sample.gripValid=sample.physicalValid=false;releaseMotion[h].update(sample);}}
struct Visual {DWORD tick=0;unsigned heldMask=0,stowed=~0u;bool editing=false;Pose hand[2]{};V marker{};int nearHand=-1;bool markerValid=false;unsigned markerCount=0,selected=0;V markers[3]{};};
inline SRWLOCK visualLock=SRWLOCK_INIT;inline Visual visual{};
inline bool readVisual(Visual& out){AcquireSRWLockShared(&visualLock);out=visual;ReleaseSRWLockShared(&visualLock);return out.tick&&DWORD(GetTickCount()-out.tick)<150;}
inline bool hidden(void* object){Visual v;if(!readVisual(v)||(!v.heldMask&&!v.editing)||v.stowed==~0u)return false;return word(object,0x6c)==v.stowed||word(object,0x70)==v.stowed;}
inline char profileOverride[MAX_PATH]{};
inline bool profile(bool save){char path[MAX_PATH]{};if(profileOverride[0])strcpy_s(path,profileOverride);else{GetModuleFileNameA(nullptr,path,MAX_PATH);char* slash=strrchr(path,92);if(!slash)return false;strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-propane-grips.ini");}
 if(save){for(unsigned i=0;i<grips.count;++i){char key[16],value[512];sprintf_s(key,"Grip%u",i);const auto& p=grips.pose[i];sprintf_s(value,"%.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g",p.b.r.x,p.b.r.y,p.b.r.z,p.b.u.x,p.b.u.y,p.b.u.z,p.b.f.x,p.b.f.y,p.b.f.z,p.p.x,p.p.y,p.p.z);if(!WritePrivateProfileStringA("Propane",key,value,path))return false;char handKey[24],handValue[8];sprintf_s(handKey,"Grip%uHand",i);sprintf_s(handValue,"%d",grips.side[i]);if(!WritePrivateProfileStringA("Propane",handKey,handValue,path))return false;}char count[16];sprintf_s(count,"%u",grips.count);bool ok=WritePrivateProfileStringA("Propane","Count",count,path)!=0;WritePrivateProfileStringA(nullptr,nullptr,nullptr,path);return ok;}
 grips={};unsigned n=GetPrivateProfileIntA("Propane","Count",0,path);for(unsigned i=0;i<(std::min)(n,3u);++i){char key[16],value[512];sprintf_s(key,"Grip%u",i);GetPrivateProfileStringA("Propane",key,"",value,sizeof(value),path);Pose p{};if(sscanf_s(value,"%f %f %f %f %f %f %f %f %f %f %f %f",&p.b.r.x,&p.b.r.y,&p.b.r.z,&p.b.u.x,&p.b.u.y,&p.b.u.z,&p.b.f.x,&p.b.f.y,&p.b.f.z,&p.p.x,&p.p.y,&p.p.z)==12){char handKey[24];sprintf_s(handKey,"Grip%uHand",i);int hand=(int)GetPrivateProfileIntA("Propane",handKey,-1,path);grips.add(p,hand);}}return grips.count!=0;
}
inline Pose pose(Object o){Pose p{};if(Reload::validObject(o)){memcpy(&p.p,(char*)o.ptr+4,12);memcpy(&p.b,(char*)o.ptr+0x10,36);}return p;}
inline bool tank(void* object){if(!memory(object,0x104)||(word(object,0x70)!=~0u&&word(object,0x48)!=0)||*((unsigned char*)object+0x7e)!=1)return false;void* def=(void*)(uintptr_t)word(object,0xa4);const char* name=(const char*)(uintptr_t)word(def,0);return memory(name,13)&&!strcmp(name,"propane_tank");}
inline bool __cdecl filter(void* object,void*){return tank(object);}
inline bool body(Object o,unsigned& id){id=word(o.ptr,0x4c);return Reload::validObject(o)&&id<65536&&word(base,0x236e980+id*4)!=0;}
// Bounded incremental registry discovery is independent of Havok contact filters.
inline Object discovered[256]{};inline unsigned discoveryCursor=0,discoveryNext=0;inline DWORD discoveryTick=0;
inline void discover(){
 DWORD now=GetTickCount();if(discoveryTick&&DWORD(now-discoveryTick)<20)return;discoveryTick=now;
 void* table=(void*)(uintptr_t)word(base,0x2b98950);unsigned count=word(base,0x2b98954);if(!table||!count||count>65536)return;
 for(unsigned n=0;n<(std::min)(512u,count);++n){unsigned bucket=discoveryCursor++%count;void* node=(void*)(uintptr_t)word(table,bucket*4);
  for(unsigned depth=0;node&&depth<128;++depth){void* item=(void*)(uintptr_t)word(node,0);void* next=(void*)(uintptr_t)word(node,4);if(tank(item)){Object found{item,word(item,0x6c)};bool known=false;for(auto& entry:discovered)if(entry.ptr==item){entry=found;known=true;break;}if(!known)discovered[discoveryNext++%256]=found;}if(next==node)break;node=next;}
 }
}
inline Object nearbyTank(const Target& t,int nearGrip[2]){
 discover();Object result{};float best=t.motion.scale;
 for(auto& item:discovered){if(!Reload::validObject(item)||!tank(item.ptr))continue;unsigned id;if(!body(item,id))continue;Pose p=pose(item);for(unsigned h=0;h<2;++h){int g=grips.aimed(p,t.hand[h],t.aim[h].b.f,t.motion.scale);if(g<0)continue;float d=length(sub(add(p.p,world(p.b,grips.pose[g].p)),t.hand[h].p));if(d<=best){best=d;result=item;}}}
 if(result.ptr){Pose p=pose(result);for(unsigned h=0;h<2;++h)nearGrip[h]=grips.aimed(p,t.hand[h],t.aim[h].b.f,t.motion.scale);}
 return result;
}
inline void makeDynamic(unsigned id){void* b=(void*)(uintptr_t)word(base,0x236e980+id*4);unsigned type=word(b,0xe8)&255;if(movable&&(type==4||type==5))movable(id,true);}
inline void release(const Target& t,bool throwIt){PropaneCollision::clear();if(Reload::validObject(held)){unsigned id=0;if(body(held,id)){makeDynamic(id);if(throwIt){const auto& motion=releaseMotion[releaseHand].output;V v=motion.valid?vrprop::limited(mul(add(mul(motion.linear,t.motion.scale*.85f),mul(motor.velocity,.15f)),1.25f),14.f*t.motion.scale):motor.velocity;if(linearVelocity)linearVelocity(id,&v);if(spin){V a=motion.valid?vrprop::limited(motion.angular,20.f):motor.angular;spin(id,&a);}}}}if(held.ptr)log(throwIt?"Propane released: tracked grip/rotation velocity plus native carry momentum":"Propane carry cancelled; physics restored");held={};heldMask=0;motor.reset();for(auto& m:releaseMotion)m.reset();RFGRVRWeaponInput::propaneHeld=false;}
inline void clearVisual(){editing=false;AcquireSRWLockExclusive(&visualLock);visual={};ReleaseSRWLockExclusive(&visualLock);RFGRVRWeaponInput::propaneHeld=false;}
inline void update(const Target& t,bool allowed){
 PropaneCollision::localPlayer.store(allowed?(uintptr_t)t.player:0);
 if(!profileReady){profileReady=true;profile(false);if(!grips.count)grips.add({M{{1,0,0},{0,1,0},{0,0,1}},{0,.32f,0}});}
 bool edge[2]{};for(unsigned i=0;i<2;++i){bool down=t.squeeze[i]>(pressed[i]?.35f:.65f);edge[i]=down&&!pressed[i];pressed[i]=down;}
 if(!allowed){lastSearch=0;nearby={};release(t,false);if(Reload::validObject(preview))Reload::erase(preview);clearVisual();return;}
 if(!info&&Reload::itemLookup)info=Reload::itemLookup("propane_tank");if(!info){if(captureRequest.exchange(false))vrstatus::notify("Propane resource is not loaded yet");release(t,false);clearVisual();return;}
 if(captureRequest.exchange(false)){if(Reload::validObject(preview)){Reload::erase(preview);vrstatus::notify("Propane grip placement finished");}else if(!heldMask){editSlot=0;edge[0]=edge[1]=false;Pose p{t.motion.body.b,add(t.motion.body.p,world(t.motion.body.b,{0,1.15f*t.motion.scale,.7f*t.motion.scale}))};preview=Reload::spawn(info,p,false);char event[160];sprintf_s(event,"Propane preview: object=%p info=%p valid=%d",preview.ptr,info,Reload::validObject(preview)?1:0);log(event);if(Reload::validObject(preview))vrstatus::notify("Propane grips: place either hand and squeeze grip to SAVE; Numpad0 finishes");else vrstatus::notify("Propane preview resource unavailable");}}
 Visual out;out.tick=GetTickCount();
 editing=Reload::validObject(preview);if(editing){out.editing=true;out.stowed=t.handle;RFGRVRWeaponInput::propaneTick=GetTickCount();RFGRVRWeaponInput::propaneHeld=true;Pose p=pose(preview);for(unsigned h=0;h<2;++h)if(edge[h]){Pose localGrip{relative(p.b,t.hand[h].b),local(p.b,sub(t.hand[h].p,p.p))};if(length(localGrip.p)<1.8f*t.motion.scale&&grips.set(editSlot,localGrip)){bool saved=profile(true);char event[120];sprintf_s(event,"Propane grip saved: hand=%u count=%u saved=%d",h,grips.count,saved?1:0);log(event);if(saved){editSlot=(editSlot+1)%3;char status[120];sprintf_s(status,"Grip SAVED; place grip %u of 3 next. Numpad0 finishes.",editSlot+1);vrstatus::notify(status);}else vrstatus::notify("Propane grip could not save");}}out.markerCount=grips.count;out.selected=editSlot;for(unsigned i=0;i<grips.count;++i)out.markers[i]=add(p.p,world(p.b,grips.pose[i].p));out.markerValid=grips.count!=0;out.nearHand=1;out.marker=add(p.p,world(p.b,grips.pose[grips.count-1].p));out.nearHand=length(sub(t.hand[0].p,out.marker))<length(sub(t.hand[1].p,out.marker))?0:1;}
 else {
  if(!Reload::validObject(held))release(t,false);
  if(heldMask){releaseHand=(heldMask&2)?1:0;sampleRelease(t);for(unsigned h=0;h<2;++h)if((heldMask&(1u<<h))&&!pressed[h])heldMask&=~(1u<<h);if(!heldMask)release(t,true);}
  Object candidate=held;Pose objectPose=pose(candidate);int nearGrip[2]={-1,-1};
  if(heldMask){for(unsigned h=0;h<2;++h)if(!(heldMask&(1u<<h)))nearGrip[h]=grips.aimed(objectPose,t.hand[h],t.aim[h].b.f,1.0f*t.motion.scale);}
  else if(worldQuery&&freeHits&&resolveObject){
   bool search=!lastSearch||DWORD(GetTickCount()-lastSearch)>=50;if(search){lastSearch=GetTickCount();nearby={};
   // Short local Havok queries, not a global object scan.
   float best=1.0f*t.motion.scale;for(unsigned h=0;h<2;++h){SweepRequest req{};req.from=t.hand[h].p;req.to=add(req.from,{0,.002f,0});req.radius=1.0f*t.motion.scale;req.filter=(void*)filter;req.context=(void*)&t;req.mask=word(base,0x125fe84);req.mode=1;HitArray hits{};PropaneCollision::DiscoveryScope pickupSearch;if(worldQuery(&req,&hits)&&hits.count>0&&hits.count<128&&memory(hits.data,hits.count*0x38)){for(int n=0;n<hits.count;++n){void* item=resolveObject(base+0x2b98490,word((char*)hits.data+n*0x38,0x28));if(!tank(item))continue;Object o{item,word(item,0x6c)};Pose p=pose(o);int g=grips.nearest(p,t.hand[h].p,best,int(h));if(g>=0){best=length(sub(add(p.p,world(p.b,grips.pose[g].p)),t.hand[h].p));candidate=o;nearby=o;objectPose=p;nearGrip[0]=nearGrip[1]=-1;nearGrip[h]=g;}}}freeHits(&hits);}}
   candidate=nearby;if(Reload::validObject(candidate)&&tank(candidate.ptr)){objectPose=pose(candidate);for(unsigned h=0;h<2;++h)nearGrip[h]=grips.aimed(objectPose,t.hand[h],t.aim[h].b.f,1.0f*t.motion.scale);}
  }
  if(!heldMask){Object registryCandidate=nearbyTank(t,nearGrip);if(registryCandidate.ptr){candidate=registryCandidate;nearby=candidate;objectPose=pose(candidate);}}
  float markerDistance=1.01f*t.motion.scale;for(unsigned h=0;h<2;++h)if(nearGrip[h]>=0){V point=add(objectPose.p,world(objectPose.b,grips.pose[nearGrip[h]].p));float distance=length(sub(point,t.hand[h].p));if(distance<markerDistance){markerDistance=distance;out.markerValid=true;out.nearHand=int(h);out.marker=point;}if(edge[h]&&distance<=1.0f*t.motion.scale ){unsigned id=0;if(body(candidate,id)){if(!heldMask){held=candidate;motor.reset();char event[160];sprintf_s(event,"Propane grabbed: object=%p handle=%08x body=%u hand=%u",held.ptr,held.handle,id,h);log(event);}gripIndex[h]=unsigned(nearGrip[h]);heldGrip[h]=grips.smart(gripIndex[h],objectPose,t.hand[h]);releaseMotion[h].reset();heldMask|=1u<<h;makeDynamic(id);}}}
  if(heldMask&&Reload::validObject(held)){
   PropaneCollision::publish(t,held.ptr);objectPose=pose(held);unsigned primary=(heldMask&2)?1:0,count=(heldMask==3)?2:1;Pose goal=vrprop::inverseGrip(t.hand[primary],heldGrip[primary]);
   if(count==2){unsigned other=1-primary;Pose second=vrprop::inverseGrip(t.hand[other],heldGrip[other]);goal.p=mul(add(goal.p,second.p),.5f);V a=sub(heldGrip[other].p,heldGrip[primary].p),b=sub(t.hand[other].p,t.hand[primary].p);if(length(a)>.03f&&length(b)>.03f){V pivot=add(goal.p,world(goal.b,heldGrip[primary].p));goal.b=rotateTo(goal.b,world(goal.b,a),b);goal.p=sub(pivot,world(goal.b,heldGrip[primary].p));}}
   unsigned id=0;if(body(held,id)&&motor.step(objectPose,goal,count,t.motion.scale,GetTickCount64())){if(linearVelocity)linearVelocity(id,&motor.velocity);if(spin)spin(id,&motor.angular);}else if(!Reload::validObject(held)||length(sub(goal.p,objectPose.p))>1.5f*t.motion.scale){release(t,false);clearVisual();return;}

   out.heldMask=heldMask;out.stowed=t.handle;if(heldMask==3)out.markerValid=false;for(unsigned h=0;h<2;++h)if(heldMask&(1u<<h))out.hand[h]={compose(objectPose.b,heldGrip[h].b),add(objectPose.p,world(objectPose.b,heldGrip[h].p))};
   RFGRVRWeaponInput::propaneTick=GetTickCount();RFGRVRWeaponInput::propaneHeld=true;
  }
 }
 AcquireSRWLockExclusive(&visualLock);visual=out;ReleaseSRWLockExclusive(&visualLock);
}
}






