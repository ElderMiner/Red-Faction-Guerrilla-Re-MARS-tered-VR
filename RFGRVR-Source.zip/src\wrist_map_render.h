#pragma once
#define RFGR_HUD_NAMESPACE RFGRVRWristMap
#define RFGR_HUD_CHANNEL RFGR_WRIST_MAP
#define RFGR_HUD_HASH 0x37bd4502u
#define RFGR_HUD_FIRST 0u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRAmmoHud
#define RFGR_HUD_CHANNEL RFGR_AMMO_HUD
#define RFGR_HUD_HASH 0x371afa45u
#define RFGR_HUD_FIRST 21844u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRChargeHud
#define RFGR_HUD_CHANNEL RFGR_CHARGE_HUD
#define RFGR_HUD_HASH 0x9c6c1157u
#define RFGR_HUD_FIRST 43688u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRNoticeHud
#define RFGR_HUD_CHANNEL RFGR_NOTICE_HUD
#define RFGR_HUD_HASH 0xd603f74bu // message_use: contextual use button, background and action icon
#define RFGR_HUD_FIRST 65532u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRMissionHud
#define RFGR_HUD_CHANNEL RFGR_MISSION_HUD
#define RFGR_HUD_HASH 0xf1db4e16u // NEW GUERRILLA ACTION availability alert
#define RFGR_HUD_FIRST 87376u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRHealthHud
#define RFGR_HUD_CHANNEL RFGR_HEALTH_HUD
#define RFGR_HUD_HASH 0x95e9bca3u // health_meter_main, excludes full-screen blood gradients
#define RFGR_HUD_FIRST 109220u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRSelectionHud
#define RFGR_HUD_CHANNEL RFGR_WEAPON_SELECTOR
#define RFGR_HUD_HASH 0xc40c4e38u
#define RFGR_HUD_FIRST 131064u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRMenuHud
#define RFGR_HUD_CHANNEL RFGR_MENU_HUD
#define RFGR_HUD_HASH 0u
#define RFGR_HUD_FIRST 152908u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVROverheatHud
#define RFGR_HUD_CHANNEL RFGR_OVERHEAT_HUD
#define RFGR_HUD_HASH 0x63befd4fu
#define RFGR_HUD_FIRST 174752u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRMainVideo
#define RFGR_HUD_CHANNEL RFGR_MAINMENU_VIDEO
#define RFGR_HUD_HASH 0u
#define RFGR_HUD_FIRST 196596u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRMainUI
#define RFGR_HUD_CHANNEL RFGR_MAINMENU_UI
#define RFGR_HUD_HASH 0u
#define RFGR_HUD_FIRST 218440u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRFactionHud
#define RFGR_HUD_CHANNEL RFGR_FACTION_HUD
#define RFGR_HUD_HASH 0xea8ce371u // native EDF control meter and power-change animation
#define RFGR_HUD_FIRST 240284u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
#define RFGR_HUD_NAMESPACE RFGRVRMoraleHud
#define RFGR_HUD_CHANNEL RFGR_MORALE_HUD
#define RFGR_HUD_HASH 0xf744587du // native Red Faction morale updates
#define RFGR_HUD_FIRST 262128u
#include "hud_group_render.h"
#undef RFGR_HUD_NAMESPACE
#undef RFGR_HUD_CHANNEL
#undef RFGR_HUD_HASH
#undef RFGR_HUD_FIRST
namespace RFGRVRWorldHud {
inline bool installed=false;inline RFGRVRWristMap::Emit nativeEmit=nullptr;
inline void __fastcall emit(void* renderer,void*,unsigned type,unsigned primitives,const void* data,unsigned stride){
 vrmemory::Scope memoryScope;
 if(stride!=sizeof(vrwrist::Vertex)||!data||primitives>16384){nativeEmit(renderer,type,primitives,data,stride);return;}unsigned n=vrwrist::vertexCount(type,primitives);if(!n||!RFGRVRWristMap::readable(data,n*stride)){nativeEmit(renderer,type,primitives,data,stride);return;}
 const auto* vertices=(const vrwrist::Vertex*)data;unsigned epoch=0;for(unsigned i=0;i<n;++i)if((epoch=vrwrist::epoch(vertices[i])))break;
 if(!epoch)nativeEmit(renderer,type,primitives,data,stride);else if(epoch<=21844)RFGRVRWristMap::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=43688)RFGRVRAmmoHud::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=65532)RFGRVRChargeHud::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=87376)RFGRVRNoticeHud::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=109220)RFGRVRMissionHud::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=131064)RFGRVRHealthHud::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=152908u)RFGRVRSelectionHud::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=174752u)RFGRVRMenuHud::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=196596u)RFGRVROverheatHud::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=218440u)RFGRVRMainVideo::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=240284u)RFGRVRMainUI::emit(renderer,nullptr,type,primitives,data,stride);else if(epoch<=262128u)RFGRVRFactionHud::emit(renderer,nullptr,type,primitives,data,stride);else RFGRVRMoraleHud::emit(renderer,nullptr,type,primitives,data,stride);
}
inline bool install(){vrscope::nativeOverlay=&RFGRVRMenuHud::scopeOverlay;if(installed)return true;if(!RFGRVRWristMap::install((void*)&emit,false))return false;
 RFGRVRMoraleHud::originalDraw=RFGRVRWristMap::originalDraw;RFGRVRFactionHud::originalDraw=(RFGRVRFactionHud::Draw)&RFGRVRMoraleHud::draw;RFGRVRMainVideo::originalDraw=(RFGRVRMainVideo::Draw)&RFGRVRFactionHud::draw;RFGRVRMainUI::originalDraw=(RFGRVRMainUI::Draw)&RFGRVRMainVideo::draw;RFGRVROverheatHud::originalDraw=(RFGRVROverheatHud::Draw)&RFGRVRMainUI::draw;RFGRVRMenuHud::originalDraw=(RFGRVRMenuHud::Draw)&RFGRVROverheatHud::draw;RFGRVRSelectionHud::originalDraw=(RFGRVRSelectionHud::Draw)&RFGRVRMenuHud::draw;RFGRVRHealthHud::originalDraw=(RFGRVRHealthHud::Draw)&RFGRVRSelectionHud::draw;RFGRVRMissionHud::originalDraw=(RFGRVRMissionHud::Draw)&RFGRVRHealthHud::draw;RFGRVRNoticeHud::originalDraw=(RFGRVRNoticeHud::Draw)&RFGRVRMissionHud::draw;RFGRVRChargeHud::originalDraw=(RFGRVRChargeHud::Draw)&RFGRVRNoticeHud::draw;RFGRVRAmmoHud::originalDraw=(RFGRVRAmmoHud::Draw)&RFGRVRChargeHud::draw;RFGRVRWristMap::originalDraw=(RFGRVRWristMap::Draw)&RFGRVRAmmoHud::draw;
 RFGRVRMoraleHud::originalAlloc=RFGRVRWristMap::originalAlloc;RFGRVRFactionHud::originalAlloc=(RFGRVRFactionHud::Alloc)&RFGRVRMoraleHud::alloc;RFGRVRMainVideo::originalAlloc=(RFGRVRMainVideo::Alloc)&RFGRVRFactionHud::alloc;RFGRVRMainUI::originalAlloc=(RFGRVRMainUI::Alloc)&RFGRVRMainVideo::alloc;RFGRVROverheatHud::originalAlloc=(RFGRVROverheatHud::Alloc)&RFGRVRMainUI::alloc;RFGRVRMenuHud::originalAlloc=(RFGRVRMenuHud::Alloc)&RFGRVROverheatHud::alloc;RFGRVRSelectionHud::originalAlloc=(RFGRVRSelectionHud::Alloc)&RFGRVRMenuHud::alloc;RFGRVRHealthHud::originalAlloc=(RFGRVRHealthHud::Alloc)&RFGRVRSelectionHud::alloc;RFGRVRMissionHud::originalAlloc=(RFGRVRMissionHud::Alloc)&RFGRVRHealthHud::alloc;RFGRVRNoticeHud::originalAlloc=(RFGRVRNoticeHud::Alloc)&RFGRVRMissionHud::alloc;RFGRVRChargeHud::originalAlloc=(RFGRVRChargeHud::Alloc)&RFGRVRNoticeHud::alloc;RFGRVRAmmoHud::originalAlloc=(RFGRVRAmmoHud::Alloc)&RFGRVRChargeHud::alloc;RFGRVRWristMap::originalAlloc=(RFGRVRWristMap::Alloc)&RFGRVRAmmoHud::alloc;
 nativeEmit=RFGRVRWristMap::originalEmit;RFGRVRAmmoHud::originalEmit=RFGRVRChargeHud::originalEmit=RFGRVRNoticeHud::originalEmit=RFGRVRMissionHud::originalEmit=RFGRVRHealthHud::originalEmit=RFGRVRSelectionHud::originalEmit=RFGRVRMenuHud::originalEmit=RFGRVROverheatHud::originalEmit=RFGRVRMainVideo::originalEmit=RFGRVRMainUI::originalEmit=RFGRVRFactionHud::originalEmit=RFGRVRMoraleHud::originalEmit=nativeEmit;
 RFGRVRMoraleHud::originalFlush=RFGRVRWristMap::originalFlush;RFGRVRFactionHud::originalFlush=(RFGRVRFactionHud::Flush)&RFGRVRMoraleHud::flush;RFGRVRMainVideo::originalFlush=(RFGRVRMainVideo::Flush)&RFGRVRFactionHud::flush;RFGRVRMainUI::originalFlush=(RFGRVRMainUI::Flush)&RFGRVRMainVideo::flush;RFGRVROverheatHud::originalFlush=(RFGRVROverheatHud::Flush)&RFGRVRMainUI::flush;RFGRVRMenuHud::originalFlush=(RFGRVRMenuHud::Flush)&RFGRVROverheatHud::flush;RFGRVRSelectionHud::originalFlush=(RFGRVRSelectionHud::Flush)&RFGRVRMenuHud::flush;RFGRVRHealthHud::originalFlush=(RFGRVRHealthHud::Flush)&RFGRVRSelectionHud::flush;RFGRVRMissionHud::originalFlush=(RFGRVRMissionHud::Flush)&RFGRVRHealthHud::flush;RFGRVRNoticeHud::originalFlush=(RFGRVRNoticeHud::Flush)&RFGRVRMissionHud::flush;RFGRVRChargeHud::originalFlush=(RFGRVRChargeHud::Flush)&RFGRVRNoticeHud::flush;RFGRVRAmmoHud::originalFlush=(RFGRVRAmmoHud::Flush)&RFGRVRChargeHud::flush;RFGRVRWristMap::originalFlush=(RFGRVRWristMap::Flush)&RFGRVRAmmoHud::flush;
 RFGRVRMoraleHud::installed=RFGRVRFactionHud::installed=RFGRVRMainVideo::installed=RFGRVRMainUI::installed=RFGRVROverheatHud::installed=RFGRVRMenuHud::installed=RFGRVRSelectionHud::installed=RFGRVRHealthHud::installed=RFGRVRMissionHud::installed=RFGRVRNoticeHud::installed=RFGRVRAmmoHud::installed=RFGRVRChargeHud::installed=true;auto* base=(unsigned char*)GetModuleHandleW(nullptr);for(unsigned rva:{0x78520u,0x1505c0u,0x12d690u,0x150480u})if(MH_EnableHook(base+rva)!=MH_OK)return false;installed=true;return true;}
inline void present(IDXGISwapChain* s){RFGRVRWristMap::present(s);RFGRVRAmmoHud::present(s);RFGRVRChargeHud::present(s);RFGRVRNoticeHud::present(s);RFGRVRMissionHud::present(s);RFGRVRHealthHud::present(s);RFGRVRSelectionHud::present(s);RFGRVRMenuHud::present(s);RFGRVROverheatHud::present(s);RFGRVRMainVideo::present(s);RFGRVRMainUI::present(s);RFGRVRFactionHud::present(s);RFGRVRMoraleHud::present(s);}
inline void endCommandList(ID3D11DeviceContext* c){RFGRVRWristMap::endCommandList(c);RFGRVRAmmoHud::endCommandList(c);RFGRVRChargeHud::endCommandList(c);RFGRVRNoticeHud::endCommandList(c);RFGRVRMissionHud::endCommandList(c);RFGRVRHealthHud::endCommandList(c);RFGRVRSelectionHud::endCommandList(c);RFGRVRMenuHud::endCommandList(c);RFGRVROverheatHud::endCommandList(c);RFGRVRMainVideo::endCommandList(c);RFGRVRMainUI::endCommandList(c);RFGRVRFactionHud::endCommandList(c);RFGRVRMoraleHud::endCommandList(c);}
}
