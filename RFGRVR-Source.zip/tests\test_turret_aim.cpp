#include "../src/vehicle_type_catalog.h"
#include "../src/vr_turret_aim.h"
#include <cassert>
#include "../src/vr_frame_parent.h"
#include "../src/vr_rig_math.h"
#include "../src/vr_vehicle_controls.h"
#include "../src/vr_forward_lean.h"
#include "../src/vr_mount_tracking.h"
#include "../src/vr_turret_barrel.h"
#include "../src/vr_turret_rig.h"
int main(){assert(RFGRVRVehicleIsMech("UnknownVariant",2));assert(RFGRVRVehicleIsMech("Walker_NewVariant",0));assert(!RFGRVRVehicleIsMech("EDF_Scout_1",0));assert(!strcmp(RFGRVRVehicleTypeFor("EDF_Scout_Rocket")->type,"EDF_Scout_1"));assert(RFGRVRVehicleTypeFor("EDF_HeavyTank-A_1")->tank&&!RFGRVRVehicleTypeFor("EDF_APC-A_1")->tank);assert(RFGRVR_MechSteering(0)==0&&RFGRVR_MechSteering(6000)==0&&RFGRVR_MechSteering(32767)>8600&&RFGRVR_MechSteering(32767)<8750&&RFGRVR_MechSteering(-32767)==-RFGRVR_MechSteering(32767));short x=0,y=0;for(float sign:{1.f,-1.f}){RFGRVRTurretHandle handle;float h[3]={0,1,-.35f},aim[3]={0,0,1};float yaw=0,pitch=0;assert(handle.update(1,h,aim,0,yaw,pitch,100,&x,&y)&&x==0&&y==0);h[0]=.02f;h[1]+=.02f;aim[0]=sinf(.08f);aim[2]=cosf(.08f);float target=.4f-atan2f(.02f,.55f);for(unsigned frame=1;frame<260;++frame){handle.update(1,h,aim,.4f,yaw,pitch,100+frame*16,&x,&y);auto motor=[&](short a){float axis=a/32767.f;return fabsf(axis)>.25f?(fabsf(axis)-.25f)/.75f*(axis<0?-1.f:1.f):0;};yaw+=motor(x)*sign*3.f*.016f;pitch+=motor(y)*sign*3.f*.016f;}assert(fabsf(yaw-target)<.04f&&fabsf(pitch+atan2f(.02f,sqrtf(.55f*.55f+.02f*.02f)))<.04f);assert(handle.response[0]==sign);}
 RFGRVRTurretHandle wrap;float h[3]={0,1,0},aim[3]={0,0,1};wrap.update(8,h,aim,3.13f,3.13f,0,100,&x,&y);wrap.update(8,h,aim,-3.13f,3.13f,0,116,&x,&y);assert(x>0&&x<20000);wrap.update(9,h,aim,2,1,0,132,&x,&y);assert(x==0&&y==0);
 // Wrist rotation alone must not turn a lever-mounted turret.
 RFGRVRTurretHandle full;float hand[3]={0,1,0},forward[3]={0,0,1};full.update(2,hand,forward,0,0,0,1,&x,&y);forward[0]=sinf(1.f);forward[2]=cosf(1.f);full.update(2,hand,forward,0,0,0,17,&x,&y);assert(x==0&&y==0);
 // Lifting the rear grip lowers the barrel; moving it right points left.
 hand[0]=.2f;hand[1]+=.2f;full.update(2,hand,forward,0,0,0,33,&x,&y);assert(x<0&&y<0);
 // At the exact lever angle there is no motor command.
 full.update(2,hand,forward,0,-atan2f(.2f,.55f),-atan2f(.2f,sqrtf(.2f*.2f+.55f*.55f)),49,&x,&y);assert(x==0&&y==0);
 RFGRVRTurretOrbit orbit;float pivot[3]={10,2,20},head[3]={10,3,19};assert(orbit.update(1,pivot,0,head));assert(fabsf(head[2]-19)<.0001f);orbit.update(1,pivot,1.57079632679f,head);assert(fabsf(orbit.facingYaw(1.57079632679f)-1.57079632679f)<.0001f);assert(fabsf(head[0]-9)<.0001f&&fabsf(head[2]-20)<.0001f&&head[1]==3);
 // Swivel translation carries the rig, and unrelated native seat jitter does not.
 pivot[0]+=3;head[0]=999;orbit.update(1,pivot,1.57079632679f,head);assert(fabsf(head[0]-12)<.0001f);orbit.reset();head[0]=13;head[2]=19;orbit.update(2,pivot,0,head);assert(head[0]==13&&head[2]==19);
 // A streamed/moved turret's gun cache is in its old component frame.
 auto basis=[](float yaw){return vrarm::M{{cosf(yaw),0,-sinf(yaw)},{0,1,0},{sinf(yaw),0,cosf(yaw)}};};
 float barrelYaw=0,barrelPitch=0;auto reference=basis(-.5f),root=basis(.8f);auto relativeGun=vrarm::turnAround(basis(.2f),{1,0,0},.15f);auto gun=vrarm::compose(reference,relativeGun);auto expected=vrarm::compose(root,relativeGun);
 assert(RFGRVR_TurretBarrel(root,reference,gun,&barrelYaw,&barrelPitch));assert(fabsf(barrelYaw-atan2f(expected.f.x,expected.f.z))<.0001f&&fabsf(barrelPitch-asinf(expected.f.y))<.0001f);
 RFGRVRTurretRig independent;vrarm::Pose pivotPose{basis(0),{10,1,20}};vrarm::V nativeBody{10,1,19},physicalHand{0,1,0};assert(independent.update(7,pivotPose,nativeBody,physicalHand,0,1,0,0,-3.14f,3.14f,-1,1));auto neutralBody=independent.body;
 physicalHand.y+=.3f;assert(independent.update(7,pivotPose,nativeBody,physicalHand,0,1,0,.016f,-3.14f,3.14f,-1,1));assert(independent.gunPitch<0&&vrarm::length(vrarm::sub(independent.body.p,neutralBody.p))<.0001f&&vrarm::length(vrarm::sub(independent.body.b.f,neutralBody.b.f))<.0001f);
 // Stick changes the body orbit, facing inward. Barrel pitch never moves eye/body.
 for(int i=0;i<100;++i)independent.update(7,pivotPose,nativeBody,physicalHand,0,1,1,.01f,-3.14f,3.14f,-1,1);
 auto inward=vrarm::unit(vrarm::sub(pivotPose.p,independent.body.p));assert(vrarm::dot(inward,independent.body.b.f)>.999f&&fabsf(vrarm::length(vrarm::sub(independent.body.p,pivotPose.p))-1)<.0001f&&independent.body.p.y==neutralBody.p.y);
 assert(independent.body.p.x>neutralBody.p.x);auto saved=independent.body;physicalHand.y-=.6f;independent.update(7,pivotPose,nativeBody,physicalHand,0,1,0,.01f,-3.14f,3.14f,-1,1);assert(independent.gunPitch>0&&vrarm::length(vrarm::sub(saved.p,independent.body.p))<.0001f);
 // New mount resets broad facing and target reference.
 independent.update(8,pivotPose,nativeBody,physicalHand,0,1,0,0,-1,1,-1,1);assert(independent.orbit==0&&independent.gunPitch==0&&independent.gunYaw==0);
 // Physical room motion carries the body under the player without an extra eye step.
 RFGRVRTurretRig room;vrarm::V neck{0,1.7f,0};room.update(1,pivotPose,nativeBody,{0,1,0},0,1,0,0,-3.14f,3.14f,-1,1,&neck);auto initialBody=room.body;
 neck.x=.2f;room.update(1,pivotPose,nativeBody,{0,1,0},0,1,0,.01f,-3.14f,3.14f,-1,1,&neck);assert(fabsf(room.body.p.x-initialBody.p.x-.14f)<.0001f&&fabsf(room.roomOffset.x-.14f)<.0001f);float eyeX=room.body.p.x+(.2f-room.roomOffset.x);assert(fabsf(eyeX-initialBody.p.x-.2f)<.0001f);
 // Vehicle mounts rotate in place at the player/seat, never orbit the gun.
 RFGRVRTurretRig seat;vrarm::V seatPoint{10.25f,1,19};seat.update(5,pivotPose,seatPoint,{0,1,0},0,1,0,0,-3.1416f,3.1416f,-1,1,nullptr,true);assert(vrarm::length(vrarm::sub(seat.body.p,vrarm::V{pivotPose.p.x,seatPoint.y,pivotPose.p.z}))<.0001f);
 for(int i=0;i<100;++i)seat.update(5,pivotPose,seatPoint,{0,1,0},0,1,1,.01f,-3.1416f,3.1416f,-1,1,nullptr,true);
 assert(vrarm::length(vrarm::sub(seat.body.p,vrarm::V{pivotPose.p.x,seatPoint.y,pivotPose.p.z}))<.0001f&&seat.body.b.f.x>.99f);
 pivotPose.p.x+=2;seat.update(5,pivotPose,seatPoint,{0,1,0},0,1,0,.01f,-3.1416f,3.1416f,-1,1,nullptr,true);assert(fabsf(seat.body.p.x-pivotPose.p.x)<.0001f);
 // A banked seat follows its actual rotation axis and keeps vehicle-relative up.
 {auto tilted=pivotPose;tilted.b=vrarm::turnAround(tilted.b,{0,0,1},.15f);RFGRVRTurretRig banked;banked.update(77,tilted,seatPoint,{0,1,0},0,1,0,0,-3.1416f,3.1416f,-1,1,nullptr,true);auto point=add(tilted.p,world(tilted.b,vrarm::V{0,banked.seatLocal.y,0}));assert(length(sub(banked.body.p,point))<.0001f&&length(sub(banked.body.b.u,tilted.b.u))<.0001f);for(int i=0;i<80;++i)banked.update(77,tilted,seatPoint,{0,1,0},0,1,1,.01f,-3.1416f,3.1416f,-1,1,nullptr,true);assert(length(sub(banked.body.p,point))<.0001f&&length(sub(banked.body.b.u,tilted.b.u))<.0001f);}
 // Entry preserves current gun targets and actual standing position, avoiding a snap when waking physics.
 RFGRVRTurretRig entry;vrarm::V offsetBody{11,1,19};entry.update(9,pivotPose,offsetBody,{0,1,0},0,1,0,0,-3.14f,3.14f,-1,1,nullptr,false,.4f,-.2f);
 assert(fabsf(entry.gunYaw-.4f)<.0001f&&fabsf(entry.gunPitch+.2f)<.0001f);
 assert(vrarm::length(vrarm::sub(entry.body.p,offsetBody))<.0001f);
 RFGRVRMountTracking mount;float origin[3]={.1f,1.7f,.3f},center[3]={1.2f,1.2f,-.8f};
 assert(!mount.update(~0u,center,origin));assert(mount.update(7,center,origin));assert(origin[0]==center[0]&&origin[2]==center[2]&&origin[1]==1.7f);
 center[0]+=.2f;assert(!mount.update(7,center,origin)&&origin[0]!=center[0]); // Physical motion remains tracked after entry.
 assert(mount.update(8,center,origin)&&origin[0]==center[0]);assert(mount.update(~0u,center,origin)&&origin[1]==1.7f);
 // A native entry animation may finish moving the actor after state3 begins.
 RFGRVRTurretRig relocation;vrarm::V entryBody{10,1,19};relocation.update(42,pivotPose,entryBody,{0,1,0},0,1,0,0,-3.14f,3.14f,-1,1);
 entryBody.x+=.5f;relocation.update(42,pivotPose,entryBody,{0,1,0},0,1,0,.016f,-3.14f,3.14f,-1,1);assert(vrarm::length(vrarm::sub(relocation.body.p,entryBody))<.0001f);
 for(int i=0;i<20;++i)relocation.update(42,pivotPose,entryBody,{0,1,0},0,1,0,.016f,-3.14f,3.14f,-1,1);
 assert(!relocation.entering);auto lockedBody=relocation.body;entryBody.x+=.2f;relocation.update(42,pivotPose,entryBody,{0,1,0},0,1,0,.016f,-3.14f,3.14f,-1,1);assert(vrarm::length(vrarm::sub(relocation.body.p,lockedBody.p))<.0001f);
 // Head-turn neck-model error does not translate the mounted avatar.
 RFGRVRTurretRig sway;vrarm::V neck0{0,1.7f,0};sway.update(61,pivotPose,nativeBody,{0,1,0},0,1,0,0,-3.14f,3.14f,-1,1,&neck0);auto fixed=sway.body;
 neck0.x=.035f;sway.update(61,pivotPose,nativeBody,{0,1,0},0,1,0,.016f,-3.14f,3.14f,-1,1,&neck0);assert(vrarm::length(vrarm::sub(fixed.p,sway.body.p))<.0001f);
 // A measured 35cm rear grip maps its circular travel directly to barrel angle.
 RFGRVRTurretRig exact;vrarm::Pose axis{basis(0),{0,0,0}};vrarm::V behind{0,0,-.8f};float angle=.4f,lever=.35f;
 exact.update(62,axis,behind,{0,1,0},0,1,0,0,-3.14f,3.14f,-1,1,nullptr,false,0,0,lever);
 exact.update(62,axis,behind,{0,1+lever*sinf(angle),lever*(1-cosf(angle))},0,1,0,.016f,-3.14f,3.14f,-1,1,nullptr,false,0,0,lever);assert(fabsf(exact.gunPitch+angle)<.0001f);
 RFGRVRVehicleControls controls;controls.update(7,0,false,.016f);controls.update(7,1,true,.05f);assert(controls.height>0&&controls.reticle);controls.update(7,0,true,.016f);assert(controls.reticle);controls.update(7,0,false,.016f);controls.update(7,0,true,.016f);assert(!controls.reticle);controls.update(~0u,0,false,.016f);assert(controls.height==0&&!controls.reticle);
 RFGRVRForwardLean lean;for(int i=0;i<100;++i)lean.update(1,.016f,true);assert(lean.angle>.17f&&lean.angle<.175f);vrarm::Pose eye{basis(0),{0,1.7f,0}},chest{basis(0),{0,1.3f,0}};auto leanedEye=RFGRVR_LeanPose(eye,{0,.9f,0},lean.angle),leanedChest=RFGRVR_LeanPose(chest,{0,.9f,0},lean.angle);assert(leanedEye.p.z>0&&fabsf(vrarm::length(vrarm::sub(leanedEye.p,leanedChest.p))-.4f)<.0001f);
 // Vehicle reversal changes motion direction without snapping a nonzero entry angle.
 RFGRVRTurretRig vehicleEntry;vrarm::V vehicleNeck{0,1.6f,0};vehicleEntry.update(91,axis,behind,{0,1,0},0,1,0,0,-3.14f,3.14f,-1,1,&vehicleNeck,true,.4f,0,.35f);assert(fabsf(vehicleEntry.gunYaw-.4f)<.0001f);auto vehicleCenter=vehicleEntry.body.p;vehicleNeck.x+=.5f;vehicleEntry.update(91,axis,behind,{.02f,1,0},0,1,0,.016f,-3.14f,3.14f,-1,1,&vehicleNeck,true,.4f,0,.35f);assert(vehicleEntry.gunYaw<.4f&&vrarm::length(vrarm::sub(vehicleEntry.body.p,vehicleCenter))<.0001f);
 // Fine hand yaw must not rotate the seated body; coarse stick yaw must
 // turn the gun and seated rig together, rather than just changing the view.
 RFGRVRTurretRig seated;seated.update(92,axis,behind,{0,1,0},0,1,0,0,-3.1416f,3.1416f,-1,1,nullptr,true,0,0,.35f);auto seatAnchor=seated.body;
 seated.update(92,axis,behind,{.05f,1,0},0,1,0,.016f,-3.1416f,3.1416f,-1,1,nullptr,true,0,0,.35f);assert(seated.gunYaw<0&&length(sub(seated.body.b.f,seatAnchor.b.f))<.0001f);
 for(unsigned i=0;i<20;++i)seated.update(92,axis,behind,{0,1,0},0,1,1,.016f,-3.1416f,3.1416f,-1,1,nullptr,true,0,0,.35f);
 assert(seated.gunYaw>.4f&&seated.body.b.f.x>.4f&&length(sub(seated.body.p,seatAnchor.p))<.0001f);
 // A different vehicle animation parent must start from room-up, never
 // preserve the previous parent's bank as the next seat's permanent offset.
 float banked[3][3]={{.9f,.3f,-.3f},{-.3f,.95f,.1f},{.3f,0,.953939f}},upright[3][3]{},resetParent[3][3]{};RFGRVR_UprightBasis(banked,upright);RFGRVR_ParentBasis(banked,banked,upright,resetParent);assert(upright[0][1]==0&&upright[1][1]==1&&upright[2][1]==0);assert(fabsf(atan2f(upright[2][0],upright[2][2])-atan2f(banked[2][0],banked[2][2]))<.0001f);
 // Right-eye reuse must restore seat state, not merely the attached flag.
 RFGRVRFrameParent frozen;frozen.capture(9,true);unsigned rightState=0;bool rightAttached=false;frozen.restore(rightState,rightAttached);assert(rightState==9&&rightAttached);frozen.capture(0,false);frozen.restore(rightState,rightAttached);assert(rightState==0&&!rightAttached);
 // Going beyond a stop and returning must recover the same absolute grip.
 RFGRVRTurretRig absolute;vrarm::Pose absolutePivot{basis(0),{0,1,0}};vrarm::V handle{.03f,0,-.4f};
 assert(absolute.aimAtHandle(absolutePivot,handle,add(absolutePivot.p,handle),-.5f,.5f,-.5f,.5f));assert(fabsf(absolute.gunYaw)<.0001f&&fabsf(absolute.gunPitch)<.0001f);
 absolute.aimAtHandle(absolutePivot,handle,{4,4,0},-.5f,.5f,-.5f,.5f);assert(absolute.gunYaw==-.5f);
 absolute.aimAtHandle(absolutePivot,handle,add(absolutePivot.p,handle),-.5f,.5f,-.5f,.5f);assert(fabsf(absolute.gunYaw)<.0001f&&fabsf(absolute.gunPitch)<.0001f);
 for(unsigned n=0;n<100;++n)absolute.aimAtHandle(absolutePivot,handle,add(absolutePivot.p,handle),-.5f,.5f,-.5f,.5f);assert(fabsf(absolute.gunYaw)<.0001f);

 // Continuous yaw cannot reverse its motor target at the +/-pi boundary.
 {RFGRVRTurretRig spins;float previous=0;for(unsigned i=0;i<1200;++i){spins.update(812,axis,behind,{0,1,0},0,1,1,.01f,-3.1416f,3.1416f,-1,1,nullptr,true);assert(spins.orbit>=previous&&spins.orbit-previous<.017f);previous=spins.orbit;}assert(spins.orbit>18.f);for(unsigned i=0;i<2400;++i){spins.update(812,axis,behind,{0,1,0},0,1,-1,.01f,-3.1416f,3.1416f,-1,1,nullptr,true);assert(spins.orbit<=previous&&previous-spins.orbit<.017f);previous=spins.orbit;}assert(spins.orbit< -18.f);}
 // Coarse seat rotation cannot become fine hand input. The same room-space
 // hand must keep the same fine yaw at any seat angle, including stop/return.
 {RFGRVRTurretRig fine;vrarm::V zero{.2f,1.3f,.4f},moved{.3f,1.3f,.4f};float expected=0;for(unsigned i=0;i<200;++i){absolutePivot.b=basis(float(i)*.08f);assert(fine.aimFromSeat(absolutePivot,handle,zero,zero,.3f,1,-.7f,.7f));assert(fabsf(fine.gunYaw)<.0001f&&fabsf(fine.gunPitch)<.0001f);fine.aimFromSeat(absolutePivot,handle,moved,zero,.3f,1,-.7f,.7f);if(!i)expected=fine.gunYaw;assert(fabsf(fine.gunYaw-expected)<.0001f);}fine.aimFromSeat(absolutePivot,handle,{4,4,.4f},zero,.3f,1,-.7f,.7f);assert(fabsf(fine.gunYaw)==.75f);fine.aimFromSeat(absolutePivot,handle,zero,zero,.3f,1,-.7f,.7f);assert(fabsf(fine.gunYaw)<.0001f);}
 // The handle's neutral control point rotates with the measured seated frame.
 absolutePivot.b=basis(1.1f);vrarm::V rotatedHandle=add(absolutePivot.p,world(absolutePivot.b,handle));absolute.aimAtHandle(absolutePivot,handle,rotatedHandle,-.75f,.75f,-.5f,.5f);assert(fabsf(absolute.gunYaw)<.0001f&&fabsf(absolute.gunPitch)<.0001f);

 // Standing vehicle platforms retain their authored rear offset while ring seats stay centered.
 {RFGRVRTurretRig platform;vrarm::Pose base{basis(0),{10,3,20}};vrarm::V rear{10.3f,3,19.2f},hand{0,1,0};assert(platform.update(91,base,rear,hand,0,1,0,.016f,-3.15f,3.15f,-1,1,nullptr,true,0,0,.5f,true));assert(length(sub(platform.body.p,rear))<.0001f);auto before=platform.body.p;hand.y+=.4f;platform.update(91,base,rear,hand,0,1,0,.016f,-3.15f,3.15f,-1,1,nullptr,true,0,0,.5f,true);assert(length(sub(platform.body.p,before))<.0001f);float radius=length(sub(rear,base.p));for(int i=0;i<100;++i)platform.update(91,base,rear,hand,0,1,1,.016f,-3.15f,3.15f,-1,1,nullptr,true,0,0,.5f,true);assert(fabsf(length(sub(platform.body.p,base.p))-radius)<.0001f&&length(sub(platform.body.p,before))>.1f);}
}



