#define WIN32_LEAN_AND_MEAN
#define DIRECTINPUT_VERSION 0x0800
#include <windows.h>
#include <dinput.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include "ipc.h"
#include "vr_launch_mode.h"
#include "vr_user_settings.h"
#include "vr_adjust_direction.h"
#include "main_menu_capture.h"
#include "game_frame_publisher.h"
extern "C" bool RFGRVR_Temporal_IsEnabled();
extern "C" bool RFGRVR_NativePair_ViewActive();
extern "C" void RFGRVR_Temporal_Recenter();
extern "C" bool RFGRVR_NativeScene_Install();
extern "C" bool RFGRVR_Arms_Install();
extern "C" bool RFGRVR_Gamepad_Install(RFGRShared*);
extern "C" bool RFGRVR_Gamepad_Installed();
extern "C" bool RFGRVR_HeadCam_Enabled();
extern "C" bool RFGRVR_HeadCam_Ready();
extern "C" unsigned RFGRVR_HeadCam_HeadSamples();
extern "C" bool RFGRVR_HeadCam_Recent();
extern "C" bool RFGRVR_HeadCam_MenuScene();
extern "C" bool RFGRVR_HeadCam_PopupMenu();
#include "vr_gameplay_signal.h"
extern "C" unsigned RFGRVR_HeadCam_PlayerState();
extern "C" void RFGRVR_HeadCam_Enable(bool);
extern "C" void RFGRVR_HeadCam_AdjustEye(int,int);
extern "C" void RFGRVR_HeadCam_AdjustFootEye(int,int);
extern "C" void RFGRVR_HeadCam_AdjustWorld(int);
extern "C" void RFGRVR_AdjustWeapon(unsigned,bool,int,bool);
extern "C" void RFGRVR_WeaponEditTarget(bool);
extern "C" void RFGRVR_CaptureSupport();
extern "C" void RFGRVR_CaptureMagazineGrip();
extern "C" void RFGRVR_CapturePrimary();
extern "C" unsigned RFGRVR_WeaponSetupInput(bool);
extern "C" void RFGRVR_ToggleVehicleMenu();
extern "C" bool RFGRVR_PollVehicleMenu(bool);
extern "C" void RFGRVR_CaptureRocketReload();
extern "C" void RFGRVR_WeaponDirection(int);
static HMODULE systemDll=nullptr;
static volatile LONG gLegacyLook=0;
extern "C" bool RFGRVR_LegacyLook_Enabled(){return InterlockedCompareExchange(&gLegacyLook,0,0)!=0;}
static HMODULE selfDll=nullptr;
static HANDLE mapping=nullptr;
static RFGRShared* shared=nullptr;
extern "C" bool RFGRVR_GameplayProjection_Enabled(){
    return shared && shared->version==RFGR_PROTOCOL && (shared->gameplayActive||RFGRVR_HeadCam_MenuScene()||RFGRVR_HeadCam_PopupMenu()) && !shared->theaterMode;
}
static HANDLE workerHandle=nullptr;
static void log(const char* value){
    char path[MAX_PATH]={}; if(!selfDll||!GetModuleFileNameA(selfDll,path,MAX_PATH))return;
    char* slash=strrchr(path,'\\'); if(!slash)return;
    strcpy_s(slash+1, MAX_PATH-(slash+1-path), "RFGRVR-v0.9-game.log");
    FILE* f=nullptr; if(fopen_s(&f,path,"a")==0 && f){fprintf(f,"%s\n",value);fclose(f);}
}
static HMODULE realDll(){
    if(systemDll)return systemDll;
    wchar_t path[MAX_PATH]={}; GetSystemDirectoryW(path,MAX_PATH);
    wcscat_s(path,L"\\dinput8.dll"); systemDll=LoadLibraryW(path);return systemDll;
}
template<class T> static T lookup(const char* name){HMODULE h=realDll(); return h?reinterpret_cast<T>(GetProcAddress(h,name)):nullptr;}
// Compatibility input adapter, opt-in with F8. Uses foreground mouse input.
// Maps headset orientation changes to ordinary Windows mouse deltas when the game is foreground.
// This is NOT stereoscopic VR and does not change the player's camera position.
static constexpr float RAD_TO_DEG = 57.295779513f;
static constexpr float PIXELS_PER_DEGREE = 5.0f;
static float wrapDegrees(float a){while(a>180.f)a-=360.f;while(a < -180.f)a+=360.f;return a;}
static float clampFloat(float v,float lo,float hi){return v<lo?lo:(v>hi?hi:v);}
static void headAngles(const RFGRPose& p,float& yaw,float& pitch){
    const float x=p.orientation[0],y=p.orientation[1],z=p.orientation[2],w=p.orientation[3];
    yaw=std::atan2(2.f*(w*y+x*z),1.f-2.f*(y*y+z*z))*RAD_TO_DEG;
    pitch=std::asin(clampFloat(2.f*(w*x-y*z),-1.f,1.f))*RAD_TO_DEG;
}
static bool gameIsForeground(){
    HWND window=GetForegroundWindow(); if(!window)return false;
    DWORD pid=0;GetWindowThreadProcessId(window,&pid);
    return pid==GetCurrentProcessId();
}
struct CameraInputState {
    bool enabled=false;
    bool haveReference=false;
    float lastYaw=0.f,lastPitch=0.f;
    float fractionX=0.f,fractionY=0.f;
    LONG previousSamples=0;
    LONG previousBridgeHeartbeat=0;
    ULONGLONG lastBridgeChange=0;
    ULONGLONG lastFreshPose=0;
    bool wasF8=false,wasF9=false,wasF10=false,wasF11=false;
    float yawSign=-1.f, pitchSign=-1.f;
    float pixelsPerDegree=PIXELS_PER_DEGREE;
    bool wasDecrease=false,wasIncrease=false;
};
static void gainSettingsPath(char (&path)[MAX_PATH]){
    path[0]=0;
    if(!selfDll||!GetModuleFileNameA(selfDll,path,MAX_PATH))return;
    char* slash=strrchr(path,'\\');if(!slash){path[0]=0;return;}
    strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-headlook.ini");
}
static void loadHeadLookGain(CameraInputState& state){
    char path[MAX_PATH]={},value[64]={};gainSettingsPath(path);if(!path[0])return;
    GetPrivateProfileStringA("HeadLook","CountsPerDegree","5.0",value,sizeof(value),path);
    float gain=0.f;
    if(sscanf_s(value,"%f",&gain)==1&&std::isfinite(gain)&&gain>=.1f&&gain<=100.f)state.pixelsPerDegree=gain;
}
extern "C" void RFGRVR_VehicleCalibrationKey(bool);
extern "C" bool RFGRVR_APC_Input(const RFGRShared*,bool,bool);
static void pumpCameraInput(CameraInputState& state,const RFGRShared* data,const RFGRPose& h,LONG sample,LONG hb){
    if(RFGRVR_HeadCam_MenuScene()){state.haveReference=false;state.fractionX=state.fractionY=0.f;return;}
    // Saved placements are final: no gameplay edit/test hotkeys remain.
    RFGRVR_APC_Input(data,false,false);
    // Temporal stereo must not also apply native XR orientation when it is active.
    // User can toggle F8 off to re-enable experimental native matrix rotation.
    if(!state.enabled)return;
    if(!data || !data->gameplayActive || data->theaterMode){state.haveReference=false;state.fractionX=state.fractionY=0.f;return;}
    if(!gameIsForeground()){state.haveReference=false;return;}
    const ULONGLONG now=GetTickCount64();
    if(hb!=state.previousBridgeHeartbeat){state.previousBridgeHeartbeat=hb;state.lastBridgeChange=now;}
    if(sample!=state.previousSamples){state.previousSamples=sample;state.lastFreshPose=now;}
    // Disable motion on missing/paused bridge, stale poses, or invalid orientation.
    if(!data || data->magic!=RFGR_MAGIC || data->version!=RFGR_PROTOCOL ||
       sample<=0 || (h.validFlags&1)==0 || (now-state.lastBridgeChange)>2500 ||
       (now-state.lastFreshPose)>250 || now<state.lastFreshPose){state.haveReference=false;return;}
    float yaw=0.f,pitch=0.f; headAngles(h,yaw,pitch);
    if(!std::isfinite(yaw)||!std::isfinite(pitch)){state.haveReference=false;return;}
    if(!state.haveReference){state.lastYaw=yaw;state.lastPitch=pitch;state.fractionX=state.fractionY=0.f;state.haveReference=true;return;}
    const float yawDelta=wrapDegrees(yaw-state.lastYaw),pitchDelta=pitch-state.lastPitch;
    state.lastYaw=yaw;state.lastPitch=pitch;
    // Reject tracking jumps without clipping ordinary fast turns and losing motion.
    if(std::fabs(yawDelta)>45.f||std::fabs(pitchDelta)>45.f){state.fractionX=state.fractionY=0.f;return;}
    float dx=yawDelta*state.pixelsPerDegree*state.yawSign+state.fractionX;
    float dy=pitchDelta*state.pixelsPerDegree*state.pitchSign+state.fractionY;
    LONG mx=static_cast<LONG>(std::round(dx)); LONG my=static_cast<LONG>(std::round(dy));
    state.fractionX=dx-mx;state.fractionY=dy-my;
    if(mx==0 && my==0)return;
    INPUT input={};input.type=INPUT_MOUSE;input.mi.dx=mx;input.mi.dy=my;input.mi.dwFlags=MOUSEEVENTF_MOVE;
    SendInput(1,&input,sizeof(input));
}

// Camera research from RSL-master/RSL/CameraManager.cpp and RFGR_Types_Player.h.
// Legacy RSL uses [rfg.exe base + 0x0023394C] for its rfg_camera pointer.
// This may NOT match the Steam Re-Mars-tered executable; telemetry is opt-in,
// disabled unless the exact uploaded executable hash matches, and READ-ONLY.
// Offset layout is derived from RSL vector (3 floats) and matrix (3 vectors).
namespace CameraObserver {
static constexpr uintptr_t LEGACY_CAMERA_PTR_RVA = 0x0023394C;
static const char* EXPECTED_EXE_SHA256 = "0d52039e7f2d3f25a4be52a2aba83919456fb3f00e52e75051726247471a2df4";
struct CameraPrefix {
    int32_t mode, modeStack[8], modeStackSize, levelMode;
    float realPos[3], idealPos[3], lastPos[3];
    float realOrient[9];
};
static bool validRead(const void* ptr, size_t bytes) {
    MEMORY_BASIC_INFORMATION m={};
    if(!VirtualQuery(ptr,&m,sizeof(m)) || m.State!=MEM_COMMIT) return false;
    DWORD prot=m.Protect & 0xff;
    if(prot==PAGE_NOACCESS || prot==PAGE_GUARD || m.Protect & PAGE_GUARD) return false;
    uintptr_t a=(uintptr_t)ptr, end=a+bytes;
    return end>=a && end<=(uintptr_t)m.BaseAddress+m.RegionSize;
}
static bool readSafe(const void* addr,void* out,size_t bytes) {
    if(!validRead(addr,bytes))return false;
    SIZE_T got=0;
    return ReadProcessMemory(GetCurrentProcess(),addr,out,bytes,&got) && got==bytes;
}
// No dynamic CryptoAPI dependency: compute exe SHA in the launcher and store a
// verifier in a small text file instead; never blindly trust legacy addresses.
static bool verifiedExe() {
    char exe[MAX_PATH]={}; if(!GetModuleFileNameA(nullptr,exe,MAX_PATH))return false;
    // Explicit per-build attestation file. The manager deliberately does not
    // create this automatically: legacy offsets need independent validation.
    char guard[MAX_PATH]={}; if(!GetModuleFileNameA(selfDll,guard,MAX_PATH))return false;
    char* slash=strrchr(guard,'\\');if(!slash)return false;
    strcpy_s(slash+1,MAX_PATH-(slash+1-guard),"RFGRVR-camera-address-approved.txt");
    FILE* f=nullptr;if(fopen_s(&f,guard,"rb")!=0 || !f)return false;
    char hash[128]={};fgets(hash,sizeof(hash),f);fclose(f);
    // File is NOT shipped by default. A matching hash alone doesn't establish
    // that the old RSL camera address is valid; hence this stays off.
    (void)exe;(void)hash;
    return false;
}
static void sample() {
    if(!verifiedExe()) { log("Camera direct-access unavailable: RSL address not validated for this remaster. No reads/writes performed.");return; }
    HMODULE base=GetModuleHandleA(nullptr);uintptr_t camPtr=0;
    if(!readSafe((char*)base+LEGACY_CAMERA_PTR_RVA,&camPtr,sizeof(uint32_t)) || !camPtr){log("Camera pointer unreadable.");return;}
    CameraPrefix c={};if(!readSafe((void*)camPtr,&c,sizeof(c))){log("Camera data unreadable.");return;}
    char msg[256];sprintf_s(msg,"camera pos %.3f %.3f %.3f",c.realPos[0],c.realPos[1],c.realPos[2]);log(msg);
}
}

struct VRMenuInput {
 LONG lastSelect=0,lastBack=0,lastX=0,lastY=0;WORD navKey=0;ULONGLONG releaseAt=0,nextNav=0;
 ULONGLONG lastPress=0;
 void key(WORD code,bool down){
  if(!gameIsForeground())return;
  INPUT i{};i.type=INPUT_KEYBOARD;i.ki.wVk=code;
  if(!down)i.ki.dwFlags=KEYEVENTF_KEYUP;
  SendInput(1,&i,sizeof(i));
 }
 void update(const RFGRShared* data,bool fresh){
  LONG sel=fresh?data->menuSelect:0,back=fresh?data->menuBack:0;
  LONG x=fresh?data->menuNavX:0,y=fresh?data->menuNavY:0;
  if(!gameIsForeground()){lastSelect=sel;lastBack=back;lastX=x;lastY=y;return;}
  if(sel!=lastSelect)key(VK_RETURN,sel!=0);
  if(back!=lastBack)key(VK_ESCAPE,back!=0);
  const ULONGLONG now=GetTickCount64();if(navKey&&now>=releaseAt){key(navKey,false);navKey=0;}
  WORD desired=y?(y>0?VK_UP:VK_DOWN):x?(x>0?VK_RIGHT:VK_LEFT):0;
  if(!desired)nextNav=0;
  if(desired&&!navKey&&now>=nextNav){key(desired,true);navKey=desired;releaseAt=now+70;nextNav=now+220;}
  lastSelect=sel;lastBack=back;lastX=x;lastY=y;
 }
};

// Native publisher is linked into the game's existing x86 proxy DLL.
// This entry must be called from a VERIFIED game render-thread callback with
// the game's live IDXGISwapChain. Never call from the input worker or DllMain.
// Kept opt-in: the older RSL raw addresses were not verified for this binary.
namespace RFGRNativeFrames {
    static GameFramePublisher publisher;
    static volatile LONG callbackCalls=0;
    static volatile LONG publisherFailures=0;
    static volatile LONG lastFailure=0;
    static volatile LONG busy=0;
}
extern "C" __declspec(dllexport) BOOL __stdcall RFGRVR_OnGameRenderFrame(IDXGISwapChain* liveSwapChain) {
    if (!liveSwapChain || GetCurrentProcessId()==0) return FALSE;
    // Avoid reentrancy; never block the game's render thread.
    if (InterlockedCompareExchange(&RFGRNativeFrames::busy,1,0)!=0) return FALSE;
    InterlockedIncrement(&RFGRNativeFrames::callbackCalls);
    // Stereo already owns both gameplay images. Keep mono capture available
    // for menus/fallback, without exporting a third 4K image every game frame.
    const bool ok=RFGRVR_NativePair_ViewActive()||RFGRNativeFrames::publisher.PublishFrame(liveSwapChain);
    if (!ok) {
        InterlockedIncrement(&RFGRNativeFrames::publisherFailures);
        InterlockedExchange(&RFGRNativeFrames::lastFailure,
            static_cast<LONG>(RFGRNativeFrames::publisher.LastError()));
    }
    InterlockedExchange(&RFGRNativeFrames::busy,0);
    return ok ? TRUE : FALSE;
}
extern "C" __declspec(dllexport) void __stdcall RFGRVR_GetPublisherCounters(
    LONG* callbacks,LONG* published,LONG* failures,LONG* lastError) {
    if(callbacks) *callbacks=RFGRNativeFrames::callbackCalls;
    if(published) *published=static_cast<LONG>(RFGRNativeFrames::publisher.PublishedFrames());
    if(failures) *failures=RFGRNativeFrames::publisherFailures;
    if(lastError) *lastError=RFGRNativeFrames::lastFailure;
}

extern "C" bool RFGRVR_StartRSLCameraInspector();
extern "C" BOOL __stdcall RFGRVR_AttachRenderer();
extern "C" void __stdcall RFGRVR_GetRenderHookStats(LONG*,LONG*,LONG*,LONG*);
static void captureDiagnosticZip(){
    wchar_t exe[MAX_PATH]={}; if(!selfDll||!GetModuleFileNameW(selfDll,exe,MAX_PATH))return;
    wchar_t* slash=wcsrchr(exe,L'\\');if(!slash)return;*slash=0;
    wchar_t script[MAX_PATH]={};swprintf_s(script,L"%s\\RFGRVR-COLLECT.ps1",exe);
    if(GetFileAttributesW(script)==INVALID_FILE_ATTRIBUTES){log("Backtick: RFGRVR-COLLECT.ps1 missing");return;}
    wchar_t cmd[2048]={};swprintf_s(cmd,L"powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"%s\" -GameFolder \"%s\"",script,exe);
    // PowerShell handles archive creation outside the game's address space.
    STARTUPINFOW si{};si.cb=sizeof(si);PROCESS_INFORMATION pi{};
    if(CreateProcessW(nullptr,cmd,nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,exe,&si,&pi)){
      CloseHandle(pi.hThread);CloseHandle(pi.hProcess);log("Backtick: diagnostic collection started");
    }else log("Backtick: diagnostic collector launch failed");
}
static DWORD WINAPI worker(LPVOID){
    if(!RFGRVR_IsVRLaunch())return 0;
    log("RFGR-VR native publisher linked. Game-frame callback not yet attached; camera engine writes disabled.");
    // Capture graphics startup before potentially expensive skeleton/physics setup.
    log(RFGRVR_AttachRenderer()?"Render callback IAT observer installed.":"Render callback observer unavailable; no renderer patch made.");
    CameraObserver::sample();
    log(RFGRVR_StartRSLCameraInspector()?"RSL camera render_begin hook installed (read-only).":"RSL camera inspector unavailable: signature or hook initialization failed.");
    log(RFGRVR_Arms_Install()?"Controller arm hooks installed (awaiting skeleton preflight).":"Controller arm hooks unavailable.");
    log(RFGRVR_NativeScene_Install()?"Native dual-scene wrapper installed; awaiting tracked gameplay.":"Native dual-scene wrapper unavailable; retaining temporal path.");
    mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRShared),RFGR_MAP_NAME);
    if(mapping){shared=(RFGRShared*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRShared));}
    if(shared){
        if(shared->magic!=RFGR_MAGIC || shared->version!=RFGR_PROTOCOL){ZeroMemory(shared,sizeof(*shared));shared->magic=RFGR_MAGIC;shared->version=RFGR_PROTOCOL;}
        InterlockedExchange(&shared->gamePid,(LONG)GetCurrentProcessId());
        log(RFGRVR_Gamepad_Install(shared)?"VR gamepad input installed.":"VR gamepad input unavailable.");
        CameraInputState camera;VRMenuInput vrMenu;
        loadHeadLookGain(camera);
        char gainLine[128];sprintf_s(gainLine,"Startup head-look gain: %.4f counts per degree",camera.pixelsPerDegree);log(gainLine);
        InterlockedExchange(&gLegacyLook,0);
        log("VR camera-input correction: native orientation default; F8 enables mouse-look fallback.");
        LONG menuLastHeartbeat=0;ULONGLONG menuLastHeartbeatChange=GetTickCount64();
        camera.lastBridgeChange=GetTickCount64();camera.lastFreshPose=GetTickCount64();
        ULONGLONG lastHeartbeat=GetTickCount64(),lastLog=GetTickCount64();
        bool backtickWasDown=false;
        bool initialHeadActivation=false;RFGRVRGameplaySignal gameplaySignal;
        for(;;){
            if(shared->magic!=RFGR_MAGIC)break;
            const bool backtickDown=(GetAsyncKeyState(VK_OEM_3)&0x8000)!=0;
            if(backtickDown&&!backtickWasDown&&gameIsForeground())captureDiagnosticZip();
            backtickWasDown=backtickDown;
            ULONGLONG now=GetTickCount64();
            InterlockedExchange(&shared->gameplayActive,gameplaySignal.update(RFGRVR_HeadCam_Recent()&&!RFGRVR_HeadCam_MenuScene(),now)?1:0);
            InterlockedExchange(&shared->playerParentState,RFGRVR_HeadCam_MenuScene()?0x101:RFGRVR_HeadCam_PopupMenu()?0x102:(LONG)RFGRVR_HeadCam_PlayerState());
            RFGRVRMenuLayout::active.store(shared->playerParentState==0x101,std::memory_order_relaxed);RFGRVRMenuLayout::popupActive.store(shared->playerParentState==0x102,std::memory_order_relaxed);if(now-lastHeartbeat>=1000){InterlockedIncrement(&shared->gameHeartbeat);lastHeartbeat=now;}
            RFGRPose h={},l={},r={}; LONG sample=0,hb=0;bool consistent=false;
            if(shared->version==RFGR_PROTOCOL){
                LONG a=shared->poseSequence;
                if(!(a&1)){
                    MemoryBarrier();h=shared->hmd;l=shared->left;r=shared->right;
                    sample=shared->poseSamples;hb=shared->bridgeHeartbeat;MemoryBarrier();
                    LONG b=shared->poseSequence;
                    consistent=(a==b);
                }
            }
            if(consistent){
                // Enable the existing first-person head anchor automatically once the
                // active VR bridge has delivered tracked head pose. Avoid enabling
                // it merely because the DLL loaded outside an XR session.
                if(!initialHeadActivation && hb>0 && (h.validFlags&3)==3 && RFGRVR_HeadCam_Ready()){
                    RFGRVR_HeadCam_Enable(true);
                    initialHeadActivation=true;
                    log("VR defaults: head camera enabled after tracked XR pose received.");
                }
                pumpCameraInput(camera,shared,h,sample,hb);
                if(hb!=menuLastHeartbeat){menuLastHeartbeat=hb;menuLastHeartbeatChange=GetTickCount64();}
                const bool fresh=(hb>0 && (GetTickCount64()-menuLastHeartbeatChange)<2000);
                vrMenu.update(shared,fresh&&!(RFGRVR_Gamepad_Installed()&&shared->gamepadActive));}
            else {camera.haveReference=false;}
            if(now-lastLog>=5000 && shared->version==RFGR_PROTOCOL){
                LONG begin=shared->stereoSequence;
                RFGREye eyeCopy[2]{};LONG good=0, seq=0;
                if(!(begin&1)){
                    MemoryBarrier();
                    eyeCopy[0]=shared->eyes[0];eyeCopy[1]=shared->eyes[1];
                    good=shared->stereoValid;
                    MemoryBarrier();seq=shared->stereoSequence;
                    if(begin==seq && good){
                        char msg[260];
                        sprintf_s(msg,"XR eyes valid: L=(%.3f %.3f %.3f) R=(%.3f %.3f %.3f) IPD=%.4fm FOV-left=(%.2f %.2f %.2f %.2f)",
                         eyeCopy[0].pose.position[0],eyeCopy[0].pose.position[1],eyeCopy[0].pose.position[2],
                         eyeCopy[1].pose.position[0],eyeCopy[1].pose.position[1],eyeCopy[1].pose.position[2],
                         std::sqrt(std::pow(eyeCopy[0].pose.position[0]-eyeCopy[1].pose.position[0],2.f)+
                                   std::pow(eyeCopy[0].pose.position[1]-eyeCopy[1].pose.position[1],2.f)+
                                   std::pow(eyeCopy[0].pose.position[2]-eyeCopy[1].pose.position[2],2.f)),
                         eyeCopy[0].fov[0],eyeCopy[0].fov[1],eyeCopy[0].fov[2],eyeCopy[0].fov[3]);
                        log(msg);
                    }
                }
            }
            if(now-lastLog>=5000){
                char pubLine[192];
                sprintf_s(pubLine,"Frame publisher callback=%ld published=%lu failures=%ld last=0x%08lX",
                    RFGRNativeFrames::callbackCalls,RFGRNativeFrames::publisher.PublishedFrames(),
                    RFGRNativeFrames::publisherFailures,(unsigned long)RFGRNativeFrames::lastFailure);
                log(pubLine);
                LONG f=0,c=0,p=0,e=0; RFGRVR_GetRenderHookStats(&f,&c,&p,&e);
                char hookLine[180];sprintf_s(hookLine,"Render hook factories=%ld swapchains=%ld presents=%ld errors=%ld",f,c,p,e);log(hookLine);
                char line[320];
                sprintf_s(line,"samples=%ld HMD=%u xyz=%.3f %.3f %.3f left=%u/%u right=%u/%u bridgePid=%ld camera=%s",sample,h.validFlags,h.position[0],h.position[1],h.position[2],l.validFlags,l.active,r.validFlags,r.active,shared->bridgePid,camera.enabled?"ON":"OFF");
                log(line);
                char vrState[200]; sprintf_s(vrState,"VR head mode=%d temporal stereo=%d legacy look=%d head samples=%u gameplay=%ld theater=%ld gain=%.4f", RFGRVR_HeadCam_Enabled()?1:0, RFGRVR_Temporal_IsEnabled()?1:0, RFGRVR_LegacyLook_Enabled()?1:0, RFGRVR_HeadCam_HeadSamples(),shared->gameplayActive,shared->theaterMode,camera.pixelsPerDegree); log(vrState);
                lastLog=now;
            }
            Sleep(16);
        }
    } else log("WARN: named IPC mapping unavailable.");
    // Avoid unmapping while a companion may still be reading; Windows releases it on exit.
    return 0;
}
extern "C" HRESULT WINAPI Proxy_DirectInput8Create(HINSTANCE a,DWORD b,REFIID c,LPVOID* d,LPUNKNOWN e){
    auto f=lookup<HRESULT(WINAPI*)(HINSTANCE,DWORD,REFIID,LPVOID*,LPUNKNOWN)>("DirectInput8Create");return f?f(a,b,c,d,e):E_FAIL;
}
extern "C" HRESULT WINAPI Proxy_DllCanUnloadNow(){auto f=lookup<HRESULT(WINAPI*)()>("DllCanUnloadNow");return f?f():S_FALSE;}
extern "C" HRESULT WINAPI Proxy_DllGetClassObject(REFCLSID a,REFIID b,LPVOID* c){auto f=lookup<HRESULT(WINAPI*)(REFCLSID,REFIID,LPVOID*)>("DllGetClassObject");return f?f(a,b,c):CLASS_E_CLASSNOTAVAILABLE;}
extern "C" HRESULT WINAPI Proxy_DllRegisterServer(){auto f=lookup<HRESULT(WINAPI*)()>("DllRegisterServer");return f?f():E_NOTIMPL;}
extern "C" HRESULT WINAPI Proxy_DllUnregisterServer(){auto f=lookup<HRESULT(WINAPI*)()>("DllUnregisterServer");return f?f():E_NOTIMPL;}
BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,LPVOID){
    if(reason==DLL_PROCESS_ATTACH){selfDll=h;DisableThreadLibraryCalls(h);if(!RFGRVR_IsVRLaunch())return TRUE; workerHandle=CreateThread(nullptr,0,worker,nullptr,0,nullptr);if(workerHandle)CloseHandle(workerHandle);}
    return TRUE;
}



