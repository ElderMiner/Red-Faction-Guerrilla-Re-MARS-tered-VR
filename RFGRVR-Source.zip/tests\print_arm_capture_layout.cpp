#include "../src/native_arms.cpp"
#include <cstddef>
extern "C" bool RFGRVR_HeadCam_Enabled(){return true;}
extern "C" float RFGRVR_HeadCam_WorldScale(){return 1;}
extern "C" void RFGRVR_HeadCam_AvatarEye(void*,const float[3]){}
int main(){printf("{\"sharedSize\":%zu,\"leftAim\":%zu,\"rightAim\":%zu,\"commandSize\":%zu,\"root\":%zu,\"pose\":%zu,\"tick\":%zu,\"handsSize\":%zu}\n",sizeof(RFGRShared),offsetof(RFGRShared,leftAim),offsetof(RFGRShared,rightAim),sizeof(ArmCommand),offsetof(ArmCommand,root),offsetof(ArmCommand,pose),offsetof(ArmCommand,tick),sizeof(Hands));}
