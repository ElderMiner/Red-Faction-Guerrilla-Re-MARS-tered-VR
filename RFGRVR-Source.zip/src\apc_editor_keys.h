#pragma once
#include <cstdint>
// Windows may expose Shift+numpad as navigation keys and temporarily lift Shift.
// Keep the chord alive across that translation, without changing normal Home/etc.
struct RFGRAPCSelectionKeys {
 bool shiftSeen=false,chord=false;uint64_t releaseAt=0;bool blocked[4]{};
 void reset(){*this={};}
 int update(bool shift,const bool digits[4],const bool navigation[4],uint64_t now){
  int event=-2;
  if(shift){shiftSeen=true;releaseAt=0;}
  else if(shiftSeen&&!releaseAt)releaseAt=now;
  bool translated=false;
  for(unsigned i=0;i<4;++i){
   bool pressed=digits[i]||navigation[i];
   if(!pressed)blocked[i]=false;
   if(shiftSeen&&pressed&&(shift||chord||now-releaseAt<150)){
    if(!blocked[i])event=int(i);
    chord=true;blocked[i]=true;translated=true;
   }
  }
  if(shiftSeen&&!shift&&!translated&&releaseAt&&now-releaseAt>=150){
   if(!chord)event=-1;
   shiftSeen=false;chord=false;releaseAt=0;
  }
  return event;
 }
};
