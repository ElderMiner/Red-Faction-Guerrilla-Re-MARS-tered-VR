#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../src/vr_effect_geometry.h"
using namespace RFGRVREffectGeometry;
static void put(void* p,unsigned offset,unsigned v){memcpy((char*)p+offset,&v,4);}
int main(){unsigned char object[0xd0]{};unsigned geometry[32]{};unsigned storage=(unsigned)(uintptr_t)geometry;put(object,0xcc,123);for(unsigned o:{0x40u,0x58u}){put(object,o-8,storage);put(object,o-4,8);put(object,o,7);}select(0);assert(!prepare(object));assert(usedCount==1);prepare(object);assert(usedCount==1);put(object,0x40,0);put(object,0x58,0);select(1);assert(restores==1);assert(!prepare(object));assert(word(object,0x40)==7&&word(object,0x58)==7);put(object,0x40,0);put(object,0x58,0);assert(!prepare(object)&&!word(object,0x40));select(1);assert(word(object,0x40)==7);put(object,0x40,0);select(1);assert(word(object,0x40)==7);put(object,0x40,0);select(0);assert(!prepare(object));select(1);assert(!word(object,0x40));assert(!prepare(object));select(0);put(object,0x40,7);prepare(object);put(object,0x40,0);put(object,0xcc,456);select(1);assert(!prepare(object)&&!word(object,0x40));put(object,0xcc,123);select(0);put(object,0x40,7);prepare(object);put(object,0x40,0);put(object,0x3c,2);select(1);assert(!prepare(object)&&!word(object,0x40));eye=-1;assert(!prepare(nullptr));}
