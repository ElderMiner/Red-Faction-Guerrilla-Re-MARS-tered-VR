#pragma once
#include "wrist_map_render.h"
namespace RFGRVRWristMapTrace {inline bool install(){return RFGRVRWorldHud::install();}}
extern "C" void RFGRVR_WristMap_Present(IDXGISwapChain* swap){RFGRVRWorldHud::present(swap);}

extern "C" void RFGRVR_WristMap_EndCommandList(ID3D11DeviceContext* context){RFGRVRWorldHud::endCommandList(context);}

#include "vr_desktop_menu.h"
extern "C" void RFGRVR_DesktopMenu(IDXGISwapChain* swap){
 if(!swap||!RFGRVR_HeadCam_PopupMenu()||!vrsettings::get().value[vrsettings::Desktop])return;
 using namespace RFGRVRMainUI;static RFGRVRDesktopMenu overlay;AcquireSRWLockShared(&gpuLock);
 if(canvas&&owner&&drawnEpoch){Microsoft::WRL::ComPtr<ID3D11Texture2D> back;Microsoft::WRL::ComPtr<ID3D11DeviceContext> context;owner->GetImmediateContext(&context);if(SUCCEEDED(swap->GetBuffer(0,IID_PPV_ARGS(&back))))overlay.draw(owner.Get(),context.Get(),back.Get(),canvas.Get());}
 ReleaseSRWLockShared(&gpuLock);
}

#include "vr_map_panel.h"
// Native terrain and VINT icons are separate renderers; merge before rebuilding the world.
extern "C" bool RFGRVR_CaptureMapPanel(IDXGISwapChain* swap){
 using namespace RFGRVRMainUI;if(!swap)return false;AcquireSRWLockExclusive(&gpuLock);bool ok=false;
 if(canvas&&owner&&drawnEpoch){static RFGRVRMapPanel map;Microsoft::WRL::ComPtr<ID3D11DeviceContext> context;Microsoft::WRL::ComPtr<ID3D11Texture2D> back;owner->GetImmediateContext(&context);if(SUCCEEDED(swap->GetBuffer(0,IID_PPV_ARGS(&back)))){ok=map.compose(owner.Get(),context.Get(),back.Get(),canvas.Get(),target.Get());if(ok)publishedEpoch=0;}}
 ReleaseSRWLockExclusive(&gpuLock);return ok;
}
