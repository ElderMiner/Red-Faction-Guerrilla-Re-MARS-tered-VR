#pragma once
#include "vr_mapping.h"
#include <windows.h>
#include <cstring>
static constexpr wchar_t RFGR_RELOAD_CUE[]=L"Local\\RFGRVR_ReloadCue_v1";
struct RFGRReloadCue {unsigned magic=0x4d414731;volatile LONG sequence=0;DWORD pid=0,tick=0;unsigned active=0;float center[3]{},radius=.05f;};
inline void RFGRVR_PublishReloadCue(RFGRReloadCue value){static HANDLE map=nullptr;static RFGRReloadCue* view=nullptr;if(!view){if(!map)map=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(value),RFGR_RELOAD_CUE);if(map)view=(RFGRReloadCue*)RFGRVR_MapViewOrClose(map,FILE_MAP_ALL_ACCESS,0,0,sizeof(value));}if(!view)return;value.pid=GetCurrentProcessId();value.tick=GetTickCount();InterlockedIncrement(&view->sequence);MemoryBarrier();memcpy(&view->pid,&value.pid,sizeof(value)-offsetof(RFGRReloadCue,pid));view->magic=value.magic;MemoryBarrier();InterlockedIncrement(&view->sequence);}
struct ReloadCueReader{HANDLE map=nullptr;RFGRReloadCue* view=nullptr;~ReloadCueReader(){if(view)UnmapViewOfFile(view);if(map)CloseHandle(map);}bool read(RFGRReloadCue& out,DWORD pid){if(!view){if(!map)map=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_RELOAD_CUE);if(map)view=(RFGRReloadCue*)RFGRVR_MapViewOrClose(map,FILE_MAP_READ,0,0,sizeof(out));}if(!view)return false;for(unsigned i=0;i<3;++i){LONG seq=view->sequence;if(seq&1)continue;MemoryBarrier();memcpy(&out,view,sizeof(out));MemoryBarrier();if(seq==view->sequence)return out.magic==0x4d414731&&out.pid==pid&&DWORD(GetTickCount()-out.tick)<200&&out.active;}return false;}};
