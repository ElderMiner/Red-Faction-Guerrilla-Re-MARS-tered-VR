#include "../src/wrist_map_pose.h"
#include <cassert>
#include <initializer_list>
int main(){RFGRPose head{},left{},right{},out{};for(auto* p:{&head,&left,&right}){p->active=1;p->validFlags=3;p->orientation[3]=1;}
 left.position[0]=-.2f;right.position[0]=.2f;left.position[1]=right.position[1]=1.1f;left.position[2]=right.position[2]=-.4f;
 assert(RFGRVR_VehicleMapPose(head,left,right,out));assert(fabsf(out.position[0])<.00001f&&fabsf(out.position[1]-.98f)<.00001f&&out.position[2]==-.4f);
 assert(out.orientation[0]==-.5f&&fabsf(out.orientation[3]-.8660254f)<.00001f);
 RFGRPose before=out;head.orientation[1]=sqrtf(.5f);head.orientation[3]=sqrtf(.5f);assert(RFGRVR_VehicleMapPose(head,left,right,out));
 for(int i=0;i<4;++i)assert(fabsf(before.orientation[i]-out.orientation[i])<.00001f); // looking around doesn't spin wheel map
 left.active=0;assert(!RFGRVR_VehicleMapPose(head,left,right,out));left.active=1;right.position[0]=NAN;assert(!RFGRVR_VehicleMapPose(head,left,right,out));
}
