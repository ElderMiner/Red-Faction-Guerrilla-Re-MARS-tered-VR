#define NOMINMAX
#include "../src/modern_lighting.h"
#include <cassert>
#include <vector>
using Microsoft::WRL::ComPtr;
static const void* sourceIdentity=nullptr;static ComPtr<ID3DBlob> baseline;static unsigned calls=0;
static HRESULT STDMETHODCALLTYPE nativeCreate(ID3D11Device* d,const void* bytes,SIZE_T count,ID3D11ClassLinkage* linkage,ID3D11PixelShader** shader){++calls;if(bytes==sourceIdentity)return d->CreatePixelShader(baseline->GetBufferPointer(),baseline->GetBufferSize(),nullptr,shader);return d->CreatePixelShader(bytes,count,linkage,shader);}
int main(){ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));const char* ps="float4 main():SV_Target{return float4(.2,.3,.4,1);}";assert(SUCCEEDED(D3DCompile(ps,strlen(ps),nullptr,nullptr,nullptr,"main","ps_4_0",0,0,&baseline,nullptr)));
 auto verify=[&](unsigned size,const unsigned char* hash,bool hdr){std::vector<unsigned char> identity(size);memcpy(identity.data(),"DXBC",4);memcpy(identity.data()+4,hash,16);sourceIdentity=identity.data();calls=0;ComPtr<ID3D11PixelShader> shader;assert(SUCCEEDED(modernlight::create(nativeCreate,d.Get(),identity.data(),identity.size(),nullptr,&shader,true)));assert(shader);if(hdr){assert(calls==2&&modernmaterial::tagged(shader.Get())&&modernlight::originalShader(shader.Get()));}else assert(calls==1&&!modernmaterial::tagged(shader.Get())&&!modernlight::originalShader(shader.Get()));};
 for(auto id:modernlight::identities)verify(id.bytes,id.hash,false);
 for(auto id:moderngenerated::identities)verify(id.bytes,id.hash,false);
 for(auto id:modernsurface::identities)verify(id.bytes,id.hash,false);
 for(auto id:modernglass::identities)verify(id.bytes,id.hash,false);
 for(auto id:modernterrain::identities)verify(id.bytes,id.hash,false);
 for(auto id:modernskymaterial::identities)verify(id.bytes,id.hash,false);
 for(auto id:modernhdr::identities)verify(id.bytes,id.hash,true);
 assert(!modernlight::transportEnabled());assert(modernlight::nativeNightGrading());modernlight::bypass=true;assert(modernlight::nativeNightGrading());modernlight::bypass=false;puts("PASS hybrid production policy: every registered surface/terrain/glass/sky identity passes through native creation exactly once; only HDR identities substitute and retain exact baseline; transport disabled");}
