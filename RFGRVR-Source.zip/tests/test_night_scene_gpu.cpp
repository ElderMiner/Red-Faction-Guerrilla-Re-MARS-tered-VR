#define main RFGR_Unused_Companion_Main
#include "../src/bridge.cpp"
#undef main
#include <cassert>
int main(){using Microsoft::WRL::ComPtr;ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));
 auto make=[&](unsigned size,unsigned bind){D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=size;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R32G32B32A32_FLOAT;td.BindFlags=bind;ComPtr<ID3D11Texture2D> t;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&t)));return t;};
 auto left=make(16,D3D11_BIND_SHADER_RESOURCE),right=make(16,D3D11_BIND_SHADER_RESOURCE),outL=make(16,D3D11_BIND_RENDER_TARGET),outR=make(16,D3D11_BIND_RENDER_TARGET);
 float pixels[16*16*4];auto fill=[&](ID3D11Texture2D* t,bool other){for(int i=0;i<256;++i){float v=other?.2f:float((i%16)/4)/3;pixels[i*4]=v;pixels[i*4+1]=v;pixels[i*4+2]=v;pixels[i*4+3]=.75f;}c->UpdateSubresource(t,0,nullptr,pixels,16*16,0);};fill(left.Get(),false);fill(right.Get(),true);
 auto read=[&](ID3D11Texture2D* t){D3D11_TEXTURE2D_DESC td{};t->GetDesc(&td);td.BindFlags=0;td.Usage=D3D11_USAGE_STAGING;td.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> copy;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&copy)));c->CopyResource(copy.Get(),t);D3D11_MAPPED_SUBRESOURCE m{};assert(SUCCEEDED(c->Map(copy.Get(),0,D3D11_MAP_READ,0,&m)));std::vector<float> values(td.Width*td.Height*4);for(unsigned y=0;y<td.Height;++y)memcpy(values.data()+y*td.Width*4,(char*)m.pData+y*m.RowPitch,td.Width*16);c->Unmap(copy.Get(),0);return values;};
 StereoGpuConsumer source;source.staged.valid=true;source.staged.native=true;source.staged.image[0]=left;source.staged.image[1]=right;for(auto& view:source.staged.views){view.fov={-.5f,.5f,.5f,-.5f};view.pose.orientation.w=1;}
 ID3D11Texture2D* output[2]={outL.Get(),outR.Get()};source.scale.sceneExposure=1;assert(source.renderStaged(c.Get(),output,90));auto baseline=read(outL.Get());source.scale.sceneExposure=.6f;assert(source.renderStaged(c.Get(),output,90));auto graded=read(outL.Get()),other=read(outR.Get());for(unsigned i=0;i<256;++i){assert(fabsf(graded[i*4]-vrnight::expose(baseline[i*4],.6f))<.0001f);assert(fabsf(other[i*4]-vrnight::expose(.2f,.6f))<.0001f);assert(graded[i*4+3]==baseline[i*4+3]);}
 // Desaturate and tint using the production stereo path, then compare pixels.
 source.scale.sceneExposure=1;source.scale.sceneSaturation=0;source.scale.sceneTint[0]=.5f;source.scale.sceneTint[1]=1;source.scale.sceneTint[2]=1.5f;assert(source.renderStaged(c.Get(),output,90));auto colour=read(outR.Get());assert(fabsf(colour[0]-.1f)<.0001f&&fabsf(colour[1]-.2f)<.0001f&&fabsf(colour[2]-.3f)<.0001f);
 // UI/main-menu alpha surfaces must bypass all grading controls.
 source.scale.preserveAlpha=true;assert(source.renderStaged(c.Get(),output,90));auto ui=read(outL.Get());source.scale.sceneExposure=source.scale.sceneSaturation=1;for(float& v:source.scale.sceneTint)v=1;assert(source.renderStaged(c.Get(),output,90));auto normalUI=read(outL.Get());assert(ui==normalUI);
 // Optional FSR applies the same grade in its existing final RCAS pass.
 auto fsrOut=make(32,D3D11_BIND_RENDER_TARGET);vrfsr::Upscaler fsr;float crop[4]={0,0,1,1};assert(fsr.render(d.Get(),c.Get(),right.Get(),fsrOut.Get(),crop,.8f,.6f));auto upscaled=read(fsrOut.Get());for(unsigned i=0;i<32*32;++i)assert(fabsf(upscaled[i*4]-vrnight::expose(.2f,.6f))<.003f);
 float tint[3]={.5f,1,1.5f};assert(fsr.render(d.Get(),c.Get(),right.Get(),fsrOut.Get(),crop,.8f,1,0,tint));auto coloured=read(fsrOut.Get());for(unsigned i=0;i<32*32;++i){assert(fabsf(coloured[i*4]-.1f)<.003f&&fabsf(coloured[i*4+1]-.2f)<.003f&&fabsf(coloured[i*4+2]-.3f)<.003f);}
 puts("PASS real GPU night exposure: both eye sources, complete frame, black/white preservation, alpha, UI bypass and existing FSR final pass");
}

