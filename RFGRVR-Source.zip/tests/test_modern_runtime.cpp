#define NOMINMAX
#include "../src/modern_runtime.h"
#include <cassert>
#include <cstdio>
using Microsoft::WRL::ComPtr;
static void put(void* p,unsigned offset,const void* value){uint32_t bits=uint32_t((uintptr_t)value);memcpy((char*)p+offset,&bits,4);}
int main(){
 float matrix[16]={2,0,0,0,0,3,0,0,0,0,4,0,5,6,7,1},inverse[16];assert(moderncamera::inverse(matrix,inverse));assert(inverse[0]==.5f&&inverse[3]==-2.5f);float singular[16]{};assert(!moderncamera::inverse(singular,inverse));
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,nullptr,&context)));
 D3D11_TEXTURE2D_DESC d{};d.Width=d.Height=32;d.MipLevels=d.ArraySize=d.SampleDesc.Count=1;d.Format=DXGI_FORMAT_R11G11B10_FLOAT;d.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;
 ComPtr<ID3D11Texture2D> hdr;ComPtr<ID3D11RenderTargetView> target;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&hdr)));assert(SUCCEEDED(device->CreateRenderTargetView(hdr.Get(),nullptr,&target)));
 d.Format=DXGI_FORMAT_R32_FLOAT;d.BindFlags=D3D11_BIND_SHADER_RESOURCE;float depth[32*32];for(float& x:depth)x=.5f;D3D11_SUBRESOURCE_DATA data{depth,32*4,32*32*4};ComPtr<ID3D11Texture2D> scene;ComPtr<ID3D11ShaderResourceView> sceneView;assert(SUCCEEDED(device->CreateTexture2D(&d,&data,&scene)));assert(SUCCEEDED(device->CreateShaderResourceView(scene.Get(),nullptr,&sceneView)));
 d.Width=d.Height=4;d.Format=DXGI_FORMAT_R16_TYPELESS;d.BindFlags=D3D11_BIND_DEPTH_STENCIL;ComPtr<ID3D11Texture2D> shadow;ComPtr<ID3D11DepthStencilView> shadowView;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&shadow)));D3D11_DEPTH_STENCIL_VIEW_DESC sd{};sd.Format=DXGI_FORMAT_D16_UNORM;sd.ViewDimension=D3D11_DSV_DIMENSION_TEXTURE2D;assert(SUCCEEDED(device->CreateDepthStencilView(shadow.Get(),&sd,&shadowView)));
 unsigned char sceneRenderer[0x390]{},renderer[0x480]{},camera[0x500]{},rt[0x24]{},shadowRT[0x24]{},textureData[28]{},writer[4]{},commands[4]{};
 put(sceneRenderer,0x220,rt);put(rt,0,target.Get());put(sceneRenderer,0x384,shadowRT);put(shadowRT,0x20,shadowView.Get());put(sceneRenderer,0x2a8,textureData);put(textureData,24,sceneView.Get());put(renderer,0x440,writer);put(writer,0,commands);put(commands,0,context.Get());put(renderer,0x478,camera);
 float identity[16]{};for(unsigned i=0;i<4;++i)identity[i*5]=1;memcpy(camera+0x4c0,identity,64);float eye[3]{};
 modernscene::collector.begin(1);modernscene::Light light;light.colour[0]=light.colour[1]=light.colour[2]=1;assert(modernscene::collector.submit(1,light));
 modernruntime::begin(sceneRenderer,renderer,eye);
 // Same eye, wrong native shadow projection: never meter/composite this pass.
 float shadowCamera[16]{};shadowCamera[0]=.02f;shadowCamera[5]=.03f;shadowCamera[10]=.001f;shadowCamera[15]=1;memcpy(camera+0x4c0,shadowCamera,64);assert(!modernruntime::beforeHDR(renderer,true));assert(!modernruntime::state.drawn&&!modernruntime::state.metered&&modernruntime::nonWorldPasses==1);memcpy(camera+0x4c0,identity,64);
 assert(modernruntime::beforeHDR(renderer,true));assert(modernruntime::state.drawn);modernruntime::end();modernruntime::draws=0;modernruntime::begin(sceneRenderer,renderer,eye);
 float shadowMatrix[16]{};shadowMatrix[0]=shadowMatrix[5]=.5f;shadowMatrix[10]=shadowMatrix[15]=1;shadowMatrix[12]=shadowMatrix[13]=.5f;
 for(unsigned i=0;i<3;++i){context->ClearDepthStencilView(shadowView.Get(),D3D11_CLEAR_DEPTH,1,0);modernruntime::cascade(sceneRenderer,renderer,shadowMatrix,i);}
 const float background[4]={0,0,0,1};context->ClearRenderTargetView(target.Get(),background);
 auto* bound=target.Get();context->OMSetRenderTargets(1,&bound,nullptr);assert(modernruntime::beforeHDR(renderer,true));assert(!modernruntime::beforeHDR(renderer,true));assert(modernruntime::draws==1&&modernruntime::shadowCopies==3);
 ComPtr<ID3D11RenderTargetView> restored;context->OMGetRenderTargets(1,&restored,nullptr);assert(restored.Get()==target.Get());
 D3D11_TEXTURE2D_DESC rd{};hdr->GetDesc(&rd);rd.BindFlags=0;rd.Usage=D3D11_USAGE_STAGING;rd.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> readback;assert(SUCCEEDED(device->CreateTexture2D(&rd,nullptr,&readback)));context->CopyResource(readback.Get(),hdr.Get());D3D11_MAPPED_SUBRESOURCE pixels{};assert(SUCCEEDED(context->Map(readback.Get(),0,D3D11_MAP_READ,0,&pixels)));unsigned packed=0;memcpy(&packed,(char*)pixels.pData+16*pixels.RowPitch+16*4,4);context->Unmap(readback.Get(),0);assert((packed&2047)>0&&((packed>>11)&2047)>0);
 modernruntime::end();assert(!modernruntime::beforeHDR(renderer,true)); // The production default has no verified medium: keep the source image exact.
 modernruntime::begin(sceneRenderer,renderer,eye);context->ClearRenderTargetView(target.Get(),background);auto previousDraws=modernruntime::draws.load();assert(!modernruntime::beforeHDR(renderer));assert(modernruntime::state.drawn&&modernruntime::draws==previousDraws);context->CopyResource(readback.Get(),hdr.Get());assert(SUCCEEDED(context->Map(readback.Get(),0,D3D11_MAP_READ,0,&pixels)));memcpy(&packed,(char*)pixels.pData+16*pixels.RowPitch+16*4,4);context->Unmap(readback.Get(),0);assert(packed==0);modernruntime::end();
 // Actual engine split: shadow work on the primary immediate renderer,
 // HDR on a different renderer recording a deferred command list.
 ComPtr<ID3D11DeviceContext> deferred;assert(SUCCEEDED(device->CreateDeferredContext(0,&deferred)));unsigned char secondary[0x480]{},writer2[4]{},commands2[4]{};put(secondary,0x440,writer2);put(writer2,0,commands2);put(commands2,0,deferred.Get());put(secondary,0x478,camera);
 modernruntime::begin(sceneRenderer,renderer,eye,secondary);for(unsigned i=0;i<3;++i){context->ClearDepthStencilView(shadowView.Get(),D3D11_CLEAR_DEPTH,1,0);modernruntime::cascade(sceneRenderer,renderer,shadowMatrix,i);}context->ClearRenderTargetView(target.Get(),background);deferred->OMSetRenderTargets(1,&bound,nullptr);
 assert(modernruntime::beforeHDR(secondary,true));assert(!modernruntime::beforeHDR(secondary,true));ComPtr<ID3D11RenderTargetView> restoredDeferred;deferred->OMGetRenderTargets(1,&restoredDeferred,nullptr);assert(restoredDeferred.Get()==target.Get());ComPtr<ID3D11CommandList> list;assert(SUCCEEDED(deferred->FinishCommandList(FALSE,&list)));context->ExecuteCommandList(list.Get(),TRUE);
 context->CopyResource(readback.Get(),hdr.Get());assert(SUCCEEDED(context->Map(readback.Get(),0,D3D11_MAP_READ,0,&pixels)));memcpy(&packed,(char*)pixels.pData+16*pixels.RowPitch+16*4,4);context->Unmap(readback.Get(),0);assert((packed&2047)>0&&modernruntime::draws==2);modernruntime::end();
 // Both eyes must use the same source set despite second-eye light uploads.
 modernscene::collector.begin(2);modernruntime::beginPair(renderer,sceneRenderer,2,12,true);light.colour[0]=light.colour[1]=light.colour[2]=.2f;assert(modernscene::collector.submit(1,light));
 auto eyePass=[&](int index){modernruntime::begin(sceneRenderer,renderer,eye,nullptr,index);for(unsigned i=0;i<3;++i){context->ClearDepthStencilView(shadowView.Get(),D3D11_CLEAR_DEPTH,1,0);modernruntime::cascade(sceneRenderer,renderer,shadowMatrix,i);}assert(modernruntime::beforeHDR(renderer,true));modernruntime::end();};
 eyePass(0);light.colour[0]=light.colour[1]=light.colour[2]=4;assert(modernscene::collector.submit(1,light));eyePass(1);assert(modernruntime::state.pairLights.count==1&&modernruntime::state.pairLights.lights[0].colour[0]==.2f);assert(modernruntime::state.eyeDraws[0]==1&&modernruntime::state.eyeDraws[1]==1);
 assert(modernruntime::meterQueued==2&&modernruntime::meterFailed==0);context->Flush();DWORD deadline=GetTickCount()+5000;while(modernruntime::developmentGraph.status().pending&&int(deadline-GetTickCount())>0){modernruntime::developmentGraph.poll();Sleep(1);}assert(modernruntime::developmentGraph.status().meters==2);
 modernruntime::meterPair=false;
 modernscene::collector.begin(3);assert(modernscene::collector.submit(1,light));eyePass(0);assert(modernruntime::state.pairLights.lights[0].colour[0]==4);
 // The same physical local light must produce the same image on either side
 // of a native floating-origin rebase. Camera/depth remain renderer-relative.
 auto pointPass=[&](uint64_t frame,float originX,float originZ){float origin[3]={originX,0,originZ};memcpy(camera+0x80,origin,12);modernscene::collector.begin(frame);modernscene::Light point;point.kind=1;point.range=10;point.position[0]=originX;point.position[2]=originZ+.75f;point.colour[0]=point.colour[1]=point.colour[2]=1;assert(modernscene::collector.submit(7,point));context->ClearRenderTargetView(target.Get(),background);modernruntime::begin(sceneRenderer,renderer,eye);assert(modernruntime::beforeHDR(renderer,true));modernruntime::end();context->CopyResource(readback.Get(),hdr.Get());assert(SUCCEEDED(context->Map(readback.Get(),0,D3D11_MAP_READ,0,&pixels)));unsigned value;memcpy(&value,(char*)pixels.pData+16*pixels.RowPitch+16*4,4);context->Unmap(readback.Get(),0);return value&2047;};auto local=pointPass(10,0,0),rebased=pointPass(11,2048,-1024);assert(local>0&&local==rebased);memset(camera+0x80,0,12);
 float scaled[3]={1,2,3},source[3]{};assert(modernscene::sourceRadiance(scaled,.25f,source)&&source[0]==4&&source[2]==12);assert(modernscene::sourceRadiance(scaled,2,source)&&source[0]==.5f);assert(!modernscene::sourceRadiance(scaled,0,source));assert(!modernscene::sourceRadiance(scaled,NAN,source));
 // A dark/no-source view must still contribute both eyes to metering. Repeat
 // callbacks in the same eye neither allocate another view nor double-submit.
 modernscene::collector.begin(12);modernruntime::beginPair(renderer,sceneRenderer,12,0,true);auto* cachedMeter=modernruntime::meterInput.Get();
 for(int index=0;index<2;++index){modernruntime::begin(sceneRenderer,renderer,eye,nullptr,index);assert(modernruntime::beforeHDR(renderer,true));assert(modernruntime::state.metered);assert(!modernruntime::beforeHDR(renderer,true));assert(modernruntime::meterInput.Get()==cachedMeter);modernruntime::end();}
 assert(modernruntime::meterQueued==4&&modernruntime::meterFailed==0);context->Flush();deadline=GetTickCount()+5000;while(modernruntime::developmentGraph.status().pending&&int(deadline-GetTickCount())>0){modernruntime::developmentGraph.poll();Sleep(1);}assert(modernruntime::developmentGraph.status().meters==4);
 modernruntime::begin(sceneRenderer,renderer,eye);float shifted=1;memcpy(camera+0x74,&shifted,4);assert(!modernruntime::beforeHDR(renderer,true));modernruntime::end();
 puts("PASS: production native wrapper/resource layouts -> three ordered shadow copies -> pre-HDR GPU scattering; per-eye once-only gate, camera rejection, state restoration and end-of-view cleanup");
}

