#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <openxr/openxr.h>
#include <cassert>
#include <vector>
#include <cstdio>
#include "../src/bridge_focus_vignette.h"
#include "../src/bridge_grip_hint.h"
#include "../src/bridge_menu_scene.h"
#include "../src/vr_final_mirror.h"
using Microsoft::WRL::ComPtr;
int main(){
 unsigned w=0,h=0;assert(vrprojection::activeSize(false,3028,3028,4800,5008,&w,&h)&&w==3028&&h==3028);
 assert(vrprojection::activeSize(true,4800,5008,4800,5008,&w,&h)&&w==4800&&h==5008);
 assert(!vrprojection::activeSize(false,6000,6000,4800,5008,&w,&h));
 w=h=3028;assert(!vrprojection::activeSize(true,6000,6000,4800,5008,&w,&h)&&w==3028&&h==3028);
 for(unsigned target:{2422u,3028u,3633u,3028u})assert(vrprojection::activeSize(false,target,target,4800,5008,&w,&h)&&w==target&&h==target);
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,nullptr,&context)));
 D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=128;td.ArraySize=2;td.MipLevels=1;td.Format=DXGI_FORMAT_R8G8B8A8_UNORM;td.SampleDesc.Count=1;td.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;
 ComPtr<ID3D11Texture2D> target;assert(SUCCEEDED(device->CreateTexture2D(&td,nullptr,&target)));std::vector<unsigned> white(128*128,0xffffffff);
 auto clear=[&]{for(unsigned eye=0;eye<2;++eye)context->UpdateSubresource(target.Get(),eye,nullptr,white.data(),128*4,0);};
 auto pixel=[&](unsigned x,unsigned y,unsigned eye=0){auto desc=td;desc.Usage=D3D11_USAGE_STAGING;desc.BindFlags=0;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> read;assert(SUCCEEDED(device->CreateTexture2D(&desc,nullptr,&read)));context->CopyResource(read.Get(),target.Get());D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(context->Map(read.Get(),eye,D3D11_MAP_READ,0,&map)));unsigned value=*(unsigned*)((char*)map.pData+y*map.RowPitch+x*4);context->Unmap(read.Get(),eye);return value;};
 XrFovf fov{-.78539816f,.78539816f,.78539816f,-.78539816f};FocusVignetteRenderer focus;GripHintRenderer grip;RFGRMenuScene menu;XrPosef eye{};eye.orientation.w=1;
 clear();{
  vrprojection::ViewportScope active(64,64);assert(vrprojection::viewport(128,128).Width==64);
  {vrprojection::ViewportScope nested(32,48);assert(vrprojection::viewport(128,128).Height==48);}assert(vrprojection::height==64);
  assert(focus.draw(device.Get(),context.Get(),target.Get(),0,fov,1,false,0,0,-1,true));
 }
 assert(vrprojection::width==0&&vrprojection::viewport(128,128).Width==128);
 assert((pixel(32,32)&0x00ffffff)==0&&pixel(96,32)==0xffffffff&&pixel(32,96)==0xffffffff&&pixel(32,32,1)==0xffffffff);
 clear();{vrprojection::ViewportScope active(64,64);assert(grip.draw(device.Get(),context.Get(),target.Get(),0,eye,fov,{0,0,-1},1,{1,0,0},.4f));}
 assert((pixel(32,32)&0x0000ff00)<0x00008000&&pixel(96,32)==0xffffffff&&pixel(32,32,1)==0xffffffff);
 auto imageDesc=td;imageDesc.Width=imageDesc.Height=8;imageDesc.ArraySize=1;imageDesc.BindFlags=D3D11_BIND_SHADER_RESOURCE;std::vector<unsigned> red(64,0xff0000ff);D3D11_SUBRESOURCE_DATA data{red.data(),32,0};ComPtr<ID3D11Texture2D> image;assert(SUCCEEDED(device->CreateTexture2D(&imageDesc,&data,&image)));
 vrarm::Pose camera{vrarm::M{{1,0,0},{0,1,0},{0,0,1}},{0,0,0}},panel=camera;panel.p.z=-1;float angles[4]={fov.angleLeft,fov.angleRight,fov.angleUp,fov.angleDown};
 clear();{vrprojection::ViewportScope active(64,64);assert(menu.draw(device.Get(),context.Get(),target.Get(),0,image.Get(),camera,angles,panel,2,2));}
 assert(pixel(32,32)==0xff0000ff&&pixel(96,32)==0xffffffff&&pixel(32,32,1)==0xffffffff);
 vrfinalmirror::Producer mirror;{vrprojection::ViewportScope active(64,64);assert(mirror.copy(device.Get(),context.Get(),target.Get(),GetCurrentProcessId()));}
 D3D11_TEXTURE2D_DESC mirrorDesc{};mirror.image->GetDesc(&mirrorDesc);assert(mirrorDesc.Width==64&&mirrorDesc.Height==64);assert(mirror.mutex->AcquireSync(1,0)==S_OK);mirror.mutex->ReleaseSync(0);
 assert(focus.draw(device.Get(),context.Get(),target.Get(),1,fov,1,false,0,0,-1,true));assert((pixel(96,96,1)&0x00ffffff)==0);
 {auto desc=td;desc.Width=desc.Height=1024;ComPtr<ID3D11Texture2D> eyes;assert(SUCCEEDED(device->CreateTexture2D(&desc,nullptr,&eyes)));std::vector<unsigned> black(1024*1024,0xff000000);for(unsigned e=0;e<2;++e)context->UpdateSubresource(eyes.Get(),e,nullptr,black.data(),4096,0);
  {vrprojection::ViewportScope active(512,512);for(unsigned e=0;e<2;++e)assert(focus.draw(device.Get(),context.Get(),eyes.Get(),e,fov,0,true,.25f,0));}
  desc.Usage=D3D11_USAGE_STAGING;desc.BindFlags=0;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> read;assert(SUCCEEDED(device->CreateTexture2D(&desc,nullptr,&read)));context->CopyResource(read.Get(),eyes.Get());
  for(unsigned e=0;e<2;++e){D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(context->Map(read.Get(),e,D3D11_MAP_READ,0,&map)));unsigned marked=0;for(unsigned y=240;y<273;++y)for(unsigned x=300;x<341;++x)marked+=(*(unsigned*)((char*)map.pData+y*map.RowPitch+x*4)&0x00ffffff)!=0;assert(marked>0);assert((*(unsigned*)((char*)map.pData+256*map.RowPitch+256*4)&0x00ffffff)==0);assert((*(unsigned*)((char*)map.pData+256*map.RowPitch+640*4)&0x00ffffff)==0);context->Unmap(read.Get(),e);}
 }
 puts("PASS: menu allocation reuse, cropped overlay/reticle GPU pixels in both eyes, eye isolation, full-size restoration and cropped desktop mirror.");
}
