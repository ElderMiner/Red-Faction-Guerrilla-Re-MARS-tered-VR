#define RFGR_TEST_USER_SETTINGS
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define RFGR_WRIST_STATUS_TEST
#include "../src/native_weapon_physics.h"
#include <cassert>
using namespace RFGRVRWeaponPhysics;
static const char* expectedRocket="rpg_clip";static void* rocketInfo=nullptr;static void* __cdecl findRocket(const char* name){assert(!strcmp(name,expectedRocket));return rocketInfo;}
static unsigned spawned=0,deleted=0,refilled=0,forwarded=0;alignas(4096) static unsigned char objects[64][0x200]{};static void* vtable[14]{};
static void __fastcall mockMove(void* obj,void*,const V* p,const M* b,bool yes){assert(yes);memcpy((char*)obj+4,p,12);memcpy((char*)obj+0x10,b,36);}
static void* __fastcall desc(void* storage,void*,void* info,const V* p,const M* b,unsigned* flags,unsigned,float mass,unsigned id){assert(mass==-1&&id==~0u);memcpy(storage,&info,4);memcpy((char*)storage+4,p,12);memcpy((char*)storage+16,b,36);memcpy((char*)storage+52,flags,4);return storage;}
static void __fastcall freeDesc(void*,void*){}
static void* __fastcall create(void*,void*,void* mgr,void* storage,bool save,unsigned id){assert(mgr==(void*)1&&!save&&id==~0u&&spawned<64);auto* o=objects[spawned++];memcpy(o+4,(char*)storage+4,48);*(void***)o=vtable;*(unsigned*)(o+0x6c)=100+spawned;*(unsigned*)(o+0x4c)=~0u;*(void**)(o+0xa4)=*(void**)storage;o[0x7e]=1;return o;}
static void __fastcall destroy(void*,void*,void* obj,bool save){assert(!save);++deleted;*(unsigned*)((char*)obj+0x6c)=~0u;}
static int __fastcall cap(void*,void*){return 30;}
static void __fastcall refill(void* obj,void*){++refilled;int& mag=*(int*)((char*)obj+0x20c);int& reserve=*(int*)((char*)obj+0x210);int n=(std::min)(30-mag,reserve);mag+=n;reserve-=n;}
static bool __cdecl start(void*,unsigned,void*){++forwarded;return true;}
static float capturedPitch=0;static void __fastcall audioParams(void* p,void*){memset(p,0,0x134);}
static int __cdecl audioCue(int,void* params,int*){capturedPitch=params?*(float*)((char*)params+0x14):0;return 123;}
static unsigned pitchCalls=0;static int __cdecl audioPitch(int sound,float pitch){assert(sound==123);++pitchCalls;capturedPitch=pitch;return 0;}
static void* menuSpawnInfo=nullptr;static unsigned menuSpawnCalls=0;
static void __fastcall menuInit(void* p,void*){memset(p,0,0x5c);}
static bool __cdecl menuSpawn(void* p){assert(*(void**)p==menuSpawnInfo&&word(p,0x54)==0x43);++menuSpawnCalls;return false;}
static V heard{};static M heardBasis{};static int __cdecl hear(const V* p,const M* b,const V*){heard=*p;heardBasis=*b;return 0;}
static bool laserMissingNormal=false;static unsigned laserQueries=0,laserFrees=0;static unsigned char laserHit[0x38]{};
static bool __cdecl laserQuery(SweepRequest* request,void* result){++laserQueries;assert(request->radius==0&&request->filter==(void*)collisionFilter);auto* hits=(HitArray*)result;hits->data=laserHit;hits->count=1;float fraction=.05f;V normal=laserMissingNormal?V{}:V{0,0,-1};memcpy(laserHit+0x24,&fraction,4);memcpy(laserHit+0x18,&normal,12);return true;}
static void __fastcall laserFree(void*,void*){++laserFrees;}
int main(){
 auto* storage=(unsigned char*)VirtualAlloc(nullptr,0x2c70000,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);assert(storage);base=storage;*(unsigned*)(base+0x2c6654c)=1;
 unsigned char player[0xe00]{},weapon[0x300]{},magazine[0x200]{},info[0x240]{},clipInfo[0x100]{},inventory[28]{};M identity{{1,0,0},{0,1,0},{0,0,1}};vtable[12]=(void*)mockMove;
 *(unsigned*)(player+0x6c)=55;*(void**)(player+0xc90)=inventory;*(unsigned*)(inventory+24)=7;*(unsigned*)(weapon+0x6c)=7;*(unsigned*)(weapon+0x13c)=55;*(void**)(weapon+0x148)=info;*(void**)(magazine+0xa4)=clipInfo;*(unsigned*)(magazine+0x6c)=8;*(unsigned*)(magazine+0x70)=7;*(unsigned*)(magazine+0xe4)=1;*(unsigned*)(weapon+0x210)=60;
 Target t;t.player=player;t.playerHandle=55;t.weapon=weapon;t.handle=7;t.weaponClass=0;t.magazine=magazine;t.magazineHandle=8;t.magazinePose={identity,{0,1,0}};t.motion.scale=1;t.motion.body={identity,{}};t.physicalHand=1;t.hand[0]={identity,{0,1,0}};t.hand[1]={identity,{.2f,1,.2f}};t.tick=GetTickCount();target=t;
 // Laser queries stop outside owned pistol gameplay and always release hit storage.
 {auto query=worldQuery;auto release=freeHits;worldQuery=laserQuery;freeHits=(FreeHits)laserFree;t.laserValid=true;t.laserMuzzle={identity,{0,1,0}};
 updateLaser(t,true);auto beam=vrlaser::snapshot();assert(beam.active&&beam.hit&&fabsf(beam.distance-vrlaser::maxRange*.05f)<.001f&&beam.normal.z==-1&&laserQueries==1&&laserFrees==1);
 assert(fabsf(vrlaser::radius(0,1)-.003f)<.00001f&&fabsf(vrlaser::radius(1000,1)-.0375f)<.00001f&&vrlaser::radius(20,1)>vrlaser::radius(10,1));
 laserMissingNormal=true;updateLaser(t,true);assert(vrlaser::snapshot().hit&&vrlaser::snapshot().normal.z==-1&&laserQueries==2&&laserFrees==2);updateLaser(t,false);assert(!vrlaser::snapshot().active&&laserQueries==2);t.laserValid=false;updateLaser(t,true);assert(!vrlaser::snapshot().active&&laserQueries==2);worldQuery=query;freeHits=release;}
 RFGRShared source{};source.version=RFGR_PROTOCOL;source.gamepadActive=1;RFGRVRWeaponInput::source=&source;
 Reload::enabled=true;Reload::descriptor=(Reload::Descriptor)desc;Reload::descriptorFree=(Reload::DescriptorFree)freeDesc;Reload::create=(Reload::RegistryCreate)create;Reload::destroy=(Reload::RegistryDelete)destroy;Reload::capacity=(Reload::Capacity)cap;Reload::originalRefill=(Reload::Refill)refill;Reload::originalStart=start;
 Reload::update(t,true);assert(!Reload::onStart(player,0,nullptr)&&forwarded==0);Reload::onRefill(weapon,nullptr);assert(refilled==0);assert(Reload::find(t)->state.empty(0));
 // Reload suppression survives stale render data and a replaced clip handle.
 target.tick=GetTickCount()-1000;target.magazineHandle=99;assert(!Reload::onStart(player,0,nullptr));Reload::onRefill(weapon,nullptr);assert(refilled==0);target=t;
 source.gamepad.buttons=0x4000;Reload::update(t,true);auto* e=Reload::find(t);assert(e&&e->state.stage==vrreload::Stage::Removed&&spawned==1&&word(weapon,0x20c)==0&&*(float*)(magazine+0xc0)==0);
 source.gamepad.buttons=0;Reload::update(t,true);t.hand[0].p={-.2f,.8f,0};t.squeeze[0]=1;source.gamepad.leftTrigger=0;Reload::update(t,true);assert(e->state.held==vrreload::Held::None);source.gamepad.leftTrigger=255;Reload::update(t,true);assert(e->state.held==vrreload::Held::Fresh&&Reload::validObject(e->held));t.hand[0]=t.magazinePose;Reload::update(t,true);assert(e->state.stage==vrreload::Stage::Inserted&&word(weapon,0x20c)==0&&word(weapon,0x210)==60);
 assert(e->seating.active&&Reload::validObject(e->held)&&Reload::sourceHidden(magazine));auto seatedClone=e->held;V originalWell=t.magazinePose.p;t.magazinePose.p.x+=.03f;e->seating.started-=90;Reload::update(t,true);assert(Reload::validObject(seatedClone)&&Reload::sourceHidden(magazine));assert(fabsf(*(float*)((char*)seatedClone.ptr+4)-t.magazinePose.p.x)<.01f);e->seating.started-=180;Reload::update(t,true);assert(!e->seating.active&&!Reload::validObject(seatedClone)&&!Reload::sourceHidden(magazine));t.magazinePose.p=originalWell;
 source.gamepad.buttons=0x4000;source.gamepad.leftTrigger=0;Reload::update(t,true);assert(e->state.stage==vrreload::Stage::Locked&&word(weapon,0x20c)==30&&word(weapon,0x210)==30&&refilled==1);Reload::update(t,true);assert(refilled==1);
 RFGRGamepad focus{};focus.buttons=0x4080;RFGRVRWeaponInput::filterFocus(focus,true);assert(focus.buttons==0x4000);focus.buttons=0x80;RFGRVRWeaponInput::filterFocus(focus,false);assert(focus.buttons==0x80);
 // Selection buttons remain available while the change-weapon modifier is held.
 RFGRVRWeaponInput::reloadLease=GetTickCount()-1000;RFGRGamepad p{};p.buttons=0x4000;RFGRVRWeaponInput::filter(p);assert(!(p.buttons&0x4000));p.buttons=0x4200;RFGRVRWeaponInput::filter(p);assert(p.buttons==0x4200);
 t.weaponClass=3;assert(!Reload::eligible(t));t.weaponClass=0;t.magazineHandle=99;assert(!Reload::eligible(t));t.magazineHandle=8;
 Reload::suspend(t);assert(*(float*)(magazine+0xc0)==1&&!RFGRVRWeaponInput::reloadControlled);assert(Reload::onStart((char*)player+4,0,nullptr)&&forwarded==1);
 // A launcher without an attached magazine fetches a safe rocket clip directly.
 static char rocketName[64]="rpg_launcher";*(void**)info="rpg_launcher";t.magazine=nullptr;t.magazinePose={};t.magazineHandle=~0u;t.hand[0].p={-.2f,.8f,0};t.motion.pose={identity,{0,1,0}};t.squeeze[0]=0;target=t;
 assert(Reload::eligible(t));rocketInfo=clipInfo;Reload::itemLookup=findRocket;source.gamepad.buttons=0;source.gamepad.leftTrigger=0;*(unsigned*)(weapon+0x20c)=0;Reload::update(t,true);
 source.gamepad.leftTrigger=255;Reload::update(t,true);assert(e->state.held==vrreload::Held::Fresh&&Reload::validObject(e->held)&&Reload::validObject(e->ghost));
 // Early launcher reload escrows loaded rounds and only transfers the missing capacity.
 e->state={};Reload::erase(e->held);Reload::erase(e->ghost);source.gamepad.leftTrigger=0;*(unsigned*)(weapon+0x20c)=5;*(unsigned*)(weapon+0x210)=60;Reload::update(t,true);source.gamepad.leftTrigger=255;Reload::update(t,true);assert(e->retainedRounds==0&&word(weapon,0x20c)==5&&word(weapon,0x210)==60);
 t.hand[0]=vrgrip::worldPose(t.motion.pose,e->rocketLocal);t.hand[0]=vrgrip::weaponAtGrip(t.hand[0],e->state.handLocal);Reload::update(t,true);assert(e->state.stage==vrreload::Stage::Locked&&word(weapon,0x20c)==6&&word(weapon,0x210)==59);source.gamepad.buttons=0x4000;Reload::update(t,true);assert(word(weapon,0x20c)==6&&word(weapon,0x210)==59&&e->retainedRounds==0);
 e->seating.started-=200;Reload::update(t,true);
 // Cancelling a partial launcher reload restores escrowed rounds without consuming reserve.
 source.gamepad.buttons=0;source.gamepad.leftTrigger=0;t.hand[0].p={-.2f,.8f,0};*(unsigned*)(weapon+0x20c)=4;*(unsigned*)(weapon+0x210)=35;Reload::update(t,true);source.gamepad.leftTrigger=255;Reload::update(t,true);assert(e->retainedRounds==0&&word(weapon,0x20c)==4);Reload::suspend(t);assert(word(weapon,0x20c)==4&&word(weapon,0x210)==35&&e->retainedRounds==0);
 // The saved insertion frame includes rotation and position.
 char temp[MAX_PATH]{};GetTempPathA(MAX_PATH,temp);sprintf_s(Reload::profileOverride,"%srfgr-reload-test-%u.ini",temp,GetCurrentProcessId());assert(GetFileAttributesA(Reload::profileOverride)==INVALID_FILE_ATTRIBUTES);
 Pose insertion{turnAround(identity,{1,0,0},.5f),{.1f,.2f,-.3f}};assert(Reload::rocketProfile(t,insertion,true));Pose loaded{identity,{}};assert(Reload::rocketProfile(t,loaded,false));assert(length(sub(loaded.p,insertion.p))<.0001f&&length(sub(loaded.b.u,insertion.b.u))<.0001f);t.motion.body={identity,{0,0,0}};t.squeeze[0]=0;source.gamepad.leftTrigger=0;source.gamepad.buttons=0;unsigned roundsBefore=word(weapon,0x20c),reserveBefore=word(weapon,0x210);Reload::magazineCapture=t.handle;Reload::update(t,true);assert(Reload::magazinePlacement.active&&Reload::validObject(Reload::magazinePreview));Pose preview=Reload::magazinePlacement.fixed;t.hand[0]={turnAround(identity,{0,0,1},.4f),add(preview.p,{.02f,0,.01f})};t.squeeze[0]=1;Reload::update(t,true);assert(!Reload::magazinePlacement.active&&!Reload::validObject(Reload::magazinePreview));Pose heldGrip{identity,{}};assert(Reload::rocketProfile(t,heldGrip,false,".MagazineGrip"));Pose expected=vrgrip::relativePose(t.hand[0],preview);assert(length(sub(heldGrip.p,expected.p))<.0001f&&length(sub(heldGrip.b.r,expected.b.r))<.0001f);assert(word(weapon,0x20c)==roundsBefore&&word(weapon,0x210)==reserveBefore);DeleteFileA(Reload::profileOverride);Reload::profileOverride[0]=0;

 unsigned char definitions[3*0x4bc]{};const char* vehicleNames[3]={"Mar_Jetter_1","Mar_Raider_1","test_mech"};for(unsigned i=0;i<3;++i){*(const char**)(definitions+i*0x4bc)=vehicleNames[i];*(unsigned*)(definitions+i*0x4bc+12)=i==1?2:0;}*(void**)(base+0x12ba5f8+4)=definitions;*(unsigned*)(base+0x12ba5f8+12)=3;toggleVehicleMenu();assert(vehicleMenuOpen&&vehicleMenuCount==2);assert(pollVehicleMenu(false)&&strstr(vrstatus::value.message,"Marauder Jetter"));strcpy_s(requestedVehicleName,"Mar_Raider_1");vehicleRequests=4;vehicleRequestTick=GetTickCount();menuSpawnInfo=definitions+0x4bc;initVehicle=(InitVehicle)menuInit;spawnVehicle=menuSpawn;pollVehicles(t);assert(menuSpawnCalls==4);toggleVehicleMenu();assert(!vehicleMenuOpen&&!(vrstatus::value.twoHand&4));

 // Thermobaric reload props must use that weapon's actual fired projectile.
 *(void**)info="thermobaric_rockets";expectedRocket="thermobaric_rocket_projectile";Reload::itemLookup=findRocket;t.rocketMountValid=true;t.rocketMount={identity,{.1f,.2f,.3f}};t.magazine=nullptr;t.magazineHandle=~0u;e->state.stage=vrreload::Stage::Locked;e->seating.active=false;*(unsigned*)(weapon+0x20c)=1;Reload::update(t,true);assert(Reload::validObject(e->loaded)&&length(sub(e->rocketLocal.p,t.rocketMount.p))<.001f);auto loadedHandle=e->loaded.handle;Reload::update(t,true);assert(e->loaded.handle==loadedHandle);*(unsigned*)(weapon+0x20c)=0;Reload::update(t,true);assert(!Reload::validObject(e->loaded));*(unsigned*)(weapon+0x20c)=1;e->loadedTry=0;Reload::update(t,true);assert(Reload::validObject(e->loaded));auto oldLoaded=e->loaded;Target ineligible=t;ineligible.weaponClass=7;Reload::update(ineligible,true);assert(!Reload::validObject(e->loaded)&&!Reload::validObject(oldLoaded));t.rocketMountValid=false;expectedRocket="rpg_clip";*(void**)info="rpg_launcher";
 // Resource admission distinguishes another loaded variant from the same
 // resource and from unrelated families, without altering manager state.
 {unsigned char entry[24]{};void* activeEntries[1]={entry};static char familyA[]="testFamilyA",familyB[]="testFamilyB";for(unsigned i=0;i<3;++i){*(unsigned*)(definitions+i*0x4bc+0x34)=100+i;*(void**)(definitions+i*0x4bc+0x38)=i==2?familyB:familyA;}*(unsigned*)(entry+8)=101;*(unsigned*)(base+0x12b8ad0)=3;*(void**)(base+0x12b8ae8)=activeEntries;*(unsigned*)(base+0x12b8af0)=1;assert(vehicleFamilyConflict(definitions)&&!vehicleFamilyConflict(definitions+0x4bc)&&!vehicleFamilyConflict(definitions+2*0x4bc));*(unsigned*)(base+0x12b8af0)=0;}
 // Empty disc magazines disappear without creating a loose dropped prop.
 static char discName[64]="grinder";*(void**)info=discName;t.magazine=magazine;t.magazineHandle=8;t.magazinePose={identity,{0,1,0}};e->state={};source.gamepad.leftTrigger=0;source.gamepad.buttons=0;*(unsigned*)(weapon+0x20c)=0;unsigned spawnedBefore=spawned;Reload::update(t,true);assert(e->state.stage==vrreload::Stage::Removed&&e->state.held==vrreload::Held::None&&spawned==spawnedBefore&&Reload::sourceHidden(magazine));
 // Expanded hip zone supplies an entry pulse only when ammo can be fetched.
 {assert(vrreload::nearHip({.6f,.45f,.45f})&&!vrreload::nearHip({.8f,.45f,.45f})&&!vrreload::nearHip({.2f,1.6f,0}));e->state.stage=vrreload::Stage::Removed;e->state.held=vrreload::Held::None;e->pickupHint={};t.hand[0]={identity,{.6f,.45f,.45f}};t.motion.scale=1;source.gamepad.leftTrigger=0;*(unsigned*)(weapon+0x210)=3;Reload::update(t,true);RFGRHapticReader hints(RFGR_MAG_HINT_MAP);RFGRHapticPacket pulse{};assert(hints.read(GetCurrentProcessId(),pulse)&&pulse.motor[0]==12000&&!pulse.motor[1]);LONG sequence=pulse.sequence;Reload::update(t,true);assert(hints.read(GetCurrentProcessId(),pulse)&&pulse.sequence==sequence);t.hand[0].p.x=.9f;Reload::update(t,true);t.hand[0].p.x=.6f;Reload::update(t,true);assert(hints.read(GetCurrentProcessId(),pulse)&&pulse.sequence!=sequence);source.gamepad.leftTrigger=255;Reload::update(t,true);assert(e->state.held==vrreload::Held::Fresh);source.gamepad.leftTrigger=0;}
 // Pitch warnings preserve the caller's audio parameters and exclude other
 // cues/owners. High-capacity weapons use their final20%; <=10 use last shot.
 vrsettings::cached.value[vrsettings::Reload]=1;vrsettings::checked=GetTickCount();assert(!Reload::eligible(t)&&!Reload::controls(player,weapon));Reload::update(t,true);assert(!RFGRVRWeaponInput::reloadControlled&&!RFGRVRWeaponInput::manualReloadEnabled&&*(float*)(magazine+0xc0)==1);vrsettings::cached.value[vrsettings::Reload]=0;
 // A later native render-camera update cannot replace fresh headset audio orientation.
 SpatialAudio::setListener=hear;SpatialAudio::ready=true;float hp[3]={1,2,3};M hb=turnAround(identity,{0,1,0},.6f);SpatialAudio::listener(hp,(float*)&hb);V nativeP{9,9,9},still{};SpatialAudio::onListener(&nativeP,&identity,&still);assert(length(sub(heard,V{1,2,3}))<.001f&&length(sub(heardBasis.f,hb.f))<.001f);SpatialAudio::headsetTick=GetTickCount()-200;SpatialAudio::onListener(&nativeP,&identity,&still);assert(length(sub(heard,nativeP))<.001f);SpatialAudio::ready=false;
 VirtualFree(storage,0,MEM_RELEASE);
}

