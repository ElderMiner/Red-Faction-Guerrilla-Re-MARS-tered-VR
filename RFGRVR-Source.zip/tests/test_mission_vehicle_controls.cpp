#define RFGR_TEST_USER_SETTINGS
#define NOMINMAX
#include <windows.h>
static ULONGLONG clockTick=1000;
static ULONGLONG VehicleTestTick(){return clockTick;}
#define GetTickCount64 VehicleTestTick
#include "../src/vr_vehicle_controls.h"
#include "../src/vr_user_settings.h"
#include "../src/vr_turret_mount_kind.h"
#include "../src/vehicle_type_catalog.h"
#include <cassert>
#include <cstdio>
int main(){using namespace vrarm;
 assert(RFGRVR_HeadAimedVehicleTurret("turret_vehicle_jetter_rocket_mg"));assert(!RFGRVR_HeadAimedVehicleTurret("turret_vehicle_raider_harpoon"));assert(!RFGRVR_HeadAimedVehicleTurret(nullptr));
 assert(RFGRVRVehicleIsMiniMech("Walker_Min")&&RFGRVRVehicleIsMiniMech("Walker_Min2")&&RFGRVRVehicleIsMiniMech("Walker_Min3"));assert(!RFGRVRVehicleIsMiniMech("Walker_Flamer")&&!RFGRVRVehicleIsMiniMech("Walker_Civilian"));
 Pose mount{M{{1,0,0},{0,1,0},{0,0,1}},{0,0,0}},head=mount;float limits[4]={1,-1,.6f,-.6f},yaw=0,pitch=0;
 head.b=turnAround(mount.b,{0,1,0},.4f);assert(RFGRVR_HeadTurretAim(mount,head,{0,0,0},1,limits,yaw,pitch)&&fabsf(yaw-.4f)<.00001f&&fabsf(pitch)<.00001f);
 mount.b=head.b;assert(RFGRVR_HeadTurretAim(mount,head,{0,0,0},1,limits,yaw,pitch)&&fabsf(yaw)<.00001f);
 mount.b=M{{1,0,0},{0,1,0},{0,0,1}};head.b=turnAround(mount.b,{0,1,0},1.4f);assert(RFGRVR_HeadTurretAim(mount,head,{0,0,0},1,limits,yaw,pitch)&&fabsf(yaw-1.4f)<.00001f);float shifted=-.5f;assert(fabsf(RFGRVR_HeadTurretTurn(yaw,shifted,0,.05f,1.5f,-1,1)-.9f)<.00001f&&shifted==-.5f);
 assert(RFGRVR_HeadTurretTurn(1.7f,shifted,0,.05f,1.5f,-1,1)==1&&shifted==-.5f);assert(fabsf(RFGRVR_HeadTurretTurn(1.4f,shifted,0,.05f,1.5f,-1,1)-.9f)<.00001f);
 limits[0]=NAN;assert(!RFGRVR_HeadTurretAim(mount,head,{0,0,0},1,limits,yaw,pitch));
 for(int degrees:{15,60,90,120,180}){vrsettings::Config config;config.value[vrsettings::Turn]=0;config.value[vrsettings::TurnSpeed]=degrees;vrsettings::Turning player;
  for(short axis:{short(-32768),short(-16000),short(0),short(16000),short(32767)}){RFGRVRMechInput::publish(axis);float value=(std::clamp)(axis/32767.f,-1.f,1.f);float expected=player.apply(value,.016f,config)*.01745329252f;assert(fabsf(RFGRVRMechInput::rate(degrees*.01745329252f)*.016f-expected)<.000001f);}
 }
 RFGRVRMechInput::publish(32767);assert(fabsf(RFGRVRMechInput::rate()-.75f)<.000001f);clockTick+=251;assert(RFGRVRMechInput::rate(3)==0);assert(RFGRVRMechInput::rate(NAN)==0);
 float offset=0;float combined=RFGRVR_HeadTurretTurn(.2f,offset,1,.05f,1.5f,-1,1);assert(fabsf(combined-.275f)<.00001f);
 assert(fabsf(RFGRVR_HeadTurretTurn(.2f,offset,0,.05f,1.5f,-1,1)-combined)<.00001f);
 assert(fabsf(RFGRVR_HeadTurretTurn(.3f,offset,0,.05f,1.5f,-1,1)-.375f)<.00001f);
 for(unsigned i=0;i<100;++i)RFGRVR_HeadTurretTurn(.3f,offset,1,.05f,1.5f,-1,1);
 assert(RFGRVR_HeadTurretTurn(.3f,offset,-1,.05f,1.5f,-1,1)<1);float prior=offset;
 RFGRVR_HeadTurretTurn(.3f,offset,.1f,.05f,1.5f,-1,1);assert(offset==prior);
 RFGRVR_HeadTurretTurn(.3f,offset,1,NAN,1.5f,-1,1);assert(offset==prior);
 offset=0;float previous=0;for(unsigned i=0;i<400;++i){float next=RFGRVR_HeadTurretTurn(0,offset,1,.05f,1.5f,-3.14154f,3.14154f);assert(next>previous&&fabsf(next-previous-.075f)<.00001f);previous=next;}assert(offset>25);
 for(unsigned i=0;i<800;++i){float next=RFGRVR_HeadTurretTurn(0,offset,-1,.05f,1.5f,-3.14154f,3.14154f);assert(next<previous&&fabsf(next-previous+.075f)<.00001f);previous=next;}assert(offset<-25);float held=offset;assert(RFGRVR_HeadTurretTurn(0,offset,0,.05f,1.5f,-3.14154f,3.14154f)==held);
 RFGRVRHeadYaw headYaw;for(float angle:{0.f,1.f,2.f,3.f,4.f,5.f,6.f,7.f,8.f,9.f,10.f,11.f,12.f,13.f})assert(fabsf(headYaw.update(std::remainder(angle,6.28318530718f))-angle)<.00001f);float last=headYaw.value;assert(headYaw.update(NAN)==last);headYaw={};assert(!headYaw.ready&&headYaw.update(-.4f)==-.4f);
 puts("PASS: head-yaw unwrap, continuous whole-seat traverse, reversal/release, limited-arc recovery, mini-walker smooth-turn parity and stale input rejection.");
}
