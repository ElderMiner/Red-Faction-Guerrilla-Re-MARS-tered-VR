#define NOMINMAX
#include "../src/modern_cascades.h"
#include <cassert>
#include <cstdio>
int main(){moderncascade::Camera eyes[2];float native[16];for(unsigned eye=0;eye<2;++eye){float position[3]={eye?.032f:-.032f,1.7f,0};auto projection=modernlocal::projection({position[0],position[1],position[2]},{0,0,1},{0,1,0},1.57079632679f,.05f,1000);for(unsigned row=0;row<4;++row)for(unsigned col=0;col<4;++col)native[col*4+row]=projection.clip[row*4+col];assert(moderncascade::camera(native,position,eyes[eye]));}auto plan=moderncascade::fit(eyes,{.3f,.8f,.5196152f},.1f,180,3,2048);assert(plan.count==3);
 for(auto& c:plan.cascades){if(!c.farDistance)continue;assert(c.farDistance>c.nearDistance&&c.worldTexel>0);for(unsigned eye=0;eye<2;++eye)for(unsigned side=0;side<2;++side)for(unsigned row=0;row<2;++row)for(unsigned col=0;col<2;++col){modernlocal::V p;assert(moderncascade::corner(eyes[eye],col?1.f:-1.f,row?1.f:-1.f,side?c.farDistance:c.nearDistance,p));float world[4]={p.x,p.y,p.z,1},uv[4]{};for(unsigned r=0;r<4;++r)for(unsigned k=0;k<4;++k)uv[r]+=c.projection.texture[r*4+k]*world[k];for(unsigned i=0;i<3;++i)assert(uv[i]>=-.0001f&&uv[i]<=1.0001f);}}
 assert(std::abs(plan.cascades[2].farDistance-180)<.001f);assert(!moderncascade::fit(eyes,{0,0,0},.1f,180,3,2048).count);assert(!moderncascade::fit(eyes,{0,1,0},10,1,3,2048).count);
 // Shadow-plane translations are exact texel steps, not arbitrary subpixel
 // offsets. Both eyes are covered by a single stable world projection.
 auto upright=moderncascade::fit(eyes,{0,1,0},.1f,180,3,2048);for(auto& c:upright.cascades){if(!c.farDistance)continue;float x=c.projection.texture[3]*2048,y=c.projection.texture[7]*2048;assert(std::abs(x-std::round(x))<.001f&&std::abs(y-std::round(y))<.001f);}puts("PASS cascades: native matrix reconstruction, stereo-union frustum coverage, bounded PSSM splits, stable world-space orientation, texel-snapped projections and invalid-input rejection");}
