#include "../src/vr_weapon_recoil.h"
#include <cassert>
#include <cstdio>
int main(){using namespace vrrecoil;using namespace vrarm;auto pistol=profile(0,"edf_pistol");assert(pistol.degrees==5.5f&&pistol.returnRate==22);// Ammo and native aiming/firing notifications may arrive in either order.
 State delayed;delayed.observe(9,9,12,false,false,100,pistol,false);float last=0;
 for(int round=1;round<=8;++round){unsigned now=100+round*90;delayed.observe(9,9,12-round,false,false,now,pistol,false);assert(delayed.climb>last);last=delayed.climb;delayed.observe(9,9,12-round,true,false,now+1,pistol,false);assert(delayed.climb==last);}
 State skipped;skipped.observe(10,10,12,false,false,100,pistol,false);skipped.observe(10,10,9,false,false,120,pistol,false);assert(fabsf(skipped.climb-3*pistol.degrees*.01745329252f*.65f)<.00001f);
 State reload;reload.observe(11,11,1,false,false,100,pistol,false);reload.observe(11,11,0,false,true,120,pistol,false);assert(reload.climb==0);reload.observe(11,11,12,true,false,140,pistol,false);assert(reload.climb==0);reload.observe(12,12,5,true,false,160,pistol,false);assert(reload.climb==0);
 State gap;gap.observe(13,13,12,false,false,100,pistol,false);gap.observe(13,13,11,false,false,800,pistol,false);assert(gap.climb==0);gap.observe(13,13,11,true,false,801,pistol,false);assert(gap.climb==0);
 // Shot vectors must exclude only the current round's kick, in either callback order.
 Pose base{M{{1,0,0},{0,1,0},{0,0,1}},{0,1,0}};
 Pose old=base;old.p.x=1;Pose kicked=base;kicked.p.x=2;
 Ballistics causal;
 auto a=causal.shot(1,1,12,old,100);assert(a.p.x==1);
 causal.drop(1,1,12,11,old,101);
 auto b=causal.shot(1,1,11,kicked,190);assert(b.p.x==2);
 causal.drop(1,1,11,10,kicked,191);
 causal.drop(1,1,10,9,old,280);
 auto c=causal.shot(1,1,9,kicked,281);assert(c.p.x==1);
 causal.drop(1,1,9,8,old,370);
 auto d=causal.shot(1,1,8,kicked,371);assert(d.p.x==1);
 causal.drop(1,1,8,7,old,460);
 assert(causal.shot(1,1,7,kicked,1000).p.x==2);
 causal.drop(1,1,7,6,old,1010);
 assert(causal.shot(2,2,6,kicked,1011).p.x==2);
 State burst;burst.observe(1,1,12,false,false,100,pistol,false);burst.observe(1,1,11,true,false,200,pistol,false);float first=burst.climb;burst.observe(1,1,10,true,false,300,pistol,false);assert(burst.climb>first*1.9f);Pose gun{M{{1,0,0},{0,1,0},{0,0,1}},{0,1,0}};auto shot=burst.apply(gun,{},gun.b,1);assert(shot.b.f.y>.1f);float climb=burst.climb;burst.observe(1,1,0,false,true,320,pistol,false);assert(burst.climb==climb);for(unsigned t=500;t<2600;t+=20)burst.observe(1,1,0,false,false,t,pistol,false);assert(burst.climb<.001f);puts("PASS: handgun cumulative firing-direction kick, reload exclusion and settled recovery");}
