#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static HWND TestForeground(){return (HWND)1;}
static bool windowFocused=true;static DWORD TestWindowProcess(HWND,DWORD* pid){*pid=windowFocused?GetCurrentProcessId():0;return 1;}
#define GetForegroundWindow TestForeground
#define GetWindowThreadProcessId TestWindowProcess
#define RFGR_TEST_USER_SETTINGS
static bool keyboardKeys[256]{};static SHORT TestKey(int code){return keyboardKeys[code]?SHORT(0x8000):0;}
#define GetAsyncKeyState TestKey
#define RFGR_HAPTICS_TEST
#include "../src/gamepad_input.cpp"
#include <cassert>
static bool flamer=false,aimOverlay=false;
extern "C" bool RFGRVR_VehicleFlamer(){return flamer;}
static unsigned resetCount=0,recenterCount=0;static short driverTurn=0;
static bool roomInput=true;static bool parent=false,moving=false,turning=false,turretPresent=true;static float heightAxis=0;static unsigned humanState=0;static float turn=0,turretStick=0;
extern "C" float RFGRVR_HeadCam_ViewYaw(){return .7f;}
extern "C" bool RFGRVR_HeadCam_RoomAxes(float,bool allowed,short* x,short* y){if(allowed&&roomInput){*x=9000;*y=12000;}return allowed&&roomInput;}
extern "C" bool RFGRVR_HeadCam_Enabled(){return true;}
extern "C" bool RFGRVR_HeadCam_TurretMounted(){return humanState==3||(humanState==8&&turretPresent);}
extern "C" bool RFGRVR_NativeTurretAxes(short* x,short* y){*x=12345;*y=-6789;return true;}
extern "C" bool RFGRVR_NativeFacing(float* y,float* p){*y=.7f;*p=.8f;return true;}
extern "C" void RFGRVR_NativeTurnAxis(float axis){turn=axis;}
extern "C" void RFGRVR_TurretStick(float axis){turretStick=axis;}
extern "C" bool RFGRVR_NativeParented(){return parent;}
extern "C" unsigned RFGRVR_HeadCam_PlayerState(){return humanState;}
extern "C" void RFGRVR_HeadCam_Locomotion(bool m,bool t){moving=m;turning=t;}
int main(){
 {using namespace RFGRVRWeaponInput;throwControlled=true;c4Controlled=true;lease=GetTickCount();reloadControlled=true;RFGRGamepad pad{};pad.leftTrigger=255;filter(pad,true);assert((pad.buttons&0x2000)&&pad.leftTrigger==0);pad={};pad.buttons=0x200;pad.leftTrigger=255;filter(pad,true);assert(!(pad.buttons&0x2000));c4Controlled=false;pad={};pad.leftTrigger=255;filter(pad,true);assert(!(pad.buttons&0x2000));throwControlled=false;reloadControlled=false;}
RFGRVRWeaponInput::manualReloadEnabled=true;RFGRVRWeaponInput::reloadControlled=false;RFGRGamepad gap{};gap.buttons=0x4000;gap.leftTrigger=123;RFGRVRWeaponInput::filter(gap,true);assert(!(gap.buttons&0x4000)&&gap.leftTrigger==123);RFGRVRWeaponInput::manualReloadEnabled=false;RFGRShared data{};shared=&data;data.magic=RFGR_MAGIC;data.version=RFGR_PROTOCOL;data.gamepadActive=1;data.inputSamples=1;data.poseSamples=1;data.calibrationReady=data.calibrationFloorValid=1;data.calibratedHeadHeight=1.6f;data.hmd.validFlags=3;data.hmd.position[1]=1.6f;data.gamepad.rightX=16000;data.gamepad.rightY=18000;data.gamepad.leftY=20000;data.gamepad.buttons=XINPUT_GAMEPAD_X;XINPUT_STATE out{};
 {auto* bus=vrsettings::bus();bus->pauseTick=bus->pauseMenuTick=GetTickCount();bus->nativeSettings=1;keyboardKeys[VK_UP]=true;assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.wButtons==0);keyboardKeys[VK_UP]=false;keyboardKeys[VK_DOWN]=true;assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.wButtons==0);keyboardKeys[VK_DOWN]=false;bus->nativeSettings=0;bus->pauseTick=bus->pauseMenuTick=0;assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.wButtons==0);RFGRGamepad saved=data.gamepad;data.gamepad={};assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.wButtons==0);data.gamepad=saved;}
 // Tutorial navigation stays native and never drives the VR body/turn path.
 {auto saved=data.gamepad;auto* bus=vrsettings::bus();data.gamepad={};data.gamepad.leftY=23000;data.gamepad.rightX=21000;data.gamepad.buttons=XINPUT_GAMEPAD_START;bus->pauseTick=GetTickCount();moving=turning=true;turn=turretStick=1;
  assert(OnGet(0,&out)==ERROR_SUCCESS);assert(out.Gamepad.wButtons==XINPUT_GAMEPAD_START&&out.Gamepad.sThumbLY==23000&&out.Gamepad.sThumbRX==21000);assert(!moving&&!turning&&turn==0&&turretStick==0);
  bus->pauseTick=0;assert(OnGet(0,&out)==ERROR_SUCCESS&&!(out.Gamepad.wButtons&XINPUT_GAMEPAD_START));data.gamepad={};OnGet(0,&out);data.gamepad.buttons=XINPUT_GAMEPAD_START;assert(OnGet(0,&out)==ERROR_SUCCESS&&(out.Gamepad.wButtons&XINPUT_GAMEPAD_START));
  // Keyboard dismissal does not latch desktop ownership into gameplay.
  data.gamepad={};bus->pauseTick=GetTickCount();keyboardKeys[VK_RETURN]=true;assert(OnGet(0,&out)==ERROR_SUCCESS&&!out.Gamepad.wButtons);keyboardKeys[VK_RETURN]=false;bus->pauseTick=0;data.gamepad.leftY=23000;data.gamepad.buttons=XINPUT_GAMEPAD_X;assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.wButtons==XINPUT_GAMEPAD_X&&out.Gamepad.sThumbLY!=0);data.gamepad=saved;
 }
 // Sprint cannot generate locomotion from rest; the modifier follows real axes.
 {auto saved=data.gamepad;auto active=data.gameplayActive;data.gameplayActive=1;roomInput=false;data.gamepad={};data.gamepad.buttons=XINPUT_GAMEPAD_LEFT_SHOULDER;assert(OnGet(0,&out)==ERROR_SUCCESS&&!(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_SHOULDER)&&!out.Gamepad.sThumbLX&&!out.Gamepad.sThumbLY);data.gamepad.leftY=24000;assert(OnGet(0,&out)==ERROR_SUCCESS&&(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_SHOULDER)&&out.Gamepad.sThumbLY!=0);data.gamepad.leftY=0;assert(OnGet(0,&out)==ERROR_SUCCESS&&!(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_SHOULDER));humanState=9;assert(OnGet(0,&out)==ERROR_SUCCESS&&(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_SHOULDER));humanState=0;roomInput=true;data.gameplayActive=active;data.gamepad=saved;}
 // Alt-tab keeps a neutral device, then recovers the same control stream.
 data.bridgePid=GetCurrentProcessId();data.bridgeHeartbeat=1;
 windowFocused=false;assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.wButtons==0&&out.Gamepad.sThumbLX==0&&out.Gamepad.sThumbLY==0);
 data.gamepadActive=0;++data.inputSamples;++data.bridgeHeartbeat;assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.wButtons==0&&out.Gamepad.sThumbLY==0);
 windowFocused=true;data.gamepadActive=1;++data.inputSamples;assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.wButtons==XINPUT_GAMEPAD_X&&out.Gamepad.sThumbLY!=0);
 assert(OnGet(0,&out)==ERROR_SUCCESS);assert(out.Gamepad.sThumbRX==0&&out.Gamepad.sThumbRY==0);assert(abs(out.Gamepad.sThumbLY-15297)<3&&abs(out.Gamepad.sThumbLX-12884)<3&&out.Gamepad.wButtons==XINPUT_GAMEPAD_X);assert(moving&&turning&&turn>.4f);
 data.gamepad.leftY=0;assert(OnGet(0,&out)==ERROR_SUCCESS);assert(out.Gamepad.sThumbLX==9000&&out.Gamepad.sThumbLY==12000&&!moving);
 physicalCrouch.reset();data.hmd.position[1]=1.2f;++data.poseSamples;assert(OnGet(0,&out)==ERROR_SUCCESS);assert(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_THUMB);
 parent=true;++data.poseSamples;assert(OnGet(0,&out)==ERROR_SUCCESS);assert(!(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_THUMB)&&!jumpHeld);
 parent=false;humanState=1;++data.poseSamples;assert(OnGet(0,&out)==ERROR_SUCCESS);assert(!(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_THUMB)&&!jumpHeld);
 {auto saved=data.gamepad;auto wasActive=data.gameplayActive;data.gameplayActive=1;data.gamepad={};data.gamepad.buttons=vrquest::ContextTap;vrinteraction::sample(true,GetTickCount());assert(OnGet(0,&out)==ERROR_SUCCESS&&(out.Gamepad.wButtons&XINPUT_GAMEPAD_B)&&!(out.Gamepad.wButtons&vrquest::Commands));vrinteraction::sample(false,GetTickCount());assert(OnGet(0,&out)==ERROR_SUCCESS&&(out.Gamepad.wButtons&XINPUT_GAMEPAD_B)&&!(out.Gamepad.wButtons&XINPUT_GAMEPAD_RIGHT_SHOULDER));data.gamepad.buttons=0;OnGet(0,&out);data.gamepad.buttons=vrquest::ContextTap;assert(OnGet(0,&out)==ERROR_SUCCESS&&(out.Gamepad.wButtons&XINPUT_GAMEPAD_RIGHT_SHOULDER)&&!(out.Gamepad.wButtons&XINPUT_GAMEPAD_B));data.gamepad.buttons=0;OnGet(0,&out);data.gamepad.buttons=vrquest::Detonate;RFGRVRWeaponInput::throwControlled=true;RFGRVRWeaponInput::c4Controlled=true;RFGRVRWeaponInput::lease=GetTickCount();assert(OnGet(0,&out)==ERROR_SUCCESS&&(out.Gamepad.wButtons&XINPUT_GAMEPAD_B));RFGRVRWeaponInput::throwControlled=false;RFGRVRWeaponInput::c4Controlled=false;assert(OnGet(0,&out)==ERROR_SUCCESS&&!(out.Gamepad.wButtons&(XINPUT_GAMEPAD_B|vrquest::Commands)));questCommands={};data.gamepad=saved;data.gameplayActive=wasActive;}
 humanState=0;data.gamepad.buttons=XINPUT_GAMEPAD_A;assert(OnGet(0,&out)==ERROR_SUCCESS);assert((out.Gamepad.wButtons&XINPUT_GAMEPAD_A)&&!moving);data.gamepad.buttons=0;
 humanState=0;data.hmd.position[1]=1.6f;jumpHeld=true;gestureSample=crouchSample;assert(OnGet(0,&out)==ERROR_SUCCESS);assert((out.Gamepad.wButtons&XINPUT_GAMEPAD_A)&&!moving);jumpHeld=false;
 humanState=0;data.calibrationFloorValid=0;++data.poseSamples;assert(OnGet(0,&out)==ERROR_SUCCESS);assert(!(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_THUMB));
 data.gamepad.leftX=16000;humanState=3;assert(OnGet(0,&out)==ERROR_SUCCESS);assert(out.Gamepad.sThumbRX==0&&out.Gamepad.sThumbRY==0&&turn==0&&turretStick>.4f&&!moving&&!turning);humanState=8;data.gamepad.leftY=20000;assert(OnGet(0,&out)==ERROR_SUCCESS&&out.Gamepad.sThumbRX==0&&out.Gamepad.sThumbRY==0&&out.Gamepad.sThumbLY==0&&out.Gamepad.sThumbLX==0&&turn==0&&turretStick>.4f);
 // Driver/passenger right stick cannot turn the rig or alter drive axes.
 humanState=9;data.gripValue[1]=1;data.gamepad.leftX=3000;assert(OnGet(0,&out)==ERROR_SUCCESS);assert(turn==0&&turretStick==0&&!turning&&out.Gamepad.sThumbLX==3000&&out.Gamepad.sThumbLY==20000&&out.Gamepad.sThumbRX==0&&out.Gamepad.sThumbRY==0&&heightAxis>.5f);
 data.gripValue[1]=0;assert(OnGet(0,&out)==ERROR_SUCCESS&&heightAxis==0&&driverTurn==16000);data.gripValue[1]=1;assert(OnGet(0,&out)==ERROR_SUCCESS&&heightAxis>.5f);humanState=8;turretPresent=false;assert(OnGet(0,&out)==ERROR_SUCCESS&&turn==0&&turretStick==0&&!turning);turretPresent=true;data.gamepad.leftX=16000;assert(OnGet(0,&out)==ERROR_SUCCESS&&turn==0&&turretStick>.4f);
 humanState=9;data.calibrationFloorValid=1;seatCrouch.reset();data.hmd.position[1]=1.1f;++data.poseSamples;physicalCrouchHeld();assert(RFGRVR_VehicleSitting());data.hmd.validFlags=0;++data.poseSamples;physicalCrouchHeld();assert(RFGRVR_VehicleSitting());humanState=0;physicalCrouchHeld();assert(!RFGRVR_VehicleSitting());data.hmd.validFlags=3;
 humanState=9;data.gamepad.buttons=XINPUT_GAMEPAD_LEFT_THUMB;OnGet(0,&out);OnGet(0,&out);assert(resetCount==1&&recenterCount==1&&!(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_THUMB));data.gamepad.buttons=0;OnGet(0,&out);data.gamepad.buttons=XINPUT_GAMEPAD_LEFT_THUMB;OnGet(0,&out);assert(resetCount==2);humanState=0;data.gamepad.buttons=0;OnGet(0,&out);data.gamepad.buttons=XINPUT_GAMEPAD_LEFT_THUMB;OnGet(0,&out);assert(resetCount==2&&(out.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_THUMB));
 humanState=9;flamer=true;data.gamepad.buttons=0;data.gamepad.rightY=-26000;data.gripValue[1]=0;OnGet(0,&out);assert(aimOverlay&&heightAxis==0);data.gripValue[1]=1;OnGet(0,&out);assert(!aimOverlay&&heightAxis<0);flamer=false;data.gripValue[1]=0;OnGet(0,&out);assert(!aimOverlay);humanState=0;
 XINPUT_VIBRATION rumble{12345,54321};assert(OnSet(0,&rumble)==ERROR_SUCCESS);RFGRHapticReader reader;RFGRHapticPacket packet;assert(reader.read(GetCurrentProcessId(),packet)&&packet.motor[0]==12345&&packet.motor[1]==54321);assert(!reader.read(GetCurrentProcessId()+1,packet));{RFGRHapticWriter hint(RFGR_MAG_HINT_MAP);RFGRHapticReader hints(RFGR_MAG_HINT_MAP);hint.publish(12000,0);RFGRHapticPacket pulse{};assert(hints.read(GetCurrentProcessId(),pulse)&&pulse.motor[0]==12000&&!pulse.motor[1]);assert(reader.read(GetCurrentProcessId(),packet)&&packet.motor[0]==12345&&packet.motor[1]==54321);}rumble={};assert(OnSet(0,&rumble)==ERROR_SUCCESS&&reader.read(GetCurrentProcessId(),packet)&&!packet.motor[0]&&!packet.motor[1]);
}

extern "C" void RFGRVR_VehicleControlsInput(float axis,bool overlay){heightAxis=axis;aimOverlay=overlay;}

extern "C" void RFGRVR_HeadCam_MoveForward(float){}

extern "C" void RFGRVR_VehicleDriverAxes(short*,short*,short turn){driverTurn=turn;}


extern "C" void RFGRVR_VehicleResetView(){++resetCount;}
extern "C" void RFGRVR_Temporal_Recenter(){++recenterCount;}
