#define NOMINMAX
#include "../src/modern_wave_scene.h"
#include <cassert>
#include <cstdio>
using namespace modernwave;
static Triangle plane(uint64_t id,float z,Profile material){return {id,{-10,-10,z},{10,-10,z},{0,10,z},material,.1f};}
int main(){
 Scene scene;V value;
 assert(!scene.segment({0,0,0},{0,0,4},value));
 assert(scene.publish({},1));assert(scene.segment({0,0,0},{0,0,4},value)&&value.x==1);
 auto concrete=profile(Material::Concrete),glass=profile(Material::Glass);
 assert(scene.publish({plane(1,2,concrete)},2));assert(scene.segment({0,0,0},{0,0,4},value)&&value.x==0);
 assert(scene.segment({20,0,0},{20,0,4},value)&&value.x==1); // outside geometry
 glass.absorption={1,2,3};assert(scene.publish({plane(1,2,glass)},3));assert(scene.segment({0,0,0},{0,0,4},value));assert(value.x>value.y&&value.y>value.z&&value.x<1);
 V single=value;assert(scene.publish({plane(1,1,glass),plane(2,3,glass)},4));assert(scene.segment({0,0,0},{0,0,4},value)&&std::abs(value.x-single.x*single.x)<1e-6f);
 assert(scene.publish({plane(1,1,glass),plane(2,3,concrete)},5));assert(scene.segment({0,0,0},{0,0,4},value)&&value.x==0);
 auto invalid=plane(7,2,glass);invalid.a.x=NAN;assert(!scene.publish({invalid},6)&&scene.revision()==5);assert(scene.segment({0,0,0},{0,0,4},value)&&value.x==0);
 // Adjacent triangles in the same thin sheet share the seam intersection.
 Triangle a{9,{-1,-1,2},{1,-1,2},{1,1,2},glass,.1f},b{9,{-1,-1,2},{1,1,2},{-1,1,2},glass,.1f};assert(scene.publish({a,b},7));assert(scene.segment({0,0,0},{0,0,4},value)&&std::abs(value.x-single.x)<1e-6f);
 // Endpoint surfaces are excluded only at their endpoint, not by object ID.
 assert(scene.publish({plane(1,0,concrete),plane(1,2,concrete)},8));assert(scene.segment({0,0,0},{0,0,4},value)&&value.x==0);
 std::vector<Triangle> large;for(unsigned i=0;i<32768;++i){auto t=plane(i+1,2,concrete);float offset=30+float(i)*30;t.a.x+=offset;t.b.x+=offset;t.c.x+=offset;large.push_back(t);}assert(scene.publish(std::move(large),9));assert(scene.segment({0,0,0},{0,0,4},value)&&value.x==1);
 Surface receiver;receiver.id=100;receiver.position={0,0,4};receiver.normal={0,0,-1};receiver.area=4;receiver.visible=true;
 Field source;source.source=5;source.energy={100,100,100};source.range=20;
 assert(scene.publish({},10));auto clear=scene.transport({receiver},{source});assert(clear.valid&&clear.received[0].x>0);
 assert(scene.publish({plane(1,2,glass)},11));auto tinted=scene.transport({receiver},{source});assert(tinted.valid&&tinted.received[0].x<clear.received[0].x&&tinted.received[0].x>tinted.received[0].z);
 assert(scene.publish({plane(1,2,concrete)},12));assert(scene.transport({receiver},{source}).received[0].x==0);
 // Complete transport -> retained secondary field -> eye-directed receiver.
 assert(scene.publish({},13));Surface bounce;bounce.id=101;bounce.position={0,0,2};bounce.normal={0,0,-1};bounce.area=4;bounce.visible=true;bounce.material=concrete;
 receiver.position={0,0,-2};receiver.normal={0,0,1};auto result=scene.transport({bounce,receiver},{source});assert(result.valid&&!result.emitted.empty());for(auto& f:result.emitted)assert(f.source==source.source&&f.surface);
 auto lit=scene.shade(result,receiver,{0,0,0});assert(lit.x>0&&std::isfinite(lit.x));assert(scene.publish({plane(8,0,concrete)},14));assert(scene.shade(result,receiver,{0,0,0}).x==0);
 assert(!scene.segment({NAN,0,0},{0,0,4},value));
 puts("PASS wave scene: real triangle BVH, solid occlusion, layered spectral transmission, seam deduplication, endpoint safety, transactional revisions, 32768-triangle bounds and end-to-end field transport");
}
