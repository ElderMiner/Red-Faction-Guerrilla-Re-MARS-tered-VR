#define RFGR_TEST_USER_SETTINGS
#define NOMINMAX
#include "../src/vr_mission_tracker.h"
#include "../src/vr_hud_layout.h"
#include <cassert>
#include <cstdio>
int main(){
 unsigned char group[0x180]{},score[0x180]{},sibling[0x180]{},doc[64]{};memcpy(doc+9,"rfg_ui_hud_missions",sizeof("rfg_ui_hud_missions"));
 auto put=[](void* p,unsigned o,uintptr_t v){unsigned value=unsigned(v);memcpy((char*)p+o,&value,4);};
 put(group,0x24,vrmissiontracker::Group);put(group,0x28,(uintptr_t)doc);put(group,0x14,(uintptr_t)score);group[0x16c]=1;put(score,0x24,vrmissiontracker::Score);put(score,0x28,(uintptr_t)doc);put(score,0x1c,(uintptr_t)group);score[0x16c]=1;
 assert(vrmissiontracker::active(group));assert(!vrmissiontracker::active(score));group[0x16c]=0;assert(!vrmissiontracker::active(group));group[0x16c]=1;score[0x16c]=0;assert(!vrmissiontracker::active(group));score[0x16c]=1;
 put(score,0x28,77);assert(!vrmissiontracker::active(group));put(score,0x28,(uintptr_t)doc);put(score,0x1c,(uintptr_t)sibling);assert(!vrmissiontracker::active(group));put(score,0x1c,(uintptr_t)group);
 doc[9]='x';assert(!vrmissiontracker::active(group));doc[9]='r';put(score,0x18,(uintptr_t)score);assert(!vrmissiontracker::active(group));put(score,0x18,0);assert(vrmissiontracker::active(group));
 vrhudlayout::Profiles profiles(false);profiles.foot.item[vrhudlayout::Timer]={{.02f,-.04f,0},1.2f};profiles.vehicle.item[vrhudlayout::Timer]={{-.04f,-.08f,0},.8f};profiles.vehicle.item[vrhudlayout::Map].scale=1.3f;RFGRPose map{},hand{};map.orientation[3]=1;
 for(bool vehicle:{false,true}){auto& layout=profiles.select(vehicle);float x=256,y=0,w=256,h=64;layout.rect(vrhudlayout::Timer,map,hand,x,y,w,h);float oldX=x,oldY=y,oldW=w,oldH=h,width=0,height=0;vrarm::V offset{};
  assert(vrmissiontracker::aboveTimer(x,y,w,h,layout.item[vrhudlayout::Map].scale,offset,width,height));float unit=.17f/512*layout.item[vrhudlayout::Map].scale;float timerTop=(512-y)*unit;
  assert(fabsf(offset.x-(x+w*.5f-384)*unit)<.000001f);assert(offset.y-height*.5f>timerTop);assert(fabsf(offset.y-height*.5f-timerTop-h*.125f*unit)<.000001f);assert(fabsf(width/height-4)<.00001f);assert(x==oldX&&y==oldY&&w==oldW&&h==oldH);
 }
 vrarm::V offset{};float width=0,height=0;assert(!vrmissiontracker::aboveTimer(0,NAN,256,64,1,offset,width,height));assert(!vrmissiontracker::aboveTimer(0,0,256,64,0,offset,width,height));
 puts("PASS: verified destruction group/document ownership, visibility, cycle rejection, and above-clock geometry for walking/vehicle layouts without moving clock.");
}
