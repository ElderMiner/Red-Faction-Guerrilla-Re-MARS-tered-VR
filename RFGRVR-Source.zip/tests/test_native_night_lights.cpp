#include "../src/native_night_lights.h"
#include <cassert>
static bool enabled=true;
extern "C" bool RFGRVR_HeadCam_Enabled(){return enabled;}
static unsigned calls=0,ambientCalls=0;static float received[4];static const float* inputExpected;
static uintptr_t __fastcall NativeColour(void*,void*,float* out,float scale){++calls;for(int i=0;i<12;++i)out[i]=(i+1)*scale;return 0x12345678;}
static void __fastcall NativeAmbient(void*,void*,const float* color){++ambientCalls;memcpy(received,color,16);assert(color!=inputExpected);
 __asm {xor ecx,ecx}
 __asm {xor edx,edx}
 __asm {xorps xmm6,xmm6}
 __asm {xorps xmm7,xmm7}
}
static uintptr_t __fastcall NativeGeometry(void* self,void*,float* output,const float* origin){assert(self==(void*)0x12345678&&output==(float*)0x23456789&&origin==(float*)0x34567890);
 __asm {xorps xmm6,xmm6}
 __asm {xorps xmm7,xmm7}
 return 0x65432109;
}
static void geometryTest(){vrnightlights::geometry=(vrnightlights::Geometry)&NativeGeometry;float input[4]={1,2,3,4},six[4],seven[4];uintptr_t before,after,result;void* entry=(void*)&vrnightlights::geometryEntry;
 __asm {
 mov before,esp
 movups xmm6,input
 movups xmm7,input
 push 0x34567890
 push 0x23456789
 mov ecx,0x12345678
 call entry
 mov result,eax
 mov after,esp
 movups six,xmm6
 movups seven,xmm7
 }
 assert(before==after&&result==0x65432109&&!memcmp(six,input,16)&&!memcmp(seven,input,16));
}
int main(){geometryTest();using namespace vrnightlights;unsigned char scene[0x134]{},light[0x120]{},other[0x120]{};void* root=scene;sceneRoot=&root;*(void**)(scene+0x12c)=light;colour=(Colour)NativeColour;front=back=(Ambient)NativeAmbient;
 float out[12];vrnight::Plan plan;plan.mainLight=0;plan.ambient=.25f;
 {vrnight::Frame frame(plan);Colour volatile entry=(Colour)&onColour;uintptr_t before,after;
 __asm mov before,esp
 auto result=entry(light,out,2);
 __asm mov after,esp
 assert(before==after&&result==0x12345678&&out[0]==0&&out[1]==0&&out[2]==0&&out[3]==8&&out[11]==24);
 entry(other,out,2);assert(out[0]==2&&out[2]==6);*(unsigned*)(light+0xc8)=1;entry(light,out,2);assert(out[0]==2);*(unsigned*)(light+0xc8)=0;
 enabled=false;entry(light,out,2);assert(out[0]==2);enabled=true;
 *(void**)(scene+0x130)=other;entry(light,out,2);assert(out[0]==2);entry(other,out,2);assert(out[0]==0);*(void**)(scene+0x130)=nullptr;
 float input[4]={4,8,12,16};inputExpected=input;Ambient volatile a=(Ambient)&onFront,b=(Ambient)&onBack;
 __asm mov before,esp
 a(scene,input);b(scene,input);
 __asm mov after,esp
 assert(before==after&&ambientCalls==2&&received[0]==1&&received[2]==3&&received[3]==16&&input[0]==4);
 // Reproduce the production caller's retained registers, not merely stack ABI.
 unsigned savedC=0,savedD=0;float retained6[4],retained7[4];
 void* ambientEntry=(void*)&frontEntry;const float* source=input;
 __asm {
  mov ecx,0x12345678
  mov edx,0x23456789
  movups xmm6,input
  movups xmm7,input
  push source
  call ambientEntry
  mov savedC,ecx
  mov savedD,edx
  movups retained6,xmm6
  movups retained7,xmm7
 }
 assert(savedC==0x12345678&&savedD==0x23456789&&!memcmp(retained6,input,16)&&!memcmp(retained7,input,16));
 ambientEntry=(void*)&backEntry;
 __asm {
  mov ecx,0x12345678
  mov edx,0x23456789
  movups xmm6,input
  movups xmm7,input
  push source
  call ambientEntry
  mov savedC,ecx
  mov savedD,edx
  movups retained6,xmm6
  movups retained7,xmm7
 }
 assert(savedC==0x12345678&&savedD==0x23456789&&!memcmp(retained6,input,16)&&!memcmp(retained7,input,16));
 }
 onColour(light,nullptr,out,2);assert(out[0]==2);assert(calls==7&&mainWrites==2);for(unsigned char v:light)assert(v==0);
 puts("PASS native night light: real callback ABI, selected directional light only, zero intensity, untouched alpha/attenuation, private ambient RGB and day/Standard passthrough");
}
