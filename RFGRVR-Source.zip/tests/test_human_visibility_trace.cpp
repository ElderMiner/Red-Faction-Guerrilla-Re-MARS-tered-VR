#include "../src/vr_human_visibility_trace.h"
#include <cassert>
#include <array>
using namespace RFGRVRHumanVisibility;
template<size_t N> void put(std::array<unsigned char,N>& out,size_t offset,unsigned value){memcpy(out.data()+offset,&value,4);}
int main(){
 std::array<unsigned char,0xc0> human{},item{},other{};
 std::array<unsigned char,0x134> render{},itemRender{};
 std::array<unsigned char,96> palette{};
 put(human,0x34,(unsigned)item.data());put(item,0x70,123);put(item,0x38,(unsigned)item.data());put(item,0xac,(unsigned)itemRender.data());
 put(render,0x124,(unsigned)palette.data());
 auto originalHuman=human,originalItem=item;auto originalRender=render,originalItemRender=itemRender;auto originalPalette=palette;
 Row a{};a.handle=123;a.bones=2;poseState(human.data(),render.data(),a);
 assert(a.attachments==1&&a.paletteHash&&a.rootHash&&a.attachmentHash);
 assert(human==originalHuman&&item==originalItem&&render==originalRender&&itemRender==originalItemRender&&palette==originalPalette);
 palette[47]=1;Row b{};b.handle=123;b.bones=2;poseState(human.data(),render.data(),b);
 assert(a.paletteHash!=b.paletteHash&&a.rootHash==b.rootHash&&a.attachmentHash==b.attachmentHash);
 itemRender[20]=1;Row c{};c.handle=123;c.bones=2;poseState(human.data(),render.data(),c);assert(c.attachmentHash!=b.attachmentHash);
 put(item,0x70,999);Row foreign{};foreign.handle=123;foreign.bones=10000;poseState(human.data(),render.data(),foreign);assert(!foreign.attachments&&!foreign.attachmentHash&&!foreign.paletteHash);
 assert(hash(nullptr,48)==0);
 puts("PASS read-only NPC draw/attachment trace: palette changes, bounded circular traversal, foreign-parent rejection and no source writes");
}
