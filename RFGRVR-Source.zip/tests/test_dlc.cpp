#include "../src/vr_dlc.h"
#include "../src/vr_dlc_arsenal.h"
#include "../src/vr_turret_mount_kind.h"
#include "../src/vr_turret_rig.h"
#include <cassert>
#include <cstdio>
int main(){
 const char dlc[]="dlc01_07_09.rfgzone_pc";
 assert(vrdlc::territory(dlc,sizeof(dlc)));
 assert(!vrdlc::territory("tharsis.rfgzone_pc",18));
 assert(!vrdlc::territory("dlc01_weapon",13));
 assert(!vrdlc::territory(dlc,sizeof(dlc)-1));
 assert(!vrdlc::territory(nullptr,64));
 vrdlc::Keys keys;
 assert(keys.edges(false,1)==0);assert(keys.edges(true,1)==0);
 assert(keys.edges(true,0)==0);assert(keys.edges(true,1)==1);
 assert(keys.edges(true,1)==0);assert(keys.edges(true,2)==2);
 assert(keys.edges(false,0)==0);assert(keys.edges(true,4)==4);
 // A saturated list from the old test grant must retain real/unknown items,
 // flags and order while freeing space for the missing handheld definitions.
 vrdlc::ArsenalRecord records[64]{};for(unsigned i=0;i<64;++i)records[i]={i,1,{2,3,4}};
 unsigned kept=vrdlc::compactAccidental(records,64,[](unsigned id){return id>=4&&vrdlc::accidentalGrant("turret_mg_vehicle","generic_inventory_item");});
 assert(kept==4);for(unsigned i=0;i<kept;++i)assert(records[i].id==i&&records[i].enabled==1&&records[i].padding[2]==4);
 assert(vrdlc::compactAccidental(records,kept,[](unsigned){return false;})==kept);
 for(auto* name:{"edf_subverter","missilepod","pickaxe","royal_sword","spiker","EDF_Super_Gauss"})assert(vrdlc::testingHandheld(name));
 assert(!vrdlc::testingHandheld("turret_missilepod")&&!vrdlc::testingHandheld("rpg_launcher_debug"));
 assert(vrdlc::accidentalGrant("ab_rpg","ab_rpg")&&!vrdlc::accidentalGrant("unknown_story_weapon","unknown_story_item"));
 assert(RFGRVR_StandingVehicleTurret("turret_stomper_mg"));assert(RFGRVR_StandingVehicleTurret("turret_vehicle_raider_harpoon"));assert(!RFGRVR_StandingVehicleTurret("turret_mg_vehicle"));
 vrarm::M basis{{1,0,0},{0,1,0},{0,0,1}};vrarm::Pose mount{basis,{10,3,20}};vrarm::V rear{10,3,19.2f},hand{0,1,0};RFGRVRTurretRig platform;
 assert(platform.update(91,mount,rear,hand,0,1,0,.016f,-3.15f,3.15f,-1,1,nullptr,true,0,0,.5f,RFGRVR_StandingVehicleTurret("turret_stomper_mg")));
 assert(vrarm::length(vrarm::sub(platform.body.p,rear))<.0001f);
 hand.y+=.3f;platform.update(91,mount,rear,hand,0,1,0,.016f,-3.15f,3.15f,-1,1,nullptr,true,0,0,.5f,true);assert(vrarm::length(vrarm::sub(platform.body.p,rear))<.0001f);
 puts("PASS DLC territory validation and focus/campaign-transition key edges");
}
