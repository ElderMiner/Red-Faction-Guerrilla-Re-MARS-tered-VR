#define RFGR_TEST_USER_SETTINGS
static bool testLandingRecovery=false;
extern "C" void RFGRVR_HeadCam_AdjustDlcEye(int,int){}
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
static ULONGLONG ArmTestTick(){return 1000000;}
#define GetTickCount64 ArmTestTick
#define RFGR_WRIST_STATUS_TEST
#define RFGR_TEST_WEAPON_HUD_CHANNELS
#include "../src/native_arms.cpp"
#include <cassert>
static void* localPlayerForTest=nullptr;
extern "C" bool RFGRVR_HeadCam_IsLocalPlayer(void* p){return p&&p==localPlayerForTest;}
extern "C" float RFGRVR_Arms_TurretGripLever(unsigned);
extern "C" void RFGRVR_CapturePrimary();
extern "C" void RFGRVR_CaptureSupport();
extern "C" float RFGRVR_HeadCam_BodyYaw(){return 0;}
extern "C" bool RFGRVR_HeadCam_Enabled(){return true;}
static float testSeatHeight=0;static bool testGunAvailable=false;static vrarm::Pose testGunPose{};
static bool testMounted=false;static vrarm::Pose testMountRoot{};extern "C" bool RFGRVR_HeadCam_TurretRenderRoot(void*,vrarm::Pose* p){if(!testMounted)return false;*p=testMountRoot;return true;}
static float testWorldScale=1;extern "C" float RFGRVR_HeadCam_WorldScale(){return testWorldScale;}
extern "C" void RFGRVR_HeadCam_AvatarEye(void*,const float[3]){}
static bool muzzleAvailable=true;static unsigned writes=0;static unsigned char gun[0x300]{};
static void __fastcall Set(void* self,void*,int index,const V* p,const M* b){++writes;auto* output=(Pose*)pointer(self,4);output[index]={*b,*p};((Pose*)pointer(self,0))[index]=output[index];}
static bool probeDuringLookup=false;static void* __fastcall Find(void*,void*,unsigned){if(probeDuringLookup){assert(controlling);unsigned before=writes;OnSkin(commandedInstance.load(),nullptr,nullptr,nullptr);assert(writes>before);}return gun;}
static void __fastcall MuzzleOriginal(void*,void*,V* p,M* m){if(p)*p={.8f,1.4f,.5f};if(m)*m=muzzleAvailable?M{{1,0,0},{0,1,0},{0,0,1}}:M{};}
static void __fastcall FireOriginal(void*,void*,V* p,V* d,V* muzzle){*p={77,0,0};*d={0,0,1};*muzzle=*p;}
static void __fastcall Move(void* self,void*,const V* p,const M* b,bool){memcpy((char*)self+4,p,12);memcpy((char*)self+0x10,b,36);}
static unsigned char renderedGunEntity[0x200]{};static Pose& renderedWeapon=*(Pose*)(renderedGunEntity+8);static unsigned visualCalls=0;
static void __fastcall VisualOriginal(void* weapon,void*,void* renderer){assert(renderer==(void*)0x21);++visualCalls;if((word(weapon,0xb8)&255u)==1){auto* entity=(char*)pointer(weapon,0xac);unsigned flags=word(entity,0x40);flags=(word(weapon,0x54)&0x00800000u)?flags&~2u:flags|2u;memcpy(entity+0x40,&flags,2);}auto* target=(Pose*)((char*)pointer(weapon,0xac)+8);memcpy(&target->p,(char*)weapon+4,12);memcpy(&target->b,(char*)weapon+0x10,36);}
static unsigned visibilityRemovals=0;static void __fastcall Visibility(void* entity,void*,bool visible){assert(!visible);++visibilityRemovals;unsigned short flags=(unsigned short)word(entity,0x40)|2;memcpy((char*)entity+0x40,&flags,2);}
static bool __fastcall GripTag(void* weapon,void*,int tag,V* p,M* b,const V* overrideP,const M* overrideB){assert((tag==3||tag==0||tag==4)&&overrideP&&overrideB);Pose root{*overrideB,*overrideP};if(tag==4){*p=add(root.p,world(root.b,{.05f,-.07f,.02f}));*b=root.b;}else if(tag==0){*p=add(root.p,world(root.b,{0,0,.5f}));*b=root.b;}else{*p=add(root.p,world(root.b,{.03f,.01f,-.1f}));*b=compose(root.b,M{{0,0,-1},{0,1,0},{1,0,0}});}return true;}
static unsigned paletteCopies=0;static void __fastcall CopyRenderablePalette(void* self,void*,const Pose* source,unsigned count){++paletteCopies;memcpy(pointer(self,0x124),source,count*48);*(unsigned*)((char*)self+0x128)=count;}
static void* liveSkin=nullptr;static void* liveModel=nullptr;static void* liveInstance=nullptr;static bool privateBuildObserved=false;
static unsigned skinCalls=0,worldCalls=0;static Pose* worldModel=nullptr;
static void __fastcall BuildOriginal(void* self,void*,void*,void*){++skinCalls;auto* output=(Pose*)pointer(self,4);auto* destination=(Pose*)pointer(self,0);Pose before{};if(liveSkin)before=((Pose*)liveSkin)[8];memcpy(destination,output,12*48);
 if(self!=liveInstance&&liveInstance){assert(destination!=liveSkin&&output!=liveModel);assert(!memcmp(&before,&((Pose*)liveSkin)[8],48));privateBuildObserved=true;}}
static Pose* __fastcall LocalOriginal(void*,void*,Pose* output,int bone){++worldCalls;int physical=bone<12?bone:bone==12?5:8;*output=worldModel[physical];if(bone>=12)output->p=add(output->p,world(output->b,{.02f,0,0}));return output;}

static void checkHeldHand(){auto& item=command.visual[0].pose;Pose localPose=binding.primaryWristLocal;char name[96]{};if(weaponTrimName(binding.weapon,name))localPose=weaponAlignments.primaryPose(name,localPose,gripAlignment[binding.hand],gripCenterInWrist[binding.hand]);Pose expected=vrgrip::worldPose(item,localPose);assert(length(sub(command.desired[binding.hand].p,expected.p))<.0001f&&length(sub(command.desired[binding.hand].b.r,expected.b.r))<.0001f);}
int main(){handPitchUpDegrees=weaponPitchDownDegrees=0;
 {WeaponBinding fixture{};fixture.rootInMuzzle=M{{1,0,0},{0,1,0},{0,0,1}};fixture.gripInRoot={.02f,.03f,.04f};fixture.muzzleFromGrip={0,0,.15f};Pose gun{turnAround(fixture.rootInMuzzle,{0,1,0},.7f),{4,5,6}};auto lowHeight=pistolLaserPose(gun,fixture,.6f),large=pistolLaserPose(gun,fixture,1.4f);assert(length(sub(lowHeight.p,large.p))<.000001f&&dot(lowHeight.b.f,gun.b.f)>.999f);gun.p.x+=2;auto moved=pistolLaserPose(gun,fixture,.6f);assert(fabsf(moved.p.x-lowHeight.p.x-2)<.000001f);}

 vrdlc::active=false;assert(&activeWeaponAlignments()==&baseWeaponAlignments);
 vrdlc::active=true;assert(&activeWeaponAlignments()==&dlcWeaponAlignments);
 vrdlc::active=false;
 {M base{{1,0,0},{0,1,0},{0,0,1}};Pose elbow{base,{0,0,0}},hand{base,{0,0,1}},cuff{base,{.1f,0,.9f}},turned=hand;turned.b=turnAround(base,{0,0,1},1.f);Pose out=cuffHelper(elbow,hand,cuff,elbow,turned);assert(fabsf(axialRoll(base,out.b,{0,0,1})-.5f)<.0001f);assert(length(sub(out.p,turnAround(cuff.p,{0,0,1},.5f)))<.0001f);assert(length(sub(elbow.b.r,base.r))<.0001f);}
 // A captured angled idle pose must not become the shoulder scaffold.
 {constexpr unsigned n=9;unsigned char refBones[n*36]{};int parents[n]={-1,0,0,1,2,3,4,5,6};
  const char* names[n]={"root","l-clavicle","r-clavicle","left-upper","right-upper","left-elbow","right-elbow","left-wrist","right-wrist"};
  M identity{{1,0,0},{0,1,0},{0,0,1}},angle=turnAround(identity,{0,1,0},.6f);
  V neutral[n]={{0,.93f,0},{-.04f,1.49f,-.016f},{.04f,1.49f,-.016f},{-.198f,1.465f,-.011f},{.198f,1.465f,-.011f},{-.3f,1.2f,0},{.3f,1.2f,0},{-.4f,1,0},{.4f,1,0}};
  Pose native[n],saved[n],result[n];for(unsigned i=0;i<n;++i){*(int*)(refBones+i*36)=(int)((intptr_t)names[i]-(intptr_t)(refBones+i*36));V inverse=mul(neutral[i],-1);memcpy(refBones+i*36+4,&inverse,12);native[i]={angle,add(V{.02f,.93f,-.02f},world(angle,sub(neutral[i],neutral[0])))};}
  memcpy(saved,native,sizeof(saved));int upper[2]={3,4};buildSolverReference(refBones,parents,n,upper,native,result);
  assert(length(sub(result[3].p,neutral[3]))<.00001f&&length(sub(result[4].p,neutral[4]))<.00001f);
  assert(fabsf(length(sub(native[5].p,native[3].p))-length(sub(result[5].p,result[3].p)))<.00001f);
  assert(!memcmp(saved,native,sizeof(saved)));
 }
 // A neutral torso is local to the rendered body; tracked hands retain their
 // world targets even if the character root turns between publication/draw.
 {ArmCommand c{};M identity{{1,0,0},{0,1,0},{0,0,1}};c.root={identity,{1,0,0}};
  c.pose[0]={identity,{0,1,0}};c.pose[1]=c.pose[0];c.rootRelative[0]=true;
  Pose moved{turnAround(identity,{0,1,0},.7f),{1.1f,0,.2f}};
  Pose body=commandBone(c,0,moved),hand=commandBone(c,1,moved);
  assert(length(sub(body.p,c.pose[0].p))<.00001f&&length(sub(body.b.f,identity.f))<.00001f);
  assert(length(sub(add(moved.p,world(moved.b,hand.p)),add(c.root.p,world(c.root.b,c.pose[1].p))))<.00001f);
 }
 // Hand anatomy defines grip axes independently from the activation pose.
 {unsigned char anatomyBones[8*36]{};Pose anatomy[8]{};for(auto& p:anatomy)p.b=M{{1,0,0},{0,1,0},{0,0,1}};
 const char* names[8]={"l-hand","l-finger1","l-finger4","l-handprop","r-hand","r-finger1","r-finger4","r-handprop"};
 for(int i=0;i<8;++i)*(int*)(anatomyBones+i*36)=(int)((intptr_t)names[i]-(intptr_t)(anatomyBones+i*36));
 for(int side=0;side<2;++side){int w=side*4;anatomy[w+1].p={0,.1f,.04f};anatomy[w+2].p={0,.1f,-.04f};anatomy[w+3].p={0,.05f,0};M a{},b{};V center{},center2{};assert(anatomicalGrip(anatomyBones,anatomy,8,side,w,a,center));M pointed=turnAround(M{{1,0,0},{0,1,0},{0,0,1}},{1,0,0},.5235987756f);M aligned=compose(pointed,a);assert(length(sub(world(aligned,{0,0,1}),pointed.f))<.0001f);
 M rotation{{0,0,-1},{0,1,0},{1,0,0}};for(int i=w;i<w+4;++i){anatomy[i].p=add(V{1,2,3},world(rotation,anatomy[i].p));anatomy[i].b=rotation;}
 assert(anatomicalGrip(anatomyBones,anatomy,8,side,w,b,center2));assert(length(sub(a.r,b.r))<.0001f&&length(sub(a.u,b.u))<.0001f&&length(sub(center,center2))<.0001f);}}

 unsigned char player[0xd00]{},character[0xa8]{},instance[0x410]{},rig[72]{},bones[12*36]{},map[200]{},inventory[28]{};
 Pose model[12]{},skin[12]{};worldModel=model;M identity{{1,0,0},{0,1,0},{0,0,1}};for(auto& p:model)p.b=identity;
 model[3].p={-.2f,1.4f,0};model[4].p={-.5f,1.4f,0};model[5].p={-.8f,1.4f,0};model[6].p={.2f,1.4f,0};model[7].p={.5f,1.4f,0};model[8].p={.8f,1.4f,0};model[9].p={.83f,1.4f,0};
 for(int i=0;i<12;++i){*(int*)(bones+i*36+28)=-1;map[12+i]=(char)i;}
 *(int*)(bones+4*36+28)=3;*(int*)(bones+5*36+28)=4;*(int*)(bones+7*36+28)=6;*(int*)(bones+8*36+28)=7;*(int*)(bones+9*36+28)=8;
 *(unsigned*)(map+4)=12;*(unsigned*)(rig+0x24)=12;*(void**)(rig+0x38)=bones;*(void**)(instance+0x18)=rig;*(void**)(instance+4)=model;*(void**)instance=skin;*(void**)(instance+0x124)=map;
 *(void**)(player+0x32c)=character;*(int*)(player+0xa6c)=5;*(int*)(player+0xa70)=8;*(int*)(player+0xa4c)=-1;memcpy(player+0x10,&identity,36);*(unsigned*)(player+0x6c)=7;
 *(void**)(player+0xc90)=inventory;*(unsigned*)(inventory+24)=1;*(unsigned*)(gun+0x13c)=7;V gunP{.8f,1.4f,0};memcpy(gun+4,&gunP,12);memcpy(gun+0x10,&identity,36);*(void**)(gun+0xac)=renderedGunEntity;void* gunTable[15]{};gunTable[12]=(void*)&Move;*(void***)gun=gunTable;
 localPlayerForTest=player;liveSkin=skin;liveModel=model;liveInstance=instance;installed=true;base=(unsigned char*)((uintptr_t)instance-0x35acbd0u);setBone=(SetBone)&Set;lookup=(Lookup)&Find;originalMuzzle=(Muzzle)&MuzzleOriginal;originalFire=(FireVectors)&FireOriginal;originalSkin=(SkinBuild)&BuildOriginal;originalLocal=(BoneLocal)&LocalOriginal;originalVisual=(VisualUpdate)&VisualOriginal;
 RFGRShared data{};data.version=RFGR_PROTOCOL;data.left.validFlags=data.right.validFlags=data.leftAim.validFlags=data.rightAim.validFlags=3;
 data.left.active=data.right.active=data.leftAim.active=data.rightAim.active=1;
 data.left.position[0]=-.4f;data.right.position[0]=.4f;data.left.position[1]=data.right.position[1]=1.25f;data.left.position[2]=data.right.position[2]=-.25f;
 data.left.orientation[1]=sinf(.3f);data.left.orientation[3]=cosf(.3f);data.right.orientation[3]=1;data.leftAim=data.left;data.rightAim=data.right;data.rightAim.orientation[1]=sqrtf(.5f);data.rightAim.orientation[3]=sqrtf(.5f);
 RFGRPose head{};head.position[1]=1.6f;float anchor[3]={0,1.6f,0},zero[4]={0,0,0,1};RFGRVR_Arms_Publish(&data,anchor,(float*)&identity,zero,&head);
 Pose scaledHand{};testWorldScale=1.2f;assert(poseWorld(data.right,head,{0,1.6f,0},identity,zero,scaledHand));assert(fabsf(scaledHand.p.x-.48f)<.00001f&&fabsf(scaledHand.p.z-.3f)<.00001f);testWorldScale=1;
 // Real game wrists are virtual weapon tags; resolve hand, elbow and shoulder across twist helpers.
 {static unsigned char tags[120]{};const char* names[12]={"", "", "", "l-upperarmtwist1", "l-foretwist", "l-hand", "r-upperarmtwist1", "r-foretwist", "r-hand", "", "", ""};
 for(int i=0;i<12;++i)*(int*)(bones+i*36)=(int)((intptr_t)names[i]-(intptr_t)(bones+i*36));
 Pose tagOffset{identity,{.02f,0,0}};memcpy(tags+4,&tagOffset,sizeof(tagOffset));memcpy(tags+64,&tagOffset,sizeof(tagOffset));
 *(unsigned*)(rig+0x30)=2;*(void**)(rig+0x3c)=tags;*(int*)(tags+52)=5;*(int*)(tags+60+52)=8;
 *(int*)(player+0xa6c)=12;*(int*)(player+0xa70)=13;*(int*)(player+0xa64)=3;*(int*)(player+0xa68)=6;
 int parents[12];for(int i=0;i<12;++i)parents[i]=*(int*)(bones+i*36+28);int w=-1,e=-1,u=-1;
 assert(armChain(player,rig,bones,parents,12,0,w,e,u)&&w==5&&e==4&&u==3);
 assert(armChain(player,rig,bones,parents,12,1,w,e,u)&&w==8&&e==7&&u==6);
 *(int*)(player+0xa6c)=5;*(int*)(player+0xa70)=8;
 }
 // Preflight cannot mutate animation before the explicit runtime gate.
 RFGRVR_Arms_Player(player);assert(writes==0&&!controlling);
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-controller-arms.enable");HANDLE file=CreateFileW(path,GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);assert(file!=INVALID_HANDLE_VALUE);CloseHandle(file);
 requestChecked=0;preflightChecked=0;RFGRVR_Arms_Player(player);DeleteFileW(path);assert(writes==0&&controlling);{Hands tracked{};assert(getHands(tracked));Pose visual{};assert(visualTarget(gun,visual));M muzzleBasis=compose(visual.b,relative(binding.rootInMuzzle,identity));assert(length(sub(muzzleBasis.f,tracked.aim[1].b.f))<.0001f);}OnSkin(instance,nullptr,nullptr,nullptr);assert(skinCalls==1&&writes>=7&&skinApplications==1&&privateBuildObserved);assert(length(sub(skin[8].p,{.4f,1.25f,.25f}))<.0001f);assert(length(sub(model[8].p,{.8f,1.4f,0}))<.0001f);
 // Held model hands follow the authored weapon-local grip, not independent aim/grip frames.
 checkHeldHand();
 // Native per-bone animation setters can run after the full skin builder.
 // Their model output must survive, but the skin must stay on the VR command.
 Pose nativeBefore=model[8],trackedBefore=skin[8];V walkingWrist{.9f,1.1f,.3f};M walkingRotation{{0,0,-1},{0,1,0},{1,0,0}};
 // Reproduce the competing writer: the unguarded engine setter visibly
 // replaces an already-correct skin with the walking animation target.
 Set(instance,nullptr,8,&walkingWrist,&walkingRotation);assert(length(sub(skin[8].p,trackedBefore.p))>.1f);model[8]=nativeBefore;skin[8]=trackedBefore;
 OnSetBone(instance,nullptr,8,&walkingWrist,&walkingRotation);
 assert(length(sub(model[8].p,walkingWrist))<.0001f&&length(sub(model[8].b.r,walkingRotation.r))<.0001f);
 assert(length(sub(skin[8].p,trackedBefore.p))<.0001f&&length(sub(skin[8].b.r,trackedBefore.b.r))<.0001f&&guardedBoneWrites==1);
 model[8]=nativeBefore;
 {unsigned char npc[0xd00]{};auto before=command.player;bool controlled=controlling;RFGRVR_Arms_Player(npc);assert(command.player==before&&controlling==controlled&&!eligible(npc));}
 // Legs remain native; an unrelated instance is never redirected.
 V nativeLeg{.2f,.3f,.4f};OnSetBone(instance,nullptr,0,&nativeLeg,&walkingRotation);assert(length(sub(skin[0].p,nativeLeg))<.0001f);
 // Weapon attachment queries use the controlled hand while retaining native tag offsets.
 auto attachmentCacheHits=vrmemory::hitTotal.load();Pose hand{};OnLocal(instance,nullptr,&hand,8);assert(worldCalls==1&&length(sub(hand.p,{.4f,1.25f,.25f}))<.0001f);assert(vrmemory::hitTotal.load()>attachmentCacheHits);
 Pose virtualHand{};OnLocal(instance,nullptr,&virtualHand,13);assert(length(sub(virtualHand.p,add(command.pose[8].p,world(command.pose[8].b,{.02f,0,0}))))<.0001f);
 // Animated backing bones cannot move an already published virtual hand tag.
 model[8].p={99,99,99};Pose stableTag{};OnLocal(instance,nullptr,&stableTag,13);assert(length(sub(stableTag.p,virtualHand.p))<.0001f);model[8]=command.pose[8];
 unsigned char otherInstance[8]{};Pose other{};OnLocal(otherInstance,nullptr,&other,8);assert(length(sub(other.p,model[8].p))<.0001f);
 probeDuringLookup=true;RFGRVR_Arms_Player(player);probeDuringLookup=false;
 // An overridden left wrist must not feed its rotation into the next frame.
 M stableLeft=command.pose[5].b;for(int i=0;i<16;++i){RFGRVR_Arms_Player(player);OnSkin(instance,nullptr,nullptr,nullptr);assert(length(sub(command.pose[5].b.r,stableLeft.r))<.0001f);assert(length(sub(command.pose[5].b.u,stableLeft.u))<.0001f);}
 // Walking animation cannot reintroduce arm swing or finger poses while
 // the hands are controlled. Torso/leg animation remains in the native model.
 {Pose savedFinger=model[9];Pose nativeWrist=model[8];for(float curl:{.2f,.6f}){Pose nativeFinger{turnAround(nativeWrist.b,nativeWrist.b.r,curl),add(nativeWrist.p,world(nativeWrist.b,{.04f,.02f,.01f}))};model[9]=nativeFinger;RFGRVR_Arms_Player(player);Pose expected=vrgrip::worldPose(command.pose[8],vrgrip::relativePose(nativeWrist,nativeFinger));assert(length(sub(command.pose[9].p,expected.p))<.0001f&&length(sub(command.pose[9].b.u,expected.b.u))<.0001f);}model[9]=savedFinger;RFGRVR_Arms_Player(player);}
 Pose animationBefore[12];memcpy(animationBefore,model,sizeof(model));Pose controlledForearm=command.pose[7],controlledFinger=command.pose[9];model[7].p.y+=.2f;model[7].b={{0,0,-1},{0,1,0},{1,0,0}};model[9].p.x+=.12f;model[3].p.y+=.15f;model[6].p.z+=.1f;RFGRVR_Arms_Player(player);assert(length(sub(command.pose[7].p,controlledForearm.p))<.0001f&&length(sub(command.pose[9].p,controlledFinger.p))<.0001f);memcpy(model,animationBefore,sizeof(model));
 // Locomotion also translates spine2. That must not feed either shoulder
 // or elbow while the controller targets and body root are unchanged.
 const char* spineName="spine2";*(int*)(bones+10*36)=(int)((intptr_t)spineName-(intptr_t)(bones+10*36));
 RFGRVR_Arms_Player(player);ArmCommand beforeSpine=command;
 model[10].p=add(model[10].p,{.04f,.10f,.16f});RFGRVR_Arms_Player(player);
 for(int bone=3;bone<=9;++bone){assert(length(sub(command.pose[bone].p,beforeSpine.pose[bone].p))<.0001f);assert(length(sub(command.pose[bone].b.r,beforeSpine.pose[bone].b.r))<.0001f);}
 assert(length(sub(model[10].p,animationBefore[10].p))>.1f);memcpy(model,animationBefore,sizeof(model));
 {auto prior=weaponRecoil;weaponRecoil.weapon=(uintptr_t)gun;weaponRecoil.handle=word(gun,0x6c);weaponRecoil.tick=GetTickCount64();weaponRecoil.climb=.2f;RFGRVR_Arms_Player(player);V origin{},direction{},muzzle{};OnFire(gun,nullptr,&origin,&direction,&muzzle);M wanted=compose(command.visual[0].pose.b,relative(binding.rootInMuzzle,identity));assert(length(sub(direction,wanted.f))<.0001f);assert(dot(direction,hands.aim[1].b.f)<.999f);weaponRecoil=prior;RFGRVR_Arms_Player(player);}
 V origin{},direction{},muzzle{};OnFire(gun,nullptr,&origin,&direction,&muzzle);Pose expectedFire=firingPose(gun,hands,binding);assert(length(sub(direction,expectedFire.b.f))<.0001f);assert(length(sub(origin,muzzle))<.001f);
 // Late visual attachment consumes the current hand without moving the
 // simulation weapon or invoking its physics movement method.
 V simulationGun;M simulationBasis;memcpy(&simulationGun,gun+4,12);memcpy(&simulationBasis,gun+0x10,36);
 unsigned renderSkinBefore=skinApplications;RFGRVR_Arms_RenderWeapon((void*)0x21);assert(skinApplications==renderSkinBefore+1);Hands trackedHands{};assert(getHands(trackedHands));assert(visualCalls==1);
 assert(length(sub(add(renderedWeapon.p,world(renderedWeapon.b,binding.gripInRoot)),trackedHands.grip[1].p))<.0001f);
 assert(!memcmp(gun+4,&simulationGun,12)&&!memcmp(gun+0x10,&simulationBasis,36));
 // Gun and circular child list share a single render-only transform packet.
 unsigned char magazine[0x300]{},magEntity[0x200]{},magAttach[64]{};*(void**)(magazine+0x48)=magAttach;*(int*)(magAttach+4)=4;*(int*)(magAttach+8)=-1;gunTable[14]=(void*)&GripTag;*(unsigned*)(gun+0x6c)=45;*(void**)(gun+0x34)=magazine;*(void**)(magazine+0x38)=magazine;*(unsigned*)(magazine+0x70)=45;magazine[0x7e]=1;*(void**)(magazine+0xac)=magEntity;
 Pose magNative{identity,add(simulationGun,{.9f,.8f,.7f})};memcpy(magazine+4,&magNative.p,12);memcpy(magazine+0x10,&magNative.b,36);
 ArmCommand savedCommand=command,assembly=command;assembly.visualCount=0;Pose targetGun{{{0,0,-1},{0,1,0},{1,0,0}},{2,3,4}};queueVisuals(assembly,gun,targetGun);assert(assembly.visualCount==2);command=assembly;watchedVisuals[0]=gun;watchedVisuals[1]=magazine;watchedVisuals[2]=nullptr;
 RFGRVR_Arms_RenderWeapon((void*)0x21);Pose magRendered{};memcpy(&magRendered,magEntity+8,48);assert(length(sub(magRendered.p,add(targetGun.p,world(targetGun.b,{.05f,-.07f,.02f}))))<.0001f);assert(!memcmp(gun+4,&simulationGun,12)&&!memcmp(magazine+4,&magNative.p,12));
 // Hiding must call native spatial removal, not only write the hidden flag.
 renderVisibility=(RenderVisibility)Visibility;RFGRVRWeaponPhysics::Reload::visual.source={magazine,word(magazine,0x6c)};RFGRVRWeaponPhysics::Reload::visual.removed=true;RFGRVRWeaponPhysics::Reload::visual.tick=GetTickCount();
 OnVisual(magazine,nullptr,(void*)0x21);assert(visibilityRemovals==1&&(word(magEntity,0x40)&2));RFGRVRWeaponPhysics::Reload::visual={};renderVisibility=nullptr;
 // Held item compensation changes no dimensions or simulation transform.
 {Pose before=*(Pose*)(magEntity+8);vrworldview::draw={.02f,0,0};OnVisual(magazine,nullptr,(void*)0x21);Pose after=*(Pose*)(magEntity+8);assert(fabsf(after.p.x-before.p.x-.02f)<.0001f&&length(sub(after.b.r,before.b.r))<.0001f&&!memcmp(magazine+4,&magNative.p,12));vrworldview::draw={};OnVisual(magazine,nullptr,(void*)0x21);}
 // Rocket-hand and guide retain original render scale and saved pose.
 RFGRVRWeaponPhysics::Reload::visual.rocket=true;RFGRVRWeaponPhysics::Reload::visual.held={magazine,word(magazine,0x6c)};RFGRVRWeaponPhysics::Reload::visual.tick=GetTickCount();OnVisual(magazine,nullptr,(void*)0x21);Pose doubled{};memcpy(&doubled,magEntity+8,48);assert(fabsf(length(doubled.b.r)-1)<.0001f&&length(sub(doubled.p,magRendered.p))<.0001f&&!memcmp(magazine+4,&magNative.p,12));RFGRVRWeaponPhysics::Reload::visual={};OnVisual(magazine,nullptr,(void*)0x21);
 // A moving animated clip tag must not move the seated magazine relative to its receiver.
 *(unsigned*)(magazine+0xe4)=1;Pose seated=fixedMagazinePose(gun,magazine,targetGun,magRendered);Pose animated=magRendered;animated.p.x+=.2f;animated.b=turnAround(animated.b,animated.b.r,.5f);
 Pose stable=fixedMagazinePose(gun,magazine,targetGun,animated);assert(length(sub(stable.p,seated.p))<.0001f&&length(sub(stable.b.u,seated.b.u))<.0001f);
 Pose translated=targetGun;translated.p.x+=1;stable=fixedMagazinePose(gun,magazine,translated,animated);assert(fabsf(stable.p.x-seated.p.x-1)<.0001f);*(unsigned*)(magazine+0xe4)=0;
 // Reproduce save-load clip initialization: zero/fallback must not pin the
 // EDF pistol magazine at the root before its native tag becomes available.
 for(const char* weaponName:{"edf_pistol","edf_assault_rifle","shotgun","sniper","railgun","grinder"}){unsigned char pistol[0x200]{},clip[0x100]{},info[0x240]{};char pistolName[96]{};strcpy_s(pistolName,weaponName);*(void**)(pistol+0x148)=info;*(void**)info=pistolName;*(unsigned*)(pistol+0x6c)=101;*(unsigned*)(clip+0x6c)=102;*(unsigned*)(clip+0xe4)=1;
  Pose root{identity,{10,20,30}},well{identity,add(root.p,{0,.048f,.153f})};
  fixedMagazinePose(pistol,clip,root,root,true);fixedMagazinePose(pistol,clip,root,root,false);
  Pose seated=fixedMagazinePose(pistol,clip,root,well,true);assert(length(sub(seated.p,well.p))<.00001f);
  Pose transient=well;transient.p.y+=.25f;Pose stable=fixedMagazinePose(pistol,clip,root,transient,true);assert(length(sub(stable.p,well.p))<.00001f);
  // Reused addresses with different object handles must acquire a fresh mount.
  *(unsigned*)(pistol+0x6c)=103;Pose other=well;other.p.z+=.04f;stable=fixedMagazinePose(pistol,clip,root,other,true);assert(length(sub(stable.p,other.p))<.00001f);
  for(auto& entry:magazineMounts)if(entry.parent==pistol)entry={};
 }
 // A later ordinary component update must keep that same published root.
 OnVisual(magazine,nullptr,(void*)0x21);assert(!memcmp(&magRendered,magEntity+8,48));unsigned nativeCalls=visualCalls;OnVisual(magazine,nullptr,(void*)0x21);assert(visualCalls==nativeCalls);*(float*)(magazine+0xc0)=.5f;OnVisual(magazine,nullptr,(void*)0x21);assert(visualCalls==nativeCalls+1&&!memcmp(&magRendered,magEntity+8,48));*(unsigned*)(magazine+0x6c)=99;Pose rejected{};assert(!visualTarget(magazine,rejected));*(unsigned*)(magazine+0x6c)=0;command=savedCommand;watchedVisuals[1]=nullptr;*(void**)(gun+0x34)=nullptr;gunTable[14]=nullptr;
 // Native parent/child grip tags define alignment without sampling a VR hand
 // against a weapon position from an earlier simulation update.
 unsigned char attachmentInfo[64]{};*(void**)(gun+0x48)=attachmentInfo;*(int*)(attachmentInfo+4)=8;*(int*)(attachmentInfo+8)=3;gunTable[14]=(void*)&GripTag;
 WeaponBinding gripBinding=binding;bindNativeGrip(gripBinding,gun,rig,model,12,8);assert(length(sub(gripBinding.gripInRoot,{.03f,.01f,-.1f}))<.0001f);M expectedWrist=compose(gripBinding.rootInMuzzle,M{{0,0,-1},{0,1,0},{1,0,0}});assert(length(sub(gripBinding.wristInMuzzle.r,expectedWrist.r))<.0001f);*(int*)(attachmentInfo+4)=13;bindNativeGrip(gripBinding,gun,rig,model,12,8);
 M targetRootBasis=compose(trackedHands.aim[1].b,gripBinding.rootInMuzzle),targetWristBasis=compose(trackedHands.aim[1].b,gripBinding.wristInMuzzle);V rootPosition=sub(trackedHands.grip[1].p,world(targetRootBasis,gripBinding.gripInRoot));
 assert(length(sub(add(rootPosition,world(targetRootBasis,{.03f,.01f,-.1f})),trackedHands.grip[1].p))<.0001f);
 // A nonzero anatomical wrist-to-palm offset must not be subtracted a second
 // time from the gun. Reproduce the captured rifle's 9.5-cm lateral offset.
 binding={};gripCenterInWrist[1]={.095f,0,0};RFGRVR_Arms_Player(player);
 checkHeldHand();
 assert(binding.gripReady&&length(sub(add(command.visual[0].pose.p,world(command.visual[0].pose.b,binding.gripInRoot)),trackedHands.grip[1].p))<.0001f);
 gripCenterInWrist[1]={};binding={};RFGRVR_Arms_Player(player);
 // A weapon alignment changes the shared receiver pose; firing and effects
 // must derive from it, while controller hand targets stay unchanged.
 {Pose before=command.visual[0].pose;auto handsBefore=command.desired[1];RFGRVRChargeTrim trim;trim.rotation[0]=20;trim.position[0]=.04f;V anchor=add(before.p,world(before.b,binding.gripInRoot));command.visual[0].pose=trim.apply(before,before.b,binding.gripInRoot,anchor);Pose wanted=firingPose(gun,hands,binding);OnFire(gun,nullptr,&origin,&direction,&muzzle);assert(length(sub(direction,wanted.b.f))<.0001f&&length(sub(muzzle,wanted.p))<.0001f);assert(length(sub(command.desired[1].p,handsBefore.p))<.0001f);command.visual[0].pose=before;}
 // End-to-end support tag -> squeeze -> shared weapon pose -> muzzle.
 Hands beforeSupport=hands;*(int*)(gun+0x248)=4;binding={};RFGRVR_Arms_Player(player);assert(binding.supportReady);
 hands.grip[0].p=add(command.visual[0].pose.p,world(command.visual[0].pose.b,binding.supportLocal.p));hands.gripValue[0]=0;hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);
 gripCenterInWrist[1]={.03f,.02f,.01f};RFGRVR_Arms_Player(player);Pose mainBeforeGrab=command.desired[1];hands.gripValue[0]=1;RFGRVR_Arms_Player(player);assert(supportHold.active);checkHeldHand();
 // The last round starts a native action timer; it must not drop an
 // already-held support grip or require another grip squeeze afterwards.
 {auto savedShotTick=recoilShotTick.load();auto savedShotHandle=recoilShotHandle.load();recoilShotTick=0;recoilShotHandle=~0u;bool manual=RFGRVRWeaponPhysics::Reload::enabled;RFGRVRWeaponPhysics::Reload::enabled=true;auto priorExpired=expired;expired=nullptr;unsigned char info[32]{};*(unsigned*)(info+0xc)=2;void* priorInfo=pointer(gun,0x148);*(void**)(gun+0x148)=info;unsigned rounds=word(gun,0x20c),inventoryId=word(inventory,24);*(unsigned*)(inventory+24)=binding.handle;*(int*)(player+0xa4c)=100;*(unsigned*)(gun+0x20c)=1;assert(eligible(player));RFGRVRWeaponPhysics::Reload::enabled=false;assert(eligible(player));hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);assert(controlling.load()&&supportHold.active);RFGRVRWeaponPhysics::Reload::enabled=true;recoilShotHandle=binding.handle;recoilShotTick=GetTickCount64();assert(eligible(player));*(unsigned*)(player+0x338)|=1u<<13;assert(!eligible(player));*(unsigned*)(player+0x338)&=~(1u<<13);recoilShotTick=0;auto savedEntry=RFGRVRWeaponPhysics::Reload::entries[0];auto& managed=RFGRVRWeaponPhysics::Reload::entries[0];managed.weapon=gun;managed.handle=binding.handle;managed.owner=word(player,0x6c);assert(eligible(player));RFGRVRWeaponPhysics::Reload::entries[0]=savedEntry;*(unsigned*)(gun+0x20c)=0;RFGRVR_Arms_Player(player);assert(supportHold.active&&controlling.load());*(int*)(player+0xa4c)=-1;RFGRVR_Arms_Player(player);assert(supportHold.active);*(unsigned*)(gun+0x20c)=rounds;*(unsigned*)(inventory+24)=inventoryId;*(void**)(gun+0x148)=priorInfo;expired=priorExpired;RFGRVRWeaponPhysics::Reload::enabled=manual;recoilShotTick=savedShotTick;recoilShotHandle=savedShotHandle;}
 hands.grip[0].p.x+=.12f;RFGRVR_Arms_Player(player);Pose supported=command.visual[0].pose;checkHeldHand();
 assert(length(sub(command.desired[0].p,add(supported.p,world(supported.b,binding.supportLocal.p))))<.0001f);
 V supportedOrigin{},supportedDirection{},supportedMuzzle{};OnFire(gun,nullptr,&supportedOrigin,&supportedDirection,&supportedMuzzle);
 M supportedAim=compose(supported.b,relative(binding.rootInMuzzle,identity));assert(length(sub(supportedDirection,supportedAim.f))<.0001f);
 hands.gripValue[0]=0;RFGRVR_Arms_Player(player);assert(!supportHold.active&&length(sub(command.desired[0].p,hands.grip[0].p))<.0001f);
 // Numpad0 arms capture; a new offhand squeeze saves the actual local point
 // and stays attached on the following frame. File access is fully isolated.
 {auto* savedDB=new RFGRVRWeaponAlignments(weaponAlignments);bool savedReady=weaponTrimsReady;weaponAlignments={};weaponTrimsReady=true;char tempPath[MAX_PATH];GetTempPathA(MAX_PATH,tempPath);sprintf_s(weaponAlignments.path,"%scapture-test-%lu.ini",tempPath,GetCurrentProcessId());unsigned char captureInfo[0x240]{};const char* captureName="capture_test";memcpy(captureInfo,&captureName,4);*(unsigned*)(captureInfo+0x10)=7;void* savedInfo=pointer(gun,0x148);*(void**)(gun+0x148)=captureInfo;
  hands.gripValue[0]=0;RFGRVR_Arms_Player(player);hands.grip[0].p=add(command.visual[0].pose.p,world(command.visual[0].pose.b,{.02f,.03f,.35f}));RFGRVR_CaptureSupport();RFGRVR_Arms_Player(player);hands.gripValue[0]=1;RFGRVR_Arms_Player(player);assert(supportCapture.load()==~0u&&supportHold.active);auto* captured=weaponAlignments.find(captureName);assert(captured&&captured->supportAbsolute&&captured->supportOrientation);M capturedHand=compose(command.visual[0].pose.b,captured->supportFrame);assert(length(sub(capturedHand.r,hands.grip[0].b.r))<.0001f);hands.grip[0].p.x+=.08f;RFGRVR_Arms_Player(player);assert(supportHold.active);Pose authored=weaponAlignments.supportPose(captureName,binding.supportLocal);V fixedPoint=add(command.visual[0].pose.p,world(command.visual[0].pose.b,authored.p));V actualPoint=add(command.desired[0].p,world(command.desired[0].b,gripCenterInWrist[0]));V heldPoint=local(command.visual[0].pose.b,sub(actualPoint,command.visual[0].pose.p));assert(heldPoint.y<=authored.p.y+.0001f&&heldPoint.y>=authored.p.y-.5501f);M expectedSupportWrist=compose(command.visual[0].pose.b,compose(captured->supportFrame,gripAlignment[0]));V shaftAxis=world(command.visual[0].pose.b,unit(sub(authored.p,binding.gripInRoot)));assert(fabsf(dot(command.desired[0].b.u,shaftAxis)-dot(expectedSupportWrist.u,shaftAxis))<.0001f);checkHeldHand();hands.gripValue[0]=0;RFGRVR_Arms_Player(player);assert(!supportHold.active);hands.gripValue[1]=0;RFGRVR_CapturePrimary();RFGRVR_Arms_Player(player);assert(primaryPlacement.active);Pose frozenWeapon=command.visual[0].pose;hands.grip[1].p.x+=.08f;hands.grip[1].b=turnAround(hands.grip[1].b,{0,1,0},.3f);RFGRVR_Arms_Player(player);assert(length(sub(command.visual[0].pose.p,frozenWeapon.p))<.0001f&&primaryPlacement.active);hands.gripValue[1]=1;RFGRVR_Arms_Player(player);assert(!primaryPlacement.active&&weaponAlignments.find(captureName)->primaryCaptured);RFGRVR_Arms_Player(player);assert(length(sub(command.visual[0].pose.p,frozenWeapon.p))<.0001f);Pose beforeFine=command.visual[0].pose;V handBeforeFine=command.desired[1].p;RFGRVR_AdjustWeapon(0,false,1,false);RFGRVR_Arms_Player(player);assert(fabsf(length(sub(command.visual[0].pose.p,beforeFine.p))-.01f)<.0001f&&length(sub(command.visual[0].pose.b.r,beforeFine.b.r))<.0001f);assert(length(sub(command.desired[1].p,handBeforeFine))<.0001f);checkHeldHand();hands.gripValue[1]=0;
  // Actual left-hand sledge attachment: Numpad0 freezes the weapon and
  // captures the main LEFT hand, never the other/support hand.
  *(int*)(attachmentInfo+4)=5;binding={};hands.gripValue[0]=0;RFGRVR_Arms_Player(player);assert(binding.hand==0);
  captureZeroGrip(binding);RFGRVR_Arms_Player(player);assert(primaryPlacement.active&&supportCapture.load()==~0u);Pose leftFrozen=command.visual[0].pose;
  hands.grip[0].p.y+=.04f;hands.grip[0].b=turnAround(hands.grip[0].b,{0,1,0},.25f);RFGRVR_Arms_Player(player);assert(length(sub(command.visual[0].pose.p,leftFrozen.p))<.0001f);
  hands.gripValue[0]=1;RFGRVR_Arms_Player(player);assert(!primaryPlacement.active&&weaponAlignments.find(captureName)->primaryCaptured);RFGRVR_Arms_Player(player);assert(length(sub(command.visual[0].pose.p,leftFrozen.p))<.0001f);checkHeldHand();
  // Decimal explicitly edits RIGHT, even though this sledge is left-primary.
  hands.gripValue[1]=0;RFGRVR_Arms_Player(player);captureDecimalGrip(binding);RFGRVR_Arms_Player(player);assert(!primaryPlacement.active&&supportCapture.load()==binding.handle);
  hands.grip[1].p=add(command.visual[0].pose.p,world(command.visual[0].pose.b,{.02f,.03f,.35f}));hands.grip[1].b=turnAround(hands.grip[1].b,{0,0,1},.2f);hands.gripValue[1]=1;RFGRVR_Arms_Player(player);assert(supportCapture.load()==~0u&&weaponAlignments.find(captureName)->supportOrientation);
  *(int*)(attachmentInfo+4)=8;binding={};hands.gripValue[0]=hands.gripValue[1]=0;RFGRVR_Arms_Player(player);
  WritePrivateProfileStringA(nullptr,nullptr,nullptr,weaponAlignments.path);assert(DeleteFileA(weaponAlignments.path));weaponAlignments=*savedDB;delete savedDB;weaponTrimsReady=savedReady;*(void**)(gun+0x148)=savedInfo;}
 gripCenterInWrist[1]={};
 hands=beforeSupport;*(int*)(gun+0x248)=-1;binding={};RFGRVR_Arms_Player(player);
 // Pitch corrections move hands up and shooting direction down independently.
 handPitchUpDegrees=weaponPitchDownDegrees=12;weaponWeight={};RFGRVR_Arms_Player(player);Hands untrimmed=hands;
 M expectedHand=compose(turnAround(untrimmed.grip[1].b,untrimmed.grip[1].b.r,-12*.01745329252f),gripAlignment[1]);checkHeldHand();
 OnFire(gun,nullptr,&supportedOrigin,&supportedDirection,&supportedMuzzle);M expectedAim=turnAround(untrimmed.aim[1].b,untrimmed.aim[1].b.r,12*.01745329252f);assert(length(sub(supportedDirection,expectedAim.f))<.0001f);
 handPitchUpDegrees=weaponPitchDownDegrees=0;RFGRVR_Arms_Player(player);
 Hands beforeCross=hands;hands.grip[1].p={-.4f,1.2f,.2f};hands.grip[0].p={.4f,1.2f,.2f};RFGRVR_Arms_Player(player);
 // Crossing the torso must keep the two rigid segments equal in this fixture;
 // no sideways post-solve clamp may stretch one of them or displace the wrist.
 for(int first:{3,6}){float upperLength=length(sub(command.pose[first+1].p,command.pose[first].p)),lowerLength=length(sub(command.pose[first+2].p,command.pose[first+1].p));assert(finite(command.pose[first+1].p)&&fabsf(upperLength-lowerLength)<.001f);}
 assert(length(sub(command.pose[5].p,command.desired[0].p))<.0001f&&length(sub(command.pose[8].p,command.desired[1].p))<.0001f);
 checkHeldHand();hands=beforeCross;RFGRVR_Arms_Player(player);
 *(void**)(gun+0x48)=nullptr;gunTable[14]=nullptr;
 // A tool without a valid muzzle must retain tracked arms and attachments.
 muzzleAvailable=false;binding={};M attachedBeforeSwitch=command.pose[8].b;RFGRVR_Arms_Player(player);assert(controlling&&binding.weapon==gun);checkHeldHand();unsigned beforeTool=writes;OnSkin(instance,nullptr,nullptr,nullptr);assert(writes>beforeTool);muzzleAvailable=true;
 // Switching or corrupting weapon alignment must never rotate either wrist.
 M controllerWrist=command.desired[1].b,controllerLeft=command.desired[0].b;
 WeaponBinding beforeRotation=binding;binding.wristInMuzzle={{0,1,0},{-1,0,0},{0,0,1}};
 RFGRVR_Arms_Player(player);checkHeldHand();
 assert(length(sub(command.desired[0].b.r,controllerLeft.r))<.0001f);
 checkHeldHand();
 binding=beforeRotation;
 // Rebinding items while the native equip animation changes must not capture
 // a new hand orientation or reset the neutral arm reference.
 Pose stableRest=armRest.pose[8];Pose savedNativeHand=model[8];M savedGunBasis;memcpy(&savedGunBasis,gun+0x10,36);
 for(int change=0;change<8;++change){M equipBasis=change%2?identity:M{{0,0,-1},{0,1,0},{1,0,0}};model[8].b=equipBasis;memcpy(gun+0x10,&equipBasis,36);binding={};RFGRVR_Arms_Player(player);
 checkHeldHand();assert(!memcmp(&stableRest,&armRest.pose[8],48));}
 model[8]=savedNativeHand;memcpy(gun+0x10,&savedGunBasis,36);binding=beforeRotation;RFGRVR_Arms_Player(player);

 // C4 is attached to the native left hand (unlike rifles). Its root must
 // follow that wrist, not a hard-coded right-controller transform.
 *(void**)(gun+0x48)=attachmentInfo;*(int*)(attachmentInfo+4)=5;*(int*)(attachmentInfo+8)=3;gunTable[14]=(void*)&GripTag;binding={};RFGRVR_Arms_Player(player);
 assert(binding.hand==0&&command.visualCount==1);assert(length(sub(add(command.visual[0].pose.p,world(command.visual[0].pose.b,binding.gripInRoot)),command.desired[0].p))<.0001f);
 // Effects ask for item tags with no explicit root. They must use the same
 // published item transform; explicit intrinsic queries must remain unchanged.
 originalItemTag=(ItemTag)&GripTag;Pose flash{};bool tagged=OnItemTag(gun,nullptr,0,&flash.p,&flash.b,nullptr,nullptr);assert(tagged);Pose item=command.visual[0].pose;
 assert(length(sub(flash.p,add(item.p,world(item.b,{0,0,.5f}))))<.0001f);
 Pose explicitRoot{identity,{9,8,7}},explicitTag{};assert(OnItemTag(gun,nullptr,0,&explicitTag.p,&explicitTag.b,&explicitRoot.p,&explicitRoot.b));assert(length(sub(explicitTag.p,V{9,8,7.5f}))<.0001f);
 // Changing attachment hand in place invalidates the cached binding.
 *(int*)(attachmentInfo+4)=8;RFGRVR_Arms_Player(player);assert(binding.hand==1);
 *(void**)(gun+0x48)=nullptr;gunTable[14]=nullptr;binding=beforeRotation;RFGRVR_Arms_Player(player);
 // The right-hand C4 charge is a player sibling of the left-held placer,
 // rather than a child of the weapon. Both must enter the same pose packet.
 unsigned char charge[0x300]{},chargeAttach[64]{},chargeEntity[0x200]{};
 *(unsigned*)(gun+0x70)=7;*(void**)(player+0x34)=gun;*(void**)(gun+0x38)=charge;*(void**)(charge+0x38)=gun;*(unsigned*)(charge+0x70)=7;charge[0x7e]=1;*(void**)(charge+0x48)=chargeAttach;*(int*)(chargeAttach+4)=13;*(int*)(chargeAttach+8)=-1;*(void**)(charge+0xac)=chargeEntity;memcpy(charge+0x10,&identity,36);
 RFGRVR_Arms_Player(player);assert(command.visualCount==2&&command.visual[1].object==charge);Pose virtualGrip=command.pose[13];V chargeExpected=add(command.root.p,world(command.root.b,virtualGrip.p));assert(length(sub(command.visual[1].pose.p,chargeExpected))<.0001f);
 // Independent C4 calibration: Num0 owns left detonator, decimal right charge.
 {auto* savedDB=new RFGRVRWeaponAlignments(weaponAlignments);bool savedReady=weaponTrimsReady;weaponAlignments={};char tempPath[MAX_PATH];GetTempPathA(MAX_PATH,tempPath);sprintf_s(weaponAlignments.path,"%sc4-dual-capture-%lu.ini",tempPath,GetCurrentProcessId());weaponTrimsReady=true;
 void* savedInfo=pointer(gun,0x148);void* savedAttach=pointer(gun,0x48);unsigned char info[0x30]{};*(unsigned*)(gun+0x20c)=1;*(const char**)info="charge_placer";*(unsigned*)(info+0x10)=3;*(void**)(gun+0x148)=info;*(void**)(gun+0x48)=attachmentInfo;*(int*)(attachmentInfo+4)=5;*(int*)(attachmentInfo+8)=-1;binding={};hands.gripValue[0]=hands.gripValue[1]=0;RFGRVR_Arms_Player(player);
 assert(binding.hand==0&&command.visualCount==2&&!supportHold.active);Pose leftBefore=command.visual[0].pose;
 RFGRVR_CapturePrimary();RFGRVR_Arms_Player(player);assert(chargePlacement.active&&!primaryPlacement.active);Pose frozen=command.visual[1].pose;hands.grip[1].p.x+=.06f;hands.grip[1].b=turnAround(hands.grip[1].b,{0,1,0},.3f);RFGRVR_Arms_Player(player);assert(length(sub(command.visual[1].pose.p,frozen.p))<.0001f);hands.gripValue[1]=1;RFGRVR_Arms_Player(player);auto* right=weaponAlignments.find(chargeProfile);assert(right&&right->primaryCaptured&&!chargePlacement.active);assert(length(sub(command.visual[1].pose.p,frozen.p))<.0001f);assert(length(sub(command.visual[0].pose.p,leftBefore.p))<.0001f);
 RFGRVR_Arms_Player(player);assert(!supportHold.active&&length(sub(command.visual[1].pose.p,frozen.p))<.0001f);
 hands.tick=GetTickCount64();RFGRVR_CaptureSupport();RFGRVR_Arms_Player(player);assert(primaryPlacement.active&&!chargePlacement.active);hands.gripValue[0]=0;RFGRVR_Arms_Player(player);hands.gripValue[0]=1;RFGRVR_Arms_Player(player);assert(weaponAlignments.find("charge_placer")->primaryCaptured&&!primaryPlacement.active&&!supportHold.active);
 RFGRVRWeaponAlignments reload;strcpy_s(reload.path,weaponAlignments.path);assert(reload.find(chargeProfile)->primaryCaptured&&reload.find("charge_placer")->primaryCaptured);
 WritePrivateProfileStringA(nullptr,nullptr,nullptr,weaponAlignments.path);assert(DeleteFileA(weaponAlignments.path));weaponAlignments=*savedDB;delete savedDB;weaponTrimsReady=savedReady;*(void**)(gun+0x148)=savedInfo;*(void**)(gun+0x48)=savedAttach;binding={};hands=beforeSupport;RFGRVR_Arms_Player(player);}
 *(void**)(player+0x34)=nullptr;*(void**)(gun+0x38)=nullptr;RFGRVR_Arms_Player(player);
 // Charge status attaches to the inventory detonator, never its throwable
 // sibling. A non-charge weapon sends that panel back to the wrist map.
 {unsigned char info[32]{};const char* name="charge_placer";*(const char**)info=name;void* previousInfo=pointer(gun,0x148);*(void**)(gun+0x148)=info;
 hands.tick=GetTickCount64();Hands hudHands{};assert(getHands(hudHands));hudHands.sample=99;hudHands.physical[1].b=identity;armRest.body.spine=4;command.count=(std::max)(command.count,5u);command.pose[4].p={0,1.2f,0};M controllers[2]={hudHands.grip[0].b,hudHands.grip[1].b};publishWeaponHud(command,binding,hudHands,controllers);
 HANDLE map=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_WEAPON_HUD_POSE);assert(map);auto* packet=(RFGRWeaponHudPose*)MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(RFGRWeaponHudPose));assert(packet&&packet->charges.hand==binding.hand&&packet->ammo.hand==binding.hand);assert(packet->chestValid&&std::isfinite(packet->chestPosition[1]));
 *(const char**)info="mine_placer";*(unsigned*)(info+0x10)=4;supportHold.active=true;RFGRVR_Arms_Player(player);assert(!supportHold.active);assert(packet->supportHand==-1);*(unsigned*)(info+0x10)=0;
 *(const char**)info="rifle";publishWeaponHud(command,binding,hudHands,controllers);assert(packet->charges.hand==-1&&packet->ammo.hand==binding.hand);UnmapViewOfFile(packet);CloseHandle(map);*(void**)(gun+0x148)=previousInfo;}
 // Propane hands use the physical item's saved grip, while its weapon HUD hides.
 {RFGRVRWeaponPhysics::Propane::Visual p{};p.tick=GetTickCount();p.heldMask=1;p.stowed=word(gun,0x6c);p.hand[0]={identity,{-.2f,1.2f,.4f}};RFGRVRWeaponPhysics::Propane::visual=p;RFGRVRWeaponInput::propaneHeld=true;RFGRVRWeaponInput::propaneTick=GetTickCount();RFGRVR_Arms_Player(player);V palm=add(command.desired[0].p,world(command.desired[0].b,gripCenterInWrist[0]));assert(length(sub(palm,p.hand[0].p))<.0001f);
 HANDLE m=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_WEAPON_HUD_POSE);assert(m);auto* packet=(RFGRWeaponHudPose*)MapViewOfFile(m,FILE_MAP_READ,0,0,sizeof(RFGRWeaponHudPose));assert(packet&&packet->ammo.hand==-1&&(packet->supportHeld&1));UnmapViewOfFile(packet);CloseHandle(m);RFGRVRWeaponPhysics::Propane::visual={};RFGRVRWeaponInput::propaneHeld=false;RFGRVR_Arms_Player(player);}
 // The body renderer interpolates its root independently from Player.Position.
 // Keep the world-space hand at the controller target through those changes.
 unsigned char renderedBody[0x200]{};Pose bodyPalette[12]{};*(void**)(renderedBody+0x124)=bodyPalette;*(unsigned*)(renderedBody+0x120)=12;paletteCopy=(PaletteCopy)&CopyRenderablePalette;*(void**)(character+0x30)=renderedBody;
 Pose renderedRoot{identity,{.12f,0,.04f}};memcpy(renderedBody+8,&renderedRoot,48);
 RFGRVR_Arms_Player(player);Pose used{};assert(renderRoot(player,character,used));assert(length(sub(used.p,renderedRoot.p))<.0001f);
 Hands sample{};assert(getHands(sample));assert(length(sub(add(renderedRoot.p,world(renderedRoot.b,command.pose[8].p)),sample.grip[1].p))<.0001f);
 renderedRoot.p.x+=.08f;memcpy(renderedBody+8,&renderedRoot,48);RFGRVR_Arms_Player(player);assert(length(sub(add(renderedRoot.p,world(renderedRoot.b,command.pose[8].p)),sample.grip[1].p))<.0001f);
 // The rendered root can advance after target publication and between eyes.
 Pose nativeWrist=model[8];renderedRoot.p.x+=.07f;renderedRoot.b={{0,0,-1},{0,1,0},{1,0,0}};memcpy(renderedBody+8,&renderedRoot,48);
 OnSkin(instance,nullptr,nullptr,nullptr);assert(length(sub(add(renderedRoot.p,world(renderedRoot.b,skin[8].p)),sample.grip[1].p))<.0001f);assert(!memcmp(&nativeWrist,&model[8],48));
 Pose modelAtEyeBoundary=model[8];V lateAnimation{-.4f,.7f,.8f};OnSetBone(instance,nullptr,8,&lateAnimation,&identity);
 assert(length(sub(add(renderedRoot.p,world(renderedRoot.b,skin[8].p)),sample.grip[1].p))<.0001f);model[8]=modelAtEyeBoundary;
 unsigned rightSkinBefore=skinApplications;RFGRVR_Arms_RenderWeapon((void*)0x21);assert(skinApplications==rightSkinBefore+1&&length(sub(add(renderedRoot.p,world(renderedRoot.b,skin[8].p)),sample.grip[1].p))<.0001f);
 // The body has a separate draw palette: stale native source matrices must
 // be corrected at that handoff, not only in the animation instance.
 Pose staleSource[12];memcpy(staleSource,model,sizeof(staleSource));V bindOffset{.03f,-.02f,.01f};memcpy(bones+8*36+4,&bindOffset,12);
 OnPaletteCopy(renderedBody,nullptr,staleSource,12);Pose expectedModel=rebasePose(command.pose[8],command.root,renderedRoot);
 assert(length(sub(bodyPalette[8].p,add(expectedModel.p,world(expectedModel.b,bindOffset))))<.0001f);assert(!memcmp(&staleSource[8],&model[8],48));
 // Per-eye player compensation only translates the owned GPU palette.
 {Pose saved=bodyPalette[8];vrworldview::draw={.02f,-.01f,.005f};OnPaletteCopy(renderedBody,nullptr,staleSource,12);V delta=local(renderedRoot.b,vrworldview::draw);assert(length(sub(bodyPalette[8].p,add(saved.p,delta)))<.0001f&&length(sub(bodyPalette[8].b.r,saved.b.r))<.0001f);assert(!memcmp(&staleSource[8],&model[8],48));vrworldview::draw={};OnPaletteCopy(renderedBody,nullptr,staleSource,12);assert(length(sub(bodyPalette[8].p,saved.p))<.0001f);}
 // An unrelated/NPC renderable receives no local-player view correction.
 {unsigned char foreign[0x130]{};Pose source[2]={{identity,{1,2,3}},{identity,{4,5,6}}},target[2]{};*(void**)(foreign+0x124)=target;vrworldview::draw={.03f,0,0};OnPaletteCopy(foreign,nullptr,source,2);assert(!memcmp(source,target,sizeof(source)));vrworldview::draw={};}
 Pose cachedBefore=bodyPalette[8];renderedRoot.p.x+=.1f;memcpy(renderedBody+8,&renderedRoot,48);RFGRVR_Arms_RenderWeapon((void*)0x21);
 V recovered=sub(bodyPalette[8].p,world(bodyPalette[8].b,bindOffset));assert(length(sub(add(renderedRoot.p,world(renderedRoot.b,recovered)),sample.grip[1].p))<.0001f);assert(length(sub(cachedBefore.p,bodyPalette[8].p))>.09f);memset(bones+8*36+4,0,12);
 Pose attachment{};OnLocal(instance,nullptr,&attachment,8);assert(length(sub(add(renderedRoot.p,world(renderedRoot.b,attachment.p)),sample.grip[1].p))<.0001f);
 renderedRoot.p.x=1000;memcpy(renderedBody+8,&renderedRoot,48);assert(renderRoot(player,character,used)&&length(used.p)<.0001f);*(void**)(character+0x30)=nullptr;
 // Calibration extends the native arm chain to the measured controller span.
 float reach=calibratedReachScale(2.04f,.4f,.3f,.3f);assert(reach>1.3f&&reach<1.4f);V elbowFit{},wristFit{},elbowNative{},wristNative{};
 assert(solve({0,0,0},{.3f,0,0},{.6f,0,0},{.8f,0,0},{0,-1,0},elbowNative,wristNative));assert(length(sub(wristNative,{.8f,0,0}))>.19f);
 assert(solve({0,0,0},{.3f*reach,0,0},{.6f*reach,0,0},{.8f,0,0},{0,-1,0},elbowFit,wristFit));assert(length(sub(wristFit,{.8f,0,0}))<.0001f);assert(calibratedReachScale(0,.4f,.3f,.3f)==1);
 data.calibrationReady=1;data.calibratedArmSpan=1.5f;testWorldScale=1.2f;publishChecked=0;RFGRVR_Arms_Publish(&data,anchor,(float*)&identity,zero,&head);Hands calibrated{};assert(getHands(calibrated)&&fabsf(calibrated.calibratedSpan-1.8f)<.0001f);testWorldScale=1;
 // End-to-end control owns the wrist even beyond the calibrated/native reach.
 data.right.position[0]=1.2f;data.rightAim.position[0]=1.2f;publishChecked=0;RFGRVR_Arms_Publish(&data,anchor,(float*)&identity,zero,&head);RFGRVR_Arms_Player(player);Hands fullReach{};assert(getHands(fullReach));checkHeldHand();OnSkin(instance,nullptr,nullptr,nullptr);Pose vrHand{};OnLocal(instance,nullptr,&vrHand,8);Pose activeRoot=currentRoot(command);assert(length(sub(add(activeRoot.p,world(activeRoot.b,vrHand.p)),command.desired[1].p))<.0001f);
 // Fallback and native camera mapping may occur in the same millisecond.
 // The second anchor must take effect; a time throttle leaves the hands behind.
 float nextAnchor[3]={anchor[0]+.2f,anchor[1],anchor[2]};publishChecked=GetTickCount64();RFGRVR_Arms_Publish(&data,nextAnchor,(float*)&identity,zero,&head);Hands remapped{};assert(getHands(remapped)&&fabsf(remapped.grip[1].p.x-fullReach.grip[1].p.x-.2f)<.0001f);
 unsigned saved=writes;*(unsigned*)(player+0x2f4)=15;RFGRVR_Arms_Player(player);assert(writes==saved&&!controlling);OnSkin(instance,nullptr,nullptr,nullptr);assert(writes==saved);OnFire(gun,nullptr,&origin,&direction,&muzzle);assert(origin.x==77&&direction.z==1);
 *(unsigned*)(player+0x2f4)=0;*(unsigned*)(player+0x33c)=1;RFGRVR_Arms_Player(player);assert(writes==saved);
 // Native interaction/reload handoff may change animation poses but must not
 // redefine the rig's controller alignment or neutral arm geometry.
 M retainedAlignment=gripAlignment[1];Pose retainedRest=armRest.pose[8];*(unsigned*)(player+0x33c)=0;model[8].b={{0,1,0},{-1,0,0},{0,0,1}};RFGRVR_Arms_Player(player);
 assert(length(sub(gripAlignment[1].r,retainedAlignment.r))<.0001f&&!memcmp(&retainedRest,&armRest.pose[8],48));

 // Coat/armour have distinct rigs and different bone indices. Their matched
 // sleeve bones must consume the body command, while cloth-only bones survive.
 unsigned char coatInstance[0x410]{},coatRig[72]{},coatBones[12*36]{},coatMap[140]{},coatRenderable[0x130]{};
 // Equip can hide the renderable without changing the cached object flags.
 // The next controlled callback must resynchronize native visibility once.
 {ArmCommand beforeVisibility=command;command=savedCommand;command.visual[0].parent=word(gun,0x70);command.visual[0].handle=word(gun,0x6c);command.tick=GetTickCount64();watchedVisuals[0]=gun;watchedVisuals[1]=nullptr;controlling=true;
 *(unsigned*)(gun+0xb8)=1;*(unsigned*)(gun+0x54)|=0x00800000u;*(unsigned*)(renderedGunEntity+0x40)|=2;
 unsigned calls=visualCalls;OnVisual(gun,nullptr,(void*)0x21);assert(visualCalls==calls+1&&!(word(renderedGunEntity,0x40)&2));
 calls=visualCalls;OnVisual(gun,nullptr,(void*)0x21);assert(visualCalls==calls);
 *(unsigned*)(renderedGunEntity+0x40)|=2;OnVisual(gun,nullptr,(void*)0x21);assert(visualCalls==calls+1&&!(word(renderedGunEntity,0x40)&2));
 controlling=false;OnVisual(gun,nullptr,(void*)0x21);calls=visualCalls;controlling=true;OnVisual(gun,nullptr,(void*)0x21);assert(visualCalls==calls+1);
 *(unsigned*)(gun+0xb8)=0;command=beforeVisibility;}
 unsigned char* coatCharacter=character+0x38;
 Pose coatModel[12]{},coatSkin[12]{},coatCache[12]{};for(auto& p:coatModel)p={identity,{7,8,9}};
 const char* coatNames[12]={"cloth_only","r-foretwist","l-upperarmtwist1","r-upperarmtwist1","l-foretwist","l-hand","r-hand","","","","",""};
 for(int i=0;i<12;++i){*(int*)(coatBones+i*36)=(int)((intptr_t)coatNames[i]-(intptr_t)(coatBones+i*36));coatMap[12+i]=(char)i;}
 *(void**)(coatInstance+0x18)=coatRig;*(void**)(coatInstance+4)=coatModel;*(void**)coatInstance=coatSkin;*(void**)(coatInstance+0x124)=coatMap;*(unsigned*)(coatMap+4)=12;*(unsigned*)(coatRig+0x24)=12;*(void**)(coatRig+0x38)=coatBones;
 *(void**)(coatCharacter+0x30)=coatRenderable;memcpy(coatRenderable+8,&command.root,48);*(void**)(coatRenderable+0x124)=coatCache;*(unsigned*)(coatRenderable+0x120)=12;
 RigRemap coatRemap{};ArmCommand coatCommand{};assert(mapSupplemental(command,coatInstance,coatCharacter,coatCommand,coatRemap));assert(coatCommand.changed[1]&&length(sub(coatCommand.pose[1].p,command.pose[7].p))<.0001f);assert(!coatCommand.changed[0]);
 supplemental[0]=coatCommand;supplementalInstances[0]=coatInstance;supplementalRenderables[0]=coatRenderable;
 OnSkin(coatInstance,nullptr,nullptr,nullptr);Pose coatExpected=rebasePose(coatCommand.pose[1],coatCommand.root,currentRoot(coatCommand));assert(length(sub(coatSkin[1].p,coatExpected.p))<.0001f);assert(coatSkin[0].p.x==7&&coatModel[1].p.x==7);
 V animatedSleeve{20,30,40};OnSetBone(coatInstance,nullptr,1,&animatedSleeve,&identity);assert(coatModel[1].p.x==20&&length(sub(coatSkin[1].p,coatExpected.p))<.0001f);
 OnPaletteCopy(coatRenderable,nullptr,coatModel,12);assert(length(sub(coatCache[1].p,coatExpected.p))<.0001f&&coatCache[0].p.x==7);
 // A new native cloth pose stays native; matching arm bones remain unchanged.
 coatModel[0].p.x=11;coatModel[1].p.x=-99;ArmCommand coatNext{};assert(mapSupplemental(command,coatInstance,coatCharacter,coatNext,coatRemap));assert(coatNext.pose[0].p.x==11&&length(sub(coatNext.pose[1].p,coatCommand.pose[1].p))<.0001f);
 // Unmatched scarf bones must carry their native deformation with the
 // corrected neck, rather than drawing from the old angled torso.
 const char* neckName="neck";const char* scarfName="scarf_tip";
 *(int*)(bones+9*36)=(int)((intptr_t)neckName-(intptr_t)(bones+9*36));
 *(int*)(coatBones+7*36)=(int)((intptr_t)neckName-(intptr_t)(coatBones+7*36));
 *(int*)(coatBones+8*36)=(int)((intptr_t)scarfName-(intptr_t)(coatBones+8*36));*(int*)(coatBones+8*36+28)=7;
 command.pose[9]={identity,{0,1.5f,0}};command.changed[9]=true;command.rootRelative[9]=true;
 coatModel[7]={turnAround(identity,{0,1,0},.5f),{.1f,1.45f,.1f}};V scarfOffset{.03f,-.1f,.05f};coatModel[8]={coatModel[7].b,add(coatModel[7].p,world(coatModel[7].b,scarfOffset))};
 RigRemap scarfRemap{};ArmCommand scarfCommand{};assert(mapSupplemental(command,coatInstance,coatCharacter,scarfCommand,scarfRemap));
 assert(scarfCommand.changed[8]&&scarfCommand.rootRelative[8]);assert(length(sub(scarfCommand.pose[8].p,add(command.pose[9].p,scarfOffset)))<.00001f);
 command.tick+=16;coatModel[8].p.y+=.15f;ArmCommand smoothedCloth{};assert(mapSupplemental(command,coatInstance,coatCharacter,smoothedCloth,scarfRemap));float clothMotion=smoothedCloth.pose[8].p.y-scarfCommand.pose[8].p.y;assert(clothMotion>0&&clothMotion<.08f);ArmCommand sameFrameCloth{};assert(mapSupplemental(command,coatInstance,coatCharacter,sameFrameCloth,scarfRemap));assert(length(sub(smoothedCloth.pose[8].p,sameFrameCloth.pose[8].p))<.00001f);
 supplementalInstances[0]=nullptr;supplementalRenderables[0]=nullptr;supplemental[0]={};

 // The body mesh has a weighted head even when the separate head object is
 // transparent. Collapse ONLY that render palette entry, never the model.
 const char* headName="head";*(int*)(bones+10*36)=(int)((intptr_t)headName-(intptr_t)(bones+10*36));
 V headPosition{.02f,1.62f,.01f},headBind=mul(headPosition,-1);memcpy(bones+10*36+4,&headBind,12);model[10]={identity,headPosition};
 *(void**)(character+0x30)=renderedBody;memcpy(renderedBody+8,&command.root,48);
 const char* eyeName="l-eye";*(int*)(bones+9*36)=(int)((intptr_t)eyeName-(intptr_t)(bones+9*36));V eyePosition{-.03f,1.7f,.08f},eyeBind=mul(eyePosition,-1);memcpy(bones+9*36+4,&eyeBind,12);model[9]={identity,eyePosition};
 // Both active tumble and native get-up retain actual head ownership.
 {auto flag=word(player,0x33c);Pose getup{};for(unsigned phase:{1u,3u}){*(unsigned*)(player+0x33c)=phase;assert(RFGRVR_Arms_RagdollHead(player,&getup));assert(length(sub(getup.p,add(command.root.p,world(command.root.b,headPosition))))<.0001f);}*(unsigned*)(player+0x33c)=0;assert(!RFGRVR_Arms_RagdollHead(player,&getup));
 auto nativeState=word(player,0x2f4);auto nativeView=vrsettings::cached.value[vrsettings::Vehicles];vrsettings::checked=GetTickCount();vrsettings::cached.value[vrsettings::Vehicles]=1;
 for(float roll:{1.5707963f,3.1415926f}){model[10].b=turnAround(identity,{0,0,1},roll);*(unsigned*)(player+0x2f4)=10;assert(RFGRVR_Arms_RagdollHead(player,&getup));assert(length(sub(getup.p,add(command.root.p,world(command.root.b,headPosition))))<.0001f);assert(length(sub(getup.b.u,world(command.root.b,model[10].b.u)))<.0001f);}
 *(unsigned*)(player+0x2f4)=9;assert(!RFGRVR_Arms_RagdollHead(player,&getup));*(unsigned*)(player+0x2f4)=10;vrsettings::cached.value[vrsettings::Vehicles]=0;assert(!RFGRVR_Arms_RagdollHead(player,&getup));
 vrsettings::cached.value[vrsettings::Vehicles]=nativeView;*(unsigned*)(player+0x2f4)=nativeState;model[10].b=identity;*(unsigned*)(player+0x33c)=flag;}
 headMeshes[0]={};rememberPlayerMeshes(player);assert(headSlot(instance)>=0);Pose nativeHead=model[10];OnSkin(instance,nullptr,nullptr,nullptr);
 assert(fabsf(length(skin[10].b.r)-.001f)<.000001f&&!memcmp(&model[10],&nativeHead,48));
 assert(length(skin[9].b.r)<.0011f&&length(sub(model[9].p,eyePosition))<.0001f);OnSetBone(instance,nullptr,9,&eyePosition,&identity);assert(length(skin[9].b.r)<.0011f);
 V headVertex=add(headPosition,V{.1f,0,0});assert(length(sub(add(skin[10].p,world(skin[10].b,headVertex)),headPosition))<.0002f);
 OnPaletteCopy(renderedBody,nullptr,model,12);assert(length(bodyPalette[10].b.r)<.0011f);
 // Gloves mode must no longer collapse any body palette entries.
 {Pose unchangedModel[12];memcpy(unchangedModel,model,sizeof(unchangedModel));vrsettings::cached.value[vrsettings::Body]=1;vrsettings::checked=GetTickCount();OnPaletteCopy(renderedBody,nullptr,model,12);assert(length(bodyPalette[0].b.r)>.9f&&length(bodyPalette[8].b.r)>.9f);assert(!memcmp(model,unchangedModel,sizeof(unchangedModel)));vrsettings::cached.value[vrsettings::Body]=0;}

 // Cinematic actors retain native head, body palette and attachment animation.
 RFGRVR_Arms_Cinematic(true);Pose cinematicTag{};OnLocal(instance,nullptr,&cinematicTag,8);assert(length(sub(cinematicTag.p,model[8].p))<.0001f);Pose hiddenAttempt[12];memcpy(hiddenAttempt,model,sizeof(model));assert(!shrinkHeadPalette(instance,hiddenAttempt,12));OnSkin(instance,nullptr,nullptr,nullptr);assert(!memcmp(skin,model,sizeof(model)));OnPaletteCopy(renderedBody,nullptr,model,12);assert(!memcmp(bodyPalette,model,sizeof(model)));RFGRVR_Arms_Cinematic(false);
 // A retained instance/cache cannot claim a replacement player's/NPC's mesh.
 void* savedCharacter=pointer(player,0x32c);unsigned char replacementCharacter[0xa8]{};*(void**)(player+0x32c)=replacementCharacter;assert(!shrinkHeadPalette(instance,hiddenAttempt,12));ArmCommand rejectedCommand{};assert(!getCommand(instance,rejectedCommand));OnLocal(instance,nullptr,&cinematicTag,8);assert(length(sub(cinematicTag.p,model[8].p))<.0001f);*(void**)(player+0x32c)=savedCharacter;
 auto* savedLocal=localPlayerForTest;localPlayerForTest=nullptr;assert(!getCommand(instance,rejectedCommand)&&!shrinkHeadPalette(instance,hiddenAttempt,12));OnLocal(instance,nullptr,&cinematicTag,8);assert(length(sub(cinematicTag.p,model[8].p))<.0001f);localPlayerForTest=savedLocal;

 // A controller physically on STAGE floor stays on game floor even when the
 // head is lower than the calibrated standing height. Body fit uses that same
 // scaled height delta, without changing the hand constraint.
 data.calibrationReady=1;data.calibrationFloorValid=1;data.calibratedHeadHeight=1.5f;data.hmd=head;data.hmd.validFlags=3;data.hmd.orientation[3]=1;data.hmd.position[1]=1;
 data.left=data.right=data.hmd;data.left.active=data.right.active=1;data.left.position[1]=data.right.position[1]=0;data.leftAim=data.left;data.rightAim=data.right;
 float floorAnchor[3]={0,101.2f,0};testWorldScale=1.2f;RFGRPose floorHead=data.hmd;RFGRVR_Arms_Publish(&data,floorAnchor,(float*)&identity,zero,&floorHead);
 Hands floorHands{};assert(getHands(floorHands));assert(fabsf(floorHands.grip[0].p.y-100)<.0001f&&fabsf(floorHands.grip[1].p.y-100)<.0001f&&fabsf(floorHands.bodyOffset+.6f)<.0001f);testWorldScale=1;
 assert(!shrinkHeadPalette((void*)0x99,bodyPalette,12));
 // Turning the head around a stationary neck must not move the mounted body.
 {RFGRShared rotateData=data;rotateData.hmd.orientation[1]=0;rotateData.hmd.orientation[3]=1;rotateData.hmd.position[0]=0;rotateData.hmd.position[2]=0;publishChecked=0;RFGRVR_Arms_Publish(&rotateData,floorAnchor,(float*)&identity,zero,&floorHead);Hands first{};assert(getHands(first));
 rotateData.hmd.orientation[1]=sinf(.5f);rotateData.hmd.orientation[3]=cosf(.5f);V neck=quaternion(0,sinf(.5f),0,cosf(.5f),{0,.10f,-.08f});rotateData.hmd.position[0]=neck.x;rotateData.hmd.position[2]=neck.z+.08f;publishChecked=0;RFGRVR_Arms_Publish(&rotateData,floorAnchor,(float*)&identity,zero,&floorHead);Hands turned{};assert(getHands(turned));assert(fabsf(turned.physicalBody.x-first.physicalBody.x)<.0001f&&fabsf(turned.physicalBody.z-first.physicalBody.z)<.0001f);}
 // Mounted rendering owns a neutral body and no inventory weapon visuals.
 hands=beforeSupport;hands.tick=GetTickCount64();requestCached=true;requestChecked=GetTickCount64();testMounted=true;testMountRoot={identity,{.1f,0,.2f}};*(unsigned*)(player+0x2f4)=3;*(int*)(player+0xa4c)=-1;*(unsigned*)(player+0x338)=0;*(unsigned*)(player+0x33c)=0;
 Pose mountPhysics{};memcpy(&mountPhysics.p,player+4,12);memcpy(&mountPhysics.b,player+0x10,36);
 RFGRVR_Arms_Player(player);assert(controlling&&command.visualCount==0&&!binding.weapon);assert(length(sub(command.root.p,testMountRoot.p))<.0001f);
 // Free-standing gun animation must not supply camera eyes from a different body pose.
 {int savedEyes[2]={armRest.body.eye[0],armRest.body.eye[1]};armRest.body.eye[0]=9;armRest.body.eye[1]=10;Pose savedA=model[9],savedB=model[10];Pose fixedRoot=command.root;
  for(int i=0;i<30;++i){model[9].p=add(savedA.p,{.2f*sinf(i*.3f),.4f*cosf(i*.3f),.3f});model[10].p=add(savedB.p,{.2f*sinf(i*.3f),.4f*cosf(i*.3f),.3f});hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);V drawnEye=mul(add(command.pose[9].p,command.pose[10].p),.5f);float cameraEye[3]{};assert(RFGRVR_Arms_EyeLocal(player,cameraEye));assert(length(sub(V{cameraEye[0],cameraEye[1],cameraEye[2]},drawnEye))<.00001f);assert(length(sub(command.root.p,fixedRoot.p))<.00001f);}
  model[9]=savedA;model[10]=savedB;armRest.body.eye[0]=savedEyes[0];armRest.body.eye[1]=savedEyes[1];RFGRVR_Arms_Player(player);}
 // Native mount animation can overwrite its draw matrix by more than a metre.
 Pose nativeMountRender{turnAround(identity,{0,1,0},.7f),{1.2f,.1f,-.5f}};memcpy(renderedBody+8,&nativeMountRender,48);
 Pose torsoWorld=vrgrip::worldPose(command.root,command.pose[0]);OnSkin(instance,nullptr,nullptr,nullptr);
 assert(length(sub(vrgrip::worldPose(nativeMountRender,skin[0]).p,torsoWorld.p))<.001f);
 // Armour root interpolation must not displace a shared body-relative bone.
 {ArmCommand armour=command;unsigned bone=0;armour.character=coatCharacter;armour.rootCharacter=character;armour.rootRelative[bone]=true;Pose primaryRoot=currentRoot(command);Pose armourRoot=primaryRoot;armourRoot.p.x+=.18f;armourRoot.b=turnAround(primaryRoot.b,{0,1,0},.1f);Pose actual=vrgrip::worldPose(armourRoot,commandBone(armour,bone,armourRoot)),expected=vrgrip::worldPose(primaryRoot,armour.pose[bone]);assert(length(sub(actual.p,expected.p))<.0001f&&length(sub(actual.b.f,expected.b.f))<.0001f);}
 // Test a regular, unshrunk upper-arm bone as well as head position.
 Pose armWorld=vrgrip::worldPose(command.root,command.pose[6]);assert(length(sub(vrgrip::worldPose(nativeMountRender,skin[6]).p,armWorld.p))<.001f);
 OnPaletteCopy(renderedBody,nullptr,model,12);V boneBind{};memcpy(&boneBind,bones+6*36+4,12);V mountedRecovered=sub(bodyPalette[6].p,world(bodyPalette[6].b,boneBind));assert(length(sub(add(nativeMountRender.p,world(nativeMountRender.b,mountedRecovered)),armWorld.p))<.001f);
 unsigned oldGunHandle=word(gun,0x6c);int oldPrimary=(int)word(gun,0x244),oldSecondary=(int)word(gun,0x248);gunTable[14]=(void*)&GripTag;*(unsigned*)(gun+0x6c)=77;*(int*)(gun+0x244)=3;*(int*)(gun+0x248)=4;*(int*)(player+0xa6c)=12;*(int*)(player+0xa70)=13;turretGripId=~0u;
 hands.sample=1;hands.physical[1]=hands.grip[1];testGunAvailable=true;testGunPose={nativeMountRender.b,{.2f,1.2f,.3f}};hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);Pose mountedHand=command.desired[1];float nativeZero[3]{};assert(RFGRVR_Arms_TurretHandZero(nativeZero));Pose nativeWristGrip=vrgrip::worldPose(testGunPose,turretGripLocal[1]);V nativePalm=add(nativeWristGrip.p,world(nativeWristGrip.b,gripCenterInWrist[1]));V expectedZero=add(hands.physical[1].p,mul(sub(nativePalm,hands.grip[1].p),1/testWorldScale));assert(length(sub({nativeZero[0],nativeZero[1],nativeZero[2]},expectedZero))<.001f);testSeatHeight=.2f;RFGRVR_Arms_Player(player);float raisedZero[3]{};assert(RFGRVR_Arms_TurretHandZero(raisedZero)&&fabsf(raisedZero[1]-nativeZero[1]+.2f/testWorldScale)<.001f);testSeatHeight=0;RFGRVR_Arms_Player(player);
 Pose propOffset{};memcpy(&propOffset,(char*)pointer(rig,0x3c)+64,48);Pose actualHandTag=vrgrip::worldPose(command.desired[1],propOffset),expectedHandTag{};assert(itemTagPose(gun,3,testGunPose,expectedHandTag));assert(length(sub(actualHandTag.p,expectedHandTag.p))<.001f&&length(sub(actualHandTag.b.f,expectedHandTag.b.f))<.001f);
 testGunPose.p.x+=.15f;model[8].p.y-=.2f;hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);assert(fabsf(command.desired[1].p.x-mountedHand.p.x-.15f)<.001f&&fabsf(command.desired[1].p.y-mountedHand.p.y)<.001f);assert(turretGripId==77&&RFGRVR_Arms_TurretGripLever(77)>0);// A retired mesh still has a rig but no output palette: synthetic
 // Both native control grips remain weapon-local through assembly yaw.
 {Pose localHands[2]={vrgrip::relativePose(testGunPose,command.desired[0]),vrgrip::relativePose(testGunPose,command.desired[1])};for(float yaw:{-.8f,.9f,-1.6f}){testGunPose.b=turnAround(nativeMountRender.b,{0,1,0},yaw);hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);for(unsigned side=0;side<2;++side){Pose actual=vrgrip::relativePose(testGunPose,command.desired[side]);assert(length(sub(actual.p,localHands[side].p))<.001f&&length(sub(actual.b.f,localHands[side].b.f))<.001f);}}}
 // render refresh must not forward it to the native builder (dump 88C9F2).
 {void* output=pointer(instance,0);*(void**)instance=nullptr;unsigned before=skinApplications;RFGRVR_Arms_RenderWeapon((void*)0x21);assert(skinApplications==before);*(void**)instance=output;}
 testGunAvailable=false;gunTable[14]=nullptr;*(unsigned*)(gun+0x6c)=oldGunHandle;*(int*)(gun+0x244)=oldPrimary;*(int*)(gun+0x248)=oldSecondary;*(int*)(player+0xa6c)=5;*(int*)(player+0xa70)=8;
 auto mountTorso=command.pose[10];model[10].p.y-=.4f;hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);assert(length(sub(command.pose[10].p,mountTorso.p))<.0001f);
 // A seated gunner must keep the native seated torso, not the standing
 // reference or floor-height fit used by a standing turret.
 armRest.body.eye[0]=9;armRest.body.eye[1]=10;
 *(unsigned*)(player+0x2f4)=8;Pose seatedTorso=model[0];seatedTorso.p.y-=.45f;model[0]=seatedTorso;
 hands.bodyOffset=.8f;hands.floorFit=true;hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);
 assert(controlling&&command.changed[0]&&length(sub(command.pose[0].p,seatedTorso.p))<.0001f);
 {Pose before=command.pose[0],headBefore=command.pose[10];model[0].p.y+=.4f;model[10].p.y+=.5f;hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);assert(length(sub(command.pose[0].p,before.p))<.0001f&&length(sub(command.pose[10].p,headBefore.p))<.0001f);assert(command.nativeEyeValid);V fixedEye=mul(add(seatedTurretScaffold.pose[command.eye[0]].p,seatedTurretScaffold.pose[command.eye[1]].p),.5f);assert(length(sub(command.nativeEye,fixedEye))<.0001f);model[0]=seatedTorso;}

 *(unsigned*)(player+0x2f4)=3;
 assert(!memcmp(player+4,&mountPhysics.p,12)&&!memcmp(player+0x10,&mountPhysics.b,36));testMounted=false;model[10]=nativeHead;
 // Vehicle/native-animation path must also hide it without VR arm ownership.
 controlling=false;*(unsigned*)(player+0x2f4)=9;rememberPlayerMeshes(player);OnSkin(instance,nullptr,nullptr,nullptr);
 assert(length(skin[10].b.r)<.0011f&&!memcmp(&model[10],&nativeHead,48));
 V animatedHead{.03f,1.63f,.02f};OnSetBone(instance,nullptr,10,&animatedHead,&identity);assert(model[10].p.y==animatedHead.y&&length(skin[10].b.r)<.0011f);
 OnPaletteCopy(renderedBody,nullptr,model,12);assert(length(bodyPalette[10].b.r)<.0011f);
 // Gloves mode is a private local-player rendering change, not an animation
 // or skeleton change. Switching back restores the ordinary body palette.
 {Pose unchangedModel[12];memcpy(unchangedModel,model,sizeof(unchangedModel));headMeshes[0].glove[8]=true;
 vrsettings::cached.value[vrsettings::Body]=1;vrsettings::checked=GetTickCount();OnPaletteCopy(renderedBody,nullptr,model,12);
 assert(length(bodyPalette[0].b.r)>.9f&&length(bodyPalette[10].b.r)<.0011f&&length(bodyPalette[8].b.r)>.9f);assert(!memcmp(model,unchangedModel,sizeof(unchangedModel)));
 vrsettings::cached.value[vrsettings::Body]=0;vrsettings::checked=GetTickCount();OnPaletteCopy(renderedBody,nullptr,model,12);assert(length(bodyPalette[0].b.r)>.9f);}


 // Camera receives unshrunk, animated model-eye positions from the same
 // published player command, never tiny render skin or an unrelated actor.
 controlling=true;command.nativeEyeValid=false;command.player=player;command.tick=GetTickCount64();command.eye[0]=9;command.eye[1]=10;command.changed[9]=command.changed[10]=true;command.pose[9].p={-.03f,1.2f,.08f};command.pose[10].p={.03f,1.2f,.08f};float eyeLocal[3];
 assert(RFGRVR_Arms_EyeLocal(player,eyeLocal)&&fabsf(eyeLocal[0])<.00001f&&fabsf(eyeLocal[1]-1.2f)<.00001f);
 command.nativeEye={0,.95f,.1f};command.nativeEyeValid=true;assert(RFGRVR_Arms_EyeLocal(player,eyeLocal)&&fabsf(eyeLocal[1]-.95f)<.0001f);command.nativeEyeValid=false;assert(!RFGRVR_Arms_EyeLocal((void*)0x99,eyeLocal));command.tick=GetTickCount64()-300;assert(!RFGRVR_Arms_EyeLocal(player,eyeLocal));

 // Walking animation may move legs, but cannot translate the VR torso scaffold.
 testMounted=false;hands=beforeSupport;hands.floorFit=false;hands.tick=GetTickCount64();requestCached=true;requestChecked=GetTickCount64();*(unsigned*)(player+0x2f4)=0;*(unsigned*)(player+0x2fc)=0;
 armRest.body.root=0;armRest.body.spine=1;armRest.solver[0]={identity,{0,0,0}};armRest.solver[1]={identity,{0,1.2f,0}};model[0]=armRest.solver[0];*(int*)(bones+1*36+28)=0;neutralPose.weight=1;
 model[1]={identity,{.3f,1.4f,.1f}};model[2]={identity,{0,.4f,0}};RFGRVR_Arms_Player(player);Pose fixedTorso=command.pose[1],walkingLeg=command.pose[2];
 model[1].p.x+=.2f;model[2].p.x+=.2f;hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);assert(length(sub(fixedTorso.p,command.pose[1].p))<.001f&&length(sub(walkingLeg.p,command.pose[2].p))>.1f);
 // Non-crouch action stances cannot hand the torso back to firing animation.
 for(unsigned actionStance:{2u,3u}){*(unsigned*)(player+0x2fc)=actionStance;model[1].p.x+=.25f;neutralPose.weight=1;hands.tick=GetTickCount64();RFGRVR_Arms_Player(player);assert(length(sub(command.pose[1].p,fixedTorso.p))<.001f);}*(unsigned*)(player+0x2fc)=0;
 // Native upper-body yaw is removed without changing native vertical travel.
 auto expectedNativeTorso=[&](){return RFGRVR_AlignBodyYaw(model[1],model[0],RFGRVR_BodyYaw(relative(command.root.b,identity)));};
 // Native lower-body ground contact must survive neutral torso stabilization.
 {Pose savedRoot=model[0],savedTorso=model[1],savedLeg=model[2];model[0].b=turnAround(identity,{1,0,0},.2f);model[2].p={.2f,.11f,.1f};neutralPose.weight=1;RFGRVR_Arms_Player(player);assert(!command.changed[2]&&length(sub(command.pose[2].p,model[2].p))<.0001f);
 for(unsigned state:{1u,2u}){*(unsigned*)(player+0x2f4)=state;model[1].p={.15f,1.05f,.22f};neutralPose.weight=1;RFGRVR_Arms_Player(player);assert(length(sub(command.pose[1].p,expectedNativeTorso().p))<.0001f&&fabsf(command.pose[1].p.y-model[1].p.y)<.0001f);}
 *(unsigned*)(player+0x2f4)=0;*(unsigned*)(player+0x2fc)=1;neutralPose.weight=1;RFGRVR_Arms_Player(player);assert(length(sub(command.pose[1].p,expectedNativeTorso().p))<.0001f&&fabsf(command.pose[1].p.y-model[1].p.y)<.0001f);*(unsigned*)(player+0x2fc)=0;testLandingRecovery=true;RFGRVR_Arms_Player(player);assert(length(sub(command.pose[1].p,expectedNativeTorso().p))<.0001f&&fabsf(command.pose[1].p.y-model[1].p.y)<.0001f);testLandingRecovery=false;model[0]=savedRoot;model[1]=savedTorso;model[2]=savedLeg;}
 // Camera samples the current native eye palette during animation, not an
 // older controller command; the immutable rig reference remains separate.
 {ArmCommand saved=command;Pose one=model[1],two=model[2];unsigned state=word(player,0x2f4);command.player=player;command.instance=instance;command.modelIdentity=model;command.count=saved.count;command.tick=GetTickCount64();command.eye[0]=1;command.eye[1]=2;command.nativeEye={0,1.6f,0};command.nativeEyeValid=true;command.referenceEye={0,1.68f,0};command.referenceEyeValid=true;command.changed[1]=command.changed[2]=true;*(unsigned*)(player+0x2f4)=1;model[1].p={0,1.05f,0};model[2].p={0,1.1f,0};float eye[3]{},reference[3]{};assert(RFGRVR_Arms_EyeLocal(player,eye)&&fabsf(eye[1]-1.075f)<.0001f);assert(RFGRVR_Arms_EyeReference(player,reference)&&fabsf(reference[1]-1.68f)<.0001f);*(unsigned*)(player+0x2f4)=0;*(unsigned*)(player+0x2fc)=2;assert(RFGRVR_Arms_EyeLocal(player,eye)&&fabsf(eye[1]-1.6f)<.0001f);*(unsigned*)(player+0x2fc)=0;command=saved;model[1]=one;model[2]=two;*(unsigned*)(player+0x2f4)=state;}
 // Native propane carry keeps VR pose ownership without forcing carry/reload
 // animation; unrelated interaction flags still disable the override.
 {unsigned char prop[0x104]{},def[16]{},attachment[12]{};*(const char**)def="propane_tank";*(void**)(prop+0xa4)=def;*(void**)(prop+0x48)=attachment;*(unsigned*)(prop+0x70)=word(player,0x6c);void* previousChild=pointer(player,0x34);*(void**)(player+0x34)=prop;unsigned flags=word(player,0x338),rag=word(player,0x33c);*(unsigned*)(player+0x338)=flags|(1u<<13);assert(nativePropObject(player)==prop&&nativePropCarry(player)&&eligible(player));*(unsigned*)(player+0x33c)=1;assert(!eligible(player));*(unsigned*)(player+0x33c)=0;*(unsigned*)(prop+0x70)=word(player,0x6c)+1;assert(!nativePropCarry(player)&&!eligible(player));*(void**)(player+0x34)=previousChild;*(unsigned*)(player+0x338)=flags;*(unsigned*)(player+0x33c)=rag;}
 command.tick=GetTickCount64();ArmCommand ownerCheck{};int originalHandle=*(int*)character;*(int*)character=originalHandle+356;assert(!getCommand(instance,ownerCheck));assert(!shrinkHeadPalette(instance,bodyPalette,12));*(int*)character=originalHandle;assert(getCommand(instance,ownerCheck));RFGRVR_Arms_Cinematic(true);assert(!getCommand(instance,ownerCheck));RFGRVR_Arms_Cinematic(false);assert(getCommand(instance,ownerCheck));

 // Reproduce the observed global arena: root359, coat361, NPC362, eye365.
 // The NPC is adjacent, while the real player attachment is not adjacent.
 {auto* savedBase=base;void* savedRoot=pointer(player,0x32c);auto* arena=(unsigned char*)VirtualAlloc(nullptr,16*0x410,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);assert(arena);unsigned char records[4][0x38]{};unsigned ids[4]={359,361,362,365};base=(unsigned char*)((uintptr_t)arena-0x35acbd0u);*(void**)(player+0x32c)=records[0];for(unsigned i=0;i<4;++i){*(unsigned*)records[i]=ids[i];*(void**)(records[i]+0x1c)=records[(i+1)%4];auto* instance=arena+(ids[i]%356)*0x410;*(unsigned*)(instance+0x1c)=(i==1||i==3)?359:~0u;}assert(playerPart(player,records[0],arena+3*0x410));assert(!playerPart(player,records[2],arena+6*0x410));assert(playerPart(player,records[3],arena+9*0x410));auto owned=playerParts(player);assert(owned.count==3&&owned.part[0]==records[0]&&owned.part[1]==records[1]&&owned.part[2]==records[3]);*(unsigned*)(arena+9*0x410+0x1c)=362;assert(!playerPart(player,records[3],arena+9*0x410));base=savedBase;*(void**)(player+0x32c)=savedRoot;VirtualFree(arena,0,MEM_RELEASE);}

}

















extern "C" bool RFGRVR_HeadCam_TurretGunPose(void*,vrarm::Pose* p,unsigned* id,bool* entering){if(!testGunAvailable)return false;*p=testGunPose;*id=77;*entering=false;return true;}


extern "C" float RFGRVR_HeadCam_ForwardLean(){return 0;}
extern "C" void RFGRVR_HeadCam_AvatarPelvis(const float[3]){}


extern "C" float RFGRVR_HeadCam_VehicleHeight(){return testSeatHeight;}

extern "C" bool RFGRVR_SaveVehicleCalibration(){return true;}
extern "C" bool RFGRVR_HeadCam_ControllerMoving(){return false;}

extern "C" void RFGRVR_APC_Created(void*){}






extern "C" bool RFGRVR_HeadCam_LandingRecovery(){return testLandingRecovery;}

