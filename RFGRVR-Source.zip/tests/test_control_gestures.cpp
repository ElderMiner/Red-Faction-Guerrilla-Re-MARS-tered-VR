#define RFGR_TEST_USER_SETTINGS
#include "../src/vr_quest_layout.h"
#include <cassert>
#include <cstdio>
using namespace vrsettings;
struct QuestInput {
 Config config;Controls controls;float grip[2]{};
 RFGRGamepad sample(unsigned buttons,uint64_t now,unsigned state=0,bool active=true){RFGRGamepad physicalPad{};physicalPad.buttons=(uint16_t)buttons;float raw[SourceCount]{},squeeze[2]{};physical(physicalPad,squeeze,raw);auto pad=controls.update(config,raw,grip,true,active,state==0x100,now);return vrquest::output(pad,state,buttons);}
};
int main(){
 {QuestInput q;assert(q.sample(0x1000,100).buttons==0x1000);assert(q.sample(0,101).buttons==0);}
 {QuestInput q;assert(!q.sample(0x2000,100).buttons);assert(!q.sample(0x2000,599).buttons);assert(q.sample(0,599).buttons==0x4000);assert(!q.sample(0,689).buttons);}
 {QuestInput q;assert(!q.sample(0x2000,100).buttons);assert(q.sample(0x2000,600).buttons==0x8000);assert(q.sample(0x2000,900).buttons==0x8000);assert(!q.sample(0,901).buttons);}
 {QuestInput q;q.sample(0x4000,100);auto tap=q.sample(0,200);assert(tap.buttons==vrquest::Detonate);vrquest::commands(tap,true,false);assert(!tap.buttons);tap=q.sample(0,201);vrquest::commands(tap,true,true);assert(tap.buttons==0x2000);}
 {QuestInput q;assert(!q.sample(0x4000,100).buttons);assert(!q.sample(0x4000,599).buttons);assert(q.sample(0x4000,600).buttons==8);assert(q.sample(0x4000,800).buttons==8);assert(!q.sample(0,801).buttons);}
 {QuestInput q;assert(q.sample(0x8000,100).buttons==0x200);assert(q.sample(0x8000,700).buttons==0x200);assert(!q.sample(0,701).buttons);}
 {QuestInput q;assert(!q.sample(0x10,100).buttons);assert(q.sample(0,200).buttons==0x20);}
 {QuestInput q;q.sample(0x10,100);assert(q.sample(0x10,600).buttons==0x10);assert(!q.sample(0,601).buttons);}
 {QuestInput q;auto crouch=q.sample(0x80,100);assert(crouch.buttons==(0x40|vrquest::ButtonCrouch));vrquest::commands(crouch,true,false);assert(crouch.buttons==0x40);assert(q.sample(0,101).buttons==0);assert(q.sample(0x40,200).buttons==0x100);}
 {QuestInput q;assert(q.sample(0x40,100,9).buttons==0x40);assert(q.sample(0x80,101,9).buttons==0x80);}
 {QuestInput q;q.sample(0xf010,100,0,false);assert(!q.sample(0xf010,200).buttons);assert(!q.sample(0xf010,900).buttons);q.sample(0,901);assert(q.sample(0x1000,902).buttons==0x1000);}
 {QuestInput q;q.sample(0,100,0x100);assert(!q.sample(0x2000,200,0x100).buttons);assert(q.sample(0x2000,700,0x100).buttons==0x8000);assert(!q.sample(0x2000,701).buttons);assert(!q.sample(0x2000,1300).buttons);q.sample(0,1301);assert(q.sample(0x2000,1802).buttons==0);assert(q.sample(0x2000,2302).buttons==0x8000);}
 {QuestInput q;auto pad=q.sample(0xf000,100,0x100);assert(!(pad.buttons&~(0x8000|0x10|0x20)));}
 {Config c;Controls input;for(int i=0;i<ActionCount;++i)c.binding[i]=None;c.binding[X]=c.binding[Y]=c.binding[B]=B;c.press[X]=vrpress::Single;c.press[Y]=vrpress::Double;c.press[B]=vrpress::Hold;float raw[SourceCount]{},grip[2]{};auto step=[&](bool down,uint64_t now){raw[B]=down?1.f:0.f;return input.update(c,raw,grip,false,true,false,now).buttons;};
  assert(!step(true,100));assert(!step(false,150));assert(!step(false,450));assert(step(false,451)==0x4000);assert(!step(false,541));
  assert(!step(true,1000));assert(!step(false,1050));assert(!step(true,1200));assert(step(false,1250)==0x8000);assert(!step(false,1340));
  assert(!step(true,2000));assert(step(true,2500)==0x2000);assert(!step(false,2501));
  assert(!step(true,3000));assert(!step(false,3050));assert(!step(true,3200));assert(step(true,3700)==0x2000);assert(!step(false,3701));
  step(true,4000);c.press[X]=vrpress::Double;assert(!step(true,4600));assert(!step(false,4601));
 }
 {QuestInput q;q.sample(0x4000,100);assert(q.sample(0,600).buttons==8);assert(!q.sample(0,690).buttons);q.sample(0x4000,700);assert(!q.sample(0x4000,701).buttons);}
 {Config c;Config invalid=c;invalid.questBinding[Y]=999;invalid.questPress[Y]=999;invalid.press[A]=-1;invalid.validate();assert(invalid.questBinding[Y]==B&&invalid.questPress[Y]==vrpress::Hold&&invalid.press[A]==vrpress::Single);Controls input;float raw[SourceCount]{},grip[2]{};raw[RT]=NAN;raw[None]=1;auto pad=input.update(c,raw,grip,true,true,false,100);assert(!pad.rightTrigger&&!pad.buttons);}
 {Config c;Controls input;float raw[SourceCount]{},grip[2]{};RFGRGamepad source{};source.leftX=-12345;source.rightX=14000;source.rightTrigger=207;physical(source,grip,raw);auto output=input.update(c,raw,grip,true,true,false,100);assert(output.leftX==source.leftX&&output.rightX==source.rightX&&output.rightTrigger==source.rightTrigger);}
 {Config c;Controls input;float raw[SourceCount]{},grip[2]{};c.binding[B]=RT;c.press[B]=vrpress::Hold;raw[RT]=1;assert(!input.update(c,raw,grip,false,true,false,100).rightTrigger);auto hold=input.update(c,raw,grip,false,true,false,600);assert(!hold.rightTrigger&&(hold.buttons&0x2000));raw[RT]=0;input.update(c,raw,grip,false,true,false,601);}
 {Config c;Controls input;float raw[SourceCount]{},grip[2]{};raw[RT]=.4f;input.update(c,raw,grip,false,false,false,100);assert(!input.update(c,raw,grip,false,true,false,200).rightTrigger);raw[RT]=0;input.update(c,raw,grip,false,true,false,201);raw[RT]=.4f;assert(input.update(c,raw,grip,false,true,false,202).rightTrigger>0);c.press[A]=vrpress::Double;assert(!input.update(c,raw,grip,false,true,false,203).rightTrigger);assert(!input.update(c,raw,grip,false,true,false,204).rightTrigger);raw[RT]=0;input.update(c,raw,grip,false,true,false,205);raw[RT]=1;assert(input.update(c,raw,grip,false,true,false,206).rightTrigger==255);}
 puts("PASS: Quest requested controls, shared tap/hold safety, single/double/hold arbitration, menu/cutscene transitions, analog retention and vehicle thumb controls.");
}
