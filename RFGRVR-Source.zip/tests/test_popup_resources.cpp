#define main RFGR_Unused_Companion_Main
#include "../src/bridge.cpp"
#undef main
#include <cassert>
struct FakeSwap {Microsoft::WRL::ComPtr<ID3D11Texture2D> image;};
static ID3D11Device* testDevice;static unsigned liveSwaps=0,creates=0,acquires=0;
static XrResult XRAPI_PTR makeSwap(XrSession,const XrSwapchainCreateInfo* info,XrSwapchain* out){if(liveSwaps>=2)return XR_ERROR_LIMIT_REACHED;auto* s=new FakeSwap;D3D11_TEXTURE2D_DESC d{};d.Width=info->width;d.Height=info->height;d.MipLevels=d.ArraySize=d.SampleDesc.Count=1;d.Format=(DXGI_FORMAT)info->format;d.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;if(FAILED(testDevice->CreateTexture2D(&d,nullptr,&s->image))){delete s;return XR_ERROR_OUT_OF_MEMORY;}*out=(XrSwapchain)s;++liveSwaps;++creates;return XR_SUCCESS;}
static XrResult XRAPI_PTR enumerateSwap(XrSwapchain s,uint32_t capacity,uint32_t* n,XrSwapchainImageBaseHeader* images){*n=1;if(capacity)((XrSwapchainImageD3D11KHR*)images)->texture=((FakeSwap*)s)->image.Get();return XR_SUCCESS;}
static XrResult XRAPI_PTR acquireSwap(XrSwapchain,const XrSwapchainImageAcquireInfo*,uint32_t* index){*index=0;++acquires;return XR_SUCCESS;}
static XrResult XRAPI_PTR waitSwap(XrSwapchain,const XrSwapchainImageWaitInfo*){return XR_SUCCESS;}
static XrResult XRAPI_PTR releaseSwap(XrSwapchain,const XrSwapchainImageReleaseInfo*){return XR_SUCCESS;}
static XrResult XRAPI_PTR destroySwap(XrSwapchain s){delete (FakeSwap*)s;--liveSwaps;return XR_SUCCESS;}
struct Producer {
 std::wstring name;HANDLE mapping=nullptr;RFGRGpuShared* packet=nullptr;Microsoft::WRL::ComPtr<ID3D11Texture2D> texture;Microsoft::WRL::ComPtr<IDXGIKeyedMutex> mutex;
 Producer(ID3D11Device* d,const wchar_t* kind){name=L"Local\\RFGRVR_TEST_Popup207_"+std::to_wstring(GetCurrentProcessId())+kind;mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRGpuShared),name.c_str());packet=(RFGRGpuShared*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRGpuShared));assert(packet);ZeroMemory(packet,sizeof(*packet));D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=4;desc.MipLevels=desc.ArraySize=desc.SampleDesc.Count=1;desc.Format=DXGI_FORMAT_B8G8R8A8_UNORM;desc.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;desc.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&texture)));assert(SUCCEEDED(texture.As(&mutex)));Microsoft::WRL::ComPtr<IDXGIResource> resource;texture.As(&resource);HANDLE handle=nullptr;resource->GetSharedHandle(&handle);packet->magic=RFGR_GPU_MAGIC;packet->version=1;packet->width=packet->height=4;packet->format=desc.Format;packet->legacyShareHandle=(uint64_t)(uintptr_t)handle;packet->ready=1;}
 void publish(ID3D11DeviceContext* c){assert(mutex->AcquireSync(0,1000)==S_OK);unsigned pixels[16];for(auto& p:pixels)p=0xff408020;c->UpdateSubresource(texture.Get(),0,nullptr,pixels,16,0);c->Flush();mutex->ReleaseSync(1);InterlockedIncrement(&packet->frames);}
 ~Producer(){if(packet)UnmapViewOfFile(packet);if(mapping)CloseHandle(mapping);}
};
int main(){Microsoft::WRL::ComPtr<ID3D11Device> d;Microsoft::WRL::ComPtr<ID3D11DeviceContext> c;D3D_FEATURE_LEVEL level;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,&level,&c)));testDevice=d.Get();Producer video(d.Get(),L"Video"),ui(d.Get(),L"UI");MainMenuLayers menu;menu.source[0].mappingName=video.name.c_str();menu.source[1].mappingName=ui.name.c_str();RFGRPose head{};head.validFlags=3;head.orientation[3]=1;head.position[1]=1.6f;RFGRVRFloorScreen floor;
 auto frame=[&](bool active,bool backdrop){return menu.frame(d.Get(),c.Get(),XR_NULL_HANDLE,XR_NULL_HANDLE,DXGI_FORMAT_B8G8R8A8_UNORM_SRGB,head,active,backdrop,floor,makeSwap,enumerateSwap,acquireSwap,waitSwap,releaseSwap);};
 video.publish(c.Get());ui.publish(c.Get());assert(frame(true,true));assert(creates==2&&liveSwaps==2&&ui.packet->acknowledged==1);auto saved=menu.swap[1];
 // There is no third swapchain slot. Opening a popup reuses the working UI.
 ui.publish(c.Get());assert(frame(true,false));assert(menu.swap[1]==saved&&creates==2&&!menu.visible[0]&&menu.visible[1]&&ui.packet->acknowledged==2);
 D3D11_TEXTURE2D_DESC eyes{};eyes.Width=eyes.Height=64;eyes.ArraySize=2;eyes.MipLevels=eyes.SampleDesc.Count=1;eyes.Format=DXGI_FORMAT_B8G8R8A8_TYPELESS;eyes.BindFlags=D3D11_BIND_RENDER_TARGET;Microsoft::WRL::ComPtr<ID3D11Texture2D> target;assert(SUCCEEDED(d->CreateTexture2D(&eyes,nullptr,&target)));XrView view{XR_TYPE_VIEW};view.pose.orientation.w=1;view.pose.position.y=1.6f;view.fov={-.8f,.8f,.8f,-.8f};for(unsigned eye=0;eye<2;++eye){view.pose.position.x=eye?.032f:-.032f;assert(menu.project(d.Get(),c.Get(),target.Get(),eye,view,DXGI_FORMAT_B8G8R8A8_UNORM_SRGB,false));}
 unsigned before=acquires,copies=menu.source[1].copied;for(unsigned i=0;i<10;++i)assert(!frame(false,false));assert(creates==2&&acquires==before&&menu.source[1].copied==copies);menu.close(destroySwap);assert(liveSwaps==0);puts("PASS actual popup lifecycle: main-to-popup UI reuse under a two-swapchain limit, native handoff, foreground-only per-eye drawing, zero closed-menu copy/acquire work and cleanup");}

