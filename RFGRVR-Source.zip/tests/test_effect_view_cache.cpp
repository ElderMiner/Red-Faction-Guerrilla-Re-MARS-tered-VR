#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../src/vr_effect_view_cache.h"
extern "C" bool RFGRVR_HeadCam_Enabled(){return true;}
using namespace RFGRVREffectViewCache;
static void put(void* p,unsigned off,unsigned v){memcpy((char*)p+off,&v,4);}
static unsigned char* originalGlow;static unsigned renderCalls=0;
static void __fastcall nativeGlow(void*,void*,uintptr_t,uintptr_t,void* source,uintptr_t pass){
 ++renderCalls;if(pass){assert(source==originalGlow);return;}
 assert(source!=originalGlow);float spin,angle;memcpy(&spin,(char*)source+0x64,4);memcpy(&angle,(char*)source+0x68,4);assert(spin==0&&angle==27);
 assert(!memcmp(source,originalGlow,0x64));assert(!memcmp((char*)source+0x68,originalGlow+0x68,0x118-0x68));
 float visibility=.75f;memcpy((char*)source+0xc4,&visibility,4);
}
int main(){bool occupied[4096]{};unsigned unique=0;for(unsigned i=0;i<512;++i){auto slot=RFGRVREffectGeometry::slotFor((void*)(uintptr_t(0x1000000u)+i*65536u));if(!occupied[slot]){occupied[slot]=true;++unique;}}assert(unique>400);
 {unsigned char source[0x118]{},before[0x118];originalGlow=source;float spin=1.5f,angle=27,visibility=.5f;memcpy(source+0x64,&spin,4);memcpy(source+0x68,&angle,4);memcpy(source+0xc4,&visibility,4);memcpy(before,source,sizeof(source));render=(Render)&nativeGlow;frame=nullptr;
  // Run the production hook through normal and profiled paths. Native fades
  // survive, but the view-spin override never leaks into simulation storage.
  for(bool profile:{false,true}){RFGRVREffectGeometry::profiling=profile;memcpy(source,before,sizeof(source));onRender(nullptr,nullptr,0,0,source,0);float result;memcpy(&result,source+0xc4,4);assert(result==.75f);memcpy(before+0xc4,&result,4);assert(!memcmp(source,before,sizeof(source)));onRender(nullptr,nullptr,0,0,source,1);onRender(nullptr,nullptr,0,0,source,2);}
  assert(renderCalls==6);vrcoronabillboard::Source privateCopy;assert(privateCopy.forDraw(source,0,false)==source);assert(privateCopy.forDraw(source,1,true)==source);RFGRVREffectGeometry::profiling=false;
 }
 {using namespace vrarm;unsigned char camera[0x38]{},source[0x118]{};V light{0,0,-10},position{0,0,0};memcpy(source+0x14,&light,12);memcpy(camera+0x2c,&position,12);
  M identity{{1,0,0},{0,1,0},{0,0,1}};unsigned char saved[sizeof(source)];memcpy(saved,source,sizeof(source));M first{};
  for(int i=-15;i<=15;++i){M rotated=turnAround(identity,{0,1,0},i*.1f);memcpy(camera+8,&rotated,36);vrcoronabillboard::Camera glow;auto output=glow.forDraw(uintptr_t(camera),source,0,true);assert(output!=uintptr_t(camera));M axes;memcpy(&axes,(void*)(output+8),36);assert(valid(axes));if(i==-15)first=axes;assert(!memcmp(&axes,&first,sizeof(axes)));assert(!memcmp((void*)(output+0x2c),camera+0x2c,12));assert(!memcmp(source,saved,sizeof(source)));
   assert(glow.forDraw(uintptr_t(camera),source,1,true)==uintptr_t(camera));assert(glow.forDraw(uintptr_t(camera),source,2,true)==uintptr_t(camera));assert(glow.forDraw(uintptr_t(camera),source,0,false)==uintptr_t(camera));
  }
  vrcoronabillboard::Camera glow;memcpy(source+0x14,&position,12);assert(glow.forDraw(uintptr_t(camera),source,0,true)==uintptr_t(camera));
 }

 unsigned char effect[0xe0]{};put(effect,0xd0,12);put(effect,0xd8,34);put(effect,0xd4,100);put(effect,0xdc,100);
 select(0);assert(!prepare(effect,100));assert(RFGRVREffectGeometry::word(effect,0xd4)==100);
 select(1);assert(prepare(effect,100));assert(RFGRVREffectGeometry::word(effect,0xd4)==99&&RFGRVREffectGeometry::word(effect,0xdc)==99);
 assert(RFGRVREffectGeometry::word(effect,0xd0)==12&&RFGRVREffectGeometry::word(effect,0xd8)==34);
 // Both query subpasses may update their stamps. Do not expire them again
 // during the same eye or the engine's intra-eye deduplication breaks.
 put(effect,0xd4,100);put(effect,0xdc,100);auto queries=vrmemory::queryTotal.load();{vrmemory::Scope scope;assert(!prepare(effect,100));}assert(vrmemory::queryTotal.load()==queries);assert(RFGRVREffectGeometry::word(effect,0xd4)==100);
 select(1);assert(prepare(effect,100));select(-1);assert(!prepare(effect,100));put(effect,0xd4,100);put(effect,0xdc,100);select(0);select(1);assert(prepare(effect,100));
 select(0);put(effect,0xd4,98);put(effect,0xdc,98);select(1);assert(!prepare(effect,100));
 select(0);put(effect,0xd4,0);put(effect,0xdc,0);select(1);assert(prepare(effect,0));assert(RFGRVREffectGeometry::word(effect,0xd4)==~0u);
}

