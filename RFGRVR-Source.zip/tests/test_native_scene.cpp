#define RFGR_TEST_FRAMEPACER
#define RFGR_TEST_USER_SETTINGS
static bool testMapMenu=false;
#include "../src/native_scene.cpp"
#include <cassert>
extern "C" void RFGRVR_Arms_BodyGeometryBegin(){}
extern "C" void RFGRVR_Arms_BodyGeometryEnd(){}
extern "C" void RFGRVR_Foveation_Begin(){}
extern "C" void RFGRVR_Foveation_End(){}
static unsigned char sceneFixture[0x300]{};static bool auxiliaryTest=false;static unsigned auxiliaryCaptures=0;
extern "C" bool RFGRVR_HeadCam_IsAuxiliary(){return auxiliaryTest;}
extern "C" void RFGRVR_APC_AuxSet(const vrarm::Pose* p){auxiliaryTest=p!=nullptr;if(p){RFGRAPCTargets::width=256;RFGRAPCTargets::height=144;}}
extern "C" void RFGRVR_APC_Pipeline(bool){}
static unsigned resizeCleanupCalls=0;extern "C" void RFGRVR_APC_BeforeResize(){++resizeCleanupCalls;}
extern "C" void RFGRVR_Scope_AuxSet(const vrarm::Pose* p){RFGRVR_APC_AuxSet(p);}
extern "C" bool RFGRVR_APC_AuxProjection(void*,float[16],float*){return false;}
extern "C" bool RFGRVR_APC_AuxCapture(unsigned i){assert(auxiliaryTest&&i<4);++auxiliaryCaptures;return true;}
static bool vrHeadEnabled=true;extern "C" bool RFGRVR_HeadCam_Enabled(){return vrHeadEnabled;}
extern "C" bool RFGRVR_HeadCam_FirstPersonVehicle(){return false;}
extern "C" void RFGRVR_HeadCam_RenderFov(float){}
extern "C" bool RFGRVR_NativePair_BuffersBusy(){return false;}
extern "C" void RFGRVR_FrameTiming_Outer(long long){}
static unsigned char renderFixture[0x500]{},secondaryFixture[0x500]{},primaryState[0x600]{},secondaryState[0x600]{};static unsigned vertexPools[2][4]={{0,1,64,1024},{0,2,64,1024}};
static bool sizeRequested=false;
extern "C" bool RFGRVR_RenderWindow_Requested(unsigned* w,unsigned* h){*w=5328;*h=5552;return sizeRequested;}
static unsigned expectedWidth=0,expectedHeight=0,applyCalls=0;
static bool __cdecl checkResolutionSwitch(void* d,void* w,unsigned width,unsigned height,unsigned n,unsigned den,unsigned mode){assert(d==(void*)1&&w==(void*)2&&n==165002&&den==1000);assert(width==expectedWidth&&height==expectedHeight);++applyCalls;return mode==2;}
static bool __cdecl checkRenderBufferResize(void* window,unsigned w,unsigned h){assert(window==(void*)2&&w==expectedWidth&&h==expectedHeight);++applyCalls;return true;}
static void testResolutionTransaction(){
 switchResolution=checkResolutionSwitch;expectedWidth=3620;expectedHeight=2036;assert(OnSwitchResolution((void*)1,(void*)2,3620,2036,165002,1000,2));assert(applyCalls==1);
 sizeRequested=true;expectedWidth=1280;expectedHeight=720;assert(OnSwitchResolution((void*)1,(void*)2,3620,2036,165002,1000,2));assert(applyCalls==2);
 expectedWidth=1920;expectedHeight=1080;assert(!OnSwitchResolution((void*)1,(void*)2,1920,1080,165002,1000,1));assert(applyCalls==3);
 resizeRenderBuffers=checkRenderBufferResize;expectedWidth=5328;expectedHeight=5552;assert(OnResizeRenderBuffers((void*)2,1280,720));assert(applyCalls==4);sizeRequested=false;expectedWidth=1280;expectedHeight=720;assert(OnResizeRenderBuffers((void*)2,1280,720));assert(applyCalls==5);expectedWidth=0;expectedHeight=0;sizeRequested=true;assert(OnResizeRenderBuffers((void*)2,0,0));assert(applyCalls==6);unsigned cleanupBefore=resizeCleanupCalls;assert(OnResizeRenderBuffers((void*)2,0,0));assert(applyCalls==7&&resizeCleanupCalls==cleanupBefore);sizeRequested=false;switchResolution=nullptr;resizeRenderBuffers=nullptr;
}
extern "C" bool RFGRVR_RingPair_Install(){return true;}
extern "C" bool RFGRVR_HeadCam_Recent(){return true;}
extern "C" void RFGRVR_PixelProbe_Begin(){}
extern "C" void RFGRVR_PixelProbe_Select(unsigned){}
extern "C" void RFGRVR_PixelProbe_End(){}
extern "C" void RFGRVR_PairGpuMarker(const wchar_t*,bool){}
extern "C" void RFGRVR_RingPair_Begin(){}
extern "C" void RFGRVR_RingPair_End(){}
extern "C" bool RFGRVR_Temporal_OpticsFov(void*,float*){return false;}
extern "C" bool RFGRVR_Temporal_EyeProjection(void*,float[16],float*){return false;}
extern "C" void RFGRVR_Temporal_OpticsApplied(void*){}
extern "C" bool RFGRVR_Temporal_HoldFov(void*,float,float){return false;}
static bool popupTest=false;static unsigned char popupCacheTest[5]{};
static bool enabled=true,captureOK=true,lastComplete=false,advanceSimulation=false;
static unsigned calls=0,selections=0,captures=0,ends=0,simulation=25,armPrepares=0;
static unsigned long long drawCount=0;
static unsigned resourceBegins=0,resourceRestores=0,resourceEnds=0,diagnosticEnds=0;
static bool resourcesOK=true;
extern "C" void RFGRVR_NativePair_TestMode(unsigned,unsigned){}
extern "C" void RFGRVR_NativePair_Continuous(bool){}
extern "C" void RFGRVR_NativePair_DiagnosticEnd(){++diagnosticEnds;++ends;lastComplete=false;}
extern "C" bool RFGRVR_EyeResources_Begin(unsigned kinds){assert(kinds==1||kinds==2);++resourceBegins;return resourcesOK;}
extern "C" bool RFGRVR_EyeResources_Between(unsigned){++resourceRestores;return resourcesOK;}
extern "C" unsigned RFGRVR_EyeResources_Count(){return 3;}
extern "C" void RFGRVR_EyeResources_End(){++resourceEnds;}
extern "C" bool RFGRVR_EyePipeline_Begin(){return true;}
extern "C" void RFGRVR_EyePipeline_Between(unsigned){}
extern "C" void RFGRVR_EyePipeline_End(){}
extern "C" bool RFGRVR_NativePair_Begin(){return enabled;}
extern "C" void RFGRVR_NativePair_Select(unsigned eye){if(selections<2)assert(eye==selections);else assert(eye==1);++selections;}
extern "C" bool RFGRVR_NativePair_Capture(unsigned eye){assert(eye==captures++);return captureOK;}
extern "C" void RFGRVR_NativePair_End(bool complete){++ends;lastComplete=complete;}
extern "C" bool RFGRVR_NativePair_Projection(void*,float[16],float*){return false;}
static bool compatibleTest=false;static unsigned compatibilityApplied=0;
extern "C" bool RFGRVR_NativePair_CompatibilityFov(void*,float* fov){if(compatibleTest)*fov=88;return compatibleTest;}
extern "C" void RFGRVR_NativePair_CompatibilityApplied(void* camera){++compatibilityApplied;assert(*(float*)((char*)camera+0xc0)==123);}
static void __fastcall CompatibilityPrepare(void* camera,void*,void*){assert(*(float*)((char*)camera+0x140)==88);*(float*)((char*)camera+0xc0)=123;}
static void testCompatibilityPreparation(){unsigned char camera[0x598]{},renderer[0x500]{};*(float*)(camera+0x140)=75;compatibleTest=true;prepare=&CompatibilityPrepare;OnPrepare(camera,nullptr,renderer);assert(compatibilityApplied==1&&*(float*)(camera+0x140)==75&&*(float*)(camera+0xc0)==123);compatibleTest=false;prepare=nullptr;}
extern "C" void RFGRVR_NativePair_ProjectionApplied(){}
extern "C" unsigned RFGRVR_HeadCam_HeadSamples(){return simulation;}
extern "C" unsigned long long RFGRVR_GPU_DrawCount(){return drawCount;}
extern "C" void RFGRVR_GPUCapture_Mark(unsigned,void*,void*){}
extern "C" void RFGRVR_Arms_RenderWeapon(void* r){assert(r==renderFixture&&selections==armPrepares+1);++armPrepares;}
extern "C" void RFGRVR_NativePair_SetRequested(bool){}
static uintptr_t __cdecl Engine(void* a,unsigned b,void* c){
 assert(a==renderFixture&&b==1&&c==secondaryFixture);++calls;drawCount+=100;
 if(advanceSimulation)++simulation;return 42;
}
static unsigned outerCalls=0,cameraBegins=0;
static unsigned mapCalls=0,mapArgument=99;static uintptr_t __cdecl MapRender(void*,unsigned flag,void*){++mapCalls;mapArgument=flag;return 42;}
static uintptr_t __cdecl Outer(void* a,unsigned b,void* c){++outerCalls;return Engine(a,b,c);}
static void __fastcall Scene(void* self,void*,void* renderer,void* camera,void* scene,void* a4,void* a5,void* a6){
 if(vrnightlights::sceneRoot)assert(word(*vrnightlights::sceneRoot,0x130)==3);assert(self==sceneFixture&&renderer==renderFixture&&camera==secondaryFixture&&scene==(void*)0x40000&&a4==(void*)4&&a5==(void*)5&&a6==(void*)6);if(sunGeneration)assert(*sunGeneration==(auxiliaryTest?0:1));if(auxiliaryTest){assert(word(self,0x1f8)==256&&word(self,0x1fc)==144);if(popupGeometryCache)assert(!word(self,0x50)&&!popupGeometryCache[0]&&!popupGeometryCache[3]&&!popupGeometryCache[4]);if(popupWorldMaskVerified)assert(!(word(self,0x14)&3));}if(selections){assert(auxiliaryTest||armPrepares==selections);for(auto* r:{renderFixture,secondaryFixture}){auto* state=(unsigned char*)(uintptr_t)word(r,0x478);assert(*(void**)(state+0x70)==(void*)4);assert(*(float*)(state+0x74)==float(selections)&&*(float*)(state+0x440)==float(selections));assert(*(float*)(r+0xe0)==float(selections));}}++calls;drawCount+=100;if(advanceSimulation)++simulation;
}
static void __fastcall BeginCamera(void* camera,void*,void* renderer){if(popupTest){assert(!popupCacheTest[0]&&!popupCacheTest[3]&&!popupCacheTest[4]);assert(word(sceneFixture,0x50)==0&&(word(sceneFixture,0x14)&3)==0);}assert(camera==(void*)4&&(renderer==renderFixture||renderer==secondaryFixture));++cameraBegins;auto* state=(unsigned char*)(uintptr_t)word(renderer,0x478);*(void**)(state+0x70)=camera;*(float*)(state+0x74)=float(selections);*(float*)(state+0x440)=float(selections);*(float*)((char*)renderer+0xe0)=float(selections);}
static void pair(){runScenePair(sceneFixture,renderFixture,secondaryFixture,(void*)0x40000,(void*)4,(void*)5,(void*)6);}
static void reset(){calls=selections=captures=ends=armPrepares=0;lastComplete=false;}
static void __fastcall CheckInitialize(void* eye,void*,void* renderer,unsigned width,unsigned height,const void* lod,void* commands,unsigned bytes){
 assert(eye==(void*)0x40000);assert(renderer==renderFixture);assert(width==2560&&height==1440);assert(lod==(void*)0x304e4);assert(!commands&&!bytes);
}
static unsigned char cloneStorage[0x4bbe8]{};static void* cloneVtable[1]{};static void* expectedContext=nullptr;static const void* expectedLod=nullptr;static unsigned cloneInitializations=0;
static void* __cdecl AllocateClone(unsigned n){assert(n==sizeof(cloneStorage));return cloneStorage;}
static void* __fastcall ConstructClone(void* raw,void*){assert(raw==cloneStorage);*(void***)raw=cloneVtable;return raw;}
static void __fastcall DestroyClone(void* raw,void*,unsigned){assert(raw==cloneStorage);}
static void __fastcall InitializeClone(void* eye,void*,void* context,unsigned w,unsigned h,const void* lod,void* commands,unsigned bytes){
 assert(eye==cloneStorage&&context==expectedContext&&lod==expectedLod&&!commands&&!bytes);++cloneInitializations;
 *(unsigned*)(cloneStorage+0x1f8)=w;*(unsigned*)(cloneStorage+0x1fc)=h;*(unsigned*)(cloneStorage+0x220)=0x2222;*(unsigned*)(cloneStorage+0x4bb24)=1;*(unsigned*)(cloneStorage+0x4bb28)=2;
}
static unsigned char leftTerrain[0x3d308]{},rightTerrain[0x3d308]{},terrainWorld[0x710]{};static unsigned terrainCalls=0;
static void __fastcall InitializeTerrain(void* self,void*){++terrainCalls;assert(self==leftTerrain||self==rightTerrain);*(void**)((char*)self+0x3d2e4)=terrainWorld;}
static unsigned ringRequested=0;static void __fastcall ConfigureRing(void* self,void*,unsigned size){ringRequested=size;if(self)*(unsigned*)((char*)self+0x14)=size;}
static void __fastcall InitializeRing(void* self,void*){assert(*(unsigned*)((char*)self+0x14)==40u*1024*1024);*((unsigned char*)self+0x1c)=1;}
static unsigned skyRefreshCalls=0;static void __cdecl TestSkyRefresh(){assert(vrnightlights::sceneRoot&&*vrnightlights::sceneRoot&&word(*vrnightlights::sceneRoot,0x130)==3);++skyRefreshCalls;}
static void* skyExpected=nullptr;static void** skySlot=nullptr;static unsigned skyObserved=0;static void __cdecl checkSkyAccessor(){assert(*skySlot==skyExpected);++skyObserved;}
static void* orbitalOriginalCamera=nullptr;static const void* orbitalExpectedRecord=nullptr;static vrarm::M orbitalExpectedBasis{};static bool orbitalExpectClone=true;static unsigned orbitalCalls=0;
static void __fastcall checkOrbital(void*,void*,void*,void* camera,const void* record){++orbitalCalls;assert(record==orbitalExpectedRecord);if(orbitalExpectClone){assert(camera!=orbitalOriginalCamera);assert(!memcmp((char*)camera+8,&orbitalExpectedBasis,36));assert(!memcmp((char*)camera+0x2c,(char*)orbitalOriginalCamera+0x2c,12));}else assert(camera==orbitalOriginalCamera);}
static void testOrbitalDraw(){using namespace vrarm;unsigned char camera[0x38]{},record[0x28]{};V direction{-.196374f,.93433f,.297432f};memcpy(record+0x10,&direction,12);*(float*)(record+0x1c)=.02f;*(unsigned*)(record+0x20)=27;unsigned char savedRecord[sizeof(record)];memcpy(savedRecord,record,sizeof(record));orbitalOriginalCamera=camera;orbitalExpectedRecord=record;assert(RFGRVR_OrbitalBillboard(direction,orbitalExpectedBasis));orbitalDraw=(OrbitalDraw)checkOrbital;
 for(int i=-10;i<=10;++i){M native=turnAround(M{{1,0,0},{0,1,0},{0,0,1}},unit(direction),i*.1f);memcpy(camera+8,&native,36);unsigned char saved[sizeof(camera)];memcpy(saved,camera,sizeof(camera));onOrbitalDraw(nullptr,nullptr,nullptr,camera,record);assert(!memcmp(saved,camera,sizeof(camera))&&!memcmp(savedRecord,record,sizeof(record)));}assert(orbitalCalls==21);
 orbitalExpectClone=false;vrHeadEnabled=false;onOrbitalDraw(nullptr,nullptr,nullptr,camera,record);vrHeadEnabled=true;memset(record+0x10,0,12);onOrbitalDraw(nullptr,nullptr,nullptr,camera,record);assert(orbitalCalls==23);orbitalExpectClone=true;orbitalDraw=nullptr;
}
static unsigned sunDraws=0;static void __fastcall checkSun(void*,void*,void*,void*){++sunDraws;}
static void __fastcall compositeCheck(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h,uintptr_t i){assert(!*(void**)((char*)self+0x978)&&*(void**)((char*)self+0xaac)==(void*)88&&a==1&&b==2&&c==3&&d==4&&e==5&&f==6&&g==7&&h==8&&i==9);}
static unsigned lensDraws=0;static void __fastcall testLens(void*,void*,void*,void*){++lensDraws;}
static void testSkyAndSun(){vrglare::lens=(vrglare::Lens)testLens;for(int eye=0;eye<2;++eye)vrglare::onLens(nullptr,nullptr,nullptr,nullptr);assert(!lensDraws);vrglare::lens=nullptr;unsigned char owner[0xba8]{};*(void**)(owner+0x978)=(void*)77;*(void**)(owner+0xaac)=(void*)88;vrglare::composite=(vrglare::Composite)compositeCheck;for(int eye=0;eye<2;++eye){vrglare::onComposite(owner,nullptr,1,2,3,4,5,6,7,8,9);assert(*(void**)(owner+0x978)==(void*)77&&*(void**)(owner+0xaac)==(void*)88);}vrglare::composite=nullptr;{vrglare::CompositeSunScope inactive(owner,false);assert(*(void**)(owner+0x978)==(void*)77&&*(void**)(owner+0xaac)==(void*)88);}unsigned char scene[0x140]{};skySlot=(void**)(scene+0x130);*skySlot=(void*)3;skyExpected=(void*)3;void* nativeScene=scene;vrnightlights::sceneRoot=&nativeScene;skyRefresh=checkSkyAccessor;refreshEyeSky(nullptr,(void*)4);assert(skyObserved==1&&*skySlot==(void*)3);unsigned char glareEntry[0x5c]{};memcpy(glareEntry,"SunGlare01",11);float glow=3;memcpy(glareEntry+0x50,&glow,4);assert(sunGlare.apply(glareEntry,true));for(int eye=0;eye<2;++eye){memcpy(glareEntry+0x50,&glow,4);refreshEyeSky(scene,skyExpected);float current;memcpy(&current,glareEntry+0x50,4);assert(current==0);}sunGlare.apply(nullptr,false);skyRefresh=nullptr;vrnightlights::sceneRoot=nullptr;unsigned char sun[0x2c]{};void* selected=sun;sunObject=&selected;sunSprite=(SunSprite)checkSun;*(float*)(sun+0x28)=1;onSunSprite(sun,nullptr,nullptr,nullptr);assert(*(float*)(sun+0x28)==1&&sunDraws==0);void* other=(void*)1;selected=other;onSunSprite(sun,nullptr,nullptr,nullptr);assert(sunDraws==1);sunObject=nullptr;sunSprite=nullptr;}
int main(){testOrbitalDraw();testSkyAndSun(); {unsigned char flag=1;{vrglare::SunGenerationScope enabled(&flag,true);assert(flag==0);{vrglare::SunGenerationScope nested(&flag,true);assert(flag==0);}assert(flag==0);}assert(flag==1);{vrglare::SunGenerationScope standard(&flag,false);assert(flag==1);}assert(flag==1);} {unsigned char readSig[7]={0x80,0x3d},retainSig[7]={0x80,0x3d};uint32_t a=0x251bd1b,b=0x251bd18;memcpy(readSig+2,&a,4);memcpy(retainSig+2,&b,4);assert(RFGRVRMenuGeometrySignature(readSig,retainSig,a,b));assert(!RFGRVRMenuGeometrySignature(readSig,retainSig,0x1b7bd1b,0x1b7bd18));}
 {uint8_t state[5]={1,7,8,1,1};uint32_t queue=123;
 for(unsigned eye=0;eye<2;++eye){ {RFGRVRMenuGeometryScope scope(state,&queue,true);assert(!state[0]&&!state[3]&&!state[4]&&!queue);assert(state[1]==7&&state[2]==8);queue=456;queue=0;state[3]=1;}assert(queue==123&&state[0]==1&&state[3]==1&&state[4]==1);}
 {RFGRVRMenuGeometryScope scope(state,&queue,false);assert(queue==123&&state[0]==1);}}
 // Paused menus must neither capture into nor replay the flat snapshot.
 for(uint32_t initial: {1u,2u,3u,11u}){uint32_t flags=initial;{RFGRVRMenuWorldScope scope(&flags,true);assert((flags&3u)==0);flags|=8;}assert(flags==(initial|8u));{RFGRVRMenuWorldScope scope(&flags,false);assert(flags==(initial|8u));}}
 testCompatibilityPreparation();
 *(void**)(renderFixture+0x478)=primaryState;*(void**)(secondaryFixture+0x478)=secondaryState;
 *(void**)(renderFixture+0x24)=vertexPools[0];*(void**)(secondaryFixture+0x24)=vertexPools[1];
 testMode=4;attempted=1;failed=2;retryAfter=100;assert(!canAttemptPair(99)&&canAttemptPair(100));testMode=1;assert(!canAttemptPair(100));testMode=0;attempted=0;failed=0;retryAfter=0;
 testResolutionTransaction();
 reuseOriginalRenderer=false;ringCapacityOriginal=(RingCapacity)&ConfigureRing;OnRingCapacity(nullptr,nullptr,1024);assert(ringRequested==1024);
 wchar_t gate[MAX_PATH]{};GetModuleFileNameW(nullptr,gate,MAX_PATH);auto* slash=wcsrchr(gate,92);wcscpy_s(slash+1,MAX_PATH-(slash+1-gate),L"RFGRVR-independent-stereo.enable");HANDLE file=CreateFileW(gate,GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);assert(file!=INVALID_HANDLE_VALUE);CloseHandle(file);
 OnRingCapacity(nullptr,nullptr,10u*1024*1024);assert(ringRequested==40u*1024*1024);
 unsigned char ringObject[0x28]{};*(unsigned*)(ringObject+0x14)=10u*1024*1024;ringInitializeOriginal=(RingInitialize)&InitializeRing;OnRingInitialize(ringObject,nullptr);assert(ringObject[0x1c]==1&&*(unsigned*)(ringObject+0x14)==40u*1024*1024);
 DeleteFileW(gate);
 OnRingCapacity(nullptr,nullptr,10u*1024*1024);assert(ringRequested==10u*1024*1024);

 unsigned char original[0x4bbe8]{},context[8]{},lod[0x94]{};*(unsigned*)(original+0x220)=0x1111;expectedContext=context;expectedLod=lod;cloneVtable[0]=(void*)&DestroyClone;
 allocateEye=&AllocateClone;constructEye=(Construct)&ConstructClone;initializeOriginal=(Initialize)&InitializeClone;
 assert(!createIndependentEye(original,context,2560,1440,lod,(void*)1,64)&&cloneInitializations==0);
 assert(createIndependentEye(original,context,2560,1440,lod,nullptr,0)&&cloneInitializations==1);
 assert(resources.original==original&&resources.right==cloneStorage&&!resources.scene);
 *(void**)(original+0x1c)=leftTerrain;*(void**)(cloneStorage+0x1c)=rightTerrain;terrainInitializeOriginal=(TerrainInitialize)&InitializeTerrain;
 OnTerrainInitialize(leftTerrain,nullptr);assert(terrainCalls==2&&word(rightTerrain,0x3d2e4)==(unsigned)(uintptr_t)terrainWorld);
 disposeResources();

 // The actual engine rail-vision flag is suppressed only during ordinary
 // eye rendering, then restored for the auxiliary native scope camera.
 {unsigned char vision=1;nativeScopeVision=&vision;vrscope::nativeVisualKind=1;vrscope::frame.kind=1;vrscope::frame.tick=GetTickCount64();{unsigned char scene[0x208]{};scene[0x1b8]=1;scene[0x1b9]=37;{NativeScopeWorldVision scope(scene);assert(vision==0&&scene[0x1b8]==0&&scene[0x1b9]==37);}assert(scene[0x1b8]==1&&scene[0x1b9]==37);}assert(vision==1);vrscope::frame.kind=0;vrscope::nativeVisualKind=0;{NativeScopeWorldVision scope;assert(vision==1);}nativeScopeVision=nullptr;vrscope::nativeVisualKind=-1;vrscope::frame={};}
 // A reused engine renderer is borrowed and must never be destroyed by this module.
 reuseOriginalRenderer=true;resources={nullptr,sceneFixture,sceneFixture,2560,1440};disposeResources();assert(!resources.right);
 initializeEye((Initialize)&CheckInitialize,(void*)0x40000,renderFixture,2560,1440,(void*)0x304e4);
 unsigned char fakeScene[0x140]{};
 resources={fakeScene,sceneFixture,(void*)0x40000,2560,1440};
 render=&Outer;sceneRender=(SceneRender)&Scene;cameraBegin=(CameraBegin)&BeginCamera;
 assert(OnRender(renderFixture,1,secondaryFixture)==42);assert(outerCalls==1&&calls==1&&captures==0);reset();
 {auto old=render;render=MapRender;mapWorldGateVerified=true;testMapMenu=true;unsigned writer=1;*(void**)(renderFixture+0x440)=&writer;assert(OnRender(renderFixture,0,secondaryFixture)==42&&mapCalls==1&&mapArgument==1);*(void**)(renderFixture+0x440)=nullptr;assert(OnRender(renderFixture,0,secondaryFixture)==42&&mapArgument==0);unsigned count=mapCalls;RFGRVR_MapWorld_Present(nullptr);assert(mapCalls==count);testMapMenu=false;*(void**)(renderFixture+0x440)=&writer;assert(OnRender(renderFixture,0,secondaryFixture)==42&&mapArgument==0);*(void**)(renderFixture+0x440)=nullptr;mapWorldGateVerified=false;render=old;}
 void* nativeSkyScene=sceneFixture;vrnightlights::sceneRoot=&nativeSkyScene;*(void**)(sceneFixture+0x130)=(void*)3;skyRefresh=&TestSkyRefresh;pair();assert(skyRefreshCalls==2&&word(sceneFixture,0x130)==3);skyRefresh=nullptr;vrnightlights::sceneRoot=nullptr;assert(calls==2&&cameraBegins==4&&captures==2&&ends==1&&lastComplete&&simulation==25);
 // Frozen-view cache invalidation must surround camera preparation, not
 // just geometry drawing. Both eyes see new view constants while paused.
 {popupTest=true;popupWorldMaskVerified=true;popupGeometryCache=popupCacheTest;popupCacheTest[0]=popupCacheTest[3]=popupCacheTest[4]=1;*(unsigned*)(sceneFixture+0x14)=3;*(unsigned*)(sceneFixture+0x50)=123;reset();pair();assert(calls==2&&captures==2&&popupCacheTest[0]==1&&popupCacheTest[3]==1&&popupCacheTest[4]==1&&word(sceneFixture,0x50)==123&&word(sceneFixture,0x14)==3);popupTest=false;popupGeometryCache=nullptr;popupWorldMaskVerified=false;}
 reset();captureOK=false;pair();assert(calls==1&&ends==1&&!lastComplete);
 reset();captureOK=true;advanceSimulation=true;pair();assert(calls==2&&ends==1&&lastComplete);
 reset();enabled=false;pair();assert(calls==1&&selections==0&&ends==0);
 enabled=true;advanceSimulation=false;testMode=2;reset();pair();
 assert(calls==2&&resourceBegins==1&&resourceRestores==1&&resourceEnds==1&&diagnosticEnds==1&&!lastComplete);
 resourcesOK=false;reset();pair();assert(calls==1&&selections==0&&resourceEnds==2&&!lastComplete);
 resourcesOK=true;testMode=4;reset();pair();assert(calls==2&&lastComplete&&resourceBegins==2);
 // Optional camera rendering occurs after two completed headset captures,
 // and never republishes arms or treats a monitor feed as an eye.
 RFGRVRAPC::packet.active=3;RFGRVRAPC::identity=123;RFGRVRAPC::nativeMounts[0]={{{1,0,0},{0,1,0},{0,0,1}},{}};
 unsigned char auxiliarySunFlag=1;sunGeneration=&auxiliarySunFlag;reset();pair();assert(auxiliarySunFlag==1);sunGeneration=nullptr;assert(calls==4&&captures==2&&armPrepares==2&&auxiliaryCaptures==2&&lastComplete&&!auxiliaryTest);assert(word(sceneFixture,0x1f8)==0&&word(sceneFixture,0x1fc)==0);assert(*(float*)(renderFixture+0xe0)==2);
 RFGRVRAPC::packet.active=1;reset();pair();assert(calls==2&&auxiliaryCaptures==2);RFGRVRAPC::packet.active=0;RFGRVRAPC::identity=~0u;
 // A scope gets two eye-specific auxiliary renders, only while visible; never four APC feeds.
 {popupGeometryCache=popupCacheTest;popupCacheTest[0]=popupCacheTest[3]=popupCacheTest[4]=1;*(unsigned*)(sceneFixture+0x50)=0x1234;auto& f=vrscope::frame;f.kind=0;f.alpha=1;f.tick=GetTickCount64();f.camera={{{1,0,0},{0,1,0},{0,0,1}},{0,1,0}};unsigned prior=auxiliaryCaptures;reset();pair();assert(calls==4&&captures==2&&armPrepares==2&&auxiliaryCaptures==prior+2&&!auxiliaryTest);assert(word(sceneFixture,0x50)==0x1234&&popupCacheTest[0]&&popupCacheTest[3]&&popupCacheTest[4]);f.alpha=0;reset();pair();assert(calls==2);popupGeometryCache=nullptr;}
 unsigned char rendererBytes[0x480];memset(rendererBytes,0x12,sizeof(rendererBytes));RFGRVRRendererCache cache;cache.save(rendererBytes);
 memset(rendererBytes+0x30,0x34,0x410);cache.restore(rendererBytes);assert(rendererBytes[0x30]==0x12&&rendererBytes[0x43f]==0x12);
 assert(rendererBytes[0x440]==0x12&&rendererBytes[0x478]==0x12&&*(unsigned*)(rendererBytes+0x444)==0xff);
 assert(!continuousMode(5)&&!continuousMode(6)&&!continuousMode(7)&&continuousMode(8)&&continuousMode(9)&&continuousMode(10));
 testMode=5;reset();pair();assert(calls==2&&!lastComplete&&diagnosticEnds==3);
}







extern "C" bool RFGRVR_HeadCam_MenuScene(){return false;}
extern "C" void RFGRVR_MenuModelSource(ID3D11DeviceContext*){}

extern "C" bool RFGRVR_HeadCam_MapMenu(){return testMapMenu;}
extern "C" bool RFGRVR_HeadCam_PopupMenu(){return popupTest;}


extern "C" bool RFGRVR_Scope_AuxView(unsigned,vrarm::Pose* out){*out=vrscope::frame.camera;return true;}

extern "C" void RFGRVR_Temporal_Recenter(){}

extern "C" bool RFGRVR_HeadCam_PauseMenu(){return false;}



