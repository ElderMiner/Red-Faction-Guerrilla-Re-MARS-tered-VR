#define RFGR_TEST_USER_SETTINGS
#include "../src/vr_deferred_probe.h"
// Exercise the actual temporal camera mutation against a synthetic engine layout.
// In particular, a superficially plausible +0x100 write must fail these checks.
#include "../src/temporal_stereo.cpp"
#include <cassert>
extern "C" bool RFGRVR_VehicleSitting(){return false;}
extern "C" bool RFGRVR_Arms_PistolLaser(vrarm::Pose*){return false;}
extern "C" bool RFGRVR_HeadCam_Cinematic(){return false;}
static bool popupTest=false;static bool menuTest=false;extern "C" bool RFGRVR_HeadCam_MenuScene(){return menuTest;}
extern "C" void RFGRVR_AudioListener(const float[3],const float[9]){}
extern "C" bool RFGRVR_Arms_TurretHand(float[3],float[3]){return false;}
extern "C" float RFGRVR_Arms_TurretLever(const float[3]){return .55f;}
extern "C" bool RFGRVR_HeadCam_TurretPivot(float[3],unsigned*){return false;}
extern "C" bool RFGRVR_HeadCam_TurretMounted(){return false;}
extern "C" bool RFGRVR_HeadCam_TurretAngles(float*,float*){return false;}
extern "C" bool RFGRVR_HeadCam_TurretRoom(float[3]){return false;}
extern "C" void RFGRVR_VehicleView(const float[3],const float[9],const RFGRPose*){}
static bool renderSizeReady=true; extern "C" bool RFGRVR_RenderWindow_Ready(unsigned,unsigned){return false;}
extern "C" bool RFGRVR_RenderWindow_Requested(unsigned* w,unsigned* h){*w=5328;*h=5552;return renderSizeReady;}
static float testHead[3]={10,20,30};
extern "C" bool RFGRVR_HeadCam_GetPosition(float p[3]){memcpy(p,testHead,12);return true;}
extern "C" bool RFGRVR_HeadCam_Enabled(){return true;}
static float testWorldScale=1;extern "C" float RFGRVR_HeadCam_WorldScale(){return testWorldScale;}
static float sceneScaleOverride=0;extern "C" float RFGRVR_HeadCam_SceneScale(){return sceneScaleOverride>0?sceneScaleOverride:testWorldScale;}
extern "C" bool RFGRVR_LegacyLook_Enabled(){return false;}
extern "C" bool RFGRVR_GameplayProjection_Enabled(){return true;}
static unsigned testParentState=9;static bool attached=false;static float movingParent[9]={1,0,0,0,1,0,0,0,1};
static bool frameReady=true;static float testFloorEye=0;static bool floorCalibration=false;
extern "C" bool RFGRVR_HeadCam_GetFrame(float p[3],float parent[9],bool* isAttached,unsigned* state,float* floorEye){if(!frameReady)return false;memcpy(p,testHead,12);memcpy(parent,movingParent,36);*isAttached=attached;*state=attached?testParentState:0;*floorEye=floorCalibration?testFloorEye:0;return true;}
extern "C" void RFGRVR_HeadCam_FloorCalibration(bool valid){floorCalibration=valid;}
extern "C" bool RFGRVR_HeadCam_Parent(float out[9],unsigned* state){memcpy(out,movingParent,36);*state=attached?testParentState:0;return attached;}
static unsigned headingUpdates=0;extern "C" void RFGRVR_HeadCam_SetBodyYaw(float){++headingUpdates;}
static bool auxiliaryMode=false;extern "C" void RFGRVR_HeadCam_Auxiliary(bool active){auxiliaryMode=active;}
extern "C" void RFGRVR_HeadCam_RenderBegin(const float[3],const float[9]){}
extern "C" void RFGRVR_HeadCam_RenderEnd(){}
extern "C" void RFGRVR_HeadCam_CalibratedHeight(float){}
extern "C" void RFGRVR_HeadCam_RoomRequest(float,float,float,float){}
static bool controllerMoving=false;extern "C" bool RFGRVR_HeadCam_ControllerMoving(){return controllerMoving;}
static float movedRaw[3]{};
extern "C" void RFGRVR_HeadCam_RoomConsumed(float out[3]){memcpy(out,movedRaw,12);memset(movedRaw,0,12);}
static unsigned armPublishes=0,armRefreshes=0;static float publishedRightX=0;
extern "C" void RFGRVR_Arms_Publish(RFGRShared* source,const float[3],const float[9],const float[4],const RFGRPose*){++armPublishes;publishedRightX=source->right.position[0];}
extern "C" void RFGRVR_HeadCam_RefreshArms(){assert(armPublishes==armRefreshes+1);++armRefreshes;}
static bool close(float a,float b){return fabsf(a-b)<.0001f;}
static void testActivePairScreensAndResize(){
 HWND window=CreateWindowExW(0,L"STATIC",L"APC GPU test",WS_POPUP,0,0,128,128,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);assert(window);
 DXGI_SWAP_CHAIN_DESC sd{};sd.BufferDesc.Width=sd.BufferDesc.Height=128;sd.BufferDesc.Format=DXGI_FORMAT_B8G8R8A8_UNORM;sd.SampleDesc.Count=1;sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;sd.BufferCount=2;sd.OutputWindow=window;sd.Windowed=TRUE;sd.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;ComPtr<IDXGISwapChain> swap;
 assert(SUCCEEDED(D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&sd,&swap,&device,nullptr,&context)));
 ComPtr<ID3D11Texture2D> back,input,readback,z;ComPtr<ID3D11RenderTargetView> backView,inputView;ComPtr<ID3D11DepthStencilView> zView;
 assert(SUCCEEDED(swap->GetBuffer(0,IID_PPV_ARGS(&back))));assert(SUCCEEDED(device->CreateRenderTargetView(back.Get(),nullptr,&backView)));
 D3D11_TEXTURE2D_DESC td{};back->GetDesc(&td);td.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;td.MiscFlags=0;assert(SUCCEEDED(device->CreateTexture2D(&td,nullptr,&input)));assert(SUCCEEDED(device->CreateRenderTargetView(input.Get(),nullptr,&inputView)));
 g.device=device;g.context=context;g.nativeSwap=swap;g.nativeActive=true;g.width=g.height=128;g.format=td.Format;g.evidenceWritten=true;g.nativeFrame=2;g.outstanding=true;g.matrixOutstanding=false;g.nativeProjectionCalls=1;
 for(unsigned eye=0;eye<2;++eye){g.texture[eye].Reset();assert(SUCCEEDED(device->CreateTexture2D(&td,nullptr,&g.texture[eye])));}
 td.Format=DXGI_FORMAT_D32_FLOAT;td.BindFlags=D3D11_BIND_DEPTH_STENCIL;assert(SUCCEEDED(device->CreateTexture2D(&td,nullptr,&z)));assert(SUCCEEDED(device->CreateDepthStencilView(z.Get(),nullptr,&zView)));
 RFGRAPCTargets::configure(device.Get(),128,128);RFGRAPCTargets::sceneDepth=zView;
 const float red[4]={1,0,0,1},black[4]={0,0,0,1};context->ClearRenderTargetView(inputView.Get(),red);assert(auxiliaryGpu.capture(device.Get(),context.Get(),input.Get(),0));
 vrarm::M unit{{1,0,0},{0,1,0},{0,0,1}};RFGRVRAPC::packet.active=7;RFGRVRAPC::validFeeds=1;RFGRVRAPC::nativeScreens={unit,{0,0,2}};RFGRVRAPC::assemblyScale=RFGRVRAPC::scale=1;memset(g.shifted,0,sizeof(g.shifted));memcpy(g.writtenMatrix,&unit,36);
 unsigned char camera[0x600]{};float angles[4]={-.785398f,.785398f,.785398f,-.785398f};RFGRVREyeProjection projection{};assert(RFGRVR_BuildEngineProjection(angles,.1f,100,&projection));memcpy(camera+0xc0,projection.columnMajor,64);g.camera=camera;
 td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.BindFlags=0;td.Usage=D3D11_USAGE_STAGING;td.CPUAccessFlags=D3D11_CPU_ACCESS_READ;assert(SUCCEEDED(device->CreateTexture2D(&td,nullptr,&readback)));unsigned before=apcScreenDraws;
 for(unsigned eye=0;eye<2;++eye){context->ClearRenderTargetView(backView.Get(),black);context->ClearDepthStencilView(zView.Get(),D3D11_CLEAR_DEPTH,1,0);g.nativeEye=eye;assert(RFGRVR_NativePair_Capture(eye));context->CopyResource(readback.Get(),g.texture[eye].Get());D3D11_MAPPED_SUBRESOURCE mapped{};assert(SUCCEEDED(context->Map(readback.Get(),0,D3D11_MAP_READ,0,&mapped)));assert(*(unsigned*)((char*)mapped.pData+64*mapped.RowPitch+64*4)==0xffff0000u);context->Unmap(readback.Get(),0);}
 assert(apcScreenDraws==before+2);
 menuTest=true;assert(!RFGRVR_NativePair_Begin()&&menuPairStage==0x100);menuTest=false;
 // Resolution uses the player eye, not the preceding exterior camera.
 g.outstanding=false;RFGRVR_APC_Pipeline(true);g.width=g.height=2000;g.nativeSourceProjection[1][0]=1;RFGRVRAPC::renderIndex=0;g.shifted[0]=100;vrarm::Pose exterior{unit,{100,0,0}};RFGRVR_APC_AuxSet(&exterior);assert(RFGRAPCTargets::width==1024);RFGRVR_APC_AuxSet(nullptr);g.width=g.height=128;RFGRVR_APC_Pipeline(false);

 // Reproduce DXGI's explicit-reference failure, then exercise its cleanup.
 RFGRAPCTargets::begin(64,36);assert(RFGRAPCTargets::resource(back.Get())!=back.Get());assert(RFGRAPCTargets::end());backView.Reset();back.Reset();context->ClearState();context->Flush();
 assert(swap->ResizeBuffers(2,160,160,DXGI_FORMAT_B8G8R8A8_UNORM,0)==DXGI_ERROR_INVALID_CALL);
 scopeCapturedTick=GetTickCount64();auto privateCaptureTick=scopeCapturedTick;RFGRVR_APC_BeforeResize();assert(scopeCapturedTick==privateCaptureTick); assert(SUCCEEDED(swap->ResizeBuffers(2,160,160,DXGI_FORMAT_B8G8R8A8_UNORM,0)));
 g.camera=nullptr;g.outstanding=false;g.nativeActive=false;g.nativeSwap.Reset();g.context.Reset();g.device.Reset();DestroyWindow(window);
}
int main(){worldScreens.displayFilter=false;
 alignas(16) unsigned char camera[0x600]{};
 float identity[9]={1,0,0,0,1,0,0,0,1};
 memcpy(camera+8,identity,sizeof(identity));
 float originalPos[3]={100,200,300};memcpy(camera+0x2c,originalPos,12);
 float derived[16];for(int i=0;i<16;++i)derived[i]=float(1000+i);
 memcpy(camera+0x100,derived,64);
 RFGRShared state{};state.magic=RFGR_MAGIC;state.version=RFGR_PROTOCOL;state.openxrState=5;
 state.hmd.validFlags=3;state.hmd.orientation[3]=1;g.tracking=&state;
 RFGRVR_Temporal_CameraBegin(camera);
 assert(g.outstanding&&g.matrixOutstanding&&g.trackedFrames==1);
 assert(close(((float*)(camera+0x2c))[0],10-.032f));
 restore();assert(!memcmp(camera+8,identity,36));assert(!memcmp(camera+0x2c,originalPos,12));
 const float s=sqrtf(.5f);
 state.hmd.orientation[1]=s;state.hmd.orientation[3]=s;
 state.hmd.position[0]=.25f;state.hmd.position[1]=.5f;state.hmd.position[2]=-.75f;
 RFGRVR_Temporal_CameraBegin(camera);
 const float* b=(float*)(camera+8);const float* p=(float*)(camera+0x2c);
 assert(close(b[0],0)&&close(b[2],1)); // Actual engine input rotates.
 assert(close(p[0],10.25f)&&close(p[1],20.5f)&&close(p[2],30.75f-.032f));
 assert(!memcmp(camera+0x100,derived,64)); // Derived view belongs to the engine.
 restore();
 // Recenter at 90 degrees: world-space tracking displacement needs inverse calibration.
 RFGRVR_Temporal_Recenter();RFGRVR_Temporal_CameraBegin(camera);restore();
 state.hmd.position[0]+=.3f;
 RFGRVR_Temporal_CameraBegin(camera);p=(float*)(camera+0x2c);
 assert(close(p[0],10-.032f)&&close(p[1],20)&&close(p[2],30-.3f));
 restore();
 // The source frustum must cover every headset ray at the actual game aspect.
 g.width=2560;g.height=1440;state.stereoValid=1;
 for(int eye=0;eye<2;++eye){float fov[4]={-1.03f,.88f,.86f,-1.05f};memcpy(state.eyes[eye].fov,fov,16);}
 RFGRVR_Temporal_CameraBegin(camera);float requestedFov=0;
 renderSizeReady=false;assert(!RFGRVR_Temporal_OpticsFov(camera,&requestedFov));renderSizeReady=true;
 assert(RFGRVR_Temporal_OpticsFov(camera,&requestedFov));
 float extent=tanf(requestedFov*3.14159265358979323846f/360.f);
 for(auto& eye:state.eyes)for(int i=0;i<4;++i)assert(fabsf(tanf(eye.fov[i]))<(i<2?extent*2560.f/1440.f:extent));
 // Frame-scoped optics survive secondary passes and restore at frame completion.
 float oldFov=85;memcpy(camera+0x140,&oldFov,4);
 assert(RFGRVR_Temporal_HoldFov(camera,oldFov,requestedFov));memcpy(camera+0x140,&requestedFov,4);
 assert(!RFGRVR_Temporal_HoldFov((void*)0x10000,oldFov,requestedFov));
 float displacement=0;for(int j=0;j<3;++j){float d=g.renderedPose.position[j]-state.hmd.position[j];displacement+=d*d;}
 assert(close(sqrtf(displacement),.032f));
 // The selected eye uses all source pixels, including asymmetric corners.
 float nearPlane=.05f,farPlane=1000.f;memcpy(camera+0x590,&nearPlane,4);memcpy(camera+0x594,&farPlane,4);
 float eyeProjection[16]{},eyeCullFov=0;assert(RFGRVR_Temporal_EyeProjection(camera,eyeProjection,&eyeCullFov));
 const float* angles=state.eyes[g.nextEye].fov;
 assert(close(.5f+.5f*(eyeProjection[0]*tanf(angles[0])+eyeProjection[8]),0));
 assert(close(.5f+.5f*(eyeProjection[0]*tanf(angles[1])+eyeProjection[8]),1));
 assert(close(.5f-.5f*(eyeProjection[5]*tanf(angles[2])+eyeProjection[9]),0));
 assert(close(.5f-.5f*(eyeProjection[5]*tanf(angles[3])+eyeProjection[9]),1));
 const float oldHorizontalScale=1.f/(extent*2560.f/1440.f);assert(eyeProjection[0]>oldHorizontalScale*1.5f);
 // Tracking and native clipping distances are preserved; FOV is frozen for this frame.
 float savedAngle=state.eyes[g.nextEye].fov[0];state.eyes[g.nextEye].fov[0]=-.5f;
 float frozen[16]{},frozenCull=0;assert(RFGRVR_Temporal_EyeProjection(camera,frozen,&frozenCull));assert(!memcmp(frozen,eyeProjection,64));state.eyes[g.nextEye].fov[0]=savedAngle;
 memcpy(camera+0xc0,eyeProjection,64);RFGRVR_Temporal_OpticsApplied(camera);assert(!memcmp(g.temporalProjection,eyeProjection,64));
 restore();assert(close(*(float*)(camera+0x140),85.f));
 assert(!RFGRVR_Temporal_EyeProjection(camera,eyeProjection,&eyeCullFov));
 // Entering VR with a rolled head must retain room-up, not make the tilt level.
 g.calibrated=false;g.recenterYaw=false;state.hmd.orientation[0]=state.hmd.orientation[1]=0;
 state.hmd.orientation[2]=sinf(.25f);state.hmd.orientation[3]=cosf(.25f);
 RFGRVR_Temporal_CameraBegin(camera);
 assert(close(g.calibration[0],0)&&close(g.calibration[1],0)&&close(g.calibration[2],0)&&close(g.calibration[3],1));
 assert(close(g.worldBasis[1][0],0)&&close(g.worldBasis[1][1],1)&&close(g.worldBasis[1][2],0));
 assert(fabsf(g.writtenMatrix[3])>.4f);restore();
 RFGRVR_Temporal_Recenter();RFGRVR_Temporal_CameraBegin(camera);
 assert(close(g.calibration[0],0)&&close(g.calibration[2],0));
 assert(fabsf(g.writtenMatrix[3])>.4f);restore();
 // Vehicle motion carries the view, and detachment retains the final orientation.
 state.hmd.orientation[0]=state.hmd.orientation[1]=state.hmd.orientation[2]=0;state.hmd.orientation[3]=1;
 g.calibrated=false;g.recenterYaw=false;attached=true;
 RFGRVR_Temporal_CameraBegin(camera);restore();
 float vehicleYaw[9]={0,0,-1,0,1,0,1,0,0};memcpy(movingParent,vehicleYaw,36);
 RFGRVR_Temporal_CameraBegin(camera);assert(close(g.writtenMatrix[6],1));restore();
 float tiltedParent[9]={0,0,-1,-.3f,sqrtf(.91f),0,sqrtf(.91f),.3f,0};memcpy(movingParent,tiltedParent,36);
 RFGRVR_Temporal_CameraBegin(camera);assert(fabsf(g.writtenMatrix[7])>.2f);restore();
 attached=false;RFGRVR_Temporal_CameraBegin(camera);assert(close(g.writtenMatrix[6],1));restore();
 assert(close(g.writtenMatrix[3],0)&&close(g.writtenMatrix[4],1)&&close(g.writtenMatrix[7],0));
 // Accepted room movement updates the tracking origin rather than doubling camera travel.
 memcpy(g.worldBasis,identity,36);memset(g.origin,0,12);g.calibrated=true;g.wasParented=false;
 state.hmd.position[0]=.3f;state.hmd.position[1]=state.hmd.position[2]=0;testHead[0]=10.3f;movedRaw[0]=.3f;
 RFGRVR_Temporal_CameraBegin(camera);assert(close(*(float*)(camera+0x2c),10.3f-.032f));restore();
 // Height scale affects eye spacing and head translation in the same game units.
 testWorldScale=1.2f;memset(g.origin,0,12);testHead[0]=10;state.hmd.position[0]=.3f;
 RFGRVR_Temporal_CameraBegin(camera);assert(close(*(float*)(camera+0x2c),10+.36f-.032f*1.2f));restore();testWorldScale=1;
 // Scene sizing changes binocular world depth, not player head translation.
 {sceneScaleOverride=.8f;RFGRVR_Temporal_CameraBegin(camera);float displayed=*(float*)(camera+0x2c);assert(close(displayed,10+.3f-.032f*.8f));assert(close(displayed-vrworldview::prepared.x,10+.3f-.032f));restore();sceneScaleOverride=0;}

 // Both eyes consume one frozen hand packet, and targets are rebuilt after
 // publishing it rather than waiting for the next player simulation update.
 g.nativeActive=true;g.nativeContinuous=true;g.nativeTracking.right.position[0]=.8f;
 for(auto& eye:g.nativeEyes){eye.pose=state.hmd;eye.pose.orientation[0]=eye.pose.orientation[1]=eye.pose.orientation[2]=0;eye.pose.orientation[3]=1;}
 unsigned armsBefore=armRefreshes,headingsBefore=headingUpdates;g.nativeEye=0;
 RFGRVR_Temporal_CameraBegin(camera);assert(armRefreshes==armsBefore+1&&close(publishedRightX,.8f));restore();
 float firstGameEye[3];memcpy(firstGameEye,g.shifted,12);float savedHead[3];memcpy(savedHead,testHead,12);testHead[0]+=1;testHead[2]-=.5f;
 state.right.position[0]=100;g.nativeEye=1;RFGRVR_Temporal_CameraBegin(camera);assert(armRefreshes==armsBefore+1&&close(publishedRightX,.8f));assert(headingUpdates==headingsBefore+1);restore();
 assert(close(g.shifted[0],firstGameEye[0])&&close(g.shifted[2],firstGameEye[2]));memcpy(testHead,savedHead,12);
 // In-game menus preserve the normal view even if the native menu camera
 // changes position, parent or scale. Headset translation remains live.
 float gameplayMatrix[9];memcpy(gameplayMatrix,g.writtenMatrix,36);float savedScale=testWorldScale;
 popupTest=true;testWorldScale=2;testHead[0]+=100;attached=true;g.nativeEye=0;g.nativeGameFrameReady=false;
 unsigned menuArms=armRefreshes,menuHeadings=headingUpdates;RFGRVR_Temporal_CameraBegin(camera);
 for(unsigned j=0;j<3;++j)assert(close(g.shifted[j],firstGameEye[j]));
 assert(!memcmp(gameplayMatrix,g.writtenMatrix,36)&&close(g.nativeGameScale,savedScale));
 assert(armRefreshes==menuArms&&headingUpdates==menuHeadings);restore();
 g.nativeEyes[0].pose.position[0]+=.1f;RFGRVR_Temporal_CameraBegin(camera);float moved=0;
 for(unsigned j=0;j<3;++j){float delta=g.shifted[j]-firstGameEye[j];moved+=delta*delta;}
 assert(close(sqrtf(moved),.1f*savedScale));restore();g.nativeEyes[0].pose.position[0]-=.1f;
 popupTest=false;attached=false;testWorldScale=savedScale;memcpy(testHead,savedHead,12);
 g.nativeActive=false;g.nativeContinuous=true;
 // If a requested pair cannot acquire its output buffers, the fallback render
 // still needs current controller poses rather than a stale previous pair.
 unsigned fallbackRefresh=armRefreshes;state.right.position[0]=.42f;RFGRVR_Temporal_CameraBegin(camera);assert(armRefreshes==fallbackRefresh+1&&close(publishedRightX,.42f));restore();
 g.nativeActive=false;g.nativeContinuous=false;
 // Physical floor remains the game floor after crouching and recentering.
 memcpy(camera+8,identity,36);state.calibrationReady=1;state.calibrationFloorValid=1;state.calibratedHeadHeight=1.5f;testFloorEye=1.8f;testWorldScale=1.2f;
 testHead[1]=101.8f;state.hmd.position[0]=state.hmd.position[2]=0;state.hmd.position[1]=1.5f;state.hmd.orientation[0]=state.hmd.orientation[1]=state.hmd.orientation[2]=0;state.hmd.orientation[3]=1;g.calibrated=false;g.wasParented=false;
 RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[1],101.8f));restore();
 state.hmd.position[1]=.5f;RFGRVR_Temporal_Recenter();RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[1],100.6f));restore();
 g.nativeActive=true;g.nativeEye=0;g.nativeEyes[0].pose=g.nativeEyes[1].pose=state.hmd;g.nativeCenter=state.hmd;
 RFGRVR_Temporal_CameraBegin(camera);float frozenY=g.shifted[1];restore();testFloorEye=2;testWorldScale=.8f;testHead[1]=102;
 g.nativeEye=1;RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[1],frozenY));restore();g.nativeActive=false;testFloorEye=1.8f;testWorldScale=1.2f;testHead[1]=101.8f;
 state.hmd.position[1]=0;RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[1],100.f));restore();
 // Animated head anchors own crouch/jump vertical motion; tracked descent
 // must not be added again. The negative ownership marker freezes per pair.
 testFloorEye=-1;testHead[1]=101.2f;state.hmd.position[1]=.7f;
 RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[1],101.2f));restore();
 g.nativeActive=true;g.nativeEye=0;g.nativeEyes[0].pose=g.nativeEyes[1].pose=state.hmd;g.nativeCenter=state.hmd;
 RFGRVR_Temporal_CameraBegin(camera);float animatedY=g.shifted[1];restore();testFloorEye=1.8f;testHead[1]=101.8f;
 g.nativeEye=1;RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[1],animatedY));restore();g.nativeActive=false;
 // Animated eye ownership must retain vertical binocular separation for
 // a rolled head. The center follows animation, both eyes retain actual IPD.
 testFloorEye=-1;testWorldScale=1.2f;g.nativeActive=true;g.nativeEye=0;
 g.nativeEyes[0].pose=g.nativeEyes[1].pose=state.hmd;g.nativeCenter=state.hmd;
 g.nativeEyes[0].pose.position[1]-=.016f;g.nativeEyes[1].pose.position[1]+=.016f;
 RFGRVR_Temporal_CameraBegin(camera);float leftRolledY=g.shifted[1];restore();g.nativeEye=1;
 RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[1]-leftRolledY,.032f*1.2f));restore();g.nativeActive=false;
 // Jump and fall keep head-relative movement available despite parenting;
 // vehicles and interactions keep their established native input gating.
 float moveYaw=0,movePitch=0;g.parentActive=true;g.parentState=1;g.facingTick=GetTickCount64();g.facingYaw=.75f;g.facingPitch=0;
 assert(RFGRVR_NativeFacing(&moveYaw,&movePitch)&&close(moveYaw,.75f));g.parentState=2;assert(RFGRVR_NativeFacing(&moveYaw,&movePitch));g.parentState=9;assert(!RFGRVR_NativeFacing(&moveYaw,&movePitch));g.parentActive=false;
 // Controller travel carries the eyes with the body; room steps remain
 // independent tracking translation when the stick is released.
 g.calibrated=false;attached=false;state.hmd.position[0]=state.hmd.position[2]=0;controllerMoving=true;testHead[0]=10;
 RFGRVR_Temporal_CameraBegin(camera);float lockedX=g.shifted[0];restore();state.hmd.position[0]=.2f;testHead[0]=11;
 RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[0],lockedX+1));float drivenX=g.shifted[0];restore();controllerMoving=false;state.hmd.position[0]=.4f;
 RFGRVR_Temporal_CameraBegin(camera);assert(close(g.shifted[0],drivenX+.2f*testWorldScale));restore();
 // Jump and fall carry animated eye translation but never feed body rotation
 // into headset heading. The same render state is used for button/gesture jumps.
 attached=true;testParentState=1;g.calibrated=false;g.wasParented=false;controllerMoving=false;testFloorEye=-1;
 memcpy(camera+8,identity,36);memcpy(movingParent,identity,36);state.hmd.position[0]=state.hmd.position[1]=state.hmd.position[2]=0;state.hmd.orientation[0]=state.hmd.orientation[1]=state.hmd.orientation[2]=0;state.hmd.orientation[3]=1;
 RFGRVR_Temporal_CameraBegin(camera);float jumpY=g.shifted[1];restore();
 memcpy(movingParent,vehicleYaw,36);testHead[1]+=.4f;
 for(unsigned i=0;i<10;++i){testParentState=(i&1)?1:2;RFGRVR_Temporal_CameraBegin(camera);assert(close(g.writtenMatrix[6],0)&&close(g.writtenMatrix[8],1)&&close(g.shifted[1],jumpY+.4f)&&!g.parentActive.load());restore();}
 attached=false;testParentState=9;
 // Auxiliary cameras do not publish tracking/arms or change calibrated pose ownership.
 {unsigned char saved[48]{};memcpy(saved,camera+8,48);unsigned published=armPublishes;vrarm::Pose feed{{{1,0,0},{0,1,0},{0,0,1}},{4,5,6}};RFGRVR_APC_AuxSet(&feed);assert(auxiliaryMode);RFGRVR_Temporal_CameraBegin(camera);assert(g.outstanding&&close(g.shifted[0],4)&&close(g.shifted[1],5)&&armPublishes==published);float opticProjection[16]{},opticFov=0;assert(RFGRVR_APC_AuxProjection(camera,opticProjection,&opticFov));unsigned char clonedCamera[0x598];memcpy(clonedCamera,camera,sizeof(clonedCamera));assert(RFGRVR_APC_AuxProjection(clonedCamera,opticProjection,&opticFov));*(float*)(clonedCamera+0x590)+=.1f;assert(!RFGRVR_APC_AuxProjection(clonedCamera,opticProjection,&opticFov));memcpy(clonedCamera,camera,sizeof(clonedCamera));*(float*)(clonedCamera+0x2c)+=.1f;assert(!RFGRVR_APC_AuxProjection(clonedCamera,opticProjection,&opticFov));
 RFGRVR_APC_AuxSet(nullptr);assert(!auxiliaryMode&&!memcmp(saved,camera+8,48));}
 // Missing one on-foot frame retains the established room heading/zero.
 {restore();g.nativeActive=false;attached=false;popupTest=false;menuTest=false;g.calibrated=true;g.lastHeadMode=true;float stableBasis[3][3]={{0,0,-1},{0,1,0},{1,0,0}};memcpy(g.worldBasis,stableBasis,36);frameReady=false;RFGRVR_Temporal_CameraBegin(camera);assert(g.calibrated&&!memcmp(g.worldBasis,stableBasis,36));restore();frameReady=true;}
 // A tumbling head may update between scene passes. Both actual camera
 // mutations must still use ONE ragdoll pose, not different animation times.
 {restore();memcpy(camera+8,identity,36);attached=true;testParentState=0x103;frameReady=true;g.nativeActive=true;g.nativeEye=0;g.nativeGameFrameReady=false;g.nativeRagdollFrameReady=false;g.nativeCenter={};g.nativeCenter.orientation[3]=1;
 for(unsigned e=0;e<2;++e){g.nativeEyes[e].pose={};g.nativeEyes[e].pose.orientation[3]=1;g.nativeEyes[e].pose.position[0]=e?.032f:-.032f;}
 auto savedScale=testWorldScale;testWorldScale=1.2f;sceneScaleOverride=0;testHead[0]=10;testHead[1]=20;testHead[2]=30;vrarm::M rolled=vrarm::turnAround(vrarm::M{{1,0,0},{0,1,0},{0,0,1}},{0,0,1},1.2f);memcpy(movingParent,&rolled,36);g.renderedPoseValid=true;
 RFGRVR_Temporal_CameraBegin(camera);vrarm::V left{};memcpy(&left,g.shifted,12);assert(g.nativeRagdollFrameReady&&!g.renderedPoseValid);restore();
 testHead[0]+=5;testHead[1]+=3;memcpy(movingParent,identity,36);frameReady=false;g.nativeEye=1;RFGRVR_Temporal_CameraBegin(camera);vrarm::V right{};memcpy(&right,g.shifted,12);auto midpoint=vrarm::mul(vrarm::add(left,right),.5f);assert(close(midpoint.x,10)&&close(midpoint.y,20)&&close(midpoint.z,30));assert(close(vrarm::length(vrarm::sub(right,left)),.064f*1.2f));assert(!memcmp(g.writtenMatrix,&rolled,36));restore();
 // Next pair must accept the new head, rather than retaining a stale tumble.
 g.nativeRagdollFrameReady=false;g.nativeEye=0;frameReady=true;RFGRVR_Temporal_CameraBegin(camera);assert(close(g.nativeRagdollHead.p.x,15));restore();g.nativeRagdollFrameReady=false;g.nativeActive=false;attached=false;testParentState=9;testWorldScale=savedScale;}
 // Invalid/nonorthogonal camera inputs must not be written.
 ((float*)(camera+8))[1]=1;
 RFGRVR_Temporal_CameraBegin(camera);assert(!g.outstanding);
 g.tracking=nullptr;
 testActivePairScreensAndResize();
}




extern "C" bool RFGRVR_HeadCam_PopupMenu(){return popupTest;}





