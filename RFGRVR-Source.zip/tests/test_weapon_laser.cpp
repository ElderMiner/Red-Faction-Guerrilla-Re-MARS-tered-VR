#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "../src/weapon_laser_gpu.h"
#include <cassert>
using Microsoft::WRL::ComPtr;
int main(){
 // Shipping input cannot change approved placement or appearance.
 vrlaser::loaded=true;vrlaser::placement={.276f,.06f,4.f,4.1f};
 auto fixed=vrlaser::placement;vrlaser::input(true);vrlaser::input(false);assert(!memcmp(&fixed,&vrlaser::placement,sizeof(fixed)));

 // Emitter is a rigid gun-local child, including yaw, translation and saved adjustments.
 {vrarm::M identity{{1,0,0},{0,1,0},{0,0,1}};vrlaser::Settings setting{};float forward=setting.forward,vertical=setting.vertical;
 assert(vrlaser::adjust(setting,VK_RIGHT)&&vrlaser::adjust(setting,VK_UP));assert(fabsf(setting.forward-forward-.002f)<.00001f&&fabsf(setting.vertical-vertical-.002f)<.00001f);
 vrlaser::adjust(setting,VK_LEFT);vrlaser::adjust(setting,VK_DOWN);assert(fabsf(setting.forward-forward)<.00001f&&fabsf(setting.vertical-vertical)<.00001f);
 vrarm::Pose root{vrarm::turnAround(identity,{0,1,0},1.1f),{4,5,6}};auto child=vrlaser::emitter(root,1,setting);auto local=vrarm::local(root.b,vrarm::sub(child.p,root.p));assert(fabsf(local.y-setting.vertical)<.00001f&&fabsf(local.z-setting.forward)<.00001f);root.p.x+=2;auto moved=vrlaser::emitter(root,1,setting);assert(fabsf(moved.p.x-child.p.x-2)<.00001f);}
 // Dropouts expire from the original hit, not from repeatedly held samples.
 {vrlaser::Stabilizer filter;vrlaser::State hit{};hit.active=hit.hit=true;hit.tick=100;hit.end={0,0,10};hit.normal={0,0,-1};hit.distance=10;filter.apply(hit,7);
 auto missing=hit;missing.hit=false;missing.end={0,0,vrlaser::maxRange};missing.distance=vrlaser::maxRange;missing.tick=120;filter.apply(missing,7);assert(missing.hit);
 missing.hit=false;missing.tick=140;filter.apply(missing,7);assert(!missing.hit);
 missing.tick=125;filter.apply(missing,8);assert(!missing.hit);
 assert(vrlaser::visibility(29,1)==1&&vrlaser::visibility(33.75f,1)>.49f&&vrlaser::visibility(37.5f,1)==0&&vrlaser::visibility(75,2)==0);
 vrarm::M identity{{1,0,0},{0,1,0},{0,0,1}};hit.end={0,0,60};vrlaser::reproject(hit,{identity,{}});assert(!hit.hit&&fabsf(hit.distance-vrlaser::maxRange)<.00001f);}
 {vrlaser::Settings s;assert(vrlaser::adjust(s,VK_MULTIPLY)&&s.size>1);vrlaser::adjust(s,VK_SUBTRACT);assert(fabsf(s.size-1)<.00001f);float initial=s.emission;vrlaser::adjust(s,VK_NUMPAD8);assert(s.emission>initial);vrlaser::adjust(s,VK_NUMPAD9);assert(fabsf(s.emission-initial)<.00001f);for(int i=0;i<200;++i){vrlaser::adjust(s,VK_MULTIPLY);vrlaser::adjust(s,VK_NUMPAD8);}assert(s.size==4&&s.emission==12);for(int i=0;i<200;++i){vrlaser::adjust(s,VK_SUBTRACT);vrlaser::adjust(s,VK_NUMPAD9);}assert(s.size==.25f&&s.emission==.1f);}
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;
 {vrarm::M identity{{1,0,0},{0,1,0},{0,0,1}};vrlaser::State s{};s.hit=true;s.normal={0,0,-1};s.end={0,0,10};vrarm::Pose mounted{identity,{.25f,.1f,1}};vrlaser::reproject(s,mounted);assert(s.hit&&fabsf(s.end.x-.25f)<.00001f&&fabsf(s.end.y-.1f)<.00001f&&fabsf(s.end.z-10)<.00001f);
 mounted.b=vrarm::turnAround(identity,{0,1,0},1.5707963f);vrlaser::reproject(s,mounted);assert(!s.hit&&vrarm::dot(vrarm::unit(vrarm::sub(s.end,s.origin)),mounted.b.f)>.999f);}
 assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,nullptr,&context)));
 D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=128;desc.MipLevels=desc.ArraySize=1;desc.SampleDesc.Count=1;desc.Format=DXGI_FORMAT_R8G8B8A8_TYPELESS;desc.BindFlags=D3D11_BIND_RENDER_TARGET;
 ComPtr<ID3D11Texture2D> color,depth,readback;assert(SUCCEEDED(device->CreateTexture2D(&desc,nullptr,&color)));
 D3D11_RENDER_TARGET_VIEW_DESC rv{};rv.Format=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;rv.ViewDimension=D3D11_RTV_DIMENSION_TEXTURE2D;ComPtr<ID3D11RenderTargetView> target;assert(SUCCEEDED(device->CreateRenderTargetView(color.Get(),&rv,&target)));
 desc.Format=DXGI_FORMAT_D32_FLOAT;desc.BindFlags=D3D11_BIND_DEPTH_STENCIL;assert(SUCCEEDED(device->CreateTexture2D(&desc,nullptr,&depth)));ComPtr<ID3D11DepthStencilView> z;assert(SUCCEEDED(device->CreateDepthStencilView(depth.Get(),nullptr,&z)));
 desc.Format=DXGI_FORMAT_R8G8B8A8_TYPELESS;desc.BindFlags=0;desc.Usage=D3D11_USAGE_STAGING;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;assert(SUCCEEDED(device->CreateTexture2D(&desc,nullptr,&readback)));
 vrarm::M identity{{1,0,0},{0,1,0},{0,0,1}};vrarm::Pose eye{identity,{}};float projection[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};RFGRWeaponLaserGpu gpu;
 vrlaser::State s{};s.active=s.hit=true;s.tick=GetTickCount();s.origin={0,0,.4f};s.end={0,0,.5f};s.normal={0,0,-1};s.distance=20;s.scale=1;vrlaser::publish(s);
 const float black[4]={0,0,0,1};
 unsigned energy=0;auto pixels=[&](){energy=0;context->CopyResource(readback.Get(),color.Get());D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(context->Map(readback.Get(),0,D3D11_MAP_READ,0,&map)));unsigned red=0;for(unsigned y=0;y<128;++y)for(unsigned x=0;x<128;++x){unsigned value=((unsigned char*)map.pData)[y*map.RowPitch+x*4];energy+=value;if(value>20)++red;}context->Unmap(readback.Get(),0);return red;};
 for(bool reverse:{false,true}){
  auto compare=reverse?D3D11_COMPARISON_GREATER_EQUAL:D3D11_COMPARISON_LESS_EQUAL;
  context->ClearRenderTargetView(target.Get(),black);context->ClearDepthStencilView(z.Get(),D3D11_CLEAR_DEPTH,reverse?.25f:.75f,0);
  assert(gpu.draw(device.Get(),context.Get(),color.Get(),z.Get(),eye,projection,compare,0,1));assert(pixels()>0);
  context->ClearRenderTargetView(target.Get(),black);context->ClearDepthStencilView(z.Get(),D3D11_CLEAR_DEPTH,reverse?.8f:.2f,0);
  assert(gpu.draw(device.Get(),context.Get(),color.Get(),z.Get(),eye,projection,compare,0,1));assert(pixels()==0);
 }
 // Emission changes actual GPU output; size changes the projected spot footprint.
 vrlaser::loaded=true;vrlaser::placement.emission=.1f;context->ClearRenderTargetView(target.Get(),black);context->ClearDepthStencilView(z.Get(),D3D11_CLEAR_DEPTH,.75f,0);assert(gpu.draw(device.Get(),context.Get(),color.Get(),z.Get(),eye,projection,D3D11_COMPARISON_LESS_EQUAL,0,1));pixels();unsigned dim=energy;
 vrlaser::placement.emission=4;context->ClearRenderTargetView(target.Get(),black);assert(gpu.draw(device.Get(),context.Get(),color.Get(),z.Get(),eye,projection,D3D11_COMPARISON_LESS_EQUAL,0,1));pixels();assert(energy>dim);
 vrlaser::placement.size=.5f;context->ClearRenderTargetView(target.Get(),black);assert(gpu.draw(device.Get(),context.Get(),color.Get(),z.Get(),eye,projection,D3D11_COMPARISON_LESS_EQUAL,0,1));unsigned smallSpot=pixels();vrlaser::placement.size=2;context->ClearRenderTargetView(target.Get(),black);assert(gpu.draw(device.Get(),context.Get(),color.Get(),z.Get(),eye,projection,D3D11_COMPARISON_LESS_EQUAL,0,1));assert(pixels()>smallSpot);
 s.tick=GetTickCount()-500;vrlaser::publish(s);assert(!gpu.draw(device.Get(),context.Get(),color.Get(),z.Get(),eye,projection,D3D11_COMPARISON_LESS_EQUAL,0,1));gpu.releaseOutput();assert(!gpu.output&&!gpu.target);
}
