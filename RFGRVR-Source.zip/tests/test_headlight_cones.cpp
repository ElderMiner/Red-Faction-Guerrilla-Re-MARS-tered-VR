#include "../src/vr_headlight_cones.h"
#include <cassert>
#include <cstdio>
static void put(void* p,unsigned offset,uintptr_t value){unsigned v=(unsigned)value;memcpy((char*)p+offset,&v,4);}
int main(){
 unsigned char source[32]{},data[160]{},meshes[0xb0*2]{};
 put(source,0x10,(uintptr_t)data);put(data,0x18,(uintptr_t)"veh_headlight_a.effectx");put(data,0x40,2);put(data,0x48,(uintptr_t)meshes);
 put(meshes,0,(uintptr_t)"g_light_cone_01");put(meshes,8,12);
 put(meshes,0xb0,(uintptr_t)"unrelated_mesh");put(meshes,0xb0+8,12);
 unsigned char before[sizeof(meshes)];memcpy(before,meshes,sizeof(meshes));
 assert(!vrheadlightcones::patchTemplate(source,false));assert(!memcmp(before,meshes,sizeof(meshes)));
 assert(vrheadlightcones::patchTemplate(source,true));assert(vrheadlightcones::word(meshes,8)==9);
 put(before,8,9);assert(!memcmp(before,meshes,sizeof(meshes)));assert(!vrheadlightcones::patchTemplate(source,true));
 put(meshes,8,28);assert(vrheadlightcones::patchTemplate(source,true));assert(vrheadlightcones::word(meshes,8)==25);
 put(meshes,8,12);put(data,0x18,(uintptr_t)"env_dust_camera_a.effectx");assert(!vrheadlightcones::patchTemplate(source,true));assert(vrheadlightcones::word(meshes,8)==12);
 put(data,0x18,(uintptr_t)"veh_headlight_b.effectx");put(data,0x40,0);assert(!vrheadlightcones::patchTemplate(source,true));
 put(data,0x40,65);assert(!vrheadlightcones::patchTemplate(source,true));put(data,0x40,1);put(data,0x48,1);assert(!vrheadlightcones::patchTemplate(source,true));assert(!vrheadlightcones::patchTemplate(nullptr,true));
 puts("PASS: verified headlight cone ROD to NORMAL, exact unrelated-byte preservation, flags, idempotence, VR isolation and malformed layouts");
}
