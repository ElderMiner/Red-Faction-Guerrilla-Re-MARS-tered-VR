#define NOMINMAX
#include "../src/modern_scene_lights.h"
#include "../src/modern_volumetrics.h"
#include "../src/modern_volume_renderer.h"
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <cassert>
#include <cstdio>
#include <thread>
using Microsoft::WRL::ComPtr;
int main(){
 using namespace modernscene;
 assert(environment(12).main==1&&environment(12).ambient==1&&environment(12).minimumLuminance==0);
 assert(environment(0).main<.11f&&environment(0).ambient<.19f&&environment(0).minimumLuminance>.3f);
 assert(environment(NAN).night==0);assert(std::abs(environment(5.5f).night-.5f)<1e-6f);assert(std::abs(environment(18.5f).night-.5f)<1e-6f);
 float native[26]{},out[26];for(unsigned i=0;i<26;++i)native[i]=float(i)+.01f;native[8]=10;native[9]=.01f;memset(out,0xcd,sizeof(out));float sentinel[26];memcpy(sentinel,out,sizeof(out));
 assert(!patchHDR(native,out,environment(12))&&!memcmp(out,sentinel,sizeof(out)));assert(patchHDR(native,out,environment(0)));assert(out[9]==.35f&&out[8]==10);for(unsigned i=0;i<26;++i)if(i!=9)assert(native[i]==out[i]);
 {Frame parent(true,0);auto* state=current;{Frame nested(true,12);assert(current==state&&current->night==1);}assert(current==state);}assert(!current);
 Collector collector;collector.begin(1);Light light;light.kind=1;light.range=20;light.colour[0]=1;assert(collector.submit(1,light));light.position[0]=5;assert(collector.submit(1,light)&&collector.snapshot().count==1&&collector.snapshot().lights[0].position[0]==5);
 std::thread a([&](){for(unsigned i=2;i<=32;++i)collector.submit(i,light);}),b([&](){for(unsigned i=33;i<=64;++i)collector.submit(i,light);});a.join();b.join();assert(collector.snapshot().count==64&&!collector.submit(65,light)&&collector.snapshot().dropped==1);collector.begin(2);assert(collector.snapshot().count==0);
 Light invalid=light;invalid.range=NAN;assert(!collector.submit(1,invalid));assert(std::abs(transmittance(2,.5f)-std::exp(-1.f))<1e-6f);assert(phase(1,.7f)>phase(-1,.7f));
 {Snapshot many;many.count=6;for(unsigned i=0;i<6;++i){auto& l=many.lights[i];l.kind=1;l.range=50;l.position[2]=float(i+1);l.colour[0]=l.colour[1]=l.colour[2]=1;}many.lights[5].kind=0;float eye[3]{};auto selected=select(many,eye);assert(selected.count==4&&selected.lights[0].kind==0&&selected.lights[1].position[2]==1&&selected.lights[3].position[2]==3);}
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));
 const char* vs="struct O{float4 p:SV_Position;float2 uv:TEXCOORD0;}; O main(uint id:SV_VertexID){O o;float2 p=float2((id<<1)&2,id&2);o.p=float4(p*float2(2,-2)+float2(-1,1),0,1);o.uv=p;return o;}";
 ComPtr<ID3DBlob> code,error;assert(SUCCEEDED(D3DCompile(vs,strlen(vs),nullptr,nullptr,nullptr,"main","vs_4_0",0,0,&code,&error)));ComPtr<ID3D11VertexShader> vertex;assert(SUCCEEDED(d->CreateVertexShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&vertex)));auto compileResult=D3DCompile(modernvolume::source,sizeof(modernvolume::source)-1,nullptr,nullptr,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error);if(FAILED(compileResult)&&error)fprintf(stderr,"%s",(const char*)error->GetBufferPointer());assert(SUCCEEDED(compileResult));ComPtr<ID3D11PixelShader> pixel;assert(SUCCEEDED(d->CreatePixelShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&pixel)));
 D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=desc.MipLevels=desc.ArraySize=desc.SampleDesc.Count=1;desc.Format=DXGI_FORMAT_R32_FLOAT;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;float depth=.5f,shadow=1;D3D11_SUBRESOURCE_DATA init{&depth,4,4};ComPtr<ID3D11Texture2D> depthTexture,shadowTexture;ComPtr<ID3D11ShaderResourceView> depthView,shadowView;assert(SUCCEEDED(d->CreateTexture2D(&desc,&init,&depthTexture)));assert(SUCCEEDED(d->CreateShaderResourceView(depthTexture.Get(),nullptr,&depthView)));init.pSysMem=&shadow;assert(SUCCEEDED(d->CreateTexture2D(&desc,&init,&shadowTexture)));D3D11_SHADER_RESOURCE_VIEW_DESC viewDesc{};viewDesc.Format=DXGI_FORMAT_R32_FLOAT;viewDesc.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2DARRAY;viewDesc.Texture2DArray.ArraySize=viewDesc.Texture2DArray.MipLevels=1;assert(SUCCEEDED(d->CreateShaderResourceView(shadowTexture.Get(),&viewDesc,&shadowView)));
 desc.Width=desc.Height=32;desc.Format=DXGI_FORMAT_R32G32B32A32_FLOAT;desc.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> target,staging;ComPtr<ID3D11RenderTargetView> rt;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&target)));assert(SUCCEEDED(d->CreateRenderTargetView(target.Get(),nullptr,&rt)));desc.BindFlags=0;desc.Usage=D3D11_USAGE_STAGING;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&staging)));
 modernvolume::Frame frame;for(unsigned i=0;i<4;++i)frame.inverseViewProjection[i*5]=1;frame.eyeMaxDistance[3]=10;frame.medium[0]=2;frame.medium[3]=.85f;frame.options[0]=1;frame.options[1]=32;frame.options[2]=0;auto& l=frame.lights[0];l.directionRange[2]=1;l.colourInner[0]=l.colourInner[1]=l.colourInner[2]=1;l.coneShadow[2]=-1;
 D3D11_BUFFER_DESC bd{};bd.ByteWidth=sizeof(frame);bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;ComPtr<ID3D11Buffer> constants;assert(SUCCEEDED(d->CreateBuffer(&bd,nullptr,&constants)));auto* buffer=constants.Get();c->PSSetConstantBuffers(0,1,&buffer);c->VSSetShader(vertex.Get(),nullptr,0);c->PSSetShader(pixel.Get(),nullptr,0);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);ID3D11ShaderResourceView* views[]={depthView.Get(),shadowView.Get()};c->PSSetShaderResources(0,2,views);auto* renderTarget=rt.Get();c->OMSetRenderTargets(1,&renderTarget,nullptr);D3D11_VIEWPORT viewport{0,0,32,32,0,1};c->RSSetViewports(1,&viewport);D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_POINT;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.MaxLOD=D3D11_FLOAT32_MAX;ComPtr<ID3D11SamplerState> sampler;assert(SUCCEEDED(d->CreateSamplerState(&sd,&sampler)));auto* sam=sampler.Get();c->PSSetSamplers(0,1,&sam);
 auto render=[&](){c->UpdateSubresource(buffer,0,nullptr,&frame,0,0);c->Draw(3,0);c->CopyResource(staging.Get(),target.Get());D3D11_MAPPED_SUBRESOURCE mapped{};assert(SUCCEEDED(c->Map(staging.Get(),0,D3D11_MAP_READ,0,&mapped)));std::array<float,4> result;memcpy(result.data(),(char*)mapped.pData+16*mapped.RowPitch+16*16,16);c->Unmap(staging.Get(),0);for(float x:result)assert(std::isfinite(x)&&x>=0);assert(result[3]<=1);return result;};
 // Analytic night haze: nearby geometry stays exact, distant geometry gains
 // bounded blue haze, twilight fades smoothly, and repeated eyes are identical.
 {auto saved=frame;frame.options[0]=0;frame.options[3]=2;frame.medium[0]=.0015f;frame.eyeMaxDistance[3]=150;frame.lights[0].colourInner[0]=.00125f;frame.lights[0].colourInner[1]=.00225f;frame.lights[0].colourInner[2]=.004375f;
  auto nearSample=render();assert(nearSample[0]==0&&nearSample[3]==1);frame.inverseViewProjection[11]=100;auto farSample=render();assert(farSample[2]>farSample[0]&&farSample[0]>0&&farSample[3]>.78f&&farSample[3]<1&&farSample==render());frame.medium[0]*=.5f;assert(render()[3]>farSample[3]);frame.medium[0]=0;auto day=render();assert(day[0]==0&&day[3]==1);frame=saved;}
 auto sun=render();assert(sun[0]>.04f&&sun[0]<.05f&&sun[3]>.35f&&sun[3]<.38f);assert(sun==render());
 frame.options[1]=8;auto low=render();assert(std::abs(low[0]-sun[0])<1e-5f);frame.options[1]=32;
 frame.medium[0]=0;auto clear=render();assert(clear[0]==0&&clear[3]==1);frame.medium[0]=2;
 // World shadow projection blocks scattering but retains medium extinction.
 l.coneShadow[2]=0;l.coneShadow[1]=.001f;l.worldToShadow[3]=l.worldToShadow[7]=l.worldToShadow[11]=.5f;l.worldToShadow[15]=1;shadow=0;c->UpdateSubresource(shadowTexture.Get(),0,nullptr,&shadow,4,4);auto blocked=render();assert(blocked[0]==0&&std::abs(blocked[3]-sun[3])<1e-6f);frame.options[0]=0;assert(modernvolume::valid(frame));auto unlitMedium=render();assert(unlitMedium[0]==0&&fabs(unlitMedium[3]-sun[3])<1e-6f);frame.options[0]=1;shadow=1;c->UpdateSubresource(shadowTexture.Get(),0,nullptr,&shadow,4,4);assert(render()[0]>.04f);l.coneShadow[2]=-1;
 // Reused native cascades are alternative projections of ONE sun.
 {auto saved=l;D3D11_TEXTURE2D_DESC cd{};cd.Width=cd.Height=cd.MipLevels=cd.SampleDesc.Count=1;cd.ArraySize=3;cd.Format=DXGI_FORMAT_R32_FLOAT;cd.BindFlags=D3D11_BIND_SHADER_RESOURCE;
  float values[3]={0,1,0};D3D11_SUBRESOURCE_DATA data[3]={{values,4,4},{values+1,4,4},{values+2,4,4}};ComPtr<ID3D11Texture2D> cascades;ComPtr<ID3D11ShaderResourceView> cascadeView;assert(SUCCEEDED(d->CreateTexture2D(&cd,data,&cascades)));auto vd=viewDesc;vd.Texture2DArray.ArraySize=3;assert(SUCCEEDED(d->CreateShaderResourceView(cascades.Get(),&vd,&cascadeView)));auto* input=cascadeView.Get();c->PSSetShaderResources(1,1,&input);
  l.directionRange[3]=3;l.coneShadow[2]=0;
  float* matrices[]={l.worldToShadow,l.worldToShadow1,l.worldToShadow2};
  for(unsigned chosen=0;chosen<3;++chosen){for(unsigned j=0;j<3;++j){memset(matrices[j],0,64);matrices[j][3]=j==chosen?.5f:2.f;matrices[j][7]=matrices[j][11]=.5f;matrices[j][15]=1;}
   assert(modernvolume::valid(frame));auto out=render();if(chosen==1)assert(std::abs(out[0]-sun[0])<1e-6f);else assert(out[0]==0);
  }
  l.coneShadow[2]=62;assert(!modernvolume::valid(frame));l=saved;input=shadowView.Get();c->PSSetShaderResources(1,1,&input);
 }
 depth=.02f;c->UpdateSubresource(depthTexture.Get(),0,nullptr,&depth,4,4);assert(render()[0]<sun[0]*.2f);depth=.5f;c->UpdateSubresource(depthTexture.Get(),0,nullptr,&depth,4,4);
 l.positionKind[3]=2;l.positionKind[2]=2;l.directionRange[2]=-1;l.directionRange[3]=5;l.colourInner[3]=.95f;l.coneShadow[0]=.8f;assert(render()[0]>.001f);l.directionRange[2]=1;assert(render()[0]==0);

 // A visible depth wall between the sample and a local source blocks transport.
 l.positionKind[3]=1;l.positionKind[2]=.8f;l.directionRange[3]=5;
 for(unsigned i=0;i<4;++i)frame.worldViewProjection[i*5]=1;
 frame.options[3]=0;auto openLocal=render();frame.options[3]=1;auto contactLocal=render();assert(contactLocal[0]<openLocal[0]*.9f);frame.options[3]=0;
 l.positionKind[3]=0;l.directionRange[3]=0;l.directionRange[2]=1;l.coneShadow[2]=-1;frame.medium[0]=2;
 const float background[4]={.2f,.2f,.2f,.7f};c->ClearRenderTargetView(rt.Get(),background);
 ComPtr<ID3D11PixelShader> oldShader;c->PSGetShader(&oldShader,nullptr,nullptr);ComPtr<ID3D11RenderTargetView> oldTarget;c->OMGetRenderTargets(1,&oldTarget,nullptr);
 assert(modernvolume::valid(frame));auto broken=frame;broken.options[0]=NAN;assert(!modernvolume::valid(broken));broken=frame;broken.options[0]=9;assert(!modernvolume::valid(broken));
 modernvolume::Renderer renderer;assert(renderer.draw(d.Get(),c.Get(),rt.Get(),depthView.Get(),shadowView.Get(),32,32,frame));assert(renderer.quarterWidth()==8&&renderer.quarterHeight()==8);
 ComPtr<ID3D11PixelShader> afterShader;c->PSGetShader(&afterShader,nullptr,nullptr);ComPtr<ID3D11RenderTargetView> afterTarget;c->OMGetRenderTargets(1,&afterTarget,nullptr);assert(oldShader.Get()==afterShader.Get()&&oldTarget.Get()==afterTarget.Get());
 c->CopyResource(staging.Get(),target.Get());D3D11_MAPPED_SUBRESOURCE checked{};assert(SUCCEEDED(c->Map(staging.Get(),0,D3D11_MAP_READ,0,&checked)));float composited[4];memcpy(composited,(char*)checked.pData+16*checked.RowPitch+16*16,16);c->Unmap(staging.Get(),0);assert(composited[0]>.10f&&composited[0]<.14f&&fabsf(composited[3]-.7f)<1e-6f);
 // Bright sources retain proportionally more HDR radiance through the same
 // medium. Brightness never changes its opacity or punches through geometry.
 frame.options[0]=0;const float brightBackground[4]={20,20,20,.7f};c->ClearRenderTargetView(rt.Get(),brightBackground);assert(renderer.draw(d.Get(),c.Get(),rt.Get(),depthView.Get(),nullptr,32,32,frame));c->CopyResource(staging.Get(),target.Get());assert(SUCCEEDED(c->Map(staging.Get(),0,D3D11_MAP_READ,0,&checked)));float bright[4];memcpy(bright,(char*)checked.pData+16*checked.RowPitch+16*16,16);c->Unmap(staging.Get(),0);
 c->ClearRenderTargetView(rt.Get(),background);assert(renderer.draw(d.Get(),c.Get(),rt.Get(),depthView.Get(),nullptr,32,32,frame));c->CopyResource(staging.Get(),target.Get());assert(SUCCEEDED(c->Map(staging.Get(),0,D3D11_MAP_READ,0,&checked)));float dim[4];memcpy(dim,(char*)checked.pData+16*checked.RowPitch+16*16,16);c->Unmap(staging.Get(),0);assert(bright[0]>1&&fabs(bright[0]/dim[0]-100)<.001f&&fabs(bright[3]-dim[3])<1e-6f);frame.options[0]=1;
 assert(!renderer.draw(d.Get(),c.Get(),rt.Get(),depthView.Get(),shadowView.Get(),64,32,frame));frame.medium[0]=0;assert(!renderer.draw(d.Get(),c.Get(),rt.Get(),depthView.Get(),shadowView.Get(),32,32,frame));


 // The actual game HDR buffer is R11G11B10_FLOAT (format 26), not RGBA16.
 desc.Width=desc.Height=32;desc.Format=DXGI_FORMAT_R11G11B10_FLOAT;desc.BindFlags=D3D11_BIND_RENDER_TARGET;desc.Usage=D3D11_USAGE_DEFAULT;desc.CPUAccessFlags=0;ComPtr<ID3D11Texture2D> nativeHDR,nativeRead;ComPtr<ID3D11RenderTargetView> nativeRT;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&nativeHDR)));assert(SUCCEEDED(d->CreateRenderTargetView(nativeHDR.Get(),nullptr,&nativeRT)));desc.BindFlags=0;desc.Usage=D3D11_USAGE_STAGING;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&nativeRead)));frame.medium[0]=2;c->ClearRenderTargetView(nativeRT.Get(),background);assert(renderer.draw(d.Get(),c.Get(),nativeRT.Get(),depthView.Get(),shadowView.Get(),32,32,frame));c->CopyResource(nativeRead.Get(),nativeHDR.Get());assert(SUCCEEDED(c->Map(nativeRead.Get(),0,D3D11_MAP_READ,0,&checked)));unsigned packed=0;memcpy(&packed,(char*)checked.pData+16*checked.RowPitch+16*4,4);c->Unmap(nativeRead.Get(),0);auto decode=[](unsigned v,unsigned bits){unsigned mant=v&((1u<<bits)-1),e=v>>bits;return e?std::ldexp(1.f+float(mant)/float(1u<<bits),int(e)-15):std::ldexp(float(mant),-14-int(bits));};assert(decode(packed&2047,6)>.1f&&decode(packed&2047,6)<.14f);assert(std::abs(decode((packed>>11)&2047,6)-decode(packed&2047,6))<.003f);
 // Measure the real renderer at the recorded headset dimensions, not a 32px
 // toy target. This is a standalone backend cost, not an in-game FPS claim.
 desc.Width=3328;desc.Height=3472;desc.Format=DXGI_FORMAT_R11G11B10_FLOAT;desc.BindFlags=D3D11_BIND_RENDER_TARGET;desc.Usage=D3D11_USAGE_DEFAULT;desc.CPUAccessFlags=0;ComPtr<ID3D11Texture2D> large;ComPtr<ID3D11RenderTargetView> largeRT;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&large)));assert(SUCCEEDED(d->CreateRenderTargetView(large.Get(),nullptr,&largeRT)));
 frame.medium[0]=.3f;frame.options[0]=8;frame.options[1]=24;for(unsigned i=1;i<8;++i){frame.lights[i]=frame.lights[0];frame.lights[i].positionKind[3]=1;frame.lights[i].positionKind[2]=2;frame.lights[i].directionRange[3]=5;}
 assert(renderer.draw(d.Get(),c.Get(),largeRT.Get(),depthView.Get(),shadowView.Get(),3328,3472,frame));
 D3D11_QUERY_DESC qd{};qd.Query=D3D11_QUERY_TIMESTAMP_DISJOINT;ComPtr<ID3D11Query> disjoint,start,finish;assert(SUCCEEDED(d->CreateQuery(&qd,&disjoint)));qd.Query=D3D11_QUERY_TIMESTAMP;assert(SUCCEEDED(d->CreateQuery(&qd,&start)));assert(SUCCEEDED(d->CreateQuery(&qd,&finish)));c->Begin(disjoint.Get());c->End(start.Get());for(unsigned i=0;i<4;++i)assert(renderer.draw(d.Get(),c.Get(),largeRT.Get(),depthView.Get(),shadowView.Get(),3328,3472,frame));c->End(finish.Get());c->End(disjoint.Get());c->Flush();D3D11_QUERY_DATA_TIMESTAMP_DISJOINT timing{};ULONGLONG first=0,last=0;DWORD deadline=GetTickCount()+10000;while(c->GetData(disjoint.Get(),&timing,sizeof(timing),0)==S_FALSE&&int(deadline-GetTickCount())>0)Sleep(1);assert(SUCCEEDED(c->GetData(start.Get(),&first,sizeof(first),0))&&SUCCEEDED(c->GetData(finish.Get(),&last,sizeof(last),0)));if(!timing.Disjoint&&timing.Frequency)printf("Standalone GPU transport cost: %.3f ms/eye at 3328x3472, quarter-size volume, 8 lights x 24 steps (not game timing)\n",1000.*double(last-first)/double(timing.Frequency)/4);
 puts("PASS: native light collector bounds/identity, day/night isolation, HDR metering floor; GPU volumetric Beer-Lambert integration, phase, geometry clipping, shadow occlusion, spot cone, deterministic eyes, quarter-resolution native R11 HDR composite and caller-state preservation");
}


