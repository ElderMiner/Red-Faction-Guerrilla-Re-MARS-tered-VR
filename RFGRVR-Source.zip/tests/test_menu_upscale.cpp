#define NOMINMAX
#include "../src/vr_menu_upscale.h"
#include "../src/vr_menu_copy_state.h"
#include <d3dcompiler.h>
#include <cassert>
#include <cstdio>
#include <cstring>
using Microsoft::WRL::ComPtr;
int main(){
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;D3D_FEATURE_LEVEL f;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,&f,&c)));
 ComPtr<ID3DBlob> v,p;assert(SUCCEEDED(D3DCompile(RFGRMenuScaleShader,sizeof(RFGRMenuScaleShader)-1,nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&v,nullptr)));assert(SUCCEEDED(D3DCompile(RFGRMenuScaleShader,sizeof(RFGRMenuScaleShader)-1,nullptr,nullptr,nullptr,"UpscalePS","ps_4_0",0,0,&p,nullptr)));
 ComPtr<ID3D11VertexShader> vs;ComPtr<ID3D11PixelShader> ps;d->CreateVertexShader(v->GetBufferPointer(),v->GetBufferSize(),nullptr,&vs);d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,&ps);
 unsigned pixels[64]{};for(unsigned y=0;y<8;++y)for(unsigned x=3;x<8;++x)pixels[y*8+x]=x==3?0x40201008:0xc0804020;
 D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=8;td.ArraySize=td.MipLevels=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R8G8B8A8_UNORM;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;D3D11_SUBRESOURCE_DATA initial{pixels,32,0};ComPtr<ID3D11Texture2D> input;assert(SUCCEEDED(d->CreateTexture2D(&td,&initial,&input)));ComPtr<ID3D11ShaderResourceView> srv;d->CreateShaderResourceView(input.Get(),nullptr,&srv);
 td.Width=5120;td.Height=2880;td.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> output;ComPtr<ID3D11RenderTargetView> rt;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&output)));d->CreateRenderTargetView(output.Get(),nullptr,&rt);
 D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;ComPtr<ID3D11SamplerState> sampler;d->CreateSamplerState(&sd,&sampler);
 D3D11_QUERY_DESC q{};q.Query=D3D11_QUERY_TIMESTAMP_DISJOINT;ComPtr<ID3D11Query> interval;d->CreateQuery(&q,&interval);q.Query=D3D11_QUERY_TIMESTAMP;ComPtr<ID3D11Query> begin,end;d->CreateQuery(&q,&begin);d->CreateQuery(&q,&end);c->Begin(interval.Get());c->End(begin.Get());
 {RFGRFullscreenRaster raster;RFGRMenuCopyState state(c.Get());assert(state.bind(d.Get(),raster));auto* target=rt.Get();c->OMSetRenderTargets(1,&target,nullptr);D3D11_VIEWPORT vp{0,0,5120,2880,0,1};c->RSSetViewports(1,&vp);c->IASetInputLayout(nullptr);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);c->VSSetShader(vs.Get(),nullptr,0);c->PSSetShader(ps.Get(),nullptr,0);auto* image=srv.Get();auto* s=sampler.Get();c->PSSetShaderResources(0,1,&image);c->PSSetSamplers(0,1,&s);c->Draw(3,0);}
 c->End(end.Get());c->End(interval.Get());c->Flush();D3D11_QUERY_DATA_TIMESTAMP_DISJOINT times{};UINT64 t0=0,t1=0;for(unsigned i=0;i<1000&&c->GetData(interval.Get(),&times,sizeof(times),0)==S_FALSE;++i)Sleep(1);assert(SUCCEEDED(c->GetData(begin.Get(),&t0,sizeof(t0),0))&&SUCCEEDED(c->GetData(end.Get(),&t1,sizeof(t1),0))&&!times.Disjoint);
 td.BindFlags=0;td.Usage=D3D11_USAGE_STAGING;td.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> staging;d->CreateTexture2D(&td,nullptr,&staging);c->CopyResource(staging.Get(),output.Get());D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(c->Map(staging.Get(),0,D3D11_MAP_READ,0,&map)));
 for(unsigned y=0;y<2880;++y)for(unsigned x=0;x<5120;++x){auto* a=(unsigned char*)map.pData+y*map.RowPitch+x*4;assert(a[0]<=a[3]&&a[1]<=a[3]&&a[2]<=a[3]);if(x<100)assert(a[0]==0&&a[1]==0&&a[2]==0&&a[3]==0);if(x>5000)assert(a[0]>=31&&a[0]<=32&&a[1]>=63&&a[1]<=64&&a[2]>=127&&a[2]<=128&&a[3]>=191&&a[3]<=192);}
 c->Unmap(staging.Get(),0);printf("PASS menu-only 5120x2880 cubic reconstruction: transparent borders, bounded premultiplied edges and unchanged solid artwork; GPU %.3f ms\n",1000.*double(t1-t0)/double(times.Frequency));
}
