#include "../src/vr_index_layout.h"
#include "../src/vr_quest_layout.h"
#include "../src/vr_interaction_context.h"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <cassert>
#include <cstdio>
#include <array>
#include <algorithm>
#include "../src/vr_controller_profiles.h"
#include "../src/vr_body_visibility.h"
#include "../src/vr_ribbon_cloth.h"
#include "../src/vr_two_hand.h"
#include "../src/vr_sun_glare.h"
int main(){
 {vrindex::Layout index;RFGRGamepad p{};vrindex::Pad none{},upper{.8f,.7f,true},lower{-.8f,.7f,true};
 auto out=index.update(p,{.8f,.05f,true},none,true,false,0,100);assert(!out.buttons);out=index.update(p,upper,none,true,false,0,110);assert(out.buttons==0x10);out=index.update(p,lower,none,true,false,0,120);assert(out.buttons==0x10); // Firm contact cannot drift into Map.
 index.update(p,none,none,true,false,0,230);out=index.update(p,lower,none,true,false,0,240);assert(out.buttons==0x20);index.update(p,none,none,true,false,0,350);
 out=index.update(p,none,{0,0,true},true,false,0,360);assert(index.selectionHeld&&!out.buttons);out=index.update(p,none,none,true,false,0,370);assert(!index.selectionHeld&&out.buttons==0x200);
 index.update(p,none,none,true,false,0,480);index.update(p,none,{0,0,true},true,false,0,500);out=index.update(p,none,{0,0,true},true,false,0,999);assert(index.selectionHeld&&!out.buttons&&!index.rightHoldUsed);out=index.update(p,none,{0,0,true},true,false,0,1000);assert(index.rightHoldUsed&&index.selectionHeld);out=index.update(p,none,none,true,false,0,1001);assert(!out.buttons&&!index.selectionHeld);index={};
 p.buttons=0x4000;assert(index.update(p,none,none,true,false,0,400).buttons==0x2000);p.buttons=0x2000;assert(index.update(p,none,none,true,false,0,401).buttons==0x4000);p.buttons=0x200;assert(index.update(p,none,none,true,false,0,402).buttons==0x400);
 p.buttons=0x40;assert(index.update(p,none,none,true,false,0,403).buttons==0x100);assert(index.update(p,none,none,true,false,9,404).buttons==0x40);p.buttons=0x80;assert(index.update(p,none,none,true,false,0,405).buttons==0x40);assert(index.update(p,none,none,true,false,9,406).buttons==0x80);
 p={};p.rightY=-28000;out=index.update(p,none,none,true,false,9,410);assert(out.buttons==8&&!out.rightY);index.rightHeightGrip=true;out=index.update(p,none,none,true,false,9,411);assert(!out.buttons&&out.rightY==-28000);
 p={};index.update(p,upper,{0,0,true},false,true,0,500);out=index.update(p,upper,{0,0,true},true,false,0,501);assert(!out.buttons&&!index.selectionHeld);index.update(p,none,none,true,false,0,502);assert(index.update(p,upper,none,true,false,0,503).buttons==0x10);
 }

 {using namespace vrquest;Layout q;RFGRGamepad p{};p.buttons=0x2000;auto out=q.update(p,0,0,true,0,100);assert(out.buttons==0x4000); // B reload.
 p.buttons=0x4000;out=q.update(p,0,0,true,0,110);assert(out.buttons==Detonate);commands(out,true,false,false);assert(out.buttons==0);out.buttons=Detonate;commands(out,true,false,true);assert(out.buttons==0x2000);
 p.buttons=0x8000;out=q.update(p,0,0,true,0,200);assert(!out.buttons&&q.selectionHeld);out=q.update(p,0,0,true,0,699);assert(!out.buttons&&!q.usedHold);p.buttons=0;out=q.update(p,0,0,true,0,699);assert(out.buttons&ContextTap);auto context=out;commands(context,true,true,false);assert(context.buttons==0x2000);commands(out,true,false,false);assert(out.buttons==0x200);
 q={};p.buttons=0x8000;q.update(p,0,0,true,0,1000);q.update(p,0,0,true,0,1500);assert(q.usedHold);p.buttons=0;out=q.update(p,0,0,true,0,1501);assert(!(out.buttons&ContextTap));
 p.buttons=0x10;assert(q.update(p,.8f,0,true,0,1600).buttons==0x20);assert(q.update(p,0,0,true,0,1601).buttons==0x10);
 p.buttons=0x40;assert(q.update(p,0,0,true,0,1700).buttons==0x100);assert(q.update(p,0,0,true,9,1701).buttons==0x40);
 p.buttons=0x80;assert(q.update(p,0,0,true,0,1702).buttons==0x40);assert(q.update(p,0,0,true,9,1703).buttons==0x80);
 p={};p.rightY=-28000;out=q.update(p,0,0,true,0,1800);assert(out.buttons==8&&!out.rightY);out=q.update(p,0,.8f,true,9,1801);assert(!out.buttons&&out.rightY==-28000);
 p.buttons=0x2000;out=q.update(p,0,0,false,0,1900);assert(out.buttons==p.buttons&&out.rightY==p.rightY);out.buttons=Commands;commands(out,false,true,true);assert(!out.buttons);
 q={};p.buttons=0x8000;q.update(p,0,0,false,0,2000);q.update(p,0,0,true,0,2100);p.buttons=0;assert(!(q.update(p,0,0,true,0,2200).buttons&ContextTap));
 CommandState resolve;out={};out.buttons=ContextTap;resolve.apply(out,true,true,false);assert(out.buttons==0x2000);out.buttons=ContextTap;resolve.apply(out,true,false,false);assert(out.buttons==0x2000);out.buttons=0;resolve.apply(out,true,false,false);out.buttons=ContextTap;resolve.apply(out,true,false,false);assert(out.buttons==0x200); // A fading prompt cannot turn one tap into two actions.
 assert(vrinteraction::group(0xd603f74bu)&&vrinteraction::group(0x2828844eu)&&!vrinteraction::group(0x3dcf239cu));
 assert(vrinteraction::visible(true,1,1)&&!vrinteraction::visible(false,1,1)&&!vrinteraction::visible(true,0,1));
 vrinteraction::sample(true,100);assert(vrinteraction::available(200)&&!vrinteraction::available(350));vrinteraction::sample(false,201);assert(!vrinteraction::available(202));
 }
using namespace vrcontrollers;using namespace vrarm;
 assert(detect("/interaction_profiles/meta/touch_controller_plus")==QuestTouch);
 assert(detect("/interaction_profiles/oculus/touch_controller")==QuestTouch);
 assert(detect("/interaction_profiles/valve/index_controller")==Index);
 assert(detect("/interaction_profiles/valve/frame_controller_valve")==Frame);
 assert(!strcmp(gripComponent(Index),"force")&&!strcmp(gripComponent(QuestTouch),"value"));assert(grip(Index,0)==0&&grip(Index,.5f)==1&&grip(QuestTouch,.5f)==.5f);
 RFGRGamepad p{};p.buttons=0x8000;p.leftX=12345;p.rightTrigger=240;fallback(QuestTouch,QuestTouch,p);assert(p.buttons==0x200&&p.leftX==12345&&p.rightTrigger==240);
 p={};p.buttons=0xc000;fallback(Index,Index,p);assert(p.buttons==0x4200);
 p={};p.buttons=0xc0;fallback(Index,Index,p);assert(p.buttons==0xc0);
 p={};p.buttons=0xc0;p.leftY=24000;fallback(Index,Index,p);assert(p.buttons==0xc0); // Driving never becomes pause.
 p={};p.buttons=0x8000;fallback(Frame,Frame,p);assert(p.buttons==0x8000);
 assert(vrbody::handBone("l-hand")&&vrbody::handBone("r-finger11")&&vrbody::handBone("l-thumb1"));assert(!vrbody::handBone("r-foretwist")&&!vrbody::handBone("head"));
 M identity{{1,0,0},{0,1,0},{0,0,1}};
 unsigned char sun[0x5c]{},lamp[0x5c]{};memcpy(sun,"SunGlare01",11);memcpy(lamp,"WhiteGlare01",13);float radius=40,intensity=9999;memcpy(sun+0x28,&radius,4);memcpy(sun+0x2c,&radius,4);memcpy(sun+0x50,&intensity,4);vrglare::Owned glare;assert(!glare.apply(lamp,true));assert(glare.apply(sun,true));float value;memcpy(&value,sun+0x50,4);assert(value==0);glare.apply(nullptr,false);memcpy(&value,sun+0x50,4);assert(value==9999);
 RFGRVRTwoHand grip;Pose single{identity,{}},anchor{identity,{0,.3f,0}},other{identity,{0,.3f,0}},gun{},hand{};
 assert(grip.update(1,1,true,1,.14f,single,{},anchor,{},other,gun,hand,true));other.p={0,.55f,0};other.b=turnAround(identity,{0,1,0},.8f);
 assert(grip.update(1,1,true,1,.14f,single,{},anchor,{},other,gun,hand,true));assert(length(sub(hand.p,other.p))<.001f);assert(length(sub(gun.p,V{}))<.001f);assert(fabsf(axialRoll(identity,hand.b,{0,1,0})-.8f)<.001f);assert(fabsf(axialRoll(identity,gun.b,{0,1,0}))<.001f);

 struct Vertex{V p;unsigned char rest[20];};Vertex vertices[6]{};vertices[0].p={0,1,0};vertices[1].p={.02f,1,0};vertices[2].p={0,1.02f,0};vertices[3].p={0,0,0};vertices[4].p={.1f,0,0};vertices[5].p={0,.1f,0};unsigned short indices[9]={0,1,2,3,4,5,0,1,5};vrbody::HandRegion region;region.count=1;region.joint[0]={0,1,0};std::vector<unsigned char> filtered;assert(vrbody::filter((unsigned char*)vertices,sizeof(vertices),sizeof(Vertex),(unsigned char*)indices,sizeof(indices),9,2,region,filtered)==1);auto* kept=(unsigned short*)filtered.data();assert(kept[0]==0&&kept[1]==1&&kept[2]==2&&kept[3]==kept[4]&&kept[4]==kept[5]&&kept[6]==kept[7]&&kept[7]==kept[8]);assert(indices[4]==4&&vertices[3].p.y==0);

 // Preserve the whole connected glove/cuff and separate decoration inside
 // its authored bounds; never promote a component that reaches the torso.
 {Vertex v[10]{};v[0].p={0,1,0};v[1].p={.02f,1,0};v[2].p={0,1.04f,.03f};v[3].p={-.16f,1.02f,.01f};v[4].p={0,0,0};v[5].p={.1f,0,0};v[6].p={0,.1f,0};v[7].p={-.12f,1.02f,.01f};v[8].p={-.11f,1.025f,.015f};v[9].p={-.115f,1.03f,.02f};unsigned short idx[]={0,1,2,0,2,3,4,5,6,7,8,9};vrbody::HandRegion gloves;gloves.joint[0]={0,1,0};gloves.count=1;assert(!gloves.contains(v[3].p));vrbody::completeGloves((unsigned char*)v,sizeof(v),sizeof(Vertex),(unsigned char*)idx,sizeof(idx),12,2,false,gloves);assert(gloves.contains(v[3].p)&&gloves.contains(v[7].p)&&!gloves.contains(v[4].p));std::vector<unsigned char> out;assert(vrbody::filter((unsigned char*)v,sizeof(v),sizeof(Vertex),(unsigned char*)idx,sizeof(idx),12,2,gloves,out)==3);unsigned short connected[]={0,1,2,0,2,3,3,4,5};vrbody::HandRegion bounded;bounded.joint[0]={0,1,0};bounded.count=1;vrbody::completeGloves((unsigned char*)v,sizeof(v),sizeof(Vertex),(unsigned char*)connected,sizeof(connected),9,2,false,bounded);assert(bounded.components.empty()&&!bounded.contains(v[3].p)&&!bounded.contains(v[4].p));}
 // Real player meshes are strips, with odd-offset material-group starts.
 // Filtering must preserve winding and must never introduce a body triangle.
 {Vertex v[8]{};for(unsigned i=0;i<8;++i)v[i].p={float(i)*.2f,1,0};unsigned short src[10]={0,1,2,65535,3,4,5,6,7,65535};unsigned groups[2]={0,5};
 auto triangles=[&](const unsigned short* p){std::vector<std::array<unsigned,3>> result;for(unsigned g=0;g<2;++g){unsigned run=0,a=0,b=0,end=g<1?groups[g+1]:10;for(unsigned i=groups[g];i<end;++i){unsigned n=p[i];if(n==65535){run=0;continue;}if(run>=2&&a!=b&&a!=n&&b!=n)result.push_back((run&1)?std::array<unsigned,3>{b,a,n}:std::array<unsigned,3>{a,b,n});a=b;b=n;++run;}}return result;};auto original=triangles(src);
 for(unsigned mask=0;mask<256;++mask){vrbody::HandRegion hands;for(unsigned i=0;i<8;++i)if(mask&(1u<<i))hands.joint[hands.count++]=v[i].p;std::vector<unsigned char> dst;auto count=vrbody::filterStrip((unsigned char*)v,sizeof(v),sizeof(Vertex),(unsigned char*)src,sizeof(src),10,2,hands,dst,groups,2);auto output=triangles((unsigned short*)dst.data());assert(count==output.size()&&dst.size()==sizeof(src));for(auto triangle:output){for(auto index:triangle)assert(mask&(1u<<index));assert(std::find(original.begin(),original.end(),triangle)!=original.end());}}assert(src[3]==65535&&src[5]==4);}
 vrribbon::Cloth cloth;for(unsigned i=0;i<12;++i)cloth.rest[i]={i%2?.02f:-.02f,-float(i/2)*.12f,0};Pose root{identity,{0,1.5f,0}};cloth.reset(root);
 for(unsigned frame=0;frame<1200;++frame){root.p.x=.25f*sinf(frame*.018f);root.b=turnAround(identity,{0,0,1},.7f*sinf(frame*.01f));cloth.update(root,1.f/120);for(unsigned i=0;i<12;++i)assert(finite(cloth.point[i]));for(unsigned i=0;i<2;++i)assert(length(sub(cloth.point[i],add(root.p,world(root.b,cloth.rest[i]))))<.0001f);}
 for(unsigned i=2;i<12;++i)assert(fabsf(length(sub(cloth.point[i],cloth.point[i-2]))-.12f)<.025f);
 // Cloth has inertia; a fast anchor movement does not rigidly teleport its tail.
 V tail=cloth.point[11];root.p.x+=.2f;cloth.update(root,1.f/120);assert(length(sub(cloth.point[11],tail))<.18f);
 root.p.x+=10;cloth.update(root,.01f);assert(length(sub(cloth.point[11],add(root.p,world(root.b,cloth.rest[11]))))<.0001f);
 LARGE_INTEGER begin,end,freq;QueryPerformanceFrequency(&freq);QueryPerformanceCounter(&begin);for(unsigned i=0;i<10000;++i)cloth.update(root,1.f/120);QueryPerformanceCounter(&end);printf("PASS: controller fallbacks, private glove triangle filter, pinned cloth/inertia/teleport; cloth %.2f us/update\n",1e6*double(end.QuadPart-begin.QuadPart)/freq.QuadPart/10000);
}
