#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <atomic>
#include <cassert>
namespace vrmemory { inline bool check(const void*,size_t){return false;} }
namespace modernlight { inline bool enabled(){return false;} }
namespace moderncatalog { inline bool enabled(){return false;} }
inline bool RFGRVR_HeadCam_FirstPersonVehicle(){return false;}
#include "../src/modern_shadow_capture.h"
static unsigned calls;
static uintptr_t __fastcall target(void* self,void*,uintptr_t a1,uintptr_t a2,uintptr_t a3,uintptr_t a4,uintptr_t a5,uintptr_t a6,uintptr_t a7,uintptr_t a8,uintptr_t a9,uintptr_t a10,uintptr_t a11,uintptr_t a12,uintptr_t a13){
 assert(self==(void*)0x12345678);uintptr_t args[]={a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13};for(unsigned i=0;i<13;++i)assert(args[i]==i+1);++calls;
 __asm {
 xorps xmm6,xmm6
 xorps xmm7,xmm7
 }
 return 0x76543210;
}
int main(){modernshadow::native=reinterpret_cast<modernshadow::Native>(&target);unsigned before,after,result;alignas(16) unsigned input[4]={1,2,3,4},six[4]{},seven[4]{};
 for(unsigned n=0;n<100;++n){
 __asm {
 mov before,esp
 movups xmm6,input
 movups xmm7,input
 push 13
 push 12
 push 11
 push 10
 push 9
 push 8
 push 7
 push 6
 push 5
 push 4
 push 3
 push 2
 push 1
 mov ecx,0x12345678
 call modernshadow::entry
 mov result,eax
 mov after,esp
 movups six,xmm6
 movups seven,xmm7
 }
 assert(before==after&&result==0x76543210);assert(!memcmp(input,six,16)&&!memcmp(input,seven,16));}
 assert(calls==100);puts("PASS: production shadow thunk forwards thirteen arguments, return, stack and XMM6/7");
}
