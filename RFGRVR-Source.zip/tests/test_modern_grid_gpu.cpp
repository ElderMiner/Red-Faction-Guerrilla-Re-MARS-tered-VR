#define NOMINMAX
#include "../src/modern_grid_gpu.h"
#include "../src/modern_material_bindings.h"
#include "../src/modern_world_sampling_source.h"
#include <d3dcompiler.h>
#include <cassert>
#include <cstdio>
#include <string>
using Microsoft::WRL::ComPtr;
int main(){
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));
 modernindirect::Grid grid;assert(grid.configure({-2,-2,-2},4,2));modernindirect::Probe p;for(auto& m:p.distance){m[0]=30;m[1]=900;}for(unsigned z=0;z<2;++z)for(unsigned y=0;y<2;++y)for(unsigned x=0;x<2;++x){p.coefficients[0][0]=(1+x+2*y+3*z)/.2820947918f;p.coefficients[0][1]=2;p.coefficients[0][2]=1;p.coefficients[2][0]=.3f;assert(grid.update(x,y,z,p,1));}
 modernindirect::GPUGrid gpu;assert(gpu.update(c.Get(),grid)&&gpu.current(grid));auto* original=gpu.resource();assert(gpu.update(c.Get(),grid)&&gpu.resource()==original);
 const char* vertex="struct O{float4 p:SV_Position;};O main(uint id:SV_VertexID){O o;float2 p=float2((id<<1)&2,id&2);o.p=float4(p*float2(2,-2)+float2(-1,1),.5,1);return o;}";ComPtr<ID3DBlob> vsCode,psCode,error;assert(SUCCEEDED(D3DCompile(vertex,strlen(vertex),nullptr,nullptr,nullptr,"main","vs_4_0",0,0,&vsCode,&error)));ComPtr<ID3D11VertexShader> vs;assert(SUCCEEDED(d->CreateVertexShader(vsCode->GetBufferPointer(),vsCode->GetBufferSize(),nullptr,&vs)));
 auto shader=[&](const char* body){std::string source=modernmaterial::samplingSource;source+=body;psCode.Reset();error.Reset();auto hr=D3DCompile(source.c_str(),source.size(),"grid material test",nullptr,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS,0,&psCode,&error);if(FAILED(hr)&&error)puts((const char*)error->GetBufferPointer());assert(SUCCEEDED(hr));ComPtr<ID3D11PixelShader> ps;assert(SUCCEEDED(d->CreatePixelShader(psCode->GetBufferPointer(),psCode->GetBufferSize(),nullptr,&ps)));return ps;};
 auto ps=shader("float4 main(float4 pixel:SV_Position):SV_Target{return modernIrradiance(float3(.3,.4,.5),normalize(float3(.3,.8,.2)));}");
 D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=8;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R32G32B32A32_FLOAT;td.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> output,read;ComPtr<ID3D11RenderTargetView> target;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&output)));assert(SUCCEEDED(d->CreateRenderTargetView(output.Get(),nullptr,&target)));td.BindFlags=0;td.Usage=D3D11_USAGE_STAGING;td.CPUAccessFlags=D3D11_CPU_ACCESS_READ;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&read)));
 auto setup=[&](ID3D11DeviceContext* stream){stream->VSSetShader(vs.Get(),nullptr,0);stream->PSSetShader(ps.Get(),nullptr,0);stream->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);auto* rt=target.Get();stream->OMSetRenderTargets(1,&rt,nullptr);D3D11_VIEWPORT vp{0,0,8,8,0,1};stream->RSSetViewports(1,&vp);};
 auto inspect=[&](){c->CopyResource(read.Get(),output.Get());D3D11_MAPPED_SUBRESOURCE mapped{};assert(SUCCEEDED(c->Map(read.Get(),0,D3D11_MAP_READ,0,&mapped)));std::array<float,4> rgba;memcpy(rgba.data(),(char*)mapped.pData+4*mapped.RowPitch+4*16,16);c->Unmap(read.Get(),0);for(float value:rgba)assert(std::isfinite(value));return rgba;};
 modernmaterial::Frame frame;for(unsigned i=0;i<4;++i)frame.inverseClip[i*5]=1;frame.eye[2]=2;frame.eye[3]=1;frame.viewport[0]=frame.viewport[1]=8;frame.grid[0]=frame.grid[1]=frame.grid[2]=-2;frame.grid[3]=4;frame.layout[0]=2;frame.layout[1]=1;
 auto draw=[&](){setup(c.Get());{modernmaterial::Bindings binding;assert(binding.bind(c.Get(),nullptr,nullptr,&frame,gpu.resource()));c->Draw(3,0);}return inspect();};
 auto result=draw();auto cpu=grid.query({.3f,.4f,.5f},{.3f,.8f,.2f});assert(std::abs(result[0]-cpu.irradiance.x)<.0001f&&std::abs(result[1]-cpu.irradiance.y)<.0001f&&std::abs(result[2]-cpu.irradiance.z)<.0001f&&std::abs(result[3]-cpu.confidence)<.0001f);
 // The final node on each axis is part of the grid, not missing coverage.
 ps=shader("float4 main(float4 pixel:SV_Position):SV_Target{return modernIrradiance(float3(2,2,2),float3(.3,.8,.2));}");auto edge=draw();auto cpuEdge=grid.query({2,2,2},{.3f,.8f,.2f});assert(edge[3]>.99f&&cpuEdge.confidence>.99f);assert(fabs(edge[0]-cpuEdge.irradiance.x)<.0001f);
 // The complete material helper reconstructs a relative position, then adds
 // the native floating origin before querying the absolute probe grid.
 ps=shader("float4 main(float4 pixel:SV_Position):SV_Target{return float4(modernAmbient(pixel,float2(0,0),float3(0,0,1),float4(0,1,0,1),float3(0,0,0),float3(1,1,1)),1);}");auto material=draw();auto sample=grid.query({.125f,-.125f,.5f},{0,1,0});assert(std::abs(material[0]-sample.irradiance.x*.125f/3.14159265f)<.0001f);
 // Reuploading a translated grid must preserve the same physical result.
 assert(grid.configure({998,-2,-1002},4,2));for(unsigned z=0;z<2;++z)for(unsigned y=0;y<2;++y)for(unsigned x=0;x<2;++x){p.coefficients[0][0]=(1+x+2*y+3*z)/.2820947918f;assert(grid.update(x,y,z,p,2));}assert(!gpu.current(grid));assert(gpu.update(c.Get(),grid)&&gpu.current(grid));frame.grid[0]=998;frame.grid[2]=-1002;frame.origin[0]=1000;frame.origin[2]=-1000;auto rebased=draw();for(unsigned channel=0;channel<3;++channel)assert(std::abs(rebased[channel]-material[channel])<.0001f);
 // An unexecuted deferred view may use a different grid frame; it restores
 // caller bindings and uses its own context's DISCARD buffer.
 ComPtr<ID3D11DeviceContext> deferred;assert(SUCCEEDED(d->CreateDeferredContext(0,&deferred)));setup(deferred.Get());{modernmaterial::Bindings binding;assert(binding.bind(deferred.Get(),nullptr,nullptr,&frame,gpu.resource()));deferred->Draw(3,0);}ComPtr<ID3D11Buffer> restored;deferred->PSGetConstantBuffers(13,1,&restored);assert(!restored);ComPtr<ID3D11ShaderResourceView> old;deferred->PSGetShaderResources(18,1,&old);assert(!old);ComPtr<ID3D11CommandList> commands;assert(SUCCEEDED(deferred->FinishCommandList(FALSE,&commands)));c->ExecuteCommandList(commands.Get(),TRUE);auto deferredResult=inspect();for(unsigned channel=0;channel<3;++channel)assert(std::abs(deferredResult[channel]-material[channel])<.0001f);
 auto serial=grid.version();assert(grid.invalidate({900,-100,-1100},{1100,100,-900})==8&&grid.version()>serial);assert(!gpu.current(grid));assert(gpu.update(c.Get(),grid)&&!gpu.current(grid));ps=shader("float4 main(float4 pixel:SV_Position):SV_Target{return float4(modernAmbient(pixel,0,float3(0,0,1),float4(0,1,0,1),float3(.7,.3,.2),1),1);}");auto fallback=draw();assert(std::abs(fallback[0]-.7f)<1e-6f&&std::abs(fallback[1]-.3f)<1e-6f);
 puts("PASS: actual GPU probe interpolation versus CPU, material irradiance, floating-origin invariance, cached uploads, destruction invalidation, deferred bindings and native fallback");
}
