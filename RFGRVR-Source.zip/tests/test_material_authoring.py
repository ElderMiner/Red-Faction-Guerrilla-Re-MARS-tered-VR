import importlib.util
from pathlib import Path
import numpy as np
spec=importlib.util.spec_from_file_location('material_authoring',Path(__file__).resolve().parents[1]/'MAKE-MATERIAL-LIGHTMAPS.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
a=module.estimate(np.full((32,32,3),230,dtype=np.uint8));b=module.estimate(np.full((32,32,3),30,dtype=np.uint8));assert a[:,:,0].mean()>b[:,:,0].mean()
noise=np.random.default_rng(8).integers(0,256,(32,32,3),dtype=np.uint8);n=module.estimate(noise);assert n[:,:,0].mean()<a[:,:,0].mean() and n[:,:,1].mean()>a[:,:,1].mean()
assert np.isfinite(n).all() and n.dtype==np.uint8
print('PASS: brightness reflectivity, fixed spatial colour-consistency roughness, bounded output and deterministic authoring')
