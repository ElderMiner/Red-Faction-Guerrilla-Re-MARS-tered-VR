#define NOMINMAX
#include "../src/modern_shadow_maps.h"
#include <cassert>
#include <cstdio>
#include <limits>
using Microsoft::WRL::ComPtr;
int main(){
 float native[16]={2,0,0,0,0,-3,0,0,0,0,.01f,0,4,5,.6f,1},rows[16]{};assert(modernshadowmaps::matrix(native,rows));assert(rows[3]==4&&rows[7]==5&&rows[11]==.6f&&rows[5]==-3);
 float invalid[16]{};assert(!modernshadowmaps::matrix(invalid,rows));native[0]=std::numeric_limits<float>::quiet_NaN();assert(!modernshadowmaps::matrix(native,rows));assert(rows[3]==4);
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> immediate;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,nullptr,&immediate)));
 for(unsigned deferred=0;deferred<2;++deferred){
  ComPtr<ID3D11DeviceContext> worker;if(deferred)assert(SUCCEEDED(device->CreateDeferredContext(0,&worker)));else worker=immediate;
  D3D11_TEXTURE2D_DESC d{};d.Width=d.Height=4;d.MipLevels=d.ArraySize=d.SampleDesc.Count=1;d.Format=DXGI_FORMAT_R16_TYPELESS;d.BindFlags=D3D11_BIND_DEPTH_STENCIL;
  ComPtr<ID3D11Texture2D> source;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&source)));
  D3D11_DEPTH_STENCIL_VIEW_DESC vd{};vd.Format=DXGI_FORMAT_D16_UNORM;vd.ViewDimension=D3D11_DSV_DIMENSION_TEXTURE2D;ComPtr<ID3D11DepthStencilView> depth;assert(SUCCEEDED(device->CreateDepthStencilView(source.Get(),&vd,&depth)));
  modernshadowmaps::Atlas atlas;atlas.begin(17);assert(!atlas.complete(17));assert(!atlas.copy(worker.Get(),source.Get(),0,16));assert(!atlas.copy(worker.Get(),source.Get(),3,17));
  for(unsigned layer=0;layer<3;++layer){worker->OMSetRenderTargets(0,nullptr,depth.Get());worker->ClearDepthStencilView(depth.Get(),D3D11_CLEAR_DEPTH,float(layer+1)/4,0);assert(!atlas.copy(worker.Get(),source.Get(),layer,17));worker->OMSetRenderTargets(0,nullptr,nullptr);assert(atlas.copy(worker.Get(),source.Get(),layer,17));if(layer<2)assert(!atlas.complete(17));}
  // The next native clear must not overwrite the three earlier snapshots.
  worker->ClearDepthStencilView(depth.Get(),D3D11_CLEAR_DEPTH,0,0);
  auto* view=atlas.complete(17);assert(view);assert(!atlas.complete(18));
  if(deferred){ComPtr<ID3D11CommandList> list;assert(SUCCEEDED(worker->FinishCommandList(FALSE,&list)));immediate->ExecuteCommandList(list.Get(),TRUE);}
  ComPtr<ID3D11Resource> resource;view->GetResource(&resource);ComPtr<ID3D11Texture2D> captured;assert(SUCCEEDED(resource.As(&captured)));captured->GetDesc(&d);d.Usage=D3D11_USAGE_STAGING;d.BindFlags=0;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> readback;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&readback)));immediate->CopyResource(readback.Get(),captured.Get());
  for(unsigned layer=0;layer<3;++layer){D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(immediate->Map(readback.Get(),layer,D3D11_MAP_READ,0,&map)));unsigned expected=unsigned(65535.f*(layer+1)/4+.5f);for(unsigned y=0;y<4;++y)for(unsigned x=0;x<4;++x){unsigned actual=((unsigned short*)((char*)map.pData+y*map.RowPitch))[x];assert(actual+1>=expected&&actual<=expected+1);}immediate->Unmap(readback.Get(),layer);}
  assert(!atlas.copy(worker.Get(),source.Get(),2,17));
  assert(atlas.copy(worker.Get(),source.Get(),0,17));assert(!atlas.complete(17));
  assert(!atlas.copy(worker.Get(),source.Get(),2,17));
  atlas.begin(18);assert(!atlas.complete(18));assert(!atlas.complete(17));
 }
 puts("PASS: native shadow matrix layout; three GPU cascades survive shared-target overwrite on immediate/deferred streams; stale, incomplete and bound-source rejection");
}
