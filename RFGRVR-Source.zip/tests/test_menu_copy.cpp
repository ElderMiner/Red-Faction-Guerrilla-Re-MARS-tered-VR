#define NOMINMAX
#include "../src/vr_menu_copy_state.h"
#include "../src/vr_menu_upscale.h"
#include <d3dcompiler.h>
#include <cassert>
#include <cstdio>
#include <cstring>
using Microsoft::WRL::ComPtr;
int main(){
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;D3D_FEATURE_LEVEL f;
 assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,&f,&c)));
 const char shader[]="float4 VS(uint i:SV_VertexID):SV_POSITION {float2 p=float2((i<<1)&2,i&2);return float4(p*float2(2,-2)+float2(-1,1),0,1);}float4 PS():SV_TARGET{return float4(.25,.125,0,.5);}";
 ComPtr<ID3DBlob> vb,pb;assert(SUCCEEDED(D3DCompile(shader,strlen(shader),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&vb,nullptr)));assert(SUCCEEDED(D3DCompile(shader,strlen(shader),nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&pb,nullptr)));
 ComPtr<ID3D11VertexShader> vs;ComPtr<ID3D11PixelShader> ps;d->CreateVertexShader(vb->GetBufferPointer(),vb->GetBufferSize(),nullptr,&vs);d->CreatePixelShader(pb->GetBufferPointer(),pb->GetBufferSize(),nullptr,&ps);
 D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=16;td.MipLevels=td.ArraySize=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R8G8B8A8_UNORM;td.BindFlags=D3D11_BIND_RENDER_TARGET;
 ComPtr<ID3D11Texture2D> output;ComPtr<ID3D11RenderTargetView> rt;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&output)));d->CreateRenderTargetView(output.Get(),nullptr,&rt);auto* target=rt.Get();c->OMSetRenderTargets(1,&target,nullptr);
 D3D11_BLEND_DESC bd{};auto& b=bd.RenderTarget[0];b.BlendEnable=TRUE;b.SrcBlend=b.SrcBlendAlpha=D3D11_BLEND_SRC_ALPHA;b.DestBlend=b.DestBlendAlpha=D3D11_BLEND_INV_SRC_ALPHA;b.BlendOp=b.BlendOpAlpha=D3D11_BLEND_OP_ADD;b.RenderTargetWriteMask=15;ComPtr<ID3D11BlendState> blend;d->CreateBlendState(&bd,&blend);float factors[4]={.2f,.3f,.4f,.5f};c->OMSetBlendState(blend.Get(),factors,~0u);
 D3D11_RASTERIZER_DESC rd{};rd.FillMode=D3D11_FILL_SOLID;rd.CullMode=D3D11_CULL_NONE;rd.ScissorEnable=TRUE;ComPtr<ID3D11RasterizerState> clipped;d->CreateRasterizerState(&rd,&clipped);c->RSSetState(clipped.Get());D3D11_RECT clip{0,0,1,1};c->RSSetScissorRects(1,&clip);
 c->VSSetShader(vs.Get(),nullptr,0);c->PSSetShader(ps.Get(),nullptr,0);c->IASetInputLayout(nullptr);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);D3D11_VIEWPORT vp{0,0,16,16,0,1};c->RSSetViewports(1,&vp);float clear[4]{};c->ClearRenderTargetView(rt.Get(),clear);
 RFGRFullscreenRaster raster;{RFGRMenuCopyState state(c.Get());assert(state.bind(d.Get(),raster));c->Draw(3,0);}
 ComPtr<ID3D11BlendState> actualBlend;float actualFactors[4];UINT mask;c->OMGetBlendState(&actualBlend,actualFactors,&mask);ComPtr<ID3D11RasterizerState> actualRaster;c->RSGetState(&actualRaster);assert(actualBlend==blend&&actualRaster==clipped&&!memcmp(factors,actualFactors,sizeof(factors))&&mask==~0u);
 td.BindFlags=0;td.Usage=D3D11_USAGE_STAGING;td.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> readback;d->CreateTexture2D(&td,nullptr,&readback);c->CopyResource(readback.Get(),output.Get());D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(c->Map(readback.Get(),0,D3D11_MAP_READ,0,&map)));
 for(unsigned y=0;y<16;++y)for(unsigned x=0;x<16;++x){auto* p=(unsigned char*)map.pData+y*map.RowPitch+x*4;if(!(p[0]>=63&&p[0]<=64&&p[1]>=31&&p[1]<=32&&p[2]==0&&p[3]>=127&&p[3]<=128)){printf("pixel %u,%u = %u %u %u %u\n",x,y,p[0],p[1],p[2],p[3]);return 9;}}c->Unmap(readback.Get(),0);
 // The native UI capture contains LINEAR values, despite using UNORM.
 // Reproduce its orange (84,24,0), then require proper sRGB encoding.
 unsigned orange[16];for(auto& pixel:orange)pixel=0xff001854;D3D11_TEXTURE2D_DESC inputDesc{};inputDesc.Width=inputDesc.Height=4;inputDesc.MipLevels=inputDesc.ArraySize=inputDesc.SampleDesc.Count=1;inputDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;inputDesc.BindFlags=D3D11_BIND_SHADER_RESOURCE;D3D11_SUBRESOURCE_DATA inputData{orange,16,0};ComPtr<ID3D11Texture2D> linear;assert(SUCCEEDED(d->CreateTexture2D(&inputDesc,&inputData,&linear)));ComPtr<ID3D11ShaderResourceView> source;assert(SUCCEEDED(d->CreateShaderResourceView(linear.Get(),nullptr,&source)));
 auto srgbDesc=inputDesc;srgbDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;srgbDesc.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> srgb;assert(SUCCEEDED(d->CreateTexture2D(&srgbDesc,nullptr,&srgb)));ComPtr<ID3D11RenderTargetView> srgbTarget;assert(SUCCEEDED(d->CreateRenderTargetView(srgb.Get(),nullptr,&srgbTarget)));
 ComPtr<ID3DBlob> copyV,copyP;assert(SUCCEEDED(D3DCompile(RFGRMenuScaleShader,sizeof(RFGRMenuScaleShader)-1,nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&copyV,nullptr)));assert(SUCCEEDED(D3DCompile(RFGRMenuScaleShader,sizeof(RFGRMenuScaleShader)-1,nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&copyP,nullptr)));ComPtr<ID3D11VertexShader> copyVS;ComPtr<ID3D11PixelShader> copyPS;d->CreateVertexShader(copyV->GetBufferPointer(),copyV->GetBufferSize(),nullptr,&copyVS);d->CreatePixelShader(copyP->GetBufferPointer(),copyP->GetBufferSize(),nullptr,&copyPS);D3D11_SAMPLER_DESC samplerDesc{};samplerDesc.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;samplerDesc.AddressU=samplerDesc.AddressV=samplerDesc.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;ComPtr<ID3D11SamplerState> sampler;d->CreateSamplerState(&samplerDesc,&sampler);
 {RFGRMenuCopyState state(c.Get());assert(state.bind(d.Get(),raster));auto* target=srgbTarget.Get();auto* srv=source.Get();auto* filter=sampler.Get();D3D11_VIEWPORT viewport{0,0,4,4,0,1};c->OMSetRenderTargets(1,&target,nullptr);c->RSSetViewports(1,&viewport);c->VSSetShader(copyVS.Get(),nullptr,0);c->PSSetShader(copyPS.Get(),nullptr,0);c->PSSetShaderResources(0,1,&srv);c->PSSetSamplers(0,1,&filter);c->Draw(3,0);}
 auto stagingDesc=srgbDesc;stagingDesc.BindFlags=0;stagingDesc.Usage=D3D11_USAGE_STAGING;stagingDesc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> colorRead;assert(SUCCEEDED(d->CreateTexture2D(&stagingDesc,nullptr,&colorRead)));c->CopyResource(colorRead.Get(),srgb.Get());assert(SUCCEEDED(c->Map(colorRead.Get(),0,D3D11_MAP_READ,0,&map)));for(unsigned y=0;y<4;++y)for(unsigned x=0;x<4;++x){auto* pixel=(unsigned char*)map.pData+y*map.RowPitch+x*4;assert(pixel[0]>=154&&pixel[0]<=156&&pixel[1]>=85&&pixel[1]<=87&&pixel[2]==0&&pixel[3]==255);}c->Unmap(colorRead.Get(),0);
 puts("PASS: UI transfer preserves premultiplied RGB/alpha over full image despite inherited blending/scissor, restores caller state");
}


