#define NOMINMAX
#include "../src/bridge_menu_scene.h"
#include <cassert>
#include <cstdio>
#include <initializer_list>
using Microsoft::WRL::ComPtr;
int main(){
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;D3D_FEATURE_LEVEL feature;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,&feature,&c)));
 D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=64;desc.MipLevels=desc.SampleDesc.Count=1;desc.ArraySize=2;desc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> eyes;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&eyes)));
 ComPtr<ID3D11RenderTargetView> views[2];for(unsigned i=0;i<2;++i){D3D11_RENDER_TARGET_VIEW_DESC r{};r.Format=desc.Format;r.ViewDimension=D3D11_RTV_DIMENSION_TEXTURE2DARRAY;r.Texture2DArray.ArraySize=1;r.Texture2DArray.FirstArraySlice=i;assert(SUCCEEDED(d->CreateRenderTargetView(eyes.Get(),&r,&views[i])));float blue[]={0,0,1,1};c->ClearRenderTargetView(views[i].Get(),blue);}
 auto* original=views[0].Get();c->OMSetRenderTargets(1,&original,nullptr);D3D11_VIEWPORT vp{0,0,17,18,0,1};c->RSSetViewports(1,&vp);
 D3D11_TEXTURE2D_DESC sd=desc;sd.Width=sd.Height=4;sd.ArraySize=1;sd.BindFlags=D3D11_BIND_SHADER_RESOURCE;unsigned pixels[16];for(auto& p:pixels)p=0x80000080;D3D11_SUBRESOURCE_DATA data{pixels,16,0};ComPtr<ID3D11Texture2D> image;assert(SUCCEEDED(d->CreateTexture2D(&sd,&data,&image)));
 vrarm::M basis{{1,0,0},{0,1,0},{0,0,1}};vrarm::Pose panel{basis,{0,0,-2}},left{basis,{-.032f,0,0}},right{basis,{.032f,0,0}};float fov[]={-.8f,.8f,.8f,-.8f};RFGRMenuScene scene;
 RFGRMenuScene::Vertex a[6],b[6];assert(RFGRMenuScene::vertices(left,fov,panel,1,1,a)&&RFGRMenuScene::vertices(right,fov,panel,1,1,b));assert(a[0].clip[0]/a[0].clip[3]>b[0].clip[0]/b[0].clip[3]);
 // Background and foreground are composed in the SAME eye texture. The
 // runtime receives no opaque quad capable of hiding the projection layer.
 unsigned bluePixels[16];for(auto& pixel:bluePixels)pixel=0xffff0000;D3D11_SUBRESOURCE_DATA blueData{bluePixels,16,0};ComPtr<ID3D11Texture2D> backgroundImage;assert(SUCCEEDED(d->CreateTexture2D(&sd,&blueData,&backgroundImage)));RFGRMenuScene background;vrarm::Pose farPanel{basis,{0,0,-20}};
 for(unsigned eye=0;eye<2;++eye){float black[]={0,0,0,1};c->ClearRenderTargetView(views[eye].Get(),black);assert(background.draw(d.Get(),c.Get(),eyes.Get(),eye,backgroundImage.Get(),eye?right:left,fov,farPanel,50,50));}
 assert(scene.draw(d.Get(),c.Get(),eyes.Get(),0,image.Get(),left,fov,panel,1,1));assert(scene.draw(d.Get(),c.Get(),eyes.Get(),1,image.Get(),right,fov,panel,1,1));
 ComPtr<ID3D11RenderTargetView> restored;c->OMGetRenderTargets(1,&restored,nullptr);assert(restored.Get()==original);UINT n=1;D3D11_VIEWPORT actual{};c->RSGetViewports(&n,&actual);assert(actual.Width==17&&actual.Height==18);
 desc.BindFlags=0;desc.Usage=D3D11_USAGE_STAGING;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> staging;assert(SUCCEEDED(d->CreateTexture2D(&desc,nullptr,&staging)));c->CopyResource(staging.Get(),eyes.Get());
 for(unsigned eye=0;eye<2;++eye){D3D11_MAPPED_SUBRESOURCE m{};assert(SUCCEEDED(c->Map(staging.Get(),eye,D3D11_MAP_READ,0,&m)));auto* center=(unsigned char*)m.pData+32*m.RowPitch+32*4;assert(center[0]>=127&&center[0]<=129&&center[1]==0&&center[2]>=126&&center[2]<=129&&center[3]==255);auto* corner=(unsigned char*)m.pData;assert(corner[0]==0&&corner[2]==255);c->Unmap(staging.Get(),eye);}
 // SteamVR-style untyped array storage requires a typed view, for clearing and drawing.
 for(auto storage:{DXGI_FORMAT_R8G8B8A8_TYPELESS,DXGI_FORMAT_B8G8R8A8_TYPELESS}){
  auto typed=storage==DXGI_FORMAT_R8G8B8A8_TYPELESS?DXGI_FORMAT_R8G8B8A8_UNORM:DXGI_FORMAT_B8G8R8A8_UNORM;
  auto td=sd;td.Width=td.Height=64;td.ArraySize=2;td.Format=storage;td.BindFlags=D3D11_BIND_RENDER_TARGET;ComPtr<ID3D11Texture2D> untyped;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&untyped)));
  for(unsigned eye=0;eye<2;++eye){D3D11_RENDER_TARGET_VIEW_DESC view{};view.Format=RFGRMenuTargetFormat(storage,typed);view.ViewDimension=D3D11_RTV_DIMENSION_TEXTURE2DARRAY;view.Texture2DArray.ArraySize=1;view.Texture2DArray.FirstArraySlice=eye;ComPtr<ID3D11RenderTargetView> clear;assert(SUCCEEDED(d->CreateRenderTargetView(untyped.Get(),&view,&clear)));float blue[]={0,0,1,1};c->ClearRenderTargetView(clear.Get(),blue);assert(scene.draw(d.Get(),c.Get(),untyped.Get(),eye,image.Get(),eye?right:left,fov,panel,1,1,typed));}
 }
 // A large panel can cross the eye's near plane while remaining visible.
 auto side=left;side.b=vrarm::turnAround(basis,{0,1,0},1.05f);RFGRMenuScene::Vertex clipped[6];assert(RFGRMenuScene::vertices(side,fov,farPanel,50,50,clipped));for(auto& vertex:clipped)for(float value:vertex.clip)assert(std::isfinite(value));
 auto fixed=panel;left.p.x+=.1f;assert(RFGRMenuScene::vertices(left,fov,panel,1,1,b)&&b[0].clip[0]<a[0].clip[0]);assert(!memcmp(&fixed,&panel,sizeof(panel)));panel.p.z=2;assert(!scene.draw(d.Get(),c.Get(),eyes.Get(),0,image.Get(),left,fov,panel,1,1));
 puts("PASS main-menu application stereo plane: separate eyes/parallax, fixed world pose, premultiplied transparency, full state preservation and behind-eye rejection");
}

