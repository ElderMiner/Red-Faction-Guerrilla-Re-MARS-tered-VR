#include "../src/vr_orbital_billboard.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <initializer_list>
int main(){using namespace vrarm;V direction{-.196374f,.93433f,.297432f};M frame{};assert(RFGRVR_OrbitalBillboard(direction,frame));assert(fabsf(dot(frame.r,{0,1,0}))<1e-6f);assert(dot(frame.u,{0,1,0})>0);
 // A surface point stays fixed in the world across head rolls. Its position
 // in the eye rotates with the world, rather than remaining screen upright.
 V mark=add(direction,mul(frame.u,.02f));M identity{{1,0,0},{0,1,0},{0,0,1}};
 for(int i=-12;i<=12;++i){float roll=i*.1f;M camera=turnAround(identity,unit(direction),roll),again{};assert(RFGRVR_OrbitalBillboard(direction,again));assert(length(sub(again.r,frame.r))<1e-6f&&length(sub(again.u,frame.u))<1e-6f);V seen=local(camera,sub(mark,direction)),restored=world(camera,seen);assert(length(sub(restored,mul(frame.u,.02f)))<1e-6f);}
 for(V pole:{V{0,1,0},V{0,-1,0},V{0,0,1}}){M b{};assert(RFGRVR_OrbitalBillboard(pole,b)&&valid(b));}assert(!RFGRVR_OrbitalBillboard({0,0,0},frame));assert(!RFGRVR_OrbitalBillboard({NAN,0,1},frame));puts("PASS orbital image orientation: world-up meridian, head-roll independence, stable world surface point, pole fallback and invalid-input rejection");}
