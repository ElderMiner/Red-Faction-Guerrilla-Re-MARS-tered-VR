#define NOMINMAX
#include "../src/modern_material_bindings.h"
#include "../src/vr_deferred_probe.h"
#include <d3dcompiler.h>
#include <cassert>
#include <fstream>
#include <iterator>
#include <string>
#include <array>
using Microsoft::WRL::ComPtr;
int main(){
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;
 assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));
 auto file=[](const char* p){std::ifstream f(p);assert(f.good());return std::string(std::istreambuf_iterator<char>(f),{});};
 auto ps=file("src/modern_world_sampling.hlsl")+file("src/modern_height_sampling.hlsl")+"\nSamplerState s:register(s0);float4 main(float4 p:SV_Position):SV_Target{float2 uv=p.xy/8;return float4(modernRelief(p,uv,0,1,s),p.z,1);}";
 const char* vs="float4 main(uint id:SV_VertexID):SV_Position{float2 p=float2((id<<1)&2,id&2);return float4(p*float2(2,-2)+float2(-1,1),.5,1);}";
 ComPtr<ID3DBlob> b,error;assert(SUCCEEDED(D3DCompile(vs,strlen(vs),nullptr,nullptr,nullptr,"main","vs_4_0",0,0,&b,&error)));ComPtr<ID3D11VertexShader> v;assert(SUCCEEDED(d->CreateVertexShader(b->GetBufferPointer(),b->GetBufferSize(),nullptr,&v)));
 auto hr=D3DCompile(ps.c_str(),ps.size(),nullptr,nullptr,nullptr,"main","ps_4_0",0,0,&b,&error);if(FAILED(hr)&&error)fwrite(error->GetBufferPointer(),1,error->GetBufferSize(),stderr);assert(SUCCEEDED(hr));ComPtr<ID3D11PixelShader> p;assert(SUCCEEDED(d->CreatePixelShader(b->GetBufferPointer(),b->GetBufferSize(),nullptr,&p)));
 c->VSSetShader(v.Get(),nullptr,0);c->PSSetShader(p.Get(),nullptr,0);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
 D3D11_TEXTURE2D_DESC td{};td.Width=td.Height=8;td.ArraySize=td.MipLevels=td.SampleDesc.Count=1;td.Format=DXGI_FORMAT_R32G32B32A32_FLOAT;td.BindFlags=D3D11_BIND_RENDER_TARGET;
 ComPtr<ID3D11Texture2D> out,read;ComPtr<ID3D11RenderTargetView> rt;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&out)));assert(SUCCEEDED(d->CreateRenderTargetView(out.Get(),nullptr,&rt)));td.BindFlags=0;td.Usage=D3D11_USAGE_STAGING;td.CPUAccessFlags=D3D11_CPU_ACCESS_READ;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&read)));auto* target=rt.Get();c->OMSetRenderTargets(1,&target,nullptr);D3D11_VIEWPORT viewport{0,0,8,8,0,1};c->RSSetViewports(1,&viewport);
 float h=.5f;td.Width=td.Height=1;td.Format=DXGI_FORMAT_R32_FLOAT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;td.Usage=D3D11_USAGE_DEFAULT;td.CPUAccessFlags=0;D3D11_SUBRESOURCE_DATA init{&h,4,4};ComPtr<ID3D11Texture2D> height;ComPtr<ID3D11ShaderResourceView> view;assert(SUCCEEDED(d->CreateTexture2D(&td,&init,&height)));assert(SUCCEEDED(d->CreateShaderResourceView(height.Get(),nullptr,&view)));auto* srv=view.Get();c->PSSetShaderResources(21,1,&srv);
 D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_WRAP;sd.MaxLOD=D3D11_FLOAT32_MAX;ComPtr<ID3D11SamplerState> sampler;assert(SUCCEEDED(d->CreateSamplerState(&sd,&sampler)));auto* s=sampler.Get();c->PSSetSamplers(0,1,&s);
 modernmaterial::Frame world;world.eye[2]=2;world.eye[3]=1;world.viewport[0]=world.viewport[1]=8;world.inverseClip[0]=world.inverseClip[5]=world.inverseClip[10]=world.inverseClip[15]=1;
 float control[8]{.2f,0,0,0,8,20,16,0};D3D11_BUFFER_DESC bd{};bd.ByteWidth=sizeof(control);bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;init={control,0,0};ComPtr<ID3D11Buffer> cb;assert(SUCCEEDED(d->CreateBuffer(&bd,&init,&cb)));auto* constants=cb.Get();c->PSSetConstantBuffers(12,1,&constants);
 auto render=[&](){modernmaterial::Bindings binding;assert(binding.bind(c.Get(),nullptr,nullptr,&world));c->Draw(3,0);c->CopyResource(read.Get(),out.Get());D3D11_MAPPED_SUBRESOURCE m{};assert(SUCCEEDED(c->Map(read.Get(),0,D3D11_MAP_READ,0,&m)));std::array<float,4> result;memcpy(result.data(),(char*)m.pData+4*m.RowPitch+4*16,16);c->Unmap(read.Get(),0);return result;};
 auto flat=render();assert(fabs(flat[0]-.5625f)<1e-5&&fabs(flat[1]-.5625f)<1e-5&&flat[2]==.5f);
 h=1;c->UpdateSubresource(height.Get(),0,nullptr,&h,4,4);auto high=render();h=0;c->UpdateSubresource(height.Get(),0,nullptr,&h,4,4);auto low=render();assert(fabs(high[0]-flat[0])>.001&&fabs(high[0]+low[0]-2*flat[0])<1e-5);
 h=1;c->UpdateSubresource(height.Get(),0,nullptr,&h,4,4);world.eye[0]=-.2f;auto left=render();world.eye[0]=.2f;auto right=render();assert(fabs(left[0]-right[0])>.005f);
 world.origin[0]=100000;assert(render()==right);world.eye[2]=30;auto distant=render();assert(fabs(distant[0]-flat[0])<1e-5);world.eye[2]=2;control[0]=0;c->UpdateSubresource(cb.Get(),0,nullptr,control,0,0);assert(fabs(render()[0]-flat[0])<1e-5);
 // Test finite local reflection projection using actual shader pixels.
 auto reflection=file("src/modern_world_sampling.hlsl")+"\nfloat4 main(float4 p:SV_Position):SV_Target{return float4(modernReflectionDirection(p,float3(1,0,0)),1);}";
 assert(SUCCEEDED(D3DCompile(reflection.c_str(),reflection.size(),nullptr,nullptr,nullptr,"main","ps_4_0",0,0,&b,&error)));ComPtr<ID3D11PixelShader> rp;assert(SUCCEEDED(d->CreatePixelShader(b->GetBufferPointer(),b->GetBufferSize(),nullptr,&rp)));c->PSSetShader(rp.Get(),nullptr,0);
 world.origin[0]=0;world.reflectionCenter[3]=1;world.reflectionBounds[0]=world.reflectionBounds[1]=world.reflectionBounds[2]=2;
 auto projected=render();float length=sqrt(4.f+.125f*.125f+.5f*.5f);assert(fabs(projected[0]-2/length)<1e-5&&fabs(projected[1]+.125f/length)<1e-5&&fabs(projected[2]-.5f/length)<1e-5);
 world.origin[0]=world.reflectionCenter[0]=100000;assert(render()==projected);world.reflectionCenter[0]=0;auto outside=render();assert(outside[0]==1&&outside[1]==0&&outside[2]==0);world.origin[0]=0;world.reflectionCenter[3]=0;assert(render()==outside);
 // Production deferred hook must bind the matched normal's height, not
 // merely make a direct shader-only test pass. Native slots survive the scope.
 ComPtr<ID3D11DeviceContext> deferred;assert(SUCCEEDED(d->CreateDeferredContext(0,&deferred)));assert(RFGRVRDeferredProbe::attachContext(deferred.Get()));
 unsigned mode=0,normalBase=0,normalCount=0;for(unsigned n=0;n<sizeof(moderngenerated::variants)/sizeof(moderngenerated::variants[0]);++n){auto& values=moderngenerated::variants[n].values;if(atoi(values[0])==2){mode=500+n;normalBase=atoi(values[3]);normalCount=atoi(values[2]);break;}}assert(mode&&normalCount);
 ComPtr<ID3D11ShaderResourceView> normalView;assert(SUCCEEDED(d->CreateShaderResourceView(height.Get(),nullptr,&normalView)));modernmaterial::tag(p.Get(),int(mode));modernheight::resident.fetch_add(4);auto* owner=new modernheight::Attachment(view.Get(),4);assert(SUCCEEDED(normalView->SetPrivateDataInterface(modernheight::attachmentId,owner)));owner->Release();modernheight::resident.fetch_add(4);auto* optical=new modernheight::Attachment(view.Get(),4);assert(SUCCEEDED(normalView->SetPrivateDataInterface(modernheight::reflectivityId,optical)));optical->Release();
 for(unsigned identity:{mode,100u,101u}){modernmaterial::tag(p.Get(),int(identity));modernmaterial::WorldScope scope(world,nullptr,nullptr,nullptr,nullptr);deferred->PSSetShader(p.Get(),nullptr,0);ID3D11ShaderResourceView* normalViews[16];for(auto& v:normalViews)v=normalView.Get();deferred->PSSetShaderResources(0,16,normalViews);RFGRVRDeferredProbe::lighting(deferred.Get());ComPtr<ID3D11ShaderResourceView> applied;deferred->PSGetShaderResources(21,1,&applied);assert(applied.Get()==view.Get());ComPtr<ID3D11ShaderResourceView> materialApplied;deferred->PSGetShaderResources(25,1,&materialApplied);assert(materialApplied.Get()==view.Get());ID3D11ShaderResourceView* empty=nullptr;deferred->PSSetShaderResources(21,1,&empty);RFGRVRDeferredProbe::lighting(deferred.Get());applied.Reset();deferred->PSGetShaderResources(21,1,&applied);assert(applied.Get()==view.Get());}
 ComPtr<ID3D11ShaderResourceView> restored;deferred->PSGetShaderResources(21,1,&restored);assert(!restored);deferred->ClearState();ComPtr<ID3D11CommandList> retired;assert(SUCCEEDED(deferred->FinishCommandList(FALSE,&retired)));retired.Reset();normalView.Reset();assert(modernheight::resident==0);
 puts("PASS: actual relief pixels, neutral midpoint, symmetric depth, independent eye parallax, floating-origin invariance, distance fade and unchanged native depth");
}


