#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <cstdio>
#include <cassert>
#include "../src/modern_generated_ids.h"
#include "../src/modern_generated_source.h"
int main(){using namespace moderngenerated;Microsoft::WRL::ComPtr<ID3D11Device> device;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,nullptr,nullptr)));unsigned mode=0;for(auto variant:variants){D3D_SHADER_MACRO macros[10]{};for(unsigned i=0;i<9;++i)macros[i]={macroNames[i],variant.values[i]};Microsoft::WRL::ComPtr<ID3DBlob> code,error;HRESULT hr=D3DCompile(source,sizeof(source)-1,"generated",macros,nullptr,"main","ps_4_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error);if(FAILED(hr)){fprintf(stderr,"Variant %u: %s\n",mode,error?(char*)error->GetBufferPointer():"no diagnostic");return 1;}Microsoft::WRL::ComPtr<ID3D11PixelShader> shader;assert(SUCCEEDED(device->CreatePixelShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&shader)));++mode;}printf("PASS: %u generated terrain/surface variants compile and create on GPU\n",mode);}
