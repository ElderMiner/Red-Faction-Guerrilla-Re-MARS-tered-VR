#define NOMINMAX
#include "../src/modern_wave_transport.h"
#include <cassert>
#include <cstdio>
using namespace modernwave;
struct Scene {bool blocked=false,unknown=false;V transmission{1,1,1};unsigned calls=0;};
static bool segment(void* context,V,V,uint64_t,uint64_t,V& throughput){auto& s=*(Scene*)context;++s.calls;throughput=s.blocked?V{}:s.transmission;return !s.unknown;}
int main(){
 Surface wall;wall.id=1;wall.position={0,0,2};wall.normal={0,0,-1};wall.area=4;wall.visible=true;wall.material=profile(Material::Concrete);
 Field light;light.source=123;light.energy={100,80,60};light.range=20;
 Scene scene;Limits limits;limits.bounces=1;
 auto direct=solve({wall},{light},segment,&scene,limits);assert(direct.valid&&direct.queries==1&&direct.received[0].x>0&&direct.received[0].x<100);
 scene.blocked=true;assert(solve({wall},{light},segment,&scene,limits).received[0].x==0);
 scene.blocked=false;scene.unknown=true;assert(solve({wall},{light},segment,&scene,limits).received[0].x==0);
 scene.unknown=false;scene.transmission={.5f,.25f,.125f};auto glass=solve({wall},{light},segment,&scene,limits);assert(std::abs(glass.received[0].x/direct.received[0].x-.5f)<1e-6f);assert(std::abs(glass.received[0].y/direct.received[0].y-.25f)<1e-6f);
 scene.transmission={1,1,1};auto far=light;far.origin={0,0,-5};assert(solve({wall},{far},segment,&scene,limits).received[0].x<direct.received[0].x);far.range=2;assert(solve({wall},{far},segment,&scene,limits).received[0].x==0);
 // Two facing walls exchange multiple bounces. The initially hidden wall must
 // remain relevant to the visible receiver; tint changes the returned field.
 auto hidden=wall;hidden.visible=false;hidden.material.albedo={1,.05f,.05f};
 auto receiver=wall;receiver.id=2;receiver.position={0,0,-2};receiver.normal={0,0,1};receiver.material.albedo={.5f,.5f,.5f};
 auto one=solve({hidden,receiver},{light},segment,&scene,limits);limits.bounces=6;
 auto many=solve({hidden,receiver},{light},segment,&scene,limits);assert(many.valid&&many.bounces>2&&many.received[1].x>one.received[1].x);assert(many.received[1].x-one.received[1].x>many.received[1].y-one.received[1].y);
 // An enormous overlapping receiver set cannot collect more than source power.
 std::vector<Surface> overlap;for(unsigned i=0;i<64;++i){auto s=wall;s.id=i+1;s.area=10000;overlap.push_back(s);}limits.bounces=1;auto energy=solve(overlap,{light},segment,&scene,limits);float sum=0;for(auto v:energy.received)sum+=v.x;assert(sum<=100.001f);
 limits.bounces=6;limits.fields=1;auto capped=solve({hidden,receiver},{light},segment,&scene,limits);assert(capped.valid&&capped.truncated&&capped.fields<=1);
 limits.queries=1;assert(solve({hidden,receiver},{light},segment,&scene,limits).truncated);
 wall.visible=false;scene.calls=0;assert(solve({wall},{light},segment,&scene).valid&&scene.calls==0);
 light.energy.x=NAN;assert(!solve({wall},{light},segment,&scene).valid);
 puts("PASS wave transport: solid/unknown blocking, RGB transmission, range loss, offscreen multi-bounce contribution, surface tint, power conservation and bounded work");
}
