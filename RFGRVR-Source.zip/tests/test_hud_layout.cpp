#define RFGR_TEST_USER_SETTINGS
#include "../src/vr_hud_layout.h"
#include <cassert>
int main(){using namespace vrhudlayout;Layout shipping(false);shipping.input(true,0);assert(!shipping.editing);shipping.key(VK_NUMPAD0);shipping.input(true,1);assert(!shipping.editing&&!shipping.moving);Layout a(false);RFGRPose base{};base.active=1;base.validFlags=3;base.orientation[3]=1;RFGRPose hand=base;
 a.key(VK_NUMPAD0);assert(a.editing);a.key(VK_NUMPAD9);assert(a.selected==EDF);a.key(VK_ADD);a.key(VK_NUMPAD3);assert(a.selected==Timer);a.key(VK_NUMPAD9);assert(a.selected==Timer);a.key(VK_MULTIPLY);assert(a.item[Timer].scale>1);a.key(VK_SUBTRACT);assert(fabsf(a.item[Timer].scale-1)<.0001f);
 a.key(VK_ADD);a.key(VK_NUMPAD2);assert(a.selected==Ammo);a.key(VK_DECIMAL);a.grip=1;a.apply(Ammo,base,hand);hand.position[0]=.1f;RFGRPose p=base;a.apply(Ammo,p,hand);assert(fabsf(p.position[0]-.1f)<.0001f);a.key(VK_DECIMAL);a.grip=0;p=base;a.apply(Ammo,p,hand);assert(fabsf(p.position[0]-.1f)<.0001f&&!a.dragging);
 // Other anchors and the camera are untouched by editing the selected item.
 p=base;a.apply(Health,p,hand);assert(p.position[0]==0&&base.position[0]==0);
 // Map-mounted parts remain planar, return after reversing motion and stay visible at their size limits.
 a.selected=Timer;a.key(VK_DECIMAL);a.grip=1;float x=256,y=0,w=256,h=64;a.rect(Timer,base,hand,x,y,w,h);hand.position[0]=.13f;hand.position[2]=.4f;x=256;y=0;w=256;h=64;a.rect(Timer,base,hand,x,y,w,h);assert(a.item[Timer].offset.z==0&&a.item[Timer].offset.x>.02f);hand.position[0]=.1f;x=256;y=0;w=256;h=64;a.rect(Timer,base,hand,x,y,w,h);assert(fabsf(a.item[Timer].offset.x)<.0001f);a.key(VK_DECIMAL);a.grip=0;a.rect(Timer,base,hand,x,y,w,h);
 a.item[Timer].scale=3;a.item[Timer].offset={1,1,0};x=256;y=0;w=256;h=64;a.rect(Timer,base,hand,x,y,w,h);assert(x>=0&&y>=0&&x+w<=768&&y+h<=1280);
 // Persistence is separate from approved defaults and rejects malformed saved values.
 char tmp[MAX_PATH];GetTempPathA(MAX_PATH,tmp);sprintf_s(a.path,"%sRFGRVR-hud-layout-test-%lu.ini",tmp,GetCurrentProcessId());a.dirty=true;assert(a.save());Layout b(false);strcpy_s(b.path,a.path);b.load();assert(fabsf(b.item[Ammo].offset.x-.1f)<.0001f&&b.item[Timer].scale==3);WritePrivateProfileStringA(names[Health],"Layout","nan 0 0 1",a.path);b.load();assert(b.item[Health].scale==1&&b.item[Health].offset.x==0);DeleteFileA(a.path);

 // Vehicle editing has its own selection map and independent persisted profile.
 Profiles profiles(false);auto& vehicle=profiles.select(true);assert(vehicle.vehicle);vehicle.key(VK_NUMPAD0);vehicle.key(VK_NUMPAD2);assert(vehicle.selected==Health);vehicle.key(VK_NUMPAD5);assert(vehicle.selected==Timer);vehicle.key(VK_ADD);assert(vehicle.page==0);assert(!vehicle.editorHud(0)&&vehicle.editorHud(5));vehicle.item[Health].scale=.6f;
 auto& foot=profiles.select(false);assert(!vehicle.editing&&!foot.vehicle);foot.item[Health].scale=1.8f;foot.key(VK_NUMPAD0);foot.key(VK_NUMPAD2);assert(foot.selected==Ammo&&vehicle.item[Health].scale==.6f);
 auto& dlc=profiles.select(false,true);assert(!foot.editing&&&dlc!=&foot&&dlc.item[Health].scale==1.8f);
 dlc.beginHealth(1);dlc.healthInput(true,1);assert(dlc.editing&&dlc.selected==Health&&dlc.editorHud(5)&&!dlc.editorHud(0));
 dlc.healthInput(true,0);dlc.item[Health].scale=.9f;dlc.healthInput(true,1);assert(!dlc.editing&&foot.item[Health].scale==1.8f&&vehicle.item[Health].scale==.6f);
 profiles.select(false);assert(!foot.editing);
 sprintf_s(foot.path,"%sRFGRVR-hud-foot-%lu.ini",tmp,GetCurrentProcessId());sprintf_s(vehicle.path,"%sRFGRVR-hud-vehicle-%lu.ini",tmp,GetCurrentProcessId());foot.dirty=vehicle.dirty=true;profiles.save();Layout savedFoot(false),savedVehicle(false);strcpy_s(savedFoot.path,foot.path);strcpy_s(savedVehicle.path,vehicle.path);savedFoot.load();savedVehicle.load();assert(savedFoot.item[Health].scale==1.8f&&savedVehicle.item[Health].scale==.6f);DeleteFileA(foot.path);DeleteFileA(vehicle.path);
 // On-foot health stays horizontally centered at every saved size and yaw.
 {RFGRPose anchor{};anchor.validFlags=3;anchor.active=1;anchor.orientation[3]=1;anchor.position[0]=2;anchor.position[1]=1;anchor.position[2]=3;Layout centered(false);centered.item[Health].offset={.22f,.08f,.07f};
 for(float yaw:{0.f,.7f,2.f})for(float scale:{.25f,1.f,2.925258f,3.f}){anchor.orientation[1]=sinf(yaw*.5f);anchor.orientation[3]=cosf(yaw*.5f);auto placed=anchor;centered.item[Health].scale=scale;centered.apply(Health,placed,hand);auto delta=vrarm::local(RFGRVRWeaponSelector::basis(anchor),vrarm::sub({placed.position[0],placed.position[1],placed.position[2]},{anchor.position[0],anchor.position[1],anchor.position[2]}));assert(fabsf(delta.x)<.0001f&&fabsf(delta.y-.08f)<.0001f&&fabsf(delta.z-.07f)<.0001f);assert(centered.item[Health].offset.x==.22f);}
 centered.vehicle=true;auto placed=anchor;centered.apply(Health,placed,hand);auto delta=vrarm::local(RFGRVRWeaponSelector::basis(anchor),vrarm::sub({placed.position[0],placed.position[1],placed.position[2]},{anchor.position[0],anchor.position[1],anchor.position[2]}));assert(fabsf(delta.x-.22f)<.0001f);}
 // A large vehicle-health rectangle retains its 4:1 aspect and all edges.
 float hx=0,hy=768,hw=768,hh=192;vehicle.item[Health].scale=3;vehicle.rect(Health,base,hand,hx,hy,hw,hh);assert(fabsf(hw/hh-4)<.0001f&&hx>=0&&hy>=0&&hx+hw<=768&&hy+hh<=1280);
 a.key(VK_NUMPAD0);assert(!a.editing&&a.closed&&!a.moving);
}
