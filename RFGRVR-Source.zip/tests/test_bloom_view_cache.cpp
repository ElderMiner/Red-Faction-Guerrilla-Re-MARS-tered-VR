#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../src/vr_bloom_view_cache.h"
#include "../src/vr_vehicle_bloom.h"
#include "../src/vr_sun_glare.h"
static bool vrEnabled=true;
extern "C" bool RFGRVR_HeadCam_Enabled(){return vrEnabled;}
using namespace RFGRVRBloomViewCache;
static unsigned char compositor[0xbac]{},managerStorage[0x700]{};
static unsigned sources=0,exposures=0;static bool useAdaptation=true;
static void put(void* p,unsigned off,unsigned v){memcpy((char*)p+off,&v,4);}
static void __fastcall Exposure(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f){assert(a==1&&f==6);++exposures;put(self,0xba8,currentFrame());}
static void __fastcall Source(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g){
 assert(a==1&&b==2&&c==3&&d==4&&e==5&&f==6&&g==0x76543210);
 if(RFGRVREffectGeometry::word(self,0xba8)!=currentFrame()){
  ++sources;if(useAdaptation)onAdaptation(self,nullptr,a,b,c,d,e,f);
 }
}
static SourcePass volatile nativeEntry=(SourcePass)&onDownsample;
static __declspec(noinline) void run(int eye){
 RFGRVREffectGeometry::eye=eye;uintptr_t before=0,after=0;
 __asm mov before,esp
 nativeEntry(compositor,1,2,3,4,5,6,0x76543210);
 __asm mov after,esp
 assert(before==after);
}

static unsigned char nativeHdr[0x68];static bool adjusted=false;static unsigned forwarded=0;
static void setFloat(unsigned char* p,unsigned off,float f){memcpy(p+off,&f,4);}
static float getFloat(const void* p,unsigned off){float f;memcpy(&f,(const char*)p+off,4);return f;}
static void __fastcall Forward(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f){
 assert(self==compositor&&a==11&&b==22&&d==44&&e==55&&f==66);++forwarded;
 // Adaptation must receive the exact original HDR argument in vehicles too.
 assert(c==(uintptr_t)nativeHdr);
}
static unsigned composites=0;
static void __fastcall ForwardUpload(void* self,void*,void* renderer,const void* h,const void* colour){
 assert(self==compositor&&renderer==managerStorage&&colour==(void*)99);++composites;
 assert((h!=nativeHdr)==adjusted);
 for(unsigned j=0;j<sizeof(nativeHdr);++j)if(j<0x48||j>=0x4c)assert(((unsigned char*)h)[j]==nativeHdr[j]);
 assert(getFloat(h,0x48)==(adjusted?.5f:2.5f));
 assert(getFloat(h,0x24)==.001f&&getFloat(h,0x20)==4);
}
static unsigned finalDraws=0;
static void __fastcall FinalDraw(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h,uintptr_t i){
 assert(self==compositor&&a==(uintptr_t)managerStorage&&b==22&&c==33&&d==44&&e==55&&f==66&&g==77&&h==(uintptr_t)nativeHdr&&i==99);
 assert(getFloat(managerStorage,0x2c0+73*4)==(adjusted?.5f:2.5f));
 assert(getFloat(nativeHdr,0x24)==.001f&&getFloat(nativeHdr,0x48)==2.5f);++finalDraws;
}
static void vehicleTest(){
 using namespace vrvehiclebloom;
 for(unsigned state=0;state<12;++state){assert(eligible(true,state,true)==(state>=8&&state<=10));assert(!eligible(false,state,true));assert(!eligible(true,state,false));}
 memset(nativeHdr,0x5a,sizeof(nativeHdr));setFloat(nativeHdr,0x20,4);setFloat(nativeHdr,0x24,.001f);setFloat(nativeHdr,0x48,2.5f);
 Parameters p;assert(p.copy(nativeHdr,true));assert(getFloat(p.bytes,0x48)==.5f);assert(getFloat(nativeHdr,0x48)==2.5f);
 assert(!p.copy(nativeHdr,false));
 adaptation=(ExposurePass)Forward;ExposurePass volatile entry=(ExposurePass)&onAdaptation;
 for(bool enabled:{false,true}){vrvehiclebloom::active=enabled;uintptr_t before,after;
 __asm mov before,esp
 entry(compositor,11,22,(uintptr_t)nativeHdr,44,55,66);
 __asm mov after,esp
 assert(before==after);assert(getFloat(nativeHdr,0x24)==.001f);}
 assert(forwarded==2);
 refreshing=compositor;entry(compositor,11,22,(uintptr_t)nativeHdr,44,55,66);refreshing=nullptr;assert(forwarded==2);
 upload=(vrvehiclebloom::Upload)ForwardUpload;vrvehiclebloom::Upload volatile uploadEntry=(vrvehiclebloom::Upload)&onUpload;
 for(bool vr:{false,true})for(bool inVehicle:{false,true})for(int eye=0;eye<2;++eye){
  vrEnabled=vr;vrvehiclebloom::active=inVehicle;adjusted=vr&&inVehicle;uintptr_t before,after;
  __asm mov before,esp
  uploadEntry(compositor,managerStorage,nativeHdr,(void*)99);
  __asm mov after,esp
  assert(before==after&&getFloat(nativeHdr,0x48)==2.5f);
 }
 assert(composites==8&&adjustments==2);
 vrglare::composite=(vrglare::Composite)FinalDraw;vrglare::Composite volatile finalEntry=(vrglare::Composite)&vrglare::onComposite;
 put(compositor,0xb58,73);
 for(bool vr:{false,true})for(bool vehicle:{false,true})for(int eye=0;eye<2;++eye){
  vrEnabled=vr;active=vehicle;adjusted=vr&&vehicle;setFloat(managerStorage,0x2c0+73*4,2.5f);put(managerStorage,0x444,4);
  unsigned char beforeState[sizeof(managerStorage)];memcpy(beforeState,managerStorage,sizeof(managerStorage));uintptr_t before,after;
  __asm mov before,esp
  finalEntry(compositor,(uintptr_t)managerStorage,22,33,44,55,66,77,(uintptr_t)nativeHdr,99);
  __asm mov after,esp
  assert(before==after&&getFloat(managerStorage,0x2c0+73*4)==2.5f);
  for(unsigned j=0;j<sizeof(managerStorage);++j)if(j<0x444||j>=0x448)assert(beforeState[j]==managerStorage[j]);
  assert(RFGRVREffectGeometry::word(managerStorage,0x444)==(adjusted?0x24u:4u));
 }
 assert(finalDraws==8);vrglare::composite=nullptr;
 {put(compositor,0xb58,1000);CompositeScope invalid(compositor,managerStorage,true);assert(!invalid.slot);}
 for(float value:{0.f,.1f,.5f,-1.f,INFINITY,NAN}){setFloat(nativeHdr,0x48,value);assert(!p.copy(nativeHdr,true));}
 assert(!p.copy(nullptr,true));vrEnabled=true;active=false;upload=nullptr;
 retainedExposure=0;adaptation=(ExposurePass)Exposure;
}

int main(){vehicleTest();void* m=managerStorage;manager=&m;downsample=(SourcePass)Source;adaptation=(ExposurePass)Exposure;put(managerStorage,0x6dc,100);
 run(0);assert(sources==1&&exposures==1);run(1);assert(sources==2&&exposures==1&&retainedExposure==1);assert(RFGRVREffectGeometry::word(compositor,0xba8)==100&&!refreshing);
 // Ordinary rendering and repeated first-eye work retain the engine's cache.
 run(-1);run(0);assert(sources==2&&exposures==1);
 put(managerStorage,0x6dc,101);run(0);run(1);assert(sources==4&&exposures==2);
 // A stale right-eye cache follows the original initialization path.
 put(managerStorage,0x6dc,102);run(1);assert(sources==5&&exposures==3);
 // With adaptation disabled, refreshing the image must still publish its stamp.
 useAdaptation=false;run(1);assert(sources==6&&exposures==3&&RFGRVREffectGeometry::word(compositor,0xba8)==102);
 put(managerStorage,0x6dc,0);put(compositor,0xba8,0);run(1);assert(sources==7&&RFGRVREffectGeometry::word(compositor,0xba8)==0);
 manager=nullptr;run(-1);
}

