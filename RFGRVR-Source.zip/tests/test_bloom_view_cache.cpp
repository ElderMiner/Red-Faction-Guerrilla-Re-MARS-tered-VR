#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../src/vr_bloom_view_cache.h"
using namespace RFGRVRBloomViewCache;
static unsigned char compositor[0xbac]{},managerStorage[0x700]{};
static unsigned sources=0,exposures=0;static bool useAdaptation=true;
static void put(void* p,unsigned off,unsigned v){memcpy((char*)p+off,&v,4);}
static void __fastcall Exposure(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f){assert(a==1&&f==6);++exposures;put(self,0xba8,currentFrame());}
static void __fastcall Source(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g){
 assert(a==1&&b==2&&c==3&&d==4&&e==5&&f==6&&g==0x76543210);
 if(RFGRVREffectGeometry::word(self,0xba8)!=currentFrame()){
  ++sources;if(useAdaptation)onAdaptation(self,nullptr,a,b,c,d,e,f);
 }
}
static SourcePass volatile nativeEntry=(SourcePass)&onDownsample;
static __declspec(noinline) void run(int eye){
 RFGRVREffectGeometry::eye=eye;uintptr_t before=0,after=0;
 __asm mov before,esp
 nativeEntry(compositor,1,2,3,4,5,6,0x76543210);
 __asm mov after,esp
 assert(before==after);
}

static unsigned char nativeHdr[0x68];static bool adjusted=false;static unsigned forwarded=0;
static void setFloat(unsigned char* p,unsigned off,float f){memcpy(p+off,&f,4);}
static float getFloat(const void* p,unsigned off){float f;memcpy(&f,(const char*)p+off,4);return f;}
static void __fastcall Forward(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f){
 assert(self==compositor&&a==11&&b==22&&d==44&&e==55&&f==66);++forwarded;
 assert((c!=(uintptr_t)nativeHdr)==adjusted);
 for(unsigned i=0;i<sizeof(nativeHdr);++i)if(i<0x24||i>=0x28)assert(((unsigned char*)c)[i]==nativeHdr[i]);
 assert(getFloat((void*)c,0x24)==(adjusted?.5f:.001f));
}
static void vehicleTest(){
 using namespace vrvehicleexposure;
 for(unsigned state=0;state<12;++state){assert(eligible(true,state,true)==(state>=8&&state<=10));assert(!eligible(false,state,true));assert(!eligible(true,state,false));}
 memset(nativeHdr,0x5a,sizeof(nativeHdr));setFloat(nativeHdr,0x20,4);setFloat(nativeHdr,0x24,.001f);
 Parameters p;assert(p.copy(nativeHdr,true));assert(getFloat(p.bytes,0x24)==.5f);assert(getFloat(nativeHdr,0x24)==.001f);
 assert(!p.copy(nativeHdr,false));
 adaptation=(ExposurePass)Forward;ExposurePass volatile entry=(ExposurePass)&onAdaptation;
 for(bool active:{false,true}){vehicleExposure=active;adjusted=active;uintptr_t before,after;
 __asm mov before,esp
 entry(compositor,11,22,(uintptr_t)nativeHdr,44,55,66);
 __asm mov after,esp
 assert(before==after);assert(getFloat(nativeHdr,0x24)==.001f);}
 assert(forwarded==2&&vehicleAdjustments==1);
 refreshing=compositor;entry(compositor,11,22,(uintptr_t)nativeHdr,44,55,66);refreshing=nullptr;assert(forwarded==2&&vehicleAdjustments==1);
 setFloat(nativeHdr,0x24,.6f);assert(!p.copy(nativeHdr,true));
 setFloat(nativeHdr,0x20,.2f);setFloat(nativeHdr,0x24,0);assert(p.copy(nativeHdr,true)&&getFloat(p.bytes,0x24)==.2f);
 for(float bad:{-1.f,INFINITY,NAN}){setFloat(nativeHdr,0x24,bad);assert(!p.copy(nativeHdr,true));}
 setFloat(nativeHdr,0x24,.3f);assert(!p.copy(nativeHdr,true));
 vehicleExposure=false;retainedExposure=0;adaptation=(ExposurePass)Exposure;
}

int main(){vehicleTest();void* m=managerStorage;manager=&m;downsample=(SourcePass)Source;adaptation=(ExposurePass)Exposure;put(managerStorage,0x6dc,100);
 run(0);assert(sources==1&&exposures==1);run(1);assert(sources==2&&exposures==1&&retainedExposure==1);assert(RFGRVREffectGeometry::word(compositor,0xba8)==100&&!refreshing);
 // Ordinary rendering and repeated first-eye work retain the engine's cache.
 run(-1);run(0);assert(sources==2&&exposures==1);
 put(managerStorage,0x6dc,101);run(0);run(1);assert(sources==4&&exposures==2);
 // A stale right-eye cache follows the original initialization path.
 put(managerStorage,0x6dc,102);run(1);assert(sources==5&&exposures==3);
 // With adaptation disabled, refreshing the image must still publish its stamp.
 useAdaptation=false;run(1);assert(sources==6&&exposures==3&&RFGRVREffectGeometry::word(compositor,0xba8)==102);
 put(managerStorage,0x6dc,0);put(compositor,0xba8,0);run(1);assert(sources==7&&RFGRVREffectGeometry::word(compositor,0xba8)==0);
 manager=nullptr;run(-1);
}

