#define NOMINMAX
#include "../src/ipc.h"
#include "../src/vr_display_geometry.h"
#include "../src/vr_eye_projection.h"
#include <cassert>
#include <cstdio>
#include <cstring>
int main(){
 unsigned w=0,h=0;
 // Panel-sized and larger synthetic recommendations; these are not headset captures.
 for(auto r:{RFGRVRRenderRecommendation{2064,2208,8192,8192},{1832,1920,8192,8192},{2160,2160,8192,8192},{1440,1600,8192,8192},{3328,3472,8192,8192}}){
  assert(RFGRVR_RecommendedSize(r,0,&w,&h)&&w==r.width&&h==r.height);
  assert(RFGRVR_RecommendedSize(r,11,&w,&h)&&w==unsigned(r.width*.8)&&h==unsigned(r.height*.8));
  assert(std::fabs(double(w)/h-double(r.width)/r.height)<.002);
  assert(RFGRVR_RecommendedSize(r,20,&w,&h)&&w==unsigned(r.width*1.2)&&h==unsigned(r.height*1.2));
 }
 auto joined=RFGRVR_JoinRecommendations({2100,2300,4096,4096},{2200,2200,4000,3900});
 assert(joined.width==2200&&joined.height==2300&&joined.maxWidth==4000&&joined.maxHeight==3900);
 assert(RFGRVR_RecommendedSize(joined,0,&w,&h)&&w==2200&&h==2300);
 assert(!RFGRVR_RecommendedSize({},0,&w,&h));assert(!RFGRVR_RecommendedSize(RFGRVR_JoinRecommendations({},joined),0,&w,&h));
 assert(!RFGRVR_RecommendedSize(joined,17,&w,&h));assert(!RFGRVR_RecommendedSize(joined,0,nullptr,&h));
 assert(RFGRVR_RecommendedSize({3000,3000,3200,4096},20,&w,&h)&&w==3200&&h==3200);
 assert(RFGRVR_RecommendedSize({8000,8000,9000,9000},20,&w,&h)&&uint64_t(w)*h<=32000000&&w<=8192&&h<=8192);
 assert(!RFGRVR_RecommendedSize({400,300,8192,8192},0,&w,&h));
 assert(RFGRVR_RecommendedSize({640,480,8192,8192},11,&w,&h)&&w==640&&h==480);
 assert(RFGRVR_RecommendedSize({800,400,8192,8192},11,&w,&h)&&w==720&&h==360);
 const float angles[2][4]={{-.95f,.72f,.85f,-.9f},{-.71f,.96f,.86f,-.88f}};
 for(auto& eye:angles){RFGRVREyeProjection initial{};assert(RFGRVR_BuildEngineProjection(eye,.05f,500.f,&initial));
  for(int preset:{11,0,20}){assert(RFGRVR_RecommendedSize({3000,3200,8192,8192},preset,&w,&h));RFGRVREyeProjection current{};
   assert(RFGRVR_BuildEngineProjection(eye,.05f,500.f,&current)&&!memcmp(&initial,&current,sizeof(initial)));
   float p[4]={current.columnMajor[0],current.columnMajor[5],current.columnMajor[8],current.columnMajor[9]},x=0,y=0;
   assert(RFGRVR_CentralPPD(w,h,p,&x,&y)&&x>0&&y>0);
   assert(std::fabs(x-w*.5f*p[0]/57.295779513f)<.0001f);
   for(unsigned i=0;i<4;++i){float ray=std::tan(eye[i]);float clip=i<2?p[0]*ray+p[2]:p[1]*ray+p[3];float expected=(i==0||i==3)?-1.f:1.f;assert(std::fabs(clip-expected)<.00001f);}
  }
 }
 float bad[4]={NAN,1,0,0},x=0,y=0;assert(!RFGRVR_CentralPPD(2160,2160,bad,&x,&y));
 printf("PASS: runtime-recommended presets, mixed eyes, bounds, unchanged asymmetric projection rays, measured central render density and shared ABI (%zu bytes).\n",sizeof(RFGRShared));
}
