#define NOMINMAX
#include "../src/modern_local_shadows.h"
#include <d3dcompiler.h>
#include <cassert>
#include <cstdio>
using Microsoft::WRL::ComPtr;
struct Caster {
 ComPtr<ID3D11VertexShader> vertex;ComPtr<ID3D11Buffer> constants;
 ComPtr<ID3D11DepthStencilState> depth;ComPtr<ID3D11RasterizerState> raster;
 unsigned calls=0;bool fail=false;
 static bool draw(void* user,ID3D11DeviceContext* c,const modernlocal::Projection& p,unsigned){auto& s=*(Caster*)user;++s.calls;if(s.fail)return false;c->UpdateSubresource(s.constants.Get(),0,nullptr,p.clip,0,0);auto* cb=s.constants.Get();c->VSSetConstantBuffers(0,1,&cb);c->VSSetShader(s.vertex.Get(),nullptr,0);c->PSSetShader(nullptr,nullptr,0);c->GSSetShader(nullptr,nullptr,0);c->HSSetShader(nullptr,nullptr,0);c->DSSetShader(nullptr,nullptr,0);c->IASetInputLayout(nullptr);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);c->OMSetDepthStencilState(s.depth.Get(),0);c->RSSetState(s.raster.Get());c->Draw(3,0);return true;}
};
int main(){
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));
 Caster caster;const char* source="cbuffer Camera:register(b0){row_major float4x4 worldClip;};float4 main(uint id:SV_VertexID):SV_Position{float3 p=id==0?float3(-4,-4,2):id==1?float3(0,4,2):float3(4,-4,2);return mul(worldClip,float4(p,1));}";ComPtr<ID3DBlob> code,error;assert(SUCCEEDED(D3DCompile(source,strlen(source),nullptr,nullptr,nullptr,"main","vs_4_0",0,0,&code,&error)));assert(SUCCEEDED(d->CreateVertexShader(code->GetBufferPointer(),code->GetBufferSize(),nullptr,&caster.vertex)));
 D3D11_BUFFER_DESC bd{};bd.ByteWidth=64;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;assert(SUCCEEDED(d->CreateBuffer(&bd,nullptr,&caster.constants)));D3D11_DEPTH_STENCIL_DESC ds{};ds.DepthEnable=TRUE;ds.DepthWriteMask=D3D11_DEPTH_WRITE_MASK_ALL;ds.DepthFunc=D3D11_COMPARISON_LESS;assert(SUCCEEDED(d->CreateDepthStencilState(&ds,&caster.depth)));D3D11_RASTERIZER_DESC rs{};rs.FillMode=D3D11_FILL_SOLID;rs.CullMode=D3D11_CULL_NONE;rs.DepthClipEnable=TRUE;assert(SUCCEEDED(d->CreateRasterizerState(&rs,&caster.raster)));
 modernscene::Light light;light.kind=2;light.range=10;light.innerCos=.9f;light.outerCos=.70710678f;light.direction[2]=1;light.colour[0]=1;
 auto v=modernlocal::views(light);assert(v.count==1);float* m=v.faces[0].texture;float world[4]={0,0,2,1},projected[4]{};for(unsigned r=0;r<4;++r)for(unsigned k=0;k<4;++k)projected[r]+=m[r*4+k]*world[k];assert(std::abs(projected[0]/projected[3]-.5f)<1e-6f&&std::abs(projected[1]/projected[3]-.5f)<1e-6f);
 modernlocal::Atlas atlas;atlas.begin(1,6);int slot=atlas.update(d.Get(),c.Get(),42,light,1,64,&Caster::draw,&caster);assert(slot>=0&&caster.calls==1&&atlas.remaining()==5&&atlas.lookup(slot,42,1));
 ComPtr<ID3D11Resource> resource;atlas.resource()->GetResource(&resource);ComPtr<ID3D11Texture2D> texture;assert(SUCCEEDED(resource.As(&texture)));D3D11_TEXTURE2D_DESC td{};texture->GetDesc(&td);td.BindFlags=0;td.Usage=D3D11_USAGE_STAGING;td.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> read;assert(SUCCEEDED(d->CreateTexture2D(&td,nullptr,&read)));
 auto center=[&](unsigned face){c->CopyResource(read.Get(),texture.Get());D3D11_MAPPED_SUBRESOURCE data{};assert(SUCCEEDED(c->Map(read.Get(),slot*6+face,D3D11_MAP_READ,0,&data)));float z;memcpy(&z,(char*)data.pData+32*data.RowPitch+32*4,4);c->Unmap(read.Get(),slot*6+face);return z;};assert(center(0)<1&&center(0)>.9f);
 assert(atlas.update(d.Get(),c.Get(),42,light,1,64,&Caster::draw,&caster)==slot&&caster.calls==1);assert(!atlas.lookup(slot,42,2));
 atlas.begin(2,0);light.position[0]=1;assert(atlas.update(d.Get(),c.Get(),42,light,2,64,&Caster::draw,&caster)<0&&!atlas.lookup(slot,42,1));
 atlas.begin(3,6);light.position[0]=0;light.kind=1;slot=atlas.update(d.Get(),c.Get(),42,light,2,64,&Caster::draw,&caster);assert(slot>=0&&caster.calls==7&&atlas.remaining()==0);assert(center(4)<1&&center(5)==1);assert(modernlocal::face({0,0,2})==4&&modernlocal::face({-2,0,0})==1);
 // A new light cannot evict a valid cached map when no draw budget remains.
 assert(atlas.update(d.Get(),c.Get(),99,light,2,64,&Caster::draw,&caster)<0&&atlas.lookup(slot,42,2));
 atlas.begin(4,6);caster.fail=true;assert(atlas.update(d.Get(),c.Get(),42,light,3,64,&Caster::draw,&caster)<0&&!atlas.lookup(slot,42,3));
 // Production callers can record on a deferred stream without hidden immediate work.
 caster.fail=false;ComPtr<ID3D11DeviceContext> deferred;assert(SUCCEEDED(d->CreateDeferredContext(0,&deferred)));atlas.begin(5,6);slot=atlas.update(d.Get(),deferred.Get(),42,light,4,64,&Caster::draw,&caster);assert(slot>=0);ComPtr<ID3D11CommandList> list;assert(SUCCEEDED(deferred->FinishCommandList(FALSE,&list)));c->ExecuteCommandList(list.Get(),TRUE);assert(center(4)<1&&center(5)==1);
 puts("PASS local shadows: world-space spot/cube projections, actual GPU caster occlusion including off-screen geometry, atomic cube publication, destruction invalidation, budgets, cache reuse, failure rejection and deferred-stream rendering");
}
