#define NOMINMAX
#include <windows.h>
#include <d3dcompiler.h>
#include <cassert>
#include "../src/vr_cone_trace.h"
int main(){using namespace vrconetrace;ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;D3D_FEATURE_LEVEL feature;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,&feature,&c)));
 const char code[]="cbuffer C:register(b0){float4 p;}float4 VS(float4 v:POSITION):SV_POSITION{return v+p;}";ComPtr<ID3DBlob> blob;assert(SUCCEEDED(D3DCompile(code,sizeof(code),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&blob,nullptr)));assert(!kind(blob->GetBufferPointer(),blob->GetBufferSize()));ComPtr<ID3D11VertexShader> vs;assert(SUCCEEDED(d->CreateVertexShader(blob->GetBufferPointer(),blob->GetBufferSize(),nullptr,&vs)));unsigned k=2;vs->SetPrivateData(shaderTag,4,&k);
 float values[64];for(int i=0;i<64;++i)values[i]=float(i);D3D11_BUFFER_DESC desc{};desc.ByteWidth=sizeof(values);desc.Usage=D3D11_USAGE_DEFAULT;desc.BindFlags=D3D11_BIND_CONSTANT_BUFFER;D3D11_SUBRESOURCE_DATA initial{values};ComPtr<ID3D11Buffer> buffer;assert(SUCCEEDED(d->CreateBuffer(&desc,&initial,&buffer)));
 ComPtr<ID3D11DeviceContext> deferred;assert(SUCCEEDED(d->CreateDeferredContext(0,&deferred)));deferred->VSSetShader(vs.Get(),nullptr,0);ID3D11Buffer* b=buffer.Get();deferred->VSSetConstantBuffers(0,1,&b);deferred->VSSetConstantBuffers(6,1,&b);eye=0;active=false;draw(deferred.Get());assert(pending.empty());active=true;deadline=GetTickCount()+10000;nextDraw=0;draw(deferred.Get());assert(pending.size()==1);ComPtr<ID3D11Buffer> after;deferred->VSGetConstantBuffers(0,1,&after);assert(after.Get()==buffer.Get());ComPtr<ID3D11VertexShader> shader;deferred->VSGetShader(&shader,nullptr,nullptr);assert(shader.Get()==vs.Get());ComPtr<ID3D11CommandList> list;assert(SUCCEEDED(deferred->FinishCommandList(FALSE,&list)));c->ExecuteCommandList(list.Get(),FALSE);c->Flush();
 float readback[64]{};bool done=false;for(int i=0;i<1000&&!done;++i){done=read(c.Get(),pending[0].common,readback,64);if(!done)Sleep(1);}assert(done&&!memcmp(readback,values,sizeof(values)));
 present(c.Get());assert(pending.empty()&&completed==1);active=false;eye=-1;DeleteFileW(L"RFGRVR-Cone-Trace.csv");puts("PASS bounded native-cone trace: exact shader classification, deferred GPU constant snapshots, constant offsets, unchanged bindings and no inactive capture");
}
