#define NOMINMAX
#include "../src/modern_height_catalog.h"
#include <cassert>
using Microsoft::WRL::ComPtr;
int main(){
 wchar_t root[MAX_PATH],path[MAX_PATH];GetTempPathW(MAX_PATH,root);GetTempFileNameW(root,L"rgh",0,path);
 unsigned char normal[32]{};unsigned char hash[32];assert(modernheight::sha256(normal,sizeof(normal),hash));
 auto fixture=[&](uint16_t value){FILE* f=nullptr;assert(!_wfopen_s(&f,path,L"wb"));fwrite("RFGRHGT\0",1,8,f);uint32_t header[]={1,1};fwrite(header,4,2,f);fwrite(hash,1,32,f);uint32_t shape[]={8,8,8,8};fwrite(shape,4,4,f);uint64_t bytes=128;fwrite(&bytes,8,1,f);for(unsigned i=0;i<64;++i)fwrite(&value,2,1,f);fclose(f);};fixture(0x3800);
 ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));
 {modernheight::Catalogue catalogue;assert(catalogue.load(path));D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=8;desc.MipLevels=desc.ArraySize=desc.SampleDesc.Count=1;desc.Format=DXGI_FORMAT_BC1_UNORM;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;D3D11_SUBRESOURCE_DATA input{normal,16,0};ComPtr<ID3D11Texture2D> source;assert(SUCCEEDED(d->CreateTexture2D(&desc,&input,&source)));assert(catalogue.attach(d.Get(),source.Get(),desc,&input));assert(modernheight::resident==170);
  auto owner=modernheight::attachment(source.Get());assert(owner&&owner->view);ComPtr<ID3D11Resource> resource;owner->view->GetResource(&resource);ComPtr<ID3D11Texture2D> height;assert(SUCCEEDED(resource.As(&height)));D3D11_TEXTURE2D_DESC hd{};height->GetDesc(&hd);assert(hd.Width==8&&hd.Height==8&&hd.MipLevels==4&&hd.Format==DXGI_FORMAT_R16_FLOAT);
  hd.BindFlags=0;hd.Usage=D3D11_USAGE_STAGING;hd.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> read;assert(SUCCEEDED(d->CreateTexture2D(&hd,nullptr,&read)));c->CopyResource(read.Get(),height.Get());D3D11_MAPPED_SUBRESOURCE pixels{};assert(SUCCEEDED(c->Map(read.Get(),0,D3D11_MAP_READ,0,&pixels)));assert(*(uint16_t*)pixels.pData==0x3800);c->Unmap(read.Get(),0);assert(SUCCEEDED(c->Map(read.Get(),3,D3D11_MAP_READ,0,&pixels)));assert(*(uint16_t*)pixels.pData==0x3800);c->Unmap(read.Get(),3);
  ComPtr<ID3D11ShaderResourceView> view;assert(SUCCEEDED(d->CreateShaderResourceView(source.Get(),nullptr,&view)));modernheight::tagView(source.Get(),view.Get());assert(modernheight::attachment(view.Get()).Get()==owner.Get());
  normal[0]=1;assert(!catalogue.attach(d.Get(),source.Get(),desc,&input));normal[0]=0;view.Reset();source.Reset();owner.Reset();assert(modernheight::resident==0);
  unsigned char padded[64]{};input.pSysMem=padded;input.SysMemPitch=32;assert(SUCCEEDED(d->CreateTexture2D(&desc,&input,&source)));assert(catalogue.attach(d.Get(),source.Get(),desc,&input));source.Reset();assert(modernheight::resident==0);
 }
 fixture(0x7c00);{modernheight::Catalogue catalogue;assert(catalogue.load(path));D3D11_TEXTURE2D_DESC desc{};desc.Width=desc.Height=8;desc.MipLevels=desc.ArraySize=desc.SampleDesc.Count=1;desc.Format=DXGI_FORMAT_BC1_UNORM;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;D3D11_SUBRESOURCE_DATA input{normal,16,0};ComPtr<ID3D11Texture2D> source;assert(SUCCEEDED(d->CreateTexture2D(&desc,&input,&source)));assert(!catalogue.attach(d.Get(),source.Get(),desc,&input));assert(modernheight::resident==0);}
 DeleteFileW(path);puts("PASS: exact normal-content matching, padded uploads, real R16 height pixels, texture/view attachment lifetime, bounded ownership and nonfinite-height rejection");
}
