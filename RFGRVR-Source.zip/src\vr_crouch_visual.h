#pragma once
#include <algorithm>
#include <cmath>
// Smooth only the owned avatar pose; headset/controller tracking is unfiltered.
struct RFGRVRCrouchVisual {
 float offset=0;bool ready=false,active=false;
 void reset(){*this={};}
 float update(float desired,float nativeOffset,float dt,bool allowed,bool requested,bool physical=false){
  if(!std::isfinite(desired)||!std::isfinite(nativeOffset)){reset();return 0;}
  if(!allowed){reset();offset=(std::clamp)(nativeOffset,-1.05f,0.f);ready=true;return offset;}
  desired=(std::clamp)(desired,-1.05f,0.f);if(!ready){offset=(std::clamp)(nativeOffset,-1.05f,0.f);ready=true;}
  if(!requested&&!active){offset=(std::clamp)(nativeOffset,-1.05f,0.f);return offset;}
  if(!std::isfinite(dt)||dt<0)dt=0;dt=(std::min)(dt,.05f);
  bool returning=desired>offset;float time=returning?.10f:.065f;bool wasActive=active;
  offset+=(desired-offset)*(1-std::exp(-dt/time));
  active=requested||(physical?(fabsf(offset)>.002f||(wasActive&&fabsf(nativeOffset-offset)>.04f)):fabsf(offset-nativeOffset)>.002f);return offset;
 }
};

