#pragma once
#include <windows.h>
#include <cstdint>
// Published only after the producer creates its keyed-mutex shared texture.
static constexpr wchar_t RFGR_GPU_MAP[] = L"Local\\RFGRVR_GPU_Shared_v1";
static constexpr uint32_t RFGR_GPU_MAGIC = 0x52564750; // RVGP
struct alignas(8) RFGRGpuShared {
    uint32_t magic;
    uint32_t version;
    volatile LONG ready;
    uint32_t width;
    uint32_t height;
    uint32_t format;
    uint64_t legacyShareHandle;
    volatile LONG frames;
    volatile LONG acknowledged;
};
static_assert(sizeof(RFGRGpuShared)==40,"shared layout mismatch");
