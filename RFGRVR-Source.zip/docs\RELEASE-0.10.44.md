# 0.10.44 validation and live evidence

## Firing/body
The installed run recorded 600 samples and 83 distinct shot updates. State/stance stayed0/0; all600 samples had the physical crouch fitter active and neutral torso weight0. Physical drop ranged about1.1–6.8cm. The animation eye X ranged−.418..+.381m and Z−.217..+.462m in that capture. Native shooting transforms were entering the upper chain while the partial physical-height fitter bypassed upright stabilization. The candidate reconstructs that partial torso from its calibrated shape at the blended height and applies the same explicit movement lean to torso/arms. Native fingers remain sampled separately. Only native crouch stances1/4 select the raw crouch animation path; airborne/landing sampling remains intact. This addresses the measured standing/partial-lean path; live firing verification remains required.

## View and cadence audit
Runtime predicted period6.9444ms confirms144Hz. The active XR loop sampled around143–144 frames/s, with about35–39 fresh stereo pairs/s in this scene. Re-submission/reprojection of cached images is not144 newly rendered frames/s. Actual source textures were3328×3472 per eye, measured-native mode3. The desktop reuses the right eye. Native mono publishing is already bypassed while native stereo owns the view; no third full-resolution gameplay view is exported each frame.

Headset-derived frusta/culling are used, with a conservative centered source and small coverage margin needed by native screen-space lighting. This is not an exact lens-shaped hidden-area mask. Shadow passes and active scope/APC cameras have legitimate additional views; scopes remain focus/setup-gated and live APC feeds driver-seat-gated. No resolution/FOV/quality was lowered in this patch.

The new small XR clock/event channel is published after fresh tracking. Outer rendering consumes one frame credit before renderer work and before either eye mutex is acquired. It follows the runtime period rather than a hardcodedHz. A stopped/unavailable clock falls back without an indefinite wait; no native scene pass is skipped or re-entered. Tests cover event wake, timeout, render suppression, invalid period and refresh changes20/90/144Hz. Headset transfer/submission remains owned by xrWaitFrame.

## Gloves
Live player meshes report triangle-strip topology5, which the old triangle-list-only guard rejected. Main mesh material starts0/5549/6694/7735 include odd offsets, so strip winding must reset at each material boundary. The private filtered index buffer retains the original size, topology and draw ranges, using restart cuts and degenerate prefixes. Exhaustive vertex-selection masks verify that resulting triangles are correctly wound subsets of original triangles. Source buffers/NPCs are not edited. The live rig has22 glove joints; its original Mason mesh has1029/2703 vertices in the hand region. Final headset visibility still needs checking.

## Reload feedback
Hip bounds expand from |X|.08–.50m/Y.55–1.15m/|Z|<.35m to |X|.05–.65m/Y.40–1.25m/|Z|<.50m in calibrated player space. Fetch readiness requires a removed magazine (or partial rocket capacity), reserve ammo, no held magazine and no active seating/placement. A70ms left-hand hint is emitted on entering that ready zone. A separate hint channel is mixed with native rumble using maximum amplitude, respecting the vibration setting; it does not overwrite firing vibration. Tests cover expanded-area fetch, single entry pulse, leaving/re-entering and separate rumble channels.

## Validation
Both release builds,27 native test executables and managed installer/updater/desktop checks pass. Built Standard-mode proxy loads and creates native DirectInput without VR startup. Installation has not yet occurred. Saved head pivots, eye/scale offsets, grips, vehicle/APC placements and controls are preserved. Live body, gloves, haptic and pacing behavior remains unverified.
