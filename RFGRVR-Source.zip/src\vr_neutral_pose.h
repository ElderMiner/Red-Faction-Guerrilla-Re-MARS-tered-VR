#pragma once
#include "vr_arm_math.h"
struct RFGRVRNeutralPose {
 vrarm::V previous{};bool ready=false;float quiet=0,weight=0;
 void reset(){ready=false;quiet=weight=0;}
 float update(vrarm::V position,float seconds,bool allowed){
  if(!vrarm::finite(position)||!std::isfinite(seconds)||seconds<=0)return weight;
  if(seconds>.05f)seconds=.05f;
  previous=position;ready=true;quiet=allowed?quiet+seconds:0;
  // VR owns upright body facing continuously, including walking. Root
  // translation jitter must never hand it back to the native diagonal stance.
  float target=allowed?1.f:0.f,step=seconds*5;
  if(weight<target)weight=(weight+step<target)?weight+step:target;
  else weight=(weight-step>target)?weight-step:target;
  return weight;
 }
};
inline vrarm::Pose RFGRVR_NeutralBone(const vrarm::Pose& bone,const vrarm::Pose& root,float weight,vrarm::M desired={{1,0,0},{0,1,0},{0,0,1}}){
 using namespace vrarm;if(weight<=0||!valid(root.b)||!valid(bone.b))return bone;if(weight>1)weight=1;
 // Orthonormal blend keeps skin matrices rigid through the idle transition.
 M target;target.r=unit(add(mul(root.b.r,1-weight),mul(desired.r,weight)));
 V up=add(mul(root.b.u,1-weight),mul(desired.u,weight));target.u=unit(sub(up,mul(target.r,dot(up,target.r))),{0,1,0});target.f=unit(cross(target.r,target.u),{0,0,1});
 return {compose(target,relative(root.b,bone.b)),add(root.p,world(target,local(root.b,sub(bone.p,root.p))))};
}

// Authored neutral skin pose. Inverse bind translations are negated and the
// bind mesh itself defines the floor; no captured gameplay stance is reused.
inline vrarm::Pose RFGRVR_IdleLegBind(vrarm::V inverseBind,vrarm::M facing){return {facing,vrarm::world(facing,vrarm::mul(inverseBind,-1))};}
