#pragma once
#include <cmath>
struct RFGRVRControllerCoast {bool active=false,ready=false;float x=0,z=0,quiet=0;
 bool update(bool input,float px,float pz,float dt){float speed=ready&&dt>.0001f?std::hypot(px-x,pz-z)/dt:0;ready=true;x=px;z=pz;if(input){active=true;quiet=0;}else if(active){if(speed>.04f)quiet=0;else if(dt>0&&dt<.25f)quiet+=dt;if(quiet>.15f)active=false;}return active;}
};
