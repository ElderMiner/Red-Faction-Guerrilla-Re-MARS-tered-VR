#include "../src/vr_body_height.h"
#include <cassert>
#include <initializer_list>
using namespace vrarm;
int main(){constexpr unsigned n=15;M identity{{1,0,0},{0,1,0},{0,0,1}};
 V positions[n]={{0,.95f,0},{0,.95f,0},{0,1,0},{0,1.5f,0},{0,1.6f,0},{-.1f,.93f,0},{-.1f,.5f,.05f},{-.1f,.05f,.03f},{-.1f,.03f,.18f},{.1f,.93f,0},{.1f,.5f,.05f},{.1f,.05f,.03f},{.1f,.03f,.18f},{-.4f,1.4f,.3f},{.4f,1.4f,.3f}};
 int parents[n]={-1,0,1,2,3,1,5,6,7,1,9,10,11,2,2};bool tracked[n]{};tracked[13]=tracked[14]=true;
 RFGRVRBodyChain chain;chain.root=0;chain.pelvis=1;chain.spine=2;chain.head=4;chain.thigh[0]=5;chain.calf[0]=6;chain.foot[0]=7;chain.thigh[1]=9;chain.calf[1]=10;chain.foot[1]=11;
 for(float offset:{-.55f,-1.0f,.05f}){Pose pose[n];for(unsigned i=0;i<n;++i)pose[i]={identity,positions[i]};
  assert(RFGRVR_FitBodyHeight(pose,n,parents,chain,tracked,offset));assert(fabsf(pose[4].p.y-(1.6f+offset))<.00001f);
  for(int i:{7,8,11,12,13,14})assert(length(sub(pose[i].p,positions[i]))<.00001f);
  assert(pose[1].p.y>.3f&&pose[2].p.y>=pose[1].p.y);for(auto& p:pose)assert(valid(p.b)&&finite(p.p));
 }
 // Native crouch animation may already lower the torso. Absolute calibrated
 // head/pelvis goals must not add that lowering a second time.
 for(float nativeDrop:{0.f,-.25f,-.5f})for(float trackedDrop:{0.f,-.3f,-.7f}){
  Pose pose[n];for(unsigned i=0;i<n;++i){pose[i]={identity,positions[i]};if(i<=6||i==9||i==10)pose[i].p.y+=nativeDrop;}
  float pelvisGoal=.95f+trackedDrop*.65f;
  assert(RFGRVR_FitBodyHeight(pose,n,parents,chain,tracked,trackedDrop-nativeDrop,pelvisGoal-pose[1].p.y)||(nativeDrop==0&&trackedDrop==0));
  assert(fabsf(pose[4].p.y-(1.6f+trackedDrop))<.00001f);assert(fabsf(pose[1].p.y-pelvisGoal)<.00001f);
  for(int j:{7,8,11,12,13,14})assert(length(sub(pose[j].p,positions[j]))<.00001f);
 }

 // Gameplay torso fitting must leave authored crouch legs byte-for-byte
 // unchanged. Even noisy/offset feet cannot affect the fitted eye height.
 for(float noise:{-.1f,0.f,.15f}){Pose pose[n],before[n];for(unsigned i=0;i<n;++i)pose[i]={identity,positions[i]};
  for(int i:{5,6,7,8,9,10,11,12})pose[i].p.y+=noise;
  for(unsigned i=0;i<n;++i)before[i]=pose[i];
  assert(RFGRVR_FitBodyHeight(pose,n,parents,chain,tracked,-.4f,-.26f,false));
  assert(fabsf(pose[4].p.y-1.2f)<.00001f);
  for(int i:{0,1,5,6,7,8,9,10,11,12}){assert(length(sub(pose[i].p,before[i].p))<.00001f);assert(dot(pose[i].b.u,before[i].b.u)>.99999f);}
 }
}
