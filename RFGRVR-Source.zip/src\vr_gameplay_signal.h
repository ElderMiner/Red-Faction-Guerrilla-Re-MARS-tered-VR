#pragma once
#include <cstdint>
// Head updates stop briefly during stalls and focus transitions. A short gap
// is not evidence that the game entered a menu or needs new render targets.
struct RFGRVRGameplaySignal {
 bool active=false;uint64_t lastRecent=0;
 bool update(bool recent,uint64_t now){
  if(recent){lastRecent=now;active=true;}
  else if(active&&(now<lastRecent||now-lastRecent>=1500))active=false;
  return active;
 }
};
