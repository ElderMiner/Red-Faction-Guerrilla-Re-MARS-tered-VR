$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
& (Join-Path $PSScriptRoot "BUILD-SHADERS.ps1")
$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$installation=& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
$vc=Join-Path $installation 'VC/Auxiliary/Build/vcvarsall.bat'
New-Item -ItemType Directory -Force build-check | Out-Null
$tests=@('test_calibration','test_hybrid_policy','test_modern_lighting_toggle','test_modern_geometry_capture','test_modern_wave_scene','test_modern_wave_transport','test_modern_optics','test_modern_relief','test_modern_height_catalog','test_modern_cube_capture','test_modern_cascades','test_modern_local_shadows','test_modern_indirect','test_modern_reflections','test_modern_policy','test_modern_sky','test_modern_sky_material','test_modern_graph','test_modern_grid_gpu','test_modern_generated','test_modern_runtime','test_modern_hdr','test_modern_shadow_maps','test_modern_shadow_capture','test_modern_surface','test_modern_transport','test_modern_lighting','test_handgun_recoil','test_headlight_cones','test_cone_trace','test_native_night_lights','test_night_lighting','test_night_scene_gpu','test_human_visibility_trace','test_orbital_billboard','test_popup_resources','test_stereo_early_release','test_menu_upscale','test_menu_scene','test_menu_copy','test_dlc','test_body_heading','test_two_hand','test_native_weapon_physics','test_native_scene','test_native_head','test_native_arms','test_weapon_scope','test_apc_cameras','test_context_runtime','test_deferred_probe','test_vr_user_settings','test_vr_gamepad_input','test_controller_cloth_visibility','test_native_reload','test_desktop_mirror','test_camera_input','test_boot_avatar','test_head_motion','test_landing_eye','test_crouch_visual','test_effect_view_cache','test_memory_cache','test_room_motion','test_room_drive','test_weapon_motion','test_launch_mode','test_frame_clock','test_weapon_selector','test_weapon_laser','test_weapon_hud_pose','test_wrist_map_gpu','test_corona_depth','test_bloom_view_cache','test_hud_layout')
$lines=@('@echo off',('cd /d "'+$PSScriptRoot+'"'),('call "'+$vc+'" x86 >nul'))
foreach($test in $tests){$lines+=('cl /nologo /EHsc /std:c++17 /O2 /Ithird_party\include tests\'+$test+'.cpp /Fe:build-check\'+$test+'.exe /Fo:build-check\'+$test+'.obj /link vendor\libMinHook.x86.lib user32.lib gdi32.lib d3d11.lib dxgi.lib d3dcompiler.lib');$lines+='if errorlevel 1 exit /b 1'}
Set-Content build-check/release-tests.cmd ($lines -join "`r`n");cmd /c build-check\release-tests.cmd;if($LASTEXITCODE -ne 0){throw 'Test compilation failed'}
foreach($test in $tests){if($test -eq 'test_deferred_probe'){& ('.\build-check\'+$test+'.exe') build-check/release-deferred}else{& ('.\build-check\'+$test+'.exe')};if($LASTEXITCODE -ne 0){throw ($test+' failed')}}
$windowTest=Start-Process -FilePath (Join-Path $PSScriptRoot 'build-check/test_vr_user_settings.exe') -ArgumentList @('--hidden-window') -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden
if(!$windowTest.WaitForExit(10000)){throw 'Hidden-start desktop settings test timed out'};if($windowTest.ExitCode -ne 0){throw 'Hidden-start desktop settings window stayed hidden'}
Get-Content build-check/desktop-window-hidden-start.txt
$idleTest=Start-Process -FilePath (Join-Path $PSScriptRoot 'build-check/test_vr_user_settings.exe') -ArgumentList @('--headset-idle') -WorkingDirectory $PSScriptRoot -PassThru -WindowStyle Hidden
if(!$idleTest.WaitForExit(10000)){throw 'Headset-idle desktop settings test timed out'};if($idleTest.ExitCode -ne 0){throw 'Headset-idle desktop settings failed'}
$csc=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
& $csc /nologo /target:winexe /out:build-check\Setup-test.exe /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll distribution\Common.cs distribution\Setup.cs distribution\Tests.cs
if($LASTEXITCODE -ne 0){throw 'Installer tests failed to compile'}
$p=Start-Process -FilePath (Join-Path $PSScriptRoot 'build-check/Setup-test.exe') -ArgumentList @('--self-test',('"'+(Join-Path $PSScriptRoot 'build-check')+'"')) -PassThru -WindowStyle Hidden
if(!$p.WaitForExit(30000)){throw 'Installer tests timed out'};if($p.ExitCode -ne 0){throw 'Installer tests failed'}
Get-Content build-check/installer-tests.txt

& $csc /nologo /target:exe /main:RFGRVR.UpdateTests /out:build-check\Update-tests.exe /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll distribution\Common.cs distribution\Launcher.cs distribution\GameAssets.cs distribution\UpdateTests.cs
if($LASTEXITCODE -ne 0){throw 'Updater tests failed to compile'}
& ./build-check/Update-tests.exe
if($LASTEXITCODE -ne 0){throw 'Updater tests failed'}
Get-Content build-check/update-tests.txt















