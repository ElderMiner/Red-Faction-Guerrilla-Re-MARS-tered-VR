#pragma once
// Local-player metadata only; mission/story records and inventory slots remain intact.
namespace GearUnlock {
using Mark=bool(__cdecl*)(void*,bool);using Grant=void(__cdecl*)(void*,bool);
inline Mark mark=nullptr;inline Grant grant=nullptr;
inline bool listed(unsigned id){unsigned n=word(base,0x1261edc);void* data=(void*)(uintptr_t)word(base,0x1261ed4);if(n>256||(n&&!memory(data,n*8)))return false;for(unsigned j=0;j<n;++j)if(word(data,j*8)==id&&*((unsigned char*)data+j*8+4))return true;return false;}
inline unsigned arsenal(){
 if(!mark||!grant)return 0;unsigned count=word(base,0x3482c94);void* definitions=(void*)(uintptr_t)word(base,0x3482c9c);if(!count||count>1024||!memory(definitions,count*0x230))return 0;
 unsigned changed=0;for(unsigned i=0;i<count;++i){auto* info=(char*)definitions+i*0x230;unsigned flags=word(info,0xc),kind=word(info,0x10);if(kind==7||kind>=17||(flags&0x8100)||!word(info,0x18))continue;
  unsigned n=word(base,0x1261edc);void* data=(void*)(uintptr_t)word(base,0x1261ed4);if(n>256||(n&&!memory(data,n*8)))return changed;if(listed(word(info,8)))continue;
  // Exactly the native add_weapon_to_arsenal script action: mark an existing
  // entry or append it through the engine-owned list and persistence path.
  if(!mark(info,true))grant(info,true);if(listed(word(info,8)))++changed;
 }return changed;
}
inline void install(){const unsigned char markSig[]={0x56,0x8b,0x74,0x24,0x08,0x85,0xf6};const unsigned char grantSig[]={0x83,0xec,8,0x56,0x8b,0x74,0x24,0x10};if(!memcmp(base+0x45b3b0,markSig,sizeof(markSig))&&!memcmp(base+0x477200,grantSig,sizeof(grantSig))){mark=(Mark)(base+0x45b3b0);grant=(Grant)(base+0x477200);}}
struct Entry {unsigned id,levels;};
inline constexpr Entry entries[]={{0,3},
{1,11},
{2,3},
{3,3},
{4,2},
{5,2},
{6,3},
{7,2},
{8,2},
{9,3},
{10,2},
{11,3},
{12,2},
{13,2},
{14,3},
{15,3},
{16,2},
{17,2},
{18,2},
{19,2},
{20,2},
{21,2},
{25,2},
{26,3},
{28,2},
{29,2},
{30,2},
{31,2},
{39,2},
{40,2},
{41,2},
{42,2},
{43,2},
{44,2},
{45,2},
{46,2},
{47,2},
{48,2},
{49,2},
{50,2},
{51,2},
{52,2},
{53,2},
{54,2},
{55,2},
{56,2},
{57,2},
{58,2},
{59,2},
{60,2},
{61,2}};
inline unsigned apply(void* player){
 auto* metadata=(unsigned char*)player+0x2978;
 if(!memory(metadata,24+128*8)||word(metadata,0)!=(unsigned)(uintptr_t)(base+0xf11ee0))return 0;
 // Validate the entire supported layout before making any change.
 for(auto e:entries){auto* p=metadata+24+e.id*8;unsigned mask=(1u<<e.levels)-1;if(p[1]||p[0]>=e.levels)return 0;for(unsigned o:{2u,4u,6u}){unsigned short bits=0;memcpy(&bits,p+o,2);if(bits&~mask)return 0;}}
 unsigned changed=0;for(auto e:entries){auto* p=metadata+24+e.id*8;unsigned short mask=(1u<<e.levels)-1;bool edited=p[0]!=e.levels-1;p[0]=(unsigned char)(e.levels-1);for(unsigned o:{2u,4u,6u}){unsigned short before=0;memcpy(&before,p+o,2);unsigned short after=before|mask;edited|=after!=before;memcpy(p+o,&after,2);}changed+=edited?1:0;}return changed;
}
inline void update(void* player){static DWORD last=0;DWORD now=GetTickCount();if(DWORD(now-last)<2000)return;last=now;if(word(player,0x2f4)>2||word(player,0x33c)||word((char*)player+0x2978,0)!=(unsigned)(uintptr_t)(base+0xf11ee0))return;unsigned n=apply(player),weapons=arsenal();if(n||weapons){char message[160];sprintf_s(message,"Local player gear unlocked: %u purchase records, %u native arsenal additions; mission state unchanged.",n,weapons);log(message);}}
}
