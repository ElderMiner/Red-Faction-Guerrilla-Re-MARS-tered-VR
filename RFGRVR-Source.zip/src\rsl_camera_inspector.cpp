extern "C" void RFGRVR_EngineProbe_CameraBegin(void*,void*);
extern "C" void RFGRVR_EngineProbe_CameraEnd(void*);
extern "C" void RFGRVR_Temporal_CameraBegin(void*);
extern "C" bool RFGRVR_Temporal_IsEnabled();
extern "C" void RFGRVR_EngineProbe_Install();
extern "C" void RFGRVR_CameraDiff_Begin(void*);
extern "C" void RFGRVR_CameraDiff_End(void*);
// Instrument the verified RSL rl_camera::render_begin entry in the supplied x86 rfg.exe.
// No camera writes. No global DXGI hook modifications.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstring>
#include <atomic>
#include <cmath>
#include "../vendor/MinHook.h"

extern "C" void RFGRVR_StereoTrace_CameraBegin(void*,void*);
extern "C" bool RFGRVR_HeadCam_GetPosition(float out[3]);
extern "C" void RFGRVR_HeadCam_RecordApplied();
extern "C" void RFGRVR_HeadCam_RecordRejected();
extern "C" bool RFGRVR_HeadCam_Install();
extern "C" void RFGRVR_HeadCam_Enable(bool);
extern "C" bool RFGRVR_HeadCam_Enabled();
extern "C" void RFGRVR_HeadCam_Forward(int);
extern "C" void RFGRVR_HeadCam_Height(int);
extern "C" int RFGRVR_HeadCam_ForwardValue();
extern "C" int RFGRVR_HeadCam_HeightValue();
extern "C" unsigned RFGRVR_HeadCam_Updates();
extern "C" unsigned RFGRVR_HeadCam_Failures();
namespace {
constexpr DWORD RVA = 0x137660;
constexpr unsigned MAGIC = 0x434D4652; // RFMC
constexpr unsigned VERSION = 1;
constexpr size_t CAPTURE = 1024;
// Observed bytes from the user's rfg.exe at RVA 0x137660 (mapped executable).
const unsigned char expected[] = {0x8b,0x44,0x24,0x04,0x8b,0x90,0x78,0x04,0x00,0x00,0x89,0x4a,0x70};
#pragma pack(push,4)
struct Telemetry {
 unsigned magic,version,status,processId;
 volatile LONG sequence;
 unsigned long long callbackCount;
 unsigned cameraPtr, rendererPtr, cameraChanges;
 unsigned lastTick, bytesValid;
 unsigned char cameraData[CAPTURE];
};
#pragma pack(pop)
using Fn = void (__fastcall*)(void*,void*,void*);
Fn original=nullptr;
HANDLE mapping=nullptr;
Telemetry* mem=nullptr;
std::atomic<unsigned long long> calls{0};
std::atomic<unsigned> lastCamera{0};
std::atomic<unsigned> changes{0};
// Reversible, opt-in first-person camera probe. Writes only xyz at +0x2C
// within the currently rendering camera and restores those same bytes immediately
// after the original render_begin returns. No persistent patching of game code.
std::atomic<bool> fpEnabled{false};
std::atomic<int> fpForwardCm{180}; // adjustable 0.0 to 5.0 scene units
std::atomic<int> fpUpCm{20};
std::atomic<unsigned> fpAttempts{0},fpApplied{0},fpRejected{0};
struct V3 {float x,y,z;};
static bool safeWritable(void* p,size_t n){
 MEMORY_BASIC_INFORMATION mbi{};
 if(!VirtualQuery(p,&mbi,sizeof(mbi)) || mbi.State!=MEM_COMMIT)return false;
 if(mbi.Protect&(PAGE_GUARD|PAGE_NOACCESS))return false;
 const DWORD protection=mbi.Protect&0xff;
 if(protection!=PAGE_READWRITE && protection!=PAGE_EXECUTE_READWRITE && protection!=PAGE_WRITECOPY && protection!=PAGE_EXECUTE_WRITECOPY)return false;
 const uintptr_t address=(uintptr_t)p,begin=(uintptr_t)mbi.BaseAddress;
 return address>=begin && n<=mbi.RegionSize && address-begin<=mbi.RegionSize-n;
}
static bool validTransform(const float* m){
 const float* a=m;
 for(int i=0;i<16;i++)if(!std::isfinite(a[i]))return false;
 if(std::fabs(a[15]-1.f)>.02f)return false;
 if(std::fabs(a[3])>.02f||std::fabs(a[7])>.02f||std::fabs(a[11])>.02f)return false;
 // Camera transform has orthonormal 3x3 rotation.
 for(int k=0;k<3;k++){
   float length=0;for(int j=0;j<3;j++)length+=a[k*4+j]*a[k*4+j];
   if(std::fabs(length-1.f)>.06f)return false;
 }
 return true;
}
static void __fastcall OnRenderBegin(void* camera,void* edx,void* renderer){
  const auto count=++calls;
  if(mem && camera && (count%3==0)) { // throttle; render thread remains nonblocking
   const auto addr=static_cast<unsigned>(reinterpret_cast<uintptr_t>(camera));
   if(lastCamera.exchange(addr)!=addr)++changes;
   InterlockedIncrement(&mem->sequence);
   MemoryBarrier();
   mem->cameraPtr=addr;
   mem->rendererPtr=static_cast<unsigned>(reinterpret_cast<uintptr_t>(renderer));
   mem->cameraChanges=changes.load();mem->callbackCount=count;
   mem->lastTick=GetTickCount();
   mem->bytesValid=0;
   // Avoid SEH in C++ functions with destructors. Validate readable committed regions first.
   MEMORY_BASIC_INFORMATION mbi={};
   if(VirtualQuery(camera,&mbi,sizeof(mbi)) && mbi.State==MEM_COMMIT && !(mbi.Protect&(PAGE_NOACCESS|PAGE_GUARD))){
      const uintptr_t end=reinterpret_cast<uintptr_t>(mbi.BaseAddress)+mbi.RegionSize;
      const uintptr_t start=reinterpret_cast<uintptr_t>(camera);
      const size_t len=(end>start)?(end-start<CAPTURE?end-start:CAPTURE):0;
      if(len){ memcpy(mem->cameraData,camera,len);mem->bytesValid=static_cast<unsigned>(len);}
   }
   MemoryBarrier();InterlockedIncrement(&mem->sequence);
  }
  // Engine-level rfg_camera::real_pos is now supplied by an RSL-derived player-head hook.
  // Run immediately before the camera render preparation consumes camera state.
  RFGRVR_StereoTrace_CameraBegin(camera,renderer);
  // The correlation run identifies the real render_begin camera as distinct
  // from rotating scene/worker parameter-block pointers. Only touch THIS camera.
  // Never overlap with the temporal stereo shift: its separate restoration
  // path operates at Present, not at render_begin return.
  float savedPos[3]={}, trialPos[3]={};
  bool trialApplied=false;
  if(RFGRVR_HeadCam_Enabled() && !RFGRVR_Temporal_IsEnabled() && safeWritable((unsigned char*)camera+0x2C,12) &&
     RFGRVR_HeadCam_GetPosition(trialPos)){
   const float* candidate=trialPos;
   float existing[3]={};memcpy(existing,(unsigned char*)camera+0x2C,12);
   bool plausible=true;
   for(int i=0;i<3;i++)if(!std::isfinite(candidate[i])||!std::isfinite(existing[i])||
      std::fabs(candidate[i])>1000000.f||std::fabs(existing[i])>1000000.f)plausible=false;
   if(plausible){
    memcpy(savedPos,existing,12);
    memcpy((unsigned char*)camera+0x2C,trialPos,12);
    trialApplied=true;RFGRVR_HeadCam_RecordApplied();
   }else RFGRVR_HeadCam_RecordRejected();
  }
  // Always feed temporal stereo when F6 is active. Without this, HMD eye images stall.
  // With F6 active, the integrated temporal path owns head pose, orientation, and eye offsets.
  RFGRVR_Temporal_CameraBegin(camera);
  RFGRVR_CameraDiff_Begin(camera);
  RFGRVR_EngineProbe_CameraBegin(camera,renderer);
  if(original) original(camera,edx,renderer);
  // Compare-before-restore: another engine thread may have replaced the value.
  // The mod must never overwrite such newer game state.
  if(trialApplied && safeWritable((unsigned char*)camera+0x2C,12)){
   if(memcmp((unsigned char*)camera+0x2C,trialPos,12)==0)
    memcpy((unsigned char*)camera+0x2C,savedPos,12);
   else RFGRVR_HeadCam_RecordRejected();
  }
  RFGRVR_CameraDiff_End(camera);
  RFGRVR_EngineProbe_CameraEnd(camera);
}
} // namespace
extern "C" bool RFGRVR_StartRSLCameraInspector(){
 if(sizeof(void*)!=4)return false;
 HMODULE exe=GetModuleHandleW(nullptr);if(!exe)return false;
 auto base=reinterpret_cast<unsigned char*>(exe);
 auto dos=reinterpret_cast<IMAGE_DOS_HEADER*>(base);
 if(dos->e_magic!=IMAGE_DOS_SIGNATURE)return false;
 auto nt=reinterpret_cast<IMAGE_NT_HEADERS32*>(base+dos->e_lfanew);
 if(nt->Signature!=IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR32_MAGIC)return false;
 if(nt->OptionalHeader.SizeOfImage<RVA+sizeof(expected))return false;
 if(memcmp(base+RVA,expected,sizeof(expected))!=0)return false;
 // Use a PID-scoped mapping to keep multiple sessions separate.
 wchar_t name[100];wsprintfW(name,L"Local\\RFGRVR_RSL_Camera_%lu",GetCurrentProcessId());
 mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Telemetry),name);
 if(!mapping)return false;
 mem=static_cast<Telemetry*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Telemetry)));
 if(!mem)return false;
 memset(mem,0,sizeof(Telemetry));mem->magic=MAGIC;mem->version=VERSION;mem->processId=GetCurrentProcessId();
 if(MH_Initialize()!=MH_OK){mem->status=2;return false;}
 if(MH_CreateHook(base+RVA,reinterpret_cast<LPVOID>(&OnRenderBegin),reinterpret_cast<LPVOID*>(&original))!=MH_OK){mem->status=3;return false;}
 if(MH_EnableHook(base+RVA)!=MH_OK){mem->status=4;return false;}
 mem->status=1;RFGRVR_HeadCam_Install();RFGRVR_EngineProbe_Install();return true;
}

extern "C" void RFGRVR_FP_SetEnabled(bool v){RFGRVR_HeadCam_Enable(v);}
extern "C" bool RFGRVR_FP_GetEnabled(){return RFGRVR_HeadCam_Enabled();}
extern "C" void RFGRVR_FP_AdjustForward(int n){RFGRVR_HeadCam_Forward(n);}
extern "C" void RFGRVR_FP_AdjustUp(int n){RFGRVR_HeadCam_Height(n);}
extern "C" int RFGRVR_FP_GetForward(){return RFGRVR_HeadCam_ForwardValue();}
extern "C" int RFGRVR_FP_GetUp(){return RFGRVR_HeadCam_HeightValue();}
extern "C" unsigned RFGRVR_FP_GetAttempts(){return RFGRVR_HeadCam_Updates();}
extern "C" unsigned RFGRVR_FP_GetApplied(){return RFGRVR_HeadCam_Updates();}
extern "C" unsigned RFGRVR_FP_GetRejected(){return RFGRVR_HeadCam_Failures();}
