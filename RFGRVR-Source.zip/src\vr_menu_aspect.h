#pragma once
#include <windows.h>
#include <cmath>
namespace vrmenuaspect {
inline constexpr wchar_t Channel[]=L"Local\\RFGRVR_MenuAspect_v1";
struct Packet {volatile LONG sequence=0;unsigned width=0,height=0,tick=0;};
inline float ratio(unsigned width,unsigned height){return width>=320&&width<=16384&&height>=200&&height<=16384?float(width)/height:16.f/9.f;}
struct Mapping {
 HANDLE handle=nullptr;Packet* packet=nullptr;DWORD retry=0;
 ~Mapping(){if(packet)UnmapViewOfFile(packet);if(handle)CloseHandle(handle);}
 bool attach(bool write){if(packet)return true;DWORD now=GetTickCount();if(retry&&DWORD(now-retry)<1000)return false;retry=now;
  handle=write?CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Packet),Channel):OpenFileMappingW(FILE_MAP_READ,FALSE,Channel);
  if(!handle)return false;packet=(Packet*)MapViewOfFile(handle,write?FILE_MAP_ALL_ACCESS:FILE_MAP_READ,0,0,sizeof(Packet));if(!packet){CloseHandle(handle);handle=nullptr;}return packet!=nullptr;}
};
inline void publish(unsigned width,unsigned height){static Mapping map;if(!map.attach(true))return;InterlockedIncrement(&map.packet->sequence);map.packet->width=width;map.packet->height=height;map.packet->tick=GetTickCount();MemoryBarrier();InterlockedIncrement(&map.packet->sequence);}
inline float current(){static Mapping map;if(!map.attach(false))return 16.f/9.f;auto* p=map.packet;LONG first=ReadAcquire(&p->sequence);if(first&1)return 16.f/9.f;unsigned w=p->width,h=p->height,t=p->tick;MemoryBarrier();if(first!=ReadAcquire(&p->sequence)||DWORD(GetTickCount()-t)>1000)return 16.f/9.f;return ratio(w,h);}
}
