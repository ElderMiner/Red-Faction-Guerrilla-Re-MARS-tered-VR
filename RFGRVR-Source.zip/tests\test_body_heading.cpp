#include "../src/vr_body_heading.h"
#include <cassert>
int main(){RFGRVRBodyHeading h;assert(h.update(0,.01f,false,false)==0);
 for(int i=0;i<100;++i)assert(h.update(1,.01f,false,false)==0);
 for(int i=0;i<100;++i)h.update(2,.01f,false,false);assert(fabsf(h.yaw-.691f)<.001f);
 float before=h.yaw;h.update(2.2f,.01f,false,true);assert(fabsf(h.yaw-before-.2f)<.001f);
 for(int i=0;i<100;++i)h.update(-2.9f,.01f,true,false);assert(fabsf(RFGRVR_WrapYaw(h.yaw+2.9f))<.001f);
 RFGRVRBodyHeading crossing;crossing.update(3.1f,.01f,false,false);crossing.update(-3.1f,.01f,false,false);assert(fabsf(crossing.yaw-3.1f)<.001f);
}
