#include "../src/vr_gamepad_math.h"
#include "../src/ipc.h"
#include <cassert>
#include <limits>
int main(){int16_t x=0,y=20000;RFGRVR_ViewRelativeMove(x,y,1.5707963268f);assert(abs(x-20000)<=1&&abs(y)<=1);x=0;y=20000;RFGRVR_ViewRelativeMove(x,y,-1.5707963268f);assert(abs(x+20000)<=1&&abs(y)<=1);x=10000;y=0;RFGRVR_ViewRelativeMove(x,y,3.141592654f);assert(abs(x+10000)<=1&&abs(y)<=1);assert(sizeof(RFGRGamepad)==12);assert(RFGRVR_Axis(2)==32767);assert(RFGRVR_Axis(-2)==-32767);assert(RFGRVR_Axis(std::numeric_limits<float>::quiet_NaN())==0);assert(RFGRVR_Trigger(2)==255);assert(RFGRVR_Trigger(-1)==0);assert(RFGRVR_FacingAxis(0)==0);assert(RFGRVR_FacingAxis(.1f)>0);assert(RFGRVR_FacingAxis(-.1f)<0);}
