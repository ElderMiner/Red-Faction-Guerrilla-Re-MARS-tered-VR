#pragma once
#include "ipc.h"
#include <cmath>
inline bool RFGRVR_CopyGripInput(const RFGRShared* source,float (&out)[2]){
 out[0]=out[1]=0;if(!source||source->version!=RFGR_PROTOCOL)return false;
 for(unsigned tries=0;tries<3;++tries){LONG seq=source->inputSequence;if(seq&1)continue;MemoryBarrier();float a=source->gripValue[0],b=source->gripValue[1];bool active=source->gamepadActive!=0;MemoryBarrier();if(seq!=source->inputSequence)continue;
  if(!active||!std::isfinite(a)||!std::isfinite(b)||a<0||a>1||b<0||b>1)return false;out[0]=a;out[1]=b;return true;}
 return false;
}
