#pragma once
#include <cstddef>
#include <cstdint>
// Shared BGRA8 feeds may copy into either matching UNORM/sRGB family member.
// Only request a swapchain format actually advertised by this XR runtime.
inline int64_t RFGRVR_APCDisplayFormat(const int64_t* formats,size_t count){for(int64_t preferred:{int64_t(91),int64_t(87)})for(size_t i=0;i<count;++i)if(formats[i]==preferred)return preferred;return 0;}
