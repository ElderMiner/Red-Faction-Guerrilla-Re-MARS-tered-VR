#include "../src/gpu_pipeline_trace.cpp"
#include <cassert>
#include "../src/vr_menu_aspect.h"
extern "C" unsigned RFGRVR_HeadCam_HeadSamples(){return 0;}
extern "C" bool RFGRVR_HeadCam_Recent(){return false;}
extern "C" void RFGRVR_Survey_Capture(bool){}
static ExecuteFn driverExecute=nullptr;static unsigned executions=0;
static void STDMETHODCALLTYPE SpyExecute(ID3D11DeviceContext* c,ID3D11CommandList* list,BOOL restore){printf("ExecuteCommandList list=%p restore=%d\n",list,restore);++executions;driverExecute(c,list,restore);}
int main(){assert(fabsf(vrmenuaspect::ratio(3328,3472)-3328.f/3472)<.00001f);assert(vrmenuaspect::ratio(0,0)==16.f/9.f);
 assert(!CaptureRecording());Event fixture[2]{};events=fixture;state=2;used=sequence=0;assert(CaptureRecording());assert(Record(22,1,3,4,0)==fixture&&fixture[0].ptr==3);state=0;assert(!Record(22,1,3,4,0));events=nullptr;
Microsoft::WRL::ComPtr<ID3D11Device> d;Microsoft::WRL::ComPtr<ID3D11DeviceContext> c;assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,nullptr,&c)));assert(RFGRVR_GPUCapture_Attach(c.Get()));driverExecute=oldExecute;oldExecute=SpyExecute;c->ClearState();printf("ClearState calls ExecuteCommandList=%u\n",executions);}
