#pragma once
#include "vr_arm_math.h"
#include <cstdint>
#include <windows.h>
#include <atomic>
#include <cstdio>
#include <cstring>
namespace vrfocus {
// Distances are physical metres, independent of calibrated world scale.
inline bool nearFace(const vrarm::Pose& head,const vrarm::Pose& grip,vrarm::V aim,bool retained){
 using namespace vrarm;
 if(!valid(head.b)||!valid(grip.b)||!finite(head.p)||!finite(grip.p)||!finite(aim)||length(aim)<.9f)return false;
 V offset=local(head.b,sub(grip.p,head.p));
 return length(offset)<(retained?.65f:.55f)&&offset.z>.03f&&offset.y>-(retained?.38f:.30f)&&fabsf(offset.x)<(retained?.35f:.28f)&&dot(unit(aim),head.b.f)>(retained?.70f:.82f);
}
// Proximity uses the tracked firing hand, never the weapon mesh/muzzle.
inline bool firingHandNearEyes(const vrarm::Pose& eyes,const vrarm::Pose& hand,bool retained,float distance=.28f){
 using namespace vrarm;if(!valid(eyes.b)||!finite(eyes.p)||!finite(hand.p))return false;
 V d=local(eyes.b,sub(hand.p,eyes.p));
 return length(d)<distance+(retained?.045f:0.f)&&d.z>-.05f;
}
inline SRWLOCK distanceLock=SRWLOCK_INIT;inline bool distancesLoaded=false;inline float distances[3]={.28f,.30f,.32f};inline char distancePath[MAX_PATH]{};
inline const char* distanceKeys[3]={"Snipers","Rifles","HandgunsHeavy"};inline std::atomic<int> distanceRequest{-1};
inline void loadDistances(){if(distancesLoaded)return;distancesLoaded=true;if(!distancePath[0]){GetModuleFileNameA(nullptr,distancePath,MAX_PATH);if(auto* s=strrchr(distancePath,92))strcpy_s(s+1,MAX_PATH-(s+1-distancePath),"RFGRVR-focus-distance.ini");}for(int i=0;i<3;++i){char b[64];GetPrivateProfileStringA("Focus",distanceKeys[i],"",b,sizeof(b),distancePath);float v=0;if(sscanf_s(b,"%f",&v)==1&&std::isfinite(v)&&v>=.08f&&v<=.8f)distances[i]=v;}}
inline float focusDistance(int group){AcquireSRWLockExclusive(&distanceLock);loadDistances();float v=distances[group<0||group>2?1:group];ReleaseSRWLockExclusive(&distanceLock);return v;}
inline bool saveDistance(int group,float v){if(group<0||group>2||!std::isfinite(v)||v<.08f||v>.8f)return false;AcquireSRWLockExclusive(&distanceLock);loadDistances();char b[64];sprintf_s(b,"%.6f",v);bool ok=WritePrivateProfileStringA("Focus",distanceKeys[group],b,distancePath)!=0;if(ok)distances[group]=v;ReleaseSRWLockExclusive(&distanceLock);return ok;}
inline int distanceGroup(const char* name,unsigned type){auto has=[&](const char* part){return name&&strstr(name,part);};if(has("sniper_rifle")||has("rail_driver"))return 0;if(type==1||has("pistol")||has("rocket")||has("rpg")||has("grinder")||has("shocker")||has("arc_welder"))return 2;return 1;}
struct DistanceCapture {int group=-1;bool released=false;void arm(int g){group=g;released=false;}bool step(float grip,float physicalDistance,float& value){if(group<0)return false;if(grip<.3f)released=true;if(!released||grip<.65f||!std::isfinite(physicalDistance)||physicalDistance<.08f||physicalDistance>.8f)return false;value=physicalDistance;released=false;return true;}};
inline DistanceCapture distanceCapture;
struct Control {
 uintptr_t player=0;bool engaged=false,owned=false;unsigned ownedState=2;
 // Returns a native zoom-state request, or -1 to leave manual focus alone.
 int update(uintptr_t identity,unsigned state,bool allowed,bool inside,unsigned target=2){
  if(player!=identity){player=identity;engaged=false;owned=false;}
  engaged=allowed&&inside;
  if(state!=ownedState)owned=false;
  if(!engaged){if(owned){owned=false;return 0;}return -1;}
  if(state==0||owned&&ownedState!=target){owned=true;ownedState=target;return int(target);}
  // Do not replace sprint, a manually selected scope, or manual fine aim.
  return -1;
 }
};
}

