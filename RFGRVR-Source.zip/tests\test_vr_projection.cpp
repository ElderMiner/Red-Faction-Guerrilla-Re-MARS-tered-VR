#include "../src/vr_eye_projection.h"
#include <cassert>
#include <cmath>
int main(){
  const float symmetric[4]={-.8f,.8f,.8f,-.8f};
  RFGRVREyeProjection p{};
  assert(RFGRVR_BuildD3DProjection(symmetric,.05f,2000.f,&p));
  assert(std::fabs(p.columnMajor[8])<1e-5f);
  assert(std::fabs(p.columnMajor[9])<1e-5f);
  assert(p.columnMajor[11]==-1.f);
  assert(p.columnMajor[10]<-1.f);
  const float asymmetric[4]={-.72f,.86f,.78f,-.82f};
  assert(RFGRVR_BuildD3DProjection(asymmetric,.05f,2000.f,&p));
  assert(std::fabs(p.columnMajor[8])>1e-3f);
  assert(std::fabs(p.columnMajor[9])>1e-3f);
  assert(!RFGRVR_BuildD3DProjection(asymmetric,0.f,2000.f,&p));
  const float reversed[4]={.8f,-.8f,.8f,-.8f};
  assert(!RFGRVR_BuildD3DProjection(reversed,.05f,2000.f,&p));
}
