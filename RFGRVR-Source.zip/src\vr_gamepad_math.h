#pragma once
#include <cmath>
#include <cstdint>
inline int16_t RFGRVR_Axis(float x){if(!std::isfinite(x))return 0;if(x>1)x=1;if(x< -1)x=-1;return int16_t(std::lround(x*32767.f));}
inline uint8_t RFGRVR_Trigger(float x){if(!std::isfinite(x)||x<0)x=0;if(x>1)x=1;return uint8_t(std::lround(x*255.f));}
inline float RFGRVR_FacingAxis(float radians){
 if(!std::isfinite(radians)||std::fabs(radians)<.006f)return 0;
 float speed=.25f+std::fabs(radians)*1.6f;if(speed>1)speed=1;return radians<0?-speed:speed;
}

inline void RFGRVR_ViewRelativeMove(int16_t& x,int16_t& y,float yaw){
 if(!std::isfinite(yaw))return;float a=x/32767.f,b=y/32767.f,c=std::cos(yaw),s=std::sin(yaw);
 x=RFGRVR_Axis(a*c+b*s);y=RFGRVR_Axis(b*c-a*s);
}
