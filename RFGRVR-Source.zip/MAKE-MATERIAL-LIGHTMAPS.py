"""Generate LOCAL reflectivity/roughness estimates from owned BC1 colour textures.
Derived game data must never be redistributed. Requires numpy and Pillow.
Brightness and spatial colour consistency are artistic estimates, not measured BRDFs.
"""
import argparse, hashlib, importlib.util, io, json, struct
from pathlib import Path
from contextlib import ExitStack
import numpy as np
from PIL import Image
spec=importlib.util.spec_from_file_location('terrain_authoring',Path(__file__).with_name('MAKE-TERRAIN-HEIGHTS.py'))
terrain=importlib.util.module_from_spec(spec);spec.loader.exec_module(terrain)
def mean(a):
    a=sum(np.roll(a,x,axis=0) for x in range(-2,3))/5
    return sum(np.roll(a,x,axis=1) for x in range(-2,3))/5
def estimate(rgb):
    srgb=np.clip(np.asarray(rgb,dtype=np.float32)/255,0,1)
    linear=np.where(srgb<=.04045,srgb/12.92,((srgb+.055)/1.055)**2.4)
    average=mean(linear);variance=np.maximum(mean(linear*linear)-average*average,0).mean(axis=2)
    luminance=linear@np.array([.2126,.7152,.0722],dtype=np.float32)
    local=average@np.array([.2126,.7152,.0722],dtype=np.float32)
    consistency=np.exp(-12*np.sqrt(variance)/(.1+local))
    reflectivity=np.clip((.15+.85*np.sqrt(luminance))*consistency,0,1)
    roughness=.25+.65*(1-consistency)
    return np.rint(np.stack((reflectivity,roughness),axis=2)*255).astype(np.uint8)
def decode(cpu,gpu,resolution):
    if cpu[:8]!=b'GEKV\x0a\0\0\0':raise ValueError('Unverified bitmap header')
    width,height,fmt=struct.unpack_from('<3H',cpu,28)
    if fmt not in (400,402) or not(4<=width<=8192 and 4<=height<=8192):raise ValueError('Only verified BC1/BC3 colour inputs are supported')
    size=((width+3)//4)*((height+3)//4)*(16 if fmt==402 else 8)
    if len(gpu)<size:raise ValueError('Incomplete bitmap')
    header=struct.pack('<7I',124,0x81007,height,width,size,0,1)+bytes(44)
    header+=struct.pack('<8I',32,4,int.from_bytes(b'DXT5' if fmt==402 else b'DXT1','little'),0,0,0,0,0)+struct.pack('<5I',0x1000,0,0,0,0)
    image=Image.open(io.BytesIO(b'DDS '+header+gpu[:size])).convert('RGB');image.thumbnail((resolution,resolution),Image.Resampling.BOX)
    return image,hashlib.sha256(gpu[:size]).hexdigest(),(width,height)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('game',type=Path);p.add_argument('output',type=Path);p.add_argument('--resolution',type=int,default=256,choices=(256,512,1024));args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    records=[];seen=set()
    with ExitStack() as stack:
        for archive in ('terr01_precache.vpp_pc','dlc01_precache.vpp_pc'):
            path=args.game/'data'/archive
            if not path.is_file():continue
            pack=terrain.Pack(stack.enter_context(path.open('rb')))
            for name in sorted(pack.entries):
                if not name.endswith('_d.cvbm_pc'):continue
                stem=name.removesuffix('.cvbm_pc')
                if Path(stem).name!=stem or ':' in stem or chr(92) in stem:raise ValueError('Unsafe bitmap name')
                try:
                    image,checksum,shape=decode(pack.get(name),pack.get(stem+'.gvbm_pc'),args.resolution)
                    if checksum in seen:continue
                    seen.add(checksum);values=estimate(image);file=checksum[:16]+'.rg8';values.tofile(args.output/file)
                    Image.fromarray(np.dstack((values,np.zeros(values.shape[:2],dtype=np.uint8)))) .save(args.output/(checksum[:16]+'.png'))
                    records.append(dict(name=stem,archive=archive,source_sha256=checksum,source_size=shape,size=image.size,file=file))
                except (ValueError,KeyError) as error:records.append(dict(name=stem,archive=archive,rejected=str(error)))
    accepted=[r for r in records if 'file' in r]
    with (args.output/'material-reflectivity.rfgo').open('wb') as bundle:
        bundle.write(struct.pack('<8sII',b'RFGRMAT\0',1,len(accepted)))
        for r in accepted:
            data=(args.output/r['file']).read_bytes();bundle.write(struct.pack('<32s4IQ',bytes.fromhex(r['source_sha256']),*r['source_size'],*r['size'],len(data)));bundle.write(data)
    (args.output/'manifest.json').write_text(json.dumps(dict(physical_measurements=False,installed=False,textures=records),indent=2))
    print('Generated',len(accepted),'local reflectivity maps; no game files changed.')
if __name__=='__main__':main()
