#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../src/vr_effect_view_cache.h"
using namespace RFGRVREffectViewCache;
static void put(void* p,unsigned off,unsigned v){memcpy((char*)p+off,&v,4);}
int main(){bool occupied[4096]{};unsigned unique=0;for(unsigned i=0;i<512;++i){auto slot=RFGRVREffectGeometry::slotFor((void*)(uintptr_t(0x1000000u)+i*65536u));if(!occupied[slot]){occupied[slot]=true;++unique;}}assert(unique>400);

 unsigned char effect[0xe0]{};put(effect,0xd0,12);put(effect,0xd8,34);put(effect,0xd4,100);put(effect,0xdc,100);
 select(0);assert(!prepare(effect,100));assert(RFGRVREffectGeometry::word(effect,0xd4)==100);
 select(1);assert(prepare(effect,100));assert(RFGRVREffectGeometry::word(effect,0xd4)==99&&RFGRVREffectGeometry::word(effect,0xdc)==99);
 assert(RFGRVREffectGeometry::word(effect,0xd0)==12&&RFGRVREffectGeometry::word(effect,0xd8)==34);
 // Both query subpasses may update their stamps. Do not expire them again
 // during the same eye or the engine's intra-eye deduplication breaks.
 put(effect,0xd4,100);put(effect,0xdc,100);auto queries=vrmemory::queryTotal.load();{vrmemory::Scope scope;assert(!prepare(effect,100));}assert(vrmemory::queryTotal.load()==queries);assert(RFGRVREffectGeometry::word(effect,0xd4)==100);
 select(1);assert(prepare(effect,100));select(-1);assert(!prepare(effect,100));put(effect,0xd4,100);put(effect,0xdc,100);select(0);select(1);assert(prepare(effect,100));
 select(0);put(effect,0xd4,98);put(effect,0xdc,98);select(1);assert(!prepare(effect,100));
 select(0);put(effect,0xd4,0);put(effect,0xdc,0);select(1);assert(prepare(effect,0));assert(RFGRVREffectGeometry::word(effect,0xd4)==~0u);
}

