#pragma once
#include <cmath>
#include <algorithm>
namespace RFGRAPCScreen {
struct Rect {unsigned x,y,width,height;};
constexpr unsigned atlasWidth=1024,atlasHeight=720;
constexpr Rect tile(unsigned i){return i==0?Rect{0,0,1024,576}:Rect{(i-1)*256,576,256,144};}
constexpr float width(unsigned i){return i==0?.9f:.29f;}
constexpr float height(unsigned i){return width(i)*9.f/16.f;}
// Source pixels are capped by the actual monitor texture, not headset size.
// Quantization avoids resource churn as the head moves by a few millimetres.
inline unsigned resolution(unsigned i,float distance,float assemblyScale,float pixelsPerRadian){
 if(!std::isfinite(distance)||!std::isfinite(assemblyScale)||!std::isfinite(pixelsPerRadian)||distance<=0||assemblyScale<=0||pixelsPerRadian<=0)return tile(i).width;
 float angle=2.f*atanf(width(i)*assemblyScale/(2.f*distance));
 unsigned desired=unsigned(ceilf(angle*pixelsPerRadian*1.15f/64.f))*64;
 return (std::max)(128u,(std::min)(tile(i).width,desired));
}
struct Size {unsigned width,height;};
// Budget each resized panel from BOTH angular dimensions and its own distance.
// Fit to its atlas tile with one common scale to retain the capture aspect.
inline Size captureSize(unsigned i,float distance,float physicalWidth,float physicalHeight,float px,float py){
 auto cap=tile(i);if(!(distance>0&&physicalWidth>0&&physicalHeight>0&&px>0&&py>0)||!std::isfinite(distance+physicalWidth+physicalHeight+px+py))return {cap.width,cap.height};
 float aspect=physicalWidth/physicalHeight;
 float w=2*atanf(physicalWidth/(2*distance))*px*1.15f;
 float h=2*atanf(physicalHeight/(2*distance))*py*1.15f;
 // Quantize the larger required density; avoid starving a tall narrow monitor.
 w=(std::max)(w,h*aspect);w=ceilf(w/32)*32;h=w/aspect;
 float fit=(std::min)(1.f,(std::min)(cap.width/w,cap.height/h));
 return {(std::max)(16u,unsigned(w*fit+.5f)),(std::max)(16u,unsigned(h*fit+.5f))};
}
}
