#pragma once
#include "gpu_protocol.h"
#ifdef RFGR_TEST_HUD_CHANNELS
#define RFGR_HUD_PREFIX L"Local\\RFGRVR_TEST_"
#else
#define RFGR_HUD_PREFIX L"Local\\RFGRVR_"
#endif
static constexpr wchar_t RFGR_WRIST_MAP[]=RFGR_HUD_PREFIX L"WristMap_v1";
static constexpr unsigned RFGR_WRIST_SIZE=512;

static constexpr wchar_t RFGR_AMMO_HUD[]=RFGR_HUD_PREFIX L"AmmoHud_v1";
static constexpr wchar_t RFGR_CHARGE_HUD[]=RFGR_HUD_PREFIX L"ChargeHud_v1";

static constexpr wchar_t RFGR_NOTICE_HUD[]=RFGR_HUD_PREFIX L"NoticeHud_v1";

static constexpr wchar_t RFGR_MISSION_HUD[]=RFGR_HUD_PREFIX L"MissionHud_v1";
static constexpr wchar_t RFGR_OBJECTIVE_HUD[]=RFGR_HUD_PREFIX L"ObjectiveHud_v1";

static constexpr wchar_t RFGR_WEAPON_SELECTOR[]=RFGR_HUD_PREFIX L"WeaponSelector_v1";

static constexpr wchar_t RFGR_MENU_HUD[]=RFGR_HUD_PREFIX L"MenuHud_v1";

static constexpr wchar_t RFGR_HEALTH_HUD[]=RFGR_HUD_PREFIX L"HealthHud_v1";

static constexpr wchar_t RFGR_OVERHEAT_HUD[]=RFGR_HUD_PREFIX L"OverheatHud_v1";

static constexpr wchar_t RFGR_MAINMENU_VIDEO[]=RFGR_HUD_PREFIX L"MainMenuVideo_v1";
static constexpr wchar_t RFGR_MAINMENU_UI[]=RFGR_HUD_PREFIX L"MainMenuUI_v1";

static constexpr wchar_t RFGR_FACTION_HUD[]=RFGR_HUD_PREFIX L"FactionHud_v1";

static constexpr wchar_t RFGR_MORALE_HUD[]=RFGR_HUD_PREFIX L"MoraleHud_v1";

#undef RFGR_HUD_PREFIX
