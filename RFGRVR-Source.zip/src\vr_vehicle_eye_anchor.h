#pragma once
#include "vr_arm_math.h"
#include <cstdint>
// Preserve the driver's native entry position, not a new hard-coded eye height.
// Tracking offsets and saved height adjustments are applied after this anchor.
struct RFGRVRVehicleEyeAnchor {
 unsigned id=~0u;uint64_t settleUntil=0;vrarm::V eye{};
 void reset(){id=~0u;settleUntil=0;eye={};}
 bool settled(unsigned vehicle,uint64_t now)const{return id==vehicle&&vehicle!=~0u&&now>=settleUntil;}
 bool position(unsigned vehicle,const vrarm::Pose& chassis,uint64_t now,vrarm::V& result)const{if(!settled(vehicle,now)||!vrarm::valid(chassis.b)||!vrarm::finite(chassis.p))return false;result=vrarm::add(chassis.p,vrarm::world(chassis.b,eye));return vrarm::finite(result);}
 bool update(unsigned vehicle,const vrarm::Pose& chassis,vrarm::V& nativeEye,uint64_t now){
  using namespace vrarm;if(vehicle==~0u||!valid(chassis.b)||!finite(chassis.p)||!finite(nativeEye)){reset();return false;}
  V sample=local(chassis.b,sub(nativeEye,chassis.p));if(length(sample)>20){reset();return false;}
  if(id!=vehicle){id=vehicle;settleUntil=now+1000;eye=sample;}
  if(now<settleUntil)eye=sample;
  nativeEye=add(chassis.p,world(chassis.b,eye));return true;
 }
};
struct RFGRVRSeatOrigin {
 bool seated=false,mode=false;float before=0,target=0;uint64_t tick=0;
 void update(bool active,bool sitting,float headY,uint64_t now,float& origin){
  if(active&&!seated){before=origin;target=headY;origin=headY;tick=now;}
  else if(active){if(sitting!=mode)target=headY;float dt=now>=tick?float(now-tick)*.001f:0;dt=(std::min)(dt,.05f);origin+=(target-origin)*(1-std::exp(-dt/.25f));tick=now;}
  else if(seated)origin=before;
  seated=active;mode=sitting;
 }
};

// Seat-height adjustments follow the vehicle's own up axis. A world-up offset
// slides the viewpoint through the body as the chassis banks over rough ground.
inline vrarm::V RFGRVR_SeatHeightOffset(vrarm::V point,const vrarm::M& seat,float height){return vrarm::add(point,vrarm::mul(seat.u,height));}
