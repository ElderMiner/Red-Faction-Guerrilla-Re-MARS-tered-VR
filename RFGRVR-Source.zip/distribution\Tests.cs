using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Linq;
namespace RFGRVR {
 public static class Tests {
  static void Assert(bool yes,string message){if(!yes)throw new Exception(message);}
  static MemoryStream Payload(string game,string content,bool bad,string entryPath="dinput8.dll",bool seed=false){var stream=new MemoryStream();using(var zip=new ZipArchive(stream,ZipArchiveMode.Create,true)){var f=zip.CreateEntry(entryPath);using(var w=new StreamWriter(f.Open()))w.Write(content);string temp=Path.GetTempFileName();File.WriteAllText(temp,content,new UTF8Encoding(false));var m=new PackageManifest{version=content,gameSha256=Core.Hash(game),files=new[]{new FileRecord{path=entryPath.Replace('\\','/'),sha256=bad?new string('0',64):Core.Hash(temp),seedOnly=seed}}};File.Delete(temp);var entry=zip.CreateEntry("manifest.json");using(var w=new StreamWriter(entry.Open()))w.Write(Core.Json.Serialize(m));}stream.Position=0;return stream;}
  public static int Run(string parent){string root=Core.Inside(parent,"installer-test-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);try{
   string game=Path.Combine(root,"rfg.exe"),dll=Path.Combine(root,"dinput8.dll"),settings=Path.Combine(root,"RFGRVR-settings.ini");File.WriteAllText(game,"synthetic game");File.WriteAllText(dll,"original");File.WriteAllText(settings,"personal settings");
   using(var p=Payload(game,"version1",false))Installer.Install(root,p,false,false);Assert(File.ReadAllText(dll)=="version1","Initial install failed");
   using(var p=Payload(game,"version2",false))Installer.Install(root,p,false,false);Assert(File.ReadAllText(dll)=="version2","Update failed");
   bool failed=false;try{using(var p=Payload(game,"broken",true))Installer.Install(root,p,false,false);}catch(IOException){failed=true;}Assert(failed&&File.ReadAllText(dll)=="version2","Failed validation changed active files");
   Installer.Uninstall(root);Assert(File.ReadAllText(dll)=="original","Uninstall did not walk update backups");Assert(File.ReadAllText(settings)=="personal settings","Personal settings changed");
   using(var p=Payload(game,"nested",false,@"RFGRVR\nested-test.txt"))Installer.Install(root,p,false,false);Assert(File.ReadAllText(Path.Combine(root,@"RFGRVR\nested-test.txt"))=="nested","Windows ZIP separator rejected");Installer.Uninstall(root);
   string eyes=Path.Combine(root,"RFGRVR-eye-offset.ini");using(var p=Payload(game,"approved eye default",false,"RFGRVR-eye-offset.ini",true))Installer.Install(root,p,false,false);Assert(File.ReadAllText(eyes)=="approved eye default","Missing eye defaults not seeded");File.WriteAllText(eyes,"later adjustment");using(var p=Payload(game,"new default",false,"RFGRVR-eye-offset.ini",true))Installer.Install(root,p,false,false);Assert(File.ReadAllText(eyes)=="later adjustment","Update overwrote saved eye settings");Installer.Uninstall(root);Assert(File.ReadAllText(eyes)=="later adjustment","Uninstall removed saved seeded settings");
   failed=false;try{Core.Inside(root,@"..\escape.dll");}catch(IOException){failed=true;}Assert(failed,"Traversal accepted");
   string text="\"UserLocalConfigStore\" { \"Software\" { \"Valve\" { \"Steam\" { \"apps\" { \"667720\" { \"LaunchOptions\" \"-windowed\" } \"123\" { \"Keep\" \"value\" } } } } } }";var v=Vdf.Parse(text);var again=Vdf.Parse(v.Serialize());Assert(again.Child("UserLocalConfigStore").Child("Software").Child("Valve").Child("Steam").Child("apps").Child("123").Child("Keep").Value=="value","VDF round trip damaged another app");
   File.WriteAllText(Path.Combine(root,"rfg.exe"),"unsupported");failed=false;using(var p=Payload(game,"good",false)){File.WriteAllText(game,"changed");try{Installer.Install(root,p,false,false);}catch(IOException){failed=true;}}Assert(failed,"Wrong game version accepted");
   File.WriteAllText(Path.Combine(parent,"installer-tests.txt"),"PASS: staged install, update, checksum rejection, rollback retention, uninstall through update history, personal settings preservation, path traversal rejection, VDF round trip, game version validation.");return 0;
  }finally{Directory.Delete(root,true);}}
 }
}
