#pragma once
#include <cmath>
// Metres in calibrated STAGE space; never filter camera/controller tracking.
struct RFGRVRPhysicalCrouch {
 float drop=0;bool held=false,ready=false;
 void reset(){drop=0;held=ready=false;}
 bool update(float eye,float standing,float seconds,bool allowed,float threshold=.30f){
  if(!allowed||!std::isfinite(eye)||!std::isfinite(standing)||standing<1||standing>2.4f||eye<0||eye>3||!std::isfinite(seconds)||seconds<0){reset();return false;}
  float target=standing-eye;if(!ready){drop=target;ready=true;}
  else {if(seconds>.1f)seconds=.1f;drop+=(target-drop)*(1-std::exp(-seconds/.06f));}
  if(!held&&drop>=threshold)held=true;else if(held&&drop<=threshold-.12f)held=false;
  return held;
 }
};
