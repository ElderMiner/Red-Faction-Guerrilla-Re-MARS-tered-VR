#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <wrl/client.h>
#include <cassert>
#include <cstdio>
#include "../../tools/renderdoc-1.46/RenderDoc_1.46_64/renderdoc_app.h"
using Microsoft::WRL::ComPtr;
int main(int argc,char** argv){
 assert(argc==2);auto module=GetModuleHandleW(L"renderdoc.dll");assert(module);
 auto get=(pRENDERDOC_GetAPI)GetProcAddress(module,"RENDERDOC_GetAPI");RENDERDOC_API_1_7_0* api=nullptr;assert(get&&get(eRENDERDOC_API_Version_1_7_0,(void**)&api)==1);
 auto hwnd=CreateWindowExW(0,L"STATIC",L"RFGR graphics capture self-test",WS_POPUP,0,0,32,32,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);assert(hwnd);
 DXGI_SWAP_CHAIN_DESC desc{};desc.BufferDesc.Width=desc.BufferDesc.Height=32;desc.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.SampleDesc.Count=1;desc.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;desc.BufferCount=1;desc.OutputWindow=hwnd;desc.Windowed=TRUE;desc.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;ComPtr<IDXGISwapChain> swap;
 assert(SUCCEEDED(D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&desc,&swap,&device,nullptr,&context)));
 ComPtr<ID3D11Texture2D> back;assert(SUCCEEDED(swap->GetBuffer(0,IID_PPV_ARGS(&back))));ComPtr<ID3D11RenderTargetView> target;assert(SUCCEEDED(device->CreateRenderTargetView(back.Get(),nullptr,&target)));
 api->SetCaptureFilePathTemplate(argv[1]);api->StartFrameCapture(device.Get(),hwnd);
 ID3D11RenderTargetView* output=target.Get();context->OMSetRenderTargets(1,&output,nullptr);const float color[]={.1f,.8f,.2f,1};context->ClearRenderTargetView(target.Get(),color);
 assert(api->EndFrameCapture(device.Get(),hwnd));swap->Present(0,0);puts("PASS: RenderDoc API captured a real D3D11 frame");DestroyWindow(hwnd);
}
