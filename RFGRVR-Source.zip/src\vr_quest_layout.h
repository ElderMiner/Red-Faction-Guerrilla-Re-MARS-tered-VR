#pragma once
#include <cstdint>
#include "ipc.h"
namespace vrquest {
constexpr unsigned Detonate=0x400,ContextTap=0x800,Commands=Detonate|ContextTap;
struct Layout {
 bool wasY=false,usedHold=false,selectionHeld=false,blocked=false;uint64_t pressed=0,pulseUntil=0;
 RFGRGamepad update(RFGRGamepad raw,float leftGrip,float rightGrip,bool gameplay,unsigned state,uint64_t now){
  bool y=(raw.buttons&0x8000)!=0;selectionHeld=false;
  if(!gameplay){wasY=false;usedHold=false;pulseUntil=0;blocked=y;return raw;}
  if(blocked){if(!y)blocked=false;y=false;}
  RFGRGamepad p=raw;p.buttons&=~(0xf000u|0xc0u|0x10u);
  if(raw.buttons&0x1000)p.buttons|=0x1000; // A jump.
  if(raw.buttons&0x2000)p.buttons|=0x4000; // B reload.
  if(raw.buttons&0x4000)p.buttons|=Detonate; // X, native C4-only command.
  bool vehicle=state>=7&&state<=10;
  if(raw.buttons&0x40)p.buttons|=vehicle?0x40:0x100; // LS sprint on foot; vehicle reset.
  if(raw.buttons&0x80)p.buttons|=vehicle?0x80:0x40; // RS crouch on foot; vehicle aim.
  if(raw.buttons&0x10)p.buttons|=leftGrip>.65f?0x20:0x10;
  if(!y&&raw.rightY<-22000&&!(vehicle&&rightGrip>.65f)){p.buttons|=8;p.rightY=0;}
  if(y&&!wasY){pressed=now;usedHold=false;}
  if(y){selectionHeld=true;if(now-pressed>=500)usedHold=true;}
  if(!y&&wasY&&!usedHold)pulseUntil=now+90;
  if(now<pulseUntil)p.buttons|=ContextTap;
  wasY=y;return p;
 }
};
inline void commands(RFGRGamepad& p,bool gameplay,bool interact,bool c4){unsigned flags=p.buttons&Commands;p.buttons&=~Commands;if(!gameplay)return;if((flags&Detonate)&&c4)p.buttons|=0x2000;else if(flags&ContextTap)p.buttons|=interact?0x2000:0x200;}
struct CommandState {
 bool held=false;unsigned choice=0;
 void apply(RFGRGamepad& p,bool gameplay,bool interact,bool c4){unsigned flags=p.buttons&Commands;if(!gameplay){held=false;choice=0;commands(p,false,false,false);return;}if((flags&ContextTap)&&!held)choice=interact?0x2000:0x200;held=(flags&ContextTap)!=0;p.buttons&=~Commands;if((flags&Detonate)&&c4)p.buttons|=0x2000;else if(held)p.buttons|=choice;}
};

}
