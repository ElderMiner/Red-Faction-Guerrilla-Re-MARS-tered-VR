#pragma once
#include "vr_arm_math.h"
// Rotate the held charge around its authored grip, not the model origin.
// The release path receives this exact same mesh pose.
inline vrarm::Pose RFGRVR_ChargeGrip(const vrarm::M& nativeOrientation,vrarm::V localGrip,vrarm::V hand){using namespace vrarm;M basis=turnAround(nativeOrientation,nativeOrientation.r,-1.57079632679f);return {basis,sub(hand,world(basis,localGrip))};}

inline vrarm::Pose RFGRVR_ChargeLift(vrarm::Pose pose,vrarm::V grip,vrarm::V controllerRight){using namespace vrarm;V pivot=add(pose.p,world(pose.b,grip));pose.b=turnAround(pose.b,controllerRight,-.3490658504f);pose.p=sub(pivot,world(pose.b,grip));return pose;}
