#pragma once
#include "vr_arm_math.h"
inline float RFGRVR_BodyYaw(vrarm::M basis){return basis.f.x*basis.f.x+basis.f.z*basis.f.z>.000001f?atan2f(basis.f.x,basis.f.z):atan2f(-basis.r.z,basis.r.x);}
inline vrarm::Pose RFGRVR_AlignBodyYaw(vrarm::Pose pose,const vrarm::Pose& animationRoot,float targetYaw){
 using namespace vrarm;float angle=std::remainder(targetYaw-RFGRVR_BodyYaw(animationRoot.b),6.283185307f);M rotation=turnAround(M{{1,0,0},{0,1,0},{0,0,1}},{0,1,0},angle);return {compose(rotation,pose.b),add(animationRoot.p,world(rotation,sub(pose.p,animationRoot.p)))};
}
