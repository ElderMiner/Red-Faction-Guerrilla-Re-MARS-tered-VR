#pragma once
#include <cmath>
#include <cstdint>
#include "vr_gamepad_math.h"
struct RFGRVRRoomDrive {
 float wanted[2]{},raw[2]{},position[2]{},drivenWorld[2]{},drivenRaw[2]{};
 uint64_t requestTick=0,driveTick=0,positionTick=0;bool positioned=false,driving=false,walking=false;
 void request(float wx,float wz,float rx,float rz,uint64_t now){
  if(!std::isfinite(wx)||!std::isfinite(wz)||!std::isfinite(rx)||!std::isfinite(rz)||wx*wx+wz*wz>4){requestTick=0;driving=walking=false;return;}
  wanted[0]=wx;wanted[1]=wz;raw[0]=rx;raw[1]=rz;requestTick=now;
 }
 bool input(float nativeYaw,bool allowed,uint64_t now,int16_t& x,int16_t& y){
  driving=false;float d=std::hypot(wanted[0],wanted[1]);
  if(!allowed||!requestTick||now-requestTick>150||!std::isfinite(nativeYaw) ){walking=false;return false;}
  walking=d>(walking?.020f:.040f);if(!walking)return false;
  float magnitude=.16f+std::fmin(.44f,d*3.f),c=std::cos(nativeYaw),s=std::sin(nativeYaw);
  x=RFGRVR_Axis((wanted[0]*c-wanted[1]*s)/d*magnitude);y=RFGRVR_Axis((wanted[0]*s+wanted[1]*c)/d*magnitude);
  for(int i=0;i<2;++i){drivenWorld[i]=wanted[i];drivenRaw[i]=raw[i];}driveTick=now;driving=true;return true;
 }
 void observe(float x,float z,bool allowed,uint64_t now,float consumed[2]){
  consumed[0]=consumed[1]=0;if(!std::isfinite(x)||!std::isfinite(z)){positioned=false;return;}
  float dx=x-position[0],dz=z-position[1];bool valid=positioned&&now-positionTick<=250&&dx*dx+dz*dz<1;
  position[0]=x;position[1]=z;positionTick=now;positioned=true;
  if(!allowed){driving=false;return;}if(!valid||!driving||now-driveTick>150)return;
  float r2=drivenRaw[0]*drivenRaw[0]+drivenRaw[1]*drivenRaw[1];if(r2<.000001f)return;
  // XR X/Z -> upright game X/Z is a scaled reflection. Invert the exact
  // requested mapping, crediting actual collision-resolved displacement.
  float a=(drivenWorld[0]*drivenRaw[0]-drivenWorld[1]*drivenRaw[1])/r2;
  float b=(drivenWorld[0]*drivenRaw[1]+drivenWorld[1]*drivenRaw[0])/r2;
  float denominator=a*a+b*b;if(denominator<.000001f)return;
  consumed[0]=(a*dx+b*dz)/denominator;consumed[1]=(b*dx-a*dz)/denominator;
 }
};
