#pragma once
#include "vr_arm_math.h"
#include "vr_weapon_motion.h"
#include <algorithm>
namespace vrprop {
using namespace vrarm;
inline Pose inverseGrip(Pose hand,Pose localGrip){M b=compose(hand.b,relative(localGrip.b,M{{1,0,0},{0,1,0},{0,0,1}}));return {b,sub(hand.p,world(b,localGrip.p))};}
inline V limited(V v,float cap){float n=length(v);return n>cap?mul(v,cap/n):v;}
struct Motor {
 V velocity{},angular{};uint64_t tick=0;
 void reset(){*this={};}
 bool step(Pose actual,Pose goal,unsigned hands,float scale,uint64_t now){
  if(!hands||!valid(actual.b)||!valid(goal.b)||!finite(actual.p)||!finite(goal.p)||!std::isfinite(scale)||scale<.1f)return false;
  if(!tick||now<=tick||now-tick>100){tick=now;velocity=angular={};return false;}
  float dt=float(now-tick)*.001f;tick=now;V error=sub(goal.p,actual.p);if(length(error)>1.5f*scale)return false;
  // A soft physical servo, never a visual teleport. Gravity and collisions remain native.
  float gain=hands>1?14.f:10.f,accel=hands>1?55.f:38.f;V desired=mul(error,gain);desired.y-=hands>1?.05f*scale:.12f*scale;
  velocity=add(velocity,limited(sub(desired,velocity),accel*scale*dt));velocity=limited(velocity,8.f*scale);
  V desiredSpin=vrweapon::angularDelta(actual.b,goal.b,hands>1?.10f:.18f);angular=add(angular,limited(sub(desiredSpin,angular),55.f*dt));angular=limited(angular,14.f);return true;
 }
};
struct Grips {
 Pose pose[8]{};int side[8]={-1,-1,-1,-1,-1,-1,-1,-1};unsigned count=0;
 bool set(unsigned slot,Pose local){if(slot>count||slot>=3||!valid(local.b)||!finite(local.p)||length(local.p)>2)return false;pose[slot]=local;side[slot]=-1;if(slot==count)++count;return true;}
 bool add(Pose local,int hand=-1){if(hand< -1||hand>1)return false;if(!valid(local.b)||!finite(local.p)||length(local.p)>2)return false;for(unsigned i=0;i<count;++i)if((side[i]==hand||side[i]==-1)&&length(sub(pose[i].p,local.p))<.015f){pose[i]=local;side[i]=hand;return true;}if(count>=3){unsigned closest=0;float distance=length(sub(pose[0].p,local.p));for(unsigned i=1;i<count;++i){float d=length(sub(pose[i].p,local.p));if(d<distance){closest=i;distance=d;}}if(distance>.45f)return false;pose[closest]=local;side[closest]=hand;return true;}side[count]=hand;pose[count++]=local;return true;}
 int aimed(Pose object,Pose hand,V forward,float range)const{int selected=-1;float best=1e9f;forward=unit(forward,hand.b.f);for(unsigned i=0;i<count;++i){V delta=sub(vrarm::add(object.p,world(object.b,pose[i].p)),hand.p);float d=length(delta);if(d>range)continue;float score=d+range*.30f*(1-dot(unit(delta,forward),forward));if(score<best){best=score;selected=int(i);}}return selected;}
 Pose smart(unsigned i,Pose object,Pose controller)const{Pose result=pose[i];M actual=relative(object.b,controller.b),other=turnAround(result.b,{0,1,0},3.141592654f);auto score=[&](M b){return dot(b.r,actual.r)+dot(b.u,actual.u)+dot(b.f,actual.f);};if(score(other)>score(result.b))result.b=other;return result;}
 int nearest(Pose object,V hand,float distance,int physicalHand=-1)const{int best=-1;for(unsigned i=0;i<count;++i){float d=length(sub(vrarm::add(object.p,world(object.b,pose[i].p)),hand));if(d<distance){distance=d;best=int(i);}}return best;}
};
}

