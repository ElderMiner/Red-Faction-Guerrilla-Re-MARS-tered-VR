#include "../src/vr_grip_snapshot.h"
#include <cassert>
#include <atomic>
#include <thread>
int main(){RFGRShared packet{};packet.version=RFGR_PROTOCOL;packet.gamepadActive=1;float grip[2];packet.gripValue[0]=.7f;packet.gripValue[1]=.2f;assert(RFGRVR_CopyGripInput(&packet,grip)&&grip[0]==.7f&&grip[1]==.2f);
 packet.inputSequence=1;assert(!RFGRVR_CopyGripInput(&packet,grip)&&grip[0]==0);packet.inputSequence=2;packet.gamepadActive=0;assert(!RFGRVR_CopyGripInput(&packet,grip));packet.gamepadActive=1;
 std::atomic<bool> done{false};std::atomic<unsigned> accepted{0};packet.gripValue[0]=packet.gripValue[1]=0;
 std::thread reader([&]{while(!done.load())if(RFGRVR_CopyGripInput(&packet,grip)){assert(grip[0]==grip[1]);++accepted;}});
 for(unsigned i=0;i<100000;++i){InterlockedIncrement(&packet.inputSequence);MemoryBarrier();packet.gripValue[0]=packet.gripValue[1]=(i&1)?1.f:0.f;MemoryBarrier();InterlockedIncrement(&packet.inputSequence);if(i%100==0)SwitchToThread();}done=true;reader.join();assert(accepted>0);
}
