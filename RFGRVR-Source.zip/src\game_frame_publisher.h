#pragma once
// Game-side DX11 backbuffer -> cross-process GPU publication.
// Call PublishFrame from the game's *verified render thread* after rendering the world.
// No DXGI vtable modifications; no background context access; no synthetic frames.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wrl/client.h>
#include "gpu_protocol.h"

class GameFramePublisher {
public:
    // The caller owns the swapchain. The publisher temporarily retains COM references.
    bool PublishFrame(IDXGISwapChain* swapchain) noexcept;
    void Shutdown() noexcept;
    ~GameFramePublisher() { Shutdown(); }
    unsigned long PublishedFrames() const noexcept { return published_; }
    HRESULT LastError() const noexcept { return lastError_; }
private:
    bool Prepare(IDXGISwapChain* swapchain, ID3D11Texture2D* backbuffer) noexcept;
    void ReleaseTexture() noexcept;
    Microsoft::WRL::ComPtr<ID3D11Device> device_;
    Microsoft::WRL::ComPtr<ID3D11DeviceContext> context_;
    Microsoft::WRL::ComPtr<ID3D11Texture2D> sharedTexture_;
    Microsoft::WRL::ComPtr<IDXGIKeyedMutex> mutex_;
    HANDLE mapHandle_=nullptr;
    RFGRGpuShared* map_=nullptr;
    unsigned width_=0,height_=0;
    DXGI_FORMAT format_=DXGI_FORMAT_UNKNOWN;
    unsigned long published_=0;
    HRESULT lastError_=S_OK;
};
