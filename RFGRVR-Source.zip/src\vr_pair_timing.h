#pragma once
#include <windows.h>
#include <d3d11.h>
#include <wrl/client.h>
#include <cstdio>
// Sparse, asynchronous timing. Never wait for a query or flush to obtain data.
struct RFGRVRPairTiming {
 using Query=Microsoft::WRL::ComPtr<ID3D11Query>;
 struct Slot {Query disjoint,stamp[3];bool pending=false,complete=false;LARGE_INTEGER cpu{};double cpuMs=0;};
 Slot slots[8];int active=-1;unsigned frame=0,samples=0,skipped=0,eyeMask=0;bool unavailable=false;
 double leftMs=0,rightMs=0,cpuMs=0;
 void reset(){for(auto& s:slots)s=Slot{};active=-1;unavailable=false;frame=samples=skipped=eyeMask=0;leftMs=rightMs=cpuMs=0;}
 bool initialize(ID3D11Device* device){
  if(unavailable)return false;if(slots[0].disjoint)return true;
  for(auto& s:slots){D3D11_QUERY_DESC desc{D3D11_QUERY_TIMESTAMP_DISJOINT,0};
   if(FAILED(device->CreateQuery(&desc,s.disjoint.GetAddressOf()))){reset();unavailable=true;return false;}
   desc.Query=D3D11_QUERY_TIMESTAMP;
   for(auto& q:s.stamp)if(FAILED(device->CreateQuery(&desc,q.GetAddressOf()))){reset();unavailable=true;return false;}
  }return true;
 }
 void poll(ID3D11DeviceContext* ctx){
  for(auto& s:slots)if(s.pending){D3D11_QUERY_DATA_TIMESTAMP_DISJOINT d{};UINT64 t[3]{};
   if(ctx->GetData(s.disjoint.Get(),&d,sizeof(d),D3D11_ASYNC_GETDATA_DONOTFLUSH)!=S_OK)continue;
   bool ready=true;for(unsigned i=0;i<3;++i)if(ctx->GetData(s.stamp[i].Get(),&t[i],sizeof(t[i]),D3D11_ASYNC_GETDATA_DONOTFLUSH)!=S_OK)ready=false;
   if(!ready)continue;s.pending=false;
   if(!s.complete||d.Disjoint||!d.Frequency||t[1]<t[0]||t[2]<t[1])continue;
   leftMs+=1000.*double(t[1]-t[0])/d.Frequency;rightMs+=1000.*double(t[2]-t[1])/d.Frequency;cpuMs+=s.cpuMs;++samples;
   if(samples%32==0){wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');
    if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Pair-GPU-Timing.log");FILE* file=nullptr;
     if(!_wfopen_s(&file,path,L"a")&&file){fprintf(file,"tick=%llu samples=%u leftGpuMs=%.3f rightGpuMs=%.3f pairCpuWallMs=%.3f skipped=%u\n",GetTickCount64(),samples,leftMs/32,rightMs/32,cpuMs/32,skipped);fclose(file);}}
    leftMs=rightMs=cpuMs=0;
   }
  }
 }
 void begin(ID3D11Device* device,ID3D11DeviceContext* ctx){
  if(!device||!ctx||active>=0)return;poll(ctx);if(++frame%16||!initialize(device))return;
  for(unsigned i=0;i<8;++i)if(!slots[i].pending){active=int(i);eyeMask=0;auto& s=slots[i];s.complete=false;
   QueryPerformanceCounter(&s.cpu);ctx->Begin(s.disjoint.Get());ctx->End(s.stamp[0].Get());return;}
  ++skipped;
 }
 void eye(ID3D11DeviceContext* ctx,unsigned eye){if(active>=0&&eye<2&&!(eyeMask&(1u<<eye))){ctx->End(slots[active].stamp[eye+1].Get());eyeMask|=1u<<eye;}}
 void end(ID3D11DeviceContext* ctx,bool complete){if(active<0)return;auto& s=slots[active];
  // Failed pairs still close all queries so their slots can be retired.
  complete=complete&&eyeMask==3;
  for(unsigned i=0;i<2;++i)if(!(eyeMask&(1u<<i)))ctx->End(s.stamp[i+1].Get());
  ctx->End(s.disjoint.Get());LARGE_INTEGER now{},frequency{};QueryPerformanceCounter(&now);QueryPerformanceFrequency(&frequency);
  s.cpuMs=1000.*double(now.QuadPart-s.cpu.QuadPart)/frequency.QuadPart;s.complete=complete;s.pending=true;active=-1;
 }
};
