#pragma once
#include "arm_training_markers.h"
#include "vr_elbow_profile.h"
#include <cstdio>
#include <algorithm>
namespace vrtraining {
using namespace vrarm;
struct Coverage {
 unsigned samples=0,directions=0,wristSamples=0;bool wristStarted=false;M wristBase{};V elbowBase{};float roll=0,bend=0;
 static unsigned bits(unsigned n){unsigned c=0;for(;n;n>>=1)c+=n&1;return c;}
 void observe(unsigned phase,V velocity,M controller,V elbow){
  if(phase==1){++samples;if(length(velocity)>.06f){float a[3]={velocity.x,velocity.y,velocity.z};unsigned axis=fabsf(a[1])>fabsf(a[0])?1:0;if(fabsf(a[2])>fabsf(a[axis]))axis=2;directions|=1u<<(axis*2+(a[axis]>0));}}
  else if(phase==2){if(wristGood())return;if(!wristStarted){wristStarted=true;wristBase=controller;elbowBase=elbow;}if(length(sub(elbow,elbowBase))>.045f){wristBase=controller;elbowBase=elbow;wristSamples=0;roll=bend=0;return;}++wristSamples;roll=(std::max)(roll,acosf((std::clamp)(dot(wristBase.r,controller.r),-1.f,1.f)));bend=(std::max)(bend,acosf((std::clamp)(dot(wristBase.f,controller.f),-1.f,1.f)));}
 }
 bool armGood()const{return samples>=18&&bits(directions)>=2;}
 bool wristGood()const{return wristSamples>=30&&roll>=.6f&&bend>=.45f;}
};
struct Session {
 unsigned phase=0,lastSample=0,rows=0,nodeSamples[48]{},armSamples=0,wristSamples=0;bool anchored=false,error=false;FILE* file=nullptr;
 ULONGLONG started=0,lastTick=0,flushed=0,neutralSince=0;V neutralHand{},neutralElbow{};M neutralController{};V previous{},anchor{},target[16]{};M bodyBasis{};float scale=1;Coverage coverage[16];RFGRVRElbowProfile fitted;
 char dataPath[MAX_PATH]{},profilePath[MAX_PATH]{},directory[MAX_PATH]{};bool installedProfile=false;const char* saveReason="recording";
 ~Session(){if(file){fflush(file);fclose(file);}}
 static bool paths(char* root,char* output){char exe[MAX_PATH]{};GetModuleFileNameA(nullptr,exe,MAX_PATH);auto* slash=strrchr(exe,'\\');if(!slash)return false;*slash=0;strcpy_s(root,MAX_PATH,exe);sprintf_s(output,MAX_PATH,"%s\\vr-research\\output",exe);return true;}
 bool begin(){if(phase){phase=1;return true;}char root[MAX_PATH],output[MAX_PATH];if(!paths(root,output))return false;if(directory[0])strcpy_s(output,directory);SYSTEMTIME t;GetLocalTime(&t);sprintf_s(dataPath,"%s\\arm-training-%04u%02u%02u-%02u%02u%02u-%03u.csv",output,t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond,t.wMilliseconds);if(fopen_s(&file,dataPath,"wx")||!file)return false;
  if(!profilePath[0])sprintf_s(profilePath,"%s\\RFGRVR-elbow-profile.txt",root);phase=1;active=true;anchored=error=installedProfile=false;lastSample=rows=armSamples=wristSamples=0;neutralSince=0;started=lastTick=flushed=GetTickCount64();fitted={};fitted.version=2;memset(nodeSamples,0,sizeof(nodeSamples));for(auto& c:coverage)c={};
  fprintf(file,"milliseconds,phase,sample,fit,target,shoulder_x,shoulder_y,shoulder_z,hand_x,hand_y,hand_z,elbow_x,elbow_y,elbow_z,body_rx,body_ry,body_rz,body_ux,body_uy,body_uz,body_fx,body_fy,body_fz,right_x,right_y,right_z,right_rx,right_ry,right_rz,right_ux,right_uy,right_uz,right_fx,right_fy,right_fz,left_x,left_y,left_z,left_rx,left_ry,left_rz,left_ux,left_uy,left_uz,left_fx,left_fy,left_fz\n");if(fflush(file)||ferror(file))error=true;return true;
 }
 void fit(V shoulder,V hand,V elbow,M controller){V delta=sub(hand,shoulder);float distance=length(delta);V axis=unit(delta),observed=sub(elbow,shoulder);observed=sub(observed,mul(axis,dot(observed,axis)));V reference{.65f,-1,-.15f};reference=unit(sub(reference,mul(axis,dot(reference,axis))),{1,0,0});V b=unit(observed);float angle=atan2f(dot(b,cross(axis,reference)),dot(b,reference));
  float feature[10]={axis.x,axis.y,axis.z,distance,controller.r.x,controller.r.y,controller.r.z,controller.f.x,controller.f.y,controller.f.z};unsigned nearest=0;float best=1e9f;for(unsigned i=0;i<fitted.count;++i){float d=0;for(unsigned j=0;j<4;++j){float x=(feature[j]-fitted.nodes[i].feature[j])*(j==3?2.f:1.f);d+=x*x;}if(d<best){best=d;nearest=i;}}
  if(best>.008f&&fitted.count<48){nearest=fitted.count++;memcpy(fitted.nodes[nearest].feature,feature,sizeof(feature));}auto& node=fitted.nodes[nearest];unsigned n=++nodeSamples[nearest];float a=1.f/n;node.weight[0]+=(cosf(angle)-node.weight[0])*a;node.weight[1]+=(sinf(angle)-node.weight[1])*a;
 }
 bool observe(unsigned sample,ULONGLONG now,V shoulder,V hand,V elbow,M controller,Pose right,Pose left,M rootBasis,float worldScale){
  if(!phase||sample==lastSample||!sample||!finite(shoulder)||!finite(hand)||!finite(elbow)||!valid(controller)||!valid(rootBasis)||!std::isfinite(worldScale)||worldScale<.1f)return false;lastSample=sample;
  // The user starts in the reference pose. Record the first valid sample immediately;
  // controller mounting orientation and avatar shoulder estimates must not gate capture.
  if(!anchored){neutralHand=hand;neutralElbow=elbow;neutralController=controller;
   anchor=shoulder;bodyBasis=rootBasis;scale=worldScale;const V offsets[16]={{.08f,-.32f,.25f},{.28f,-.25f,.3f},{.05f,-.1f,.4f},{.18f,.05f,.45f},{-.2f,-.05f,.35f},{-.3f,.15f,.3f},{.05f,.3f,.3f},{.25f,.25f,.3f},{.4f,0,.18f},{.35f,-.12f,.08f},{-.12f,-.28f,.2f},{.12f,.12f,.2f},{.25f,.1f,.35f},{-.12f,.08f,.4f},{.15f,-.15f,.25f},{.05f,.2f,.4f}};for(unsigned i=0;i<16;++i)target[i]=add(anchor,world(bodyBasis,mul(offsets[i],scale)));anchored=true;previous=hand;lastTick=now;}
  float dt=float(now-lastTick)/1000;V velocity=dt>.001f&&dt<.2f?mul(sub(hand,previous),1/(dt*worldScale)):V{};previous=hand;lastTick=now;float upper=length(sub(elbow,shoulder))/worldScale,lower=length(sub(hand,elbow))/worldScale,reach=length(sub(hand,shoulder))/worldScale;V axis=unit(sub(hand,shoulder)),bend=sub(elbow,shoulder);bend=sub(bend,mul(axis,dot(axis,bend)));
  bool accepted=upper>.12f&&upper<.55f&&lower>.12f&&lower<.6f&&reach>.12f&&reach<.85f&&length(bend)>.045f*worldScale&&length(velocity)<2.5f;int hit=-1;float nearest=.095f*scale;for(unsigned i=0;i<(complete(false)>=8?16u:12u);++i){float d=length(sub(hand,target[i]));if(d<nearest){nearest=d;hit=int(i);}}
  M localController=relative(rootBasis,controller);V localShoulder{},localHand=mul(local(rootBasis,sub(hand,shoulder)),1/worldScale),localElbow=mul(local(rootBasis,sub(elbow,shoulder)),1/worldScale);
  if(accepted){fit(localShoulder,localHand,localElbow,localController);if(phase==1)++armSamples;else ++wristSamples;if(hit>=0)coverage[hit].observe(phase,local(rootBasis,velocity),localController,localElbow);}
  if(file){fprintf(file,"%llu,%u,%u,%u,%d",now-started,phase,sample,accepted?1:0,hit);auto vec=[&](V v){fprintf(file,",%.7g,%.7g,%.7g",v.x,v.y,v.z);};auto pose=[&](Pose p){vec(p.p);vec(p.b.r);vec(p.b.u);vec(p.b.f);};vec(shoulder);vec(hand);vec(elbow);vec(rootBasis.r);vec(rootBasis.u);vec(rootBasis.f);pose(right);pose(left);fputc('\n',file);if(rows==0||now-flushed>1000){if(fflush(file)||ferror(file))error=true;flushed=now;}++rows;}
  return accepted;
 }
 unsigned complete(bool wrist)const{unsigned n=0;for(auto& c:coverage)if(c.armGood()&&(!wrist||c.wristGood()))++n;return n;}
 bool result(bool applied){char summary[MAX_PATH];sprintf_s(summary,"%s.summary.txt",dataPath);FILE* out=nullptr;if(!fopen_s(&out,summary,"w")&&out){fprintf(out,"RawSamples=%u\nArmSamples=%u\nWristSamples=%u\nArmTargetsComplete=%u\nWristTargetsComplete=%u\nProfileApplied=%u\nWriteError=%u\n",rows,armSamples,wristSamples,complete(false),complete(true),applied?1:0,error?1:0);fprintf(out,"Result=%s\n",saveReason);fprintf(out,"WorldScale=%.6g\nRawControllerSpace=physical stage with native +Z forward\n",scale);fprintf(out,"NeutralHand=%.6g %.6g %.6g\nNeutralElbowMarker=%.6g %.6g %.6g\n",neutralHand.x,neutralHand.y,neutralHand.z,neutralElbow.x,neutralElbow.y,neutralElbow.z);for(unsigned i=0;i<16;++i){auto& c=coverage[i];fprintf(out,"Target%u: samples=%u directions=%u wrist=%u roll=%.3f bend=%.3f\n",i+1,c.samples,c.directions,c.wristSamples,c.roll,c.bend);}fclose(out);}return applied;}
 bool finish(){if(!phase)return false;phase=0;active=false;if(file){if(fflush(file)||ferror(file))error=true;if(fclose(file))error=true;file=nullptr;}bool enough=!error&&fitted.count>=8&&armSamples>=120&&wristSamples>=60&&complete(false)>=6&&complete(true)>=3;if(!enough){saveReason=error?"raw data write failed":"coverage incomplete";return result(false);}
  char temp[MAX_PATH],backup[MAX_PATH];sprintf_s(temp,"%s.tmp",profilePath);sprintf_s(backup,"%s.previous",profilePath);FILE* out=nullptr;if(fopen_s(&out,temp,"w")||!out){saveReason="profile temporary file open failed";return result(false);}fprintf(out,"RFGRVR_ELBOW_PROFILE 2 %u\n",fitted.count);for(unsigned i=0;i<fitted.count;++i){for(float v:fitted.nodes[i].feature)fprintf(out,"%.8g ",v);fprintf(out,"%.8g %.8g\n",fitted.nodes[i].weight[0],fitted.nodes[i].weight[1]);}bool ok=!ferror(out);if(fclose(out))ok=false;RFGRVRElbowProfile check;if(!ok||!check.load(temp)){saveReason="profile validation failed";DeleteFileA(temp);return result(false);}if(GetFileAttributesA(profilePath)!=INVALID_FILE_ATTRIBUTES&&!CopyFileA(profilePath,backup,FALSE)){saveReason="previous profile backup failed";DeleteFileA(temp);return result(false);}installedProfile=MoveFileExA(temp,profilePath,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;saveReason=installedProfile?"profile applied":"profile replace failed";return result(installedProfile);
 }
 void packet(const Pose& physicalHand,const Pose& gameHand,float worldScale){Markers out;out.pid=GetCurrentProcessId();out.tick=GetTickCount();out.phase=phase;out.count=phase&&anchored?(complete(false)>=8?16:12):0;for(unsigned i=0;i<out.count;++i){V p=add(physicalHand.p,world(physicalHand.b,mul(local(gameHand.b,sub(target[i],gameHand.p)),1/worldScale)));out.points[i][0]=p.x;out.points[i][1]=p.y;out.points[i][2]=-p.z;out.state[i]=(phase==1?coverage[i].armGood():coverage[i].armGood()&&coverage[i].wristGood())?2:(coverage[i].samples||coverage[i].wristSamples)?1:0;}publish(out);}
};
}
