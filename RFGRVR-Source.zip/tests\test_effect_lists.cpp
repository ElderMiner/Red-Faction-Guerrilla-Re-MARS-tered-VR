#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../src/vr_effect_lists.h"
int main(){using namespace RFGRVREffects;std::vector<unsigned> out;assert(merge(out,{1,2},{2,3},3));assert((out==std::vector<unsigned>{1,2,3}));assert(!merge(out,{1,2},{3},2));unsigned char manager[0xb520]{};unsigned buffers[5][8]{};for(unsigned i=0;i<5;++i){unsigned data=(unsigned)(uintptr_t)buffers[i],cap=8,n=2;memcpy(manager+listOffsets[i]+4,&data,4);memcpy(manager+listOffsets[i]+8,&cap,4);memcpy(manager+listOffsets[i]+12,&n,4);buffers[i][0]=10+i;buffers[i][1]=20+i;}Snapshot saved;capture(manager,saved);for(unsigned i=0;i<5;++i){buffers[i][0]=20+i;buffers[i][1]=30+i;}assert(apply(manager,saved));for(unsigned i=0;i<5;++i){assert(word(manager,listOffsets[i]+12)==3);assert(buffers[i][0]==10+i&&buffers[i][1]==20+i&&buffers[i][2]==30+i);}assert(!apply(manager+4,saved));unsigned bad=100000;memcpy(manager+listOffsets[4]+8,&bad,4);assert(!apply(manager,saved));}
