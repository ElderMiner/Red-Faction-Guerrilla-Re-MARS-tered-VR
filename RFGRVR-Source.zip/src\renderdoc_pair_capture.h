#pragma once
#include <windows.h>
#include <cstdio>
#include "../../tools/renderdoc-1.46/RenderDoc_1.46_64/renderdoc_app.h"
namespace RFGRVRPairCapture {
inline RENDERDOC_API_1_7_0* api=nullptr;
inline bool rootPath(char (&path)[MAX_PATH],const char* suffix){GetModuleFileNameA(nullptr,path,MAX_PATH);auto* slash=strrchr(path,'\\');if(!slash)return false;strcpy_s(slash+1,MAX_PATH-(slash+1-path),suffix);return true;}
inline bool begin(){
 char gate[MAX_PATH]{};if(!rootPath(gate,"RFGRVR-renderdoc.capture")||GetFileAttributesA(gate)==INVALID_FILE_ATTRIBUTES)return false;
 auto module=GetModuleHandleW(L"renderdoc.dll");if(!module)return false;
 if(!api){auto get=(pRENDERDOC_GetAPI)GetProcAddress(module,"RENDERDOC_GetAPI");if(!get||get(eRENDERDOC_API_Version_1_7_0,(void**)&api)!=1)return false;}
 if(api->IsFrameCapturing())return false;
 char suffix[128]{},path[MAX_PATH]{};sprintf_s(suffix,"vr-research\\output\\scene-pair-%lu",GetCurrentProcessId());if(!rootPath(path,suffix))return false;
 api->SetCaptureFilePathTemplate(path);api->StartFrameCapture(nullptr,nullptr);return api->IsFrameCapturing()!=0;
}
inline void end(bool attempted){
 if(!api)return;if(!attempted){api->DiscardFrameCapture(nullptr,nullptr);return;}
 unsigned ok=api->EndFrameCapture(nullptr,nullptr);char path[MAX_PATH]{};
 if(rootPath(path,"vr-research\\output\\scene-pair-capture-status.txt")){FILE* f=nullptr;if(!fopen_s(&f,path,"a")&&f){fprintf(f,"pid=%lu pair-attempted=1 capture-success=%u captures=%u\n",GetCurrentProcessId(),ok,api->GetNumCaptures());fclose(f);}}
 if(ok&&rootPath(path,"RFGRVR-renderdoc.capture"))DeleteFileA(path);
}
}
