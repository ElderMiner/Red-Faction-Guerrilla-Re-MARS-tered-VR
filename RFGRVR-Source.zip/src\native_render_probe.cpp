// v7.5: read-only renderer-boundary probe. Does NOT replay or modify rendering.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <atomic>
#include "../vendor/MinHook.h"
namespace {
static void* gSceneOriginal=nullptr;
static void* gWorkerOriginal=nullptr;
static std::atomic<unsigned> sceneCalls{0},workerCalls{0}, sceneThread{0},workerThread{0};
static std::atomic<unsigned> sceneThis{0}, workerThis{0}, sceneArg0{0}, workerArg0{0};
static std::atomic<unsigned> installStatus{0};
static unsigned prevScene=0,prevWorker=0;static unsigned presentIndex=0;
// v7.5.5 camera/renderer correlation. All hook callbacks record atomic summaries only.
static std::atomic<unsigned> cameraBeginCalls{0},cameraEndCalls{0};
static std::atomic<unsigned> cameraThread{0},lastCamera{0},lastCameraRenderer{0};
static std::atomic<unsigned> cameraBeginHash{0},cameraEndHash{0},cameraBeginXYZHash{0},cameraEndXYZHash{0};
static std::atomic<unsigned> cameraBeginTick{0},cameraEndTick{0};
static std::atomic<unsigned> workerCamera{0},sceneCamera{0},workerCameraMatchesLast{0};
static std::atomic<unsigned> workerCameraReads{0},sceneCameraReads{0},badCameraReads{0};
static std::atomic<unsigned> workerCameraHash{0},sceneCameraHash{0};
static std::atomic<unsigned> sceneCameraChanges{0},workerCameraChanges{0};
static unsigned previousSceneCamera=0,previousWorkerCamera=0;
static bool readableBlock(const void* p,unsigned n){
 if(!p || (uintptr_t)p<0x10000u)return false;
 MEMORY_BASIC_INFORMATION m={};if(!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||
    (m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 uintptr_t addr=(uintptr_t)p,start=(uintptr_t)m.BaseAddress;
 return addr>=start && addr-start<=m.RegionSize && n<=m.RegionSize-(addr-start);
}
static unsigned hashBlock(const unsigned char* p,unsigned n){
 if(!readableBlock(p,n))return 0;
 unsigned v=2166136261u;
 for(unsigned i=0;i<n;++i){v^=p[i];v*=16777619u;}
 return v;
}
// RSL Part2Params p_camera is at renderer +0x4BBBC in this executable build.
// This offset is a hypothesis to be tested, not an asserted validated view matrix.
static unsigned parameterCamera(unsigned renderer){
 const auto* slot=(const unsigned char*)(uintptr_t)renderer+0x4BBBC;
 if(!readableBlock(slot,4))return 0;
 unsigned cam=0;memcpy(&cam,slot,sizeof(cam));
 if(!readableBlock((const void*)(uintptr_t)cam,0x140))return 0;
 return cam;
}
static void recordCameraBegin(void* camera,void* renderer){
 cameraBeginCalls.fetch_add(1,std::memory_order_relaxed);
 cameraThread.store(GetCurrentThreadId());
 lastCamera.store((unsigned)(uintptr_t)camera);
 lastCameraRenderer.store((unsigned)(uintptr_t)renderer);
 cameraBeginTick.store(GetTickCount());
 cameraBeginHash.store(hashBlock((const unsigned char*)camera+0x100,64));
 cameraBeginXYZHash.store(hashBlock((const unsigned char*)camera+0x2C,12));
}
static void recordCameraEnd(void* camera){
 cameraEndCalls.fetch_add(1,std::memory_order_relaxed);
 cameraEndTick.store(GetTickCount());
 cameraEndHash.store(hashBlock((const unsigned char*)camera+0x100,64));
 cameraEndXYZHash.store(hashBlock((const unsigned char*)camera+0x2C,12));
}

// Record exact live bytes before making any decision about installing hooks.
constexpr unsigned kSceneRva=0x161D20, kWorkerRva=0x1601B0;
constexpr unsigned kByteCount=20;
static unsigned char sceneAtInstall[kByteCount]={},workerAtInstall[kByteCount]={};
static unsigned sceneReadable=0,workerReadable=0,sceneProtection=0,workerProtection=0;
static unsigned sceneMatches=0,workerMatches=0;
static unsigned createSceneResult=0xFFFFFFFFu,createWorkerResult=0xFFFFFFFFu;
static unsigned enableSceneResult=0xFFFFFFFFu,enableWorkerResult=0xFFFFFFFFu;
static const unsigned char sceneExpected[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x81,0xec,0xc4,0x05,0,0};
static const unsigned char workerExpected[]={0x81,0xec,0x0c,0x01,0x00,0x00,0xa1,0x70,0x54,0x4b,0x02,0x33,0xc4,0x89};
static unsigned capture(const unsigned char* base,unsigned rva,unsigned char* dst,unsigned* protect){
 MEMORY_BASIC_INFORMATION m={};const unsigned char* p=base+rva;
 if(!VirtualQuery(p,&m,sizeof(m)))return 0;
 *protect=m.Protect;
 const uintptr_t addr=(uintptr_t)p,begin=(uintptr_t)m.BaseAddress;
 if(m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))||
    addr<begin||addr-begin>m.RegionSize||kByteCount>m.RegionSize-(addr-begin))return 0;
 memcpy(dst,p,kByteCount);return 1;
}
static void hex(const unsigned char* bytes,unsigned size,char* out,size_t outSize){
 if(outSize<size_t(size)*2+1)return;
 static const char digits[]="0123456789ABCDEF";
 for(unsigned i=0;i<size;++i){out[i*2]=digits[bytes[i]>>4];out[i*2+1]=digits[bytes[i]&15];}
 out[size*2]=0;
}
static void writeHookReport(const char* event){
 wchar_t file[MAX_PATH]={};if(!GetModuleFileNameW(nullptr,file,MAX_PATH))return;
 wchar_t* slash=wcsrchr(file,L'\\');if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(size_t)(slash+1-file),L"RFGRVR-Hook-Bytes-v7.5.3.csv");
 FILE* out=nullptr;if(_wfopen_s(&out,file,L"a")!=0||!out)return;
 if(_ftelli64(out)==0)fputs("event,status,scene_readable,worker_readable,scene_match,worker_match,scene_protect,worker_protect,scene_bytes,worker_bytes,scene_expected,worker_expected,create_scene,create_worker,enable_scene,enable_worker\n",out);
 char sceneHex[kByteCount*2+1]={},workerHex[kByteCount*2+1]={};
 char sceneExp[sizeof(sceneExpected)*2+1]={},workerExp[sizeof(workerExpected)*2+1]={};
 hex(sceneAtInstall,kByteCount,sceneHex,sizeof(sceneHex));hex(workerAtInstall,kByteCount,workerHex,sizeof(workerHex));
 hex(sceneExpected,sizeof(sceneExpected),sceneExp,sizeof(sceneExp));hex(workerExpected,sizeof(workerExpected),workerExp,sizeof(workerExp));
 fprintf(out,"%s,%u,%u,%u,%u,%u,%08X,%08X,%s,%s,%s,%s,%u,%u,%u,%u\n",event,
 installStatus.load(),sceneReadable,workerReadable,sceneMatches,workerMatches,sceneProtection,workerProtection,
 sceneHex,workerHex,sceneExp,workerExp,createSceneResult,createWorkerResult,enableSceneResult,enableWorkerResult);
 fclose(out);
}
// pushfd/pushad preserves every register and flags before returning control to the engine.
// saved[6]=ECX (member this); saved[3]=ESP immediately after pushfd; saved[3]+4 points to the entry return address.
extern "C" __declspec(noinline) void __cdecl RecordScene(const unsigned* saved){
 sceneCalls.fetch_add(1,std::memory_order_relaxed);sceneThread.store(GetCurrentThreadId());
 sceneThis.store(saved[6]);
 if((sceneCalls.load(std::memory_order_relaxed)&15u)==0){
  unsigned cam=parameterCamera(saved[6]);
  if(cam){sceneCameraReads.fetch_add(1);sceneCamera.store(cam);
   if(previousSceneCamera!=cam){sceneCameraChanges.fetch_add(1);previousSceneCamera=cam;}
   sceneCameraHash.store(hashBlock((const unsigned char*)(uintptr_t)cam+0x100,64));
  }else badCameraReads.fetch_add(1);
 }
 const unsigned* stack=(const unsigned*)(uintptr_t)(saved[3]+4u);
 MEMORY_BASIC_INFORMATION mbi={};if(VirtualQuery(stack,&mbi,sizeof(mbi))&&mbi.State==MEM_COMMIT&&!(mbi.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&
 (uintptr_t)stack+8<=(uintptr_t)mbi.BaseAddress+mbi.RegionSize)sceneArg0.store(stack[1]);
}
extern "C" __declspec(noinline) void __cdecl RecordWorker(const unsigned* saved){
 workerCalls.fetch_add(1,std::memory_order_relaxed);workerThread.store(GetCurrentThreadId());workerThis.store(saved[6]);
 if((workerCalls.load(std::memory_order_relaxed)&15u)==0){
  unsigned cam=parameterCamera(saved[6]);
  if(cam){workerCameraReads.fetch_add(1);workerCamera.store(cam);
   if(previousWorkerCamera!=cam){workerCameraChanges.fetch_add(1);previousWorkerCamera=cam;}
   workerCameraHash.store(hashBlock((const unsigned char*)(uintptr_t)cam+0x100,64));
   if(cam==lastCamera.load())workerCameraMatchesLast.fetch_add(1);
  }else badCameraReads.fetch_add(1);
 }
 const unsigned* stack=(const unsigned*)(uintptr_t)(saved[3]+4u);MEMORY_BASIC_INFORMATION mbi={};
 if(VirtualQuery(stack,&mbi,sizeof(mbi))&&mbi.State==MEM_COMMIT&&!(mbi.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&
 (uintptr_t)stack+8<=(uintptr_t)mbi.BaseAddress+mbi.RegionSize)workerArg0.store(stack[1]);
}
extern "C" __declspec(naked) void SceneDetour() {
    __asm {
        pushfd
        pushad
        mov eax, esp
        push eax
        call RecordScene
        add esp, 4
        popad
        popfd
        jmp dword ptr [gSceneOriginal]
    }
}
extern "C" __declspec(naked) void WorkerDetour() {
    __asm {
        pushfd
        pushad
        mov eax, esp
        push eax
        call RecordWorker
        add esp, 4
        popad
        popfd
        jmp dword ptr [gWorkerOriginal]
    }
}
}
extern "C" void RFGRVR_EngineProbe_CameraBegin(void* camera,void* renderer){recordCameraBegin(camera,renderer);}
extern "C" void RFGRVR_EngineProbe_CameraEnd(void* camera){recordCameraEnd(camera);}
extern "C" void RFGRVR_EngineProbe_Install(){
 if(sizeof(void*)!=4){installStatus.store(1);writeHookReport("wrong_pointer_size");return;}
 const auto* base=(const unsigned char*)GetModuleHandleW(nullptr);
 if(!base){installStatus.store(2);writeHookReport("module_not_found");return;}
 sceneReadable=capture(base,kSceneRva,sceneAtInstall,&sceneProtection);
 workerReadable=capture(base,kWorkerRva,workerAtInstall,&workerProtection);
 sceneMatches=sceneReadable&&memcmp(sceneAtInstall,sceneExpected,sizeof(sceneExpected))==0;
 // +7 is a relocated absolute security-cookie address, not fixed signature bytes.
 // Check the opcodes and validate the operand against this loaded module base.
 unsigned cookie=0;memcpy(&cookie,workerAtInstall+7,4);
 workerMatches=workerReadable&&memcmp(workerAtInstall,workerExpected,7)==0&&
  memcmp(workerAtInstall+11,workerExpected+11,sizeof(workerExpected)-11)==0&&
  cookie==(unsigned)(uintptr_t)(base+0x1635470);
 if(!sceneMatches||!workerMatches){installStatus.store(3);writeHookReport("signature_rejected");return;}
 // Scene entry is owned by native_scene.cpp; never install a second detour there.
 createSceneResult=(unsigned)MH_OK;enableSceneResult=(unsigned)MH_OK;
 createWorkerResult=(unsigned)MH_CreateHook((void*)(base+kWorkerRva),(void*)&WorkerDetour,(void**)&gWorkerOriginal);
 if(createWorkerResult!=(unsigned)MH_OK){installStatus.store(5);writeHookReport("worker_create_failed");return;}
 enableWorkerResult=(unsigned)MH_EnableHook((void*)(base+kWorkerRva));
 if(enableWorkerResult!=(unsigned)MH_OK){installStatus.store(7);writeHookReport("worker_enable_failed");return;}
 installStatus.store(100);writeHookReport("worker_hook_installed_scene_owned_by_stereo");
}
extern "C" void RFGRVR_EngineProbe_Present(){
 const unsigned f=++presentIndex;if(f%120)return;
 const unsigned sc=sceneCalls.load(),wc=workerCalls.load();
 wchar_t file[MAX_PATH]={}; if(!GetModuleFileNameW(nullptr,file,MAX_PATH))return;
 wchar_t* slash=wcsrchr(file,L'\\');if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(size_t)(slash+1-file),L"RFGRVR-Engine-Validation-v7.5.csv");
 FILE* out=nullptr;if(_wfopen_s(&out,file,L"a")!=0||!out)return;
 if(_ftelli64(out)==0)fputs("present,hook_status,scene_total,worker_total,scene_delta,worker_delta,scene_tid,worker_tid,scene_this,worker_this,scene_arg0,worker_arg0\n",out);
 fprintf(out,"%u,%u,%u,%u,%u,%u,%u,%u,%08X,%08X,%08X,%08X\n",f,installStatus.load(),sc,wc,sc-prevScene,wc-prevWorker,
 sceneThread.load(),workerThread.load(),sceneThis.load(),workerThis.load(),sceneArg0.load(),workerArg0.load());
 fclose(out);prevScene=sc;prevWorker=wc;
}

extern "C" void RFGRVR_EngineProbe_CorrelationPresent(){
 static unsigned frame=0;if(++frame%120u)return;
 wchar_t path[MAX_PATH]={};if(!GetModuleFileNameW(nullptr,path,MAX_PATH))return;
 wchar_t* slash=wcsrchr(path,L'\\');if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(size_t)(slash+1-path),L"RFGRVR-Native-Camera-Correlation-v7.5.5.csv");
 FILE* f=nullptr;if(_wfopen_s(&f,path,L"a")!=0||!f)return;
 if(_ftelli64(f)==0)fputs("present,scene_calls,worker_calls,camera_begin,camera_end,scene_thread,worker_thread,camera_thread,scene_this,worker_this,begin_renderer,begin_camera,scene_param_camera,worker_param_camera,scene_param_reads,worker_param_reads,worker_camera_matched_last,invalid_reads,scene_camera_changes,worker_camera_changes,begin_tick,end_tick,begin_matrix_hash,end_matrix_hash,scene_matrix_hash,worker_matrix_hash,begin_xyz_hash,end_xyz_hash\n",f);
 fprintf(f,"%u,%u,%u,%u,%u,%u,%u,%u,%08X,%08X,%08X,%08X,%08X,%08X,%u,%u,%u,%u,%u,%u,%u,%u,%08X,%08X,%08X,%08X,%08X,%08X\n",
 frame,sceneCalls.load(),workerCalls.load(),cameraBeginCalls.load(),cameraEndCalls.load(),
 sceneThread.load(),workerThread.load(),cameraThread.load(),sceneThis.load(),workerThis.load(),
 lastCameraRenderer.load(),lastCamera.load(),sceneCamera.load(),workerCamera.load(),
 sceneCameraReads.load(),workerCameraReads.load(),workerCameraMatchesLast.load(),badCameraReads.load(),
 sceneCameraChanges.load(),workerCameraChanges.load(),cameraBeginTick.load(),cameraEndTick.load(),
 cameraBeginHash.load(),cameraEndHash.load(),sceneCameraHash.load(),workerCameraHash.load(),
 cameraBeginXYZHash.load(),cameraEndXYZHash.load());
 fclose(f);
}
