#include "../src/stereo_ring_lifetime.cpp"
#include <cassert>
#include <cstring>
using namespace ringlife;
static unsigned draws=0,ordinaryCalls=0,skippedCalls=0;
static void __cdecl Ordinary(){++ordinaryCalls;}
static void __cdecl Skipped(){++skippedCalls;}
static void __fastcall DrawMock(void* ring,void*,void*,unsigned topology,unsigned start,unsigned primitives,unsigned blocks,bool fromRing){
 ++draws;if(fromRing&&!holdCurrent){*(unsigned*)((char*)ring+0x68)-=blocks;*(unsigned*)((char*)ring+0x64)=start+primitives*2*28;}
}
int main(){
 module=(unsigned char*)VirtualAlloc(nullptr,0x1100000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);assert(module);
 *(unsigned*)(module+0x14cb60)=(unsigned)(uintptr_t)(module+0x14cb00);*(unsigned*)(module+0x14cb64)=(unsigned)(uintptr_t)(module+0x14cb06);
 memset(module+0x14cb68,0,11);*(unsigned*)(module+0x10fa34c)=28;
 unsigned char ring[0x80]{};*(unsigned*)(ring+0x14)=1024;*(unsigned*)(ring+0x60)=268;*(unsigned*)(ring+0x64)=100;*(unsigned*)(ring+0x68)=2;
 originalDraw=(Draw)&DrawMock;RFGRVR_RingPair_Begin();OnDraw(ring,nullptr,nullptr,0,100,3,2,true);
 assert(draws==1&&*(unsigned*)(ring+0x68)==2&&*(unsigned*)(ring+0x64)==100);
 OnDraw(ring,nullptr,nullptr,0,100,3,2,true);assert(draws==2&&count==1&&duplicates==1&&*(unsigned*)(ring+0x68)==2);
 RFGRVR_RingPair_End();assert(*(unsigned*)(ring+0x68)==0&&*(unsigned*)(ring+0x64)==268);
 *(unsigned*)(ring+0x68)=2;OnDraw(ring,nullptr,nullptr,0,100,3,2,true);assert(*(unsigned*)(ring+0x68)==0);
 // The naked mid-function gate preserves both ordinary and deferred continuations.
 originalRetire=(void*)&Ordinary;skipRetire=(void*)&Skipped;holdCurrent=false;RetirementGate();holdCurrent=true;RetirementGate();holdCurrent=false;
 assert(ordinaryCalls==1&&skippedCalls==1);VirtualFree(module,0,MEM_RELEASE);
}
