#pragma once
#include "vr_mapping.h"
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <cstring>
inline constexpr wchar_t RFGR_PROP_MARKERS[]=L"Local\\RFGRVR_PropaneMarkers_v1";
struct RFGRPropMarkers {LONG sequence=0;DWORD magic=0x504d4b31,tick=0;unsigned count=0,selected=0;float point[3][3]{};};
inline void RFGRVR_PublishPropMarkers(const RFGRPropMarkers& value){static HANDLE mapping=nullptr;static RFGRPropMarkers* data=nullptr;if(!data){if(!mapping)mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(*data),RFGR_PROP_MARKERS);if(mapping)data=(RFGRPropMarkers*)RFGRVR_MapViewOrClose(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(*data));}if(!data)return;InterlockedIncrement(&data->sequence);MemoryBarrier();memcpy((char*)data+4,(const char*)&value+4,sizeof(value)-4);MemoryBarrier();InterlockedIncrement(&data->sequence);}
struct RFGRPropMarkersReader {HANDLE mapping=nullptr;const RFGRPropMarkers* data=nullptr;~RFGRPropMarkersReader(){if(data)UnmapViewOfFile(data);if(mapping)CloseHandle(mapping);}bool read(RFGRPropMarkers& value){if(!data){if(!mapping)mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_PROP_MARKERS);if(mapping)data=(const RFGRPropMarkers*)RFGRVR_MapViewOrClose(mapping,FILE_MAP_READ,0,0,sizeof(*data));}if(!data)return false;for(int i=0;i<3;++i){LONG sequence=data->sequence;if(sequence&1)continue;MemoryBarrier();value=*data;MemoryBarrier();if(sequence==data->sequence)return value.magic==0x504d4b31&&value.count<=3&&DWORD(GetTickCount()-value.tick)<150;}return false;}};
