#define NOMINMAX
#include "../src/render_window_profile.h"
#include <cassert>
LRESULT CALLBACK stock(HWND w,UINT m,WPARAM p,LPARAM l){if(m==WM_GETMINMAXINFO){auto* v=(MINMAXINFO*)l;v->ptMaxTrackSize={800,600};return 0;}return DefWindowProcW(w,m,p,l);}
int main(){WNDCLASSW c{};c.lpfnWndProc=stock;c.lpszClassName=L"RFGRRenderSizeTest";c.hInstance=GetModuleHandleW(nullptr);RegisterClassW(&c);auto w=CreateWindowW(c.lpszClassName,L"",WS_OVERLAPPEDWINDOW,0,0,640,480,0,0,c.hInstance,0);assert(w);RFGRVRRenderWindow::attach(w);RFGRVRRenderWindow::width=1200;RFGRVRRenderWindow::height=1000;SendMessageW(w,RFGRVRRenderWindow::requestMessage,RFGRVRRenderWindow::requestMagic,0);RECT r{};GetClientRect(w,&r);assert(r.right==1280&&r.bottom==720);SetWindowPos(w,nullptr,0,0,720,500,SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);GetClientRect(w,&r);assert(r.right==1280&&r.bottom==720);assert(RFGRVRRenderWindow::ready(1200,1000));assert(!RFGRVRRenderWindow::ready(1200,999));RFGRVRRenderWindow::width=0;RFGRVRRenderWindow::height=0;SendMessageW(w,RFGRVRRenderWindow::requestMessage,RFGRVRRenderWindow::requestMagic,0);GetClientRect(w,&r);assert((unsigned)r.right==RFGRVRRenderWindow::baseWidth&&(unsigned)r.bottom==RFGRVRRenderWindow::baseHeight);DestroyWindow(w);}


