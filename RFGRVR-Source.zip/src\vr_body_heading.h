#pragma once
#include <cmath>
inline float RFGRVR_WrapYaw(float v){return std::remainder(v,6.283185307f);}
struct RFGRVRBodyHeading {
 float yaw=0,previousHead=0;bool ready=false;
 float update(float head,float dt,bool moving,bool turning){
  if(!std::isfinite(head))return yaw;
  if(!ready){yaw=previousHead=head;ready=true;return yaw;}
  if(!std::isfinite(dt)||dt<0)dt=0;if(dt>.05f)dt=.05f;
  if(turning)yaw=RFGRVR_WrapYaw(yaw+RFGRVR_WrapYaw(head-previousHead));
  if(moving){yaw=head;previousHead=head;return yaw;}
  float delta=RFGRVR_WrapYaw(head-yaw),target=delta>1.309f?delta-1.309f:delta< -1.309f?delta+1.309f:0;
  float step=dt*3.5f;if(target>step)target=step;if(target< -step)target=-step;
  yaw=RFGRVR_WrapYaw(yaw+target);previousHead=head;return yaw;
 }
};
