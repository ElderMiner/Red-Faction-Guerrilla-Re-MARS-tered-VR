#include "../src/vr_controller_coast.h"
#include "../src/vr_charge_trim.h"
#include "../src/vr_neutral_pose.h"
#include <cassert>
#include "../src/vr_adjust_direction.h"
int main(){RFGRVRAdjustDirection direction;assert(direction.sign()==1);assert(direction.update(true,true)&&direction.sign()==-1);for(int i=0;i<20;++i)assert(!direction.update(true,true)&&direction.sign()==-1);assert(!direction.update(false,true));assert(direction.update(true,true)&&direction.sign()==1);direction.update(false,false);assert(!direction.update(true,false)&&direction.sign()==1);assert(!direction.update(true,true)&&direction.sign()==1);direction.update(false,true);assert(direction.update(true,true)&&direction.sign()==-1);RFGRVRControllerCoast c;assert(c.update(true,0,0,.01f));assert(c.update(false,.03f,0,.01f));for(int i=0;i<10;++i)assert(c.update(false,.03f+i*.005f,0,.01f));for(int i=0;i<14;++i)assert(c.update(false,.08f,0,.01f));for(int i=0;i<3;++i)c.update(false,.08f,0,.01f);assert(!c.active);
 using namespace vrarm;M id{{1,0,0},{0,1,0},{0,0,1}};RFGRVRChargeTrim t;for(int i=0;i<45;++i)t.adjust(0,true,1);t.adjust(1,false,1);V grip{.1f,0,0},hand{1,2,3};auto p=t.apply({id,{}},id,grip,hand);assert(length(sub(add(p.p,world(p.b,grip)),add(hand,V{0,.01f,0})))<.0001f);assert(fabsf(p.b.f.y+1)<.0001f);t.adjust(0,true,-1);assert(t.rotation[0]==88);
 M turned{{0,0,-1},{0,1,0},{1,0,0}};Pose body{turned,{0,1,0}},bone{turned,{1,1,0}};auto neutral=RFGRVR_NeutralBone(bone,body,1,relative(turned,id));assert(valid(neutral.b)&&length(sub(compose(turned,neutral.b).f,id.f))<.0001f);
}
