#define NOMINMAX
#include "vr_head_motion.h"
#include "vr_mapping.h"
#include "propane_markers.h"
#include "arm_training_markers.h"
#include "vr_gamepad_math.h"
#include "vr_scene_cache.h"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#define XR_NO_PROTOTYPES
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#pragma comment(lib,"d3dcompiler.lib")
#include <dxgi1_2.h>
#include "vr_fsr1.h"
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <array>
#include <algorithm>
#include <cstdint>
#pragma comment(lib,"gdi32.lib")
#pragma comment(lib,"user32.lib")
#include "ipc.h"
#include "vr_quest_layout.h"
#include "vr_index_layout.h"
#include "vr_weapon_selector.h"
#include "bridge_map_placement.h"
#include "vr_haptics.h"
#include "vr_calibration.h"
#include "bridge_vr_settings.h"
#include "bridge_desktop_settings.h"
#include "vr_notification_layout.h"
#include "vr_display_geometry.h"
#include "vr_boot_avatar_gpu.h"
#include "vr_boot_sequence.h"
#include "vr_floor_screen.h"
#include "vr_boot_text.h"
#pragma comment(lib,"d3d11.lib")
#pragma comment(lib,"dxgi.lib")

// A true OpenXR quad layer. No game-frame capture, shared DXGI vtable patching, or stereo spoofing.
// Renders RFGR-VR's own readable panel as a single binocularly aligned virtual plane.
static constexpr int PANEL_W=3840, PANEL_H=2160;
struct MenuPixels {
 HDC dc=nullptr; HBITMAP bmp=nullptr,original=nullptr; void* pixels=nullptr;
 MenuPixels(){
  dc=CreateCompatibleDC(nullptr);
  BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
  bi.bmiHeader.biWidth=PANEL_W;bi.bmiHeader.biHeight=-PANEL_H;
  bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
  bmp=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,&pixels,nullptr,0);
  if(dc&&bmp)original=(HBITMAP)SelectObject(dc,bmp);
  if(dc){SetMapMode(dc,MM_ANISOTROPIC);SetWindowExtEx(dc,960,540,nullptr);SetViewportExtEx(dc,PANEL_W,PANEL_H,nullptr);}
 }
 ~MenuPixels(){if(dc&&original)SelectObject(dc,original);if(bmp)DeleteObject(bmp);if(dc)DeleteDC(dc);}
 bool ready()const{return dc&&bmp&&pixels;}
 void calibration(float progress,bool poseValid,bool complete){
  RECT all{0,0,960,540};HBRUSH bg=CreateSolidBrush(RGB(13,23,34));FillRect(dc,&all,bg);DeleteObject(bg);
  SetBkMode(dc,TRANSPARENT);HFONT font=CreateFontW(-34,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");auto old=SelectObject(dc,font);SetTextColor(dc,RGB(240,250,253));
  RECT title{50,45,900,115};DrawTextW(dc,complete?L"Ready � starting the game":L"Calibrate your VR body",-1,&title,DT_LEFT|DT_WORDBREAK);
  SelectObject(dc,old);DeleteObject(font);font=CreateFontW(-25,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");old=SelectObject(dc,font);
  RECT instructions{50,150,535,390};DrawTextW(dc,complete?L"Calibration saved. Release both triggers.":L"Stand upright on your room floor.\n\nStretch both arms out in a T-pose.\n\nHold both triggers for one second.",-1,&instructions,DT_LEFT|DT_WORDBREAK);
  RECT status{50,430,900,500};SetTextColor(dc,RGB(135,220,210));DrawTextW(dc,complete?L"Your room setup controls floor and forward.":poseValid?L"T-pose detected. Hold both triggers.":L"Keep both controllers tracked and level with your shoulders.",-1,&status,DT_LEFT|DT_WORDBREAK);
  HPEN pen=CreatePen(PS_SOLID,8,RGB(110,215,210));auto previous=SelectObject(dc,pen);auto brush=SelectObject(dc,GetStockObject(HOLLOW_BRUSH));
  Ellipse(dc,690,155,750,215);MoveToEx(dc,720,215,nullptr);LineTo(dc,720,350);MoveToEx(dc,590,245,nullptr);LineTo(dc,850,245);MoveToEx(dc,720,350,nullptr);LineTo(dc,675,410);MoveToEx(dc,720,350,nullptr);LineTo(dc,765,410);
  SelectObject(dc,previous);SelectObject(dc,brush);DeleteObject(pen);
  RECT bar{50,505,LONG(50+850*progress),515};HBRUSH fill=CreateSolidBrush(RGB(60,200,170));FillRect(dc,&bar,fill);DeleteObject(fill);
  SelectObject(dc,old);DeleteObject(font);auto* bytes=(unsigned char*)pixels;for(int i=0;i<PANEL_W*PANEL_H;++i)bytes[i*4+3]=255;
 }
 void render(bool gameActive,bool hmdActive,bool leftActive,bool rightActive,unsigned long frames){
  RECT all{0,0,PANEL_W,PANEL_H};HBRUSH bg=CreateSolidBrush(RGB(13,23,34));FillRect(dc,&all,bg);DeleteObject(bg);
  RECT bar{0,0,PANEL_W,16};HBRUSH accent=CreateSolidBrush(RGB(30,180,174));FillRect(dc,&bar,accent);DeleteObject(accent);
  SetBkMode(dc,TRANSPARENT);
  HFONT title=CreateFontW(-48,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
  HFONT textFont=CreateFontW(-27,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
  HFONT tiny=CreateFontW(-22,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Consolas");
  HGDIOBJ old=SelectObject(dc,title);SetTextColor(dc,RGB(240,250,253));TextOutW(dc,55,47,L"RFGR-VR  |  Native Control Panel",32);
  SelectObject(dc,textFont);SetTextColor(dc,RGB(160,222,224));
  TextOutW(dc,57,130,L"Headset-aligned menu view",25);
  wchar_t line[160];
  swprintf_s(line,L"Game: %ls     HMD: %ls",gameActive?L"CONNECTED":L"NOT RUNNING",hmdActive?L"TRACKED":L"WAITING");
  SetTextColor(dc,RGB(234,241,248));TextOutW(dc,57,190,line,(int)wcslen(line));
  swprintf_s(line,L"Left controller: %ls     Right controller: %ls",leftActive?L"TRACKED":L"WAITING",rightActive?L"TRACKED":L"WAITING");
  TextOutW(dc,57,244,line,(int)wcslen(line));
  SetTextColor(dc,RGB(135,205,215));TextOutW(dc,57,324,L"F7  Toggle game / panel    ",26);
  {const wchar_t* hint=L"F5 Menu screen | F8 Head-look (starts on)";TextOutW(dc,57,359,hint,(int)wcslen(hint));}
  {const wchar_t* hint=L"F9 Recenter | Ctrl+Alt +/- Head-look gain";TextOutW(dc,57,394,hint,(int)wcslen(hint));}
  {const wchar_t* hint=L"Controller A: Enter   B: Back   Stick: Navigate";TextOutW(dc,57,434,hint,(int)wcslen(hint));}
  SelectObject(dc,tiny);SetTextColor(dc,RGB(158,177,192));
  swprintf_s(line,L"XR frames %lu  |  This panel is NOT game stereo output",frames);
  TextOutW(dc,57,485,line,(int)wcslen(line));
  SelectObject(dc,old);DeleteObject(title);DeleteObject(textFont);DeleteObject(tiny);
 }
};
static bool justPressed(int key,bool& previous){const bool down=(GetAsyncKeyState(key)&0x8000)!=0;const bool fire=down&&!previous;previous=down;return fire;}

static HANDLE mapHandle=nullptr;
static RFGRShared* shm=nullptr;
static void report(LONG state,const char* msg){
 if(shm){ InterlockedExchange(&shm->openxrState,state); strncpy_s(shm->status,sizeof(shm->status),msg,_TRUNCATE); }
 puts(msg);fflush(stdout);
}
static RFGRPose convert(const XrSpaceLocation& loc){
 RFGRPose p={};
 p.validFlags=((loc.locationFlags&XR_SPACE_LOCATION_ORIENTATION_VALID_BIT)?1u:0u)|((loc.locationFlags&XR_SPACE_LOCATION_POSITION_VALID_BIT)?2u:0u);
 if(p.validFlags&1){p.orientation[0]=loc.pose.orientation.x;p.orientation[1]=loc.pose.orientation.y;p.orientation[2]=loc.pose.orientation.z;p.orientation[3]=loc.pose.orientation.w;}
 if(p.validFlags&2){p.position[0]=loc.pose.position.x;p.position[1]=loc.pose.position.y;p.position[2]=loc.pose.position.z;}
 return p;
}
static void writeStereo(const XrView views[2], bool valid, XrTime predicted) {
 if (!shm) return;
 InterlockedIncrement(&shm->stereoSequence);
 MemoryBarrier();
 shm->stereoValid = 0;
 shm->predictedDisplayTime = static_cast<int64_t>(predicted);
 for (int i=0; i<2; ++i) {
  RFGREye& eye=shm->eyes[i];
  ZeroMemory(&eye,sizeof(eye));
  if (!valid) continue;
  eye.pose.position[0]=views[i].pose.position.x;
  eye.pose.position[1]=views[i].pose.position.y;
  eye.pose.position[2]=views[i].pose.position.z;
  eye.pose.orientation[0]=views[i].pose.orientation.x;
  eye.pose.orientation[1]=views[i].pose.orientation.y;
  eye.pose.orientation[2]=views[i].pose.orientation.z;
  eye.pose.orientation[3]=views[i].pose.orientation.w;
  eye.pose.validFlags=3;
  eye.fov[0]=views[i].fov.angleLeft;
  eye.fov[1]=views[i].fov.angleRight;
  eye.fov[2]=views[i].fov.angleUp;
  eye.fov[3]=views[i].fov.angleDown;
 }
 MemoryBarrier();
 InterlockedExchange(&shm->stereoValid,valid?1:0);
 InterlockedIncrement(&shm->stereoSamples);
 InterlockedIncrement(&shm->stereoSequence);
}
static void writePoses(const RFGRPose& h,const RFGRPose& l,const RFGRPose& r,const RFGRPose& la,const RFGRPose& ra,const XrView eyes[2],bool valid,XrTime predicted){
 if(!shm) return;
 InterlockedIncrement(&shm->poseSequence); // odd
 MemoryBarrier();
 shm->hmd=h;shm->left=l;shm->right=r;shm->leftAim=la;shm->rightAim=ra;
 writeStereo(eyes,valid,predicted);
 MemoryBarrier();
 InterlockedIncrement(&shm->poseSamples);
 InterlockedIncrement(&shm->poseSequence); // even
}
static bool saveCalibration(float height,float span,bool room){
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return false;
 wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"..\\..\\output\\calibration-ready.json");
 wchar_t temporary[MAX_PATH]{};swprintf_s(temporary,L"%ls.tmp",path);FILE* file=nullptr;if(_wfopen_s(&file,temporary,L"w"))return false;
 fprintf(file,"{\"bridgePid\":%lu,\"headHeight\":%.5f,\"armSpan\":%.5f,\"roomStage\":%s}\n",GetCurrentProcessId(),height,span,room?"true":"false");bool ok=fclose(file)==0;
 return ok&&MoveFileExW(temporary,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH);
}
#define XRPROC(NAME) PFN_##NAME NAME=nullptr
#define GETXR(NAME) if(XR_FAILED(xrGetInstanceProcAddr(instance,#NAME,reinterpret_cast<PFN_xrVoidFunction*>(&NAME)))||!NAME){report(-20,"OpenXR function unavailable: " #NAME);goto cleanup;}


#include "gpu_protocol.h"
#include "wrist_map_protocol.h"
#include "bridge_wrist_status.h"
#include "bridge_wrist_atlas.h"
#include "bridge_grip_hint.h"
#include "bridge_hand_fingers.h"
#include "bridge_focus_vignette.h"
#include "vehicle_aim_packet.h"
#include "bridge_apc_cameras.h"
#include "reload_visual.h"
#include "wrist_map_pose.h"
#include "weapon_hud_pose.h"
#include "stereo_gpu_protocol.h"

// Optional x86 GPU test source: a separate x86 producer supplies a BGRA texture.
// The real Red Faction renderer is not integrated yet; these are test frames.
// Live GPU texture consumer: supports game-sized BGRA/RGBA and sRGB textures.
// The producer uses keys 0 -> 1; consumer always returns key 0, even if blit fails.
struct GpuPreview {
 const wchar_t* mappingName=RFGR_GPU_MAP;bool successfulAcksOnly=false,acknowledgeCopies=true;bool fillTarget=false;
 explicit GpuPreview(const wchar_t* name=RFGR_GPU_MAP,bool successOnly=false,bool autoAck=true):mappingName(name),successfulAcksOnly(successOnly),acknowledgeCopies(autoAck){}
 HANDLE mapping=nullptr;
 RFGRGpuShared* state=nullptr;
 Microsoft::WRL::ComPtr<ID3D11Texture2D> texture;
 Microsoft::WRL::ComPtr<IDXGIKeyedMutex> mutex;
 Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> srv;
 Microsoft::WRL::ComPtr<ID3D11VertexShader> vs;
 Microsoft::WRL::ComPtr<ID3D11PixelShader> ps;
 Microsoft::WRL::ComPtr<ID3D11SamplerState> sampler;
 Microsoft::WRL::ComPtr<ID3D11RenderTargetView> panelRtv;
 ID3D11Texture2D* panelRtvSource=nullptr;
 uint64_t currentHandle=0;
 LONG lastFrame=-1;
 unsigned copied=0,missed=0;
 bool announcedCompileError=false;
 void detachTexture(){
  panelRtv.Reset();panelRtvSource=nullptr;
  srv.Reset();mutex.Reset();texture.Reset();currentHandle=0;
 }
 void close(){
  detachTexture();
  sampler.Reset();ps.Reset();vs.Reset();
  if(state){UnmapViewOfFile(state);state=nullptr;}
  if(mapping){CloseHandle(mapping);mapping=nullptr;}
 }
 bool attach(ID3D11Device* device){
  if(!mapping)mapping=OpenFileMappingW(FILE_MAP_READ|FILE_MAP_WRITE,FALSE,mappingName);
  if(!mapping)return false;
  if(!state)state=static_cast<RFGRGpuShared*>(MapViewOfFile(mapping,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(RFGRGpuShared)));
  if(!state)return false;
  if(state->magic!=RFGR_GPU_MAGIC || state->version!=1 || !state->ready || !state->legacyShareHandle){detachTexture();return false;}
  auto h64=state->legacyShareHandle;
  if(texture && currentHandle==h64)return true;
  detachTexture();
  auto handle=reinterpret_cast<HANDLE>(static_cast<uintptr_t>(h64));
  HRESULT hr=device->OpenSharedResource(handle,__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(texture.GetAddressOf()));
  if(FAILED(hr)){printf("GPU OpenSharedResource HRESULT=0x%08lX handle=%llX\n",(unsigned long)hr,(unsigned long long)h64);return false;}
  hr=texture.As(&mutex);
  if(FAILED(hr)){printf("GPU keyed mutex query HRESULT=0x%08lX\n",(unsigned long)hr);detachTexture();return false;}
  D3D11_TEXTURE2D_DESC d{};texture->GetDesc(&d);
  if(d.Format!=DXGI_FORMAT_B8G8R8A8_UNORM && d.Format!=DXGI_FORMAT_R8G8B8A8_UNORM &&
     d.Format!=DXGI_FORMAT_B8G8R8A8_UNORM_SRGB && d.Format!=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB){
     printf("GPU unsupported source format=%u\n",unsigned(d.Format));detachTexture();return false;
  }
  D3D11_SHADER_RESOURCE_VIEW_DESC sv{};
  sv.Format=d.Format;sv.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2D;sv.Texture2D.MipLevels=1;
  hr=device->CreateShaderResourceView(texture.Get(),&sv,srv.GetAddressOf());
  if(FAILED(hr)){printf("GPU source SRV creation HRESULT=0x%08lX\n",(unsigned long)hr);detachTexture();return false;}
  currentHandle=h64;
  printf("GPU game texture attached %ux%u format=%u handle=%llX\n",d.Width,d.Height,unsigned(d.Format),(unsigned long long)h64);
  return true;
 }
 bool initShader(ID3D11Device* device){
  if(vs && ps && sampler)return true;
  static constexpr char hlsl[]=R"HLSL(
Texture2D source : register(t0);
SamplerState texSampler : register(s0);
struct Output { float4 position:SV_Position; float2 uv:TEXCOORD0; };
Output VS(uint index:SV_VertexID) {
 Output o;
 float2 uv=float2((index<<1)&2,index&2);
 o.position=float4(uv*float2(2,-2)+float2(-1,1),0,1);
 o.uv=uv;
 return o;
}
float4 PS(Output i):SV_Target { return source.Sample(texSampler,i.uv); }
)HLSL";
  Microsoft::WRL::ComPtr<ID3DBlob> vertex,pixel,error;
  HRESULT hr=D3DCompile(hlsl,sizeof(hlsl)-1,nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,vertex.GetAddressOf(),error.GetAddressOf());
  if(FAILED(hr)){
   if(!announcedCompileError){printf("GPU VS compile error: %s\n",error?static_cast<const char*>(error->GetBufferPointer()):"unknown");announcedCompileError=true;}
   return false;
  }
  error.Reset();
  hr=D3DCompile(hlsl,sizeof(hlsl)-1,nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,pixel.GetAddressOf(),error.GetAddressOf());
  if(FAILED(hr)){
   if(!announcedCompileError){printf("GPU PS compile error: %s\n",error?static_cast<const char*>(error->GetBufferPointer()):"unknown");announcedCompileError=true;}
   return false;
  }
  hr=device->CreateVertexShader(vertex->GetBufferPointer(),vertex->GetBufferSize(),nullptr,vs.GetAddressOf());
  if(FAILED(hr))return false;
  hr=device->CreatePixelShader(pixel->GetBufferPointer(),pixel->GetBufferSize(),nullptr,ps.GetAddressOf());
  if(FAILED(hr))return false;
  D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;
  sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;
  hr=device->CreateSamplerState(&sd,sampler.GetAddressOf());
  return SUCCEEDED(hr);
 }
 bool copy(ID3D11Device* device,ID3D11DeviceContext* context,ID3D11Texture2D* dest){
  if(!texture || !state || !state->ready || !mutex || !srv || !dest)return false;
  // Important: NEVER reject the frame before acquiring and releasing key 1.
  // Otherwise producer is left waiting for key 0 after its first frame.
  HRESULT hr=mutex->AcquireSync(1,0);
  if(hr!=S_OK){if(++missed%900==1)printf("GPU consumer waiting for producer hr=0x%08lX\n",(unsigned long)hr);return false;}
  bool ok=false;
  do {
   D3D11_TEXTURE2D_DESC a{},b{};texture->GetDesc(&a);dest->GetDesc(&b);
   if(a.Width==b.Width && a.Height==b.Height && a.Format==b.Format){
    context->CopyResource(dest,texture.Get());ok=true;break;
   }
   if(!initShader(device)){printf("GPU shader initialization failed\n");break;}
   if(panelRtvSource!=dest || !panelRtv){
    panelRtv.Reset();panelRtvSource=nullptr;
    hr=device->CreateRenderTargetView(dest,nullptr,panelRtv.GetAddressOf());
    if(FAILED(hr)){printf("GPU panel RTV failed hr=0x%08lX format=%u bind=0x%X\n",(unsigned long)hr,unsigned(b.Format),b.BindFlags);break;}
    panelRtvSource=dest;
   }
   // Fit the complete game image into the fixed menu panel without changing
   // pixel aspect. Gameplay's taller render size must not stretch films/UI.
   const auto fit=RFGRVR_FitImage(fillTarget?b.Width:a.Width,fillTarget?b.Height:a.Height,b.Width,b.Height);
   D3D11_VIEWPORT viewport{};viewport.TopLeftX=fit.x;viewport.TopLeftY=fit.y;viewport.Width=fit.width;viewport.Height=fit.height;viewport.MaxDepth=1.0f;
   ID3D11RenderTargetView* target=panelRtv.Get();
   const float black[4]={0,0,0,fillTarget?0.f:1.f};context->ClearRenderTargetView(target,black);
   ID3D11ShaderResourceView* input=srv.Get();
   ID3D11SamplerState* filter=sampler.Get();
   context->OMSetRenderTargets(1,&target,nullptr);
   context->RSSetViewports(1,&viewport);
   context->IASetInputLayout(nullptr);
   context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
   context->VSSetShader(vs.Get(),nullptr,0);
   context->PSSetShader(ps.Get(),nullptr,0);
   context->PSSetShaderResources(0,1,&input);
   context->PSSetSamplers(0,1,&filter);
   context->Draw(3,0);
   ID3D11ShaderResourceView* nullSrv=nullptr;
   context->PSSetShaderResources(0,1,&nullSrv);
   ID3D11RenderTargetView* nullTarget=nullptr;
   context->OMSetRenderTargets(1,&nullTarget,nullptr);
   ok=true;
  } while(false);
  // Complete the GPU work before key handoff; always release even on failure.
  context->Flush();
  HRESULT release=mutex->ReleaseSync(0);
  if(FAILED(release))printf("GPU consumer ReleaseSync failed 0x%08lX\n",(unsigned long)release);
  if(state->ready&&(ok||!successfulAcksOnly)){if(acknowledgeCopies)InterlockedIncrement(&state->acknowledged);lastFrame=state->frames;}
  if(ok){++copied;if(copied==1||copied%180==0)printf("GPU-to-XR image copies=%u producerFrames=%ld\n",copied,lastFrame);}
  return ok;
 }
};

// Stereo source dimensions may differ from the OpenXR recommended eye size.
// Resize on the XR device, never on the game's immediate context.
// Reproject each rectilinear desktop image into headset tangent-ray coordinates.
// This corrects the stretching caused by fitting 16:9 into a square OpenXR eye target.
// IMPORTANT: The desktop camera FOV is an estimate until RFGR's projection matrix
// is controlled. This mapping does not synthesize missing world geometry or 6DoF.
struct StereoScaleBlit {
 bool preserveAlpha=false;
 vrfsr::Upscaler fsr;
 struct Views {
  Microsoft::WRL::ComPtr<ID3D11Texture2D> source,target;
  Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> srv;
  Microsoft::WRL::ComPtr<ID3D11RenderTargetView> rtv;
 };
 Views cached[2];unsigned nextCached=0;
 Microsoft::WRL::ComPtr<ID3D11VertexShader> vs;
 Microsoft::WRL::ComPtr<ID3D11PixelShader> ps;
 Microsoft::WRL::ComPtr<ID3D11SamplerState> sampler;
 Microsoft::WRL::ComPtr<ID3D11Buffer> constants;
 struct alignas(16) Optics {
  float sourceScaleX,sourceScaleY,tanLeft,tanRight;
  float tanUp,tanDown,unused0,unused1;
  float centerX,centerY,pad0,pad1;
 };
 bool init(ID3D11Device* d){
  if(vs&&ps&&sampler&&constants)return true;
  static constexpr char shader[]=R"HLSL(
 Texture2D t:register(t0);SamplerState s:register(s0);
 cbuffer Optics:register(b0) {
  float sourceScaleX,sourceScaleY,tanLeft,tanRight;
  float tanUp,tanDown,unused0,unused1;
  float centerX,centerY,pad0,pad1;
 };
 struct V{float4 p:SV_Position;float2 uv:TEXCOORD0;};
 V VS(uint i:SV_VertexID){
  V o;float2 uv=float2((i<<1)&2,i&2);
  o.p=float4(uv*float2(2,-2)+float2(-1,1),0,1);o.uv=uv;return o;
 }
 float4 Source(float2 uv){
  uint w,h;t.GetDimensions(w,h);float2 step=1.0/float2(w,h);
  float4 c=t.Sample(s,uv);float3 a=t.Sample(s,uv+float2(step.x,0)).rgb;
  float3 b=t.Sample(s,uv-float2(step.x,0)).rgb;float3 d=t.Sample(s,uv+float2(0,step.y)).rgb;
  float3 e=t.Sample(s,uv-float2(0,step.y)).rgb;
  float3 lo=min(c.rgb,min(min(a,b),min(d,e))),hi=max(c.rgb,max(max(a,b),max(d,e)));
    if(unused1>0.5){
   float2 edgeStep=step*2.0;
   float edge=max(max(t.Sample(s,uv+float2(edgeStep.x,0)).a,t.Sample(s,uv-float2(edgeStep.x,0)).a),max(t.Sample(s,uv+float2(0,edgeStep.y)).a,t.Sample(s,uv-float2(0,edgeStep.y)).a));
   if(c.a<.08&&edge>.15)return float4(.75,.86,1.0,edge*.85);
   return float4(max(c.rgb,float3(.18,.20,.24)*c.a),c.a);
  }
  return float4(clamp(c.rgb+0.12*(4*c.rgb-a-b-d-e),lo,hi),c.a);
 }
 float4 PS(V i):SV_Target{
  if(unused0>0.5)return Source(i.uv);
  // OpenXR's per-eye FOV is a frustum, not a texture-stretch instruction.
  // Convert each eye pixel to a physical tangent ray, then project that ray
  // into the game camera's assumed centered symmetric perspective.
  float tx=lerp(tanLeft,tanRight,i.uv.x);
  float ty=lerp(tanUp,tanDown,i.uv.y);
  float2 uv=float2(centerX+tx*sourceScaleX,centerY-ty*sourceScaleY);
  if(any(uv<0.0)||any(uv>1.0))return float4(0,0,0,unused1>0.5?0:1);
  return Source(uv);
 }
 )HLSL";
  Microsoft::WRL::ComPtr<ID3DBlob> v,p,error;
  HRESULT hr=D3DCompile(shader,sizeof(shader)-1,nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,v.GetAddressOf(),error.GetAddressOf());
  if(FAILED(hr)){printf("Optics vertex shader failed: %s\n",error?(char*)error->GetBufferPointer():"unknown");return false;}
  error.Reset();
  hr=D3DCompile(shader,sizeof(shader)-1,nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,p.GetAddressOf(),error.GetAddressOf());
  if(FAILED(hr)){printf("Optics pixel shader failed: %s\n",error?(char*)error->GetBufferPointer():"unknown");return false;}
  if(FAILED(d->CreateVertexShader(v->GetBufferPointer(),v->GetBufferSize(),nullptr,vs.GetAddressOf())))return false;
  if(FAILED(d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,ps.GetAddressOf())))return false;
  D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;
  sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_BORDER;
  if(FAILED(d->CreateSamplerState(&sd,sampler.GetAddressOf())))return false;
  D3D11_BUFFER_DESC cb{};cb.ByteWidth=sizeof(Optics);cb.Usage=D3D11_USAGE_DEFAULT;
  cb.BindFlags=D3D11_BIND_CONSTANT_BUFFER;
  return SUCCEEDED(d->CreateBuffer(&cb,nullptr,constants.GetAddressOf()));
 }
 bool render(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* src,ID3D11Texture2D* dst,
             float left,float right,float up,float down,float gameVFovDegrees,bool native=false,const float* measured=nullptr){
  if(!init(d)||!src||!dst)return false;
  Views* views=nullptr;for(auto& entry:cached)if(entry.source.Get()==src&&entry.target.Get()==dst){views=&entry;break;}
  if(!views){auto& entry=cached[nextCached++%2];entry={};entry.source=src;entry.target=dst;
   if(FAILED(d->CreateShaderResourceView(src,nullptr,entry.srv.GetAddressOf()))||FAILED(d->CreateRenderTargetView(dst,nullptr,entry.rtv.GetAddressOf()))){entry={};return false;}
   views=&entry;}
  D3D11_TEXTURE2D_DESC source{},td{};src->GetDesc(&source);dst->GetDesc(&td);
  if(!source.Width||!source.Height||!td.Width||!td.Height)return false;
  constexpr float pi=3.14159265358979323846f;
  const float halfTan=tanf(gameVFovDegrees*pi/360.f);
  if(!(halfTan>0.f))return false;
  Optics o{};
  o.unused0=native?1.f:0.f;o.unused1=preserveAlpha?1.f:0.f;o.centerX=o.centerY=.5f;
  o.sourceScaleY=0.5f/halfTan;
  o.sourceScaleX=o.sourceScaleY*(float(source.Height)/float(source.Width));
  if(measured){o.sourceScaleX=.5f*measured[0];o.sourceScaleY=.5f*measured[1];o.centerX=.5f+.5f*measured[2];o.centerY=.5f-.5f*measured[3];}
  o.tanLeft=tanf(left);o.tanRight=tanf(right);
  o.tanUp=tanf(up);o.tanDown=tanf(down);
  const auto upscale=vrfsr::setting();
  if(upscale.mode&&!preserveAlpha){
   float crop[4]={0,0,1,1};
   if(!native){crop[0]=o.centerX+o.tanLeft*o.sourceScaleX;crop[1]=o.centerY-o.tanUp*o.sourceScaleY;crop[2]=o.centerX+o.tanRight*o.sourceScaleX;crop[3]=o.centerY-o.tanDown*o.sourceScaleY;}
   if(fsr.render(d,c,src,dst,crop,upscale.sharpness))return true;
  }
  c->UpdateSubresource(constants.Get(),0,nullptr,&o,0,0);
  D3D11_VIEWPORT viewport{};viewport.Width=float(td.Width);viewport.Height=float(td.Height);viewport.MaxDepth=1.f;
  ID3D11RenderTargetView* target=views->rtv.Get();ID3D11ShaderResourceView* input=views->srv.Get();ID3D11SamplerState* samp=sampler.Get();
  ID3D11Buffer* cb=constants.Get();
  c->OMSetBlendState(nullptr,nullptr,~0u);c->OMSetDepthStencilState(nullptr,0);c->OMSetRenderTargets(1,&target,nullptr);c->RSSetViewports(1,&viewport);
  c->IASetInputLayout(nullptr);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  c->VSSetShader(vs.Get(),nullptr,0);c->PSSetShader(ps.Get(),nullptr,0);
  c->PSSetConstantBuffers(0,1,&cb);c->PSSetShaderResources(0,1,&input);c->PSSetSamplers(0,1,&samp);
  c->Draw(3,0);
  ID3D11ShaderResourceView* nil=nullptr;ID3D11RenderTargetView* nilRt=nullptr;ID3D11Buffer* nilCb=nullptr;
  c->PSSetShaderResources(0,1,&nil);c->PSSetConstantBuffers(0,1,&nilCb);c->OMSetRenderTargets(1,&nilRt,nullptr);
  return true;
 }
};
// Consumes two distinct GPU textures from an engine stereo producer. This path NEVER
// constructs a second eye by copying the monoscopic back buffer.
struct StereoGpuConsumer {
 HANDLE mapping=nullptr;
 RFGRStereoGpuShared* state=nullptr;
 Microsoft::WRL::ComPtr<ID3D11Texture2D> texture[2];
 Microsoft::WRL::ComPtr<IDXGIKeyedMutex> mutex[2];
 uint64_t handles[2]={};
 StereoScaleBlit scale;
 bool nativePair=false,recordedPose=false; XrView renderedViews[2]{}; uint64_t sceneFrame=0;
 LONG acknowledgement(unsigned eye)const{return state&&eye<2?state->eyeAcknowledged[eye]:-1;}
 LONG producerGame=0;unsigned sourceOwner=0,sourceGeneration=0;bool epochChanged=false,pendingEpoch=false;
 void close(){sourceOwner=sourceGeneration=0;pendingEpoch=false;for(int i=0;i<2;++i){texture[i].Reset();mutex[i].Reset();staged.image[i].Reset();handles[i]=0;}staged.valid=false;
  for(auto& entry:scale.cached)entry={};for(auto& entry:scale.fsr.cache)entry={};
  if(state){UnmapViewOfFile(state);state=nullptr;}if(mapping){CloseHandle(mapping);mapping=nullptr;}}
 bool attach(ID3D11Device* device){
  const LONG game=shm?shm->gamePid:0;
  if(producerGame&&game&&producerGame!=game)close();
  producerGame=game;
  if(!mapping)mapping=OpenFileMappingW(FILE_MAP_READ|FILE_MAP_WRITE,FALSE,RFGR_STEREO_GPU_MAP);
  if(!mapping)return false;
  if(!state)state=static_cast<RFGRStereoGpuShared*>(MapViewOfFile(mapping,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(RFGRStereoGpuShared)));
  if(!state||state->magic!=RFGR_STEREO_GPU_MAGIC||state->version!=4||state->ready!=1){close();return false;}
  return attachTextures(device);
 }
 bool attachTextures(ID3D11Device* device){
  epochChanged=false;if(!state||state->ready!=1)return false;
  if(sourceOwner!=state->ownerPid||sourceGeneration!=state->generation){
   sourceOwner=state->ownerPid;sourceGeneration=state->generation;pendingEpoch=true;
   for(unsigned i=0;i<2;++i){texture[i].Reset();mutex[i].Reset();handles[i]=0;staged.image[i].Reset();consumedFrames[i]=0;}
   staged.valid=false;for(auto& entry:scale.cached)entry={};for(auto& entry:scale.fsr.cache)entry={};
   printf("Stereo resource generation: owner=%u generation=%u size=%ux%u\n",sourceOwner,sourceGeneration,state->width,state->height);
  }
  if(!state->eyeHandle[0]||!state->eyeHandle[1]||state->eyeHandle[0]==state->eyeHandle[1])return false;
  for(int i=0;i<2;++i){
   if(texture[i]&&handles[i]==state->eyeHandle[i])continue;
   texture[i].Reset();mutex[i].Reset();handles[i]=0;
   HANDLE h=reinterpret_cast<HANDLE>(static_cast<uintptr_t>(state->eyeHandle[i]));
   if(FAILED(device->OpenSharedResource(h,__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(texture[i].GetAddressOf()))))return false;
   if(FAILED(texture[i].As(&mutex[i])))return false;
   D3D11_TEXTURE2D_DESC d{};texture[i]->GetDesc(&d);
   if(d.Width!=state->width||d.Height!=state->height||d.ArraySize!=1||d.SampleDesc.Count!=1||
      d.Format!=(DXGI_FORMAT)state->format)return false;
   handles[i]=state->eyeHandle[i];
  }
  epochChanged=pendingEpoch;pendingEpoch=false;return true;
 }
 struct StagedPair {
  Microsoft::WRL::ComPtr<ID3D11Texture2D> image[2];
  XrView views[2]{};float projection[2][4]{};LONG frames[2]{};
  uint64_t scene=0;bool native=false,measured=false,valid=false;
 } staged;
 LONG consumedFrames[2]{};
 bool stagePair(ID3D11DeviceContext* ctx,const XrView views[2]){
  staged.valid=false;if(!ctx||!state||state->ready!=1)return false;
  const unsigned generation=state->generation,owner=state->ownerPid;
  Microsoft::WRL::ComPtr<ID3D11Device> dev;ctx->GetDevice(&dev);
  for(unsigned i=0;i<2;++i){
   if(!texture[i]||!mutex[i])return false;D3D11_TEXTURE2D_DESC src{},local{};texture[i]->GetDesc(&src);
   if(staged.image[i])staged.image[i]->GetDesc(&local);
   if(!src.Width||!src.Height||src.ArraySize!=1||src.SampleDesc.Count!=1)return false;
   if(!staged.image[i]||local.Width!=src.Width||local.Height!=src.Height||local.Format!=src.Format){
    auto desc=src;desc.MiscFlags=desc.CPUAccessFlags=0;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;desc.Usage=D3D11_USAGE_DEFAULT;
    staged.image[i].Reset();if(FAILED(dev->CreateTexture2D(&desc,nullptr,&staged.image[i])))return false;
   }
  }
  if(mutex[0]->AcquireSync(1,0)!=S_OK)return false;
  if(mutex[1]->AcquireSync(1,0)!=S_OK){mutex[0]->ReleaseSync(1);return false;}
  if(state->ready!=1||generation!=state->generation||owner!=state->ownerPid){mutex[0]->ReleaseSync(1);mutex[1]->ReleaseSync(1);return false;}
  staged.native=(state->renderMode==1||state->renderMode==3||state->renderMode==4)&&!(state->pairSequence&1);
  staged.measured=state->renderMode==2||state->renderMode==3||state->renderMode==4;staged.scene=state->sceneFrame;
  for(unsigned i=0;i<2;++i){
   staged.views[i]=views[i];staged.frames[i]=state->eyeFrames[i];memcpy(staged.projection[i],state->sourceProjection[i],16);
   if(staged.native||staged.measured){memcpy(&staged.views[i].pose.position,state->eyePosition[i],12);memcpy(&staged.views[i].pose.orientation,state->eyeOrientation[i],16);if(staged.native)memcpy(&staged.views[i].fov,state->eyeFov[i],16);}
   ctx->CopyResource(staged.image[i].Get(),texture[i].Get());
  }
  // Protect only the source copies, not the expensive eye upscaling passes.
  // Both images and their camera metadata now belong to this exact pair.
  ctx->Flush();HRESULT a=mutex[0]->ReleaseSync(0),b=mutex[1]->ReleaseSync(0);
  bool same=state->ready==1&&generation==state->generation&&owner==state->ownerPid;
  if(same&&SUCCEEDED(a))InterlockedIncrement(&state->eyeAcknowledged[0]);
  if(same&&SUCCEEDED(b))InterlockedIncrement(&state->eyeAcknowledged[1]);
  staged.valid=same&&SUCCEEDED(a)&&SUCCEEDED(b);return staged.valid;
 }
 bool renderStaged(ID3D11DeviceContext* ctx,ID3D11Texture2D* const dst[2],float gameVFov){
  if(!ctx||!staged.valid||!dst[0]||!dst[1])return false;
  Microsoft::WRL::ComPtr<ID3D11Device> dev;ctx->GetDevice(&dev);
  for(unsigned i=0;i<2;++i){const auto& view=staged.views[i];if(!scale.render(dev.Get(),ctx,staged.image[i].Get(),dst[i],view.fov.angleLeft,view.fov.angleRight,view.fov.angleUp,view.fov.angleDown,gameVFov,staged.native&&!staged.measured,staged.measured?staged.projection[i]:nullptr))return false;}
  nativePair=staged.native;recordedPose=staged.native||staged.measured;sceneFrame=staged.scene;
  for(unsigned i=0;i<2;++i){renderedViews[i]=staged.views[i];consumedFrames[i]=staged.frames[i];}
  static bool reported=false;if(staged.measured&&!reported){reported=true;printf("Measured optics active: source scales %.5f %.5f; recorded eye poses enabled; early pair release\n",staged.projection[0][0],staged.projection[0][1]);}
  // The following XR swapchain copy uses this context, so no intermediate
  // Flush is needed between upscaling and the final image copy.
  return true;
 }
 bool copyPair(ID3D11DeviceContext* ctx,ID3D11Texture2D* const dst[2],const XrView views[2],float gameVFov){
  if(!dst[0]||!dst[1])return false;return stagePair(ctx,views)&&renderStaged(ctx,dst,gameVFov);
 }
};

#include "vr_menu_aspect.h"
#include "vr_frame_clock.h"
struct MainMenuLayers {
 GpuPreview source[2]={GpuPreview(RFGR_MAINMENU_VIDEO,true,true),GpuPreview(RFGR_MAINMENU_UI,true,true)};
 XrSwapchain swap[2]{};std::vector<XrSwapchainImageD3D11KHR> images[2];Microsoft::WRL::ComPtr<ID3D11Texture2D> local[2];ULONGLONG updated[2]{};
 XrCompositionLayerQuad quad[2]{{XR_TYPE_COMPOSITION_LAYER_QUAD},{XR_TYPE_COMPOSITION_LAYER_QUAD}};bool visible[2]{},anchored=false;XrPosef anchor{};
 bool frame(ID3D11Device* device,ID3D11DeviceContext* context,XrSession session,XrSpace stage,int64_t format,const RFGRPose& head,bool active,bool backdrop,RFGRVRFloorScreen& floorScreen,PFN_xrCreateSwapchain create,PFN_xrEnumerateSwapchainImages enumerate,PFN_xrAcquireSwapchainImage acquire,PFN_xrWaitSwapchainImage wait,PFN_xrReleaseSwapchainImage release){
 visible[0]=visible[1]=false;if(!active)return false;if((head.validFlags&3)!=3)return false;
 vrarm::M basis=vrboot::quaternion(head.orientation[0],head.orientation[1],head.orientation[2],head.orientation[3]);floorScreen.set({head.position[0],head.position[1],head.position[2]},basis);auto fixed=floorScreen.pose;float yaw=atan2f(fixed.b.f.x,fixed.b.f.z);anchor.position={fixed.p.x,fixed.p.y,fixed.p.z};anchor.orientation={0,sinf(yaw*.5f),0,cosf(yaw*.5f)};anchored=true;
 for(unsigned i=0;i<2;++i){if(!backdrop&&!i)continue;const unsigned surfaceWidth=i?3840:1920,surfaceHeight=i?2160:1080;source[i].fillTarget=true;if(!swap[i]){XrSwapchainCreateInfo info{XR_TYPE_SWAPCHAIN_CREATE_INFO};info.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT|XR_SWAPCHAIN_USAGE_SAMPLED_BIT;info.format=format;info.sampleCount=info.arraySize=info.faceCount=info.mipCount=1;info.width=surfaceWidth;info.height=surfaceHeight;if(XR_FAILED(create(session,&info,&swap[i])))continue;uint32_t count=0;if(XR_FAILED(enumerate(swap[i],0,&count,nullptr))||!count)continue;images[i].resize(count);for(auto& image:images[i])image.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;if(XR_FAILED(enumerate(swap[i],count,&count,(XrSwapchainImageBaseHeader*)images[i].data())))continue;D3D11_TEXTURE2D_DESC d{};d.Width=surfaceWidth;d.Height=surfaceHeight;d.MipLevels=d.ArraySize=d.SampleDesc.Count=1;d.Format=(DXGI_FORMAT)format;d.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;if(FAILED(device->CreateTexture2D(&d,nullptr,&local[i])))continue;}
 if(!local[i]||!source[i].attach(device))continue;if(source[i].copy(device,context,local[i].Get()))updated[i]=GetTickCount64();if(!updated[i]||(i&&GetTickCount64()-updated[i]>500))continue;
 XrSwapchainImageAcquireInfo ac{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};uint32_t index=0;if(XR_FAILED(acquire(swap[i],&ac,&index)))continue;XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wi.timeout=XR_INFINITE_DURATION;if(XR_SUCCEEDED(wait(swap[i],&wi))&&index<images[i].size()){context->OMSetRenderTargets(0,nullptr,nullptr);context->CopyResource(images[i][index].texture,local[i].Get());visible[i]=true;}XrSwapchainImageReleaseInfo re{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};release(swap[i],&re);
 auto& q=quad[i];q.type=XR_TYPE_COMPOSITION_LAYER_QUAD;q.layerFlags=i?XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT:0;q.space=stage;q.eyeVisibility=XR_EYE_VISIBILITY_BOTH;q.pose=anchor;float distance=i?2.f:20.f;float y=anchor.orientation.y,w=anchor.orientation.w;q.pose.position.x-=distance*2*y*w;q.pose.position.z-=distance*(1-2*y*y);q.size=i?XrExtent2Df{2.8f,backdrop?1.575f:2.8f/vrmenuaspect::current()}:XrExtent2Df{50.f,28.125f};q.subImage.swapchain=swap[i];q.subImage.imageRect.extent={int32_t(surfaceWidth),int32_t(surfaceHeight)};
 }return (!backdrop||visible[0])&&visible[1];
 }
 void close(PFN_xrDestroySwapchain destroy){for(unsigned i=0;i<2;++i){source[i].close();local[i].Reset();if(swap[i])destroy(swap[i]);swap[i]=XR_NULL_HANDLE;images[i].clear();}}
};

int main(int argc,char** argv){
 const bool resumeCalibration=argc>2&&!strcmp(argv[2],"--resume-calibration");
 int seconds=45;
 if(argc>1)seconds=atoi(argv[1]);if(seconds<10)seconds=10;if(seconds>86400)seconds=86400;
 mapHandle=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRShared),RFGR_MAP_NAME);
 if(mapHandle)shm=static_cast<RFGRShared*>(MapViewOfFile(mapHandle,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRShared)));
 if(shm){
   if(shm->magic!=RFGR_MAGIC||shm->version!=RFGR_PROTOCOL){ZeroMemory(shm,sizeof(*shm));shm->magic=RFGR_MAGIC;shm->version=RFGR_PROTOCOL;}
   InterlockedExchange(&shm->bridgePid,GetCurrentProcessId());
 }
 wchar_t exe[MAX_PATH]={};GetModuleFileNameW(nullptr,exe,MAX_PATH);
 wchar_t* slash=wcsrchr(exe,L'\\');if(slash)slash[1]=0;
 std::wstring local=std::wstring(exe)+L"openxr_loader.dll";
 HMODULE loader=LoadLibraryW(local.c_str());
 if(!loader){report(-1,"OpenXR loader missing next to companion.");return 2;}
 report(1,"OpenXR loader loaded.");
 auto xrCreateInstance=reinterpret_cast<PFN_xrCreateInstance>(GetProcAddress(loader,"xrCreateInstance"));
 auto xrGetInstanceProcAddr=reinterpret_cast<PFN_xrGetInstanceProcAddr>(GetProcAddress(loader,"xrGetInstanceProcAddr"));
 if(!xrCreateInstance||!xrGetInstanceProcAddr){report(-2,"OpenXR loader missing exported entry points.");return 3;}
 auto enumerateExtensions=reinterpret_cast<PFN_xrEnumerateInstanceExtensionProperties>(GetProcAddress(loader,"xrEnumerateInstanceExtensionProperties"));std::vector<XrExtensionProperties> advertised;uint32_t extensionCount=0;if(enumerateExtensions&&XR_SUCCEEDED(enumerateExtensions(nullptr,0,&extensionCount,nullptr))){advertised.resize(extensionCount,{XR_TYPE_EXTENSION_PROPERTIES});enumerateExtensions(nullptr,extensionCount,&extensionCount,advertised.data());}
 auto available=[&](const char* name){for(auto& e:advertised)if(!strcmp(name,e.extensionName))return true;return false;};bool handTrackingSupported=available(XR_EXT_HAND_TRACKING_EXTENSION_NAME);bool frameProfileSupported=available("XR_VALVE_frame_controller_interaction");bool touchPlusSupported=available(XR_META_TOUCH_CONTROLLER_PLUS_EXTENSION_NAME);
 std::vector<const char*> extensions{XR_KHR_D3D11_ENABLE_EXTENSION_NAME};if(touchPlusSupported)extensions.push_back(XR_META_TOUCH_CONTROLLER_PLUS_EXTENSION_NAME);if(frameProfileSupported)extensions.push_back("XR_VALVE_frame_controller_interaction");if(handTrackingSupported)extensions.push_back(XR_EXT_HAND_TRACKING_EXTENSION_NAME);printf("Optional finger tracking extension=%d\n",handTrackingSupported?1:0);
 XrInstanceCreateInfo info{XR_TYPE_INSTANCE_CREATE_INFO};
 strcpy_s(info.applicationInfo.applicationName,"RFGR-VR");
 strcpy_s(info.applicationInfo.engineName,"RFGR-VR");
 info.applicationInfo.apiVersion=XR_MAKE_VERSION(1,0,0);
 printf("Requested OpenXR API version: 1.0.0\n");
 info.enabledExtensionCount=(uint32_t)extensions.size();info.enabledExtensionNames=extensions.data();
 XrInstance instance=XR_NULL_HANDLE;
 XrResult rc=xrCreateInstance(&info,&instance);

 if(rc==XR_ERROR_EXTENSION_NOT_PRESENT){handTrackingSupported=frameProfileSupported=touchPlusSupported=false;info.enabledExtensionCount=1;rc=xrCreateInstance(&info,&instance);}
 if(XR_FAILED(rc)){printf("xrCreateInstance result=%ld (XR_ERROR_API_VERSION_UNSUPPORTED=-4)\n",(long)rc);report(-3,"OpenXR instance failed.");return 4;}
 report(2,"OpenXR instance created.");
 XRPROC(xrGetSystemProperties);XRPROC(xrGetSystem);XRPROC(xrGetD3D11GraphicsRequirementsKHR);XRPROC(xrCreateSession);XRPROC(xrDestroySession);
 XRPROC(xrCreateReferenceSpace);XRPROC(xrDestroySpace);XRPROC(xrWaitFrame);XRPROC(xrBeginFrame);XRPROC(xrEndFrame);
 XRPROC(xrLocateSpace);XRPROC(xrPollEvent);XRPROC(xrBeginSession);XRPROC(xrEndSession);
 XRPROC(xrStringToPath);XRPROC(xrCreateActionSet);XRPROC(xrDestroyActionSet);XRPROC(xrCreateAction);
 XRPROC(xrCreateActionSpace);XRPROC(xrAttachSessionActionSets);XRPROC(xrSyncActions);XRPROC(xrGetActionStatePose);
 XRPROC(xrApplyHapticFeedback);XRPROC(xrStopHapticFeedback);
 XRPROC(xrGetActionStateBoolean);XRPROC(xrGetActionStateVector2f);XRPROC(xrGetActionStateFloat);
 XRPROC(xrSuggestInteractionProfileBindings);XRPROC(xrGetCurrentInteractionProfile);XRPROC(xrPathToString);XRPROC(xrDestroyInstance);
 XRPROC(xrEnumerateViewConfigurationViews);XRPROC(xrEnumerateSwapchainFormats);XRPROC(xrCreateSwapchain);
 XRPROC(xrEnumerateSwapchainImages);XRPROC(xrAcquireSwapchainImage);XRPROC(xrWaitSwapchainImage);
 XRPROC(xrReleaseSwapchainImage);XRPROC(xrDestroySwapchain);XRPROC(xrLocateViews);
 RFGRXRHands trackedHands;
 XrSession session=XR_NULL_HANDLE;
 XrSpace stage=XR_NULL_HANDLE,view=XR_NULL_HANDLE,leftSpace=XR_NULL_HANDLE,rightSpace=XR_NULL_HANDLE;
 XrActionSet actions=XR_NULL_HANDLE;
 IDXGIFactory1* factory=nullptr;IDXGIAdapter1* adapter=nullptr;
 ID3D11Device* device=nullptr;ID3D11DeviceContext* context=nullptr;
 bool calibrationConfirmed=false,calibrationPose=false,roomStage=false;ULONGLONG calibrationHold=0;float calibrationProgress=0;RFGRVRCalibrationSamples calibrationSamples;vrheadmotion::Guide headGuide;float pendingHeight=1.7f,pendingSpan=1.7f;
 bool sessionRunning=false;bool trackingStarted=false;int sampleCount=0;int lastProfileReport=-1;
 XrSwapchain eyeSwapchain=XR_NULL_HANDLE;
 std::vector<XrSwapchainImageD3D11KHR> eyeImages;
 std::vector<ID3D11Texture2D*> panelImages;
 ID3D11Texture2D* panelSource=nullptr;
 VRSettingsPanel settingsPanel;RFGRVRDesktopSettingsHost desktopSettings;RFGRNotificationLayout notificationLayout;bool settingsConsumed=false;RFGRVRWeaponSelector weaponSelector;RFGRMapPlacement mapPlacement;
 RFGRAPCDisplay apcDisplay;vrtraining::Reader trainingReader;ReloadCueReader reloadCueReader;FocusVignetteRenderer focusVignette;RFGRVehicleAimReader vehicleAimReader;RFGRVehicleAimPrediction vehicleAimPrediction;MenuPixels panel;WristAtlas wristAtlas;GripHintRenderer gripHintRenderer;RFGRPropMarkersReader propMarkerReader;WristStatusReader wristStatusReader;WristStatusPixels wristStatusPixels;
 bool panelReady=false, panelVisible=false, f7WasDown=false; // start without diagnostic panel
 bool menuWorldAnchorValid=false;XrPosef menuWorldAnchor{};menuWorldAnchor.orientation.w=1.0f;
 GpuPreview gpuPreview;GpuPreview wristPreview{RFGR_WRIST_MAP,true,false};
 GpuPreview selectionPreview{RFGR_WEAPON_SELECTOR,true,false};GpuPreview menuPreview{RFGR_MENU_HUD,true,true};ULONGLONG menuUpdated=0;menuPreview.fillTarget=true;
 XrSwapchain selectionSwapchain=XR_NULL_HANDLE;std::vector<XrSwapchainImageD3D11KHR> selectionImages;Microsoft::WRL::ComPtr<ID3D11Texture2D> selectionSource;ULONGLONG selectionUpdated=0;
 GpuPreview worldHudPreview[9]={GpuPreview(RFGR_AMMO_HUD,true,false),GpuPreview(RFGR_CHARGE_HUD,true,false),GpuPreview(RFGR_NOTICE_HUD,true,false),GpuPreview(),GpuPreview(RFGR_MISSION_HUD,true,false),GpuPreview(RFGR_HEALTH_HUD,true,false),GpuPreview(RFGR_OVERHEAT_HUD,true,false),GpuPreview(RFGR_FACTION_HUD,true,false),GpuPreview(RFGR_MORALE_HUD,true,false)};
 XrSwapchain worldHudSwapchain[9]{};std::vector<XrSwapchainImageD3D11KHR> worldHudImages[9];Microsoft::WRL::ComPtr<ID3D11Texture2D> worldHudSource[9];ULONGLONG worldHudUpdated[9]{};
 HANDLE hudPoseMapping=nullptr;RFGRWeaponHudPose* hudPoseShared=nullptr;
 XrSwapchain wristSwapchain=XR_NULL_HANDLE;std::vector<XrSwapchainImageD3D11KHR> wristImages;Microsoft::WRL::ComPtr<ID3D11Texture2D> wristSource;ULONGLONG wristUpdated=0;
 vrframeclock::Publisher renderClock;StereoGpuConsumer stereoGpu;MainMenuLayers mainMenuLayers;vrboot::AvatarGpu bootAvatar;vrboot::Sequence bootSequence;RFGRVRBootText bootText;RFGRVRFloorScreen floorScreen;vrarm::Pose bootHands[2]{};
 // F9 only recenters. Ctrl+Alt+F9 adjusts provisional compositor FOV separately.
 float gameVFovDegrees=110.f; // compositor calibration only; DOES NOT change game frustum
 bool f9WasDown=false;
 bool f5WasDown=false,theaterMode=false,wasProjection=false;
 XrSwapchain projectionSwapchain=XR_NULL_HANDLE;
 std::vector<XrSwapchainImageD3D11KHR> projectionImages;
 ID3D11Texture2D* projectionTargets[2]={nullptr,nullptr};
 uint32_t projectionWidth=0,projectionHeight=0,defaultProjectionWidth=0,defaultProjectionHeight=0;ULONGLONG projectionResizeAttempt=0;
 bool projectionReady=false;
 LONG lastStereoFrames[2]={-1,-1};
 bool stereoPairCached=false;bool worldMenuWasActive=false;LONG cachedSceneGame=0;
 ULONGLONG lastPairTick=0;
 unsigned long projectedFrames=0, repeatedStereoFrames=0, missedStereoPairs=0;

 uint32_t eyeWidth=PANEL_W,eyeHeight=PANEL_H;
 DXGI_FORMAT selectedFormat=DXGI_FORMAT_UNKNOWN;
 unsigned long displayedFrames=0;
 XrAction aimAction=XR_NULL_HANDLE;XrSpace aimSpaces[2]={XR_NULL_HANDLE,XR_NULL_HANDLE};
 XrAction poseAction=XR_NULL_HANDLE,confirmAction=XR_NULL_HANDLE,backAction=XR_NULL_HANDLE,navAction=XR_NULL_HANDLE;
 RFGRHapticReader hapticReader;RFGRHapticReader magazineHintReader{RFGR_MAG_HINT_MAP};bool hapticRunning[2]{};ULONGLONG hapticTick[2]{};float hapticAmplitude[2]{};
 XrAction hapticAction{};
 XrAction trackpadAction{},trackpadForceAction{},trackpadTouchAction{};
 XrAction lookAction{},triggerAction{},squeezeAction{},bumperAction{},thumbAction{},xAction{},yAction{},menuAction{},viewAction{},dpadAction[4]{};
 XrPath leftPath=XR_NULL_PATH,rightPath=XR_NULL_PATH;
 // Function pointers are loaded from the active runtime instance.
 GETXR(xrGetSystemProperties) GETXR(xrGetSystem) GETXR(xrGetD3D11GraphicsRequirementsKHR) GETXR(xrCreateSession) GETXR(xrDestroySession)
 GETXR(xrCreateReferenceSpace) GETXR(xrDestroySpace) GETXR(xrWaitFrame) GETXR(xrBeginFrame) GETXR(xrEndFrame)
 GETXR(xrLocateSpace) GETXR(xrPollEvent) GETXR(xrBeginSession) GETXR(xrEndSession)
 GETXR(xrStringToPath) GETXR(xrCreateActionSet) GETXR(xrDestroyActionSet) GETXR(xrCreateAction)
 GETXR(xrApplyHapticFeedback) GETXR(xrStopHapticFeedback)
 GETXR(xrCreateActionSpace) GETXR(xrAttachSessionActionSets) GETXR(xrSyncActions) GETXR(xrGetActionStatePose)
 GETXR(xrGetActionStateBoolean) GETXR(xrGetActionStateVector2f) GETXR(xrGetActionStateFloat)
 GETXR(xrSuggestInteractionProfileBindings) GETXR(xrGetCurrentInteractionProfile) GETXR(xrPathToString) GETXR(xrDestroyInstance)
 GETXR(xrEnumerateViewConfigurationViews) GETXR(xrEnumerateSwapchainFormats) GETXR(xrCreateSwapchain)
 GETXR(xrEnumerateSwapchainImages) GETXR(xrAcquireSwapchainImage) GETXR(xrWaitSwapchainImage)
 GETXR(xrReleaseSwapchainImage) GETXR(xrDestroySwapchain) GETXR(xrLocateViews)
 {
 XrSystemGetInfo sysInfo{XR_TYPE_SYSTEM_GET_INFO};sysInfo.formFactor=XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
 XrSystemId systemId=XR_NULL_SYSTEM_ID;
 rc=xrGetSystem(instance,&sysInfo,&systemId);
 if(XR_FAILED(rc)){printf("xrGetSystem error=%ld\n",(long)rc);report(-4,"No active HMD system.");goto cleanup;}
 report(3,"OpenXR headset available.");
 {XrSystemProperties properties{XR_TYPE_SYSTEM_PROPERTIES};if(XR_SUCCEEDED(xrGetSystemProperties(instance,systemId,&properties)))printf("Detected HMD: %s; controller profiles select device bindings independently.\n",properties.systemName);}
 XrGraphicsRequirementsD3D11KHR req{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR};
 rc=xrGetD3D11GraphicsRequirementsKHR(instance,systemId,&req);
 if(XR_FAILED(rc)){printf("xrGetD3D11GraphicsRequirementsKHR=%ld\n",(long)rc);report(-5,"D3D11 requirements unavailable.");goto cleanup;}
 printf("OpenXR D3D11 minimum feature level=0x%X\n",(unsigned)req.minFeatureLevel);

 // Runtime-selected GPU LUID is mandatory to avoid bridging across mismatched adapters.
 if(FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1),reinterpret_cast<void**>(&factory)))){report(-6,"DXGI factory creation failed.");goto cleanup;}
 for(UINT i=0;;++i){IDXGIAdapter1* candidate=nullptr;if(factory->EnumAdapters1(i,&candidate)==DXGI_ERROR_NOT_FOUND)break;
  DXGI_ADAPTER_DESC1 desc={};candidate->GetDesc1(&desc);
  if(!memcmp(&desc.AdapterLuid,&req.adapterLuid,sizeof(LUID))){adapter=candidate;break;}candidate->Release();}
 if(!adapter){report(-7,"No DXGI adapter matches SteamVR's required GPU LUID.");goto cleanup;}
 D3D_FEATURE_LEVEL available[]={D3D_FEATURE_LEVEL_11_1,D3D_FEATURE_LEVEL_11_0};D3D_FEATURE_LEVEL selected{};
 HRESULT hr=D3D11CreateDevice(adapter,D3D_DRIVER_TYPE_UNKNOWN,nullptr,0,available,2,D3D11_SDK_VERSION,&device,&selected,&context);
 if(FAILED(hr)){D3D_FEATURE_LEVEL fallback[]={D3D_FEATURE_LEVEL_11_0};hr=D3D11CreateDevice(adapter,D3D_DRIVER_TYPE_UNKNOWN,nullptr,0,fallback,1,D3D11_SDK_VERSION,&device,&selected,&context);}
 if(FAILED(hr)){printf("D3D11CreateDevice HRESULT=0x%08lX\n",(unsigned long)hr);report(-8,"OpenXR companion D3D11 device failed.");goto cleanup;}
 if(selected<req.minFeatureLevel){report(-9,"GPU D3D11 feature level below OpenXR requirement.");goto cleanup;}
 XrGraphicsBindingD3D11KHR binding{XR_TYPE_GRAPHICS_BINDING_D3D11_KHR};binding.device=device;
 XrSessionCreateInfo sessionInfo{XR_TYPE_SESSION_CREATE_INFO};sessionInfo.next=&binding;sessionInfo.systemId=systemId;
 rc=xrCreateSession(instance,&sessionInfo,&session);
 if(XR_FAILED(rc)){printf("xrCreateSession result=%ld\n",(long)rc);report(-10,"OpenXR D3D11 session creation failed.");goto cleanup;}
 trackedHands.init(instance,session,systemId,xrGetInstanceProcAddr,handTrackingSupported);
 report(4,"OpenXR D3D11 session created. Waiting for focused/running state.");
 // One monoscopic QUAD in XR VIEW space: the compositor handles eye alignment.
 // OpenXR runtime chooses formats; a matching D3D11 source texture is GPU-copied to each acquired image.
 {
  uint32_t fmtCount=0;
  if(XR_FAILED(xrEnumerateSwapchainFormats(session,0,&fmtCount,nullptr))||!fmtCount){report(-33,"No OpenXR swapchain formats.");goto cleanup;}
  std::vector<int64_t> formats(fmtCount);
  if(XR_FAILED(xrEnumerateSwapchainFormats(session,fmtCount,&fmtCount,formats.data()))){report(-34,"OpenXR formats query failed.");goto cleanup;}
  printf("Advertised DXGI formats:");for(auto f:formats)printf(" %lld",(long long)f);printf("\n");
  const DXGI_FORMAT preferred[]={DXGI_FORMAT_B8G8R8A8_UNORM_SRGB,DXGI_FORMAT_R8G8B8A8_UNORM_SRGB,
      DXGI_FORMAT_B8G8R8A8_UNORM,DXGI_FORMAT_R8G8B8A8_UNORM};
  apcDisplay.format=RFGRVR_APCDisplayFormat(formats.data(),formats.size());
  for(auto f:preferred)if(std::find(formats.begin(),formats.end(),(int64_t)f)!=formats.end()){selectedFormat=f;break;}
  if(selectedFormat==DXGI_FORMAT_UNKNOWN){report(-35,"No supported 8-bit DXGI color format for the menu.");goto cleanup;}
  XrSwapchainCreateInfo create{XR_TYPE_SWAPCHAIN_CREATE_INFO};create.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT|XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT;
  create.format=selectedFormat;create.sampleCount=1;create.width=PANEL_W;create.height=PANEL_H;
  create.faceCount=1;create.arraySize=1;create.mipCount=1;
  rc=xrCreateSwapchain(session,&create,&eyeSwapchain);
  if(XR_FAILED(rc)){
   // Some runtimes do not advertise TRANSFER_DST. COLOR_ATTACHMENT is the required baseline.
   create.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT;
   rc=xrCreateSwapchain(session,&create,&eyeSwapchain);
  }
  if(XR_FAILED(rc)){printf("xrCreateSwapchain result=%ld\n",(long)rc);report(-36,"VR panel swapchain creation failed.");goto cleanup;}
  uint32_t count=0;
  if(XR_FAILED(xrEnumerateSwapchainImages(eyeSwapchain,0,&count,nullptr))||!count){report(-37,"VR panel has no swapchain images.");goto cleanup;}
  eyeImages.resize(count);for(auto& im:eyeImages)im.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;
  if(XR_FAILED(xrEnumerateSwapchainImages(eyeSwapchain,count,&count,reinterpret_cast<XrSwapchainImageBaseHeader*>(eyeImages.data())))){report(-38,"VR panel image query failed.");goto cleanup;}
  D3D11_TEXTURE2D_DESC td{};td.Width=PANEL_W;td.Height=PANEL_H;td.MipLevels=1;td.ArraySize=1;
  td.SampleDesc.Count=1;td.Usage=D3D11_USAGE_DEFAULT;td.Format=selectedFormat;
  td.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_RENDER_TARGET;
  HRESULT texhr=device->CreateTexture2D(&td,nullptr,&panelSource);
  if(FAILED(texhr)||!panel.ready()){printf("Menu texture creation 0x%08lX\n",(unsigned long)texhr);report(-39,"Menu buffer initialization failed.");goto cleanup;}
  panelReady=true;
  printf("XR binocular QUAD menu ready: %ux%u format=%d images=%u\n",PANEL_W,PANEL_H,(int)selectedFormat,count);
  // Independent small transparent surface; scene eye textures are untouched.
  XrSwapchainCreateInfo wc=create;wc.width=768;wc.height=944;wc.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT;
  if(std::find(formats.begin(),formats.end(),(int64_t)DXGI_FORMAT_B8G8R8A8_UNORM)!=formats.end())wc.format=DXGI_FORMAT_B8G8R8A8_UNORM;
  if(XR_SUCCEEDED(xrCreateSwapchain(session,&wc,&wristSwapchain))){uint32_t wn=0;if(XR_SUCCEEDED(xrEnumerateSwapchainImages(wristSwapchain,0,&wn,nullptr))&&wn){wristImages.resize(wn);for(auto& im:wristImages)im.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;if(XR_FAILED(xrEnumerateSwapchainImages(wristSwapchain,wn,&wn,(XrSwapchainImageBaseHeader*)wristImages.data())))wristImages.clear();}
   D3D11_TEXTURE2D_DESC wd{};wd.Width=wd.Height=RFGR_WRIST_SIZE;wd.MipLevels=wd.ArraySize=wd.SampleDesc.Count=1;wd.Usage=D3D11_USAGE_DEFAULT;wd.Format=(DXGI_FORMAT)wc.format;wd.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;device->CreateTexture2D(&wd,nullptr,&wristSource);
  }
  wc.width=wc.height=RFGR_WRIST_SIZE;
  if(XR_SUCCEEDED(xrCreateSwapchain(session,&wc,&selectionSwapchain))){uint32_t n=0;if(XR_SUCCEEDED(xrEnumerateSwapchainImages(selectionSwapchain,0,&n,nullptr))&&n){selectionImages.resize(n);for(auto& im:selectionImages)im.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;if(XR_FAILED(xrEnumerateSwapchainImages(selectionSwapchain,n,&n,(XrSwapchainImageBaseHeader*)selectionImages.data())))selectionImages.clear();}
   D3D11_TEXTURE2D_DESC d{};d.Width=d.Height=RFGR_WRIST_SIZE;d.MipLevels=d.ArraySize=d.SampleDesc.Count=1;d.Format=(DXGI_FORMAT)wc.format;d.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;device->CreateTexture2D(&d,nullptr,&selectionSource);}
  wc.width=wc.height=VRSettingsPanel::Resolution;
  if(XR_SUCCEEDED(xrCreateSwapchain(session,&wc,&settingsPanel.swapchain))){uint32_t n=0;if(XR_SUCCEEDED(xrEnumerateSwapchainImages(settingsPanel.swapchain,0,&n,nullptr))&&n){settingsPanel.images.resize(n);for(auto& im:settingsPanel.images)im.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;xrEnumerateSwapchainImages(settingsPanel.swapchain,n,&n,(XrSwapchainImageBaseHeader*)settingsPanel.images.data());}}
  wc.width=wc.height=RFGR_WRIST_SIZE;
  for(unsigned hud=0;hud<9;++hud){
  if((hud==3)||XR_SUCCEEDED(xrCreateSwapchain(session,&wc,&worldHudSwapchain[hud]))){uint32_t wn=0;if((hud!=3)&&XR_SUCCEEDED(xrEnumerateSwapchainImages(worldHudSwapchain[hud],0,&wn,nullptr))&&wn){worldHudImages[hud].resize(wn);for(auto& im:worldHudImages[hud])im.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;if(XR_FAILED(xrEnumerateSwapchainImages(worldHudSwapchain[hud],wn,&wn,(XrSwapchainImageBaseHeader*)worldHudImages[hud].data())))worldHudImages[hud].clear();}
   D3D11_TEXTURE2D_DESC wd{};wd.Width=wd.Height=RFGR_WRIST_SIZE;wd.MipLevels=wd.ArraySize=wd.SampleDesc.Count=1;wd.Usage=D3D11_USAGE_DEFAULT;wd.Format=(DXGI_FORMAT)wc.format;wd.BindFlags=D3D11_BIND_RENDER_TARGET|D3D11_BIND_SHADER_RESOURCE;device->CreateTexture2D(&wd,nullptr,&worldHudSource[hud]);
  }
  }

 }

 XrReferenceSpaceCreateInfo ref{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};ref.referenceSpaceType=XR_REFERENCE_SPACE_TYPE_STAGE;ref.poseInReferenceSpace.orientation.w=1.0f;
 rc=xrCreateReferenceSpace(session,&ref,&stage);
 if(XR_FAILED(rc)){ref.referenceSpaceType=XR_REFERENCE_SPACE_TYPE_LOCAL;rc=xrCreateReferenceSpace(session,&ref,&stage);printf("Room STAGE unavailable; using LOCAL reference space.\n");}
 else {roomStage=true;printf("Room STAGE reference space active.\n");}
 if(XR_FAILED(rc)){report(-11,"Room reference space failed.");goto cleanup;}
 {std::wstring cache=std::wstring(exe)+L"../../../RFGRVR/cache/mason-avatar.bin";printf("Calibration Mason cache loaded=%d\n",bootAvatar.load(cache.c_str()));}
 if(resumeCalibration&&RFGRVR_CanResumeCalibration(shm,roomStage)){bootSequence.released=bootSequence.ready=true;calibrationConfirmed=true;saveCalibration(shm->calibratedHeadHeight,shm->calibratedArmSpan,roomStage);printf("Existing STAGE calibration retained for companion-only restart.\n");}
 // The projection swapchain is a two-layer D3D11 array. Each layer receives a
 // DIFFERENT engine-rendered eye. This stays unused unless both producer textures
 // have been published and both frames can be acquired.
 {
  uint32_t count=0;
  if(XR_SUCCEEDED(xrEnumerateViewConfigurationViews(instance,systemId,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,0,&count,nullptr))&&count==2){
   XrViewConfigurationView views[2]={{XR_TYPE_VIEW_CONFIGURATION_VIEW},{XR_TYPE_VIEW_CONFIGURATION_VIEW}};
   if(XR_SUCCEEDED(xrEnumerateViewConfigurationViews(instance,systemId,XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO,2,&count,views))){
    // Use the minimum recommendation if the runtime reports asymmetric widths.
    projectionWidth=std::min(views[0].recommendedImageRectWidth,views[1].recommendedImageRectWidth);
    projectionHeight=std::min(views[0].recommendedImageRectHeight,views[1].recommendedImageRectHeight);defaultProjectionWidth=projectionWidth;defaultProjectionHeight=projectionHeight;
    XrSwapchainCreateInfo sc{XR_TYPE_SWAPCHAIN_CREATE_INFO};
    sc.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT|XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT;
    sc.format=selectedFormat;sc.sampleCount=1;sc.width=projectionWidth;sc.height=projectionHeight;
    sc.faceCount=1;sc.arraySize=2;sc.mipCount=1;
    XrResult r=xrCreateSwapchain(session,&sc,&projectionSwapchain);
    if(XR_FAILED(r)){sc.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT;r=xrCreateSwapchain(session,&sc,&projectionSwapchain);}
    if(XR_SUCCEEDED(r)){
     uint32_t n=0;
     if(XR_SUCCEEDED(xrEnumerateSwapchainImages(projectionSwapchain,0,&n,nullptr))&&n){
      projectionImages.resize(n);for(auto& im:projectionImages)im.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;
      projectionReady=XR_SUCCEEDED(xrEnumerateSwapchainImages(projectionSwapchain,n,&n,reinterpret_cast<XrSwapchainImageBaseHeader*>(projectionImages.data())));
     }
    }
    printf("Stereo projection swapchain ready=%d size=%ux%u\n",projectionReady?1:0,projectionWidth,projectionHeight);
   }
  }
 }
 ref.referenceSpaceType=XR_REFERENCE_SPACE_TYPE_VIEW;
 if(XR_FAILED(xrCreateReferenceSpace(session,&ref,&view))){report(-18,"VIEW reference space failed.");goto cleanup;}
 XrActionSetCreateInfo setInfo{XR_TYPE_ACTION_SET_CREATE_INFO};strcpy_s(setInfo.actionSetName,"rfgr_tracking");strcpy_s(setInfo.localizedActionSetName,"RFGR Tracking");setInfo.priority=0;
 if(XR_FAILED(xrCreateActionSet(instance,&setInfo,&actions))){report(-12,"Action-set creation failed.");goto cleanup;}
 if(XR_FAILED(xrStringToPath(instance,"/user/hand/left",&leftPath))||XR_FAILED(xrStringToPath(instance,"/user/hand/right",&rightPath))){report(-13,"Controller user paths unavailable.");goto cleanup;}
 XrPath paths[]={leftPath,rightPath};
 XrActionCreateInfo actionInfo{XR_TYPE_ACTION_CREATE_INFO};actionInfo.actionType=XR_ACTION_TYPE_POSE_INPUT;strcpy_s(actionInfo.actionName,"hand_pose");strcpy_s(actionInfo.localizedActionName,"Hand Pose");actionInfo.countSubactionPaths=2;actionInfo.subactionPaths=paths;
 if(XR_FAILED(xrCreateAction(actions,&actionInfo,&poseAction))){report(-14,"Pose action creation failed.");goto cleanup;}
 strcpy_s(actionInfo.actionName,"hand_aim_pose");strcpy_s(actionInfo.localizedActionName,"Hand Aim Pose");
 if(XR_FAILED(xrCreateAction(actions,&actionInfo,&aimAction))){report(-14,"Aim action creation failed.");goto cleanup;}
 // Separate boolean/axis input actions. Profiles without these bindings keep tracking only.
 XrActionCreateInfo buttons{XR_TYPE_ACTION_CREATE_INFO};buttons.actionType=XR_ACTION_TYPE_BOOLEAN_INPUT;
 strcpy_s(buttons.actionName,"rfgr_confirm");strcpy_s(buttons.localizedActionName,"RFGR Confirm");
 if(XR_FAILED(xrCreateAction(actions,&buttons,&confirmAction))){report(-41,"Menu confirm action failed.");goto cleanup;}
 strcpy_s(buttons.actionName,"rfgr_back");strcpy_s(buttons.localizedActionName,"RFGR Back");
 if(XR_FAILED(xrCreateAction(actions,&buttons,&backAction))){report(-42,"Menu back action failed.");goto cleanup;}
 XrActionCreateInfo axis{XR_TYPE_ACTION_CREATE_INFO};axis.actionType=XR_ACTION_TYPE_VECTOR2F_INPUT;
 strcpy_s(axis.actionName,"rfgr_navigate");strcpy_s(axis.localizedActionName,"RFGR Navigate");
 if(XR_FAILED(xrCreateAction(actions,&axis,&navAction))){report(-43,"Menu navigation action failed.");goto cleanup;}

 {
 auto make=[&](XrAction& out,const char* name,XrActionType type,bool both=false){
 XrActionCreateInfo a{XR_TYPE_ACTION_CREATE_INFO};a.actionType=type;
 strcpy_s(a.actionName,name);strcpy_s(a.localizedActionName,name);
 if(both){a.countSubactionPaths=2;a.subactionPaths=paths;}
 return XR_SUCCEEDED(xrCreateAction(actions,&a,&out));};
 bool ok=make(trackpadAction,"trackpad_position",XR_ACTION_TYPE_VECTOR2F_INPUT,true)&&make(trackpadForceAction,"trackpad_pressure",XR_ACTION_TYPE_FLOAT_INPUT,true)&&make(trackpadTouchAction,"trackpad_touch",XR_ACTION_TYPE_BOOLEAN_INPUT,true)&&make(hapticAction,"controller_vibration",XR_ACTION_TYPE_VIBRATION_OUTPUT,true)&&make(lookAction,"look",XR_ACTION_TYPE_VECTOR2F_INPUT)&&make(triggerAction,"trigger",XR_ACTION_TYPE_FLOAT_INPUT,true)&&make(squeezeAction,"squeeze",XR_ACTION_TYPE_FLOAT_INPUT,true)&&make(bumperAction,"bumper",XR_ACTION_TYPE_BOOLEAN_INPUT,true)&&make(thumbAction,"thumb_click",XR_ACTION_TYPE_BOOLEAN_INPUT,true)&&make(xAction,"button_x",XR_ACTION_TYPE_BOOLEAN_INPUT)&&make(yAction,"button_y",XR_ACTION_TYPE_BOOLEAN_INPUT)&&make(menuAction,"start",XR_ACTION_TYPE_BOOLEAN_INPUT)&&make(viewAction,"view",XR_ACTION_TYPE_BOOLEAN_INPUT);
 const char* names[]={"dpad_up","dpad_down","dpad_left","dpad_right"};
 for(int i=0;i<4;++i)ok=make(dpadAction[i],names[i],XR_ACTION_TYPE_BOOLEAN_INPUT)&&ok;
 if(!ok){report(-44,"Gameplay actions unavailable.");goto cleanup;}
 }
 XrActionSpaceCreateInfo spaceInfo{XR_TYPE_ACTION_SPACE_CREATE_INFO};spaceInfo.action=poseAction;spaceInfo.poseInActionSpace.orientation.w=1.0f;
 spaceInfo.subactionPath=leftPath;
 if(XR_FAILED(xrCreateActionSpace(session,&spaceInfo,&leftSpace))){report(-15,"Left controller action space failed.");goto cleanup;}
 spaceInfo.subactionPath=rightPath;
 if(XR_FAILED(xrCreateActionSpace(session,&spaceInfo,&rightSpace))){report(-16,"Right controller action space failed.");goto cleanup;}
 spaceInfo.action=aimAction;
 for(int hand=0;hand<2;++hand){spaceInfo.subactionPath=paths[hand];if(XR_FAILED(xrCreateActionSpace(session,&spaceInfo,&aimSpaces[hand]))){report(-16,"Controller aim space failed.");goto cleanup;}}
 // Suggest grip-pose actions on common OpenXR controller profiles.
 // Unsupported profiles are logged and skipped. The runtime selects the active profile.
 const char* profiles[]={
   "/interaction_profiles/valve/frame_controller_valve",
   "/interaction_profiles/khr/simple_controller",
   "/interaction_profiles/valve/index_controller",
   "/interaction_profiles/htc/vive_controller",
   "/interaction_profiles/oculus/touch_controller",
   "/interaction_profiles/meta/touch_controller_plus",
   "/interaction_profiles/microsoft/motion_controller"
 };
 for(const char* name:profiles){
  const bool frameProfile=strstr(name,"frame_controller_valve")!=nullptr;
  if(frameProfile&&!frameProfileSupported)continue;if(strstr(name,"meta/touch_controller_plus")&&!touchPlusSupported)continue;
  XrPath profile=XR_NULL_PATH,leftGrip=XR_NULL_PATH,rightGrip=XR_NULL_PATH;
  if(XR_FAILED(xrStringToPath(instance,name,&profile)))continue;
  if(XR_FAILED(xrStringToPath(instance,"/user/hand/left/input/grip/pose",&leftGrip)))continue;
  if(XR_FAILED(xrStringToPath(instance,"/user/hand/right/input/grip/pose",&rightGrip)))continue;
  std::vector<XrActionSuggestedBinding> binds{{poseAction,leftGrip},{poseAction,rightGrip}};
  for(const char* hand:{"left","right"}){char path[96];sprintf_s(path,"/user/hand/%s/input/aim/pose",hand);XrPath aimPath=0;if(XR_SUCCEEDED(xrStringToPath(instance,path,&aimPath)))binds.push_back({aimAction,aimPath});}
  for(const char* hand:{"left","right"}){char path[96];sprintf_s(path,"/user/hand/%s/output/haptic",hand);XrPath output=XR_NULL_PATH;if(XR_SUCCEEDED(xrStringToPath(instance,path,&output)))binds.push_back({hapticAction,output});}
  const bool hasButtons=(frameProfile||strstr(name,"touch_controller")||strstr(name,"valve/index_controller"));
  if(hasButtons){
   auto add=[&](XrAction action,const char* path){XrPath p=XR_NULL_PATH;
     if(XR_SUCCEEDED(xrStringToPath(instance,path,&p)))binds.push_back({action,p});};
   add(confirmAction,"/user/hand/right/input/a/click");
   add(backAction,"/user/hand/right/input/b/click");
   add(navAction,"/user/hand/left/input/thumbstick");
   add(lookAction,"/user/hand/right/input/thumbstick");
   add(xAction,frameProfile?"/user/hand/right/input/x/click":strstr(name,"index_controller")?"/user/hand/left/input/a/click":"/user/hand/left/input/x/click");
   add(yAction,frameProfile?"/user/hand/right/input/y/click":strstr(name,"index_controller")?"/user/hand/left/input/b/click":"/user/hand/left/input/y/click");
   for(const char* hand:{"left","right"}){char path[128];
    sprintf_s(path,"/user/hand/%s/input/trigger/value",hand);add(triggerAction,path);
    sprintf_s(path,"/user/hand/%s/input/squeeze/%s",hand,vrcontrollers::gripComponent(vrcontrollers::detect(name)));add(squeezeAction,path);
    sprintf_s(path,"/user/hand/%s/input/thumbstick/click",hand);add(thumbAction,path);
    if(frameProfile){sprintf_s(path,"/user/hand/%s/input/bumper/click",hand);add(bumperAction,path);}
   }
   if(strstr(name,"index_controller")){for(const char* hand:{"left","right"}){char path[128];sprintf_s(path,"/user/hand/%s/input/trackpad",hand);add(trackpadAction,path);sprintf_s(path,"/user/hand/%s/input/trackpad/force",hand);add(trackpadForceAction,path);sprintf_s(path,"/user/hand/%s/input/trackpad/touch",hand);add(trackpadTouchAction,path);}}
   if(frameProfile){
    add(menuAction,"/user/hand/right/input/menu/click");add(viewAction,"/user/hand/left/input/view/click");
    const char* dpad[]={"up","down","left","right"};for(int i=0;i<4;++i){char path[128];sprintf_s(path,"/user/hand/left/input/dpad_%s/click",dpad[i]);add(dpadAction[i],path);}
   }else if(strstr(name,"touch_controller"))add(menuAction,"/user/hand/left/input/menu/click");
  }
  XrInteractionProfileSuggestedBinding suggestion{XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING};
  suggestion.interactionProfile=profile;suggestion.countSuggestedBindings=(uint32_t)binds.size();suggestion.suggestedBindings=binds.data();
  const XrResult result=xrSuggestInteractionProfileBindings(instance,&suggestion);
  printf("Profile suggestion %s result=%ld\n",name,(long)result);
 }

 XrSessionActionSetsAttachInfo attach{XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO};attach.countActionSets=1;attach.actionSets=&actions;
 if(XR_FAILED(xrAttachSessionActionSets(session,&attach))){report(-17,"Attaching tracking actions failed.");goto cleanup;}
 // Pose actions require interaction profile bindings; the simple controller profiles below
 // are handled by the next test revision if runtime leaves action state inactive.
 DWORD started=GetTickCount();
 while(GetTickCount()-started<(DWORD)seconds*1000){
  desktopSettings.frame(settingsPanel,vrsettings::get().value[vrsettings::Desktop]!=0);
  if(shm)InterlockedIncrement(&shm->bridgeHeartbeat);
  XrEventDataBuffer event{XR_TYPE_EVENT_DATA_BUFFER};
  while(xrPollEvent(instance,&event)==XR_SUCCESS){
   if(event.type==XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED){
    auto* changed=reinterpret_cast<XrEventDataSessionStateChanged*>(&event);
    printf("Session state=%d\n",(int)changed->state);
    if(changed->state==XR_SESSION_STATE_READY&&!sessionRunning){
     XrSessionBeginInfo begin{XR_TYPE_SESSION_BEGIN_INFO};begin.primaryViewConfigurationType=XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
     rc=xrBeginSession(session,&begin);sessionRunning=XR_SUCCEEDED(rc);
     if(!sessionRunning)printf("xrBeginSession result=%ld\n",(long)rc);
    }
    if(changed->state==XR_SESSION_STATE_STOPPING&&sessionRunning){xrEndSession(session);sessionRunning=false;}
    if(changed->state==XR_SESSION_STATE_EXITING||changed->state==XR_SESSION_STATE_LOSS_PENDING)goto cleanup;
   }
   event.type=XR_TYPE_EVENT_DATA_BUFFER;
  }
  if(!sessionRunning){Sleep(50);continue;}
  XrFrameWaitInfo waitInfo{XR_TYPE_FRAME_WAIT_INFO};XrFrameState frame{XR_TYPE_FRAME_STATE};
  if(XR_FAILED(xrWaitFrame(session,&waitInfo,&frame))){Sleep(50);continue;}
  XrFrameBeginInfo beginFrame{XR_TYPE_FRAME_BEGIN_INFO};
  if(XR_FAILED(xrBeginFrame(session,&beginFrame)))continue;
  XrActiveActionSet activeSet{actions,XR_NULL_PATH};XrActionsSyncInfo sync{XR_TYPE_ACTIONS_SYNC_INFO};sync.countActiveActionSets=1;sync.activeActionSets=&activeSet;
  xrSyncActions(session,&sync);
  {RFGRHapticPacket packet{};const bool fresh=shm&&shm->gamepadActive&&hapticReader.read(shm->gamePid,packet);auto now=GetTickCount64();RFGRHapticPacket magazineHint{};bool hintFresh=shm&&magazineHintReader.read(shm->gamePid,magazineHint)&&DWORD(GetTickCount()-magazineHint.tick)<70;
   for(unsigned hand=0;hand<2;++hand){float amplitude=fresh?float(packet.motor[hand])/65535.f*vrsettings::get().value[vrsettings::Haptics]/100.f:0.f;if(hand==0&&hintFresh)amplitude=(std::max)(amplitude,float(magazineHint.motor[0])/65535.f*vrsettings::get().value[vrsettings::Haptics]/100.f);XrHapticActionInfo info{XR_TYPE_HAPTIC_ACTION_INFO};info.action=hapticAction;info.subactionPath=paths[hand];
    if(amplitude>0){if(!hapticRunning[hand]||fabsf(amplitude-hapticAmplitude[hand])>.01f||now-hapticTick[hand]>=35){XrHapticVibration vibration{XR_TYPE_HAPTIC_VIBRATION};vibration.amplitude=amplitude;vibration.frequency=XR_FREQUENCY_UNSPECIFIED;vibration.duration=50000000;XrResult result=xrApplyHapticFeedback(session,&info,(const XrHapticBaseHeader*)&vibration);hapticRunning[hand]=XR_SUCCEEDED(result);hapticTick[hand]=now;hapticAmplitude[hand]=amplitude;}}
    else if(hapticRunning[hand]){xrStopHapticFeedback(session,&info);hapticRunning[hand]=false;hapticAmplitude[hand]=0;}
   }
  }

  // Locate real asymmetric left/right eye poses at the XR predicted display time.
  // This is independent of the mono game camera and does not touch the game renderer.
  XrViewLocateInfo locate{XR_TYPE_VIEW_LOCATE_INFO};
  locate.viewConfigurationType=XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
  locate.displayTime=frame.predictedDisplayTime;
  locate.space=stage;
  XrViewState viewState{XR_TYPE_VIEW_STATE};
  XrView xrEyes[2]={{XR_TYPE_VIEW},{XR_TYPE_VIEW}};
  uint32_t viewCount=0;
  XrResult viewResult=xrLocateViews(session,&locate,&viewState,2,&viewCount,xrEyes);
  const XrViewStateFlags required = XR_VIEW_STATE_ORIENTATION_VALID_BIT | XR_VIEW_STATE_POSITION_VALID_BIT;
  bool eyeValid=XR_SUCCEEDED(viewResult)&&viewCount==2&&((viewState.viewStateFlags&required)==required);
  if(sampleCount%180==0)printf("XR stereo eye views valid=%d count=%u result=%ld\n",eyeValid?1:0,viewCount,(long)viewResult);


  trackedHands.update(stage,frame.predictedDisplayTime);
  RFGRPose poses[5]={};
  XrSpaceLocation loc{XR_TYPE_SPACE_LOCATION};
  if(XR_SUCCEEDED(xrLocateSpace(view,stage,frame.predictedDisplayTime,&loc)))poses[0]=convert(loc);
  for(int hand=0;hand<2;hand++){
   XrActionStateGetInfo get{XR_TYPE_ACTION_STATE_GET_INFO};get.action=poseAction;get.subactionPath=paths[hand];
   XrActionStatePose state{XR_TYPE_ACTION_STATE_POSE};
   if(XR_SUCCEEDED(xrGetActionStatePose(session,&get,&state))&&state.isActive){
    XrSpaceLocation handLoc{XR_TYPE_SPACE_LOCATION};
    XrSpace which=hand?rightSpace:leftSpace;
    if(XR_SUCCEEDED(xrLocateSpace(which,stage,frame.predictedDisplayTime,&handLoc))){poses[hand+1]=convert(handLoc);poses[hand+1].active=1;}
   }
  }
  for(int hand=0;hand<2;++hand){XrSpaceLocation aim{XR_TYPE_SPACE_LOCATION};if(XR_SUCCEEDED(xrLocateSpace(aimSpaces[hand],stage,frame.predictedDisplayTime,&aim))){poses[hand+3]=convert(aim);poses[hand+3].active=poses[hand+1].active;}}
  // OpenXR input is sampled on the XR frame thread. The 32-bit game side only emits
  // keyboard events when the game is foreground; it never hooks or edits game menus.
  if(shm){
   XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO};
   XrActionStateBoolean confirm{XR_TYPE_ACTION_STATE_BOOLEAN},back{XR_TYPE_ACTION_STATE_BOOLEAN};
   XrActionStateVector2f axis{XR_TYPE_ACTION_STATE_VECTOR2F};
   gi.action=confirmAction;const bool haveConfirm=XR_SUCCEEDED(xrGetActionStateBoolean(session,&gi,&confirm));
   gi.action=backAction;const bool haveBack=XR_SUCCEEDED(xrGetActionStateBoolean(session,&gi,&back));
   gi.action=navAction;const bool haveAxis=XR_SUCCEEDED(xrGetActionStateVector2f(session,&gi,&axis));
   auto button=[&](XrAction action,XrPath hand=XR_NULL_PATH){XrActionStateGetInfo q{XR_TYPE_ACTION_STATE_GET_INFO};q.action=action;q.subactionPath=hand;XrActionStateBoolean v{XR_TYPE_ACTION_STATE_BOOLEAN};return XR_SUCCEEDED(xrGetActionStateBoolean(session,&q,&v))&&v.isActive&&v.currentState;};
   auto value=[&](XrAction action,XrPath hand){XrActionStateGetInfo q{XR_TYPE_ACTION_STATE_GET_INFO};q.action=action;q.subactionPath=hand;XrActionStateFloat v{XR_TYPE_ACTION_STATE_FLOAT};return XR_SUCCEEDED(xrGetActionStateFloat(session,&q,&v))&&v.isActive?v.currentState:0.f;};
   XrActionStateVector2f look{XR_TYPE_ACTION_STATE_VECTOR2F};gi.action=lookAction;xrGetActionStateVector2f(session,&gi,&look);
   RFGRGamepad pad{};pad.leftX=RFGRVR_Axis(axis.isActive?axis.currentState.x:0);pad.leftY=RFGRVR_Axis(axis.isActive?axis.currentState.y:0);
   pad.rightX=RFGRVR_Axis(look.isActive?look.currentState.x:0);pad.rightY=RFGRVR_Axis(look.isActive?look.currentState.y:0);
   pad.leftTrigger=RFGRVR_Trigger(value(triggerAction,leftPath));pad.rightTrigger=RFGRVR_Trigger(value(triggerAction,rightPath));
   if(button(confirmAction))pad.buttons|=0x1000;if(button(backAction))pad.buttons|=0x2000;
   if(button(xAction))pad.buttons|=0x4000;if(button(yAction))pad.buttons|=0x8000;
   if(button(menuAction))pad.buttons|=0x10;if(button(viewAction))pad.buttons|=0x20;
   if(button(thumbAction,leftPath))pad.buttons|=0x40;if(button(thumbAction,rightPath))pad.buttons|=0x80;
   if(button(bumperAction,leftPath))pad.buttons|=0x100;
   if(button(bumperAction,rightPath))pad.buttons|=0x200;
   for(int i=0;i<4;++i)if(button(dpadAction[i]))pad.buttons|=(1<<i);
   float rawGrip[2]={vrcontrollers::grip(settingsPanel.controllerKind[0],value(squeezeAction,leftPath)),vrcontrollers::grip(settingsPanel.controllerKind[1],value(squeezeAction,rightPath))} ,rawControls[vrsettings::SourceCount]{};
   const RFGRGamepad physicalPad=pad;static vrquest::Layout questLayout;
   const bool questGameplay=settingsPanel.controllerKind[0]==vrcontrollers::QuestTouch&&settingsPanel.controllerKind[1]==vrcontrollers::QuestTouch&&calibrationConfirmed&&shm->gameplayActive&&!theaterMode&&!vrsettings::paused();
   pad=questLayout.update(pad,rawGrip[0],rawGrip[1],questGameplay,shm->playerParentState,GetTickCount64());
   if(!questGameplay)vrcontrollers::fallback(settingsPanel.controllerKind[0],settingsPanel.controllerKind[1],pad);
   if(!questGameplay&&settingsPanel.active&&settingsPanel.controllerKind[0]==vrcontrollers::QuestTouch){pad.buttons&=~(0xc000u|0x20u|0x300u);if(physicalPad.buttons&0x4000)pad.buttons|=0x100;if(physicalPad.buttons&0x8000)pad.buttons|=0x200;}
   bool indexTouchSelection=false;const bool indexProfile=settingsPanel.controllerKind[0]==vrcontrollers::Index&&settingsPanel.controllerKind[1]==vrcontrollers::Index;
   if(indexProfile){
    auto trackpad=[&](XrPath hand){XrActionStateGetInfo q{XR_TYPE_ACTION_STATE_GET_INFO};q.action=trackpadAction;q.subactionPath=hand;XrActionStateVector2f v{XR_TYPE_ACTION_STATE_VECTOR2F};bool valid=XR_SUCCEEDED(xrGetActionStateVector2f(session,&q,&v))&&v.isActive;return vrindex::Pad{valid?v.currentState.y:0,value(trackpadForceAction,hand),valid&&button(trackpadTouchAction,hand)};};
    static vrindex::Layout indexLayout;bool gameplay=calibrationConfirmed&&shm->gameplayActive&&!theaterMode&&!vrsettings::paused();indexLayout.rightHeightGrip=rawGrip[1]>.65f;pad=indexLayout.update(pad,trackpad(leftPath),trackpad(rightPath),gameplay,settingsPanel.active,shm->playerParentState,GetTickCount64());indexTouchSelection=indexLayout.selectionHeld;
   }
   unsigned questCommands=pad.buttons&vrquest::Commands;vrsettings::physical(pad,rawGrip,rawControls);
   notificationLayout.input(false);if(notificationLayout.closed){worldHudUpdated[7]=worldHudUpdated[8]=0;notificationLayout.closed=false;}auto userConfig=vrsettings::get();settingsConsumed=settingsPanel.input(poses[0],poses[4],pad,rawControls);
   if(auto* settingsBus=vrsettings::bus())if(InterlockedExchange(&settingsBus->recalibrateRequest,0))settingsPanel.recalibrate=true;
   if(settingsPanel.recalibrate){settingsPanel.recalibrate=false;calibrationConfirmed=false;calibrationHold=0;calibrationSamples.reset();headGuide.reset();bootSequence.reset();bootAvatar.avatar.anchored=bootAvatar.avatar.matched=false;floorScreen.reset();shm->calibrationReady=0;}
   if(calibrationConfirmed&&!vrsettings::paused()&&shm->gameplayActive&&!theaterMode)pad=vrsettings::remap(userConfig,rawControls,rawGrip);
   pad.buttons|=questCommands;
   if(settingsConsumed)pad={};
   if(weaponSelector.update(indexProfile?indexTouchSelection:((questGameplay&&questLayout.selectionHeld)||(pad.buttons&0x200)!=0),calibrationConfirmed&&shm->gameplayActive&&!theaterMode&&!vrsettings::paused(),poses[0],poses[2],GetTickCount64(),500)){
    if(questGameplay)pad.buttons=(pad.buttons&~(0xf000u|vrquest::Commands))|(physicalPad.buttons&0x7000u)|0x200;
    if(indexTouchSelection)pad.buttons=(pad.buttons&~(0xf000u|vrquest::Commands))|(physicalPad.buttons&0xf000u)|0x200;
    pad.buttons=weaponSelector.buttons(pad.buttons);pad.rightX=pad.rightY=0;pad.leftTrigger=pad.rightTrigger=0;
   }
   if(!calibrationConfirmed){
    if(headGuide.active){headGuide.update(poses[0],GetTickCount64());if(headGuide.done){bootSequence.match(GetTickCount64());shm->calibratedHeadHeight=pendingHeight;shm->calibratedArmSpan=pendingSpan;InterlockedExchange(&shm->calibrationFloorValid,roomStage?1:0);MemoryBarrier();InterlockedExchange(&shm->calibrationReady,1);calibrationConfirmed=true;menuWorldAnchorValid=false;if(auto* bus=vrsettings::bus())InterlockedExchange(&bus->recalibrated,1);printf("Head rotation complete: samples=%u fitted=%d saved=%d error=%.4f\n",unsigned(headGuide.samples.size()),headGuide.fitted.valid,headGuide.saved,headGuide.fitted.error);}}
    else {

    float height=0,span=0;calibrationPose=RFGRVR_TPose(poses[0],poses[1],poses[2],roomStage&&!userConfig.value[vrsettings::Seated],height,span);
    bool held=bootSequence.roomPresented&&calibrationPose&&pad.leftTrigger>220&&pad.rightTrigger>220;
    ULONGLONG now=GetTickCount64();if(!held){calibrationHold=0;calibrationSamples.reset();}
    else if(!calibrationSamples.add(height,span))calibrationHold=0;
    else if(!calibrationHold)calibrationHold=now;
    calibrationProgress=calibrationHold?std::min(1.f,float(now-calibrationHold)/1000.f):0;
    if(calibrationProgress>=1){calibrationSamples.average(height,span);if(userConfig.value[vrsettings::Seated]){height=shm->calibratedHeadHeight>=1?shm->calibratedHeadHeight:1.65f;userConfig.seatHeightCm=int(poses[0].position[1]*100);vrsettings::save(userConfig);}}
    if(calibrationProgress>=1){pendingHeight=height;pendingSpan=span;headGuide.begin(poses[0]);calibrationHold=0;calibrationSamples.reset();calibrationProgress=0;}
    }
   }
   if(calibrationConfirmed&&!bootSequence.ready&&bootSequence.mayLaunch(GetTickCount64())&&saveCalibration(shm->calibratedHeadHeight,shm->calibratedArmSpan,roomStage))bootSequence.ready=true;
   const bool padActive=calibrationConfirmed&&bootSequence.ready&&(axis.isActive||look.isActive||confirm.isActive);
   float gripValues[2]={settingsConsumed?0.f:rawGrip[0],settingsConsumed?0.f:rawGrip[1]};mapPlacement.squeeze=gripValues[1];
   InterlockedIncrement(&shm->inputSequence);MemoryBarrier();shm->gamepad=pad;shm->gamepadActive=padActive;for(unsigned hand=0;hand<2;++hand)shm->gripValue[hand]=padActive&&!(mapPlacement.editing&&hand==1)?gripValues[hand]:0.f;InterlockedIncrement(&shm->inputSamples);MemoryBarrier();InterlockedIncrement(&shm->inputSequence);
   if(sampleCount%180==0)printf("Gamepad active=%d buttons=%04X sticks=%d,%d,%d,%d triggers=%u,%u\n",padActive,pad.buttons,pad.leftX,pad.leftY,pad.rightX,pad.rightY,pad.leftTrigger,pad.rightTrigger);
   InterlockedExchange(&shm->menuSelect,(!settingsConsumed&&haveConfirm&&confirm.isActive&&confirm.currentState)?1:0);
   InterlockedExchange(&shm->menuBack,(!settingsConsumed&&haveBack&&back.isActive&&back.currentState)?1:0);
   InterlockedExchange(&shm->menuNavX,(!settingsConsumed&&((pad.buttons&8)||(haveAxis&&axis.isActive&&axis.currentState.x>.55f)))?1:
     (!settingsConsumed&&((pad.buttons&4)||(haveAxis&&axis.isActive&&axis.currentState.x<-.55f)))?-1:0);
   InterlockedExchange(&shm->menuNavY,(!settingsConsumed&&((pad.buttons&1)||(haveAxis&&axis.isActive&&axis.currentState.y>.55f)))?1:
     (!settingsConsumed&&((pad.buttons&2)||(haveAxis&&axis.isActive&&axis.currentState.y<-.55f)))?-1:0);
  }
  writePoses(poses[0],poses[1],poses[2],poses[3],poses[4],xrEyes,eyeValid,frame.predictedDisplayTime);renderClock.publish(frame.predictedDisplayTime,frame.predictedDisplayPeriod,frame.shouldRender!=0);sampleCount++;
  if(!trackingStarted){trackingStarted=true;report(5,"OpenXR frame loop running; pose transport active (hands may be unbound).");}
  if(sampleCount==1||sampleCount%180==0){
    for(int hand=0;hand<2;++hand){
      XrInteractionProfileState profileState{XR_TYPE_INTERACTION_PROFILE_STATE};
      XrResult pr=xrGetCurrentInteractionProfile(session,paths[hand],&profileState);
      if(XR_SUCCEEDED(pr)&&profileState.interactionProfile!=XR_NULL_PATH){
        char pathText[256]={};uint32_t needed=0;
        if(XR_SUCCEEDED(xrPathToString(instance,profileState.interactionProfile,sizeof(pathText),&needed,pathText)))
          {auto kind=vrcontrollers::detect(pathText);if(settingsPanel.controllerKind[hand]!=kind){settingsPanel.controllerKind[hand]=kind;strcpy_s(settingsPanel.controller[hand],vrcontrollers::name(kind));settingsPanel.dirty=true;printf("Active hand %d: %s (%s)\n",hand,vrcontrollers::name(kind),pathText);}}
      } else printf("Active hand %d profile: none (result=%ld)\n",hand,(long)pr);
    }
  }
  if(sampleCount%90==0)printf("samples=%d hmdFlags=%u leftFlags=%u rightFlags=%u game_pid=%ld\n",sampleCount,poses[0].validFlags,poses[1].validFlags,poses[2].validFlags,shm?shm->gamePid:0);
  // Setup/render diagnostic hotkeys are retired; saved presentation stays active.
  if(shm)InterlockedExchange(&shm->theaterMode,theaterMode?1:0);
  RFGRWeaponHudPose hudPose{};bool hudPoseValid=false;
  if(!hudPoseShared){if(!hudPoseMapping)hudPoseMapping=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_WEAPON_HUD_POSE);if(hudPoseMapping)hudPoseShared=(RFGRWeaponHudPose*)RFGRVR_MapViewOrClose(hudPoseMapping,FILE_MAP_READ,0,0,sizeof(RFGRWeaponHudPose));}
  if(hudPoseShared)for(int attempt=0;attempt<3;++attempt){LONG seq=hudPoseShared->sequence;if(seq&1)continue;MemoryBarrier();memcpy(&hudPose,hudPoseShared,sizeof(hudPose));MemoryBarrier();if(seq==hudPoseShared->sequence){hudPoseValid=hudPose.magic==0x48554432&&DWORD(GetTickCount()-hudPose.tick)<200;break;}}
  RFGRReloadCue magazineCue{};bool magazineCueValid=reloadCueReader.read(magazineCue,shm?shm->gamePid:0);
  apcDisplay.read(shm?shm->gamePid:0);
  RFGRVehicleAimPacket vehicleAim{};bool vehicleAimRead=vehicleAimReader.read(shm?shm->gamePid:0,vehicleAim);bool vehicleAimValid=vehicleAimRead;if(vehicleAimValid)vehicleAimValid=vehicleAimPrediction.update(vehicleAim,GetTickCount());else vehicleAimPrediction.ready=false;
  RFGRWristStatus focusStatus{};bool focusActive=wristStatusReader.read(focusStatus,shm?shm->gamePid:0)&&(focusStatus.twoHand&2);float focusStrength=focusVignette.update(focusActive&&vrsettings::get().value[vrsettings::FocusVignette],GetTickCount64());
  vrtraining::Markers trainingMarkers{};bool trainingVisible=trainingReader.read(shm?shm->gamePid:0,trainingMarkers);
  RFGRPropMarkers propMarkers{};bool propMarkersValid=propMarkerReader.read(propMarkers);vrarm::V gripHint{};float gripHintAlpha=0;RFGRPose hintHands[2]={poses[1],poses[2]};bool gripHintVisible=hudPoseValid&&RFGRVR_GripHint(hudPose,hintHands,gripHint,gripHintAlpha);
  XrCompositionLayerProjection projection{XR_TYPE_COMPOSITION_LAYER_PROJECTION};
  XrCompositionLayerProjectionView projectedEyes[2]={{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW},{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW}};
  // Once both independently produced eye images arrive, keep projection mode stable.
  // A missed temporal eye update must not turn the headset into a flashing quad.
  if(shm&&cachedSceneGame!=shm->gamePid){stereoPairCached=false;cachedSceneGame=shm->gamePid;}
  const bool mainMenuScene=shm&&shm->playerParentState==0x101&&!theaterMode;
  const bool popupMenuScene=shm&&shm->playerParentState==0x102&&!theaterMode;
  static RFGRVRSceneTransition sceneTransition;const bool sceneContinuity=sceneTransition.update(shm?shm->gamePid:0,popupMenuScene,mainMenuScene||panelVisible||theaterMode,shm&&shm->gameplayActive,GetTickCount64());
  static bool transitionGameplay=false;static ULONGLONG transitionTick=0;bool desiredGameplay=shm&&(shm->gameplayActive||sceneContinuity)&&!panelVisible&&!theaterMode;if(desiredGameplay!=transitionGameplay){transitionGameplay=desiredGameplay;transitionTick=GetTickCount64();menuWorldAnchorValid=false;}float transitionFade=transitionTick?(std::max)(0.f,1.f-float(GetTickCount64()-transitionTick)/250.f):0.f;transitionFade=transitionFade*transitionFade*(3.f-2.f*transitionFade);
  unsigned presentation=mainMenuScene?1:popupMenuScene?2:shm&&!shm->gameplayActive?3:0;floorScreen.show(presentation);
  const bool menuModal=mainMenuScene||popupMenuScene;
  const bool mainMenuReady=mainMenuLayers.frame(device,context,session,stage,selectedFormat,poses[0],menuModal&&calibrationConfirmed&&frame.shouldRender,mainMenuScene,floorScreen,xrCreateSwapchain,xrEnumerateSwapchainImages,xrAcquireSwapchainImage,xrWaitSwapchainImage,xrReleaseSwapchainImage);
  stereoGpu.scale.preserveAlpha=mainMenuScene;
  static bool previousMenuScene=false;if(previousMenuScene!=mainMenuScene){stereoPairCached=false;lastPairTick=0;previousMenuScene=mainMenuScene;}
  const bool worldMenuActive=false; // Native full menu screen; isolated foreground experiment retired.
  if(worldMenuActive!=worldMenuWasActive){menuWorldAnchorValid=false;worldMenuWasActive=worldMenuActive;menuUpdated=0;}
  bool genuineStereo=false;bool gripSphereDrawn[2]{},focusDrawn[2]{};
  if(bootSequence.released&&calibrationConfirmed&&projectionReady&&eyeValid&&frame.shouldRender&&!panelVisible&&!theaterMode&&shm&&(shm->gameplayActive||sceneContinuity||worldMenuActive||popupMenuScene||(mainMenuScene&&mainMenuReady))){
   // Build replacement first. Keep the working swapchain if allocation fails.
   {unsigned desiredW=defaultProjectionWidth,desiredH=defaultProjectionHeight;float fovs[2][4];for(unsigned e=0;e<2;++e)memcpy(fovs[e],&xrEyes[e].fov,16);int ppd=vrsettings::get().value[vrsettings::PPD];if(ppd)RFGRVR_PPDSize(ppd,fovs,&desiredW,&desiredH);
    auto now=GetTickCount64();if(!worldMenuActive&&(desiredW!=projectionWidth||desiredH!=projectionHeight)&&now-projectionResizeAttempt>1000){projectionResizeAttempt=now;XrSwapchain replacement=XR_NULL_HANDLE;XrSwapchainCreateInfo sc{XR_TYPE_SWAPCHAIN_CREATE_INFO};sc.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT|XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT;sc.format=selectedFormat;sc.sampleCount=1;sc.width=desiredW;sc.height=desiredH;sc.faceCount=1;sc.arraySize=2;sc.mipCount=1;
     XrResult created=xrCreateSwapchain(session,&sc,&replacement);if(XR_FAILED(created)){sc.usageFlags=XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT;created=xrCreateSwapchain(session,&sc,&replacement);}uint32_t n=0;std::vector<XrSwapchainImageD3D11KHR> images;
     bool valid=XR_SUCCEEDED(created)&&XR_SUCCEEDED(xrEnumerateSwapchainImages(replacement,0,&n,nullptr))&&n;if(valid){images.resize(n);for(auto& im:images)im.type=XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;valid=XR_SUCCEEDED(xrEnumerateSwapchainImages(replacement,n,&n,reinterpret_cast<XrSwapchainImageBaseHeader*>(images.data())));}
     if(valid){xrDestroySwapchain(projectionSwapchain);projectionSwapchain=replacement;projectionImages=std::move(images);projectionWidth=desiredW;projectionHeight=desiredH;for(auto& target:projectionTargets)if(target){target->Release();target=nullptr;}stereoPairCached=false;lastStereoFrames[0]=lastStereoFrames[1]=-1;printf("PPD %d projection=%ux%u\n",ppd,projectionWidth,projectionHeight);}else if(replacement)xrDestroySwapchain(replacement);
    }}
   const bool connected=stereoGpu.attach(device);
   if(connected&&stereoGpu.epochChanged){lastStereoFrames[0]=lastStereoFrames[1]=0;}
   const bool haveNewPair=connected&&(mainMenuScene?stereoGpu.state->renderMode==4:stereoGpu.state->renderMode!=4)&&stereoGpu.state->eyeFrames[0]>0&&stereoGpu.state->eyeFrames[1]>0&&
      (stereoGpu.state->eyeFrames[0]!=lastStereoFrames[0]||stereoGpu.state->eyeFrames[1]!=lastStereoFrames[1]);
   // Targets retain the last complete stereo pair, but they are invalidated if
   // the producer disconnects (otherwise we'd show indefinitely stale imagery).
   // Locally owned eye images remain valid through producer teardown/resize.
   // Gameplay freshness expires below; menus retain the last complete scene.
   if(haveNewPair&&!worldMenuActive){
    bool ready=true;
    for(unsigned eye=0;eye<2;++eye){
     if(!projectionTargets[eye]){
      D3D11_TEXTURE2D_DESC td{};td.Width=projectionWidth;td.Height=projectionHeight;
      td.MipLevels=1;td.ArraySize=1;td.Format=selectedFormat;
      td.SampleDesc.Count=1;td.Usage=D3D11_USAGE_DEFAULT;td.BindFlags=D3D11_BIND_RENDER_TARGET;
      if(FAILED(device->CreateTexture2D(&td,nullptr,&projectionTargets[eye])))ready=false;
     }
    }
    if(ready){
     ID3D11Texture2D* targets[2]={projectionTargets[0],projectionTargets[1]};
     ready=stereoGpu.copyPair(context,targets,xrEyes,gameVFovDegrees);
    }
    if(ready){
     lastStereoFrames[0]=stereoGpu.consumedFrames[0];
     lastStereoFrames[1]=stereoGpu.consumedFrames[1];
     stereoPairCached=true;
     lastPairTick=GetTickCount64();
    }else ++missedStereoPairs;
   }
   if(RFGRVR_SubmitCachedScene(stereoPairCached,worldMenuActive||sceneContinuity,GetTickCount64(),lastPairTick)){
    XrSwapchainImageAcquireInfo ac{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};uint32_t ix=0;
    XrResult r=xrAcquireSwapchainImage(projectionSwapchain,&ac,&ix);
    if(XR_SUCCEEDED(r)){
     XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wi.timeout=XR_INFINITE_DURATION;
     if(XR_SUCCEEDED(xrWaitSwapchainImage(projectionSwapchain,&wi))&&ix<projectionImages.size()){
      D3D11_TEXTURE2D_DESC imageDesc{};
      projectionImages[ix].texture->GetDesc(&imageDesc);
      if(imageDesc.Width==projectionWidth&&imageDesc.Height==projectionHeight&&imageDesc.ArraySize>=2){
       for(unsigned eye=0;eye<2;++eye){
        context->CopySubresourceRegion(projectionImages[ix].texture,D3D11CalcSubresource(0,eye,1),0,0,0,projectionTargets[eye],0,nullptr);
        projectedEyes[eye].pose=stereoGpu.recordedPose?stereoGpu.renderedViews[eye].pose:xrEyes[eye].pose;
        projectedEyes[eye].fov=stereoGpu.recordedPose?stereoGpu.renderedViews[eye].fov:xrEyes[eye].fov;
        if(transitionFade>.001f)focusVignette.draw(device,context,projectionImages[ix].texture,eye,projectedEyes[eye].fov,transitionFade,false,0,0,-1,true);
        if(focusStrength>.001f)focusDrawn[eye]=focusVignette.draw(device,context,projectionImages[ix].texture,eye,projectedEyes[eye].fov,focusStrength);
        if(vehicleAimValid)for(unsigned marker=0;marker<vehicleAim.count;++marker){const auto& eyePose=projectedEyes[eye].pose;vrarm::V delta{vehicleAim.target[marker][0]-eyePose.position.x,vehicleAim.target[marker][1]-eyePose.position.y,vehicleAim.target[marker][2]-eyePose.position.z};vrarm::V q{-eyePose.orientation.x,-eyePose.orientation.y,-eyePose.orientation.z};auto local=vrarm::add(delta,vrarm::add(vrarm::mul(vrarm::cross(q,delta),2*eyePose.orientation.w),vrarm::mul(vrarm::cross(q,vrarm::cross(q,delta)),2)));if(local.z<-.1f)focusVignette.draw(device,context,projectionImages[ix].texture,eye,projectedEyes[eye].fov,0,true,local.x/-local.z,local.y/-local.z);
 if(vehicleAim.bounds&(1u<<marker))for(unsigned corner=0;corner<4;++corner){vrarm::V d{vehicleAim.corners[marker][corner][0]-eyePose.position.x,vehicleAim.corners[marker][corner][1]-eyePose.position.y,vehicleAim.corners[marker][corner][2]-eyePose.position.z};auto p=vrarm::add(d,vrarm::add(vrarm::mul(vrarm::cross(q,d),2*eyePose.orientation.w),vrarm::mul(vrarm::cross(q,vrarm::cross(q,d)),2)));if(p.z<-.1f)focusVignette.draw(device,context,projectionImages[ix].texture,eye,projectedEyes[eye].fov,0,true,p.x/-p.z,p.y/-p.z,int(corner));}}
        if(magazineCueValid){float pulse=.07f+.12f*(.5f-.5f*cosf(float(GetTickCount()%1800)*6.2831853f/1800));gripHintRenderer.draw(device,context,projectionImages[ix].texture,eye,projectedEyes[eye].pose,projectedEyes[eye].fov,{magazineCue.center[0],magazineCue.center[1],magazineCue.center[2]},pulse,{1,.02f,.01f},magazineCue.radius);}
        if(trainingVisible)for(unsigned i=0;i<trainingMarkers.count;++i){vrarm::V color=trainingMarkers.state[i]==2?vrarm::V{.05f,1.f,.12f}:trainingMarkers.state[i]==1?vrarm::V{1.f,.65f,.08f}:vrarm::V{.12f,.55f,1.f};gripHintRenderer.draw(device,context,projectionImages[ix].texture,eye,projectedEyes[eye].pose,projectedEyes[eye].fov,{trainingMarkers.points[i][0],trainingMarkers.points[i][1],trainingMarkers.points[i][2]},.6f,color,.045f);}
        if(propMarkersValid)for(unsigned i=0;i<propMarkers.count;++i)gripHintRenderer.draw(device,context,projectionImages[ix].texture,eye,projectedEyes[eye].pose,projectedEyes[eye].fov,{propMarkers.point[i][0],propMarkers.point[i][1],propMarkers.point[i][2]},i==propMarkers.selected?.65f:.35f,i==propMarkers.selected?vrarm::V{1,1,1}:vrarm::V{.55f,.55f,.55f},.035f);
        if(gripHintVisible)gripSphereDrawn[eye]=gripHintRenderer.draw(device,context,projectionImages[ix].texture,eye,projectedEyes[eye].pose,projectedEyes[eye].fov,gripHint,gripHintAlpha);
        projectedEyes[eye].subImage.swapchain=projectionSwapchain;
        projectedEyes[eye].subImage.imageRect.offset={0,0};
        projectedEyes[eye].subImage.imageRect.extent={(int32_t)projectionWidth,(int32_t)projectionHeight};
        projectedEyes[eye].subImage.imageArrayIndex=eye;
       }
       context->Flush();
       projection.layerFlags=mainMenuScene?XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT:0;projection.space=stage;projection.viewCount=2;projection.views=projectedEyes;
       genuineStereo=true;
       ++projectedFrames;
       if(!haveNewPair)++repeatedStereoFrames;
       if(projectedFrames%180==0)
         printf("%s STEREO: projection=%lu repeated=%lu failedPairs=%lu eyeFrames=%ld/%ld ack=%ld/%ld\n",
          stereoGpu.nativePair?"SAME-FRAME":"TEMPORAL",projectedFrames,repeatedStereoFrames,missedStereoPairs,
         lastStereoFrames[0],lastStereoFrames[1],stereoGpu.acknowledgement(0),stereoGpu.acknowledgement(1));
      }
     }
     XrSwapchainImageReleaseInfo rel{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};xrReleaseSwapchainImage(projectionSwapchain,&rel);
    }
   }
  }
  bool bootMessageVisible=false;
  if(!bootSequence.released&&bootSequence.ready&&shm&&shm->gamePid&&gpuPreview.attach(device)&&gpuPreview.copy(device,context,panelSource)){bootSequence.released=true;transitionTick=GetTickCount64();transitionFade=1;}
  if(!bootSequence.released&&projectionReady&&eyeValid&&frame.shouldRender&&bootAvatar.loaded&&(poses[0].validFlags&3)==3){
   auto convert=[](const RFGRPose& p){return vrarm::Pose{vrboot::quaternion(p.orientation[0],p.orientation[1],p.orientation[2],p.orientation[3]),{p.position[0],p.position[1],p.position[2]}};};
   for(unsigned hand=0;hand<2;++hand)if((poses[hand+1].validFlags&3)==3)bootHands[hand]=convert(poses[hand+1]);
   auto head=convert(poses[0]);float height=shm&&shm->calibratedHeadHeight>1?shm->calibratedHeadHeight:1.7f,span=shm&&shm->calibratedArmSpan>1?shm->calibratedArmSpan:1.7f;auto now=GetTickCount64();float visibility=bootSequence.visibility(now);
   bootAvatar.avatar.relaxed=headGuide.active||calibrationConfirmed;bootAvatar.avatar.armDrop=headGuide.active&&headGuide.phase==0?(std::clamp)(float(now-headGuide.phaseBegan)/450.f,0.f,1.f):1.f;bootAvatar.avatar.lookTargetActive=headGuide.active||headGuide.done;bootAvatar.avatar.lookTarget=headGuide.targetPoint();
   bool drawn=bootAvatar.update(device,context,head.p,head.b,bootHands,false,headGuide.active?pendingHeight:height,headGuide.active?pendingSpan:span,bootSequence.blend(now));
   XrSwapchainImageAcquireInfo ac{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};uint32_t ix=0;if(drawn&&XR_SUCCEEDED(xrAcquireSwapchainImage(projectionSwapchain,&ac,&ix))){XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wi.timeout=XR_INFINITE_DURATION;if(XR_SUCCEEDED(xrWaitSwapchainImage(projectionSwapchain,&wi))&&ix<projectionImages.size()){
    for(unsigned eye=0;eye<2;++eye){const auto& e=xrEyes[eye];vrarm::Pose viewPose{vrboot::quaternion(e.pose.orientation.x,e.pose.orientation.y,e.pose.orientation.z,e.pose.orientation.w),{e.pose.position.x,e.pose.position.y,e.pose.position.z}};float fov[4]={e.fov.angleLeft,e.fov.angleRight,e.fov.angleUp,e.fov.angleDown};drawn=bootAvatar.draw(device,context,projectionImages[ix].texture,eye,viewPose,fov,visibility)&&drawn;projectedEyes[eye].pose=e.pose;projectedEyes[eye].fov=e.fov;projectedEyes[eye].subImage.swapchain=projectionSwapchain;projectedEyes[eye].subImage.imageRect.extent={int32_t(projectionWidth),int32_t(projectionHeight)};projectedEyes[eye].subImage.imageArrayIndex=eye;}
    if(drawn){bootSequence.roomPresented=true;projection.space=stage;projection.viewCount=2;projection.views=projectedEyes;genuineStereo=true;bootText.guide=&headGuide;bootMessageVisible=bootText.frame(context,session,stage,selectedFormat,bootAvatar.avatar,calibrationConfirmed,visibility,calibrationProgress,xrCreateSwapchain,xrEnumerateSwapchainImages,xrAcquireSwapchainImage,xrWaitSwapchainImage,xrReleaseSwapchainImage);}
   }XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};xrReleaseSwapchainImage(projectionSwapchain,&release);}
  }
  if(!bootSequence.released&&sampleCount%180==0){wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);if(auto* slash=wcsrchr(path,L'\\')){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"..\\..\\output\\calibration-scene-state.json");FILE* file=nullptr;if(!_wfopen_s(&file,path,L"w")&&file){fprintf(file,"{\"modelLoaded\":%s,\"projectionReady\":%s,\"eyesValid\":%s,\"headFlags\":%u,\"shouldRender\":%s,\"eyeDraws\":%u,\"targetFormat\":%u,\"error\":%ld,\"stage\":\"%s\",\"roomPresented\":%s}\n",bootAvatar.loaded?"true":"false",projectionReady?"true":"false",eyeValid?"true":"false",poses[0].validFlags,frame.shouldRender?"true":"false",bootAvatar.draws,bootAvatar.lastFormat,long(bootAvatar.lastError),bootAvatar.lastStage,bootSequence.roomPresented?"true":"false");fclose(file);}}}
  // A compositor focus/tracking gap does not destroy our locally owned scene.
  // Drain the mono producer even in projection mode, so returning to a menu
  // cannot display the first old frame still waiting on its keyed mutex.
  if(genuineStereo&&!worldMenuActive&&gpuPreview.attach(device))gpuPreview.copy(device,context,panelSource);
  if(genuineStereo!=wasProjection){menuWorldAnchorValid=false;wasProjection=genuineStereo;
   printf("Display mode: %s\n",genuineStereo?"gameplay projection":"menu screen");}
  XrCompositionLayerQuad quad{XR_TYPE_COMPOSITION_LAYER_QUAD};
  const XrCompositionLayerBaseHeader* submittedLayer=nullptr;
  if(panelReady && frame.shouldRender && (!genuineStereo||worldMenuActive)){
   XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};uint32_t index=0;
   rc=xrAcquireSwapchainImage(eyeSwapchain,&acquire,&index);
   if(XR_SUCCEEDED(rc)){
    XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wait.timeout=XR_INFINITE_DURATION;
    rc=xrWaitSwapchainImage(eyeSwapchain,&wait);
    if(XR_SUCCEEDED(rc) && index<eyeImages.size()){
     if(!calibrationConfirmed){panel.calibration(calibrationProgress,calibrationPose,false);}
     else if(displayedFrames%25==0){
      panel.render(shm&&shm->gamePid!=0,(poses[0].validFlags&3)==3,(poses[1].validFlags&3)==3,(poses[2].validFlags&3)==3,displayedFrames);
     }
     // Top-down GDI DIB returns BGRA bytes. When an RGBA swapchain was selected, the
     // text/background red and blue channels are swapped, but readability remains intact.
     // Test GPU frame has priority; panel remains a visible fallback when producer is absent.
     bool externalGPU=false;
     if(worldMenuActive){if(menuPreview.attach(device)&&menuPreview.copy(device,context,panelSource))menuUpdated=GetTickCount64();externalGPU=menuUpdated&&GetTickCount64()-menuUpdated<1000;}else if(gpuPreview.attach(device))externalGPU=gpuPreview.copy(device,context,panelSource);
     // Prefer live gameplay over the debug panel; F7 deliberately replaces it with the panel.
     // When no game texture is available, show the diagnostic panel as a fallback.
     if(!calibrationConfirmed || panelVisible || (!externalGPU && !(shm && shm->gamePid!=0)))
       context->UpdateSubresource(panelSource,0,nullptr,panel.pixels,PANEL_W*4,0);
     D3D11_TEXTURE2D_DESC sourceDesc{},targetDesc{};
     panelSource->GetDesc(&sourceDesc);eyeImages[index].texture->GetDesc(&targetDesc);
     if(targetDesc.Width==PANEL_W&&targetDesc.Height==PANEL_H&&targetDesc.ArraySize==1){
      context->CopyResource(eyeImages[index].texture,panelSource);
      if(transitionFade>.001f){XrFovf screenFov{-.7f,.7f,.5f,-.5f};focusVignette.draw(device,context,eyeImages[index].texture,0,screenFov,transitionFade,false,0,0,-1,true);}
      context->Flush();
      // Place the panel in tracked stage coordinates, not attached to VIEW space.
      // Anchor is acquired once on display/recenter and remains fixed as the head moves.
      if((poses[0].validFlags&3)==3){auto& h=poses[0];floorScreen.set({h.position[0],h.position[1],h.position[2]},vrboot::quaternion(h.orientation[0],h.orientation[1],h.orientation[2],h.orientation[3]));}
      auto fixed=floorScreen.at(2.f);float yaw=atan2f(fixed.b.f.x,fixed.b.f.z);quad.space=stage;quad.eyeVisibility=XR_EYE_VISIBILITY_BOTH;quad.pose.position={fixed.p.x,fixed.p.y,fixed.p.z};quad.pose.orientation={0,sinf(yaw*.5f),0,cosf(yaw*.5f)};quad.size={2.8f,1.575f};
      quad.subImage.swapchain=eyeSwapchain;quad.subImage.imageRect.offset={0,0};
      quad.subImage.imageRect.extent={PANEL_W,PANEL_H};quad.subImage.imageArrayIndex=0;
      if(worldMenuActive)quad.layerFlags=XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;
      if(!worldMenuActive||externalGPU)submittedLayer=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&quad);
      ++displayedFrames;
      if(displayedFrames==1)printf("First VR menu QUAD submitted.\n");
      if(displayedFrames%180==0)printf("VR menu submitted frames=%lu\n",displayedFrames);
     }else if(displayedFrames==0){printf("Unexpected menu texture dimensions %u x %u\n",targetDesc.Width,targetDesc.Height);}
    }else if(displayedFrames==0){printf("XR panel image wait error=%ld\n",(long)rc);}
    XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};xrReleaseSwapchainImage(eyeSwapchain,&release);
   }else if(displayedFrames==0){printf("XR panel image acquire error=%ld\n",(long)rc);}
  }
  RFGRWristStatus wristStatus{};bool wristStatusValid=wristStatusReader.read(wristStatus,shm?shm->gamePid:0);bool wristHidden=((wristStatusValid&&(wristStatus.twoHand&1)!=0)||(hudPoseValid&&(hudPose.supportHeld&1)!=0))&&!(wristStatusValid&&(wristStatus.twoHand&4));
  XrCompositionLayerQuad wristQuad{XR_TYPE_COMPOSITION_LAYER_QUAD};bool wristVisible=false;RFGRPose wristPose{};
  const bool vehicleMap=shm&&shm->version==RFGR_PROTOCOL&&shm->playerParentState>=7&&shm->playerParentState<=10;
  bool mapPoseValid=vehicleMap?RFGRVR_VehicleMapPose(poses[0],poses[1],poses[2],wristPose):RFGRVR_WristPose(poses[1],wristPose);
  RFGRPose defaultMap=wristPose;DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);bool placementAllowed=genuineStereo&&shm&&foreground==shm->gamePid&&mapPoseValid;bool placementKey=false; // Numpad 0 belongs to magazine-grip placement.mapPoseValid=mapPoseValid&&mapPlacement.update(placementKey,placementAllowed,vehicleMap,mapPlacement.squeeze,poses[2],defaultMap,wristPose);if(mapPlacement.editing)wristHidden=false;
  if(!menuModal&&genuineStereo&&frame.shouldRender&&wristSwapchain&&wristSource&&!wristImages.empty()&&mapPoseValid&&wristPreview.attach(device)){
   if(wristPreview.copy(device,context,wristSource.Get()))wristUpdated=GetTickCount64();
  }

  XrCompositionLayerQuad worldHudQuad[9]={{XR_TYPE_COMPOSITION_LAYER_QUAD},{XR_TYPE_COMPOSITION_LAYER_QUAD}};bool worldHudVisible[9]{};
  for(unsigned hud=0;hud<9;++hud){worldHudQuad[hud].type=XR_TYPE_COMPOSITION_LAYER_QUAD;RFGRPose panelPose{};bool validPose=false;
   RFGRHudAnchor anchor=hud?hudPose.charges:hudPose.ammo;
   if(hudPoseValid&&anchor.hand>=0&&anchor.hand<2)validPose=RFGRVR_HudPose(poses[1+anchor.hand],anchor,panelPose);
   else if(hud==1&&hudPoseValid&&mapPoseValid){panelPose=wristPose;float x=panelPose.orientation[0],y=panelPose.orientation[1],z=panelPose.orientation[2],w=panelPose.orientation[3];panelPose.position[0]+=.155f*(1-2*(y*y+z*z));panelPose.position[1]+=.155f*2*(x*y+z*w);panelPose.position[2]+=.155f*2*(x*z-y*w);validPose=true;}
   if(hud>=3&&mapPoseValid){panelPose=wristPose;float x=panelPose.orientation[0],y=panelPose.orientation[1],z=panelPose.orientation[2],w=panelPose.orientation[3],offset=hud==2?-.12f:hud==3?-.18f:hud==4?-.25f:-.32f;panelPose.position[0]+=offset*2*(x*y-z*w);panelPose.position[1]+=offset*(1-2*(x*x+z*z));panelPose.position[2]+=offset*2*(y*z+x*w);validPose=hud!=3||(wristStatusValid&&(vehicleMap||(wristStatus.twoHand&4)));}
   
   if(hud==4||(hud==5&&!vehicleMap)){validPose=hudPoseValid&&hudPose.chestValid;panelPose=poses[0];if(validPose){memcpy(panelPose.position,hudPose.chestPosition,12);if(hud==5)panelPose.position[1]-=.12f;panelPose.orientation[0]=panelPose.orientation[2]=0;panelPose.orientation[1]=sinf(hudPose.chestYaw*.5f);panelPose.orientation[3]=cosf(hudPose.chestYaw*.5f);}}

   if(hud==6){validPose=false;if(vehicleMap&&mapPoseValid){panelPose=wristPose;float x=panelPose.orientation[0],y=panelPose.orientation[1],z=panelPose.orientation[2],w=panelPose.orientation[3];panelPose.position[0]+=.17f*(1-2*(y*y+z*z));panelPose.position[1]+=.17f*2*(x*y+z*w);panelPose.position[2]+=.17f*2*(x*z-y*w);validPose=true;}else if(vehicleAimRead&&vehicleAim.heatValid){panelPose=poses[0];memcpy(panelPose.position,vehicleAim.heatPosition,12);memcpy(panelPose.orientation,vehicleAim.heatOrientation,16);validPose=true;}}
   if(hud>=7){validPose=mapPoseValid&&!wristHidden;if(validPose){panelPose=wristPose;float x=panelPose.orientation[0],y=panelPose.orientation[1],z=panelPose.orientation[2],w=panelPose.orientation[3],dx=notificationLayout.x,dy=notificationLayout.y-(hud==8?.10f*notificationLayout.scale:0);panelPose.position[0]+=dx*(1-2*(y*y+z*z))+dy*2*(x*y-z*w);panelPose.position[1]+=dx*2*(x*y+z*w)+dy*(1-2*(x*x+z*z));panelPose.position[2]+=dx*2*(x*z-y*w)+dy*2*(y*z+x*w);}}
   if(hud==5&&!vehicleMap)validPose=RFGRVR_ChestLookHudPose(poses[0],panelPose);
   if(hud==4)validPose=RFGRVR_MissionOfferHudPose(poses[0],panelPose);
   if(hud==8&&notificationLayout.editing)continue;
   if(hud==2){int dominant=0;validPose=RFGRVR_InteractionHudPose(poses[0],poses[1+dominant],dominant,panelPose);}
   if(menuModal||!genuineStereo||!frame.shouldRender||!validPose||((hud!=3)&&(!worldHudSwapchain[hud]||worldHudImages[hud].empty()))||!worldHudSource[hud]||(hud!=3&&notificationLayout.needsNativeSource(hud)&&!worldHudPreview[hud].attach(device)))continue;
   if(hud==7&&notificationLayout.editing&&notificationLayout.preview()){if(!notificationLayout.previewUploaded){context->UpdateSubresource(worldHudSource[hud].Get(),0,nullptr,notificationLayout.pixels,512*4,0);notificationLayout.previewUploaded=true;}worldHudUpdated[hud]=GetTickCount64();}
   else if(hud==3){RFGRWristStatus displayed=wristStatus;if(vehicleMap&&!(displayed.twoHand&4)){displayed.twoHand|=8;displayed.messageTick=GetTickCount();strcpy_s(displayed.message,wristStatus.vehicleControls);}if(wristStatusPixels.draw(displayed)){context->UpdateSubresource(worldHudSource[hud].Get(),0,nullptr,wristStatusPixels.pixels,512*4,0);worldHudUpdated[hud]=GetTickCount64();}}else if(worldHudPreview[hud].copy(device,context,worldHudSource[hud].Get()))worldHudUpdated[hud]=GetTickCount64();
   if(!worldHudUpdated[hud]||(GetTickCount64()-worldHudUpdated[hud]>200))continue;
   if(hud==3){worldHudVisible[hud]=true;continue;}
   XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};uint32_t index=0;
   if(XR_SUCCEEDED(xrAcquireSwapchainImage(worldHudSwapchain[hud],&acquire,&index))){XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wait.timeout=XR_INFINITE_DURATION;
    if(XR_SUCCEEDED(xrWaitSwapchainImage(worldHudSwapchain[hud],&wait))&&index<worldHudImages[hud].size()){context->CopyResource(worldHudImages[hud][index].texture,worldHudSource[hud].Get());worldHudVisible[hud]=true;}XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};xrReleaseSwapchainImage(worldHudSwapchain[hud],&release);
   }
   if(worldHudVisible[hud]){auto& q=worldHudQuad[hud];q.layerFlags=XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;q.space=stage;q.eyeVisibility=XR_EYE_VISIBILITY_BOTH;memcpy(&q.pose.position,panelPose.position,12);memcpy(&q.pose.orientation,panelPose.orientation,16);q.size=hud>=7?XrExtent2Df{.24f*notificationLayout.scale,.06f*notificationLayout.scale}:hud==6?XrExtent2Df{.16f,.04f}:hud==5?XrExtent2Df{.28f,.07f}:hud==4?XrExtent2Df{.36f,.09f}:hud==2?XrExtent2Df{.16f,.08f}:hud>=2?XrExtent2Df{hud>=4?.24f:.20f,hud==3?.0625f:hud>=4?.06f:.05f}:XrExtent2Df{.12f,hud?.03f:.04f};q.subImage.swapchain=worldHudSwapchain[hud];q.subImage.imageRect.extent={RFGR_WRIST_SIZE,hud==3?160:RFGR_WRIST_SIZE};}
  }
  if(genuineStereo&&frame.shouldRender&&!wristHidden&&mapPoseValid&&wristUpdated&&GetTickCount64()-wristUpdated<500&&wristSwapchain&&!wristImages.empty()&&wristAtlas.init(device)){
   FLOAT clear[4]{};context->ClearRenderTargetView(wristAtlas.target.Get(),clear);wristAtlas.draw(device,context,0,wristSource.Get(),128,0,512,512);

   if(vehicleMap&&worldHudVisible[5])wristAtlas.draw(device,context,5,worldHudSource[5].Get(),0,512,768,192);
   // The generated status has a 512x160 used region; crop it when copying below.
   if(worldHudVisible[3])wristAtlas.draw(device,context,3,worldHudSource[3].Get(),0,704,768,768);
   XrSwapchainImageAcquireInfo acquire{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};uint32_t index=0;
   if(XR_SUCCEEDED(xrAcquireSwapchainImage(wristSwapchain,&acquire,&index))){XrSwapchainImageWaitInfo wait{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};wait.timeout=XR_INFINITE_DURATION;if(XR_SUCCEEDED(xrWaitSwapchainImage(wristSwapchain,&wait))&&index<wristImages.size()){context->OMSetRenderTargets(0,nullptr,nullptr);context->CopyResource(wristImages[index].texture,wristAtlas.texture.Get());wristVisible=true;}XrSwapchainImageReleaseInfo release{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};xrReleaseSwapchainImage(wristSwapchain,&release);}
   if(wristVisible){wristQuad.layerFlags=XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;wristQuad.space=stage;wristQuad.eyeVisibility=XR_EYE_VISIBILITY_BOTH;memcpy(&wristQuad.pose.position,wristPose.position,12);memcpy(&wristQuad.pose.orientation,wristPose.orientation,16);float x=wristPose.orientation[0],y=wristPose.orientation[1],z=wristPose.orientation[2],w=wristPose.orientation[3],offset=-216.f*.17f/512;wristQuad.pose.position.x+=offset*2*(x*y-z*w);wristQuad.pose.position.y+=offset*(1-2*(x*x+z*z));wristQuad.pose.position.z+=offset*2*(y*z+x*w);wristQuad.size={768.f*.17f/512,944.f*.17f/512};wristQuad.subImage.swapchain=wristSwapchain;wristQuad.subImage.imageRect.extent={768,944};}
  }
  XrCompositionLayerQuad selectionQuad{XR_TYPE_COMPOSITION_LAYER_QUAD};bool selectionVisible=false;
  if(genuineStereo&&weaponSelector.active&&selectionSwapchain&&selectionSource&&selectionPreview.attach(device)){
   if(selectionPreview.copy(device,context,selectionSource.Get()))selectionUpdated=GetTickCount64();
   if(selectionUpdated&&GetTickCount64()-selectionUpdated<200){uint32_t ix=0;XrSwapchainImageAcquireInfo a{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
    if(XR_SUCCEEDED(xrAcquireSwapchainImage(selectionSwapchain,&a,&ix))){XrSwapchainImageWaitInfo w{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};w.timeout=XR_INFINITE_DURATION;if(XR_SUCCEEDED(xrWaitSwapchainImage(selectionSwapchain,&w))&&ix<selectionImages.size()){context->CopyResource(selectionImages[ix].texture,selectionSource.Get());selectionVisible=true;}XrSwapchainImageReleaseInfo r{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};xrReleaseSwapchainImage(selectionSwapchain,&r);}
   }
   if(selectionVisible){selectionQuad.layerFlags=XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT|XR_COMPOSITION_LAYER_UNPREMULTIPLIED_ALPHA_BIT;selectionQuad.space=stage;selectionQuad.eyeVisibility=XR_EYE_VISIBILITY_BOTH;memcpy(&selectionQuad.pose.position,weaponSelector.anchor.position,12);memcpy(&selectionQuad.pose.orientation,weaponSelector.anchor.orientation,16);selectionQuad.size={.30f,.30f};selectionQuad.subImage.swapchain=selectionSwapchain;selectionQuad.subImage.imageRect.extent={512,512};}
  }
  if(sampleCount%180==0)printf("Focus cue: state=%d amount=%.3f eyes=%d/%d projection=%d\n",focusActive,focusStrength,focusDrawn[0],focusDrawn[1],genuineStereo);
  if(sampleCount%180==0&&hudPoseValid)printf("Grip marker hand=%d flags=%u eligible=%d left=%d right=%d format=%d selector=%d image=%d\n",hudPose.supportHand,hudPose.supportHeld,gripHintVisible,gripSphereDrawn[0],gripSphereDrawn[1],int(gripHintRenderer.lastFormat),weaponSelector.active,selectionVisible);
  if(sampleCount%180==0)printf("Interaction HUD: source=%d copied=%d visible=%d\n",worldHudPreview[2].state?1:0,worldHudUpdated[2]?1:0,worldHudVisible[2]?1:0);
  if(wristVisible||worldHudVisible[0]||worldHudVisible[1]||worldHudVisible[2]||worldHudVisible[4]||worldHudVisible[5]||worldHudVisible[7]||worldHudVisible[8]||selectionVisible)context->Flush();
  XrFrameEndInfo endFrame{XR_TYPE_FRAME_END_INFO};endFrame.displayTime=frame.predictedDisplayTime;
  endFrame.environmentBlendMode=XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
  if(genuineStereo&&frame.shouldRender)apcDisplay.frame(device,context,session,stage,xrCreateSwapchain,xrEnumerateSwapchainImages,xrAcquireSwapchainImage,xrWaitSwapchainImage,xrReleaseSwapchainImage);
  const XrCompositionLayerBaseHeader* layers[20]{};layers[0]=genuineStereo?reinterpret_cast<const XrCompositionLayerBaseHeader*>(&projection):submittedLayer;
  endFrame.layerCount=layers[0]?1:0;if(mainMenuScene&&mainMenuReady){layers[0]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&mainMenuLayers.quad[0]);endFrame.layerCount=1;if(genuineStereo)layers[endFrame.layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&projection);layers[endFrame.layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&mainMenuLayers.quad[1]);}else if(popupMenuScene&&genuineStereo&&mainMenuReady){layers[0]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&projection);if(!settingsPanel.active)layers[1]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&mainMenuLayers.quad[1]);endFrame.layerCount=settingsPanel.active?1:2;}if(genuineStereo&&worldMenuActive&&submittedLayer&&!settingsPanel.active)layers[endFrame.layerCount++]=submittedLayer;if(wristVisible&&!wristHidden&&endFrame.layerCount)layers[endFrame.layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&wristQuad);for(unsigned hud=0;hud<9;++hud)if((hud!=3)&&!(hud==5&&vehicleMap)&&worldHudVisible[hud]&&endFrame.layerCount)layers[endFrame.layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&worldHudQuad[hud]);if(selectionVisible&&endFrame.layerCount)layers[endFrame.layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&selectionQuad);for(unsigned i=0;i<4;++i)if(apcDisplay.visible[i]&&endFrame.layerCount)layers[endFrame.layerCount++]=reinterpret_cast<const XrCompositionLayerBaseHeader*>(&apcDisplay.quads[i]);if(calibrationConfirmed&&frame.shouldRender&&settingsPanel.render(context,stage,xrAcquireSwapchainImage,xrWaitSwapchainImage,xrReleaseSwapchainImage)&&endFrame.layerCount<20)layers[endFrame.layerCount++]=(const XrCompositionLayerBaseHeader*)&settingsPanel.quad;if(bootMessageVisible&&endFrame.layerCount<20)layers[endFrame.layerCount++]=(const XrCompositionLayerBaseHeader*)&bootText.quad;endFrame.layers=endFrame.layerCount?layers:nullptr;
  rc=xrEndFrame(session,&endFrame);
  if(XR_SUCCEEDED(rc)&&(wristVisible||wristHidden)&&wristPreview.state&&wristPreview.state->ready)InterlockedIncrement(&wristPreview.state->acknowledged);
  if(XR_SUCCEEDED(rc))for(unsigned hud=0;hud<9;++hud)if(hud!=3&&worldHudVisible[hud]&&worldHudPreview[hud].state&&worldHudPreview[hud].state->ready)InterlockedIncrement(&worldHudPreview[hud].state->acknowledged);
  if(XR_SUCCEEDED(rc)&&selectionVisible&&selectionPreview.state)InterlockedIncrement(&selectionPreview.state->acknowledged);
  if(XR_FAILED(rc)&&displayedFrames<2)printf("xrEndFrame result=%ld\n",(long)rc);
 }
 }
cleanup:
 apcDisplay.close(xrDestroySwapchain);
 if(hudPoseShared)UnmapViewOfFile(hudPoseShared);if(hudPoseMapping)CloseHandle(hudPoseMapping);
 mainMenuLayers.close(xrDestroySwapchain);
 for(unsigned hud=0;hud<9;++hud){if(hud!=3)worldHudPreview[hud].close();worldHudSource[hud].Reset();if(worldHudSwapchain[hud]&&xrDestroySwapchain)xrDestroySwapchain(worldHudSwapchain[hud]);}
 wristPreview.close();wristSource.Reset();if(wristSwapchain&&xrDestroySwapchain)xrDestroySwapchain(wristSwapchain);
 stereoGpu.close();
 for(auto& target:projectionTargets){if(target){target->Release();target=nullptr;}}
 bootText.close(xrDestroySwapchain);if(projectionSwapchain&&xrDestroySwapchain)xrDestroySwapchain(projectionSwapchain);
 selectionPreview.close();if(selectionSwapchain&&xrDestroySwapchain)xrDestroySwapchain(selectionSwapchain);
 menuPreview.close();gpuPreview.close();
 if(panelSource)panelSource->Release();
 if(eyeSwapchain&&xrDestroySwapchain)xrDestroySwapchain(eyeSwapchain);
 if(sessionRunning&&xrEndSession)xrEndSession(session);
 for(auto aimSpace:aimSpaces)if(aimSpace&&xrDestroySpace)xrDestroySpace(aimSpace);
 if(leftSpace&&xrDestroySpace)xrDestroySpace(leftSpace);
 if(rightSpace&&xrDestroySpace)xrDestroySpace(rightSpace);
 if(view&&xrDestroySpace)xrDestroySpace(view);
 if(stage&&xrDestroySpace)xrDestroySpace(stage);
 if(actions&&xrDestroyActionSet)xrDestroyActionSet(actions);
 trackedHands.close();
 if(settingsPanel.swapchain&&xrDestroySwapchain)xrDestroySwapchain(settingsPanel.swapchain);
 if(session&&xrDestroySession)xrDestroySession(session);
 if(context)context->Release();if(device)device->Release();if(adapter)adapter->Release();if(factory)factory->Release();
 if(instance&&xrDestroyInstance)xrDestroyInstance(instance);
 if(shm){InterlockedExchange(&shm->bridgePid,0);UnmapViewOfFile(shm);}
 if(mapHandle)CloseHandle(mapHandle);
 FreeLibrary(loader);
 return trackingStarted?0:6;
}












