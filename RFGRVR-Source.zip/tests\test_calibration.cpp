#include "../src/vr_calibration.h"
#include <cassert>
int main(){RFGRShared shared{};shared.magic=RFGR_MAGIC;shared.version=RFGR_PROTOCOL;shared.gamePid=1;shared.calibrationReady=shared.calibrationFloorValid=1;shared.hmd.validFlags=3;shared.calibratedHeadHeight=1.6f;shared.calibratedArmSpan=1.55f;assert(RFGRVR_CanResumeCalibration(&shared,true));assert(!RFGRVR_CanResumeCalibration(&shared,false));shared.calibrationFloorValid=0;assert(!RFGRVR_CanResumeCalibration(&shared,true));shared.calibrationFloorValid=1;shared.calibratedHeadHeight=NAN;assert(!RFGRVR_CanResumeCalibration(&shared,true));RFGRPose h{},l{},r{};h.validFlags=l.validFlags=r.validFlags=3;l.active=r.active=1;h.position[1]=1.7f;l.position[0]=-.7f;r.position[0]=.7f;l.position[1]=r.position[1]=1.45f;float height=0,span=0;
 assert(RFGRVR_TPose(h,l,r,true,height,span));assert(fabsf(height-1.7f)<.001f&&fabsf(span-1.4f)<.001f);
 l.position[1]=.5f;assert(!RFGRVR_TPose(h,l,r,true,height,span));l.position[1]=1.45f;
 l.active=0;assert(!RFGRVR_TPose(h,l,r,true,height,span));l.active=1;
 h.position[1]=3;assert(!RFGRVR_TPose(h,l,r,true,height,span));h.position[1]=1.7f;
 assert(RFGRVR_TPose(h,l,r,false,height,span)&&height==1.65f);
 RFGRVRCalibrationSamples samples;for(int i=0;i<90;++i)assert(samples.add(1.7f+(i%2?.005f:-.005f),1.6f));
 assert(samples.average(height,span)&&fabsf(height-1.7f)<.00001f&&fabsf(span-1.6f)<.00001f);
 assert(!samples.add(1.5f,1.6f)&&samples.count==0);assert(samples.add(1.7f,1.6f));samples.reset();assert(!samples.average(height,span));
}
