#pragma once
#include "vr_arm_math.h"
namespace vrgrip {
using namespace vrarm;
inline Pose relativePose(const Pose& frame,const Pose& pose){return {relative(frame.b,pose.b),local(frame.b,sub(pose.p,frame.p))};}
inline Pose worldPose(const Pose& frame,const Pose& pose){return {compose(frame.b,pose.b),add(frame.p,world(frame.b,pose.p))};}
inline Pose weaponAtGrip(const Pose& hand,const Pose& grip){M inverse{{grip.b.r.x,grip.b.u.x,grip.b.f.x},{grip.b.r.y,grip.b.u.y,grip.b.f.y},{grip.b.r.z,grip.b.u.z,grip.b.f.z}};M basis=compose(hand.b,inverse);return {basis,sub(hand.p,world(basis,grip.p))};}
inline Pose wristAtGrip(const Pose& grip,M wristBasis,V palmOffset){M b=compose(grip.b,wristBasis);return {b,sub(grip.p,world(b,palmOffset))};}
struct Placement {uintptr_t weapon=0;unsigned handle=~0u;Pose fixed{};bool active=false,released=false;
 void cancel(){active=false;released=false;weapon=0;handle=~0u;}
 void begin(uintptr_t w,unsigned h,const Pose& pose){weapon=w;handle=h;fixed=pose;active=true;released=false;}
 bool update(uintptr_t w,unsigned h,float grip){if(!active)return false;if(w!=weapon||h!=handle||!std::isfinite(grip)){cancel();return false;}if(grip<.35f)released=true;return released&&grip>.65f;}
};
}
