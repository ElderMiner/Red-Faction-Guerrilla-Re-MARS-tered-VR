# DLC support and finalized placements

The temporary setup period is complete. Numpad hand, magazine, ghost, eye and
HUD placement controls, Page Up/Down spacing edits, and automatic locker
testing grants are disabled. Ordinary controller input and VR Settings remain.

The approved placements are retained. Fresh installations receive the approved
DLC weapon grips, reload insertion/hand poses and stack spacing, on-foot DLC
HUD layout, and vehicle heights as seed-only defaults. Updates preserve existing
settings. Personal head-pivot and arm recordings are not distributed.

The Missilepod uses a downward stack of rockets representing empty capacity,
limited by available reserve ammunition. It can be fetched whenever room and
reserve ammunition are available. Insertion fills those slots immediately,
without a reload-button press. Other launchers keep single-rocket insertion.
The Stomper machine-gun mount and Raider harpoon retain their rear standing
platform offsets; ring-seat turrets remain centered.

Locker/shop availability now follows native progression. Unlocks already
written into a testing save are preserved; no grants or save relocking run.

Configuration files:

| File | Purpose |
| --- | --- |
| RFGRVR-dlc-weapon-alignment.ini | DLC weapon hand poses |
| RFGRVR-reload-positions.ini | Per-weapon reload ghosts, magazine grips and stack spacing |
| RFGRVR-dlc-hud-layout.ini | On-foot DLC HUD placement |
| RFGRVR-hud-layout.ini | Main-campaign on-foot HUD placement |
| RFGRVR-vehicle-hud-layout.ini | Separate vehicle HUD placement |
| RFGRVR-vehicle-heights.ini | Approved seat heights |

Main-menu UI has a menu-only cubic reconstruction path up to 5120x2880,
bounded by runtime image limits, and a 25-PPD menu eye target. Gameplay
resolution and the accepted in-game menu path are unchanged. Headset clarity
and live cost remain to be verified after installation.
