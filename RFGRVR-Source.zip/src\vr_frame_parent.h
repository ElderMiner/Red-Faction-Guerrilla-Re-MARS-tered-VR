#pragma once
// The two eyes share locomotion/seat state as well as camera transforms.
struct RFGRVRFrameParent {unsigned state=0;bool attached=false;void capture(unsigned s,bool a){state=s;attached=a;}void restore(unsigned& s,bool& a)const{s=state;a=attached;}};
