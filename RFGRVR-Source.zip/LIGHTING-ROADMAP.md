# Modern lighting: build and integration ledger

The public release remains 0.10.105. The installed private build is 0.13.1.
The following tables include historical backend checkpoints; the dated integration
sections below take precedence. Current source is the combined 0.13.3 candidate,
not installed or headset-verified. No complete renderer replacement is claimed.

## Current components

| System | Built and tested | Native integration remaining |
| --- | --- | --- |
| Stereo stability | Shared light selection/radiance; explicit main-light seed; per-eye diagnostics | Install/verify the pending correction and investigate any remaining visible flicker |
| Materials | GGX, explicit metal/nonmetal masks, glass; 38 captured generated identities, including three terrain-overlay modes | Audit other scenes, DLC and uncaptured material families; preserve accepted material response |
| Sky | GPU world-space Rayleigh/Mie single-scattering HDR lookup with independent sun/moon inputs | Bind verified native celestial directions and coordinate sky rendering without changing camera/perspective ownership; multiple scattering is not implemented |
| Local shadows | GPU spot and six-face point atlas; depth-only caster callback, face budgets, cache reuse and geometry revisions | Connect the native static/skinned/alpha-tested caster path and world-space visibility; expose these maps to actual material and volume lighting |
| Directional shadows | Native cascade capture plus offline stereo-union, PSSM, texel-snapped custom fitting | Native caster/culling adapter, transition filtering and coordinated material sampling |
| Volumetrics | Native-world connection, depth-limited scattering and directional shadows; local screen contact occlusion | Consume proper local maps; tune density/cascade transitions and edge reconstruction; measure actual game cost |
| Indirect light | Owned six-face HDR/world-distance capture backend; GPU SH projection; bounded grid, visibility weighting and destruction invalidation | Native auxiliary-camera producer, material world-normal/position adapters, multi-bounce feedback and thin-wall tuning |
| Reflections | GPU GGX cubemap mip chain and split-sum BRDF lookup, HDR/energy tests | Obtain native/owned world-space captures, coordinate refresh/invalidation, and bind to compatible material interfaces |
| Exposure | GPU scene histogram, one-update-per-stereo-pair adaptation, highlight trimming, smooth changes and native deferred-stream support; bounded diagnostic bridge is connected in source | Verify diagnostic source/history and replace native metering; scene output still uses existing exposure |
| Light-producing effects | Native point/spot collection is connected | Audit muzzle/fire/explosion/projectile light lifetimes and emission, avoiding duplicate invented lights |
| Performance | Low/default/high budgets; cache reuse; bounded asynchronous GPU readbacks; frame coordinator | Native visibility/geometry integration, actual GPU timings, target-headset presets and worst-case scene testing |
| Release/compatibility | Existing Standard-mode and installer protections remain | Full campaign/DLC/vehicle/scope/menu matrix, diagnostic removal, fallback and release validation |

## Coordinator contract

`modern_lighting_graph.h` runs once per world frame on the caller's explicit
immediate stream. It coordinates the local-shadow, atmosphere, reflection,
probe and histogram backends. It will not search scene registries, infer native
mesh layouts, treat UI images as scene radiance, or wait for a GPU readback.
Probe results from an invalidated geometry revision are discarded. New scenes
discard prior probes, metering history and scene capture identities.

Native adapters must provide genuine linear HDR captures, world-distance cubes,
verified caster submissions, and explicit scene/geometry revisions. Until those
adapters are finished, the new backends remain offline rather than receiving
fabricated inputs. No whole-engine replacement or final visual quality is claimed.

## Build discipline

Run `BUILD-SHADERS.ps1` after editing authored HLSL; the test/release scripts also
run it automatically. It synchronizes embedded shader strings, including the
volume implementation. Exact native identities are interface metadata only;
private native `.cso`/disassembly/captures must never enter source or installers.

Tests include actual GPU rendering/convolution/projection/metering and an
end-to-end coordinator test. Synthetic scenes establish backend behavior;
they do not replace eventual native scene, performance and headset verification.

## 0.12.0 development checkpoint

This is a source/backend milestone, not an installed or public visual release.
The new material identities and pending stereo correction are in the development
build; sky/probe/reflection/custom-shadow backends are not activated in gameplay.
The coordinator now accepts completed owned cube captures only when their world
position and geometry revision match the requested probe. Captures reject wrong
faces, wrong field of view, wrong origin, wrong formats, incomplete generations
and duplicate faces. GPU work must execute in producer-stream order before a
consumer on another stream uses a published capture.

Native HDR metering is connected as opt-in, bounded diagnostics (120 pairs),
with own histogram/readback resources and actual pair timing. The engine's
secondary deferred stream records both the meter and its result copy/query;
CPU readback happens later on the primary immediate context without waiting.
It does not apply its measured exposure. `modern-native-meter-status.json`
reports completion/failures, keeping this distinction inspectable.

The shadow integration investigation now verifies native rl_camera, rl_light,
rl_batched_pass and the separate rl_terrain_renderer identities, with the
executable checks in VERIFY-ENGINE-LIGHTING.py. This resolves the interface
identity gap, not the remaining per-light visibility/lifetime contract. The
read-only live sample did not alter the installed shaders or game memory.

## Native world-capture adapter candidate

The source now schedules one 128-square native auxiliary world view every eight
stereo pairs, only when `RFGRVR-modern-world-capture.enable` is present at
startup. It borrows the existing auxiliary-camera target isolation, restores
native camera/render caches, and bypasses headset geometry replay. Scope and
APC feeds take priority; menus do not trigger these captures. The initial
adapter is deliberately bounded to one six-face diagnostic generation, with
120 attempts maximum. It is not yet the continuous scene-update policy.

Pre-HDR copies resolve the actual reduced native radiance/depth views, validate
the six face matrices, and temporarily suspend target redirection for owned
capture draws. A query is recorded in the final producer stream, submission
is marked only after the enclosing native renderer returns, and completion
is polled without waiting. The completed cube feeds the GPU reflection filter
and one irradiance probe. GPU tests check this publication boundary.

Verified TYPE4 reflective materials can now consume the filtered HDR cube and
BRDF lookup through scoped t16/t17 and b13 bindings. Immutable control buffers
are cached; native texture/sampler slots are retained, and previous bindings
are restored at world-view exit. A GPU material test verifies an actual image
response and restoration. Other material families still need world-normal
and probe/shadow adapters. This path has not been installed or native-verified.
`modern-native-world-capture.json` reports dimensions, capture phase, rejected
faces, GPU completion, reflection readiness and completed probe readbacks.

0.12.1 candidate corrects native floating-origin conversion in capture-camera
placement, cube depth math and local-light selection/scattering. 0.12.0 native
logs show zero accepted faces; no native reflection/probe activation was claimed.
Detailed validation stage is now reported alongside capture dimensions. Shader
appearance remains dependent on successful native capture and subsequent tests.

## 0.13.0 private integration candidate (not installed or visually verified)

Material diffuse lighting now consumes the GPU SH probe grid through a scoped
world-space adapter. It reconstructs geometric/tangent normals, accounts for
native floating origins, tests distance moments to reduce light leaking, and
retains native ambient where there is no valid capture. A real GPU test compares
interpolation against CPU queries and verifies deferred binding restoration.

The native HDR histogram now feeds a shared, gradually introduced filmic
exposure value for both eyes. Night has a separate upper adaptation bound so
metering cannot simply brighten darkness into daytime. Main menus and popup
surfaces are excluded from metering. Exposure-only frames do not require probes.

Two verified base-sky pixel interfaces now consume the owned atmospheric LUT.
Native sky geometry, cloud artwork, stars and the corrected moon are retained;
there is no camera override or screen-sized sky overlay. World-ray reconstruction
uses each eye's actual projection. The LUT is refreshed at most once every 120
pairs from the authoritative scene directional source. Native gradient shading
remains the fallback. This is atmospheric integration, not a replacement cloud
or weather simulation; the current scattering parameters still need Mars tuning.

World captures can refresh after 600 eligible pairs, at one face every eight
pairs, once the preceding generation has been consumed. APC and rifle scope
views take priority. The opt-in gate and failure circuit breaker remain pending
native validation of the installed origin correction. This is a moving local
probe/reflection sample, not yet a fully populated streaming irradiance volume.

Remaining substantial work: local-light native caster/visibility integration,
custom directional caster rendering, continuous multi-probe coverage and
invalidation from destruction, cloud/sky/material response matching, reflection
coverage for additional material families, transparent/particle integration,
quality presets and measured frame budgets. Backend availability must not be
reported as complete native activation or visually verified modern lighting.

## 0.13.0 native verification and 0.13.1 candidate

The 45128 native run completed 36 auxiliary faces with zero validation
rejections at the first inspection, six reflection/probe updates, nonzero SH
irradiance and confidence 1 at the probe. The meter completed 1794 readbacks
with two pending and zero failures. Subsequent samples reached 25 probe updates.
These counters verify execution and scene data, not overall visual quality.
The right-eye image was inspected: legacy cloud/fog colour still dominated the
sky, motivating the following separate candidate corrections.

0.13.1 source retains overlapping irradiance cells on integer world-grid moves,
prioritizes nearest missing nodes and then old data, and places asynchronous
readbacks by world position rather than outdated array indices. Nodes outside
the moved grid are rejected. The grid remains a small local approximation;
there is no claim of full-map GI or native destruction-event integration.

The atmospheric material now uses the correct inverse-matrix convention and
handles zenith/nadir azimuth safely. An actual varying-colour GPU lookup test
checks camera translation invariance and rotation response. Native distance fog
is excluded only when the integrated atmosphere is available, avoiding a second
fog operation that overwrites the sky. Native gradient/fog fallback is retained.

Two exact cloud interfaces now preserve authored density, textures, animation,
opacity and premultiplied blending while taking illumination from the atmosphere.
GPU tests check cloud pixels, night response, opacity and zero-coverage output.
The runtime uses an authored dusty scattering blend rather than Earth-blue
coefficients; this is art direction, not a claim of measured Martian optics.

Metering uses one cached view of the current non-swapchain HDR texture and runs
once per eye even when no volume light is selected. A missing scattering light
must not drop one eye from the exposure pair. No menu or UI source is metered.

A pre-existing/intermittent generated-overlay GPU check has reproduced a failure
at mode 20, local variant, layer 1. Source textures were copied back and matched
the CPU changes, while output did not change in that failed sample. Standalone
and repeated runs can pass; this is not treated as resolved by retries. Diagnostic
assertions remain and packaging/install claims must report the actual suite result.

## 0.13.2 deferred-world binding correction

The fresh 6424 capture records atmosphere t20 on 4172 immediate draws and on
zero of 2717 deferred draws. A read-only live inspection found equivalent camera
matrices in both native renderers, but secondary Renderer +0x440 did not resolve
to a command context outside its actual pass. Prebinding both renderers before
calling the scene renderer therefore could not reach its deferred draws.

Replacement shader objects now carry an authored identity tag. A world-view
scope supplies its verified eye frame/resources to the actual deferred context
at its first replacement draw. Context state resets and explicit overwrites of
the reserved bindings invalidate that context's stamp. Reapplication does not
query GPU state per draw or create another constant buffer. Untagged native
shaders do not trigger lighting injection; scopes restore prior bindings.

A real GPU regression goes through production context hooks, repeatedly clears
state, records and executes lists, explicitly erases b13/t20 and verifies the
resulting sky pixels. It also verifies ordinary shaders remain untouched.
The full 66-test suite passed, followed by the added targeted ownership checks.
Native activation and the user's flicker result still need verification.

## Local terrain-height authoring experiment

MAKE-TERRAIN-HEIGHTS.py is an optional authoring utility requiring numpy and
Pillow. Invoke with the owned game directory and a LOCAL research-output path.
It reads verified version-10 BC1 normals, uses the native normal decoding, and
integrates slopes using periodic Fourier least squares. A synthetic periodic
surface test reproduces height and gradients to numerical precision.

60 candidate maps were generated locally from the terrain precache, at up to
1024 square with 16-bit previews and float16 payloads. That archive contains
props as well as terrain. The native legacy terrain table references 27 unique
normal names; only 15 resolve in the examined precaches. A manifest preserves
source hashes, dimensions and integration residuals. No displacement is enabled
by this utility, physical height scale is unknown, and generated maps are derived
game data that must not be included in public source/setup archives. Runtime
material assignment, seam/LOD handling, stereo relief, shadow and collision
policy remain necessary before enabling actual terrain displacement.

## 0.13.3 offline integration batch

Includes the deferred-world binding correction from 0.13.2. Terrain TYPE2 and
TYPE5 replacements and the four older terrain identities additionally consume exact-content-matched local height maps.
The local generator resolves the native terrain table against base/DLC precaches:
15 of 27 referenced names resolve; missing names use native shading. The earlier
60-map catalogue included props and is not the runtime bundle. Derived textures
stay private and are excluded from all source/setup archives.

Relief is deliberately shallow (2 cm), fades between 8 and 20 metres, uses explicit
texture gradients and 8�16 bounded steps, and samples filtered R16 mip chains.
The resident allocation budget is 64 MB including mip levels. Matching occurs at
texture creation, not every draw. Texture/SRV lifetime owns the height attachment
without retaining the parent texture. Deferred context resets and reserved-slot
writes trigger rebinding; ordinary/native non-terrain shaders remain untouched.

GPU checks cover neutral-height UVs, opposite height offsets, per-eye parallax,
floating-origin invariance, distance fallback, preserved depth, production context
binding/restoration and command-list resource retirement. This is parallax relief,
not geometric displacement: silhouettes, terrain collision and shadow geometry
remain native. Physical relief amplitude is an authored conservative approximation.

Compatible reflective surfaces now use finite local box projection around the
verified cube-capture origin. GPU checks verify intersection directions, origin
rebasing and safe fallback outside the box. The 12-metre proxy bounds are not
measured room geometry, and this is not ray tracing or complete reflection coverage.

Remaining native dependencies before further integration: actual per-light caster
visibility/batch lifetimes (static, skinned and alpha-tested), geometry/destruction
invalidation ownership, uncaptured material interfaces, and terrain LOD/shadow
contracts for true displacement. These cannot be established by synthetic GPU
fixtures. The combined deferred sky fix, local relief and reflections also require
native activation, stereo image and timing captures before visual/performance claims.

## 0.13.3 live findings / 0.13.4 candidate

PID 46776 confirms replacement atmosphere bindings on both deferred eye streams,
217 successful shader replacements, five matched terrain height attachments
(13,981,010 bytes including mips), and all 27 irradiance cells ready around the
sampled player position. The inspected right-eye image remains flat/tinted; native
activation does not establish the requested modern appearance.

The zero-confidence telemetry sample was at the grid's positive boundary,
which both CPU and GPU queries incorrectly excluded. The candidate includes
that last node and adds CPU/GPU endpoint checks; this was not absent GI coverage
around the player. Lighting art direction and native fog integration remain open.

The live counts also show unequal skipped volumetric passes between eyes. The
zero-usable-light branch previously bypassed the entire medium, not only light
scattering, removing extinction for that frame. The candidate allows a zero-light
medium and still composites its transmittance once per eye; unavailable shadowed
sources are omitted rather than replaced by invented unshadowed rays. GPU checks
verify identical extinction for lit, shadowed and zero-source cases. This fixes a
concrete brightness-pop mechanism; it is not yet a confirmed cure for the user's
remaining sky flicker. No visibility-caster connection or full replacement claimed.

## 0.13.5 combined optical/view-priority candidate

0.13.4 live PID 32308 rendered its atmospheric medium in both eyes on every
recorded attempt, but the user still reports sky flicker. A read-only comparison
found the native camera temporarily replaced by an orthographic shadow projection
with the SAME eye position. During final mask-7 world rendering, the inverse
matrices agree within 0.000061; during shadow preparation they differ by ~2125.
The candidate verifies the expected eye projection before metering/compositing;
a GPU runtime regression reproduces the same-eye/wrong-projection condition.
This is a measured pass-identity correction, not a verified final flicker cure.

The local colour-map authoring tool now derives reflectivity from linearized
brightness and fixed spatial colour variance. It resolves 189 BC1/BC3 colour maps
in base/DLC precaches; other inputs retain native shading. These are approximate
artistic material maps, not measured BRDFs, baked irradiance or physical metalness.
They are generated once locally, content-matched on texture creation, mip-filtered
as RG8, and share a 64 MB residency budget with terrain heights. No per-frame colour
analysis, visible particles, game-derived textures or output bundles enter releases.
The default map size is 256, independent of albedo resolution. Authoring/source is
redistributable; derived output remains local.

Verified terrain, generated, legacy surface and glass interfaces bind matching
colour maps in scoped t25�28 slots. Existing material properties bound the inferred
reflectivity and roughness. Missing maps preserve the established response. Both
immediate and production deferred checks verify ownership, overwrite/reset handling
and restoration; colour and opacity remain separate from reflectivity metadata.

All supported material families share Fresnel and finite-range light helpers.
Glass uses exact dielectric Fresnel, the same gloss conversion as opaque materials,
and angle/thickness-dependent transmission that preserves authored normal opacity.
Cloud layers account for increased optical path at oblique viewing angles. Bright
background sources remain HDR values multiplied by transmission; source brightness
does not erase solid geometry or make an opaque layer transparent. True refracted
scene rays/background capture are NOT connected by these changes.

The CPU secondary-transport model conserves incident energy and describes at most
three reflection/diffuse/transmission lobes using material properties and surface
normals. It is a tested backend, NOT a connected scene-light/photon emitter. Verified
native surface-hit/occlusion inputs remain necessary before enabling secondary lights.

Visible work is prioritized conservatively: local light influence spheres intersect
a guard-banded first-eye volume frozen for both eyes; new probe captures prioritize
visible missing nodes, then populate other missing nodes and refresh oldest caches.
Off-screen geometry/caches are retained for shadows/reflections. This is not hardware
ray tracing, a full scene path tracer, or an established performance gain. Synthetic
and native timing/image validation remain distinct.

Final 0.13.5 checks additionally preserve native source identity through selection
and attach source/surface provenance to the bounded transport lobes. IDs are
scoped to their native frame/lifetime; object pointers are not retained or treated
as permanent scene identities. These records do not reconstruct unknown geometry
from colour/brightness and do not emit actual scene photons. The native visibility
and secondary-light integration remains unfinished.

The authoring pass was expanded using the already verified version-10 BC3 mapping
from the existing local asset reader. It generates 189 local maps from base/DLC
precache inputs; the default 256-square bundle is ~24 MB on disk. The shared GPU
budget remains 64 MB including mips, with native fallback on cache exhaustion.
Private diagnostics now report projection-rejected non-world passes, matched
material maps and cache bytes, and sample GI at the actual eye rather than the
probe-grid boundary. A real HDR composite test checks that 100x brighter background
radiance stays 100x brighter through identical fog, without changing opacity.

## Source-field multi-bounce transport backend (not connected to gameplay)

`modern_wave_transport.h` implements bounded spherical influence with directional
reflection/diffuse lobes. Surface patches carry position, area, normal, identity
and material properties. Fields retain source identity across bounces. Reverse
relevance starts from visible patches and keeps potentially contributing offscreen
patches. Segment queries must explicitly report solid blocking or RGB throughput;
unknown geometry blocks. Range attenuation, colour transfer and Fresnel responses
apply without spawning visible particles. Power is normalized before occlusion,
so blocking cannot redistribute light into other receivers. Weak fields expire;
bounce, field and query limits terminate worst-case feedback. Budget exhaustion is
reported, not presented as a converged solution.

This is an approximate finite-patch CPU transport backend, NOT a Maxwell wave
solver or a complete ray tracer. Transparent-layer intersection and throughput
belong to the segment adapter; transmission is not emitted again at patch nodes.
Specular paths narrower than patch sampling may be missed. The verified gameplay
Havok sweep supplies hit position/normal but does not yet supply a verified optical
material/layer mapping. It is unsafe to call those simulation queries from GPU
callbacks. Native patch extraction, transparent-layer mapping, revision/invalidation,
GPU field evaluation and performance measurements remain required connections.
The backend is deliberately not enabled in the live renderer. Do not claim it
changes the current game's lighting or replaces its existing probe system.

`test_modern_wave_transport` covers solid/unknown obstruction, coloured transmission,
finite range, repeated reflection from an offscreen patch to a visible patch,
material tint, aggregate power bounds and work exhaustion.

## 0.13.6 private native-geometry connection candidate

The owned Scene adapter now builds a median-split triangle BVH, intersects actual
segments, blocks solid geometry, and accumulates spectral Beer/Fresnel attenuation
through thin transparent sheets. Endpoint exclusion is local, not object-wide;
shared-sheet seams are deduplicated. Scene publication is transactional. Solves
cache segment throughput only within a snapshot, retain source IDs in secondary
fields, and reject stale-revision shading. Eye-directed receiver evaluation is
available as a CPU reference. These tests use explicit geometry, not a visibility
callback that pretends every path is clear. Refraction through closed volumes,
GPU field shading and native scene population remain unfinished.

A fresh installed-0.13.5 capture contains 13960 events with both immediate/deferred
world draws and several vertex strides. Buffer stride does not prove position,
skinning, object transform, material identity or world units. The private candidate
adds a one-pair bounded diagnostic to the existing pixel probe: up to 16 tagged
world vertex-shader families, first-eye indexed draws only, maximum 32 MB copied
buffers (4 MB per buffer). It captures input-layout declarations, vertex bytecode,
vertex/index data and VS constant buffers at the actual draw sequence. Deferred
copies retain draw-time data even if the source changes later. Normal rendering
never initiates these copies. Tag blobs live with their COM objects; no registry
search or permanent native pointer ownership is introduced. Exact layout/transform
reconstruction must be verified from these captures before publishing geometry to
the transport solver. These proprietary diagnostics remain private and are never
included in source/installer releases. This candidate is not a completed modern
lighting replacement and does not activate multi-bounce fields in gameplay.

## 0.13.7 private rendering recovery and comparison

The live 0.13.6 garage eye image contains a flat-colour structure. Pixel sample 6
changes in the tagged TYPE=3 directional material draw (mode 507, native identity
3d58a74365b187fb8854f6677d03429c). The candidate restores native shaders for the
TYPE=3 blended pair while investigating its replacement. This preserves textures
through an exact native fallback, not a completed corrected modern material model.

Native sky/cloud shaders are restored. Unscoped global atmospheric composition is
disabled: no verified authored medium is available, so normal gameplay must not
receive the test's fixed .004-density fog. Explicit-medium GPU tests continue to
exercise scattering; a new default-path test checks unchanged pixels. The native
sky geometry/camera/moon fixes are untouched. The returning headset flicker has
not been proven resolved; the unconfirmed atmosphere paths are withdrawn.

Numpad 0 toggles experimental/baseline lighting on a foreground rising edge in the
game scene pair. The baseline uses exact original pixel shaders retained as COM
private interfaces by their replacements; originals never retain replacements.
Shader creation continues to prepare both choices while bypassed. Native scene,
probe and atmospheric scheduling follows enabled(), whereas resource creation
follows available(). Existing approved night/bloom/glow and camera paths remain.
Deferred contexts reselect a retained shader when the mode changes even without
a repeated PSSetShader. ClearState and non-restoring command-list finish release
the retained selection. Immediate shader-bind hooks select the native counterpart
while bypassed. No withdrawn placement/editor tools are enabled. The switch is
session-local and does not rewrite user profiles. Test coverage verifies foreground
edge/release behavior, exact shader identity, deferred mode changes and state reset.

## 0.13.8 private hybrid direction (supersedes the recovery candidate)

The user selected the hybrid route: native materials, lights, shadows, AO, sky,
exposure and the previously accepted mod fixes remain authoritative. Production
shader replacement is now restricted to the three exact verified final HDR shader
identities. Non-HDR source shaders pass through unchanged. The experimental graph,
probe/auxiliary captures, per-eye atmospheric medium, material/height attachments
and its night-environment override are disabled by transportEnabled(). These
backends remain in source/tests for research; they are not running gameplay work.
Numpad 0 remains a session-only switch to the exact original HDR shaders.

The private tone-curve comparison uses Hable-style coefficients and white/exposure
parameters inspected in the user-provided Sildur pack, re-expressed for the game's
verified linear HDR inputs. It does NOT copy Minecraft gamma decoding/encoding,
shadow buffers, TAA, screen-space reflections, or shader binding assumptions. The
existing native blurred-bloom buffer feeds a hue-preserving bounded contribution;
no new full-screen blur passes or uniform haze are added. Native particle handling,
three pass-specific alpha contracts, shared native adaptation and eye separation
remain tested. Probe-derived exposure overrides are removed. Expected visible
changes: a different highlight/contrast rolloff and bounded glow, with native
surface textures restored. This is a first hybrid candidate, not Sildur fully ported,
not a new indirect-light engine, and no performance benefit is measured yet.

This experiment is PRIVATE. Do not publish its modified sources/installers to the
public repository/release. The provided pack explicitly prohibits modification and
redistribution without written permission. The public stable release is unchanged.
Further effects such as depth-localized shafts require verified scene inputs;
blanket fog, VR motion blur and Minecraft temporal jitter are not substitutes.
The final production-policy regression checks every registered material/terrain/glass/sky identity passes through native creation exactly once, while only HDR identities substitute and retain their exact baseline shader. The 73-test full run and this added regression pass (74 tests total); both native/companion builds and Standard-mode checks pass. Headset appearance and performance remain unverified.

## 0.13.9 hybrid nighttime grade correction

The hybrid restored the approved native ambient/main-light preset but bridge.cpp
still excluded the established nighttime eye grade whenever modernlight::enabled()
was true. Thus the preset's 200% night ambient was active without its matching
20% night scene exposure and colour balance. The companion now gates that grade
by nativeNightGrading(), tied to the actual transport mode rather than the HDR
finishing switch. Hybrid and its Numpad 0 baseline comparison both retain the
same approved night-only grade. Existing native clock validation, smooth dawn/dusk,
day identity, menu/video bypass and user profiles remain unchanged. Regression
coverage checks hybrid/bypass grade policy and existing real-GPU two-eye exposure,
highlight preservation, day and UI bypass. No new brightness slider or lower
all-day exposure is introduced. This private correction needs headset verification.

## 0.13.10 darker night and native shaft handoff

The requested night adjustment lowers approved scene exposure from 20% to 18% and
ambient fill from 200% to 175%. The main-light setting and colour balance stay at
the existing preset; native day/clock transitions and menu bypass remain unchanged.
Reducing ambient fill deepens unlit areas rather than lowering lamp intensity.

The earlier glare suppression explicitly disabled the native sun/shaft generation
flag for the entire frame and nulled both sun input +978 and shaft input +aac.
The candidate leaves generation at the engine's own setting and removes only the
sun-glow composite input. The shaft texture stays available through both native
composite calls. Dedicated sun-sprite and lens-ghost suppression remains active.
The native scene/camera/depth and unmodified shaft shaders retain ownership; no
blanket fog or unoccluded radial fake is introduced. Scoped-slot tests check the
shaft survives during both composites and that the sun slot restores afterward.
Private counters record non-null native shaft inputs; they do not prove rendered
pixels or claim moon/headlight volumetrics. Final HMD ray visibility still requires
an in-game check. No public release or saved profile files are changed.

## 0.13.11 night-only atmospheric haze (includes 0.13.10)

The user additionally requested more atmosphere at night. A separate analytic
haze mode reuses the verified native HDR/depth reconstruction and state-preserving
quarter-resolution composite. It starts beyond 18 world metres, clamps traversal
to 150 metres and haze amount to 22%, uses restrained dark-blue HDR radiance,
and fades with the existing night clock/plan. No lights, ray-marching loop, shadow
copies, probe capture or light grid are needed for this mode. Near interiors remain
clear according to world depth; this is not an indoor/outdoor volume classifier.
Infinite-depth sky pixels with an unreconstructable position stay unchanged.

The hybrid establishes expected per-eye camera state and connects the existing
pre-HDR callback without activating the old transport/shadow hooks. Baseline
bypass, daytime/unknown clock and absent night-plan paths are no-ops. Native/UI
shader paths and day grading remain unchanged. The GPU regression verifies clear
near geometry, bounded far haze, identical repeated-eye samples and twilight/day
attenuation; existing runtime checks cover projection identity, floating origin,
deferred state restoration and per-eye gating. Actual HMD appearance and the
cost of this analytic mode still need measurement. This is atmospheric depth fog,
not a new multi-scattering volumetric lighting engine. Native god-ray generation
and its separate final composite input remain restored as described for 0.13.10.
