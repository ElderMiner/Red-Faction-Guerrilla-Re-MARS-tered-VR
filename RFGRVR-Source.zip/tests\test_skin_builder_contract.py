import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tools'))
import pefile,capstone
root=Path(__file__).resolve().parents[3]
pe=pefile.PE(str(root/'rfg.exe'));data=pe.get_memory_mapped_image();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
instructions=list(cs.disasm(data[0x88c940:0x88ce6e],0x88c940))
assert instructions[-1].address==0x88ce6b and instructions[-1].mnemonic=='ret' and int(instructions[-1].op_str,0)==8
assert not any(i.mnemonic.startswith('call') for i in instructions)
for i in instructions:
 for operand in i.operands:
  if operand.type==capstone.x86.X86_OP_MEM and operand.access&capstone.CS_AC_WRITE:
   assert operand.mem.base!=capstone.x86.X86_REG_ECX,(hex(i.address),i.mnemonic,i.op_str)
   assert operand.mem.base or operand.mem.index,(hex(i.address),i.mnemonic,i.op_str)
print('CPU skin builder contract verified: no calls, global writes, or instance-header writes; RET8.')

setter=list(cs.disasm(data[0x88aff0:0x88b260],0x88aff0))
assert setter[-1].address==0x88b25d and setter[-1].mnemonic=='ret' and int(setter[-1].op_str,0)==12
assert not any(i.mnemonic.startswith('call') for i in setter)
# Both public engine setters route to the same competing model+skin writer.
import struct
for call in (0x8910d0,0x8911b0):
 assert data[call]==0xe8 and call+5+struct.unpack_from('<i',data,call+1)[0]==0x88aff0
# The engine itself invokes the full builder with two null arguments.
assert data[0x8911f1:0x8911f5]==bytes.fromhex('6a006a00')
assert data[0x8911f5]==0xe8 and 0x8911fa+struct.unpack_from('<i',data,0x8911f6)[0]==0x88c940
print('Individual bone setter RET12/no-call contract and native null-argument rebuild wrapper verified.')


copy=list(cs.disasm(data[0xd1380:0xd13fa],0xd1380))
assert copy[-1].address==0xd13f7 and copy[-1].mnemonic=='ret' and int(copy[-1].op_str,0)==8
assert not any(i.mnemonic.startswith('call') for i in copy)
assert any('0x124' in i.op_str for i in copy) and any('0x128' in i.op_str for i in copy)
print('Renderable palette copy contract verified: independent +124 cache, +128 count, RET8/no calls.')
