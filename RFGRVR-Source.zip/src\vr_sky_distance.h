#pragma once
#include <cmath>
inline bool RFGRVR_ExpandSky(float pose[12],float factor){
 if(!pose||!std::isfinite(factor)||factor<1||factor>64)return false;
 for(int i=0;i<12;++i)if(!std::isfinite(pose[i]))return false;
 for(int i=0;i<3;++i){float length=0;for(int j=0;j<3;++j)length+=pose[i*3+j]*pose[i*3+j];if(fabsf(length-1)>.01f)return false;}
 for(int i=0;i<3;++i)for(int k=i+1;k<3;++k){float dot=0;for(int j=0;j<3;++j)dot+=pose[i*3+j]*pose[k*3+j];if(fabsf(dot)>.01f)return false;}
 for(int i=0;i<9;++i)pose[i]*=factor;return true;
}
