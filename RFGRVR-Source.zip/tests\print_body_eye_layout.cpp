#define main testMainUnused
#include "test_native_arms.cpp"
#undef main
#include <cstddef>
int main(){printf("command size=%zu root=%zu pose=%zu eye=%zu nativeEye=%zu nativeEyeValid=%zu changed=%zu rootRelative=%zu count=%zu tick=%zu\n",sizeof(ArmCommand),offsetof(ArmCommand,root),offsetof(ArmCommand,pose),offsetof(ArmCommand,eye),offsetof(ArmCommand,nativeEye),offsetof(ArmCommand,nativeEyeValid),offsetof(ArmCommand,changed),offsetof(ArmCommand,rootRelative),offsetof(ArmCommand,count),offsetof(ArmCommand,tick));printf("rest solver=%zu body=%zu size=%zu\n",offsetof(ArmRest,solver),offsetof(ArmRest,body),sizeof(ArmRest));}
