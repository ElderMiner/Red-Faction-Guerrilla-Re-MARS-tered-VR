#pragma once
#include "vr_arm_math.h"
namespace vrgutter {
// Rigid-metal coverage measured in authored weapon space. Ribbon vertices
// are excluded. The tip reaches 1.90m; the former .73m fallback missed it.
inline constexpr vrarm::V points[24]={{0,0,0},{-.007f,1.901f,.123f},{-.010f,.946f,.116f},{-.008f,1.432f,-.208f},{-.029f,.479f,-.008f},{-.007f,1.372f,.249f},{.031f,-.340f,-.023f},{-.008f,1.116f,-.152f},{-.008f,1.733f,-.098f},{-.004f,1.611f,.123f},{.031f,1.312f,.005f},{-.007f,1.148f,.269f},{-.003f,.687f,.002f},{0,.273f,.018f},{-.105f,-.206f,.034f},{.080f,-.202f,.070f},{-.032f,1.469f,-.005f},{.012f,1.070f,.006f},{-.005f,1.195f,.116f},{-.008f,1.577f,-.126f},{-.015f,.844f,-.017f},{-.023f,1.305f,-.131f},{.003f,1.409f,.114f},{-.030f,.134f,-.010f}};
inline constexpr float radius=.145f;
}
