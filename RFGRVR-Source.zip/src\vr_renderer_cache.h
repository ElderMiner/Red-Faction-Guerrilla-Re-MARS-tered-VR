#pragma once
#include <cstring>
// Exactly the six borrowed state ranges copied by engine RVA F3050. Excludes
// context/ownership pointers at +440/+478 and all camera/scene objects.
struct RFGRVRRendererCache {
 unsigned char values[0x410]{};
 void save(void* renderer){memcpy(values,(char*)renderer+0x30,sizeof(values));}
 void restore(void* renderer,unsigned mask=~0u)const{
  const unsigned offsets[]={0,0x100,0x1b0,0x200,0x220,0x290,0x410};
  for(unsigned i=0;i<6;++i)if(mask&(1u<<i))memcpy((char*)renderer+0x30+offsets[i],values+offsets[i],offsets[i+1]-offsets[i]);
  unsigned dirty=0xff;memcpy((char*)renderer+0x444,&dirty,sizeof(dirty));
 }
};
