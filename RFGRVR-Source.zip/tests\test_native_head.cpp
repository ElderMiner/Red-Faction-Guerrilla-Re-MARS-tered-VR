#define RFGR_TEST_USER_SETTINGS
#include "../src/native_head_camera.cpp"
#include <cassert>
#include "../src/vr_ragdoll_view.h"
static bool ragViewReady=false;static vrarm::Pose ragViewPose{};
extern "C" bool RFGRVR_Arms_RagdollHead(void*,vrarm::Pose* out){if(!ragViewReady)return false;*out=ragViewPose;return true;}
extern "C" bool RFGRVR_VehicleSitting(){return false;}
extern "C" void RFGRVR_Arms_Player(void*){}
static bool restEyeReady=false;static float restEyeHeight=1.68f;extern "C" bool RFGRVR_Arms_EyeReference(void*,float out[3]){out[0]=.01f;out[1]=restEyeHeight;out[2]=.078f;return restEyeReady;}
static bool physicalBlend=false;extern "C" bool RFGRVR_Arms_PhysicalCrouchBlend(){return physicalBlend;}
static bool physicalDuck=false;extern "C" bool RFGRVR_PhysicalCrouchView(){return physicalDuck;}
static float animatedEyeX=.01f,animatedEyeZ=.078f;static float animatedEyeHeight=1.2f;static bool animatedEyeReady=false;extern "C" bool RFGRVR_Arms_EyeLocal(void*,float out[3]){out[0]=animatedEyeX;out[1]=animatedEyeHeight;out[2]=animatedEyeZ;return animatedEyeReady;}
static void __cdecl Head(void* player,V3& pos,M3& basis){pos={1,2,3};memcpy(&basis,(char*)player+0x10,36);}
static bool allowPlacement=true;
static bool __cdecl Place(V3* out,void*,float,const V3* desired){*out=*desired;return allowPlacement;}
static void* __fastcall Cull(void* camera,void*){auto* c=(unsigned char*)camera;if(c!=cameraGlobal){assert(c[0x808]==0);assert(fabsf(*(float*)(c+0xbc)-114)<.0001f);assert(*(float*)(c+0x10c)==4);assert(*(float*)(c+0x110)==5);}return c+0x810;}
static void __fastcall Transform(void* player,void*,const V3* position,const M3* basis,bool){memcpy((char*)player+4,position,12);memcpy((char*)player+0x10,basis,36);}
static unsigned fakeCinematicState(){return 1;}
static unsigned fakeVideoState(){return 0x31;}
int main(){
 {auto* page=(unsigned char*)VirtualAlloc(nullptr,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);assert(page);auto q=vrmemory::queryTotal.load(),h=vrmemory::hitTotal.load();{vrmemory::Scope outer;assert(vrmemory::check(page,100,true));for(int i=0;i<1000;++i)assert(vrmemory::check(page+i,4));{vrmemory::Scope inner;assert(vrmemory::check(page,4));}}assert(vrmemory::queryTotal==q+1&&vrmemory::hitTotal>=h+1001);DWORD old=0;assert(VirtualProtect(page,4096,PAGE_READONLY,&old));{vrmemory::Scope next;assert(vrmemory::check(page,4)&&!vrmemory::check(page,4,true));}assert(VirtualFree(page,0,MEM_RELEASE));}

 {using namespace RFGRVRNativeTurret;auto* page=(unsigned char*)VirtualAlloc(nullptr,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);assert(page);{BatchMemory outer;assert(memory(page,64,true));unsigned before=regionBatch.count;assert(memory(page+32,16));assert(regionBatch.count==before);{BatchMemory nested;assert(memory(page,4,true));}assert(regionBatch.depth==1);}assert(regionBatch.count==0&&!regionBatch.depth);DWORD old=0;assert(VirtualProtect(page,4096,PAGE_READONLY,&old));{BatchMemory next;assert(memory(page,4)&&!memory(page,4,true));}assert(VirtualFree(page,0,MEM_RELEASE));}
for(unsigned state:{7u,0xfu,0x10u,0x12u,0x25u,0x2au,0x2eu,0x32u,0x35u,0x3eu}){assert(RFGRVR_PopupMenuEligible(state,1));assert(!RFGRVR_PopupMenuEligible(state,0));}for(unsigned state:{0u,1u,2u,0x2cu,0x2fu,0x31u,0x38u,0x3du})assert(!RFGRVR_PopupMenuEligible(state,1));assert(RFGRVR_MainMenuEligible(10,0x32,0)&&RFGRVR_MainMenuEligible(10,0x35,0)&&!RFGRVR_MainMenuEligible(10,0x32,1)&&!RFGRVR_MainMenuEligible(10,0x31,0));assert(RFGRVR_MainMenuEligible(10,0)&&!RFGRVR_MainMenuEligible(10,1));assert(RFGRVR_PopupMenuEligible(0x2a)&&RFGRVR_PopupMenuEligible(0x2e)&&!RFGRVR_PopupMenuEligible(1)&&!RFGRVR_PopupMenuEligible(0x2c)&&!RFGRVR_PopupMenuEligible(0x31));assert(RFGRVR_MainMenuEligible(0,0)&&RFGRVR_MainMenuEligible(0,7)&&!RFGRVR_MainMenuEligible(0,1)&&!RFGRVR_MainMenuEligible(4,0));
 // The observed tutorial notification: gameplay stack1, camera10, pause depth1.
 {unsigned char code[11]={0xa1,0x80,0x38,0xed,0x02,0x85,0xc0,0x0f,0x9f,0xc0,0xc3};assert(RFGRVR_PauseCounterAddress(code,0xda0000)==0x2ed3880);assert(!RFGRVR_PauseCounterAddress(code,0x400000));code[10]=0x90;assert(!RFGRVR_PauseCounterAddress(code,0xda0000));}
 assert(RFGRVR_BlockingNotificationEligible(10,1,1,1)&&RFGRVR_BlockingNotificationEligible(0,1,1,2));
 assert(!RFGRVR_BlockingNotificationEligible(10,1,1,0)&&!RFGRVR_BlockingNotificationEligible(4,1,1,1)&&!RFGRVR_BlockingNotificationEligible(10,1,0,1)&&!RFGRVR_BlockingNotificationEligible(10,0x31,1,1)&&!RFGRVR_BlockingNotificationEligible(10,1,1,~0u));
 // APC housings register on creation, including before first occupancy.
 {unsigned char vehicle[13600]{},definition[16]{};vehicle[0x7e]=3;*(unsigned*)(vehicle+0x6c)=123;*(void**)(vehicle+13588)=definition;*(const char**)definition="EDF_APC-A_1";RFGRVRNativeVehicle::parkedAPC=~0u;assert(RFGRVRNativeVehicle::rememberCreatedAPC(vehicle)&&RFGRVRNativeVehicle::parkedAPC==123);*(const char**)definition="EDF_Buggy";assert(!RFGRVRNativeVehicle::rememberCreatedAPC(vehicle));vehicle[0x7e]=1;*(const char**)definition="EDF_APC-A_1";assert(!RFGRVRNativeVehicle::rememberCreatedAPC(vehicle));RFGRVRNativeVehicle::parkedAPC=~0u;}
 // Keep the measured entry eye when the animated head jumps during jolts.
 {RFGRVRVehicleEyeAnchor seat;vrarm::Pose car{{{1,0,0},{0,1,0},{0,0,1}},{10,2,20}};vrarm::V eye{10.2f,3.4f,20.5f};assert(seat.update(5,car,eye,1000));assert(fabsf(eye.y-3.4f)<.0001f);eye.y=3.5f;seat.update(5,car,eye,1500);car.p.y+=1;eye.y=8;seat.update(5,car,eye,2200);assert(fabsf(eye.y-4.5f)<.0001f);eye.y=6;seat.update(6,car,eye,2300);assert(eye.y==6);}
 {RFGRVRVehicleEyeAnchor seat;vrarm::Pose car{{{1,0,0},{0,1,0},{0,0,1}},{0,0,0}};vrarm::V eye{.1f,.72f,.12f};seat.update(5,car,eye,1000);seat.update(5,car,eye,2001);car.b=vrarm::turnAround(car.b,{0,0,1},.6f);car.p={10,4,8};vrarm::V expected=vrarm::add(car.p,vrarm::world(car.b,{.1f,.72f,.12f}));eye=vrarm::add(car.p,vrarm::world(car.b,{.1f,.52f,-.02f}));assert(seat.update(5,car,eye,2100));assert(vrarm::length(vrarm::sub(eye,expected))<.0001f);seat.reset();assert(seat.id==~0u);}
 {vrarm::M bank=vrarm::turnAround(vrarm::M{{1,0,0},{0,1,0},{0,0,1}},{0,0,1},.9f);vrarm::V root{10,4,8},eye=RFGRVR_SeatHeightOffset(root,bank,-.2f);auto delta=vrarm::local(bank,vrarm::sub(eye,root));assert(fabsf(delta.x)<.0001f&&fabsf(delta.y+.2f)<.0001f&&fabsf(delta.z)<.0001f);}
 {RFGRVRSeatOrigin seat;float origin=0;seat.update(true,false,1.7f,1000,origin);assert(origin==1.7f);seat.update(true,true,1.2f,1016,origin);assert(origin<1.7f&&origin>1.65f);float previous=origin;seat.update(true,true,1.2f,1032,origin);assert(origin<previous&&origin>1.6f);seat.update(false,false,1.7f,2000,origin);assert(origin==0);}
 {RFGRVRVehicleHeightBlend blend;assert(blend.update(5,9,.2f,.016f)==.2f);float next=blend.update(5,9,.8f,.016f);assert(next>.2f&&next<.3f);assert(blend.update(6,9,.4f,.016f)==.4f);}
 // Reflection-only glass control: keep tint/tiling/exponent and restore exit.
 {unsigned char car[0xa0]{},subinfo[0x70]{},list[8]{},material[28]{},data[128]{};*(void**)(car+0x9c)=subinfo;*(void**)(subinfo+0x58)=list;*(unsigned*)(subinfo+0x60)=1;*(void**)list=material;*(void**)(material+0x18)=data;*(unsigned*)(data+4)=0xdee94842;*(unsigned*)(data+8)=1;*(unsigned*)(data+12)=0x10030002;*(unsigned*)(data+0x14)=0x20;*(unsigned*)(data+0x18)=0x34;auto* names=(unsigned*)(data+0x34);names[0]=0x08cc10ef;names[1]=0x39e923fe;names[2]=0xa0e07244;auto* constants=(float*)(data+0x4c);for(unsigned i=0;i<12;++i)constants[i]=1;constants[11]=10;RFGRVRNativeVehicle::Glass::update(car,true);assert(fabsf(constants[8]-.18f)<.00001f&&constants[0]==1&&constants[9]==1&&constants[10]==1&&constants[11]==10);RFGRVRNativeVehicle::Glass::update(car,true);assert(fabsf(constants[8]-.18f)<.00001f);RFGRVRNativeVehicle::Glass::update(nullptr,false);assert(constants[8]==1);}
 alignas(16) unsigned char player[0xc00]{},head[0x100]{},camera[0xa30]{};void* table[4]{};*(void***)head=table;
 *(float*)(head+0xd0)=1;*(void**)(player+0xa4)=head;player[0xb0]=1;
 M3 identity{{1,0,0},{0,1,0},{0,0,1}};memcpy(player+0x10,&identity,36);
 testLocalPlayer=player;active=true;ready=true;headFunction=Head;RFGRVR_HeadCam_SetBodyYaw(1.5707963268f);PlayerFrame(player,nullptr);
 assert(fabsf(((M3*)(player+0x10))->forward.x-1)<.00001f);assert(*(float*)(head+0xd0)==0);
 // Player-frame hook forwards NPC animation without any VR writes or head hiding.
 unsigned char npc[sizeof(player)];memcpy(npc,player,sizeof(npc));unsigned char beforeNPC[sizeof(npc)];memcpy(beforeNPC,npc,sizeof(npc));auto beforeReads=headReads.load();PlayerFrame(npc,nullptr);assert(!memcmp(npc,beforeNPC,sizeof(npc))&&headReads==beforeReads&&lastPlayer==player);
 float parent[9];unsigned state;assert(!RFGRVR_HeadCam_Parent(parent,&state));
 *(unsigned*)(player+0x2f4)=3;PlayerFrame(player,nullptr);assert(RFGRVR_HeadCam_TurretMounted());*(unsigned*)(player+0x2f4)=8;*(unsigned*)(player+0xa08)=123;PlayerFrame(player,nullptr);assert(RFGRVR_HeadCam_TurretMounted());*(unsigned*)(player+0x2f4)=9;PlayerFrame(player,nullptr);assert(!RFGRVR_HeadCam_TurretMounted());*(unsigned*)(player+0x2f4)=8;*(unsigned*)(player+0xa08)=~0u;PlayerFrame(player,nullptr);assert(!RFGRVR_HeadCam_TurretMounted());
 *(unsigned*)(player+0x2f4)=9;memcpy(player+0x10,&identity,36);PlayerFrame(player,nullptr);
 assert(((M3*)(player+0x10))->forward.z==1);assert(RFGRVR_HeadCam_Parent(parent,&state)&&state==9);
 *(unsigned*)(player+0x2f4)=0;*(unsigned*)(player+0x33c)=1;PlayerFrame(player,nullptr);
 assert(RFGRVR_HeadCam_Parent(parent,&state)&&state==0);assert(((M3*)(player+0x10))->forward.z==1);
 *(unsigned*)(player+0x33c)=0;void* objectTable[13]{};objectTable[12]=(void*)&Transform;*(void***)player=objectTable;
 *(unsigned*)(player+0xac4)=0xffffffffu;findPlacement=Place;
 // Native room input requests movement; it never teleports the player.
 RFGRVR_HeadCam_RoomRequest(.3f,0,.3f,0);short roomX=0,roomY=0;assert(RFGRVR_HeadCam_RoomAxes(0,true,&roomX,&roomY)&&roomX>7000&&roomY==0);
 float originalX=*(float*)(player+4);PlayerFrame(player,nullptr);assert(*(float*)(player+4)==originalX);
 float consumed[3];ObserveRoom(player,0,false,{0,0,0});ObserveRoom(player,0,false,{.05f,0,0});RFGRVR_HeadCam_RoomConsumed(consumed);assert(fabsf(consumed[0]-.05f)<.0001f);
 // Render interpolation must carry the sampled head offset, rather than
 // leaving the camera ahead of the body during walking or body rotation.
 unsigned char character[64]{},body[0x80]{};*(void**)(character+0x30)=body;sampledBodyCharacter=character;sampledBodyPosition={1,0,0};sampledBodyBasis=identity;tracked={1,1.6f,.12f};parented=false;playerState=0;lastHeadTick=GetTickCount64();
 vrarm::Pose rendered{{{0,0,-1},{0,1,0},{1,0,0}},{.8f,0,.1f}};memcpy(body+8,&rendered,48);float anchored[3]{};assert(RFGRVR_HeadCam_GetPosition(anchored));assert(fabsf(anchored[0]-.92f)<.0001f&&fabsf(anchored[1]-1.6f)<.0001f&&fabsf(anchored[2]-.1f)<.0001f);
 floorCalibration=true;calibratedHeight=1.5f;nativeEyeHeight=1.8f;playerStance=0;tracked.y=1.2f;float floorEye=0;
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));assert(fabsf(anchored[1]-1.8f)<.0001f&&floorEye==1.8f);
 playerStance=1;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye==-1.f);playerStance=0;crouchEyeBlend={};
 heightPlayer=player;float actualEye[3]={.01f,1.715f,.078f};RFGRVR_HeadCam_AvatarEye(player,actualEye);assert(fabsf(RFGRVR_HeadCam_WorldScale()-1.715f/1.5f)<.00001f);
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));assert(fabsf(anchored[1]-1.715f)<.0001f&&fabsf(anchored[0]-(rendered.p.x+.128f))<.0001f&&fabsf(anchored[2]-(rendered.p.z-.01f))<.0001f);
 // A saved vehicle trim must not make the standing avatar taller than NPCs.
 eyeUpCm=12;onFootEyeUpCm=0;
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));assert(fabsf(anchored[1]-1.715f)<.0001f&&fabsf(RFGRVR_HeadCam_WorldScale()*1.5f-1.715f)<.0001f);
 // User trim moves the camera without changing floor scale/reference.
 onFootEyeUpCm=3;eyeForwardCm=7;float scaleBefore=RFGRVR_HeadCam_WorldScale();
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));assert(fabsf(anchored[1]-1.745f)<.0001f&&floorEye==1.715f&&RFGRVR_HeadCam_WorldScale()==scaleBefore);
 // Manual forward trim preserves base floor/height calibration. World sizing
 // affects tracked/stereo scale together without fitting a new skeleton.
 {float before[3];memcpy(before,anchored,12);onFootEyeForwardCm=4;worldAppearancePercent=120;
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));
 assert(fabsf(anchored[1]-before[1])<.0001f&&fabsf(anchored[0]-before[0]-.04f)<.0001f);
 assert(fabsf(RFGRVR_HeadCam_SceneScale()-scaleBefore/1.2f)<.0001f&&RFGRVR_HeadCam_WorldScale()==scaleBefore);onFootEyeForwardCm=0;worldAppearancePercent=100;}
 // Jump/fall camera is carried by the interpolated body root, not stale
 // native head coordinates or the grounded floor override.
 parented=true;playerState=1;parentOrientation=identity;
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye==-1.f);float jumpY=anchored[1];rendered.p.y+=.8f;memcpy(body+8,&rendered,48);
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&fabsf(anchored[1]-jumpY-.8f)<.0001f);
 rendered.p.y-=.8f;memcpy(body+8,&rendered,48);eyeUpCm=onFootEyeUpCm=0;eyeForwardCm=5;parented=false;playerState=0;
 landingEye={};animatedEyeReady=true;playerStance=1;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye==-1.f&&fabsf(anchored[1]-1.2f)<.0001f);playerStance=0;animatedEyeReady=false;crouchEyeBlend={};
 // Physical crouching follows the rendered eye while the native stance remains crouched.
 vrsettings::cached.value[vrsettings::Crouch]=0;vrsettings::checked=GetTickCount();physicalDuck=true;animatedEyeReady=true;playerStance=1;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye==-1.f&&fabsf(anchored[1]-1.2f)<.0001f);animatedEyeHeight=.9f;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&fabsf(anchored[1]-.9f)<.0001f);physicalDuck=false;playerStance=0;animatedEyeReady=false;trackedCrouchEye=false;animatedEyeHeight=1.2f;crouchEyeBlend={};
 // Half crouch maps a partial physical dip to native crouch-eye height instead.
 vrsettings::cached.value[vrsettings::Crouch]=1;vrsettings::checked=GetTickCount();physicalDuck=true;animatedEyeReady=true;playerStance=1;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye==-1.f);physicalDuck=false;animatedEyeReady=false;playerStance=0;trackedCrouchEye=false;crouchEyeBlend={};
 // Controller locomotion follows the interpolated root, excluding walking head-bone bob.
 animatedEyeReady=true;bodyMoving=true;locomotionTick=GetTickCount64();
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&fabsf(floorEye-1.715f)<.0001f&&fabsf(anchored[1]-1.715f)<.0001f);
 animatedEyeHeight=.95f;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&fabsf(anchored[1]-1.715f)<.0001f);animatedEyeHeight=1.2f;
 bodyMoving=false;controllerAttachedMotion=true;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&fabsf(floorEye-1.715f)<.0001f);controllerAttachedMotion=false;playerState=1;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));
 playerState=0;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye==-1.f&&fabsf(anchored[1]-1.2f)<.0001f);
 // A lowered anticipation/crouch pose must not become the standing reference.
 {animationReferenceValid=false;restEyeReady=true;restEyeHeight=1.68f;animatedEyeReady=true;animatedEyeHeight=1.43f;landingEye={};crouchEyeBlend={};playerState=0;playerStance=0;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));assert(animationReferenceValid&&fabsf(animationReference.y-1.68f)<.0001f);playerState=1;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));playerState=0;animatedEyeHeight=1.68f;landingEye.landing=.9f;landingEye.settled=.19f;LARGE_INTEGER f{},now{};QueryPerformanceFrequency(&f);QueryPerformanceCounter(&now);crouchEyeClock.QuadPart=now.QuadPart-f.QuadPart/50;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));assert(!landingEye.active&&!animationRecovery.load());restEyeReady=false;landingEye={};crouchEyeBlend={};}
 // Physical blending never hijacks/filter HMD floor tracking at the native
 // crouch threshold. The eye's normal floor correction remains unchanged.
 {physicalBlend=true;physicalDuck=true;playerState=0;playerStance=1;animatedEyeReady=true;animatedEyeHeight=1.1f;landingEye={};crouchEyeBlend={};animationRecovery=false;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye>0);physicalBlend=false;physicalDuck=false;playerStance=0;crouchEyeBlend={};}
 // Actual camera continuity across floor/animation paths at the user's
 // non-default player scale. Temporal applies the floor correction only
 // in standing; the animation anchor must already contain the same value.
 {auto savedHeight=calibratedHeight.load();int savedPercent=playerReferencePercent.load(),savedTrim=onFootEyeUpCm.load();restEyeReady=true;restEyeHeight=1.68f;animatedEyeReady=true;animatedEyeHeight=1.68f;calibratedHeight=1.6f;onFootEyeUpCm=29;playerStance=0;playerState=0;
 for(int percent:{100,118,140}){playerReferencePercent=percent;landingEye={};crouchEyeBlend={};animationRecovery=false;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye>0);float expected=anchored[1]+RFGRVR_FloorEyeOffset(1.6f,floorEye,RFGRVR_HeadCam_WorldScale());playerState=1;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye==-1.f&&fabsf(anchored[1]-expected)<.0001f);playerState=0;playerStance=1;animatedEyeHeight=1.22f;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&fabsf(anchored[1]-(expected-.46f))<.0001f);playerStance=0;animatedEyeHeight=1.68f;}
 calibratedHeight=savedHeight;playerReferencePercent=savedPercent;onFootEyeUpCm=savedTrim;restEyeReady=false;landingEye={};crouchEyeBlend={};animationRecovery=false;}
 // Preserve the same camera/head offset through crouch, even when the
 // standing palette eye differs from the authored calibration reference.
 landingEye={};animationRecovery=false;animationReferenceValid=false;crouchEyeBlend={};playerState=0;playerStance=0;animatedEyeReady=true;restEyeReady=true;restEyeHeight=1.68f;animatedEyeHeight=1.68f;
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));float standingY=anchored[1];playerStance=1;animatedEyeHeight=1.22f;bodyMoving=true;
 assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye)&&floorEye==-1.f&&fabsf(anchored[1]-(standingY-.46f))<.0001f);
 // Grounded forward motion follows the actual rendered head once, including lean.
 playerStance=0;animatedEyeHeight=restEyeHeight;landingEye={};animationRecovery=false;crouchEyeBlend={};assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));float baseX=anchored[0],baseZ=anchored[2];animatedEyeX+=.03f;animatedEyeZ+=.12f;assert(RFGRVR_HeadCam_GetFrame(anchored,nullptr,nullptr,nullptr,&floorEye));assert(fabsf(anchored[0]-baseX-.12f)<.0001f&&fabsf(anchored[2]-baseZ+.03f)<.0001f);animatedEyeX=.01f;animatedEyeZ=.078f;
 bodyMoving=false;playerStance=0;restEyeReady=false;
 landingEye={};animatedEyeReady=false;crouchEyeBlend={};
 floorCalibration=false;tracked.y=1.6f;
 parented=true;assert(RFGRVR_HeadCam_GetPosition(anchored)&&anchored[0]==1&&anchored[2]==.12f);
 // Vehicle view carries translation AND parent rotation with the rendered
 // driver root, read through the same snapshot. Interactions stay untouched.
 playerState=9;parentOrientation=identity;bool attached=false;unsigned frameState=0;
 assert(RFGRVR_HeadCam_GetFrame(anchored,parent,&attached,&frameState)&&attached&&frameState==9);
 assert(fabsf(anchored[0]-.92f)<.0001f&&fabsf(anchored[2]-.1f)<.0001f);
 assert(fabsf(parent[6]-1)<.0001f&&fabsf(parent[8])<.0001f);
 playerState=4;assert(RFGRVR_HeadCam_GetFrame(anchored,parent,&attached,&frameState)&&anchored[0]==1&&parent[8]==1);
 parented=false;playerState=0;rendered.p.x=10;memcpy(body+8,&rendered,48);assert(RFGRVR_HeadCam_GetPosition(anchored)&&anchored[0]==1);sampledBodyCharacter=nullptr;
 {using namespace vrarm;ragViewPose={turnAround(M{{1,0,0},{0,1,0},{0,0,1}},{0,0,1},1.2f),{17,4,23}};ragViewReady=true;bool lock=false;unsigned mode=0;float floor=0;assert(RFGRVR_HeadCam_GetFrame(anchored,parent,&lock,&mode,&floor)&&lock&&mode==0x103&&floor==-1);assert(length(sub(*(V*)anchored,ragViewPose.p))<.00001f&&!memcmp(parent,&ragViewPose.b,36));auto left=RFGRVR_RagdollEye(ragViewPose,{-.032f,0,0},1.2f),right=RFGRVR_RagdollEye(ragViewPose,{.032f,0,0},1.2f);assert(length(sub(mul(add(left.p,right.p),.5f),ragViewPose.p))<.00001f);assert(fabsf(length(sub(left.p,right.p))-.0768f)<.00001f);assert(!memcmp(&left.b,&ragViewPose.b,36));ragViewReady=false;}
 active=false;PlayerFrame(player,nullptr);assert(*(float*)(head+0xd0)==1&&*(unsigned short*)(head+0x40)==0);
 active=true;ready=true;cameraGlobal=camera;auto oldStateReader=cinematicGameState;cinematicGameState=fakeCinematicState;*(unsigned*)camera=4;float scriptedPosition[3]={30,40,50};memcpy(camera+44,scriptedPosition,12);memcpy(camera+80,&identity,36);assert(RFGRVR_HeadCam_Cinematic());auto cinematicReads=headReads.load();auto beforeCinematicBasis=*(M3*)(player+0x10);PlayerFrame(player,nullptr);assert(headReads==cinematicReads&&!memcmp(player+0x10,&beforeCinematicBasis,36)&&*(float*)(head+0xd0)==1);bool scriptedAttached=false;unsigned scriptedState=0;float scriptedFloor=0;assert(RFGRVR_HeadCam_GetFrame(anchored,parent,&scriptedAttached,&scriptedState,&scriptedFloor)&&anchored[0]==30&&anchored[1]==40&&scriptedAttached&&scriptedState==0x100&&scriptedFloor==-1);RFGRVR_HeadCam_Apply();assert(*(float*)(camera+44)==30);cinematicGameState=fakeVideoState;assert(!RFGRVR_HeadCam_Cinematic());cinematicGameState=oldStateReader;*(unsigned*)camera=0;memset(camera+44,0,12);memset(camera+80,0,36);float position[3]={4,5,6};camera[0x808]=1;RFGRVR_HeadCam_RenderBegin(position,(float*)&identity);assert(camera[0x808]==0);
 assert(*(float*)(camera+44)==4&&*(float*)(camera+268)==4);RFGRVR_HeadCam_RenderEnd();assert(*(float*)(camera+44)==0&&*(float*)(camera+268)==0);
 *(float*)(camera+188)=75;RFGRVR_HeadCam_RenderBegin(position,(float*)&identity);RFGRVR_HeadCam_RenderFov(110);assert(*(float*)(camera+188)==110);camera[0x808]=1;RFGRVR_HeadCam_RenderEnd();assert(*(float*)(camera+188)==75&&camera[0x808]==0);
 originalCulling=(CullingQuery)&Cull;unsigned char nativeCamera[sizeof(camera)];memcpy(nativeCamera,camera,sizeof(camera));
 void* planes=OnCulling(camera,nullptr);assert(planes!=camera+0x810&&trackedCullQueries==1&&!memcmp(camera,nativeCamera,sizeof(camera)));
 assert(OnCulling(camera,nullptr)==planes&&trackedCullQueries==2&&trackedCullBuilds==1);
 trackedCull.tick=GetTickCount64()-500;assert(OnCulling(camera,nullptr)==camera+0x810&&trackedCullQueries==2);
 RFGRVR_HeadCam_RenderBegin(position,(float*)&identity);*(float*)(camera+44)=20;RFGRVR_HeadCam_RenderEnd();assert(*(float*)(camera+44)==20);
 // Mounted body, render root and eye anchor share the independent orbit pose.
 *(unsigned*)(player+0x2f4)=3;*(unsigned*)(player+0xa08)=444;*(void**)(player+0x32c)=character;*(void**)(character+0x30)=body;
 RFGRVRNativeTurret::rig.ready=true;RFGRVRNativeTurret::rig.identity=444;RFGRVRNativeTurret::rig.body={{{1,0,0},{0,1,0},{0,0,1}},{4,0,5}};RFGRVRNativeTurret::fresh=GetTickCount64();distanceCm=riseCm=0;nativeEyeHeight=1.7f;eyeUpCm=onFootEyeUpCm=0;eyeForwardCm=5;
 vrarm::Pose renderBefore{};memcpy(&renderBefore,body+8,48);vrarm::V physicsBefore{};memcpy(&physicsBefore,player+4,12);PlayerFrame(player,nullptr);assert(!memcmp(&physicsBefore,player+4,12));vrarm::Pose mountedRender{};memcpy(&mountedRender,body+8,48);assert(!memcmp(&mountedRender,&renderBefore,48));assert(fabsf(tracked.y-actualEye[1])<.0001f&&fabsf(tracked.x-4-actualEye[0])<.0001f&&fabsf(tracked.z-5-actualEye[2])<.0001f);
 vrarm::Pose centered{{{0,0,-1},{0,1,0},{1,0,0}},{4,0,5}};auto axis=centered.p;RFGRVRNativeVehicle::eyeHeight=.3f;alignSeatedTurretBody(player,8,centered);assert(fabsf(centered.p.y-axis.y)<.0001f);RFGRVRNativeVehicle::eyeHeight=0;auto eyePoint=vrarm::add(centered.p,vrarm::world(centered.b,{actualEye[0],0,actualEye[2]}));assert(fabsf(eyePoint.x-axis.x)<.0001f&&fabsf(eyePoint.z-axis.z)<.0001f);
 *(unsigned*)(player+0x2f4)=0;PlayerFrame(player,nullptr);assert(!RFGRVRNativeTurret::rig.ready);

}

extern "C" bool RFGRVR_Arms_TurretHand(float[3],float[3]){return false;}

extern "C" bool RFGRVR_Arms_TurretBody(float[3]){return false;}

extern "C" float RFGRVR_Arms_TurretGripLever(unsigned){return 0;}

extern "C" bool RFGRVR_Arms_TurretHandZero(float[3]){return false;}

extern "C" bool RFGRVR_Arms_TurretHandleTarget(float[3],float[3]){return false;}

extern "C" void RFGRVR_Arms_Cinematic(bool){}




