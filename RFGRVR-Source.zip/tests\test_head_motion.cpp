#define NOMINMAX
#define RFGR_TEST_USER_SETTINGS
#include "../src/vr_head_motion.h"
#include <cassert>
#include "../src/vr_room_motion.h"
#include "../src/vr_body_yaw.h"
using namespace vrheadmotion;
static RFGRPose head(float yaw,float pitch,V offset={.012f,-.13f,.075f}){
 RFGRPose h{};float sy=sinf(yaw/2),cy=cosf(yaw/2),sx=sinf(pitch/2),cx=cosf(pitch/2);h.orientation[0]=cy*sx;h.orientation[1]=sy*cx;h.orientation[2]=-sy*sx;h.orientation[3]=cy*cx;h.validFlags=3;V p=sub(V{0,1.6f,0},world(basis(h),offset));memcpy(h.position,&p,12);return h;
}
int main(){
 std::vector<Pose> samples;for(int i=0;i<120;++i){float t=i*.08f;samples.push_back(pose(head(.7f*sinf(t),.45f*sinf(t*1.6f))));}auto measured=fit(samples);assert(measured.valid&&length(sub(measured.offset,V{.012f,-.13f,.075f}))<.0001f&&measured.error<.0001f);
 for(unsigned i=0;i<samples.size();++i)samples[i].p.x+=.09f*sinf(i*.4f);assert(!fit(samples).valid);samples.clear();for(int i=0;i<60;++i)samples.push_back(pose(head(i*.015f,0)));assert(!fit(samples).valid);
 Guide guide;guide.begin(head(0,0));guide.persist=false;unsigned long long now=1000;
 for(int i=0;i<400;++i)guide.update(head(0,0),now+=30);assert(guide.active&&guide.phase==0&&guide.dotYaw==0&&guide.dotPitch==0);
 for(unsigned phase=0;phase<4;++phase){assert(guide.phase==phase);float start=phase==1?.65f:phase==3?.45f:0,target=guide.target();for(int i=0;i<=70;++i){float angle=start+(target-start)*i/70.f;guide.update(head(phase<2?angle:0,phase>=2?angle:0),now+=30);}for(int i=0;i<10&&guide.active&&guide.phase==phase;++i)guide.update(head(phase<2?target:0,phase>=2?target:0),now+=30);}
 // The fitted pivot rejects eye arcs for simultaneous yaw/pitch. Real
 // translation still reaches the body-follow request with the tighter radius.
 {auto initial=head(0,0);V eye=mul(measured.offset,-1),neck0=world(basis(initial),eye);RFGRVRRoomMotion motion;motion.reset(&neck0.x);for(int i=0;i<100;++i){auto h=head(.8f*sinf(i*.1f),.5f*cosf(i*.12f));V neck=world(basis(h),eye),delta=sub({h.position[0],h.position[1],h.position[2]},{initial.position[0],initial.position[1],initial.position[2]});float out[3];motion.displacement(&delta.x,&neck.x,out);assert(fabsf(out[0])+fabsf(out[2])<.00001f);delta.x+=.06f;motion.displacement(&delta.x,&neck.x,out);assert(fabsf(out[0]-.045f)<.00001f);}}
 {M identity{{1,0,0},{0,1,0},{0,0,1}};Pose root{turnAround(identity,{0,1,0},.6f),{0,.7f,0}},torso{root.b,add(root.p,world(root.b,{0,.4f,.1f}))};auto fixed=RFGRVR_AlignBodyYaw(torso,root,0);assert(fabsf(RFGRVR_BodyYaw(fixed.b))<.00001f&&fabsf(fixed.p.y-torso.p.y)<.00001f&&length(sub(fixed.p,{0,1.1f,.1f}))<.00001f);}
 assert(guide.done&&!guide.active&&guide.fitted.valid&&!guide.saved&&guide.samples.size()>=20);assert(save(measured));for(int i=0;i<60;++i){auto h=head(.7f*sinf(i*.1f),.45f*sinf(i*.2f));assert(fabsf(uprightHeight(h)-head(0,0).position[1])<.0001f);}char path[MAX_PATH];profilePath(path);assert(DeleteFileA(path));puts("PASS: guided left/right/up/down, measured neck pivot, degenerate/noisy rejection, no arm or scale fitting");
}

