#pragma once
#include "vr_arm_math.h"
#include <cctype>
#include <cstdint>
#include <algorithm>
namespace vrrecoil {
struct Profile {float degrees=0,back=0,returnRate=24,unsupportedGain=1.8f;bool perRound=false;};
inline bool contains(const char* name,const char* part){if(!name)return false;for(;*name;++name){const char* a=name;const char* b=part;while(*a&&*b&&std::tolower((unsigned char)*a)==*b){++a;++b;}if(!*b)return true;}return false;}
inline Profile profile(unsigned type,const char* name){
 if(contains(name,"sniper_rifle")||contains(name,"rail_driver"))return {5,.04f,20};
 if(type==2||type==3||type==4||type==5||type==6||type==7||type==8||type==14||type==15)return {};
 if(contains(name,"shotgun"))return {6,.035f,22};
 if(type==1)return {5,.04f,20};
 if(type==12||contains(name,"gauss"))return {5.5f,.035f,23};
 if(type==11)return {3.5f,.022f,25};
 if(contains(name,"pistol"))return {5.5f,.026f,22,1.f,true};
 if(contains(name,"smg"))return {1.2f,.009f,30};
 if(type==10||type==16)return {.35f,.004f,32};
 if(type==9||type==13)return {3,.025f,24};
 return type==0?Profile{2,.014f,28}:Profile{};
}
struct Spring {
 float x=0,v=0;
 void step(float dt,float rate){float j=v+rate*x,e=expf(-rate*dt);x=(x+j*dt)*e;v=(v-rate*j*dt)*e;}
};
struct State {
 uintptr_t weapon=0;unsigned handle=0;int ammo=0;uint64_t tick=0;Spring pitch{},back{};float climb=0;uint64_t lastShot=0;
 void observe(uintptr_t id,unsigned serial,int loaded,bool shotRecent,bool magazineRemoved,uint64_t now,Profile p,bool supported){
  if(id!=weapon||serial!=handle||!tick||now<tick||now-tick>500){bool retainRound=p.perRound&&id==weapon&&serial==handle&&tick&&now>=tick;int previousAmmo=ammo;*this={};weapon=id;handle=serial;ammo=retainRound?previousAmmo:loaded;tick=now;if(!retainRound)return;}
  float dt=float(now-tick)*.001f;tick=now;if(lastShot&&now-lastShot>180)climb*=expf(-(std::min)(dt,float(now-lastShot-180)*.001f)*3.5f);float rate=p.returnRate+(supported?6.f:0);pitch.step(dt,rate);back.step(dt,rate);
  if(loaded>=0&&ammo>loaded&&(shotRecent||(p.perRound&&ammo-loaded<=4))&&!magazineRemoved&&p.degrees>0){float gain=supported?.45f:p.unsupportedGain;float count=float((std::min)(4,ammo-loaded));float kick=gain*p.degrees*.01745329252f;climb=(std::min)(.5235988f,climb+count*kick*(supported?.50f:.65f));lastShot=now;pitch.v+=(std::min)(1.4f,count)*kick*.35f*rate*2.7182818f;back.v+=(std::min)(1.4f,count)*gain*p.back*rate*2.7182818f;}
  ammo=loaded;pitch.x=(std::min)(pitch.x,.20944f);back.x=(std::min)(back.x,.07f);
 }
 vrarm::Pose apply(vrarm::Pose pose,vrarm::V grip,vrarm::M barrel,float scale)const{using namespace vrarm;V pivot=add(pose.p,world(pose.b,grip));pose.b=turnAround(pose.b,barrel.r,-(pitch.x+climb));pose.p=sub(sub(pivot,world(pose.b,grip)),mul(barrel.f,back.x*scale));return pose;}
};
}

