#include "vr_wrist_status.h"
#include "vr_memory_access.h"
#include "vr_user_settings.h"
#include "native_pause_settings.h"
extern "C" void RFGRVR_Arms_Cinematic(bool);
extern "C" bool RFGRVR_HeadCam_Cinematic();
extern "C" bool RFGRVR_HeadCam_IsLocalPlayer(void*);
extern "C" bool RFGRVR_HeadCam_MenuScene();
extern "C" bool RFGRVR_HeadCam_PopupMenu();
#include "vr_cinematic_camera.h"
#include "vr_landing_eye.h"
#include "vr_turret_barrel.h"
#include "native_turret_rig.h"
#include "native_vehicle_weapons.h"
#include "vr_controller_coast.h"
#include "vr_forward_lean.h"
// Experimental native head-anchored camera for the exact user-supplied x86 rfg.exe.
// RSL references: CameraManager.cpp, PlayerDoFrame.cpp, FunctionManager.cpp.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <atomic>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdint>
#include "../vendor/MinHook.h"
#include "vr_world_scale.h"
#include "vr_arm_math.h"
#include "vr_render_anchor.h"
#include "vr_vehicle_eye_anchor.h"
#include "vr_body_heading.h"
#include "vr_crouch_eye.h"
#include "vr_room_drive.h"
extern "C" void RFGRVR_Arms_Player(void*);
extern "C" bool RFGRVR_Arms_PhysicalCrouchBlend();
extern "C" bool RFGRVR_Arms_EyeReference(void*,float[3]);
extern "C" bool RFGRVR_Arms_EyeLocal(void*,float[3]);
extern "C" bool RFGRVR_PhysicalCrouchView();
namespace {
constexpr uintptr_t PLAYER_FRAME_RVA=0x6D5A80;
constexpr uintptr_t HEAD_POS_RVA=0x69B5D0;
constexpr uintptr_t GLOBAL_CAMERA_REF_RVA=0x23394C;
const unsigned char playerSig[]={0x81,0xec,0x04,0x02,0x00,0x00,0xa1};
const unsigned char headSig[]={0x83,0xec,0x18,0x53,0x56,0x8b};
// RSL rfg_camera: mode 4 + stack[8] 32 + stack_size 4 + level_mode 4.
constexpr size_t REAL_POS_OFFSET=44;
struct V3 {float x,y,z;};
struct M3 {V3 right,up,forward;};
using FrameFn=void(__fastcall*)(void*,void*);
using HeadFn=void(__cdecl*)(void*,V3&,M3&);
FrameFn originalFrame=nullptr;
RFGRVRVehicleEyeAnchor driverEyeAnchor;
HeadFn headFunction=nullptr;
std::atomic<unsigned> roomInputPolls{0},roomInputDrives{0},roomAcceptedMoves{0},frustumInvalidations{0};
RFGRVRRoomDrive roomDrive;void* roomDrivePlayer=nullptr;
unsigned char* cameraGlobal=nullptr;
std::atomic<bool> active{false},ready{false};
std::atomic<int> distanceCm{12},riseCm{5};
std::atomic<unsigned> playerFrames{0},headReads{0},positionWrites{0},failed{0};
std::atomic<long> positionSeq{0};
std::atomic<ULONGLONG> lastHeadTick{0};
 V3 tracked{},sampledBodyPosition{};M3 sampledBodyBasis{};void* sampledBodyCharacter=nullptr;M3 parentOrientation{};bool parented=false;unsigned playerState=0,playerStance=0;
std::atomic<float> bodyYaw{0},lastHeadYaw{0};std::atomic<ULONGLONG> bodyYawTick{0};
void* lastPlayer=nullptr;unsigned short hiddenFlags=0;
void* hiddenHead=nullptr;float hiddenOpacity=1;void* hiddenVtable=nullptr;
static void RestoreHead();
struct CameraField {size_t offset,bytes;unsigned char saved[36],written[36];};
using PlaceFn=bool(__cdecl*)(V3*,void*,float,const V3*);
PlaceFn findPlacement=nullptr;
SRWLOCK roomLock=SRWLOCK_INIT;V3 roomWanted{},roomRaw{},roomConsumed{};bool roomPending=false;
std::atomic<float> calibratedHeight{0},nativeEyeHeight{0};std::atomic<void*> heightPlayer{nullptr};
std::atomic<bool> floorCalibration{false};
RFGRVRControllerCoast controllerCoast;std::atomic<bool> controllerAttachedMotion{false};LARGE_INTEGER coastClock{};
RFGRVRBodyHeading bodyHeading;std::atomic<bool> bodyMoving{false},bodyTurning{false};std::atomic<ULONGLONG> locomotionTick{0};LARGE_INTEGER headingClock{};
std::atomic<int> playerReferencePercent{100},worldAppearancePercent{100},onFootEyeForwardCm{0};
std::atomic<int> eyeUpCm{0},onFootEyeUpCm{0},eyeForwardCm{5};
std::atomic<bool> animationRecovery{false};V3 animationReference{};bool animationReferenceValid=false;bool trackedCrouchEye=false;RFGRVRLandingEye landingEye;RFGRVRCrouchEye crouchEyeBlend;void* crouchEyePlayer=nullptr;LARGE_INTEGER crouchEyeClock{};
SRWLOCK eyeLock=SRWLOCK_INIT;void* eyePlayer=nullptr;V3 avatarEye{};
static bool inRegion(const void*,size_t,bool);
static bool finite(V3);
static void ObserveRoom(void* player,unsigned state,bool attached,V3 position){
 float consumed[2]{};
 AcquireSRWLockExclusive(&roomLock);if(roomDrivePlayer!=player){roomDrivePlayer=player;roomDrive.positioned=false;}
 roomDrive.observe(position.x,position.z,state==0&&!attached,GetTickCount64(),consumed);
 roomConsumed.x+=consumed[0];roomConsumed.z+=consumed[1];if(fabsf(consumed[0])+fabsf(consumed[1])>.00001f)++roomAcceptedMoves;ReleaseSRWLockExclusive(&roomLock);
}
CameraField renderFields[4]={{44,12},{80,36},{268,12},{280,36}};bool renderingPose=false;std::atomic<bool> auxiliaryRendering{false};float savedRenderFov=0,writtenRenderFov=0;bool renderFovOwned=false;
using CullingQuery=void*(__thiscall*)(void*);CullingQuery originalCulling=nullptr;
struct TrackedCull {V3 position{},body{};M3 basis{};float fov=0;ULONGLONG tick=0;unsigned revision=0;};
TrackedCull trackedCull;SRWLOCK cullLock=SRWLOCK_INIT;std::atomic<unsigned> trackedCullQueries{0},trackedCullBuilds{0};
static bool inRegion(const void* ptr,size_t n,bool write){return vrmemory::check(ptr,n,write);}

static bool finite(V3 p){return std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z)&&std::fabs(p.x)<1000000 && std::fabs(p.y)<1000000 && std::fabs(p.z)<1000000;}
static void* __fastcall OnCulling(void* camera,void*){
 // Animation/attachment preparation queries the camera before scene rendering.
 // Give that query the tracked view too, without changing the native camera or
 // reusing an eye pass's cached planes in the simulation phase.
 if(camera!=cameraGlobal||!active.load()||renderingPose)return originalCulling(camera);
 TrackedCull pose;AcquireSRWLockShared(&cullLock);pose=trackedCull;ReleaseSRWLockShared(&cullLock);
 auto now=GetTickCount64();if(!pose.tick||now-pose.tick>250||pose.fov<10||pose.fov>170)return originalCulling(camera);
 V3 body=pose.body;for(unsigned tries=0;tries<3;++tries){auto sequence=positionSeq.load();if(sequence&1)continue;V3 sample=sampledBodyPosition;if(sequence==positionSeq.load()){body=sample;break;}}
 V3 delta{body.x-pose.body.x,body.y-pose.body.y,body.z-pose.body.z};
 if(!finite(delta)||delta.x*delta.x+delta.y*delta.y+delta.z*delta.z>4)return originalCulling(camera);
 pose.position={pose.position.x+delta.x,pose.position.y+delta.y,pose.position.z+delta.z};
 alignas(16) thread_local unsigned char scratch[0xa30];thread_local unsigned revision=~0u;thread_local V3 cachedBody{};
 ++trackedCullQueries;if(revision==pose.revision&&!memcmp(&cachedBody,&body,sizeof(body)))return scratch+0x810;
 memcpy(scratch,camera,sizeof(scratch));
 memcpy(scratch+0x10c,&pose.position,12);memcpy(scratch+0x118,&pose.basis,36);
 float conservativeFov=std::fmin(170.f,pose.fov+4.f);memcpy(scratch+0xbc,&conservativeFov,4);scratch[0x808]=0;
 void* result=originalCulling(scratch);revision=pose.revision;cachedBody=body;++trackedCullBuilds;return result;
}
static void RestoreHead(){
 if(hiddenHead&&inRegion((char*)hiddenHead+0xd0,4,true)&&inRegion(hiddenHead,4,false)){
 void* table=nullptr;memcpy(&table,hiddenHead,4);float alpha=0;memcpy(&alpha,(char*)hiddenHead+0xd0,4);
 if(table==hiddenVtable&&alpha==0){memcpy((char*)hiddenHead+0xd0,&hiddenOpacity,4);
 unsigned short flags=0;memcpy(&flags,(char*)hiddenHead+0x40,2);if(flags==(unsigned short)(hiddenFlags|0x20))memcpy((char*)hiddenHead+0x40,&hiddenFlags,2);}}
 hiddenHead=nullptr;
}
static void HideHead(void* player){
 if(!RFGRVR_HeadCam_IsLocalPlayer(player)||RFGRVR_HeadCam_Cinematic())return;
 if(!inRegion((char*)player+0x9c,24,false))return;
 unsigned char loaded=0;memcpy(&loaded,(char*)player+0xb0,1);void* head=nullptr;memcpy(&head,(char*)player+0xa4,4);
 if(!loaded||!inRegion(head,4,false)||!inRegion((char*)head+0xd0,4,true))return;
 void* table=nullptr;memcpy(&table,head,4);if(!inRegion(table,8,false))return;
 if(head!=hiddenHead){RestoreHead();float opacity=0;memcpy(&opacity,(char*)head+0xd0,4);
 if(!std::isfinite(opacity)||opacity<0||opacity>1)return;hiddenHead=head;hiddenOpacity=opacity;hiddenVtable=table;memcpy(&hiddenFlags,(char*)head+0x40,2);}
 unsigned short flags=0;memcpy(&flags,(char*)head+0x40,2);flags|=0x20;memcpy((char*)head+0x40,&flags,2);
 float zero=0;memcpy((char*)head+0xd0,&zero,4);
}
std::atomic<bool> mountedTurret{false};
std::atomic<float> forwardMotion{0},forwardLean{0};RFGRVRForwardLean leanState;V3 avatarPelvis{0,.9f,0};
using TurretLookup=void*(__thiscall*)(void*,unsigned);TurretLookup turretLookup=nullptr;void* turretRegistry=nullptr;
static void alignSeatedTurretBody(void* player,unsigned state,vrarm::Pose& pose){if(state!=8)return;vrarm::V eye{};AcquireSRWLockShared(&eyeLock);if(eyePlayer==player&&finite(avatarEye))memcpy(&eye,&avatarEye,12);ReleaseSRWLockShared(&eyeLock);eye.y=0;eye.z+=(eyeForwardCm.load()-5)/100.f;pose.p=vrarm::sub(pose.p,vrarm::world(pose.b,eye));}
struct VehicleFrameCost {
 LARGE_INTEGER start{},nativeEnd{},vehicleEnd{},visibilityEnd{},headEnd{};void* player;
 VehicleFrameCost(void* p):player(p){QueryPerformanceCounter(&start);}
 ~VehicleFrameCost(){
#ifndef RFGR_TEST_USER_SETTINGS
  if(!active.load()||!inRegion((char*)player+0x2f4,4,false))return;unsigned state=0;memcpy(&state,(char*)player+0x2f4,4);if(state<7||state>10)return;
  LARGE_INTEGER end{},frequency{};QueryPerformanceCounter(&end);QueryPerformanceFrequency(&frequency);
  static double nativeMs=0,vrMs=0,vehicleMs=0,visibilityMs=0,headMs=0;static unsigned samples=0;static ULONGLONG last=GetTickCount64();
  nativeMs+=1000.*double(nativeEnd.QuadPart-start.QuadPart)/frequency.QuadPart;vrMs+=1000.*double(end.QuadPart-nativeEnd.QuadPart)/frequency.QuadPart;++samples;auto ms=[&](LARGE_INTEGER a,LARGE_INTEGER b){return b.QuadPart>=a.QuadPart?1000.*double(b.QuadPart-a.QuadPart)/frequency.QuadPart:0.;};vehicleMs+=ms(nativeEnd,vehicleEnd);visibilityMs+=ms(vehicleEnd,visibilityEnd);headMs+=ms(visibilityEnd,headEnd);
  if(GetTickCount64()-last<5000)return;last=GetTickCount64();FILE* file=nullptr;if(!fopen_s(&file,"RFGRVR-Vehicle-Frame-Cost.log","a")&&file){fprintf(file,"tick=%llu state=%u samples=%u nativePlayerMs=%.4f vrSeatMs=%.4f vehicleUpdateMs=%.4f visibilityMs=%.4f nativeHeadMs=%.4f\n",last,state,samples,nativeMs/samples,vrMs/samples,vehicleMs/samples,visibilityMs/samples,headMs/samples);fclose(file);}samples=0;nativeMs=vrMs=vehicleMs=visibilityMs=headMs=0;
#endif
 }
};
static void __fastcall PlayerFrame(void* player,void* edx){
 VehicleFrameCost frameCost(player);
 if(originalFrame)originalFrame(player,edx);QueryPerformanceCounter(&frameCost.nativeEnd);
 if(!RFGRVR_HeadCam_IsLocalPlayer(player))return;
 bool cinematic=RFGRVR_HeadCam_Cinematic();RFGRVR_Arms_Cinematic(cinematic);if(cinematic){RestoreHead();return;}
 RFGRVRNativeTurret::BatchMemory vehicleMemory;vrmemory::Scope memoryScope;
 ++playerFrames;
 if(!active.load(std::memory_order_relaxed)||!player||!headFunction){mountedTurret=false;RFGRVRNativeTurret::unmount();RestoreHead();return;}
 if(!inRegion(player,64,false)){++failed;return;}
 unsigned state=0;if(!inRegion((char*)player+0x2f4,4,false))return;memcpy(&state,(char*)player+0x2f4,4);if(state>16)return;
 unsigned turretHandle=~0u;if(inRegion((char*)player+0xa08,4,false))memcpy(&turretHandle,(char*)player+0xa08,4);mountedTurret=state==3||(state==8&&turretHandle!=~0u&&turretHandle!=0);
 if(!mountedTurret.load())RFGRVRNativeTurret::unmount();else RFGRVRNativeTurret::step(player);
 LARGE_INTEGER coastNow{},coastFrequency{};QueryPerformanceCounter(&coastNow);QueryPerformanceFrequency(&coastFrequency);float coastDt=coastClock.QuadPart?float(double(coastNow.QuadPart-coastClock.QuadPart)/coastFrequency.QuadPart):0;coastClock=coastNow;
 RFGRVRNativeVehicle::update(player,coastDt);QueryPerformanceCounter(&frameCost.vehicleEnd);
 forwardLean=leanState.update(GetTickCount64()-locomotionTick.load()<250?forwardMotion.load():0,coastDt,state==0&&RFGRVRNativeTurret::word(player,0x2fc)==0);
 bool stickFresh=bodyMoving.load()&&GetTickCount64()-locomotionTick.load()<250;
 if(state<=2)controllerAttachedMotion=controllerCoast.update(stickFresh,((V3*)((char*)player+4))->x,((V3*)((char*)player+4))->z,coastDt);else{controllerCoast={};controllerAttachedMotion=false;}
 // The executable's head routine independently verifies state+2F4 and vehicle+AC4.
 unsigned rag=0;memcpy(&rag,(char*)player+0x33c,4);if(rag>6)return;lastPlayer=player;
 auto tick=bodyYawTick.load(std::memory_order_acquire);
 if(state<=2&&rag==0&&tick&&GetTickCount64()-tick<250&&inRegion((char*)player+0x10,36,true)){
  const float yaw=bodyYaw.load(),c=cosf(yaw),s=sinf(yaw);M3 upright{{c,0,-s},{0,1,0},{s,0,c}};memcpy((char*)player+0x10,&upright,36);
 }
 vrarm::Pose mountedBody{};bool vrMount=mountedTurret.load()&&RFGRVRNativeTurret::body(player,mountedBody);
 if(vrMount)alignSeatedTurretBody(player,state,mountedBody);
 // The native render matrix remains engine-owned. Skin output is rebased
 // to this VR anchor at the actual draw handoff.
 if(RFGRVR_HeadCam_Cinematic()||(state>=7&&state<=10&&!vrsettings::get().value[vrsettings::Vehicles]))RestoreHead();else HideHead(player);
 QueryPerformanceCounter(&frameCost.visibilityEnd);V3 head{};M3 orientation{};
 // Only executed for engine-supplied Player*; original RSL function is x86 cdecl.
 const unsigned driverId=RFGRVRNativeTurret::word(player,0xac4);
 const bool rigidDriver=state==9&&!RFGRVR_HeadCam_Cinematic()&&!RFGRVRNativeVehicle::isMech()&&!RFGRVRNativeVehicle::thirdPerson();
 vrarm::Pose driverRoot{};memcpy(&driverRoot.p,(char*)player+4,12);memcpy(&driverRoot.b,(char*)player+0x10,36);vrarm::V cachedEye{};
 // After settling, the native third-person camera query contributes nothing
 // to this rigid seat anchor. Do not run its collision/effect calculation only
 // to throw the result away. Physical head pose remains applied at eye render.
 if(rigidDriver&&driverEyeAnchor.position(driverId,driverRoot,GetTickCount64(),cachedEye)){memcpy(&head,&cachedEye,12);memcpy(&orientation,&driverRoot.b,36);}
 else headFunction(player,head,orientation);QueryPerformanceCounter(&frameCost.headEnd);
 // Wheeled driver camera helpers can alternate between two native offsets
 // while driving, despite an unchanged seated skeleton. Preserve the entry
 // offset in the rigid seated-body frame; physical HMD motion and saved
 // height remain separate. Mechs retain their articulated head attachment.
 if(rigidDriver){
  vrarm::Pose seat{};memcpy(&seat.p,(char*)player+4,12);memcpy(&seat.b,(char*)player+0x10,36);
  vrarm::V eye{head.x,head.y,head.z};if(driverEyeAnchor.update(RFGRVRNativeTurret::word(player,0xac4),seat,eye,GetTickCount64()))memcpy(&head,&eye,12);
 }else driverEyeAnchor.reset();
 // Keep the native animated head/body attachment in occupied seats.

 if(vrMount){float eye=nativeEyeHeight.load();if(eye<1||eye>2.4f)eye=1.65f;memcpy(&orientation,&mountedBody.b,36);vrarm::V eyeLocal{0,eye,0};AcquireSRWLockShared(&eyeLock);if(eyePlayer==player&&finite(avatarEye))memcpy(&eyeLocal,&avatarEye,12);ReleaseSRWLockShared(&eyeLock);// Use the same fixed entry scaffold as the visible mounted torso/head.
 float mountedEye[3]{};if(RFGRVR_Arms_EyeLocal(player,mountedEye)&&finite(*(vrarm::V*)mountedEye))memcpy(&eyeLocal,mountedEye,12);auto point=vrarm::add(mountedBody.p,vrarm::world(mountedBody.b,eyeLocal));memcpy(&head,&point,12);}

 if(state==9&&RFGRVRNativeVehicle::thirdPerson()){void* vehicle=RFGRVRNativeVehicle::mountedVehicle(player);if(vehicle){vrarm::Pose car{};memcpy(&car.p,(char*)vehicle+4,12);memcpy(&car.b,(char*)vehicle+0x10,36);if(vrarm::valid(car.b)){float yaw=atan2f(car.b.f.x,car.b.f.z),c=cosf(yaw),s=sinf(yaw);car.b={{c,0,-s},{0,1,0},{s,0,c}};auto p=vrarm::add(car.p,vrarm::world(car.b,{0,3.5f,-6.f}));memcpy(&head,&p,12);memcpy(&orientation,&car.b,36);}}}
 if(state>=7&&state<=10){vrarm::V adjusted=RFGRVR_SeatHeightOffset({head.x,head.y,head.z},*(vrarm::M*)&orientation,RFGRVRNativeVehicle::eyeHeight.load());memcpy(&head,&adjusted,12);}
 if(!finite(head)||!finite(orientation.forward)){++failed;return;}
 float height=calibratedHeight.load();unsigned stance=0;memcpy(&stance,(char*)player+0x2fc,4);
 if(heightPlayer!=player){heightPlayer=player;nativeEyeHeight=0;}
 if(state==0&&!rag&&!stance){float root=0;memcpy(&root,(char*)player+8,4);float natural=head.y-root;
 if(!nativeEyeHeight.load()&&natural>=1&&natural<=2.4f)nativeEyeHeight=natural;
 float reference=nativeEyeHeight.load();if(reference>=1&&height>=1&&height<=2.4f)head.y=root+reference-riseCm.load()/100.f;}

 float d=vrMount?0:distanceCm.load()/100.f;
 head.x+=d*orientation.forward.x;
 float rise=vrMount?0:riseCm.load()/100.f;head.y+=d*orientation.forward.y;
 if(state>=7&&state<=10){head.x+=rise*orientation.up.x;head.y+=rise*orientation.up.y;head.z+=rise*orientation.up.z;}else head.y+=rise;
 head.z+=d*orientation.forward.z;
 if(!finite(head))return;
 positionSeq.fetch_add(1,std::memory_order_acq_rel);
 tracked=head;memcpy(&sampledBodyPosition,(char*)player+4,12);memcpy(&sampledBodyBasis,(char*)player+0x10,36);memcpy(&sampledBodyCharacter,(char*)player+0x32c,4);if(vrMount){memcpy(&sampledBodyPosition,&mountedBody.p,12);memcpy(&sampledBodyBasis,&mountedBody.b,36);}playerState=state;playerStance=stance;
 parented=(rag!=0&&rag!=3)||state==1||state==2||state==4||state==3||state==5||state==6||(state>=7&&state<=10)||state==15;
 parentOrientation=orientation;
 if(!vrMount&&(state==1||state==2||(state>=7&&state<=10)))memcpy(&parentOrientation,(char*)player+0x10,36);
 positionSeq.fetch_add(1,std::memory_order_release);
 ++headReads;
 lastHeadTick.store(GetTickCount64(),std::memory_order_release);
}
}
extern "C" void RFGRVR_HeadCam_RefreshArms(){
 if(active.load()&&lastPlayer&&GetTickCount64()-lastHeadTick.load()<250)RFGRVR_Arms_Player(lastPlayer);
}
static void eyeSettingsPath(char (&path)[MAX_PATH]){
 path[0]=0;if(!GetModuleFileNameA(nullptr,path,MAX_PATH))return;char* slash=strrchr(path,'\\');if(!slash){path[0]=0;return;}
 strcpy_s(slash+1,MAX_PATH-(slash+1-path),"RFGRVR-eye-offset.ini");
}
extern "C" void RFGRVR_HeadCam_AdjustEye(int up,int forward){
 bool foot=heightPlayer.load()&&RFGRVRNativeTurret::word(heightPlayer.load(),0x2f4)<=2;auto& vertical=foot?onFootEyeUpCm:eyeUpCm;int y=vertical.load()+up,z=eyeForwardCm.load()+forward;if(y>50)y=50;if(y< -50)y=-50;if(z>50)z=50;if(z< -50)z=-50;vertical=y;eyeForwardCm=z;
 char path[MAX_PATH]{},value[32]{};eyeSettingsPath(path);if(!path[0])return;
 sprintf_s(value,"%d",y);WritePrivateProfileStringA("EyeOffset",foot?"OnFootUpCm":"UpCm",value,path);sprintf_s(value,"%d",z);WritePrivateProfileStringA("EyeOffset","ForwardCm",value,path);
}
// Manual defaults are offsets on the original single-pose setup; no rig fitting.
extern "C" void RFGRVR_HeadCam_AdjustFootEye(int up,int forward){
 int y=(std::clamp)(onFootEyeUpCm.load()+up,-50,50),z=(std::clamp)(onFootEyeForwardCm.load()+forward,-50,50);onFootEyeUpCm=y;onFootEyeForwardCm=z;
 char path[MAX_PATH]{},value[32]{},message[128]{};eyeSettingsPath(path);if(path[0]){sprintf_s(value,"%d",y);WritePrivateProfileStringA("EyeOffset","OnFootUpCm",value,path);sprintf_s(value,"%d",z);WritePrivateProfileStringA("EyeOffset","OnFootForwardCm",value,path);}sprintf_s(message,"Eye defaults: height %+d cm, forward %+d cm",y,z);vrstatus::notify(message);
}
extern "C" void RFGRVR_HeadCam_AdjustWorld(int direction){
 int percent=(std::clamp)(worldAppearancePercent.load()+direction*2,60,160);worldAppearancePercent=percent;char path[MAX_PATH]{},value[32]{},message[96]{};eyeSettingsPath(path);sprintf_s(value,"%d",percent);if(path[0])WritePrivateProfileStringA("WorldScale","AppearancePercent",value,path);sprintf_s(message,"World scale default: %d%%",percent);vrstatus::notify(message);
}
extern "C" bool RFGRVR_HeadCam_Install(){
 if(sizeof(void*)!=4)return false;
 char eyePath[MAX_PATH]{};eyeSettingsPath(eyePath);int up=GetPrivateProfileIntA("EyeOffset","UpCm",0,eyePath),forward=GetPrivateProfileIntA("EyeOffset","ForwardCm",5,eyePath);if(up>=-50&&up<=50)eyeUpCm=up;if(forward>=-50&&forward<=50)eyeForwardCm=forward;
 worldAppearancePercent=(std::clamp)(int(GetPrivateProfileIntA("WorldScale","AppearancePercent",100,eyePath)),60,160);onFootEyeForwardCm=(std::clamp)(int(GetPrivateProfileIntA("EyeOffset","OnFootForwardCm",0,eyePath)),-50,50);int reference=GetPrivateProfileIntA("WorldScale","PlayerReferencePercent",0,eyePath);if(reference<60||reference>160){reference=worldAppearancePercent.load();char value[24];sprintf_s(value,"%d",reference);WritePrivateProfileStringA("WorldScale","PlayerReferencePercent",value,eyePath);}playerReferencePercent=reference;
 int footUp=GetPrivateProfileIntA("EyeOffset","OnFootUpCm",0,eyePath);if(footUp>=-50&&footUp<=50)onFootEyeUpCm=footUp;
 auto exe=(unsigned char*)GetModuleHandleW(nullptr);if(!exe)return false;
 auto dos=(IMAGE_DOS_HEADER*)exe;if(dos->e_magic!=IMAGE_DOS_SIGNATURE)return false;
 auto nt=(IMAGE_NT_HEADERS32*)(exe+dos->e_lfanew);
 if(nt->Signature!=IMAGE_NT_SIGNATURE||nt->OptionalHeader.SizeOfImage<PLAYER_FRAME_RVA+16)return false;
 if(memcmp(exe+PLAYER_FRAME_RVA,playerSig,sizeof(playerSig)) || memcmp(exe+HEAD_POS_RVA,headSig,sizeof(headSig)))return false;
 // Executable RVA points to the 4-byte relocated absolute camera address.
 uint32_t absolute=0;memcpy(&absolute,exe+GLOBAL_CAMERA_REF_RVA,sizeof(absolute));
 if(absolute<0x10000)return false;
 cameraGlobal=(unsigned char*)(uintptr_t)absolute;
 if(!inRegion(cameraGlobal,0xa30,true))return false;
 V3 pos{};memcpy(&pos,cameraGlobal+REAL_POS_OFFSET,sizeof(pos));
 if(!finite(pos))return false;
 const unsigned char placementSig[]={0x55,0x8b,0xec,0x83,0xe4,0xf8,0xb8,0x14,0x15,0,0};
 if(!memcmp(exe+0x6819d0,placementSig,sizeof(placementSig)))findPlacement=(PlaceFn)(exe+0x6819d0);
 headFunction=(HeadFn)(exe+HEAD_POS_RVA);turretLookup=(TurretLookup)(exe+0x53c050);turretRegistry=exe+0x2b98490;
 const unsigned char cullingSig[]={0x56,0x8b,0xf1,0x80,0xbe,0x08,0x08,0,0,0};
 if(memcmp(exe+0x2d4c40,cullingSig,sizeof(cullingSig)))return false;
 if(MH_CreateHook(exe+0x2d4c40,(LPVOID)&OnCulling,(LPVOID*)&originalCulling)!=MH_OK||MH_EnableHook(exe+0x2d4c40)!=MH_OK)return false;
 MH_STATUS status=MH_CreateHook(exe+PLAYER_FRAME_RVA,(LPVOID)&PlayerFrame,(LPVOID*)&originalFrame);
 if(status!=MH_OK)return false;
 if(MH_EnableHook(exe+PLAYER_FRAME_RVA)!=MH_OK){MH_RemoveHook(exe+PLAYER_FRAME_RVA);return false;}
 const bool turretInstalled=RFGRVRNativeTurret::install(exe);
 {wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Turret-Direct.log");FILE* f=nullptr;if(!_wfopen_s(&f,path,L"a")&&f){fprintf(f,"Direct joint hooks installed=%d; native control RVA642040/643150/643560, weapon handle +E8\n",turretInstalled?1:0);fclose(f);}}}
 if(!turretInstalled)OutputDebugStringA("RFGR VR turret direct joint hooks unavailable\n");
 if(!RFGRVRPauseSettings::install(exe))OutputDebugStringA("Native pause VR Settings insertion unavailable\n");
 ready.store(true);return true;
}
extern "C" void RFGRVR_HeadCam_Enable(bool on){active.store(on && ready.load());}
extern "C" bool RFGRVR_HeadCam_Enabled(){return active.load();}
extern "C" bool RFGRVR_HeadCam_Ready(){return ready.load();}
extern "C" void RFGRVR_HeadCam_Forward(int step){int v=distanceCm.load()+step;if(v>100)v=100;if(v<-100)v=-100;distanceCm.store(v);}
extern "C" void RFGRVR_HeadCam_Height(int step){int v=riseCm.load()+step;if(v>100)v=100;if(v<-100)v=-100;riseCm.store(v);}
extern "C" int RFGRVR_HeadCam_ForwardValue(){return distanceCm.load();}
extern "C" int RFGRVR_HeadCam_HeightValue(){return riseCm.load();}
extern "C" unsigned RFGRVR_HeadCam_Updates(){return positionWrites.load();}
extern "C" unsigned RFGRVR_HeadCam_Failures(){return failed.load();}
extern "C" unsigned RFGRVR_HeadCam_HeadSamples(){return headReads.load();}
static unsigned nativeCinematicGameState(){auto* exe=(unsigned char*)GetModuleHandleW(nullptr);if(!exe||!inRegion(exe+0x125cbcc,4,false))return ~0u;int index=0;memcpy(&index,exe+0x125cbcc,4);if(index<0||index>63||!inRegion(exe+0x2132be8+index*4,4,false))return ~0u;unsigned state=~0u;do{if(!inRegion(exe+0x2132be8+index*4,4,false))return ~0u;memcpy(&state,exe+0x2132be8+index*4,4);if(state!=0x3e||index==0)break;--index;}while(index>=0);return state;}
static unsigned (*cinematicGameState)()=nativeCinematicGameState;
static unsigned nativeRootGameState(){auto* exe=(unsigned char*)GetModuleHandleW(nullptr);unsigned value=~0u;if(exe&&inRegion(exe+0x2132be8,4,false))memcpy(&value,exe+0x2132be8,4);return value;}
extern "C" bool RFGRVR_HeadCam_MenuScene(){unsigned mode=~0u;if(!active.load()||!ready.load()||!inRegion(cameraGlobal,116,false))return false;memcpy(&mode,cameraGlobal,4);return RFGRVR_MainMenuEligible(mode,cinematicGameState(),nativeRootGameState());}
static unsigned nativeOverlayGameState(){auto* exe=(unsigned char*)GetModuleHandleW(nullptr);int index=-1;if(exe&&inRegion(exe+0x125cbcc,4,false))memcpy(&index,exe+0x125cbcc,4);unsigned raw=~0u;if(index>=0&&index<=63&&inRegion(exe+0x2132be8+index*4,4,false))memcpy(&raw,exe+0x2132be8+index*4,4);return raw==0x3e?raw:cinematicGameState();}
static unsigned nativePauseDepth(){
#ifdef RFGR_TEST_USER_SETTINGS
 return 0;
#else
 auto* exe=(unsigned char*)GetModuleHandleW(nullptr);auto* code=exe+0x3c1690;
 // Native game_is_paused: mov eax,[counter]; test eax,eax; setg al; ret.
 if(!inRegion(code,11,false))return 0;uintptr_t address=RFGRVR_PauseCounterAddress(code,(uintptr_t)exe);if(!address||!inRegion((void*)address,4,false))return 0;
 unsigned depth=0;memcpy(&depth,(void*)(uintptr_t)address,4);return depth;
#endif
}
extern "C" bool RFGRVR_HeadCam_PopupMenu(){const auto state=nativeOverlayGameState();unsigned cameraMode=~0u;if(inRegion(cameraGlobal,4,false))memcpy(&cameraMode,cameraGlobal,4);if(!active.load()||!ready.load()||!lastPlayer||!lastHeadTick.load()||RFGRVR_HeadCam_MenuScene()||!(RFGRVR_PopupMenuEligible(state,nativeRootGameState())||RFGRVR_BlockingNotificationEligible(cameraMode,state,nativeRootGameState(),nativePauseDepth())))return false;auto* exe=(unsigned char*)GetModuleHandleW(nullptr);void* current=nullptr;if(!inRegion(exe+0x2c23874,4,false))return false;memcpy(&current,exe+0x2c23874,4);return (current==lastPlayer||state==0x10)&&inRegion(lastPlayer,0x330,false);}
extern "C" bool RFGRVR_HeadCam_MapMenu(){return nativeOverlayGameState()==0x25&&RFGRVR_HeadCam_PopupMenu();}
// Verified MENU_PAUSE popup handle: constructed at517E90, destroyed at518A70.
// Locker/store use other popup owners and must not expose VR Settings.
extern "C" bool RFGRVR_HeadCam_PauseMenu(){if(!RFGRVR_HeadCam_PopupMenu())return false;auto* exe=(unsigned char*)GetModuleHandleW(nullptr);unsigned address=0;if(!inRegion(exe+0x518a70,12,false)||exe[0x518a70]!=0xa1||exe[0x518a75]!=0x83||exe[0x518a76]!=0xf8||exe[0x518a77]!=0xff)return false;memcpy(&address,exe+0x518a71,4);if(address!=(unsigned)(uintptr_t)(exe+0x1264108)||!inRegion((void*)(uintptr_t)address,4,false))return false;unsigned handle=~0u;memcpy(&handle,(void*)(uintptr_t)address,4);return handle!=~0u;}
extern "C" bool RFGRVR_HeadCam_Cinematic(){unsigned mode=~0u;if(!active.load()||!ready.load()||!inRegion(cameraGlobal,116,false))return false;memcpy(&mode,cameraGlobal,4);return RFGRVR_CinematicEligible(mode,cinematicGameState())||RFGRVR_MainMenuEligible(mode,cinematicGameState(),nativeRootGameState());}
extern "C" bool RFGRVR_HeadCam_Recent(){
 const auto tick=lastHeadTick.load(std::memory_order_acquire);
 return RFGRVR_HeadCam_Cinematic()||(tick!=0 && GetTickCount64()-tick<350);
}
extern "C" void RFGRVR_HeadCam_Apply(){
 if(!active.load()||!ready.load()||!cameraGlobal||!headReads.load()||RFGRVR_HeadCam_Cinematic()||(playerState>=7&&playerState<=10&&!vrsettings::get().value[vrsettings::Vehicles]))return;
 V3 pos{};bool stable=false;
 for(int i=0;i<3;i++){
  long s1=positionSeq.load(std::memory_order_acquire);if(s1&1)continue;
  pos=tracked;
  long s2=positionSeq.load(std::memory_order_acquire);
  if(s1==s2){stable=true;break;}
 }
 if(!stable||!finite(pos)||!inRegion(cameraGlobal+REAL_POS_OFFSET,sizeof(pos),true)){++failed;return;}
 memcpy(cameraGlobal+REAL_POS_OFFSET,&pos,sizeof(pos));
 ++positionWrites;
}

// v7.5.6: render-thread snapshot; NO write to the unrelated global camera slot.
// The caller supplies the verified render_begin camera pointer.
extern "C" bool RFGRVR_Arms_RagdollHead(void*,vrarm::Pose*);
extern "C" bool RFGRVR_HeadCam_GetFrame(float out[3],float parentOut[9],bool* attachedOut,unsigned* stateOut,float* floorEyeOut=nullptr){vrmemory::Scope memoryScope;if(auto* settings=vrsettings::bus())if(LONG request=InterlockedExchange(&settings->eyeElevationRequest,0))onFootEyeUpCm=(std::clamp)(int(request-1000),-50,50);
 if(out&&RFGRVR_HeadCam_Cinematic()){V3 p{};M3 b{};memcpy(&p,cameraGlobal+44,12);memcpy(&b,cameraGlobal+80,36);if(!finite(p)||!vrarm::valid(*(vrarm::M*)&b))return false;memcpy(out,&p,12);if(parentOut)memcpy(parentOut,&b,36);if(attachedOut)*attachedOut=true;if(stateOut)*stateOut=RFGRVR_HeadCam_MenuScene()?0x101:0x100;if(floorEyeOut)*floorEyeOut=RFGRVR_HeadCam_MenuScene()?0.f:-1.f;return true;}
 if(!out||!active.load(std::memory_order_acquire)||!ready.load(std::memory_order_acquire)||(!RFGRVR_HeadCam_Recent()&&!RFGRVR_HeadCam_PopupMenu()))return false;
 vrarm::Pose ragHead{};if(RFGRVR_Arms_RagdollHead(heightPlayer.load(),&ragHead)){memcpy(out,&ragHead.p,12);if(parentOut)memcpy(parentOut,&ragHead.b,36);if(attachedOut)*attachedOut=true;if(stateOut)*stateOut=0x103;if(floorEyeOut)*floorEyeOut=-1;return true;}
 V3 pos{},sourcePosition{};M3 sourceBasis{},parentBasis{};void* character=nullptr;bool attached=false;unsigned state=0,stance=0;bool stable=false;
 for(int i=0;i<3;i++){
  const long a=positionSeq.load(std::memory_order_acquire);
  if(a&1)continue;
  pos=tracked;sourcePosition=sampledBodyPosition;sourceBasis=sampledBodyBasis;parentBasis=parentOrientation;character=sampledBodyCharacter;attached=parented;state=playerState;stance=playerStance;
  const long b=positionSeq.load(std::memory_order_acquire);
  if(a==b){stable=true;break;}
 }
 if(!stable||!finite(pos))return false;
 if(state>=7&&state<=10&&!vrsettings::get().value[vrsettings::Vehicles]){V3 native{};M3 b{};memcpy(&native,cameraGlobal+44,12);memcpy(&b,cameraGlobal+80,36);if(!finite(native)||!vrarm::valid(*(vrarm::M*)&b))return false;float yaw=atan2f(b.forward.x,b.forward.z),c=cosf(yaw),s=sinf(yaw);M3 upright{{c,0,-s},{0,1,0},{s,0,c}};memcpy(out,&native,12);if(parentOut)memcpy(parentOut,&upright,36);if(attachedOut)*attachedOut=true;if(stateOut)*stateOut=state;if(floorEyeOut)*floorEyeOut=0;return true;}

 V3 roomRoot=sourcePosition;
 const float forwardCm=eyeForwardCm.load()+(state<=2?onFootEyeForwardCm.load():0);V3 eye{};bool anatomical=false;AcquireSRWLockShared(&eyeLock);if(eyePlayer==heightPlayer){eye=avatarEye;eye.z+=forwardCm/100.f;anatomical=eye.y>=1&&eye.y<=2.4f;}ReleaseSRWLockShared(&eyeLock);
 V3 standingEye=eye;float animatedLocal[3]{};bool localReady=false;
 if(state<=2)localReady=RFGRVR_Arms_EyeLocal(heightPlayer.load(),animatedLocal);
 LARGE_INTEGER eyeClock{},eyeFrequency{};QueryPerformanceCounter(&eyeClock);QueryPerformanceFrequency(&eyeFrequency);
 float eyeDt=crouchEyeClock.QuadPart?float(double(eyeClock.QuadPart-crouchEyeClock.QuadPart)/eyeFrequency.QuadPart):0;crouchEyeClock=eyeClock;
 if(crouchEyePlayer!=heightPlayer.load()){crouchEyePlayer=heightPlayer.load();crouchEyeBlend={};landingEye={};animationRecovery=false;animationReferenceValid=false;trackedCrouchEye=false;}
 float restEye[3]{};if(state<=2&&RFGRVR_Arms_EyeReference(heightPlayer.load(),restEye)){memcpy(&animationReference,restEye,12);animationReferenceValid=true;}
 V3 eyeReference=animationReferenceValid?animationReference:V3{standingEye.x,standingEye.y,standingEye.z-forwardCm/100.f};
 const bool physicalDuck=RFGRVR_PhysicalCrouchView()&&vrsettings::get().value[vrsettings::Crouch]==0;if(physicalDuck&&state==0)trackedCrouchEye=true;
 if(trackedCrouchEye&&!physicalDuck&&stance==0)trackedCrouchEye=false;
 float crouchWeight=crouchEyeBlend.update(!attached&&state==0&&floorCalibration.load()&&!RFGRVR_Arms_PhysicalCrouchBlend(),stance==1||stance==4,localReady?animatedLocal[1]-eyeReference.y:0,eyeDt);
 const bool crouchEye=crouchWeight>0;
 const bool landingAttached=landingEye.update(state==1||state==2,state<=2,localReady?animatedLocal[1]-eyeReference.y:1.f,eyeDt);
 animationRecovery=landingAttached;
 const bool controllerAttached=(controllerAttachedMotion.load()||(bodyMoving.load()&&GetTickCount64()-locomotionTick.load()<250))&&state==0;
 // Locomotion follows the interpolated rigid root, never the walking head bone.
 const bool animatedEye=crouchEye||landingAttached;
 if(animatedEye&&localReady){float w=landingAttached?1:crouchWeight;eye={standingEye.x+(animatedLocal[0]-eyeReference.x)*w,standingEye.y+(animatedLocal[1]-eyeReference.y)*w,standingEye.z+(animatedLocal[2]-eyeReference.z)*w};anatomical=true;}
 // Grounded head X/Z comes from the SAME rendered pose as the body. Do
 // not add an independently calculated forward-lean translation afterward.
 if(!animatedEye&&state==0&&localReady&&animationReferenceValid){eye.x+=animatedLocal[0]-eyeReference.x;eye.z+=animatedLocal[2]-eyeReference.z;}
 // The animated path suppresses HMD center-height in temporal_stereo.
 // Carry the SAME calibrated player-scale floor correction here, otherwise
 // non-100% player scale jumps to the unscaled authored height in mid-air.
 if(animatedEye&&floorCalibration.load()){
  float nativeHeight=nativeEyeHeight.load(),calibrated=calibratedHeight.load();
  if(nativeHeight>=1&&nativeHeight<=2.4f&&calibrated>=1&&calibrated<=2.4f){
   float playerScale=RFGRVR_AdjustedWorldScale(RFGRVR_HeightScale(nativeHeight,calibrated),playerReferencePercent.load());
   eye.y+=RFGRVR_FloorEyeOffset(calibrated,nativeHeight,playerScale);
  }
 }
 float floorEye=!attached&&!animatedEye&&state<=2&&floorCalibration.load()?nativeEyeHeight.load():0;
 if(floorEye<1||floorEye>2.4f||calibratedHeight.load()<1)floorEye=0;
 const float eyeUp=((state>=7&&state<=10)?eyeUpCm.load():onFootEyeUpCm.load())/100.f;
 if(animatedEye&&anatomical){auto v=vrarm::world(*(vrarm::M*)&sourceBasis,{eye.x,eye.y,eye.z});pos={sourcePosition.x+v.x,sourcePosition.y+v.y,sourcePosition.z+v.z};}
 if(floorEye){if(anatomical){auto local=vrarm::world(*(vrarm::M*)&sourceBasis,{eye.x,0,eye.z});pos.x=sourcePosition.x+local.x;pos.z=sourcePosition.z+local.z;}pos.y=sourcePosition.y+floorEye;}
 if(!floorEye&&!(animatedEye&&anatomical)){auto v=vrarm::world(*(vrarm::M*)&sourceBasis,{0,0,(forwardCm-5)/100.f});pos.x+=v.x;pos.z+=v.z;}
 if(attached&&state>=7&&state<=10){pos.x+=eyeUp*sourceBasis.up.x;pos.y+=eyeUp*sourceBasis.up.y;pos.z+=eyeUp*sourceBasis.up.z;}else pos.y+=eyeUp;
 if(state==0&&stance==0&&anatomical&&!animatedEye&&!localReady){vrarm::Pose eyePose{{{1,0,0},{0,1,0},{0,0,1}},{eye.x,eye.y,eye.z}};vrarm::V pelvis{};AcquireSRWLockShared(&eyeLock);memcpy(&pelvis,&avatarPelvis,12);ReleaseSRWLockShared(&eyeLock);auto leaned=RFGRVR_LeanPose(eyePose,pelvis,forwardLean.load());auto offset=vrarm::world(*(vrarm::M*)&sourceBasis,vrarm::sub(leaned.p,eyePose.p));pos.x+=offset.x;pos.y+=offset.y;pos.z+=offset.z;}

 // On foot and in a seated vehicle, carry the sampled animation anchor
 // with the rendered character root. Ragdolls and interactions keep their
 // existing anchor. Both eye views cache this one position/orientation pair.
 if(((!attached&&state<=2)||state==1||state==2||((state>=7&&state<=10)&&!mountedTurret.load()))&&inRegion((char*)character+0x30,4,false)){
  void* entity=nullptr;memcpy(&entity,(char*)character+0x30,4);vrarm::Pose rendered{},verify{};
  if(inRegion((char*)entity+8,48,false)){
   memcpy(&rendered,(char*)entity+8,48);memcpy(&verify,(char*)entity+8,48);
   vrarm::Pose source{},anchor{};memcpy(&source.p,&sourcePosition,12);memcpy(&source.b,&sourceBasis,36);memcpy(&anchor.p,&pos,12);memcpy(&anchor.b,&parentBasis,36);
   void* currentCharacter=nullptr;void* owner=heightPlayer.load();unsigned currentState=0;
   if(inRegion((char*)owner+0x32c,4,false))memcpy(&currentCharacter,(char*)owner+0x32c,4);
   if(inRegion((char*)owner+0x2f4,4,false))memcpy(&currentState,(char*)owner+0x2f4,4);
   const bool ownedSeat=attached&&state>=7&&state<=10&&currentState==state&&currentCharacter==character;
   if(!memcmp(&rendered,&verify,48)&&RFGRVR_RenderAnchor(source,rendered,anchor,ownedSeat?32.f:2.f)){
    memcpy(&pos,&anchor.p,12);roomRoot={rendered.p.x,rendered.p.y,rendered.p.z};if(floorEye)pos.y=rendered.p.y+floorEye+eyeUp;if(attached)memcpy(&parentBasis,&anchor.b,36);
   }
  }
 }
 ObserveRoom(heightPlayer.load(),state,attached,roomRoot);
 out[0]=pos.x;out[1]=pos.y;out[2]=pos.z;
 if(parentOut)memcpy(parentOut,&parentBasis,36);if(attachedOut)*attachedOut=attached;if(stateOut)*stateOut=RFGRVR_HeadCam_PopupMenu()?0x102:state;if(floorEyeOut)*floorEyeOut=animatedEye?-1.f:floorEye;return true;
}
extern "C" bool RFGRVR_HeadCam_GetPosition(float out[3]){return RFGRVR_HeadCam_GetFrame(out,nullptr,nullptr,nullptr);}
extern "C" void RFGRVR_HeadCam_RecordApplied(){++positionWrites;}
extern "C" void RFGRVR_HeadCam_RecordRejected(){++failed;}

extern "C" bool RFGRVR_HeadCam_LandingRecovery(){return animationRecovery.load();}
extern "C" bool RFGRVR_HeadCam_ControllerMoving(){return controllerAttachedMotion.load()||(bodyMoving.load()&&GetTickCount64()-locomotionTick.load()<250);}
extern "C" void RFGRVR_HeadCam_Locomotion(bool moving,bool turning){bodyMoving=moving;bodyTurning=turning;locomotionTick=GetTickCount64();if(moving){bodyYaw=lastHeadYaw.load();bodyYawTick=GetTickCount64();}}
extern "C" void RFGRVR_HeadCam_SetBodyYaw(float yaw){
 if(!std::isfinite(yaw))return;lastHeadYaw=yaw;LARGE_INTEGER clock{},frequency{};QueryPerformanceCounter(&clock);QueryPerformanceFrequency(&frequency);
 float dt=headingClock.QuadPart?float(double(clock.QuadPart-headingClock.QuadPart)/frequency.QuadPart):0;headingClock=clock;
 bool fresh=GetTickCount64()-locomotionTick.load()<250;
 bodyYaw.store(bodyHeading.update(yaw,dt,fresh&&bodyMoving.load(),fresh&&bodyTurning.load()));bodyYawTick.store(GetTickCount64(),std::memory_order_release);
}
extern "C" bool RFGRVR_HeadCam_Parent(float out[9],unsigned* state){
 if(!out||!state||(!RFGRVR_HeadCam_Recent()&&!RFGRVR_HeadCam_PopupMenu()))return false;
 for(int i=0;i<3;++i){long a=positionSeq.load(std::memory_order_acquire);if(a&1)continue;
 M3 basis=parentOrientation;bool isParented=parented;unsigned st=playerState;
 if(a!=positionSeq.load(std::memory_order_acquire))continue;*state=st;if(!isParented)return false;memcpy(out,&basis,36);return true;}return false;
}
extern "C" unsigned RFGRVR_HeadCam_PlayerState(){
 if(!RFGRVR_HeadCam_Recent())return ~0u;
 for(int i=0;i<3;++i){long a=positionSeq.load(std::memory_order_acquire);if(a&1)continue;unsigned state=playerState;
  if(a==positionSeq.load(std::memory_order_acquire))return state;}
 return ~0u;
}

extern "C" void RFGRVR_HeadCam_RenderEnd(){
 if(!renderingPose||!cameraGlobal)return;
 if(renderFovOwned&&!auxiliaryRendering){TrackedCull next{};memcpy(&next.position,renderFields[2].written,12);memcpy(&next.basis,renderFields[3].written,36);next.fov=writtenRenderFov;next.tick=GetTickCount64();
  for(unsigned tries=0;tries<3;++tries){auto sequence=positionSeq.load();if(sequence&1)continue;V3 body=sampledBodyPosition;if(sequence==positionSeq.load()){next.body=body;break;}}
  AcquireSRWLockExclusive(&cullLock);next.revision=trackedCull.revision+1;trackedCull=next;ReleaseSRWLockExclusive(&cullLock);
 }
 if(cameraGlobal&&inRegion(cameraGlobal+0x808,1,true)){if(cameraGlobal[0x808])++frustumInvalidations;cameraGlobal[0x808]=0;}
 for(auto& field:renderFields){auto* target=cameraGlobal+field.offset;
 if(inRegion(target,field.bytes,true)&&!memcmp(target,field.written,field.bytes))memcpy(target,field.saved,field.bytes);}
 if(renderFovOwned&&inRegion(cameraGlobal+188,4,true)){float current=0;memcpy(&current,cameraGlobal+188,4);if(current==writtenRenderFov)memcpy(cameraGlobal+188,&savedRenderFov,4);}renderFovOwned=false;
 renderingPose=false;
}
extern "C" void RFGRVR_HeadCam_RenderBegin(const float position[3],const float basis[9]){
 if(!active.load()||!cameraGlobal||renderingPose)return;
 if(cameraGlobal&&inRegion(cameraGlobal+0x808,1,true)){if(cameraGlobal[0x808])++frustumInvalidations;cameraGlobal[0x808]=0;}
 bool cinematic=RFGRVR_HeadCam_Cinematic();RFGRVR_Arms_Cinematic(cinematic);if(cinematic)RestoreHead();else if(RFGRVR_HeadCam_IsLocalPlayer(lastPlayer)&&RFGRVR_HeadCam_Recent())HideHead(lastPlayer);
 for(auto& field:renderFields)if(!inRegion(cameraGlobal+field.offset,field.bytes,true))return;
 for(auto& field:renderFields){auto* target=cameraGlobal+field.offset;memcpy(field.saved,target,field.bytes);
 memcpy(field.written,field.bytes==12?(const void*)position:(const void*)basis,field.bytes);memcpy(target,field.written,field.bytes);}
 renderingPose=true;
}

extern "C" void RFGRVR_HeadCam_CalibratedHeight(float height){calibratedHeight.store(height);}
extern "C" void RFGRVR_HeadCam_FloorCalibration(bool valid){floorCalibration.store(valid);}
extern "C" void RFGRVR_HeadCam_RoomRequest(float wx,float wz,float rx,float rz){
 AcquireSRWLockExclusive(&roomLock);roomDrive.request(wx,wz,rx,rz,GetTickCount64());ReleaseSRWLockExclusive(&roomLock);
}
extern "C" bool RFGRVR_HeadCam_RoomAxes(float yaw,bool allowed,short* x,short* y){
 if(!x||!y)return false;++roomInputPolls;AcquireSRWLockExclusive(&roomLock);bool result=roomDrive.input(yaw,allowed,GetTickCount64(),*x,*y);ReleaseSRWLockExclusive(&roomLock);if(result)++roomInputDrives;return result;
}
extern "C" float RFGRVR_HeadCam_ViewYaw(){return lastHeadYaw.load();}
extern "C" void RFGRVR_HeadCam_RoomConsumed(float out[3]){
 AcquireSRWLockExclusive(&roomLock);out[0]=roomConsumed.x;out[1]=0;out[2]=roomConsumed.z;roomConsumed={};ReleaseSRWLockExclusive(&roomLock);
}

// Legacy WorldScale API remains the calibrated player/interaction scale.
extern "C" float RFGRVR_HeadCam_WorldScale(){float eye=nativeEyeHeight.load();if((eye<1||eye>2.4f)&&RFGRVR_HeadCam_MenuScene())eye=1.65f;return RFGRVR_AdjustedWorldScale(RFGRVR_HeightScale(eye,calibratedHeight.load()),playerReferencePercent.load());}
extern "C" float RFGRVR_HeadCam_SceneScale(){float eye=nativeEyeHeight.load();if((eye<1||eye>2.4f)&&RFGRVR_HeadCam_MenuScene())eye=1.65f;return RFGRVR_AdjustedWorldScale(RFGRVR_HeightScale(eye,calibratedHeight.load()),worldAppearancePercent.load());}


extern "C" void RFGRVR_HeadCam_AvatarEye(void* player,const float local[3]){
 if(!player||!local||player!=heightPlayer)return;V3 eye{local[0],local[1],local[2]};if(!finite(eye)||eye.y<1||eye.y>2.4f||fabsf(eye.x)>.3f||fabsf(eye.z)>.5f)return;
 AcquireSRWLockExclusive(&eyeLock);eyePlayer=player;avatarEye=eye;nativeEyeHeight=eye.y;ReleaseSRWLockExclusive(&eyeLock);
}

extern "C" void RFGRVR_HeadCam_RenderFov(float degrees){
 if(!renderingPose||!std::isfinite(degrees)||degrees<10||degrees>170||!inRegion(cameraGlobal+188,4,true))return;
 if(!renderFovOwned)memcpy(&savedRenderFov,cameraGlobal+188,4);writtenRenderFov=degrees;renderFovOwned=true;memcpy(cameraGlobal+188,&degrees,4);
 if(inRegion(cameraGlobal+0x808,1,true))cameraGlobal[0x808]=0;
}

extern "C" float RFGRVR_HeadCam_BodyYaw(){return bodyYaw.load();}

extern "C" bool RFGRVR_HeadCam_TurretMounted(){return active.load()&&RFGRVR_HeadCam_Recent()&&mountedTurret.load();}

extern "C" bool RFGRVR_HeadCam_TurretPivot(float out[3],unsigned* identity){
 if(!out||!identity||!RFGRVR_HeadCam_TurretMounted()||!lastPlayer||!turretLookup||!inRegion((char*)lastPlayer+0xa08,4,false))return false;
 unsigned handle=0;memcpy(&handle,(char*)lastPlayer+0xa08,4);void* turret=turretLookup(turretRegistry,handle);if(!inRegion(turret,0x164,false)||*((unsigned char*)turret+0x7e)!=6)return false;
 V3 pivot{};unsigned gunHandle=0;memcpy(&gunHandle,(char*)turret+0xe8,4);void* gun=turretLookup(turretRegistry,gunHandle);
 if(inRegion(gun,0x80,false)&&*((unsigned char*)gun+0x7e)==1&&*((unsigned char*)gun+0x7f)==7)memcpy(&pivot,(char*)gun+4,12);else memcpy(&pivot,(char*)turret+4,12);
 if(!finite(pivot))return false;memcpy(out,&pivot,12);*identity=handle;return true;
}

// The native turret resolves its weapon from full handle +E8, not adjacent memory.
extern "C" bool RFGRVR_HeadCam_TurretAngles(float* yaw,float* pitch){
 if(!yaw||!pitch||!RFGRVR_HeadCam_TurretMounted()||!lastPlayer||!turretLookup)return false;
 unsigned handle=0;memcpy(&handle,(char*)lastPlayer+0xa08,4);auto* turret=(char*)turretLookup(turretRegistry,handle);
 if(!inRegion(turret,0x164,false)||turret[0x7e]!=6)return false;unsigned gunHandle=0;memcpy(&gunHandle,turret+0xe8,4);void* gun=turretLookup(turretRegistry,gunHandle);
 if(!inRegion(gun,0x80,false)||*((unsigned char*)gun+0x7e)!=1||*((unsigned char*)gun+0x7f)!=7)return false;
 vrarm::M barrel{};memcpy(&barrel,(char*)gun+0x10,36);if(!vrarm::valid(barrel))return false;
 *yaw=atan2f(barrel.f.x,barrel.f.z);float y=barrel.f.y;if(y>1)y=1;if(y< -1)y=-1;*pitch=asinf(y);return std::isfinite(*yaw)&&std::isfinite(*pitch);
}

extern "C" bool RFGRVR_HeadCam_TurretRoom(float out[3]){if(!out||!RFGRVR_HeadCam_TurretMounted())return false;AcquireSRWLockShared(&RFGRVRNativeTurret::lock);bool ok=RFGRVRNativeTurret::rig.ready&&GetTickCount64()-RFGRVRNativeTurret::fresh<200;if(ok)memcpy(out,&RFGRVRNativeTurret::rig.roomOffset,12);ReleaseSRWLockShared(&RFGRVRNativeTurret::lock);return ok;}

extern "C" bool RFGRVR_HeadCam_TurretRenderRoot(void* player,vrarm::Pose* pose){bool ok=pose&&mountedTurret.load()&&RFGRVRNativeTurret::body(player,*pose);if(ok)alignSeatedTurretBody(player,RFGRVRNativeTurret::word(player,0x2f4),*pose);return ok;}

extern "C" bool RFGRVR_HeadCam_TurretGunPose(void* player,vrarm::Pose* pose,unsigned* id,bool* entering){
 if(!pose||!id||!entering||!RFGRVRNativeTurret::base||player!=RFGRVRNativeTurret::player())return false;
 using namespace RFGRVRNativeTurret;void* turret=lookup(base+0x2b98490,word(player,0xa08));if(!owned(turret))return false;
 unsigned handle=word(turret,0xe8);void* gun=lookup(base+0x2b98490,handle);if(!memory(gun,0x80)||*((unsigned char*)gun+0x7e)!=1||*((unsigned char*)gun+0x7f)!=7)return false;
 if(!gunRenderPose(gun,*pose))return false;
 AcquireSRWLockShared(&lock);*entering=rig.entering;ReleaseSRWLockShared(&lock);*id=handle;return true;
}

extern "C" bool RFGRVR_DriverTurretOwned(void* turret){return RFGRVRNativeTurret::base&&RFGRVRNativeVehicle::driverControlled(turret);}
extern "C" bool RFGRVR_VehicleFlamer(){return RFGRVRNativeVehicle::isFlamer();}
extern "C" void RFGRVR_VehicleControlsInput(float height,bool focus){RFGRVRNativeVehicle::heightAxis=height;RFGRVRNativeVehicle::focusButton=focus;RFGRVRNativeVehicle::inputTick=GetTickCount64();}
extern "C" void RFGRVR_VehicleView(const float p[3],const float b[9],const RFGRPose* tracked){if(RFGRVRNativeTurret::base)RFGRVRNativeVehicle::publishView(p,b,tracked);}

extern "C" void RFGRVR_HeadCam_MoveForward(float value){forwardMotion=std::isfinite(value)?value:0;}
extern "C" float RFGRVR_HeadCam_ForwardLean(){return forwardLean.load();}
extern "C" void RFGRVR_HeadCam_AvatarPelvis(const float p[3]){if(!p)return;V3 v{};memcpy(&v,p,12);if(!finite(v))return;AcquireSRWLockExclusive(&eyeLock);avatarPelvis=v;ReleaseSRWLockExclusive(&eyeLock);}

extern "C" float RFGRVR_HeadCam_VehicleHeight(){return RFGRVRNativeVehicle::eyeHeight.load();}

extern "C" void RFGRVR_VehicleDriverAxes(short* x,short*,short turn){if(x&&RFGRVRNativeVehicle::isMech()){RFGRVRMechInput::publish(turn);*x=0;}else RFGRVRMechInput::publish(0);}
extern "C" bool RFGRVR_SaveVehicleCalibration(){auto* p=RFGRVRNativeTurret::player();if(RFGRVRNativeTurret::word(p,0x2f4)!=9)return false;RFGRVRNativeVehicle::prepareHeight(RFGRVRNativeTurret::word(p,0xac4));RFGRVRNativeVehicle::heightDirty=true;RFGRVRNativeVehicle::saveHeight();return !RFGRVRNativeVehicle::heightDirty;}

extern "C" void RFGRVR_VehicleResetView(){RFGRVRNativeVehicle::resetRequested=true;}

extern "C" bool RFGRVR_APC_Input(const RFGRShared* source,bool foreground,bool menu){return RFGRVRAPC::input(source,foreground,menu);}

extern "C" bool RFGRVR_HeadCam_IsAuxiliary(){return auxiliaryRendering.load(std::memory_order_relaxed);}
extern "C" void RFGRVR_HeadCam_Auxiliary(bool active){auxiliaryRendering=active;}

extern "C" void RFGRVR_APC_Created(void* object){RFGRVRNativeVehicle::rememberCreatedAPC(object);}






#ifdef RFGR_TEST_USER_SETTINGS
static void* testLocalPlayer=nullptr;
extern "C" bool RFGRVR_HeadCam_IsLocalPlayer(void* player){return player&&player==testLocalPlayer;}
#else
extern "C" bool RFGRVR_HeadCam_IsLocalPlayer(void* player){auto* exe=(unsigned char*)GetModuleHandleW(nullptr);void* local=nullptr;if(!inRegion(exe+0x2c23874,4,false))return false;memcpy(&local,exe+0x2c23874,4);return player&&player==local;}
#endif
