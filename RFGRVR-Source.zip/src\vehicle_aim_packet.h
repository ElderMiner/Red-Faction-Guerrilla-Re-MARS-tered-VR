#pragma once
#include "vr_mapping.h"
#include <windows.h>
#include <cstring>
#include <algorithm>
#include "vr_arm_math.h"
struct RFGRVehicleAimPacket {unsigned magic=0x56414933;volatile LONG sequence=0;DWORD pid=0,tick=0;unsigned count=0;float target[2][3]{};unsigned bounds=0;float corners[2][4][3]{};unsigned heatValid=0;float heatPosition[3]{},heatOrientation[4]{};};
static constexpr wchar_t RFGR_VEHICLE_AIM[]=L"Local\\RFGRVR_VehicleAim_v3";
struct RFGRVehicleAimWriter{HANDLE map=nullptr;RFGRVehicleAimPacket* shared=nullptr;
 void publish(RFGRVehicleAimPacket value){if(!shared){if(!map)map=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(value),RFGR_VEHICLE_AIM);if(map)shared=(RFGRVehicleAimPacket*)RFGRVR_MapViewOrClose(map,FILE_MAP_ALL_ACCESS,0,0,sizeof(value));}if(!shared)return;value.pid=GetCurrentProcessId();value.tick=GetTickCount();InterlockedIncrement(&shared->sequence);MemoryBarrier();memcpy(&shared->pid,&value.pid,sizeof(value)-offsetof(RFGRVehicleAimPacket,pid));shared->magic=value.magic;MemoryBarrier();InterlockedIncrement(&shared->sequence);}
};
struct RFGRVehicleAimReader{HANDLE map=nullptr;const RFGRVehicleAimPacket* shared=nullptr;
 bool read(DWORD pid,RFGRVehicleAimPacket& out){if(!shared){if(!map)map=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_VEHICLE_AIM);if(map)shared=(const RFGRVehicleAimPacket*)RFGRVR_MapViewOrClose(map,FILE_MAP_READ,0,0,sizeof(out));}if(!shared)return false;for(unsigned i=0;i<3;++i){LONG seq=shared->sequence;if(seq&1)continue;MemoryBarrier();out=*shared;MemoryBarrier();if(seq==shared->sequence)return out.magic==0x56414933&&out.pid==pid&&DWORD(GetTickCount()-out.tick)<250&&out.count<=2;}return false;}
};

// One shared predicted world point for both eyes. Never smooth each eye's
// screen coordinates independently; that would change binocular depth.
struct RFGRVehicleAimPrediction {
 RFGRVehicleAimPacket previous{};float velocity[2][3]{};bool ready=false;
 bool update(RFGRVehicleAimPacket& sample,DWORD now){
  if(!sample.count||DWORD(now-sample.tick)>=250){ready=false;return false;}
  bool changed=!ready||sample.tick!=previous.tick;
  if(changed){DWORD dt=sample.tick-previous.tick;bool continuous=ready&&sample.pid==previous.pid&&sample.count==previous.count&&dt>0&&dt<=100;
   for(unsigned i=0;i<sample.count;++i)for(unsigned j=0;j<3;++j)velocity[i][j]=continuous?(sample.target[i][j]-previous.target[i][j])/float(dt):0;
   previous=sample;ready=true;
  }
  DWORD interval=25;float lead=float((std::min)(DWORD(now-sample.tick),interval));
  for(unsigned i=0;i<sample.count;++i){float distance2=0;for(unsigned j=0;j<3;++j)distance2+=velocity[i][j]*velocity[i][j]*lead*lead;
   // Ignore teleports and limit extrapolation to a short angular correction.
   if(distance2<100)for(unsigned j=0;j<3;++j)sample.target[i][j]+=velocity[i][j]*lead;
  }return true;
 }
};

inline void RFGRVR_MergeVehicleAimFrame(RFGRVehicleAimPacket& p,const float position[3],const vrarm::M& frame){
 if(p.count<2)return;using namespace vrarm;V origin{position[0],position[1],position[2]};auto rotate=[&](V v,bool inverse){return inverse?local(frame,v):world(frame,v);};
 V midpoint{};for(unsigned i=0;i<p.count;++i)midpoint=add(midpoint,{p.target[i][0],p.target[i][1],p.target[i][2]});midpoint=mul(midpoint,1.f/p.count);
 float loX=1e9f,loY=1e9f,hiX=-1e9f,hiY=-1e9f;bool bounds=false;
 for(unsigned i=0;i<p.count;++i)if(p.bounds&(1u<<i))for(unsigned c=0;c<4;++c){V local=rotate(sub({p.corners[i][c][0],p.corners[i][c][1],p.corners[i][c][2]},origin),true);if(!finite(local)||local.z>=-.1f)continue;float x=local.x/-local.z,y=local.y/-local.z;loX=(std::min)(loX,x);hiX=(std::max)(hiX,x);loY=(std::min)(loY,y);hiY=(std::max)(hiY,y);bounds=true;}
 memcpy(p.target[0],&midpoint,12);p.count=1;p.bounds=bounds?1:0;if(bounds)for(unsigned c=0;c<4;++c){V point=add(origin,rotate({((c&1)?hiX:loX)*100.f,((c&2)?hiY:loY)*100.f,-100.f},false));memcpy(p.corners[0][c],&point,12);}
}

inline void RFGRVR_MergeVehicleAim(RFGRVehicleAimPacket& p,const float position[3],const float orientation[4]){using namespace vrarm;V q{orientation[0],orientation[1],orientation[2]};auto r=[&](V v){return add(v,add(mul(cross(q,v),2*orientation[3]),mul(cross(q,cross(q,v)),2)));};RFGRVR_MergeVehicleAimFrame(p,position,M{r({1,0,0}),r({0,1,0}),r({0,0,1})});}
