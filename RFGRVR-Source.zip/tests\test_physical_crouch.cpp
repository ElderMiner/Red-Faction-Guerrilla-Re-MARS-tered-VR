#include "../src/vr_physical_crouch.h"
#include <cassert>
int main(){RFGRVRPhysicalCrouch threshold;for(int i=0;i<50;++i)assert(!threshold.update(1.33f,1.6f,.01f,true));RFGRVRPhysicalCrouch c;assert(!c.update(1.6f,1.6f,.01f,true));
 for(int i=0;i<50;++i)c.update(1.2f,1.6f,.01f,true);assert(c.held);
 for(int i=0;i<50;++i)c.update(1.4f,1.6f,.01f,true);assert(c.held);
 for(int i=0;i<50;++i)c.update(1.5f,1.6f,.01f,true);assert(!c.held);
 assert(c.update(1,1.6f,.01f,true)==false); // brief dip is filtered
 assert(!c.update(1,1.6f,.01f,false));assert(!c.held&&!c.ready);
 assert(!c.update(0,0,.01f,true));
}
