#pragma once
#include <cmath>
inline float RFGRVR_SmoothTurn(float axis,float seconds){
 if(!std::isfinite(axis)||!std::isfinite(seconds)||seconds<=0)return 0;
 float magnitude=std::fabs(axis);if(magnitude<=.2f)return 0;if(magnitude>1)magnitude=1;
 if(seconds>.05f)seconds=.05f;return (axis<0?-1.f:1.f)*(magnitude-.2f)/.8f*75.f*seconds;
}
inline void RFGRVR_ParentBasis(const float original[3][3],const float current[3][3],const float world[3][3],float out[3][3]){
 for(int row=0;row<3;++row){float local[3]{};
 for(int i=0;i<3;++i)for(int j=0;j<3;++j)local[i]+=world[row][j]*original[i][j];
 for(int j=0;j<3;++j){out[row][j]=0;for(int i=0;i<3;++i)out[row][j]+=local[i]*current[i][j];}}
}

inline void RFGRVR_UprightBasis(const float source[3][3],float out[3][3]){float yaw=atan2f(source[2][0],source[2][2]),c=cosf(yaw),s=sinf(yaw);float upright[3][3]={{c,0,-s},{0,1,0},{s,0,c}};for(int i=0;i<3;++i)for(int j=0;j<3;++j)out[i][j]=upright[i][j];}
