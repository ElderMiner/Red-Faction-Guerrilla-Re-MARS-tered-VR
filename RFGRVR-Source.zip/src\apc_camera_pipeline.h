#pragma once
#include "vr_eye_pipeline.h"
// Camera passes may use compute/postprocess UAVs as well as graphics bindings.
struct RFGRAPCCameraPipeline:RFGRVREyePipeline {
 RFGRVRShaderBindings<ID3D11ComputeShader> cs;
 RFGRVRBindings<ID3D11UnorderedAccessView,8> computeOutputs,pixelOutputs;
 void save(ID3D11DeviceContext* c){
  RFGRVREyePipeline::save(c);c->CSGetShader(&cs.shader,cs.classes.p,&cs.count);
  c->CSGetConstantBuffers(0,14,cs.buffers.p);c->CSGetShaderResources(0,128,cs.resources.p);c->CSGetSamplers(0,16,cs.samplers.p);
  c->CSGetUnorderedAccessViews(0,8,computeOutputs.p);c->OMGetRenderTargetsAndUnorderedAccessViews(0,nullptr,nullptr,0,8,pixelOutputs.p);
 }
 void restore(ID3D11DeviceContext* c){
  ID3D11UnorderedAccessView* empty[8]{};ID3D11ShaderResourceView* resources[128]{};UINT counts[8];for(auto& n:counts)n=~0u;
  // Release auxiliary outputs before restoring input resources, preventing
  // D3D hazard handling from silently removing a restored binding.
  c->OMSetRenderTargetsAndUnorderedAccessViews(0,nullptr,nullptr,0,8,empty,counts);
  c->CSSetUnorderedAccessViews(0,8,empty,counts);c->CSSetShaderResources(0,128,resources);
  RFGRVREyePipeline::restore(c);unsigned n=0;for(unsigned i=0;i<8;++i)if(targets.p[i])n=i+1;
  if(n<8)c->OMSetRenderTargetsAndUnorderedAccessViews(n,targets.p,depth.Get(),n,8-n,pixelOutputs.p+n,counts+n);
  c->CSSetShader(cs.shader.Get(),cs.classes.p,cs.count);c->CSSetConstantBuffers(0,14,cs.buffers.p);
  c->CSSetShaderResources(0,128,cs.resources.p);c->CSSetSamplers(0,16,cs.samplers.p);c->CSSetUnorderedAccessViews(0,8,computeOutputs.p,counts);
 }
};
