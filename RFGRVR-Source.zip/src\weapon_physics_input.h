#include "vr_user_settings.h"
#pragma once
#include "ipc.h"
#include <atomic>
namespace RFGRVRWeaponInput {
inline std::atomic<RFGRShared*> source{nullptr};inline std::atomic<bool> reloadControlled{false},manualReloadEnabled{false};inline std::atomic<DWORD> reloadLease{0};inline std::atomic<bool> throwControlled{false},sledgeControlled{false};inline std::atomic<DWORD> lease{0};
inline std::atomic<bool> nativePropane{false},c4Controlled{false};
inline std::atomic<ULONGLONG> propaneRestoreUntil{0};
inline bool restoringWeapon(){return GetTickCount64()<propaneRestoreUntil.load();}
inline std::atomic<bool> propaneHeld{false};inline std::atomic<DWORD> propaneTick{0};
inline bool carrying(){return propaneHeld.load()&&DWORD(GetTickCount()-propaneTick.load())<150;}
inline bool fresh(){DWORD tick=lease.load(std::memory_order_acquire);return throwControlled.load(std::memory_order_relaxed)&&tick&&DWORD(GetTickCount()-tick)<100;}
inline void filterFocus(RFGRGamepad& pad,bool vr){if(vr)pad.buttons&=~0x80u;}
inline void filter(RFGRGamepad& pad,bool manualVR=false){if(restoringWeapon()){pad.rightTrigger=pad.leftTrigger=0;}if(carrying()&&!vrsettings::get().value[vrsettings::Throw]){pad.rightTrigger=pad.leftTrigger=0;pad.buttons&=~(0x4000u|0x200u);return;}if(fresh()&&c4Controlled.load()&&!(pad.buttons&0x200)&&pad.leftTrigger>100){pad.buttons|=0x2000u;pad.leftTrigger=0;}if(!(pad.buttons&0x200)){if(reloadControlled.load()||(manualVR&&manualReloadEnabled.load()))pad.buttons&=~0x4000u;if(reloadControlled.load())pad.leftTrigger=0;}if(fresh()){pad.rightTrigger=0;if(sledgeControlled.load()||nativePropane.load())pad.leftTrigger=0;if(nativePropane.load())pad.buttons&=~0x4000u;}}
inline bool trigger(float& value){auto* s=source.load();if(!s||s->version!=RFGR_PROTOCOL)return false;for(int i=0;i<3;++i){LONG seq=s->inputSequence;if(seq&1)continue;MemoryBarrier();bool active=s->gamepadActive!=0;auto v=s->gamepad.rightTrigger;MemoryBarrier();if(seq!=s->inputSequence)continue;value=float(v)/255.f;return active;}return false;}
}

