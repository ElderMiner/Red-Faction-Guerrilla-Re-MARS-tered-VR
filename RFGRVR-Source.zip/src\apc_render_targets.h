#include "main_menu_capture.h"
#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <atomic>
#include <vector>
#include <mutex>
#include <type_traits>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <cmath>
// Auxiliary views borrow the engine's render graph, but never its eye-sized
// writable textures. The original descriptors and native caches stay intact.
namespace RFGRAPCTargets {
template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
inline std::atomic<bool> active{false},failed{false};
inline unsigned baseWidth=0,baseHeight=0,width=0,height=0;
inline std::recursive_mutex guard;
inline Ptr<ID3D11Device> owner;
inline Ptr<ID3D11DepthStencilView> sceneDepth;inline std::atomic<bool> depthFound{false};
inline std::atomic<bool> collectingDepth{false};
inline uint64_t depthScore=0;inline D3D11_COMPARISON_FUNC depthCompare=D3D11_COMPARISON_LESS_EQUAL;inline float depthMin=0,depthMax=1;
struct DepthSource {Ptr<ID3D11DepthStencilView> view;uint64_t score=0;};inline std::vector<DepthSource> depthSources;
struct Texture {Ptr<ID3D11Resource> original;Ptr<ID3D11Texture2D> reduced;unsigned width,height;};
struct View {Ptr<ID3D11View> original;Ptr<ID3D11View> reduced;unsigned width,height;};
inline std::vector<Texture> textures;inline std::vector<View> views;
inline void configure(ID3D11Device* d,unsigned w,unsigned h){std::lock_guard<std::recursive_mutex> held(guard);if(owner.Get()!=d||baseWidth!=w||baseHeight!=h){views.clear();textures.clear();sceneDepth.Reset();depthFound=false;owner=d;baseWidth=w;baseHeight=h;}}
inline bool eligible(const D3D11_TEXTURE2D_DESC& d){
 if(!baseWidth||!baseHeight||d.ArraySize!=1||d.MipLevels!=1||d.SampleDesc.Count!=1||!(d.BindFlags&(D3D11_BIND_RENDER_TARGET|D3D11_BIND_DEPTH_STENCIL)))return false;
 for(unsigned div=1;div<=16;div*=2)if(d.Width==(std::max)(1u,baseWidth/div)&&d.Height==(std::max)(1u,baseHeight/div))return true;
 return false;
}
inline ID3D11Resource* resource(ID3D11Resource* r){
 if(!r||!active.load())return r;std::lock_guard<std::recursive_mutex> held(guard);
 for(auto& t:textures){if(t.reduced.Get()==r)return r;if(t.original.Get()==r&&t.width==width&&t.height==height)return t.reduced.Get();}
 Ptr<ID3D11Texture2D> source;if(FAILED(r->QueryInterface(IID_PPV_ARGS(&source))))return r;D3D11_TEXTURE2D_DESC d{};source->GetDesc(&d);if(!eligible(d))return r;
 if(textures.size()>=384){failed=true;return r;}
 d.Width=(std::max)(1u,unsigned((uint64_t(d.Width)*width+baseWidth-1)/baseWidth));d.Height=(std::max)(1u,unsigned((uint64_t(d.Height)*height+baseHeight-1)/baseHeight));d.MiscFlags=0;d.CPUAccessFlags=0;d.Usage=D3D11_USAGE_DEFAULT;
 Texture t{};t.original=r;t.width=width;t.height=height;if(!owner||FAILED(owner->CreateTexture2D(&d,nullptr,&t.reduced))){failed=true;return r;}textures.push_back(std::move(t));return textures.back().reduced.Get();
}
template<class T>inline T* view(T* v){
 if(!v||!active.load())return v;std::lock_guard<std::recursive_mutex> held(guard);
 for(auto& x:views){if(x.reduced.Get()==v)return v;if(x.original.Get()==v&&x.width==width&&x.height==height)return static_cast<T*>(x.reduced.Get());}
 Ptr<ID3D11Resource> original;v->GetResource(&original);auto* r=resource(original.Get());if(r==original.Get())return v;
 Ptr<T> replacement;HRESULT hr=E_FAIL;
 if constexpr(std::is_same_v<T,ID3D11RenderTargetView>){D3D11_RENDER_TARGET_VIEW_DESC d{};v->GetDesc(&d);hr=owner->CreateRenderTargetView(r,&d,&replacement);}
 if constexpr(std::is_same_v<T,ID3D11DepthStencilView>){D3D11_DEPTH_STENCIL_VIEW_DESC d{};v->GetDesc(&d);hr=owner->CreateDepthStencilView(r,&d,&replacement);}
 if constexpr(std::is_same_v<T,ID3D11UnorderedAccessView>){D3D11_UNORDERED_ACCESS_VIEW_DESC d{};v->GetDesc(&d);hr=owner->CreateUnorderedAccessView(r,&d,&replacement);}
 if constexpr(std::is_same_v<T,ID3D11ShaderResourceView>){D3D11_SHADER_RESOURCE_VIEW_DESC d{};v->GetDesc(&d);hr=owner->CreateShaderResourceView(r,&d,&replacement);}
 if(FAILED(hr)||views.size()>=768){failed=true;return nullptr;}View x{};x.original=v;x.reduced=replacement;x.width=width;x.height=height;views.push_back(std::move(x));return replacement.Get();
}
inline void observeDepth(ID3D11DepthStencilView* v){if(active.load()||!collectingDepth||!v||depthFound.load())return;Ptr<ID3D11Resource> r;v->GetResource(&r);Ptr<ID3D11Texture2D> t;if(FAILED(r.As(&t)))return;D3D11_TEXTURE2D_DESC d{};t->GetDesc(&d);if(d.Width==baseWidth&&d.Height==baseHeight&&d.SampleDesc.Count==1){std::lock_guard<std::recursive_mutex> held(guard);if(!sceneDepth){sceneDepth=v;depthFound=true;}}}
struct Hooks {ID3D11DeviceContext* context=nullptr;void** shadow=nullptr;void* old[115]{};bool color=false,depthDirty=true,geometryDepth=false,depthEnabled=true,depthWrite=true;Ptr<ID3D11DepthStencilView> depth;D3D11_COMPARISON_FUNC compare=D3D11_COMPARISON_LESS;float min=0,max=1,viewportWidth=0,viewportHeight=0;};
inline Hooks hooks[128]{};inline std::atomic<unsigned> hookCount{0};
inline Hooks* find(ID3D11DeviceContext* c){for(unsigned i=0;i<hookCount;++i)if(hooks[i].context==c&&hooks[i].shadow==*(void***)c)return &hooks[i];return nullptr;}
template<unsigned Slot,class... A>inline void call(ID3D11DeviceContext* c,A... a){if(auto* h=find(c))((void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,A...))h->old[Slot])(c,a...);}
inline void dirtyDepth(ID3D11DeviceContext* c){if(auto* h=find(c))h->depthDirty=true;}
inline void beginDepth(bool enabled){std::lock_guard<std::recursive_mutex> held(guard);collectingDepth=enabled;depthSources.clear();sceneDepth.Reset();depthFound=false;depthScore=0;depthCompare=D3D11_COMPARISON_LESS_EQUAL;depthMin=0;depthMax=1;if(!enabled)for(unsigned i=0;i<hookCount;++i){hooks[i].depth.Reset();hooks[i].geometryDepth=false;}}
inline void scoreDepth(ID3D11DepthStencilView* view,D3D11_COMPARISON_FUNC compare,float minimum,float maximum,uint64_t vertices){
 std::lock_guard<std::recursive_mutex> held(guard);if(!view||vertices<12)return;DepthSource* source=nullptr;for(auto& s:depthSources)if(s.view.Get()==view){source=&s;break;}if(!source){if(depthSources.size()>=16)return;depthSources.push_back({view,0});source=&depthSources.back();}source->score+=(std::min)(vertices,uint64_t(1000000));if(source->score>depthScore){depthScore=source->score;sceneDepth=view;depthFound=true;depthCompare=(compare==D3D11_COMPARISON_GREATER||compare==D3D11_COMPARISON_GREATER_EQUAL)?D3D11_COMPARISON_GREATER_EQUAL:D3D11_COMPARISON_LESS_EQUAL;depthMin=minimum;depthMax=maximum;}
}
inline void cacheDepth(ID3D11DeviceContext* c,ID3D11DepthStencilView* v){
 if(active||!collectingDepth)return;auto* h=find(c);if(!h)return;h->depth.Reset();h->geometryDepth=false;if(!v)return;Ptr<ID3D11Resource> r;v->GetResource(&r);Ptr<ID3D11Texture2D> t;if(FAILED(r.As(&t)))return;D3D11_TEXTURE2D_DESC d{};t->GetDesc(&d);if(d.Width==baseWidth&&d.Height==baseHeight&&d.SampleDesc.Count==1){h->depth=v;h->geometryDepth=true;}
}
inline void geometry(ID3D11DeviceContext* c,uint64_t vertices){
 if(active||!collectingDepth||vertices<12)return;auto* h=find(c);if(!h||!h->depth||!h->geometryDepth||!h->depthEnabled||!h->depthWrite||fabsf(h->viewportWidth-baseWidth)>1||fabsf(h->viewportHeight-baseHeight)>1)return;
 if(h->compare!=D3D11_COMPARISON_LESS&&h->compare!=D3D11_COMPARISON_LESS_EQUAL&&h->compare!=D3D11_COMPARISON_GREATER&&h->compare!=D3D11_COMPARISON_GREATER_EQUAL)return;
 scoreDepth(h->depth.Get(),h->compare,h->min,h->max,vertices);
}
inline void resetContextDepth(ID3D11DeviceContext* c){if(auto* h=find(c)){h->depth.Reset();h->color=false;h->geometryDepth=false;h->depthEnabled=h->depthWrite=true;h->compare=D3D11_COMPARISON_LESS;h->viewportWidth=h->viewportHeight=0;h->min=0;h->max=1;}}
inline void STDMETHODCALLTYPE clearState(ID3D11DeviceContext* c){resetContextDepth(c);call<110>(c);}
inline HRESULT STDMETHODCALLTYPE finish(ID3D11DeviceContext* c,BOOL restore,ID3D11CommandList** list){auto* h=find(c);if(!h)return E_FAIL;auto hr=((HRESULT(STDMETHODCALLTYPE*)(ID3D11DeviceContext*,BOOL,ID3D11CommandList**))h->old[114])(c,restore,list);if(!restore)resetContextDepth(c);return hr;}
inline void STDMETHODCALLTYPE depthState(ID3D11DeviceContext* c,ID3D11DepthStencilState* state,UINT stencil){if(!active&&collectingDepth)if(auto* h=find(c)){D3D11_DEPTH_STENCIL_DESC d{};d.DepthEnable=TRUE;d.DepthWriteMask=D3D11_DEPTH_WRITE_MASK_ALL;d.DepthFunc=D3D11_COMPARISON_LESS;if(state)state->GetDesc(&d);h->depthEnabled=d.DepthEnable!=FALSE;h->depthWrite=d.DepthWriteMask==D3D11_DEPTH_WRITE_MASK_ALL;h->compare=d.DepthFunc;}call<36>(c,state,stencil);}
inline void STDMETHODCALLTYPE om(ID3D11DeviceContext* c,UINT n,ID3D11RenderTargetView*const* v,ID3D11DepthStencilView* d){cacheDepth(c,d);observeDepth(d);if(!active){call<33>(c,n,v,d);return;}ID3D11RenderTargetView* out[8]{};for(unsigned i=0;i<n&&i<8;++i)out[i]=view(v?v[i]:nullptr);call<33>(c,n,(ID3D11RenderTargetView*const*)out,view(d));}
inline void STDMETHODCALLTYPE clearRT(ID3D11DeviceContext* c,ID3D11RenderTargetView* v,const FLOAT* color){call<50>(c,view(v),color);}
inline void STDMETHODCALLTYPE clearDS(ID3D11DeviceContext* c,ID3D11DepthStencilView* v,UINT flags,FLOAT z,UINT8 s){observeDepth(v);call<53>(c,view(v),flags,z,s);}
template<unsigned Slot>inline void STDMETHODCALLTYPE srv(ID3D11DeviceContext* c,UINT start,UINT n,ID3D11ShaderResourceView*const* v){if(!active){call<Slot>(c,start,n,v);return;}ID3D11ShaderResourceView* out[128]{};for(unsigned i=0;i<n&&i<128;++i)out[i]=view(v?v[i]:nullptr);call<Slot>(c,start,n,(ID3D11ShaderResourceView*const*)out);}
inline void STDMETHODCALLTYPE viewport(ID3D11DeviceContext* c,UINT n,const D3D11_VIEWPORT* p){if(!active&&collectingDepth&&p&&n)if(auto* h=find(c)){h->viewportWidth=p[0].Width;h->viewportHeight=p[0].Height;h->min=p[0].MinDepth;h->max=p[0].MaxDepth;}D3D11_VIEWPORT out[16]{};if(!active||!p){call<44>(c,n,p);return;}for(unsigned i=0;i<n&&i<16;++i){out[i]=p[i];bool screen=false;for(unsigned div=1;div<=16;div*=2)screen=screen||(fabsf(p[i].Width-float(baseWidth/div))<1&&fabsf(p[i].Height-float(baseHeight/div))<1);if(screen){out[i].TopLeftX*=float(width)/baseWidth;out[i].Width*=float(width)/baseWidth;out[i].TopLeftY*=float(height)/baseHeight;out[i].Height*=float(height)/baseHeight;}}call<44>(c,n,(const D3D11_VIEWPORT*)out);}
inline void STDMETHODCALLTYPE scissor(ID3D11DeviceContext* c,UINT n,const D3D11_RECT* p){D3D11_RECT out[16]{};if(!active||!p){call<45>(c,n,p);return;}for(unsigned i=0;i<n&&i<16;++i){out[i]=p[i];bool screen=false;for(unsigned div=1;div<=16;div*=2)screen=screen||(p[i].right-p[i].left==LONG(baseWidth/div)&&p[i].bottom-p[i].top==LONG(baseHeight/div));if(screen)out[i]={LONG(int64_t(p[i].left)*width/baseWidth),LONG(int64_t(p[i].top)*height/baseHeight),LONG(int64_t(p[i].right)*width/baseWidth),LONG(int64_t(p[i].bottom)*height/baseHeight)};}call<45>(c,n,(const D3D11_RECT*)out);}
inline void STDMETHODCALLTYPE copy(ID3D11DeviceContext* c,ID3D11Resource* dst,ID3D11Resource* src){auto* out=resource(dst);auto* in=resource(src);if(active&&(out!=dst||in!=src)){Ptr<ID3D11Texture2D> a,b;if(SUCCEEDED(out->QueryInterface(IID_PPV_ARGS(&a)))&&SUCCEEDED(in->QueryInterface(IID_PPV_ARGS(&b)))){D3D11_TEXTURE2D_DESC x{},y{};a->GetDesc(&x);b->GetDesc(&y);if(x.Width!=y.Width||x.Height!=y.Height){failed=true;return;}}}call<47>(c,out,in);}
inline void STDMETHODCALLTYPE region(ID3D11DeviceContext* c,ID3D11Resource* dst,UINT sub,UINT x,UINT y,UINT z,ID3D11Resource* src,UINT sourceSub,const D3D11_BOX* box){auto* out=resource(dst);auto* in=resource(src);D3D11_BOX b{};const D3D11_BOX* use=box;if(active&&out!=dst){x=UINT(uint64_t(x)*width/baseWidth);y=UINT(uint64_t(y)*height/baseHeight);}if(active&&in!=src&&box){b=*box;b.left=UINT(uint64_t(b.left)*width/baseWidth);b.right=UINT(uint64_t(b.right)*width/baseWidth);b.top=UINT(uint64_t(b.top)*height/baseHeight);b.bottom=UINT(uint64_t(b.bottom)*height/baseHeight);use=&b;}call<46>(c,out,sub,x,y,z,in,sourceSub,use);}
inline void STDMETHODCALLTYPE resolve(ID3D11DeviceContext* c,ID3D11Resource* dst,UINT ds,ID3D11Resource* src,UINT ss,DXGI_FORMAT f){call<57>(c,resource(dst),ds,resource(src),ss,f);}
inline void STDMETHODCALLTYPE uav(ID3D11DeviceContext* c,UINT start,UINT n,ID3D11UnorderedAccessView*const* v,const UINT* counts){if(!active){call<68>(c,start,n,v,counts);return;}ID3D11UnorderedAccessView* out[64]{};for(unsigned i=0;i<n&&i<64;++i)out[i]=view(v?v[i]:nullptr);call<68>(c,start,n,(ID3D11UnorderedAccessView*const*)out,counts);}
inline void STDMETHODCALLTYPE omUav(ID3D11DeviceContext* c,UINT n,ID3D11RenderTargetView*const* v,ID3D11DepthStencilView* d,UINT start,UINT u,ID3D11UnorderedAccessView*const* values,const UINT* counts){if(n!=D3D11_KEEP_RENDER_TARGETS_AND_DEPTH_STENCIL){cacheDepth(c,d);}observeDepth(d);if(!active){call<34>(c,n,v,d,start,u,values,counts);return;}ID3D11RenderTargetView* rtv[8]{};ID3D11UnorderedAccessView* out[64]{};if(n!=D3D11_KEEP_RENDER_TARGETS_AND_DEPTH_STENCIL)for(unsigned i=0;i<n&&i<8;++i)rtv[i]=view(v?v[i]:nullptr);if(u!=D3D11_KEEP_UNORDERED_ACCESS_VIEWS)for(unsigned i=0;i<u&&i<64;++i)out[i]=view(values?values[i]:nullptr);call<34>(c,n,n==D3D11_KEEP_RENDER_TARGETS_AND_DEPTH_STENCIL?v:(ID3D11RenderTargetView*const*)rtv,view(d),start,u,u==D3D11_KEEP_UNORDERED_ACCESS_VIEWS?values:(ID3D11UnorderedAccessView*const*)out,counts);}
inline void STDMETHODCALLTYPE clearUint(ID3D11DeviceContext* c,ID3D11UnorderedAccessView* v,const UINT* value){call<51>(c,view(v),value);}
inline void STDMETHODCALLTYPE clearFloat(ID3D11DeviceContext* c,ID3D11UnorderedAccessView* v,const FLOAT* value){call<52>(c,view(v),value);}
// Called only on our existing private context shadow tables, never D3D's vtable.
inline void attach(ID3D11DeviceContext* c,void** table,unsigned count){std::lock_guard<std::recursive_mutex> held(guard);if(find(c)||count<115||hookCount>=128)return;unsigned index=hookCount.load();auto& h=hooks[index];h.context=c;h.shadow=table;memcpy(h.old,table,sizeof(h.old));table[110]=(void*)clearState;table[114]=(void*)finish;table[36]=(void*)depthState;table[34]=(void*)omUav;table[68]=(void*)uav;table[51]=(void*)clearUint;table[52]=(void*)clearFloat;table[33]=(void*)om;table[50]=(void*)clearRT;table[53]=(void*)clearDS;table[44]=(void*)viewport;table[45]=(void*)scissor;table[46]=(void*)region;table[47]=(void*)copy;table[57]=(void*)resolve;table[8]=(void*)srv<8>;table[25]=(void*)srv<25>;table[31]=(void*)srv<31>;table[59]=(void*)srv<59>;table[63]=(void*)srv<63>;table[67]=(void*)srv<67>;hookCount.store(index+1,std::memory_order_release);}
inline void begin(unsigned w,unsigned h){width=w;height=h;failed=false;active=true;}
inline void releaseAuxiliary(){std::lock_guard<std::recursive_mutex> held(guard);if(!active){views.clear();textures.clear();depthSources.clear();for(unsigned i=0;i<hookCount;++i){hooks[i].depth.Reset();hooks[i].depthDirty=true;}}}
inline bool end(){active=false;return !failed.load();}
}

