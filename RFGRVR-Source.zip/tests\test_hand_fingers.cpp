#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define RFGR_FINGERS_TEST
#include <windows.h>
#include <openxr/openxr.h>
#include <algorithm>
#include <cstdio>
#include <cassert>
#include "../src/bridge_hand_fingers.h"
#include "../src/vr_free_finger.h"
static bool supported=true;static unsigned created=0,destroyed=0;
static XrResult XRAPI_PTR properties(XrInstance,XrSystemId,XrSystemProperties* p){((XrSystemHandTrackingPropertiesEXT*)p->next)->supportsHandTracking=supported;return XR_SUCCESS;}
static XrResult XRAPI_PTR create(XrSession,const XrHandTrackerCreateInfoEXT*,XrHandTrackerEXT* out){*out=(XrHandTrackerEXT)(uintptr_t)++created;return XR_SUCCESS;}
static XrResult XRAPI_PTR destroy(XrHandTrackerEXT){++destroyed;return XR_SUCCESS;}
static XrResult XRAPI_PTR locate(XrHandTrackerEXT hand,const XrHandJointsLocateInfoEXT*,XrHandJointLocationsEXT* out){out->isActive=(uintptr_t)hand==1;for(unsigned i=0;i<out->jointCount;++i){out->jointLocations[i].locationFlags=XR_SPACE_LOCATION_POSITION_VALID_BIT;out->jointLocations[i].pose.position={float(i)*.01f,0,0};}return XR_SUCCESS;}
static XrResult XRAPI_PTR get(XrInstance,const char* name,PFN_xrVoidFunction* out){*out=!strcmp(name,"xrGetSystemProperties")?(PFN_xrVoidFunction)properties:!strcmp(name,"xrCreateHandTrackerEXT")?(PFN_xrVoidFunction)create:!strcmp(name,"xrDestroyHandTrackerEXT")?(PFN_xrVoidFunction)destroy:(PFN_xrVoidFunction)locate;return XR_SUCCESS;}
int main(){RFGRXRHands hands;supported=false;hands.init({}, {}, {},get,true);assert(created==0);supported=true;hands.init({}, {}, {},get,true);assert(created==2);hands.update({},{});RFGRFingerReader reader;RFGRHandFingers value{};assert(reader.read(value)&&value.valid==1);for(float curl:value.curl[0])assert(curl==0);hands.close();assert(destroyed==2);hands.update({},{});assert(reader.read(value)&&value.valid==0);
 auto rest=RFGRVR_OpenFingerLocal({-.4f,-1.2f,0},{-.4f,-1.3f,-.04f});assert(vrarm::length(vrarm::sub(rest.p,{0,.1f,.04f}))<.0001f&&rest.b.r.x==1);
 vrarm::Pose pose{vrarm::M{{1,0,0},{0,1,0},{0,0,1}},vrarm::V{1,2,3}};auto open=RFGRVR_FreeFinger(pose,{1,0,0},0,false,false),fist=RFGRVR_FreeFinger(pose,{1,0,0},1,false,false);assert(vrarm::valid(open.b)&&vrarm::length(vrarm::sub(open.b.u,pose.b.u))<.00001f&&vrarm::valid(fist.b)&&vrarm::length(vrarm::sub(open.p,fist.p))==0&&vrarm::length(vrarm::sub(open.b.u,fist.b.u))>.5f);
 auto right=RFGRVR_FreeFinger(pose,{1,0,0},1,false,false,true),thumb=RFGRVR_FreeFinger(pose,{1,0,0},1,true,false);assert(fist.b.u.z>0&&right.b.u.z<0&&thumb.b.u.z<0);assert(RFGRVR_FingerCurl(.15f,4)==0&&RFGRVR_FingerCurl(1,4)==1);
}
