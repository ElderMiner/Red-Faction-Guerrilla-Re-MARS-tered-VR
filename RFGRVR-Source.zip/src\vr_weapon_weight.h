#pragma once
#include "vr_arm_math.h"
#include "vr_weapon_recoil.h"
namespace vrweight {
inline float response(unsigned type,const char* name){
 if(vrrecoil::contains(name,"sniper_rifle")||vrrecoil::contains(name,"rail_driver"))return .24f;
 if(type==1||type==9||type==10||type==12||type==13||type==16)return .24f;
 if(type==0||type==11){if(vrrecoil::contains(name,"pistol"))return 0;return .065f;}
 return 0;
}
// Angular inertia only: the primary grip remains a hard positional constraint.
struct State {
 uintptr_t weapon=0;unsigned handle=0;uint64_t tick=0;vrarm::M basis{};
 vrarm::Pose apply(uintptr_t id,unsigned serial,uint64_t now,vrarm::Pose target,vrarm::V grip,float seconds,bool direct){
  using namespace vrarm;
  if(id!=weapon||serial!=handle||!tick||now<tick||now-tick>250||direct||seconds<=0){weapon=id;handle=serial;tick=now;basis=target.b;return target;}
  float dt=float(now-tick)*.001f;tick=now;
  float a=1-expf(-dt/seconds);float c=dot(basis.f,target.b.f);c=c<-1?-1:c>1?1:c;
  float angle=acosf(c);V axis=cross(basis.f,target.b.f);
  if(length(axis)<.00001f&&c<0)axis=basis.u;
  if(angle>.00001f&&length(axis)>.00001f)basis=turnAround(basis,axis,angle*a);
  basis=turnAround(basis,basis.f,axialRoll(basis,target.b,basis.f)*a);
  V pivot=add(target.p,world(target.b,grip));target.b=basis;target.p=sub(pivot,world(basis,grip));return target;
 }
};
}
