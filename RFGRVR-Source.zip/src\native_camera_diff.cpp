// Read-only pre/post rl_camera::render_begin differential survey.
// Never writes camera memory. Scoped to original hook invocation on same thread.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cmath>
namespace {
constexpr unsigned BYTES=768;
struct Snapshot { void* ptr=nullptr;bool valid=false;unsigned char bytes[BYTES]{}; };
static thread_local Snapshot snapshot;
static std::atomic<unsigned> calls{0}, sampled{0}, failed{0};
static std::atomic<unsigned> changes[BYTES/4];
static unsigned presentCount=0;
static bool region(void* p,unsigned n){
 MEMORY_BASIC_INFORMATION m={};if(!p||!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
 uintptr_t at=(uintptr_t)p,base=(uintptr_t)m.BaseAddress;
 return at>=base&&n<=m.RegionSize&&at-base<=m.RegionSize-n;
}
}
extern "C" void RFGRVR_CameraDiff_Begin(void* p){
 snapshot.valid=false;
 if(calls.fetch_add(1,std::memory_order_relaxed)%30!=0)return;
 if(!region(p,BYTES)){++failed;return;}
 snapshot.ptr=p;memcpy(snapshot.bytes,p,BYTES);snapshot.valid=true;
}
extern "C" void RFGRVR_CameraDiff_End(void* p){
 if(!snapshot.valid||p!=snapshot.ptr){snapshot.valid=false;return;}
 snapshot.valid=false;
 if(!region(p,BYTES)){++failed;return;}
 const unsigned char* after=(const unsigned char*)p;
 for(unsigned offset=0;offset<BYTES;offset+=4){
  if(memcmp(snapshot.bytes+offset,after+offset,4)!=0)changes[offset/4].fetch_add(1,std::memory_order_relaxed);
 }
 ++sampled;
}
extern "C" void RFGRVR_CameraDiff_Present(){
 if(++presentCount%240)return;
 wchar_t path[MAX_PATH]={};if(!GetModuleFileNameW(nullptr,path,MAX_PATH))return;
 wchar_t* slash=wcsrchr(path,L'\\');if(!slash)return;
 wcscpy_s(slash+1,MAX_PATH-(size_t)(slash+1-path),L"RFGRVR-Camera-Field-Diff-v7.5.csv");
 FILE* f=nullptr;if(_wfopen_s(&f,path,L"a")!=0||!f)return;
 if(_ftelli64(f)==0)fputs("present,begin_calls,samples,failures,offset_hex,different_samples\n",f);
 unsigned emitted=0;
 for(unsigned i=0;i<BYTES/4;++i){const unsigned count=changes[i].load();if(count){fprintf(f,"%u,%u,%u,%u,%03X,%u\n",presentCount,calls.load(),sampled.load(),failed.load(),i*4,count);++emitted;}}
 if(!emitted)fprintf(f,"%u,%u,%u,%u,NONE,0\n",presentCount,calls.load(),sampled.load(),failed.load());
 fclose(f);
}
