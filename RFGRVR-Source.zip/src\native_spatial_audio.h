#pragma once
// Included within RFGRVRWeaponPhysics after native source ownership helpers.
namespace SpatialAudio {
using Cue=int(__cdecl*)(int,void*,int*);using Fire=void(__thiscall*)(void*);using Init=void(__thiscall*)(void*);using Position=int(__cdecl*)(int,const V*,const V*,const V*);using Listener=int(__cdecl*)(const V*,const M*,const V*);
inline Cue originalCue=nullptr;inline Fire originalFire=nullptr,originalLoop=nullptr;inline Init init=nullptr;inline Position setPosition=nullptr;inline Listener setListener=nullptr;inline bool ready=false;inline thread_local void* firing=nullptr;
inline std::atomic<unsigned> converted{0},alreadySpatial{0},untouched{0},listenerUpdates{0};
inline SRWLOCK listenerLock=SRWLOCK_INIT;inline Pose headsetListener{};inline DWORD headsetTick=0;
inline int __cdecl onListener(const V* position,const M* basis,const V* velocity){
 Pose pose{};DWORD tick=0;AcquireSRWLockShared(&listenerLock);pose=headsetListener;tick=headsetTick;ReleaseSRWLockShared(&listenerLock);
 // Native camera updates must not overwrite the HMD listener between stereo frames.
 if(requested()&&tick&&DWORD(GetTickCount()-tick)<100&&finite(pose.p)&&valid(pose.b)){V still{};return setListener(&pose.p,&pose.b,&still);}
 return setListener(position,basis,velocity);
}
inline SRWLOCK sourceLock=SRWLOCK_INIT;struct Loop{void* weapon=nullptr;unsigned handle=~0u;int voice=-1;};inline Loop loop;
inline int __cdecl onCue(int id,void* parameters,int* error){
 Target t{};bool local=firing&&requested()&&snapshot(t)&&t.weapon==firing&&owned(t,t.player)&&t.motion.tracked;
 void* info=(void*)(uintptr_t)word(local?t.weapon:nullptr,0x148);bool match=local&&(int(word(info,0x84))==id||int(word(info,0x88))==id||int(word(info,0x8c))==id||int(word(info,0x98))==id);
 if(!match||!init||(parameters&&!memory(parameters,0x134))){++untouched;return originalCue(id,parameters,error);}
 unsigned short flags=0;if(parameters)memcpy(&flags,parameters,2);bool wasSpatial=(flags&1)!=0;if(wasSpatial)++alreadySpatial;
 alignas(16) unsigned char copy[0x134]{};if(parameters)memcpy(copy,parameters,sizeof(copy));else init(copy);memcpy(&flags,copy,2);flags|=1;memcpy(copy,&flags,2);
 V position=t.motion.pose.p,direction=t.motion.pose.b.f,velocity{};memcpy(copy+0x4c,&position,12);memcpy(copy+0x58,&direction,12);memcpy(copy+0x64,&velocity,12);
 int voice=originalCue(id,copy,error);if(voice>=0){if(!wasSpatial)++converted;AcquireSRWLockExclusive(&sourceLock);loop={t.weapon,t.handle,voice};ReleaseSRWLockExclusive(&sourceLock);}return voice;
}
struct Scope{void* previous;Scope(void* weapon):previous(firing){firing=weapon;}~Scope(){firing=previous;}};
inline void __fastcall onFire(void* weapon,void*){Scope scope(weapon);originalFire(weapon);}
inline void __fastcall onLoop(void* weapon,void*){Scope scope(weapon);originalLoop(weapon);}
inline void update(const Target& t){if(!ready||!setPosition||!t.motion.tracked||!owned(t,t.player))return;Loop sound;AcquireSRWLockShared(&sourceLock);sound=loop;ReleaseSRWLockShared(&sourceLock);if(sound.weapon!=t.weapon||sound.handle!=t.handle||sound.voice<0||int(word(t.weapon,0x260))!=sound.voice)return;V direction=t.motion.pose.b.f;setPosition(sound.voice,&t.motion.pose.p,&direction,nullptr);}
inline void listener(const float p[3],const float b[9]){if(!ready||!setListener||!p||!b)return;Pose pose{};memcpy(&pose.p,p,12);memcpy(&pose.b,b,36);if(!finite(pose.p)||!valid(pose.b))return;AcquireSRWLockExclusive(&listenerLock);headsetListener=pose;headsetTick=GetTickCount();ReleaseSRWLockExclusive(&listenerLock);V velocity{};primeSpatialListener(p,b);if(setListener(&pose.p,&pose.b,&velocity)==0)++listenerUpdates;}

inline bool install(){const unsigned char fireSig[]={0x83,0xec,0x30,0x56,0x8b,0xf1},cueSig[]={0x81,0xec,0x68,0x01,0,0},initSig[]={0x0f,0x57,0xc0,0x33,0xc0},listenerSig[]={0x83,0xec,0x24,0x56,0x8b,0x74,0x24,0x30};if(memcmp(base+0x7e65a0,fireSig,6)||memcmp(base+0x7e2b50,fireSig,6)||memcmp(base+0x9f120,cueSig,6)||memcmp(base+0x8cde0,initSig,5)||memcmp(base+0x89d80,listenerSig,8)||base[0x91cc0]!=0xb9||word(base,0x91cc1)!=(unsigned)(uintptr_t)(base+0x169d0e4))return false;
 struct Hook{unsigned rva;void* detour;void** original;};Hook hooks[]={{0x7e65a0,(void*)&onFire,(void**)&originalFire},{0x7e2b50,(void*)&onLoop,(void**)&originalLoop},{0x9f120,(void*)&onCue,(void**)&originalCue},{0x89d80,(void*)&onListener,(void**)&setListener}};unsigned created=0;for(auto& h:hooks){if(MH_CreateHook(base+h.rva,h.detour,h.original)!=MH_OK){for(unsigned j=0;j<created;++j)MH_RemoveHook(base+hooks[j].rva);return false;}++created;}for(auto& h:hooks)if(MH_EnableHook(base+h.rva)!=MH_OK){for(auto& undo:hooks){MH_DisableHook(base+undo.rva);MH_RemoveHook(base+undo.rva);}return false;}init=(Init)(base+0x8cde0);setPosition=(Position)(base+0x91cc0);ready=true;return true;
}
}
inline void updateSpatialSound(const Target& t){SpatialAudio::update(t);}

