#define NOMINMAX
#include <d3d11.h>
#include <wrl/client.h>
#include <cstdio>
using Microsoft::WRL::ComPtr;
int main(){ComPtr<ID3D11Device> d;ComPtr<ID3D11DeviceContext> i,c;D3D_FEATURE_LEVEL f;auto h=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,&f,&i);if(FAILED(h))return 1;d->CreateDeferredContext(0,&c);D3D11_VIEWPORT v{0,0,512,512,0,1};c->RSSetViewports(1,&v);D3D11_VIEWPORT got[16]{};UINT n=16;c->RSGetViewports(&n,got);printf("type=%d viewport count=%u width=%g maxdepth=%g\n",c->GetType(),n,got[0].Width,got[0].MaxDepth);ComPtr<ID3D11CommandList> list;printf("finish=%lx\n",c->FinishCommandList(FALSE,&list));}
