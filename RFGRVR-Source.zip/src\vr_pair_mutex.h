#pragma once
template<class Mutex> bool RFGRVR_AcquirePair(Mutex* left,Mutex* right,bool replacePending=true,unsigned firstWaitMs=0){
 Mutex* mutexes[2]={left,right};unsigned key[2]{};
 for(unsigned eye=0;eye<2;++eye){
  HRESULT hr=mutexes[eye]->AcquireSync(0,eye?0:firstWaitMs);
  if(hr==WAIT_TIMEOUT&&replacePending){hr=mutexes[eye]->AcquireSync(1,0);key[eye]=1;}
  if(hr!=S_OK){if(eye)left->ReleaseSync(key[0]);return false;}
 }
 return true;
}
