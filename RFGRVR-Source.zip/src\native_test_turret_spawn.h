#pragma once
#include "test_spawn_catalog.h"
// Included inside RFGRVRWeaponPhysics. These are the native object-property
// constructor, string setter, world factory and matching property destructor.
namespace TestTurretSpawn {
using Init=void(__thiscall*)(void*,const V*,const M*,const char*);
using SetString=void(__thiscall*)(void*,void*,const char*);
using Destroy=void(__thiscall*)(void*);
using Find=void*(__cdecl*)(const char*);
using Create=void*(__thiscall*)(void*,unsigned,void*,void*,unsigned);
inline Init init=nullptr;inline SetString setString=nullptr;inline Destroy destroy=nullptr;inline Find find=nullptr;inline Create create=nullptr;
inline void* world=nullptr;inline void* typeProperty=nullptr;inline unsigned* classHash=nullptr;
inline bool ready(){return init&&setString&&destroy&&find&&create&&world&&typeProperty&&classHash;}
inline V worldVector(const M& b);
inline void* spawn(const char* name,const Pose& player){const auto* entry=vrtestspawn::find(name);if(!entry||!entry->turret||!ready()||*classHash!=0x05b96354u||!find(name)||!valid(player.b)||!finite(player.p))return nullptr;
 float yaw=atan2f(player.b.f.x,player.b.f.z),c=cosf(yaw),s=sinf(yaw);M upright{{c,0,-s},{0,1,0},{s,0,c}};V position=add(player.p,worldVector(upright));
 alignas(8) unsigned char block[12]{};init(block,&position,&upright,nullptr);setString(block,typeProperty,name);void* object=create(world,*classHash,block,nullptr,~0u);destroy(block);return object;
}
inline V worldVector(const M& b){return vrarm::world(b,{0,.1f,5.f});}
inline bool install(unsigned char* b){const unsigned char a[]={0x83,0xec,0x30,0x56},s[]={0x56,0x57,0x8b,0x7c,0x24,0x10},d[]={0x56,0x8b,0xf1,0x33,0xc0},f[]={0x53,0x8b,0x5c,0x24,0x08};
 if(memcmp(b+0x638b00,a,sizeof(a))||memcmp(b+0x51a870,s,sizeof(s))||memcmp(b+0x521950,d,sizeof(d))||memcmp(b+0x6208f0,f,sizeof(f))||b[0x53e6b0]!=0xa1||memcmp(b+0x6afc20,"\x83\xec\x1c",3))return false;
 const char* property=(const char*)(uintptr_t)word(b+0x12adba4,0);if(!memory(property,12)||strcmp(property,"turret_type"))return false;
 init=(Init)(b+0x638b00);setString=(SetString)(b+0x51a870);destroy=(Destroy)(b+0x521950);find=(Find)(b+0x6208f0);create=(Create)(b+0x53e6b0);world=b+0x2b98490;typeProperty=b+0x12adba4;classHash=(unsigned*)(b+0x3138994);return true;
}
}
