#pragma once
#include <cmath>
// A headset rotates around the neck, not its optical centre. Keep that
// eye orbit in the view while excluding it from character translation.
struct RFGRVRRoomMotion {
 float neckAtOrigin[3]{},previousBody[3]{};bool bodySampled=false,controllerWasMoving=false;
 void anchorController(bool moving,const float position[3],const float neck[3],float origin[3]){float body[3]={position[0]-neck[0],0,position[2]-neck[2]};if(moving&&controllerWasMoving&&bodySampled){origin[0]+=body[0]-previousBody[0];origin[2]+=body[2]-previousBody[2];}for(int i=0;i<3;++i)previousBody[i]=body[i];bodySampled=true;controllerWasMoving=moving;}
 void reset(const float neck[3]){bodySampled=false;controllerWasMoving=false;for(int i=0;i<3;++i)neckAtOrigin[i]=neck[i];}
 void displacement(const float eyeDelta[3],const float neck[3],float out[3])const{
  for(int i=0;i<3;++i)out[i]=eyeDelta[i]-(neck[i]-neckAtOrigin[i]);out[1]=0;
  float d=std::sqrt(out[0]*out[0]+out[2]*out[2]);
  // A small body-follow radius absorbs ordinary neck-model error and sway.
  constexpr float radius=.015f;if(d<=radius){out[0]=out[2]=0;return;}
  float f=(d-radius)/d;out[0]*=f;out[2]*=f;
 }
};
