#pragma once
#include <d3d11.h>
#include <wrl/client.h>
namespace vrdesktop {
struct Mirror {
 Microsoft::WRL::ComPtr<ID3D11Texture2D> eye;
 bool capture(ID3D11Device* device,ID3D11DeviceContext* context,ID3D11Texture2D* source){if(!device||!context||!source)return false;D3D11_TEXTURE2D_DESC d{},old{};source->GetDesc(&d);if(eye)eye->GetDesc(&old);if(!eye||d.Width!=old.Width||d.Height!=old.Height||d.Format!=old.Format){eye.Reset();d.MiscFlags=0;d.BindFlags=0;d.Usage=D3D11_USAGE_DEFAULT;d.CPUAccessFlags=0;if(FAILED(device->CreateTexture2D(&d,nullptr,&eye)))return false;}context->CopyResource(eye.Get(),source);return true;}
 bool present(ID3D11Device* device,ID3D11DeviceContext* context,ID3D11Texture2D* target,bool enabled){if(!device||!context||!target)return false;if(!enabled){Microsoft::WRL::ComPtr<ID3D11RenderTargetView> rtv;if(FAILED(device->CreateRenderTargetView(target,nullptr,&rtv)))return false;const float black[4]={0,0,0,1};context->ClearRenderTargetView(rtv.Get(),black);return true;}if(!eye)return false;D3D11_TEXTURE2D_DESC a{},b{};eye->GetDesc(&a);target->GetDesc(&b);if(a.Width!=b.Width||a.Height!=b.Height||a.Format!=b.Format)return false;context->CopyResource(target,eye.Get());return true;}
};
}
