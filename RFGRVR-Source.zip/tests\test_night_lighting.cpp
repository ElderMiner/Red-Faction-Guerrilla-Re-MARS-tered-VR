#define RFGR_TEST_USER_SETTINGS
#include "../src/vr_user_settings.h"
#include <cassert>
#include <cstdio>
int main(){using namespace vrnight;
 {using namespace vrsettings;Config config;assert(config.value[Lighting]==1);auto preset=nightPlan(config,0);assert(fabsf(preset.exposure-.2f)<1e-6f&&preset.mainLight==0&&preset.ambient==2&&fabsf(preset.saturation-1.1f)<1e-6f&&fabsf(preset.tint[0]-.55f)<1e-6f&&fabsf(preset.tint[1]-.9f)<1e-6f&&fabsf(preset.tint[2]-1.4f)<1e-6f);config.value[Lighting]=0;auto vanilla=nightPlan(config,0);assert(vanilla.exposure==1&&vanilla.bloom==1&&vanilla.mainLight==1&&vanilla.ambient==1&&vanilla.saturation==1&&vanilla.tint[0]==1&&vanilla.tint[1]==1&&vanilla.tint[2]==1);config.validate();float hour=0;publishNightHour(1.5f,123,1000);assert(nightHour(123,1001,hour)&&hour==1.5f);assert(!nightHour(124,1001,hour)&&!nightHour(123,2001,hour));publishNightHour(NAN,123,1000);assert(!nightHour(123,1001,hour));publishNightHour(23,123,0xffffff00);assert(nightHour(123,0x20,hour));InterlockedIncrement(&bus()->nightSequence);assert(!nightHour(123,0x20,hour));InterlockedIncrement(&bus()->nightSequence);}
 assert(weight(0)==1&&weight(24)==1&&weight(12)==0&&weight(5)==1&&weight(7)==0&&weight(17)==0&&weight(19)==1);
 for(float hour=-2;hour<26;hour+=.01f){float w=weight(hour);assert(w>=0&&w<=1);if(hour>=0&&hour<=24)assert(fabsf(w-weight(24-hour))<.00001f);}
 assert(weight(NAN)==0&&weight(INFINITY)==0);
 assert(weight(5.5f)==.5f&&weight(18.5f)==.5f);
 // Exact native daytime includes the formerly graded 06-07 and 17-18 windows.
 for(int minute=6*60;minute<18*60;++minute){
  auto d=Plan::at(minute/60.f,5,0,0,200,0,200,0,200);
  assert(d.exposure==1&&d.bloom==1&&d.mainLight==1&&d.ambient==1&&d.saturation==1&&d.tint[0]==1&&d.tint[1]==1&&d.tint[2]==1);
 }
 auto night=Plan::at(0,60,50),day=Plan::at(12,60,50),native=Plan::at(0,100,100);
 assert(night.exposure==.6f&&night.bloom==.5f&&day.exposure==1&&day.bloom==1&&native.exposure==1&&native.bloom==1);
 assert(expose(0,.6f)==0&&expose(1,.6f)==1&&expose(.2f,.6f)<.2f&&expose(.5f,1)==.5f);
 {auto p=Plan::at(0,100,100,0,25,0,50,100,150);assert(p.mainLight==0&&p.ambient==.25f&&p.saturation==0&&p.tint[0]==.5f&&p.tint[2]==1.5f);float rgb[3]={.2f,.5f,.8f};grade(rgb,p);assert(fabsf(rgb[1]-rgb[0]*2)<.00001f&&fabsf(rgb[2]-rgb[0]*3)<.00001f);auto dayGrade=Plan::at(12,50,0,0,0,0,0,0,0);assert(dayGrade.mainLight==1&&dayGrade.ambient==1&&dayGrade.saturation==1&&dayGrade.tint[2]==1);}
 unsigned char hdr[0x68]{},before[0x68];float maximum=4,minimum=.001f,amount=2.5f;memcpy(hdr+0x20,&maximum,4);memcpy(hdr+0x24,&minimum,4);memcpy(hdr+0x48,&amount,4);memcpy(before,hdr,sizeof(hdr));Parameters p;
 assert(!p.copy(hdr));
 {Frame frame(night);assert(current==&frame.value);{Frame nested(day);assert(current==&frame.value);}assert(p.copy(hdr));float value;memcpy(&value,p.bytes+0x48,4);assert(value==1.25f);float ceiling;assert(bloomLimit(hdr,ceiling)&&ceiling==1.25f);for(unsigned i=0;i<sizeof(hdr);++i)if(i<0x48||i>=0x4c)assert(hdr[i]==p.bytes[i]);assert(!memcmp(hdr,before,sizeof(hdr)));}
 assert(!current);{Frame frame(day);assert(!p.copy(hdr));}{Frame frame(native);assert(!p.copy(hdr));}
 puts("PASS night lighting: smooth clock gating, native/day identity, highlight retention, nested-frame ownership and bloom-only HDR copy");
}
