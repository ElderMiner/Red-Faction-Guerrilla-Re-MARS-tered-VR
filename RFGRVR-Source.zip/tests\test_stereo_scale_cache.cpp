#define main RFGRVR_BridgeEntryForTest
#include "../src/bridge.cpp"
#undef main
#include <cassert>
using Microsoft::WRL::ComPtr;
int main(){
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;
 assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,nullptr,&context)));
 auto texture=[&](unsigned width,unsigned bind){D3D11_TEXTURE2D_DESC d{};d.Width=width;d.Height=32;d.MipLevels=d.ArraySize=1;d.Format=DXGI_FORMAT_R8G8B8A8_UNORM;d.SampleDesc.Count=1;d.BindFlags=bind;ComPtr<ID3D11Texture2D> t;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&t)));return t;};
 auto a=texture(32,D3D11_BIND_SHADER_RESOURCE),b=texture(32,D3D11_BIND_SHADER_RESOURCE);
 auto left=texture(32,D3D11_BIND_RENDER_TARGET),right=texture(32,D3D11_BIND_RENDER_TARGET);
 auto fill=[&](ID3D11Texture2D* t,unsigned color){unsigned pixels[1024];for(auto& p:pixels)p=color;context->UpdateSubresource(t,0,nullptr,pixels,128,0);};
 auto check=[&](ID3D11Texture2D* t,unsigned color){D3D11_TEXTURE2D_DESC d{};t->GetDesc(&d);d.Usage=D3D11_USAGE_STAGING;d.BindFlags=0;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> read;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&read)));context->CopyResource(read.Get(),t);D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(context->Map(read.Get(),0,D3D11_MAP_READ,0,&map)));for(unsigned y=0;y<32;++y)for(unsigned x=0;x<d.Width;++x)assert(((unsigned*)((char*)map.pData+y*map.RowPitch))[x]==color);context->Unmap(read.Get(),0);};
 StereoScaleBlit blit;float measured[4]={1,1,0,0};
 auto draw=[&](ID3D11Texture2D* source,ID3D11Texture2D* target){assert(blit.render(device.Get(),context.Get(),source,target,-.5f,.5f,.5f,-.5f,90,false,measured));};
 fill(a.Get(),0xff0000ff);fill(b.Get(),0xff00ff00);draw(a.Get(),left.Get());draw(b.Get(),right.Get());check(left.Get(),0xff0000ff);check(right.Get(),0xff00ff00);
 // Reuse the same views while their texture contents change every frame.
 fill(a.Get(),0xffff0000);draw(a.Get(),left.Get());draw(b.Get(),right.Get());check(left.Get(),0xffff0000);check(right.Get(),0xff00ff00);assert(blit.nextCached==2);
 // Replacing a resized target must rebuild its view without using the old one.
 auto resized=texture(64,D3D11_BIND_RENDER_TARGET);draw(a.Get(),resized.Get());check(resized.Get(),0xffff0000);
 // Menu-only outline makes a black character visible without filling clear space.
 {unsigned pixels[1024]{};for(unsigned y=8;y<24;++y)for(unsigned x=8;x<24;++x)pixels[y*32+x]=0xff000000;context->UpdateSubresource(a.Get(),0,nullptr,pixels,128,0);blit.preserveAlpha=true;assert(blit.render(device.Get(),context.Get(),a.Get(),left.Get(),-.5f,.5f,.5f,-.5f,90,true,measured));D3D11_TEXTURE2D_DESC d{};left->GetDesc(&d);d.Usage=D3D11_USAGE_STAGING;d.BindFlags=0;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Texture2D> read;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&read)));context->CopyResource(read.Get(),left.Get());D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(context->Map(read.Get(),0,D3D11_MAP_READ,0,&map)));auto pixel=[&](unsigned x,unsigned y){return ((unsigned*)((char*)map.pData+y*map.RowPitch))[x];};assert((pixel(16,16)&255)>30);assert((pixel(7,16)>>24)>100);assert((pixel(0,0)>>24)==0);context->Unmap(read.Get(),0);}}

