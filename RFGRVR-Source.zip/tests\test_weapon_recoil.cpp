#include "../src/vr_weapon_recoil.h"
#include <cassert>
#include "../src/vr_weapon_weight.h"
#include "../src/vr_leg_stability.h"
#include "../src/vr_forward_lean.h"
int main(){using namespace vrrecoil;using namespace vrarm;
 RFGRVRLegStability legs;V feet[2]={{-.1f,0,0},{.1f,0,0}};legs.update(1,1,1,feet);feet[0].z=.1f;legs.update(1,2,1.01,feet);assert(feet[0].z>0&&feet[0].z<.04f);float cached=feet[0].z;feet[0].z=.2f;legs.update(1,2,1.011,feet);assert(feet[0].z==cached);feet[0].z=2;legs.update(1,3,1.02,feet);assert(feet[0].z==2);RFGRVRForwardLean lean;for(int i=0;i<100;++i)lean.update(1,.01f,true);assert(lean.angle>.17f&&lean.angle<.175f);
 RFGRVRStableGait gait;gait.update(1,1,1,{0,0,0},1);for(unsigned i=2;i<100;++i)gait.update(1,i,1+i*.01,{0,0,0},1);assert(gait.weight==0&&length(gait.offset(0,M{{1,0,0},{0,1,0},{0,0,1}},1))==0);
 for(unsigned i=100;i<200;++i)gait.update(1,i,1+i*.01,{(i-99)*.01f,0,0},1);M identityGait{{1,0,0},{0,1,0},{0,0,1}};auto sideStep=gait.offset(0,identityGait,1);assert(fabsf(sideStep.z)<.00001f&&fabsf(sideStep.x)<=.181f&&sideStep.y<=.056f);float phase=gait.phase;gait.update(1,199,3.001,{10,0,0},1);assert(gait.phase==phase);
 for(unsigned i=200;i<400;++i)gait.update(1,i,1+i*.01,{1,0,0},1);assert(gait.weight<.0001f);gait.update(1,400,5.1,{20,0,0},1);assert(gait.weight==0);
 assert(profile(0,"edf_assault_rifle").unsupportedGain>1.5f&&profile(0,"edf_pistol").unsupportedGain==1.f);
 auto rifle=profile(0,"edf_assault_rifle"),shotgun=profile(0,"edf_shotgun"),smg=profile(0,"edf_smg");assert(shotgun.degrees>rifle.degrees&&rifle.degrees>smg.degrees&&profile(7,"sledge").degrees==0&&profile(3,"c4").degrees==0);
 for(const char* scoped:{"sniper_rifle","rail_driver"}){auto p=profile(0,scoped),launcher=profile(1,"rpg");assert(p.degrees==launcher.degrees&&p.back==launcher.back&&p.returnRate==launcher.returnRate&&vrweight::response(0,scoped)==vrweight::response(1,"rpg"));}
 State one,two;one.observe(1,1,10,false,false,100,rifle,false);two.observe(1,1,10,false,false,100,rifle,true);
 one.observe(1,1,9,true,false,110,rifle,false);two.observe(1,1,9,true,false,110,rifle,true);one.observe(1,1,9,false,false,150,rifle,false);two.observe(1,1,9,false,false,150,rifle,true);assert(one.pitch.x>0&&two.pitch.x<one.pitch.x&&one.back.x>0);
 Pose gun{M{{1,0,0},{0,1,0},{0,0,1}},{0,1,0}};auto kicked=one.apply(gun,{0,0,0},gun.b,1);assert(kicked.b.f.y>0&&kicked.p.z<0);
 State split=one,whole=one;for(unsigned t=160;t<=350;t+=10)split.observe(1,1,9,false,false,t,rifle,false);whole.observe(1,1,9,false,false,350,rifle,false);assert(fabsf(split.pitch.x-whole.pitch.x)<.000001f&&fabsf(split.back.x-whole.back.x)<.000001f);
 for(unsigned t=360;t<=750;t+=10)one.observe(1,1,9,false,false,t,rifle,false);assert(fabsf(one.pitch.x)<.00001f);
 State noShot;noShot.observe(1,1,10,false,false,100,rifle,false);noShot.observe(1,1,0,true,true,110,rifle,false);assert(noShot.pitch.v==0);noShot.observe(1,1,10,true,false,120,rifle,false);noShot.observe(1,1,10,true,false,130,rifle,false);assert(noShot.pitch.v==0);noShot.observe(2,2,4,true,false,140,rifle,false);assert(noShot.pitch.v==0);noShot.observe(2,2,3,false,false,150,rifle,false);assert(noShot.pitch.v==0);

 vrweight::State heavy,light;Pose initial{M{{1,0,0},{0,1,0},{0,0,1}},{1,2,3}};V grip{.1f,.2f,.3f};
 heavy.apply(1,1,100,initial,grip,.24f,false);light.apply(1,1,100,initial,grip,.065f,false);
 Pose aim=initial;aim.b=turnAround(aim.b,{0,1,0},1.f);auto h=heavy.apply(1,1,110,aim,grip,.24f,false),l=light.apply(1,1,110,aim,grip,.065f,false);
 assert(h.b.f.x<l.b.f.x&&valid(h.b));assert(length(sub(add(h.p,world(h.b,grip)),add(aim.p,world(aim.b,grip))))<.00001f);
 auto duplicate=heavy.apply(1,1,110,aim,grip,.24f,false);assert(length(sub(duplicate.b.f,h.b.f))<.00001f);
 for(unsigned t=120;t<=1510;t+=10)h=heavy.apply(1,1,t,aim,grip,.24f,false);assert(dot(h.b.f,aim.b.f)>.999f);
 h=heavy.apply(1,1,1520,initial,grip,.24f,true);assert(dot(h.b.f,initial.b.f)>.99999f);
 h=heavy.apply(2,2,1530,aim,grip,.24f,false);assert(dot(h.b.f,aim.b.f)>.99999f);
 assert(vrweight::response(1,"rpg")>vrweight::response(0,"rifle")&&vrweight::response(0,"edf_pistol")==0&&vrweight::response(3,"c4")==0);
 State burst;burst.observe(7,7,30,false,false,100,rifle,false);for(unsigned round=1;round<=8;++round)burst.observe(7,7,30-round,true,false,100+round*80,rifle,false);assert(burst.climb>.25f);float accumulated=burst.climb;burst.observe(7,7,22,true,false,750,rifle,false);assert(burst.climb==accumulated);auto raised=burst.apply(gun,{0,0,0},gun.b,1);assert(raised.b.f.y>.2f);for(unsigned time=800;time<=2400;time+=20)burst.observe(7,7,22,false,false,time,rifle,false);assert(burst.climb<.002f);
 State supportedBurst;supportedBurst.observe(8,8,30,false,false,100,rifle,true);for(unsigned round=1;round<=8;++round)supportedBurst.observe(8,8,30-round,true,false,100+round*80,rifle,true);float oldSupportedClimb=8*.6f*rifle.degrees*.01745329252f*.65f;assert(supportedBurst.climb>0&&supportedBurst.climb<oldSupportedClimb*.6f);
}
