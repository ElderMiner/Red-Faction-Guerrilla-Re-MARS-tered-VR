#pragma once
#include <vector>
#include <array>
#include <algorithm>
#include <unordered_set>
#include <atomic>
#include <cstring>
namespace RFGRVREffects {
inline std::atomic<int> eye{-1};inline unsigned callIndex[2]{};
inline constexpr unsigned listOffsets[]={0x148,0x4158,0x8168,0x9178,0xa188};
struct Snapshot {void* manager=nullptr;std::array<std::vector<unsigned>,5> lists;};
inline Snapshot saved[16];
inline bool readable(void* p,size_t n){MEMORY_BASIC_INFORMATION m{};return p&&VirtualQuery(p,&m,sizeof(m))&&m.State==MEM_COMMIT&&!(m.Protect&(PAGE_NOACCESS|PAGE_GUARD))&&n<=m.RegionSize&&(uintptr_t)p>=(uintptr_t)m.BaseAddress&&(uintptr_t)p-(uintptr_t)m.BaseAddress<=m.RegionSize-n;}
inline unsigned word(void* p,unsigned off){unsigned v=0;memcpy(&v,(char*)p+off,4);return v;}
inline bool list(void* p,unsigned offset,unsigned*& data,unsigned& count,unsigned& capacity){if(!readable((char*)p+offset,16))return false;data=(unsigned*)(uintptr_t)word(p,offset+4);capacity=word(p,offset+8);count=word(p,offset+12);return capacity<=16384&&count<=capacity&&readable(data,size_t(capacity)*4);}
inline bool merge(std::vector<unsigned>& out,const std::vector<unsigned>& first,const std::vector<unsigned>& second,unsigned capacity){if(first.size()>capacity)return false;out=first;std::unordered_set<unsigned> seen(first.begin(),first.end());for(auto v:second)if(seen.insert(v).second){if(out.size()==capacity)return false;out.push_back(v);}return true;}
inline bool enabled(){wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return false;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-effect-list-reuse.enable");return GetFileAttributesW(path)!=INVALID_FILE_ATTRIBUTES;}
inline void select(unsigned e){callIndex[e]=0;eye=int(e);}
inline void capture(void* manager,Snapshot& snapshot){snapshot.manager=manager;for(unsigned i=0;i<5;++i){unsigned* data=nullptr,n=0,cap=0;snapshot.lists[i].clear();if(list(manager,listOffsets[i],data,n,cap))snapshot.lists[i].assign(data,data+n);}}
inline bool apply(void* manager,const Snapshot& snapshot){if(manager!=snapshot.manager)return false;std::array<std::vector<unsigned>,5> output;for(unsigned i=0;i<5;++i){unsigned* data=nullptr,n=0,cap=0;if(!list(manager,listOffsets[i],data,n,cap))return false;std::vector<unsigned> current(data,data+n);if(!merge(output[i],snapshot.lists[i],current,cap))return false;}for(unsigned i=0;i<5;++i){auto off=listOffsets[i];auto* data=(unsigned*)(uintptr_t)word(manager,off+4);memcpy(data,output[i].data(),output[i].size()*4);unsigned n=unsigned(output[i].size());memcpy((char*)manager+off+12,&n,4);}return true;}
using Render=void(__thiscall*)(void*,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);
inline Render render=nullptr;
inline void __fastcall onRender(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h,uintptr_t i,uintptr_t j){
 int current=eye.load();Snapshot original;unsigned index=0;bool changed=false;
 if(current>=0&&current<2){index=callIndex[current]++;if(index<16){if(current==0)capture(self,saved[index]);else if(enabled()){capture(self,original);changed=apply(self,saved[index]);}}}
 render(self,a,b,c,d,e,f,g,h,i,j);
 if(changed)for(unsigned k=0;k<5;++k){unsigned* data=nullptr,n=0,cap=0;if(list(self,listOffsets[k],data,n,cap)&&original.lists[k].size()<=cap){memcpy(data,original.lists[k].data(),original.lists[k].size()*4);unsigned count=unsigned(original.lists[k].size());memcpy((char*)self+listOffsets[k]+12,&count,4);}}
}
}

