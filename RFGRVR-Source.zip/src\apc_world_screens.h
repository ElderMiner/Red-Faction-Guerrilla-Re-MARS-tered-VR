#pragma once
#include "apc_camera_gpu.h"
#include "native_apc_cameras.h"
struct RFGRAPCWorldScreens {
 bool displayFilter=true;uint64_t scanFrame=0;float scanPhase=0;
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> deferred;
 Ptr<ID3D11VertexShader> vs;Ptr<ID3D11PixelShader> ps;Ptr<ID3D11InputLayout> layout;Ptr<ID3D11Buffer> buffer;
 Ptr<ID3D11SamplerState> sampler;Ptr<ID3D11RasterizerState> raster;Ptr<ID3D11DepthStencilState> depth,reverseDepth;
 Ptr<ID3D11Texture2D> output,atlas;Ptr<ID3D11RenderTargetView> target;Ptr<ID3D11ShaderResourceView> image;
 struct Vertex{float clip[4],uv[2],rect[4],lens,material,phase;};
 bool init(ID3D11Device* d){if(owner.Get()==d&&buffer)return true;bool filter=displayFilter;*this={};displayFilter=filter;owner=d;
 const char shader[]=R"(Texture2D image:register(t0);SamplerState linearClamp:register(s0);struct V{float4 p:POSITION;float2 uv:TEXCOORD0;float4 rect:TEXCOORD1;float lens:TEXCOORD2;float material:TEXCOORD3;float phase:TEXCOORD4;};struct O{float4 p:SV_POSITION;float2 uv:TEXCOORD0;float4 rect:TEXCOORD1;float lens:TEXCOORD2;float material:TEXCOORD3;float phase:TEXCOORD4;};O VS(V v){O o;o.p=v.p;o.uv=v.uv;o.rect=v.rect;o.lens=v.lens;o.material=v.material;o.phase=v.phase;return o;}uint letter(int c,int row){if(row<0||row>6)return 0;if(c==0)return row==0||row==6?14:17;if(c==1||c==2)return row==0?31:row==3?30:16;if(c==3)return row==6?31:16;if(c==4)return row==0||row==6?31:4;if(c==5)return row==0||row==6?17:row<3?25:row==3?21:19;if(c==6)return row==0||row==6?31:row==3?30:16;return 0;}
float4 PS(O i):SV_Target{float sweep=1-.18*exp(-pow((i.uv.y-i.phase)/.012,2));if(i.material< -1.5){float2 cell=(i.uv-float2(.15,.4))*float2(60,35);int col=(int)floor(cell.x),row=(int)floor(cell.y);bool text=col>=0&&col<42&&row>=0&&row<7&&((letter(col/6,row)>>(4-col%6))&1)!=0&&col%6<5;float grain=frac(sin(dot(floor(i.uv*float2(768,432)),float2(12.9898,78.233)))*43758.5453);return float4((text?float3(.28,.34,.32):float3(.012,.02,.017)+grain*.008)*sweep,1);}if(i.material>0)return float4(i.material.xxx,1);float2 q=i.uv*2-1;float radius=dot(q,q);q*=lerp(1,(1+.35*radius)/1.7,i.lens);float2 uv=i.rect.xy+saturate(q*.5+.5)*i.rect.zw;float3 color=image.Sample(linearClamp,uv).rgb;if(i.material<0)return float4(color,1);float scan=sweep;float grain=frac(sin(dot(floor(i.uv*float2(768,432)),float2(12.9898,78.233)))*43758.5453)-.5;return float4(saturate(color*scan+grain*.008),1);})";
 Ptr<ID3DBlob> v,p;if(FAILED(D3DCompile(shader,sizeof(shader),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&v,nullptr))||FAILED(D3DCompile(shader,sizeof(shader),nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&p,nullptr)))return false;
 D3D11_INPUT_ELEMENT_DESC elements[]={{"POSITION",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,16,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",1,DXGI_FORMAT_R32G32B32A32_FLOAT,0,24,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",2,DXGI_FORMAT_R32_FLOAT,0,40,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",3,DXGI_FORMAT_R32_FLOAT,0,44,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",4,DXGI_FORMAT_R32_FLOAT,0,48,D3D11_INPUT_PER_VERTEX_DATA,0}};
 if(FAILED(d->CreateVertexShader(v->GetBufferPointer(),v->GetBufferSize(),nullptr,&vs))||FAILED(d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,&ps))||FAILED(d->CreateInputLayout(elements,6,v->GetBufferPointer(),v->GetBufferSize(),&layout))||FAILED(d->CreateDeferredContext(0,&deferred)))return false;
 D3D11_BUFFER_DESC b{};b.ByteWidth=168*sizeof(Vertex);b.Usage=D3D11_USAGE_DYNAMIC;b.BindFlags=D3D11_BIND_VERTEX_BUFFER;b.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;if(FAILED(d->CreateBuffer(&b,nullptr,&buffer)))return false;
 D3D11_SAMPLER_DESC s{};s.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;s.AddressU=s.AddressV=s.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;s.MaxLOD=D3D11_FLOAT32_MAX;
 D3D11_RASTERIZER_DESC r{};r.FillMode=D3D11_FILL_SOLID;r.CullMode=D3D11_CULL_NONE;r.DepthClipEnable=TRUE;
 D3D11_DEPTH_STENCIL_DESC z{};z.DepthEnable=TRUE;z.DepthWriteMask=D3D11_DEPTH_WRITE_MASK_ZERO;z.DepthFunc=D3D11_COMPARISON_LESS_EQUAL;
 bool states=SUCCEEDED(d->CreateDepthStencilState(&z,&depth));z.DepthFunc=D3D11_COMPARISON_GREATER_EQUAL;states=states&&SUCCEEDED(d->CreateDepthStencilState(&z,&reverseDepth));
 return states&&SUCCEEDED(d->CreateSamplerState(&s,&sampler))&&SUCCEEDED(d->CreateRasterizerState(&r,&raster));
 }
 bool draw(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* back,ID3D11DepthStencilView* sceneDepth,RFGRAPCGpu& feeds,const vrarm::Pose& eye,const float projection[16],D3D11_COMPARISON_FUNC comparison=D3D11_COMPARISON_LESS_EQUAL,float minimum=0,float maximum=1,uint64_t frame=0){
 using namespace vrarm;Pose panel{};float size=1,scale=1;unsigned mask=0;bool online=false;RFGRVRAPC::Monitor monitors[4]{};vrarm::V positions[4]{};
 {AcquireSRWLockShared(&RFGRVRAPC::lock);bool enabled=(RFGRVRAPC::packet.active&4)!=0;online=(RFGRVRAPC::packet.active&2)!=0;panel=RFGRVRAPC::nativeScreens;size=RFGRVRAPC::assemblyScale;scale=RFGRVRAPC::scale;mask=enabled?(online?RFGRVRAPC::validFeeds:15u):0;for(unsigned i=0;i<4;++i){monitors[i]=RFGRVRAPC::monitors[i];positions[i]=RFGRVRAPC::monitorOffset(i);}ReleaseSRWLockShared(&RFGRVRAPC::lock);}
 if(!mask||!sceneDepth||!init(d)||(!feeds.atlas.texture&&!feeds.init(d)))return false;
 if(output.Get()!=back){output=back;target.Reset();if(FAILED(d->CreateRenderTargetView(back,nullptr,&target)))return false;}
 if(atlas.Get()!=feeds.atlas.texture.Get()){atlas=feeds.atlas.texture;image.Reset();if(FAILED(d->CreateShaderResourceView(atlas.Get(),nullptr,&image)))return false;}
 if(!frame||scanFrame!=frame){scanFrame=frame;scanPhase=float(GetTickCount64()%8000)/8000.f;}
 D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);Vertex vertices[168]{};unsigned count=0;
 const unsigned corners[6]={0,1,2,2,1,3};
 for(unsigned i=0;i<4;++i){if(!(mask&(1u<<i)))continue;auto tile=RFGRAPCScreen::tile(i);float w=RFGRAPCScreen::width(i)*monitors[i].width*size*scale,h=RFGRAPCScreen::height(i)*monitors[i].height*size*scale;M facing=compose(panel.b,compose(turnAround(M{{1,0,0},{0,1,0},{0,0,1}},{0,1,0},monitors[i].yaw),turnAround(M{{1,0,0},{0,1,0},{0,0,1}},{1,0,0},monitors[i].tilt)));
 V offset=positions[i];V center=add(panel.p,world(panel.b,mul(offset,size*scale)));

 auto point=[&](V p,float material){auto& out=vertices[count++];p=local(eye.b,sub(add(center,world(facing,p)),eye.p));float value[4]={p.x,p.y,p.z,1};for(unsigned row=0;row<4;++row)for(unsigned col=0;col<4;++col)out.clip[row]+=projection[col*4+row]*value[col];out.material=material;};
 float rim=.012f*size*scale,thickness=.035f*size*scale,halfW=w*.5f+rim,halfH=h*.5f+rim;
 auto quad=[&](V a,V b,V c,V d,float shade){point(a,shade);point(b,shade);point(c,shade);point(c,shade);point(b,shade);point(d,shade);};
 // A six-face rectangular enclosure, rendered before its slightly inset glass.
 quad({-halfW,-halfH,thickness},{halfW,-halfH,thickness},{-halfW,halfH,thickness},{halfW,halfH,thickness},.035f);
 quad({-halfW,-halfH,0},{-halfW,-halfH,thickness},{-halfW,halfH,0},{-halfW,halfH,thickness},.065f);
 quad({halfW,-halfH,thickness},{halfW,-halfH,0},{halfW,halfH,thickness},{halfW,halfH,0},.05f);
 quad({-halfW,halfH,0},{halfW,halfH,0},{-halfW,halfH,thickness},{halfW,halfH,thickness},.085f);
 quad({-halfW,-halfH,thickness},{halfW,-halfH,thickness},{-halfW,-halfH,0},{halfW,-halfH,0},.045f);
 quad({-halfW,-halfH,0},{halfW,-halfH,0},{-halfW,halfH,0},{halfW,halfH,0},.055f);
 if(dot(sub(eye.p,center),facing.f)>0)continue;
 for(unsigned j=0;j<6;++j){unsigned corner=corners[j];float u=float(corner&1),v=float(corner>>1);V p=local(eye.b,sub(add(center,world(facing,{(u-.5f)*w,(.5f-v)*h,-.001f*size*scale})),eye.p));auto& out=vertices[count++];const float value[4]={p.x,p.y,p.z,1};for(unsigned row=0;row<4;++row)for(unsigned col=0;col<4;++col)out.clip[row]+=projection[col*4+row]*value[col];out.uv[0]=u;out.uv[1]=v;out.rect[0]=(tile.x+.5f)/RFGRAPCScreen::atlasWidth;out.rect[1]=(tile.y+.5f)/RFGRAPCScreen::atlasHeight;out.rect[2]=float(tile.width-1)/RFGRAPCScreen::atlasWidth;out.rect[3]=float(tile.height-1)/RFGRAPCScreen::atlasHeight;out.phase=scanPhase;out.lens=monitors[i].lens;out.material=online?(displayFilter?0:-1):-2;}}
 if(!count||feeds.mutex->AcquireSync(0,0)!=S_OK)return false;
 D3D11_MAPPED_SUBRESOURCE mapped{};bool ok=SUCCEEDED(deferred->Map(buffer.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&mapped));if(ok){memcpy(mapped.pData,vertices,count*sizeof(Vertex));deferred->Unmap(buffer.Get(),0);auto* r=target.Get();deferred->OMSetRenderTargets(1,&r,sceneDepth);deferred->OMSetBlendState(nullptr,nullptr,~0u);deferred->OMSetDepthStencilState(comparison==D3D11_COMPARISON_GREATER_EQUAL?reverseDepth.Get():depth.Get(),0);deferred->RSSetState(raster.Get());D3D11_VIEWPORT vp{0,0,float(desc.Width),float(desc.Height),minimum,maximum};deferred->RSSetViewports(1,&vp);deferred->IASetInputLayout(layout.Get());deferred->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);UINT stride=sizeof(Vertex),offset=0;auto* b=buffer.Get();deferred->IASetVertexBuffers(0,1,&b,&stride,&offset);deferred->VSSetShader(vs.Get(),nullptr,0);deferred->PSSetShader(ps.Get(),nullptr,0);deferred->GSSetShader(nullptr,nullptr,0);deferred->HSSetShader(nullptr,nullptr,0);deferred->DSSetShader(nullptr,nullptr,0);auto* v=image.Get();auto* s=sampler.Get();deferred->PSSetShaderResources(0,1,&v);deferred->PSSetSamplers(0,1,&s);deferred->Draw(count,0);Ptr<ID3D11CommandList> list;ok=SUCCEEDED(deferred->FinishCommandList(FALSE,&list));if(ok)c->ExecuteCommandList(list.Get(),TRUE);c->Flush();}
 feeds.mutex->ReleaseSync(0);return ok;
 }
};
