#pragma once
#include <windows.h>
inline bool RFGRVR_IsVRLaunch(){wchar_t mode[24]{};DWORD size=GetEnvironmentVariableW(L"RFGRVR_LAUNCH_MODE",mode,24);return size==2&&!_wcsicmp(mode,L"vr");}
