#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <wrl/client.h>
#include <cassert>
using Microsoft::WRL::ComPtr;
int main(){
 WNDCLASSW c{};c.lpfnWndProc=DefWindowProcW;c.hInstance=GetModuleHandleW(nullptr);c.lpszClassName=L"RFGRVRRenderSeparationTest";assert(RegisterClassW(&c));
 RECT r{0,0,1280,720};AdjustWindowRect(&r,WS_OVERLAPPEDWINDOW,FALSE);
 auto w=CreateWindowW(c.lpszClassName,L"",WS_OVERLAPPEDWINDOW,0,0,r.right-r.left,r.bottom-r.top,nullptr,nullptr,c.hInstance,nullptr);assert(w);
 DXGI_SWAP_CHAIN_DESC sc{};sc.BufferDesc.Width=3840;sc.BufferDesc.Height=2160;sc.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;sc.SampleDesc.Count=1;sc.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;sc.BufferCount=1;sc.OutputWindow=w;sc.Windowed=TRUE;sc.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
 ComPtr<IDXGISwapChain> chain;ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;
 assert(SUCCEEDED(D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&sc,&chain,&device,nullptr,&context)));
 for(unsigned pass=0;pass<3;++pass){
  const unsigned width=pass==1?2816:3840,height=pass==1?2944:2160;
  if(pass)assert(SUCCEEDED(chain->ResizeBuffers(0,width,height,DXGI_FORMAT_UNKNOWN,0)));
  ComPtr<ID3D11Texture2D> back;assert(SUCCEEDED(chain->GetBuffer(0,IID_PPV_ARGS(&back))));D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);assert(desc.Width==width&&desc.Height==height);
  GetClientRect(w,&r);assert(r.right==1280&&r.bottom==720);
 }
 chain.Reset();context.Reset();device.Reset();DestroyWindow(w);
}
