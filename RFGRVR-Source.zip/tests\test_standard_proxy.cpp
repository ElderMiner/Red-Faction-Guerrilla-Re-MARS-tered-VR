#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>
#include <cstdio>
int wmain(int argc,wchar_t** argv){if(argc<2)return 1;SetEnvironmentVariableW(L"RFGRVR_LAUNCH_MODE",L"standard");HMODULE proxy=LoadLibraryW(argv[1]);if(!proxy)return 2;using Create=HRESULT(WINAPI*)(HINSTANCE,DWORD,REFIID,LPVOID*,LPUNKNOWN);auto create=(Create)GetProcAddress(proxy,"DirectInput8Create");if(!create)return 3;IDirectInput8A* input=nullptr;HRESULT hr=create(GetModuleHandleW(nullptr),0x0800,IID_IDirectInput8A,(void**)&input,nullptr);if(FAILED(hr)||!input){printf("Native input failure %08X\n",unsigned(hr));return 4;}input->Release();Sleep(150);puts("PASS: Standard-mode candidate DLL loads and forwards native DirectInput creation without VR startup");return 0;}
