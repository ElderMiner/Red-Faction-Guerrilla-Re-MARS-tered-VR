#pragma once
// Included inside RFGRVRWeaponPhysics, after native vehicle resource helpers.
namespace VehicleCalibration {
struct EnterData {unsigned specified=0,method=0,destination=0;unsigned char flags=1,pad[3]{};};
using Enter=bool(__cdecl*)(void*,void*,const EnterData*);using Exit=void(__cdecl*)(void*,const unsigned char*);
inline ULONGLONG nativeClock(){return GetTickCount64();}
inline ULONGLONG(*clock)()=&nativeClock;
inline Enter enter=nullptr;inline Exit exit=nullptr;inline bool(*save)()=nullptr;
inline std::atomic<unsigned> commands{0};inline const char* types[64]{};inline unsigned count=0,index=0,stage=0,retries=0;inline Reload::Object created{};inline ULONGLONG since=0;
inline void build(){count=0;for(auto& type:RFGRVRVehicleTypes){if(type.tank||!strcmp(type.type,"Tharsis_gun")||!strcmp(type.type,"MarsRover1"))continue;bool found=false;for(unsigned i=0;i<count;++i)if(!strcmp(types[i],type.type))found=true;if(!found&&count<64)types[count++]=type.type;}}
inline void stop(const char* reason){RFGRVRVehicleCalibrationActive=false;stage=0;log(reason);vrstatus::notify(reason);}
inline void skip(const char* reason){char message[180];sprintf_s(message,"Calibration skipped %s: %s",types[index],reason);log(message);vrstatus::notify(message);if(++index>=count){stop("Vehicle tour finished; unavailable types were not saved");return;}stage=1;retries=0;since=clock();}
inline void rejected(){if(!RFGRVRVehicleCalibrationActive||stage!=2)return;if(++retries<4){stage=6;since=clock();vrstatus::notify("Vehicle placement blocked; retrying calibration spawn");}else skip("native spawn rejected after four attempts");}
inline void init(){const unsigned char entrySig[]={0xe9,0x6b,0xfa,0xff,0xff};const unsigned char exitSig[]={0x56,0x8b,0x74,0x24,0x08,0x85,0xf6};if(!memcmp(base+0x7b81f0,entrySig,sizeof(entrySig)))enter=(Enter)(base+0x7b81f0);if(!memcmp(base+0x7b6060,exitSig,sizeof(exitSig)))exit=(Exit)(base+0x7b6060);}
inline bool entryReady(void* car){void* info=(void*)(uintptr_t)word(car,0x3514);void* rig=(void*)(uintptr_t)word(info,0x44);void* seats=(void*)(uintptr_t)word(rig,0x10);return memory(info,0x48)&&memory(rig,0x14)&&memory(seats,0x21);}
inline void spawned(void* object,const char* name){if(!RFGRVRVehicleCalibrationActive||stage!=2||strcmp(name,types[index])||!memory(object,0x70))return;created={object,word(object,0x6c)};stage=3;since=clock();}
inline void update(void* player){
 unsigned request=commands.exchange(0);if(request&1){if(RFGRVRVehicleCalibrationActive){stop("Vehicle calibration stopped");return;}build();if(!count||!enter||!exit||!save){vrstatus::notify("Vehicle calibration native functions unavailable");return;}index=0;retries=0;log("Vehicle calibration tour started");RFGRVRVehicleCalibrationActive=true;stage=1;since=clock();}
 if(!RFGRVRVehicleCalibrationActive)return;
 if((request&2)&&stage==4){if(!save()){vrstatus::notify("Vehicle eye height could not save");return;}if(++index>=count){stop("All vehicle eye heights SAVED");return;}stage=1;retries=0;since=clock();}
 unsigned state=word(player,0x2f4);
 if(stage==1){if(state>=7&&state<=10){if(state==8||state==9){unsigned char flags=1;exit(player,&flags);}if(clock()-since>10000)stop("Vehicle exit failed; calibration stopped");return;}
  if(state!=0)return;if(Reload::validObject(created))Reload::erase(created);else created={};
  AcquireSRWLockExclusive(&vehicleMenuLock);strcpy_s(requestedVehicleName,types[index]);vehicleMenuOpen=false;ReleaseSRWLockExclusive(&vehicleMenuLock);vehicleRequestTick=GetTickCount();vehicleRequests.fetch_or(4);stage=2;since=clock();char message[180];sprintf_s(message,"Calibrating %u/%u: %s - loading driver seat",index+1,count,types[index]);log(message);vrstatus::notify(message);
 }else if(stage==6&&clock()-since>=1500){stage=1;since=clock();}
 else if(stage==2){if(clock()-since>35000)skip("resource loading timed out");}
 else if(stage==3&&clock()-since>=500){if(!Reload::validObject(created)){stop("Calibration vehicle disappeared");return;}if(!entryReady(created.ptr)){if(clock()-since>15000)skip("native seat resources unavailable");return;}EnterData data{};if(!enter(player,created.ptr,&data)){skip("native entry refused");return;}stage=5;since=clock();}
 else if(stage==5){if(state==9&&word(player,0xac4)==created.handle){stage=4;char message[180];sprintf_s(message,"%u/%u %s: adjust eye height, NUM * saves/next",index+1,count,types[index]);vrstatus::notify(message);}else if(clock()-since>10000)skip("driver seat entry timed out");}
}
}


