#define CINTERFACE
#include <d3d11.h>
#include <stddef.h>
#include <stdio.h>
int main(){printf("CreateDeferredContext=%zu FinishCommandList=%zu OMSetRTUAV=%zu IASetVB=%zu IASetIB=%zu OMSetBlend=%zu OMSetDepth=%zu PSSetSRV=%zu\\n",offsetof(ID3D11DeviceVtbl,CreateDeferredContext)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,FinishCommandList)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,OMSetRenderTargetsAndUnorderedAccessViews)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,IASetVertexBuffers)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,IASetIndexBuffer)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,OMSetBlendState)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,OMSetDepthStencilState)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,PSSetShaderResources)/sizeof(void*));printf("DrawAuto=%zu IndexedIndirect=%zu InstancedIndirect=%zu Dispatch=%zu DispatchIndirect=%zu ExecuteCommandList=%zu\n",offsetof(ID3D11DeviceContextVtbl,DrawAuto)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,DrawIndexedInstancedIndirect)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,DrawInstancedIndirect)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,Dispatch)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,DispatchIndirect)/sizeof(void*),offsetof(ID3D11DeviceContextVtbl,ExecuteCommandList)/sizeof(void*));}


