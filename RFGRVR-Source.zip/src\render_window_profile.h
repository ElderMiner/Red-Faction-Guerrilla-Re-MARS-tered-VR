#pragma once
#include <windows.h>
#include <atomic>
#include <cstdio>
#include "vr_user_settings.h"
namespace RFGRVRRenderWindow {
inline HWND window=nullptr;inline WNDPROC original=nullptr;
inline std::atomic<unsigned> width{0},height{0};
inline unsigned desktopWidth=1280,desktopHeight=720;
inline bool desktopEnabled=true;
inline SIZE mirrorSize(unsigned w,unsigned h,bool enabled){if(!enabled)return {320,180};if(!w||!h)return {960,720};RECT work{};SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);unsigned maxH=(std::max)(360L,(work.bottom-work.top)*3/4),maxW=(std::max)(640L,(work.right-work.left)*3/4);float scale=(std::min)(float(maxW)/w,float(maxH)/h);return {LONG(w*scale),LONG(h*scale)};}
inline unsigned baseWidth=0,baseHeight=0;inline ULONGLONG nextPoll=0;
inline constexpr UINT requestMessage=WM_APP+0x471;inline constexpr WPARAM requestMagic=0x52464756;
inline thread_local bool applying=false;
inline void(*settingsBack)()=nullptr;inline constexpr UINT settingsBackMessage=WM_APP+0x472;
// Optional gameplay/menu profiles. Resize through the engine on its owner
// thread; desktop dimensions never become the render-buffer dimensions.
inline bool (*gameplayActive)()=nullptr;
inline bool (*resizeBuffers)(unsigned,unsigned)=nullptr;
inline bool resizePending=false;inline bool (*ppdSize)(int,unsigned*,unsigned*)=nullptr;
inline bool profilePath(wchar_t (&path)[MAX_PATH],const wchar_t* name){GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(!slash)return false;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),name);return true;}
inline SIZE outerSize(HWND hwnd,unsigned w,unsigned h){RECT r{0,0,LONG(w),LONG(h)};AdjustWindowRectEx(&r,DWORD(GetWindowLongPtrW(hwnd,GWL_STYLE)),GetMenu(hwnd)!=nullptr,DWORD(GetWindowLongPtrW(hwnd,GWL_EXSTYLE)));return {r.right-r.left,r.bottom-r.top};}
inline LRESULT CALLBACK procedure(HWND hwnd,UINT message,WPARAM wp,LPARAM lp){
 if(message==settingsBackMessage&&wp==requestMagic){if(settingsBack)settingsBack();return 0;}
 if(message==requestMessage&&wp==requestMagic){
  // Device rebuilds can pump window messages. Coalesce a nested request
  // instead of rebuilding the render targets again on the same stack.
  if(applying)return 0;
  const unsigned w=width.load(),h=height.load();const auto size=outerSize(hwnd,w?desktopWidth:baseWidth,h?desktopHeight:baseHeight);
  applying=true;BOOL ok=SetWindowPos(hwnd,nullptr,0,0,size.cx,size.cy,SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);
  if(resizePending&&resizeBuffers&&resizeBuffers(w,h)&&width.load()==w&&height.load()==h)resizePending=false;
  applying=false;
  RECT client{};GetClientRect(hwnd,&client);wchar_t path[MAX_PATH]{};if(profilePath(path,L"RFGRVR-Render-Size.log")){FILE* f=nullptr;if(!_wfopen_s(&f,path,L"a")&&f){fprintf(f,"requested=%ux%u accepted=%d client=%ldx%ld\n",w,h,ok,client.right,client.bottom);fclose(f);}}
  return 0;
 }
 LRESULT result=CallWindowProcW(original,hwnd,message,wp,lp);
 // Alt-tab restores activation, but the native input child can retain no
 // keyboard/mouse focus. Reacquire on the window's own activation thread.
 if((message==WM_ACTIVATE&&LOWORD(wp)!=WA_INACTIVE)||(message==WM_ACTIVATEAPP&&wp)){DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);if(pid==GetCurrentProcessId()&&!IsIconic(hwnd))SetFocus(hwnd);}

 const unsigned w=width.load(),h=height.load();
 if(w&&h&&message==WM_GETMINMAXINFO){auto* info=(MINMAXINFO*)lp;auto size=outerSize(hwnd,desktopWidth,desktopHeight);if(info->ptMaxTrackSize.x<size.cx)info->ptMaxTrackSize.x=size.cx;if(info->ptMaxTrackSize.y<size.cy)info->ptMaxTrackSize.y=size.cy;}
 if(w&&h&&message==WM_WINDOWPOSCHANGING&&!IsIconic(hwnd)){auto* pos=(WINDOWPOS*)lp;if(!(pos->flags&SWP_NOSIZE)){auto size=outerSize(hwnd,desktopWidth,desktopHeight);pos->cx=size.cx;pos->cy=size.cy;}}
 return result;
}
inline void poll(){
 if(!window)return;auto now=GetTickCount64();if(now<nextPoll)return;nextPoll=now+1000;
 wchar_t path[MAX_PATH]{};unsigned w=0,h=0,mw=0,mh=0;FILE* file=nullptr;
 if(profilePath(path,L"RFGRVR-render-size.txt")&&!_wfopen_s(&file,path,L"r")&&file){int fields=fscanf_s(file,"%u %u %u %u",&w,&h,&mw,&mh);if(fields<2)w=h=0;else if(fields==4&&gameplayActive&&!gameplayActive()){w=mw;h=mh;}fclose(file);}
 int ppd=vrsettings::get().value[vrsettings::PPD];if(ppd&&ppdSize&&(!gameplayActive||gameplayActive())){unsigned pw=0,ph=0;if(ppdSize(ppd,&pw,&ph)){w=pw;h=ph;}}
 if(w<640||h<360||w>8192||h>8192||static_cast<unsigned long long>(w)*h>32000000)w=h=0;
 bool visible=vrsettings::get().value[vrsettings::Desktop]!=0;SIZE desired=mirrorSize(w,h,visible);bool desktopChanged=desktopWidth!=unsigned(desired.cx)||desktopHeight!=unsigned(desired.cy);desktopWidth=desired.cx;desktopHeight=desired.cy;desktopEnabled=visible;
 const bool changed=w!=width.load()||h!=height.load();width=w;height=h;
 if((changed||desktopChanged)&&w&&h)resizePending=true;
 if(changed||desktopChanged||resizePending)PostMessageW(window,requestMessage,requestMagic,0);
}
inline void attach(HWND hwnd){
 if(window||!hwnd)return;RECT r{};GetClientRect(hwnd,&r);baseWidth=r.right;baseHeight=r.bottom;
 SetLastError(0);auto prior=(WNDPROC)SetWindowLongPtrW(hwnd,GWLP_WNDPROC,(LONG_PTR)procedure);if(!prior)return;original=prior;window=hwnd;poll();
}
inline bool ready(unsigned sourceWidth,unsigned sourceHeight){return width.load()!=0&&sourceWidth==width.load()&&sourceHeight==height.load();}
}

