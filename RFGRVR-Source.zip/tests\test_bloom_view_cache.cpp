#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../src/vr_bloom_view_cache.h"
using namespace RFGRVRBloomViewCache;
static unsigned char compositor[0xbac]{},managerStorage[0x700]{};
static unsigned sources=0,exposures=0;static bool useAdaptation=true;
static void put(void* p,unsigned off,unsigned v){memcpy((char*)p+off,&v,4);}
static void __fastcall Exposure(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f){assert(a==1&&f==6);++exposures;put(self,0xba8,currentFrame());}
static void __fastcall Source(void* self,void*,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g){
 assert(a==1&&b==2&&c==3&&d==4&&e==5&&f==6&&g==0x76543210);
 if(RFGRVREffectGeometry::word(self,0xba8)!=currentFrame()){
  ++sources;if(useAdaptation)onAdaptation(self,nullptr,a,b,c,d,e,f);
 }
}
static SourcePass volatile nativeEntry=(SourcePass)&onDownsample;
static __declspec(noinline) void run(int eye){
 RFGRVREffectGeometry::eye=eye;uintptr_t before=0,after=0;
 __asm mov before,esp
 nativeEntry(compositor,1,2,3,4,5,6,0x76543210);
 __asm mov after,esp
 assert(before==after);
}
int main(){void* m=managerStorage;manager=&m;downsample=(SourcePass)Source;adaptation=(ExposurePass)Exposure;put(managerStorage,0x6dc,100);
 run(0);assert(sources==1&&exposures==1);run(1);assert(sources==2&&exposures==1&&retainedExposure==1);assert(RFGRVREffectGeometry::word(compositor,0xba8)==100&&!refreshing);
 // Ordinary rendering and repeated first-eye work retain the engine's cache.
 run(-1);run(0);assert(sources==2&&exposures==1);
 put(managerStorage,0x6dc,101);run(0);run(1);assert(sources==4&&exposures==2);
 // A stale right-eye cache follows the original initialization path.
 put(managerStorage,0x6dc,102);run(1);assert(sources==5&&exposures==3);
 // With adaptation disabled, refreshing the image must still publish its stamp.
 useAdaptation=false;run(1);assert(sources==6&&exposures==3&&RFGRVREffectGeometry::word(compositor,0xba8)==102);
 put(managerStorage,0x6dc,0);put(compositor,0xba8,0);run(1);assert(sources==7&&RFGRVREffectGeometry::word(compositor,0xba8)==0);
 manager=nullptr;run(-1);
}
