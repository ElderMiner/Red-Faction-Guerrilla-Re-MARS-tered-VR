#pragma once
#include "vr_ribbon_cloth.h"
// Included inside the local-player weapon rendering implementation. Native
// simulation/model arrays and the shared Gutter asset are never modified.
namespace GutterCloth {
inline SRWLOCK lock=SRWLOCK_INIT;
inline std::atomic<void*> renderer{nullptr};
inline void* object=nullptr;inline unsigned handle=~0u,count=0;inline int bone[12]{};
inline vrribbon::Cloth cloth;inline Pose palette[128]{};inline ULONGLONG tick=0;
inline bool copy(void* target,const Pose* source,unsigned n){
 if(renderer.load(std::memory_order_relaxed)!=target||!source||n!=14||!paletteCopy)return false;
 Pose output[128];memcpy(output,source,n*48);AcquireSRWLockShared(&lock);
 bool valid=renderer==target&&count==n&&owned(object)&&word(object,0x6c)==handle&&GetTickCount64()-tick<250;
 if(valid)for(unsigned i=0;i<12;++i)output[bone[i]]=palette[bone[i]];
 ReleaseSRWLockShared(&lock);if(valid)paletteCopy(target,output,n);return valid;
}
inline void update(void* item,const Pose& root){
 const char* name=(const char*)pointer(pointer(item,0x148),0);
 if(!memory(name,8)||strcmp(name,"gutter"))return;
 void* character=pointer(item,0xbc);int id=int(word(character,0));if(id<0)return;
 void* instance=base+0x35acbd0+(id%356)*0x410;void* rig=pointer(instance,0x18);
 unsigned n=word(rig,0x24);auto* bones=(unsigned char*)pointer(rig,0x38);auto* map=(signed char*)pointer(instance,0x124);
 auto* model=(Pose*)pointer(instance,4);auto* skin=(Pose*)pointer(instance,0);void* target=pointer(character,0x30);
 if(n!=14||!memory(bones,n*36)||!memory(map,n+12)||!memory(model,n*48)||!memory(skin,n*48)||!memory(target,0x12c))return;
 AcquireSRWLockExclusive(&lock);auto now=GetTickCount64();
 if(object!=item||handle!=word(item,0x6c)){
  renderer=nullptr;object=item;handle=word(item,0x6c);count=0;cloth={};for(int& index:bone)index=-1;
  for(unsigned logical=0;logical<n;++logical){int physical=map[logical+12];if(physical<0||physical>=int(n))continue;const char* label=(const char*)(bones+physical*36+(int)word(bones+physical*36,0));
   if(!memory(label,12)||strncmp(label,"Ribbon",6)||(label[6]!='A'&&label[6]!='B')||label[7]!='_'||label[8]!='0'||label[9]<'1'||label[9]>'6')continue;
   unsigned node=(label[9]-'1')*2+(label[6]=='B');bone[node]=int(logical);V bind{};memcpy(&bind,bones+physical*36+4,12);cloth.rest[node]=mul(bind,-1);
  }
  bool complete=true;for(int index:bone)complete=complete&&index>=0;if(!complete){object=nullptr;ReleaseSRWLockExclusive(&lock);return;}count=n;tick=now;cloth.reset(root);
 }
 cloth.update(root,float(now-tick)/1000.f);tick=now;memcpy(palette,skin,n*48);
 for(unsigned i=0;i<12;++i){unsigned b=bone[i],other=bone[i<10?i+2:i-2];V from=sub(model[other].p,model[b].p),to=local(root.b,sub(cloth.point[i<10?i+2:i-2],cloth.point[i]));Pose p{rotateTo(model[b].b,from,to),local(root.b,sub(cloth.point[i],root.p))};V bind{};memcpy(&bind,bones+map[b+12]*36+4,12);palette[b]={p.b,add(p.p,world(p.b,bind))};}
 renderer=target;ReleaseSRWLockExclusive(&lock);copy(target,skin,n);
}
}
