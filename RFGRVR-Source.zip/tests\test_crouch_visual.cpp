#include "../src/vr_crouch_visual.h"
#include "../src/vr_body_height.h"
#include <cassert>
#include "../src/vr_pose_transition.h"
#include "../src/vr_crouch_torso.h"
using namespace vrarm;
int main(){RFGRVRCrouchVisual blend;assert(blend.update(0,0,.01f,true,false,true)==0&&!blend.active);float previous=0;for(int i=0;i<90;++i){float next=blend.update(-.3f,0,1.f/90,true,true,true);assert(next<=previous&&next>-.301f&&fabsf(next-previous)<.06f);previous=next;}assert(fabsf(previous+.3f)<.001f);float threshold=blend.update(-.3f,-.5f,1.f/90,true,true,true);assert(fabsf(threshold-previous)<.001f);for(int i=0;i<120;++i)blend.update(0,0,1.f/90,true,false,true);assert(!blend.active&&fabsf(blend.offset)<.002f);blend.update(-.5f,-.2f,.01f,false,true,true);assert(!blend.active&&fabsf(blend.offset+.2f)<.001f);
 // A physically upright player must not be handed back to a still-crouched native pose.
 blend.reset();blend.update(-.4f,-.4f,.01f,true,true,true);previous=blend.offset;
 for(int i=0;i<150;++i){float next=blend.update(0,-.4f,1.f/90,true,false,true);assert(next>=previous&&next-previous<.05f&&blend.active);previous=next;}
 assert(fabsf(previous)<.002f);blend.update(0,0,1.f/90,true,false,true);assert(!blend.active);
 Pose a{M{{1,0,0},{0,1,0},{0,0,1}},{0,0,0}},b{turnAround(a.b,{0,1,0},3.14159265f),{2,4,6}};
 auto midpoint=RFGRVR_BlendPose(a,b,.5f);assert(length(sub(midpoint.p,{1,2,3}))<.0001f);assert(fabsf(length(midpoint.b.r)-1)<.0001f&&fabsf(dot(midpoint.b.r,midpoint.b.f))<.0001f);assert(length(sub(RFGRVR_BlendPose(a,b,0).p,a.p))<.0001f&&length(sub(RFGRVR_BlendPose(a,b,1).p,b.p))<.0001f);
 // Physical partial crouch uses calibrated torso shape/height, independent
 // of native shooting kick. Fingers remain a separate native-animation input.
 {M id{{1,0,0},{0,1,0},{0,0,1}};Pose root{id,{0,.9f,0}},rest{id,{0,1.5f,.1f}};auto stable=RFGRVR_StableCrouchTorso(rest,root,.9f,1.5f,-.15f,id);assert(fabsf(stable.p.y-1.35f)<.0001f&&fabsf(stable.p.x)<.0001f&&fabsf(stable.p.z-.1f)<.0001f&&fabsf(stable.b.u.y-1)<.0001f);}
 // Small dips smoothly lower the head while foot/toe poses remain identical.
 constexpr unsigned n=15;M identity{{1,0,0},{0,1,0},{0,0,1}};V pos[n]={{0,.95f,0},{0,.95f,0},{0,1,0},{0,1.5f,0},{0,1.6f,0},{-.1f,.93f,0},{-.1f,.5f,.05f},{-.1f,.05f,.03f},{-.1f,.03f,.18f},{.1f,.93f,0},{.1f,.5f,.05f},{.1f,.05f,.03f},{.1f,.03f,.18f},{-.4f,1.4f,.3f},{.4f,1.4f,.3f}};int parents[n]={-1,0,1,2,3,1,5,6,7,1,9,10,11,2,2};bool tracked[n]{};tracked[13]=tracked[14]=true;RFGRVRBodyChain chain;chain.root=0;chain.pelvis=1;chain.spine=2;chain.head=4;chain.thigh[0]=5;chain.calf[0]=6;chain.foot[0]=7;chain.thigh[1]=9;chain.calf[1]=10;chain.foot[1]=11;
 for(float drop:{-.03f,-.12f,-.35f,-.6f})for(float native:{0.f,-.2f,-.5f}){Pose p[n];for(unsigned i=0;i<n;++i){p[i]={identity,pos[i]};if(i<7||i==9||i==10)p[i].p.y+=native;}assert(RFGRVR_FitBodyHeight(p,n,parents,chain,tracked,drop-native,.95f+drop*.65f-p[1].p.y));assert(fabsf(p[4].p.y-(1.6f+drop))<.0001f);for(int foot:{7,8,11,12,13,14})assert(length(sub(p[foot].p,pos[foot]))<.0001f);}
}
