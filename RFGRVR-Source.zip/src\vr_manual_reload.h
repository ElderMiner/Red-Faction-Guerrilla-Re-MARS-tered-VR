#pragma once
#include <cstdint>
#include "vr_grip_placement.h"
namespace vrreload {
using namespace vrarm;
// Once accepted by the well, follow its moving frame while seating the prop.
struct Seating {
 bool active=false;uint32_t started=0;Pose localFrom{};
 void begin(const Pose& well,const Pose& magazine,uint32_t now){localFrom=vrgrip::relativePose(well,magazine);started=now;active=true;}
 bool complete(uint32_t now)const{return uint32_t(now-started)>=180;}
 Pose pose(const Pose& well,uint32_t now)const{
  float t=std::fmin(1.f,float(uint32_t(now-started))/180.f);t=t*t*(3-2*t);M identity{{1,0,0},{0,1,0},{0,0,1}},b=localFrom.b;V axis=cross(b.f,identity.f);float angle=acosf(std::fmax(-1.f,std::fmin(1.f,dot(b.f,identity.f))));if(length(axis)<.00001f)axis=b.u;if(angle>.00001f)b=turnAround(b,axis,angle*t);b=turnAround(b,b.f,axialRoll(b,identity,b.f)*t);return vrgrip::worldPose(well,Pose{b,mul(localFrom.p,1-t)});
 }
};
enum class Stage{Locked,Removed,Inserted};
enum class Held{None,Spent,Fresh};
enum Event:unsigned {None=0,Eject=1,Drop=2,Fetch=4,Insert=8,Chamber=16};
struct Input {bool reload=false,rocket=false,autoEjectEmpty=false;float squeeze=0;Pose hand{},magazine{};bool hip=false;float scale=1;int rounds=0,reserve=0,capacity=0;Pose freshLocal{M{{1,0,0},{0,1,0},{0,0,1}},V{}};V magazineCenter{};};
inline Pose gripForBounds(V lo,V hi){V center=mul(add(lo,hi),.5f),extent=sub(hi,lo);int axis=extent.x>extent.y?(extent.x>extent.z?0:2):(extent.y>extent.z?1:2);V longAxis{};((float*)&longAxis)[axis]=1;M b=rotateTo(M{{1,0,0},{0,1,0},{0,0,1}},longAxis,{0,1,0});return {b,mul(world(b,center),-1)};}
inline bool nearHip(V p){return finite(p)&&fabsf(p.x)>.05f&&fabsf(p.x)<.65f&&p.y>.4f&&p.y<1.25f&&fabsf(p.z)<.5f;}
struct PickupHint {bool inside=false;bool update(bool ready,bool nearby){bool now=ready&&nearby,pulse=now&&!inside;inside=now;return pulse;}};
struct State {
 Stage stage=Stage::Locked;Held held=Held::None;bool button=false,grip=false,extracting=false,rocketLoading=false;Pose handLocal{},heldPose{};
 bool canFetch(const Input& in)const{return held==Held::None&&in.reserve>0&&(in.rocket?in.rounds<in.capacity:stage==Stage::Removed);}
 unsigned update(const Input& in){unsigned event=0;bool reload=in.reload&&!button;button=in.reload;bool down=std::isfinite(in.squeeze)&&(grip?in.squeeze>.35f:in.squeeze>.65f),press=down&&!grip;grip=down;
  if(!valid(in.hand.b)||!finite(in.hand.p)||!valid(in.magazine.b)||!finite(in.magazine.p)||!std::isfinite(in.scale)||in.scale<=0)return 0;
  rocketLoading=in.rocket;
  if(in.rocket){stage=Stage::Locked;extracting=false;
   if(held!=Held::None){heldPose=vrgrip::worldPose(in.hand,handLocal);if(!down){held=Held::None;event|=Drop;}else if(held==Held::Fresh&&in.rounds<in.capacity&&in.reserve>0&&length(sub(heldPose.p,in.magazine.p))<.16f*in.scale){held=Held::None;event|=Insert|Chamber;}}
   else if(press&&in.hip&&in.reserve>0&&in.rounds<in.capacity){held=Held::Fresh;handLocal=in.freshLocal;heldPose=vrgrip::worldPose(in.hand,handLocal);event|=Fetch;}
   return event;
  }
  if(in.autoEjectEmpty&&in.rounds<=0&&stage==Stage::Locked){stage=Stage::Removed;held=Held::None;extracting=false;return Eject;}
  if(stage==Stage::Locked){
   if(press&&length(sub(in.hand.p,in.magazine.p))<.12f*in.scale){extracting=true;handLocal=vrgrip::relativePose(in.hand,in.magazine);}
   if(extracting){heldPose=vrgrip::worldPose(in.hand,handLocal);if(!down)extracting=false;else if(length(sub(heldPose.p,in.magazine.p))>.055f*in.scale){stage=Stage::Removed;held=Held::Spent;extracting=false;event|=Eject;}}
   if(reload&&stage==Stage::Locked){stage=Stage::Removed;held=Held::None;extracting=false;event|=Eject|Drop;heldPose=in.magazine;}
  }else if(stage==Stage::Removed){
   if(held!=Held::None){heldPose=vrgrip::worldPose(in.hand,handLocal);
    if(!down){held=Held::None;event|=Drop;}
    else if(held==Held::Fresh&&length(sub(vrgrip::worldPose(heldPose,Pose{M{{1,0,0},{0,1,0},{0,0,1}},in.magazineCenter}).p,vrgrip::worldPose(in.magazine,Pose{M{{1,0,0},{0,1,0},{0,0,1}},in.magazineCenter}).p))<.16f*in.scale){held=Held::None;stage=Stage::Inserted;event|=Insert;}
   }else if(press&&in.hip&&in.reserve>0){held=Held::Fresh;handLocal=in.freshLocal;heldPose=vrgrip::worldPose(in.hand,handLocal);event|=Fetch;}
  }else if(reload){stage=Stage::Locked;event|=Chamber;}
  return event;
 }
 bool empty(int rounds)const{return stage==Stage::Locked&&rounds<=0;}
 bool ghost()const{return (stage==Stage::Removed||rocketLoading)&&held==Held::Fresh;}
};
}

