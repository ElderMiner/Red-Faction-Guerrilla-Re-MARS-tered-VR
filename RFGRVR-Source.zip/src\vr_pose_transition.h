#pragma once
#include "vr_arm_math.h"
#include <algorithm>
inline vrarm::Pose RFGRVR_BlendPose(const vrarm::Pose& from,const vrarm::Pose& to,float weight){
 using namespace vrarm;weight=(std::clamp)(weight,0.f,1.f);if(weight<=0)return from;if(weight>=1)return to;
 M delta=relative(from.b,to.b);float angle=acosf((std::clamp)((delta.r.x+delta.u.y+delta.f.z-1)*.5f,-1.f,1.f));V axis{delta.u.z-delta.f.y,delta.f.x-delta.r.z,delta.r.y-delta.u.x};
 if(length(axis)<.00001f&&angle>.01f){
  if(delta.r.x>=delta.u.y&&delta.r.x>=delta.f.z){axis.x=sqrtf((std::max)(0.f,1+delta.r.x-delta.u.y-delta.f.z))*.5f;axis.y=(delta.u.x+delta.r.y)/(4*(std::max)(axis.x,.0001f));axis.z=(delta.f.x+delta.r.z)/(4*(std::max)(axis.x,.0001f));}
  else if(delta.u.y>=delta.f.z){axis.y=sqrtf((std::max)(0.f,1+delta.u.y-delta.r.x-delta.f.z))*.5f;axis.x=(delta.u.x+delta.r.y)/(4*(std::max)(axis.y,.0001f));axis.z=(delta.f.y+delta.u.z)/(4*(std::max)(axis.y,.0001f));}
  else{axis.z=sqrtf((std::max)(0.f,1+delta.f.z-delta.r.x-delta.u.y))*.5f;axis.x=(delta.f.x+delta.r.z)/(4*(std::max)(axis.z,.0001f));axis.y=(delta.f.y+delta.u.z)/(4*(std::max)(axis.z,.0001f));}
 }
 M rotation=angle<.00001f?from.b:compose(from.b,turnAround(M{{1,0,0},{0,1,0},{0,0,1}},unit(axis),angle*weight));
 return {rotation,add(from.p,mul(sub(to.p,from.p),weight))};
}
