#pragma once
#include <windows.h>
#include <cstdint>
#include <atomic>
// Metadata is cached only during one synchronous owned operation. No pointer
// validity or page protection result survives the outer scope.
namespace vrmemory {
inline std::atomic<unsigned long long> queryTotal{0},hitTotal{0};
struct Cache {MEMORY_BASIC_INFORMATION regions[32]{};unsigned count=0,depth=0,recent=0,victim=0;unsigned long long queries=0,hits=0;};
inline thread_local Cache cache;
struct Scope {Scope(){if(!cache.depth++){cache.count=cache.recent=cache.victim=0;cache.queries=cache.hits=0;}}~Scope(){if(!--cache.depth){queryTotal.fetch_add(cache.queries,std::memory_order_relaxed);hitTotal.fetch_add(cache.hits,std::memory_order_relaxed);cache.count=0;}}};
inline bool check(const void* pointer,size_t bytes,bool write=false){if(!pointer)return false;uintptr_t a=(uintptr_t)pointer;MEMORY_BASIC_INFORMATION region{};bool found=false;
 if(cache.depth&&cache.count){
 auto contains=[&](unsigned i){const auto& item=cache.regions[i];auto b=(uintptr_t)item.BaseAddress;return a>=b&&bytes<=item.RegionSize&&a-b<=item.RegionSize-bytes;};
 if(contains(cache.recent)){region=cache.regions[cache.recent];found=true;++cache.hits;}
 else for(unsigned i=0;i<cache.count;++i)if(i!=cache.recent&&contains(i)){region=cache.regions[i];cache.recent=i;found=true;++cache.hits;break;}
 }
 if(!found){if(cache.depth)++cache.queries;if(!VirtualQuery(pointer,&region,sizeof(region)))return false;if(cache.depth){unsigned slot=cache.count<32?cache.count++:cache.victim++%32;cache.regions[slot]=region;cache.recent=slot;}}
 auto b=(uintptr_t)region.BaseAddress;DWORD p=region.Protect&255;return region.State==MEM_COMMIT&&!(region.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&a>=b&&bytes<=region.RegionSize&&a-b<=region.RegionSize-bytes&&(!write||p==PAGE_READWRITE||p==PAGE_WRITECOPY||p==PAGE_EXECUTE_READWRITE||p==PAGE_EXECUTE_WRITECOPY);
}
}
