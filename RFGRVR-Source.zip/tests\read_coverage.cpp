#include <windows.h>
#define NOMINMAX
#include "../src/vr_display_geometry.h"
#include "../src/ipc.h"
#include <cstdio>
#include <cstdlib>
int main(int argc,char** argv){unsigned bw=3620,bh=1614;float vf=85;if(argc==4){bw=std::strtoul(argv[1],nullptr,10);bh=std::strtoul(argv[2],nullptr,10);vf=std::strtof(argv[3],nullptr);}auto map=OpenFileMappingW(FILE_MAP_READ,FALSE,RFGR_MAP_NAME);if(!map)return 2;auto* s=(RFGRShared*)MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(RFGRShared));if(!s)return 3;float fovs[2][4]{};bool valid=false;for(int n=0;n<20;++n){LONG a=s->stereoSequence;if(a&1)continue;MemoryBarrier();memcpy(fovs[0],s->eyes[0].fov,16);memcpy(fovs[1],s->eyes[1].fov,16);LONG v=s->stereoValid;MemoryBarrier();if(a==s->stereoSequence&&v){valid=true;break;}}RFGRVRCoverage c{};if(!valid||!RFGRVR_CoverageSize(bw,bh,vf,fovs,&c))return 4;printf("%u %u density=%.3f\n",c.width,c.height,c.pixelsPerTangent);for(auto& f:fovs)printf("fov %.6f %.6f %.6f %.6f\n",f[0],f[1],f[2],f[3]);}

