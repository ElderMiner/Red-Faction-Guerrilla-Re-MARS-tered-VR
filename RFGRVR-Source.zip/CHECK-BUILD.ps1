$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$vc=@(
 "$env:ProgramFiles\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvarsall.bat",
 "${env:ProgramFiles(x86)}\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat") | Where-Object { Test-Path $_ } | Select-Object -First 1
if(!$vc){$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe';if(Test-Path $vswhere){$installation=& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath;if($installation){$vc=Join-Path $installation 'VC\Auxiliary\Build\vcvarsall.bat'}}}
if(!$vc){throw 'Visual Studio C++ toolchain missing'}
$mhLib=Join-Path $root 'vendor\libMinHook.x86.lib'
if(!(Test-Path $mhLib)){throw "Missing MinHook link library: $mhLib. Re-extract the full v4.7.1 ZIP."}
New-Item -ItemType Directory -Force -Path (Join-Path $root 'build-check') | Out-Null
$src=Join-Path $root 'src'
$command='call "'+$vc+'" x86 >nul && cl /nologo /EHsc /std:c++17 /O2 /LD /I"'+$src+'" "'+(Join-Path $src 'game.cpp')+'" "'+(Join-Path $src 'game_frame_publisher.cpp')+'" "'+(Join-Path $src 'render_attach.cpp')+'" "'+(Join-Path $src 'rsl_camera_inspector.cpp')+'" "'+(Join-Path $src 'native_head_camera.cpp')+'" "'+(Join-Path $src 'ingame_camera_lab.cpp')+'" "'+(Join-Path $src 'stereo_pass_trace.cpp')+'" "'+(Join-Path $src 'gpu_pipeline_trace.cpp')+'" "'+(Join-Path $src 'stereo_engine_producer.cpp')+'" "'+(Join-Path $src 'temporal_stereo.cpp')+'" "'+(Join-Path $src 'native_render_probe.cpp')+'" "'+(Join-Path $src 'native_camera_diff.cpp')+'" /link /MACHINE:X86 /DEF:"'+(Join-Path $src 'proxy.def')+'" user32.lib gdi32.lib d3d11.lib dxgi.lib d3dcompiler.lib /LIBPATH:"'+(Join-Path $root 'vendor')+'" libMinHook.x86.lib /MAP:"'+(Join-Path $root 'build-check\dinput8.map')+'" /OUT:"'+(Join-Path $root 'build-check\dinput8.dll')+'"'
$command=$command.Replace(' /link ',(' "'+(Join-Path $src 'native_scene.cpp')+'" "'+(Join-Path $src 'gamepad_input.cpp')+'" "'+(Join-Path $src 'native_arms.cpp')+'" "'+(Join-Path $src 'stereo_ring_lifetime.cpp')+'" /link '))
cmd.exe /d /c $command 2>&1 | Tee-Object (Join-Path $root 'build-check\build.log')
if($LASTEXITCODE -ne 0){throw 'Build failed; see build-check\build.log'}
Write-Host 'SUCCESS: game-side DLL compiled with native in-game camera lab and RSL hook. Runtime behavior not yet verified.'

