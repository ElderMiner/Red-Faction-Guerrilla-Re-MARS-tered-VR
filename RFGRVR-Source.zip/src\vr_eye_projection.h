#pragma once
// OpenXR asymmetrical eye projection in D3D clip space (z from 0 to 1).
// Column-major storage: p[col*4+row]. Right-handed view, -Z forward.
// This component is CPU-only and independent of RFGR's unresolved camera ABI.
#include <cmath>
#include <cstdint>

struct RFGRVREyeProjection {
    float columnMajor[16];
};
// A centered source frustum covering every headset ray at the source aspect.
// Keeps legacy screen-space lighting on its native projection convention.
inline bool RFGRVR_CenteredSourceFov(const float eyes[2][4],unsigned width,unsigned height,float* degrees){
    if(!eyes||!width||!height||!degrees)return false;
    float aspect=float(width)/height,extent=0;
    for(unsigned e=0;e<2;++e){
        // Validate both complete frusta before using their extrema.
        if(!(eyes[e][0]<0&&eyes[e][1]>0&&eyes[e][2]>0&&eyes[e][3]<0))return false;
        for(unsigned i=0;i<4;++i){float a=eyes[e][i];if(!std::isfinite(a)||std::fabs(a)>1.5f)return false;
            float t=std::fabs(std::tan(a));if(i<2)t/=aspect;if(t>extent)extent=t;}}
    *degrees=2.f*std::atan(extent*1.03f)*57.295779513f;
    return std::isfinite(*degrees)&&*degrees>0&&*degrees<175;
}
inline bool RFGRVR_BuildD3DProjection(const float angles[4], float nearZ, float farZ,
                                      RFGRVREyeProjection* out) {
    if (!angles || !out || !std::isfinite(nearZ) || !std::isfinite(farZ) ||
        nearZ <= 0.f || farZ <= nearZ) return false;
    // OpenXR order: angleLeft, angleRight, angleUp, angleDown.
    for (unsigned i=0;i<4;++i)
        if (!std::isfinite(angles[i]) || std::fabs(angles[i]) >= 1.55f) return false;
    const float l=std::tan(angles[0]), r=std::tan(angles[1]);
    const float u=std::tan(angles[2]), d=std::tan(angles[3]);
    if (!(l<r && d<u && l<0 && r>0 && d<0 && u>0)) return false;
    const float invX=1.f/(r-l), invY=1.f/(u-d);
    float m[16]{};
    m[0]=2.f*invX;
    m[5]=2.f*invY;
    m[8]=(r+l)*invX;
    m[9]=(u+d)*invY;
    m[10]=-farZ/(farZ-nearZ);
    m[11]=-1.f;
    m[14]=-(farZ*nearZ)/(farZ-nearZ);
    for (unsigned i=0;i<16;++i) out->columnMajor[i]=m[i];
    return true;
}

// RFGR's actual +0xC0 projection uses positive view-space Z (verified live).
// Convert the existing XR right-handed projection by reflecting its input Z.
// This also changes the signs of asymmetric horizontal/vertical offsets.
// This helper does not install projection/culling hooks or render an eye.
inline bool RFGRVR_BuildEngineProjection(const float angles[4], float nearZ, float farZ,
                                        RFGRVREyeProjection* out) {
    if (!RFGRVR_BuildD3DProjection(angles,nearZ,farZ,out)) return false;
    for(unsigned row=0;row<4;++row)out->columnMajor[8+row]=-out->columnMajor[8+row];
    return true;
}
