$ErrorActionPreference='Stop'
# Embed only our authored HLSL. Native captures/bytecode never enter this step.
$items=@(
 @('modern_optics','modernoptics','source','OPTICS'),
 @('modern_reflectivity_sampling','modernreflectivity','samplingSource','REFLECTIVITY'),
 @('modern_sky_material','modernskymaterial','source','SKYMATERIAL'),
 @('modern_height_sampling','modernheight','samplingSource','HEIGHTS'),
 @('modern_world_sampling','modernmaterial','samplingSource','WORLD'),
 @('modern_surface','modernsurface','source','SURFACE'),
 @('modern_generated','moderngenerated','source','GENERATED'),
 @('modern_probe_projection','modernindirect','projectionSource','PROBE'),
 @('modern_histogram','modernpolicy','histogramSource','METER'),
 @('modern_reflections','modernreflection','reflectionSource','REFLECT'),
 @('modern_reflection_brdf','modernreflection','brdfSource','BRDF'),
 @('modern_sky','modernsky','skySource','SKY')
)
foreach($item in $items){
 $source=Join-Path $PSScriptRoot ('src/'+$item[0]+'.hlsl')
 $target=Join-Path $PSScriptRoot ('src/'+$item[0]+'_source.h')
 $hlsl=[IO.File]::ReadAllText($source)
 if($item[0] -in @('modern_surface','modern_generated','modern_sky_material')){$hlsl=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'src/modern_world_sampling.hlsl'))+"`n"+$hlsl}
 if($item[0] -eq 'modern_generated'){$prefix=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'src/modern_world_sampling.hlsl'));$hlsl=$prefix+"`n"+[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'src/modern_height_sampling.hlsl'))+"`n"+[IO.File]::ReadAllText($source)}
 if($item[0] -in @('modern_surface','modern_generated','modern_sky_material')){$hlsl=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'src/modern_optics.hlsl'))+"`n"+[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'src/modern_reflectivity_sampling.hlsl'))+"`n"+$hlsl}
 if($hlsl.Contains((')'+$item[3]+'"'))){throw ('Raw-string delimiter collision: '+$source)}
 $literals=@();for($at=0;$at -lt $hlsl.Length;$at+=8000){$chunk=$hlsl.Substring($at,[Math]::Min(8000,$hlsl.Length-$at));$literals+=('R"'+$item[3]+'('+$chunk+')'+$item[3]+'"')}
 $text='#pragma once'+"`n"+'namespace '+$item[1]+' {inline constexpr char '+$item[2]+'[]='+"`n"+($literals -join "`n")+';}'+"`n"
 if(!(Test-Path -LiteralPath $target) -or [IO.File]::ReadAllText($target) -cne $text){[IO.File]::WriteAllText($target,$text,[Text.UTF8Encoding]::new($false))}
}
# Keep legacy authored shader literals self-contained for their native factories.
foreach($entry in @(@('modern_lighting','MODERN'),@('modern_terrain','TERRAIN'),@('modern_glass','GLASS'))){
 $path=Join-Path $PSScriptRoot ('src/'+$entry[0]+'.h');$text=[IO.File]::ReadAllText($path)
 $text=[regex]::Replace($text,'(?s)// OPTICAL_HELPERS_BEGIN.*?// OPTICAL_HELPERS_END\r?\n','')
 $marker='R"'+$entry[1]+'('; $start=$text.IndexOf($marker);if($start -lt 0){throw 'Missing authored shader literal'}
 $helpers="`n// OPTICAL_HELPERS_BEGIN`n"+[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'src/modern_optics.hlsl'))+"`n"+[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'src/modern_reflectivity_sampling.hlsl'))+"`n// OPTICAL_HELPERS_END`n"
 $text=$text.Insert($start+$marker.Length,$helpers);[IO.File]::WriteAllText($path,$text,[Text.UTF8Encoding]::new($false))
}
$volume=Join-Path $PSScriptRoot 'src/modern_volumetrics.h'
$text=[IO.File]::ReadAllText($volume)
$start=$text.IndexOf('R"VOLUME(');$end=$text.IndexOf(')VOLUME";',$start)
if($start -lt 0 -or $end -lt 0){throw 'Missing volumetric source delimiter'}
$shader=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'src/modern_volumetrics.hlsl'))
$next=$text.Substring(0,$start+9)+"`n"+$shader+"`n"+$text.Substring($end)
if($next -cne $text){[IO.File]::WriteAllText($volume,$next,[Text.UTF8Encoding]::new($false))}
