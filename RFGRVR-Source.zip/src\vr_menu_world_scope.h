#pragma once
#include <cstdint>
#include <cstring>
inline bool RFGRVRMenuGeometrySignature(const uint8_t* read,const uint8_t* retain,uint32_t readAddress,uint32_t retainAddress){
 uint32_t a=0,b=0;memcpy(&a,read+2,4);memcpy(&b,retain+2,4);
 return read[0]==0x80&&read[1]==0x3d&&read[6]==0&&retain[0]==0x80&&retain[1]==0x3d&&retain[6]==0&&a==readAddress&&b==retainAddress;
}
// Flag 1 routes postprocessing into the pause snapshot (160DE3/161337);
// flag 2 replays that snapshot without geometry. Both must be disabled for
// an eye render. Clearing only 2 renders new geometry offscreen while the
// swapchain still contains the old menu image. Simulation remains paused.
struct RFGRVRMenuWorldScope {
 uint32_t* flags=nullptr;uint32_t saved=0;
 RFGRVRMenuWorldScope(uint32_t* value,bool active){if(active&&value){flags=value;saved=*flags&3u;*flags&=~3u;}}
 ~RFGRVRMenuWorldScope(){if(flags)*flags=(*flags&~3u)|saved;}
 RFGRVRMenuWorldScope(const RFGRVRMenuWorldScope&)=delete;
 RFGRVRMenuWorldScope& operator=(const RFGRVRMenuWorldScope&)=delete;
};
// Paused scenes reuse a cached command queue, which contains the first eye's
// view. Borrow that queue unchanged and let each eye build/release its own
// temporary queue through the ordinary engine path (retention disabled).
struct RFGRVRMenuGeometryScope {
 uint8_t* state=nullptr;uint8_t saved[3]{};uint32_t* queue=nullptr;uint32_t borrowed=0;
 RFGRVRMenuGeometryScope(uint8_t* retain,uint32_t* cachedQueue,bool active){
  if(active&&retain&&cachedQueue){state=retain;queue=cachedQueue;borrowed=*queue;
   saved[0]=state[0];saved[1]=state[3];saved[2]=state[4];
   state[0]=state[3]=state[4]=0;*queue=0;}
 }
 ~RFGRVRMenuGeometryScope(){if(state){state[0]=saved[0];state[3]=saved[1];state[4]=saved[2];*queue=borrowed;}}
};
