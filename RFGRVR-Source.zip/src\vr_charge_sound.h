#pragma once
#include <windows.h>
#include <xaudio2.h>
#include <cmath>
#include <algorithm>
// One bounded mono source. Both tone playback and its world position survive release.
struct RFGRVRChargeSound {
 SRWLOCK lock=SRWLOCK_INIT;IXAudio2* engine=nullptr;IXAudio2MasteringVoice* output=nullptr;IXAudio2SourceVoice* voice=nullptr;
 HMODULE module=nullptr;short samples[44100]{};float source[3]{},listener[3]{},right[3]{1,0,0},scale=1;
 bool initialize(){if(voice)return true;if(!module)module=LoadLibraryW(L"xaudio2_9.dll");if(!module)return false;using Create=HRESULT(WINAPI*)(IXAudio2**,UINT32,XAUDIO2_PROCESSOR);auto create=(Create)GetProcAddress(module,"XAudio2Create");if(!create)return false;
 if(!engine&&FAILED(create(&engine,0,XAUDIO2_DEFAULT_PROCESSOR)))return false;
 if(!output&&FAILED(engine->CreateMasteringVoice(&output,2,44100)))return false;
 WAVEFORMATEX fmt{};fmt.wFormatTag=WAVE_FORMAT_PCM;fmt.nChannels=1;fmt.nSamplesPerSec=44100;fmt.wBitsPerSample=16;fmt.nBlockAlign=2;fmt.nAvgBytesPerSec=88200;
 return SUCCEEDED(engine->CreateSourceVoice(&voice,&fmt));}
 void spatial(){if(!voice||!output)return;float d[3],distance=0,pan=0;for(unsigned i=0;i<3;++i){d[i]=(source[i]-listener[i])/scale;distance+=d[i]*d[i];pan+=d[i]*right[i];}distance=sqrtf(distance);pan=distance>.01f?(std::max)(-1.f,(std::min)(1.f,pan/distance)):0;float gain=.7f/(1+.25f*distance),matrix[2]={gain*sqrtf((1-pan)*.5f),gain*sqrtf((1+pan)*.5f)};voice->SetOutputMatrix(output,1,2,matrix);}
 void position(const float p[3]){if(!TryAcquireSRWLockExclusive(&lock))return;memcpy(source,p,12);spatial();ReleaseSRWLockExclusive(&lock);}
 void hear(const float p[3],const float r[3],float units){if(!TryAcquireSRWLockExclusive(&lock))return;memcpy(listener,p,12);memcpy(right,r,12);scale=units>.1f?units:1;spatial();ReleaseSRWLockExclusive(&lock);}
 void stop(){AcquireSRWLockExclusive(&lock);if(voice){voice->Stop();voice->FlushSourceBuffers();}ReleaseSRWLockExclusive(&lock);}
 bool play(unsigned ms){AcquireSRWLockExclusive(&lock);bool ok=initialize();if(ok){voice->Stop();voice->FlushSourceBuffers();unsigned frames=(std::min)(44100u,44100u*ms/1000);double phase=0;for(unsigned i=0;i<frames;++i){unsigned segment=i*3/frames;double elapsed=(double(i)-double(segment)*frames/3)/44100.,length=double(frames)/3/44100.;double envelope=(std::min)(1.,elapsed/.012)*(std::min)(1.,(length-elapsed)/.022);phase+=6.283185307179586*(segment<2?440.:740.)/44100.;samples[i]=short(4200*envelope*(sin(phase)+.18*sin(phase*2)));}XAUDIO2_BUFFER b{};b.Flags=XAUDIO2_END_OF_STREAM;b.AudioBytes=frames*2;b.pAudioData=(BYTE*)samples;spatial();ok=SUCCEEDED(voice->SubmitSourceBuffer(&b))&&SUCCEEDED(voice->Start());}ReleaseSRWLockExclusive(&lock);return ok;}
 ~RFGRVRChargeSound(){if(voice)voice->DestroyVoice();if(output)output->DestroyVoice();if(engine)engine->Release();if(module)FreeLibrary(module);}
};
