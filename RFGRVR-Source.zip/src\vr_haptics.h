#pragma once
#include "vr_mapping.h"
#include <windows.h>
#include <cstring>
#if defined(RFGR_HAPTICS_TEST)||defined(RFGR_TEST_USER_SETTINGS)
inline constexpr wchar_t RFGR_HAPTICS_MAP[]=L"Local\\RFGRVR_Haptics_TEST_v1";
inline constexpr wchar_t RFGR_MAG_HINT_MAP[]=L"Local\\RFGRVR_MagHint_TEST_v1";
#else
inline constexpr wchar_t RFGR_HAPTICS_MAP[]=L"Local\\RFGRVR_Haptics_v1";
inline constexpr wchar_t RFGR_MAG_HINT_MAP[]=L"Local\\RFGRVR_MagHint_v1";
#endif
struct RFGRHapticPacket {unsigned magic=0x48415031;volatile LONG sequence=0;DWORD tick=0,pid=0;unsigned short motor[2]{};};
struct RFGRHapticWriter {
 const wchar_t* name;explicit RFGRHapticWriter(const wchar_t* channel=RFGR_HAPTICS_MAP):name(channel){}
 HANDLE map=nullptr;RFGRHapticPacket* view=nullptr;SRWLOCK lock=SRWLOCK_INIT;
 void publish(unsigned short left,unsigned short right){AcquireSRWLockExclusive(&lock);if(!view){if(!map)map=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRHapticPacket),name);if(map)view=(RFGRHapticPacket*)RFGRVR_MapViewOrClose(map,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRHapticPacket));}if(view){InterlockedIncrement(&view->sequence);MemoryBarrier();view->magic=0x48415031;view->tick=GetTickCount();view->pid=GetCurrentProcessId();view->motor[0]=left;view->motor[1]=right;MemoryBarrier();InterlockedIncrement(&view->sequence);}ReleaseSRWLockExclusive(&lock);}
};
struct RFGRHapticReader {
 const wchar_t* name;explicit RFGRHapticReader(const wchar_t* channel=RFGR_HAPTICS_MAP):name(channel){}
 HANDLE map=nullptr;RFGRHapticPacket* view=nullptr;
 bool read(DWORD game,RFGRHapticPacket& out){if(!view){if(!map)map=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(map)view=(RFGRHapticPacket*)RFGRVR_MapViewOrClose(map,FILE_MAP_READ,0,0,sizeof(out));}if(!view)return false;for(unsigned n=0;n<3;++n){LONG seq=view->sequence;if(seq&1)continue;MemoryBarrier();memcpy(&out,view,sizeof(out));MemoryBarrier();if(seq==view->sequence)return out.magic==0x48415031&&out.pid==game&&DWORD(GetTickCount()-out.tick)<250;}return false;}
};
