#pragma once
#include "vr_arm_math.h"
#include "vr_body_height.h"
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include <stdexcept>
#include <filesystem>
namespace vrboot {
using namespace vrarm;
struct Bone {char name[48]{};V bind{};int parent=-1;};
struct Packed {V p;unsigned char normal[4],tangent[4],weight[4],joint[4];short uv[2];};static_assert(sizeof(Packed)==32,"Native skinned vertex layout");
struct Vertex {V p,n;float uv[2];};
struct Group {unsigned texture=0,start=0,count=0;};
struct Part {std::vector<Bone> bones;std::vector<Packed> vertices;std::vector<unsigned> indices;std::vector<Group> groups;std::vector<Pose> pose;};
struct Texture {unsigned w=0,h=0,format=0;std::vector<unsigned char> pixels;};
struct Reader {std::ifstream file;template<class Path> explicit Reader(const Path* path):file(std::filesystem::path(path),std::ios::binary){if(!file)throw std::runtime_error("Mason cache unavailable");}void bytes(void* p,size_t n){if(n>16*1024*1024||!file.read((char*)p,n))throw std::runtime_error("Invalid Mason cache");}unsigned word(){unsigned n;bytes(&n,4);return n;}};
inline M identity(){return {{1,0,0},{0,1,0},{0,0,1}};}
inline int named(const Part& p,const char* name){for(unsigned i=0;i<p.bones.size();++i)if(!strcmp(p.bones[i].name,name))return int(i);return -1;}
inline bool descendant(const Part& p,int i,int parent){for(unsigned n=0;n<p.bones.size()&&i>=0&&i<int(p.bones.size());++n){if(i==parent)return true;i=p.bones[i].parent;}return false;}
inline M quaternion(float x,float y,float z,float w){return {{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};}
inline M mirrored(M m){return {{m.r.x,m.r.y,-m.r.z},{m.u.x,m.u.y,-m.u.z},{-m.f.x,-m.f.y,m.f.z}};}
struct Avatar {
 std::vector<Part> parts;std::vector<Texture> textures;V origin{};M yaw=identity();bool anchored=false,matched=false,relaxed=false,lookTargetActive=false;V lookTarget{};float armDrop=1,scale=1;M capturedHand[2]{identity(),identity()};
 template<class Path> bool load(const Path* path){try{Reader r(path);if(r.word()!=0x32415652||r.word()!=4)return false;unsigned np=r.word(),nt=r.word();if(np<1||np>4||nt<1||nt>8)return false;std::vector<Texture> tx(nt);for(auto& t:tx){t.w=r.word();t.h=r.word();t.format=r.word();unsigned bytes=r.word();if(t.w<4||t.h<4||t.w>4096||t.h>4096||(t.format!=71&&t.format!=77)||bytes!=(t.w+3)/4*((t.h+3)/4)*(t.format==77?16:8))return false;t.pixels.resize(bytes);r.bytes(t.pixels.data(),bytes);}std::vector<Part> meshes(np);for(auto& p:meshes){unsigned nb=r.word(),nv=r.word(),ni=r.word(),ng=r.word();if(nb<1||nb>128||nv<1||nv>50000||ni<3||ni>600000||ni%3||ng<1||ng>256)return false;p.bones.resize(nb);p.vertices.resize(nv);p.indices.resize(ni);p.groups.resize(ng);p.pose.resize(nb);for(unsigned i=0;i<nb;++i){r.bytes(&p.bones[i],sizeof(Bone));if(!memchr(p.bones[i].name,0,48)||!finite(p.bones[i].bind)||p.bones[i].parent>=int(i)||p.bones[i].parent< -1)return false;}r.bytes(p.vertices.data(),nv*sizeof(Packed));r.bytes(p.indices.data(),ni*4);r.bytes(p.groups.data(),ng*sizeof(Group));for(unsigned i:p.indices)if(i>=nv)return false;for(auto g:p.groups)if(g.texture>=nt||g.start>ni||g.count>ni-g.start)return false;for(auto v:p.vertices){if(!finite(v.p))return false;for(unsigned k=0;k<4;++k)if(v.weight[k]&&v.joint[k]>=nb)return false;}}textures=std::move(tx);parts=std::move(meshes);return named(parts[0],"head")>=0&&named(parts[0],"l-hand")>=0;}catch(...){return false;}}
 void anchor(V head,M basis){if(anchored)return;float angle=atan2f(basis.f.x,basis.f.z);yaw=turnAround(identity(),{0,1,0},angle);origin={head.x,0,head.z};anchored=true;}
 V tracked(V stage)const{V p=local(yaw,sub(stage,origin));return {p.x/scale,p.y/scale,-p.z/scale};}
 void update(V head,M headBasis,const Pose hands[2],bool follow,float height,float span,float blend=1){if(parts.empty())return;anchor(head,headBasis);if(follow&&!matched){for(unsigned s=0;s<2;++s)capturedHand[s]=mirrored(relative(yaw,hands[s].b));matched=true;}// The preview keeps its existing scale through calibration; no size tween.
 auto& p=parts[0];std::vector<int> parents(p.bones.size());for(unsigned i=0;i<p.bones.size();++i){p.pose[i]={identity(),p.bones[i].bind};parents[i]=p.bones[i].parent;}
 if(follow){RFGRVRBodyChain chain;chain.root=named(p,"root");chain.pelvis=named(p,"pelvis");chain.spine=named(p,"spine");chain.head=named(p,"head");for(int s=0;s<2;++s){chain.thigh[s]=named(p,s?"r-thigh":"l-thigh");chain.calf[s]=named(p,s?"r-calf":"l-calf");chain.foot[s]=named(p,s?"r-foot":"l-foot");}bool trackedBones[128]{};float drop=(std::clamp)((head.y-height)/scale,-.8f,.08f);RFGRVR_FitBodyHeight(p.pose.data(),unsigned(p.pose.size()),parents.data(),chain,trackedBones,drop);int hi=chain.head;M rotation=mirrored(relative(yaw,headBasis));V pivot=p.pose[hi].p;for(unsigned i=0;i<p.pose.size();++i)if(descendant(p,int(i),hi)){p.pose[i].p=add(pivot,world(rotation,sub(p.pose[i].p,pivot)));p.pose[i].b=rotation;}}
 if(lookTargetActive){int hi=named(p,"head");if(hi>=0){V pivot=p.pose[hi].p,target=mul(local(yaw,sub(lookTarget,base())),1/scale);V direction=unit(sub(target,pivot),{0,0,1});M rotation=rotateTo(identity(),{0,0,1},direction);for(unsigned i=0;i<p.pose.size();++i)if(descendant(p,int(i),hi)){p.pose[i].p=add(pivot,world(rotation,sub(p.pose[i].p,pivot)));p.pose[i].b=rotation;}}}
 for(unsigned s=0;s<2;++s){int a=named(p,s?"r-upperarmtwist1":"l-upperarmtwist1"),e=named(p,s?"r-foretwist":"l-foretwist"),h=named(p,s?"r-hand":"l-hand");if(a<0||e<0||h<0)continue;V shoulder=p.pose[a].p,oldE=p.pose[e].p,oldH=p.pose[h].p,newE{},newH{};M baseRotation=rotateTo(identity(),sub(oldE,shoulder),relaxed?unit(V{(s?1.f:-1.f)*(1-armDrop)+ (s?.08f:-.08f)*armDrop,-armDrop,0}):V{s?1.f:-1.f,0,0});M handRotation=baseRotation;
  if(follow){float upper=length(sub(oldE,shoulder)),lower=length(sub(oldH,oldE));float fitted=calibratedReachScale(span/scale,fabsf(p.bones[a].bind.x)*2,upper,lower);oldE=add(shoulder,mul(sub(oldE,shoulder),fitted));oldH=add(oldE,mul(sub(p.pose[h].p,p.pose[e].p),fitted));V targetHand=tracked(hands[s].p);if(!solveTracked(shoulder,oldE,oldH,targetHand,{s?.15f:-.15f,-1,.2f},newE,newH)){newE=oldE;newH=oldH;}handRotation=compose(mirrored(relative(yaw,hands[s].b)),relative(capturedHand[s],baseRotation));}else{newE=add(shoulder,world(baseRotation,sub(oldE,shoulder)));newH=add(shoulder,world(baseRotation,sub(oldH,shoulder)));}
  Pose upperBefore{identity(),shoulder},elbowBefore{identity(),p.pose[e].p},handBefore{identity(),p.pose[h].p};Pose upperAfter{rotateTo(identity(),sub(p.pose[e].p,shoulder),sub(newE,shoulder)),shoulder},elbowAfter{rotateTo(identity(),sub(p.pose[h].p,p.pose[e].p),sub(newH,newE)),newE},handAfter{handRotation,newH};
  for(unsigned i=0;i<p.pose.size();++i)if(descendant(p,int(i),h))p.pose[i]={handAfter.b,add(newH,world(handAfter.b,sub(p.pose[i].p,handBefore.p)))};else if(descendant(p,int(i),e))p.pose[i]=cuffHelper(elbowBefore,handBefore,p.pose[i],elbowAfter,handAfter);else if(descendant(p,int(i),a))p.pose[i]=segmentHelper(upperBefore,elbowBefore,p.pose[i],upperAfter,elbowAfter,false);p.pose[a]=upperAfter;p.pose[e]=elbowAfter;p.pose[h]=handAfter;
 }
 for(unsigned part=1;part<parts.size();++part){auto& q=parts[part];for(unsigned i=0;i<q.bones.size();++i){int same=named(p,q.bones[i].name),parent=q.bones[i].parent;if(same>=0)q.pose[i]={p.pose[same].b,add(p.pose[same].p,world(p.pose[same].b,sub(q.bones[i].bind,p.bones[same].bind)))};else if(parent>=0)q.pose[i]={q.pose[parent].b,add(q.pose[parent].p,world(q.pose[parent].b,sub(q.bones[i].bind,q.bones[parent].bind)))};else q.pose[i]={identity(),q.bones[i].bind};}}
 }
 V base()const{return add(origin,world(yaw,{0,0,-2.5f}));}
 void skin(unsigned part,std::vector<Vertex>& out)const{const auto& p=parts[part];out.resize(p.vertices.size());for(unsigned i=0;i<out.size();++i){const auto& v=p.vertices[i];V position{},normal{},n{(v.normal[0]-127.f)/127.f,(v.normal[1]-127.f)/127.f,(v.normal[2]-127.f)/127.f};float total=0;for(unsigned k=0;k<4;++k){unsigned bone=v.joint[k];float weight=v.weight[k]/255.f;if(!weight||bone>=p.pose.size())continue;position=add(position,mul(add(p.pose[bone].p,world(p.pose[bone].b,sub(v.p,p.bones[bone].bind))),weight));normal=add(normal,mul(world(p.pose[bone].b,n),weight));total+=weight;}if(total<=0){position=v.p;normal=n;}else position=mul(position,1/total);out[i]={add(base(),world(yaw,mul(position,scale))),world(yaw,unit(normal,{0,1,0})),{v.uv[0]/1024.f,v.uv[1]/1024.f}};}}
};
}


