#pragma once
#include "vr_arm_math.h"
struct RFGRVRBodyChain {int root=-1,pelvis=-1,spine=-1,head=-1,thigh[2]{-1,-1},calf[2]{-1,-1},foot[2]{-1,-1},eye[2]{-1,-1};};
inline bool RFGRVR_BodyDescendant(int bone,int parent,const int* parents,unsigned count){
 for(unsigned i=0;i<count&&bone>=0&&unsigned(bone)<count;++i){if(bone==parent)return true;bone=parents[bone];}return false;
}
inline bool RFGRVR_FitBodyHeight(vrarm::Pose* pose,unsigned count,const int* parents,const RFGRVRBodyChain& chain,const bool* tracked,float offset,float fittedPelvis=100.f,bool fitLegs=true){
 using namespace vrarm;if(!count||count>128||!std::isfinite(offset)||offset< -1.1f||offset>1.1f)return false;
 const int indices[10]={chain.root,chain.pelvis,chain.spine,chain.head,chain.thigh[0],chain.thigh[1],chain.calf[0],chain.calf[1],chain.foot[0],chain.foot[1]};
 for(int i:indices)if(i<0||unsigned(i)>=count||!valid(pose[i].b)||!finite(pose[i].p))return false;
 if(fabsf(offset)<.00001f&&(!std::isfinite(fittedPelvis)||fabsf(fittedPelvis)>1.1f||fabsf(fittedPelvis)<.00001f))return false;
 Pose old[128];for(unsigned i=0;i<count;++i)old[i]=pose[i];
 float pelvisDrop=offset*.65f;if(pelvisDrop<-.55f)pelvisDrop=-.55f;if(pelvisDrop>.1f)pelvisDrop=.1f;
 if(std::isfinite(fittedPelvis)&&fabsf(fittedPelvis)<=1.1f)pelvisDrop=fittedPelvis;
 for(unsigned i=0;i<count;++i)if(!tracked[i]){
  if(RFGRVR_BodyDescendant(int(i),chain.spine,parents,count)){
   float height=old[chain.head].p.y-old[chain.pelvis].p.y;
   float t=height>.1f?(old[i].p.y-old[chain.pelvis].p.y)/height:1;if(t<0)t=0;if(t>1)t=1;
   pose[i].p.y+=pelvisDrop+(offset-pelvisDrop)*t;
  }
  else if(fitLegs&&(int(i)==chain.root||int(i)==chain.pelvis||parents[i]==chain.root))pose[i].p.y+=pelvisDrop;
 }
 for(int side=0;fitLegs&&side<2;++side){int a=chain.thigh[side],b=chain.calf[side],c=chain.foot[side];V drop{0,pelvisDrop,0},hip=add(old[a].p,drop),knee{},foot{};
  if(!solveTracked(hip,add(old[b].p,drop),add(old[c].p,drop),old[c].p,{0,0,1},knee,foot))continue;
  pose[a]={rotateTo(old[a].b,sub(old[b].p,old[a].p),sub(knee,hip)),hip};pose[b]={rotateTo(old[b].b,sub(old[c].p,old[b].p),sub(foot,knee)),knee};pose[c]=old[c];
  // Foot/toe targets keep their original floor contact. Other helpers follow
  // the fitted segment, as in the tracked arm solver.
  for(unsigned i=0;i<count;++i)if(int(i)!=a&&int(i)!=b&&int(i)!=c&&!tracked[i]){
   if(RFGRVR_BodyDescendant(int(i),c,parents,count))pose[i]=old[i];
   else if(RFGRVR_BodyDescendant(int(i),b,parents,count))pose[i]=segmentHelper(old[b],old[c],old[i],pose[b],pose[c],true);
   else if(RFGRVR_BodyDescendant(int(i),a,parents,count))pose[i]=segmentHelper(old[a],old[b],old[i],pose[a],pose[b],false);
  }
 }return true;
}
