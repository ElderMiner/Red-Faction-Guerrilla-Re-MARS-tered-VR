#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <vector>

// Diagnostic transaction for render-target contents, not CPU renderer objects.
// Remember each texture before its first left-eye write, and optionally restore
// those contents before the right eye. No engine ownership/refcounts are edited.
class RFGRVREyeResources {
 using Resource=Microsoft::WRL::ComPtr<ID3D11Resource>;
 using Texture=Microsoft::WRL::ComPtr<ID3D11Texture2D>;
 struct Entry {Resource source,saved;};
 std::vector<Entry> entries;
 ID3D11DeviceContext* context=nullptr;
 bool recording=false,good=true;unsigned kinds=1;
 unsigned copies=0;
public:
 bool observingBuffers()const{return recording&&good&&(kinds&2);}
 void begin(ID3D11DeviceContext* c,unsigned types=1){entries.clear();context=c;recording=c!=nullptr;good=recording;copies=0;kinds=types;}
 void observe(ID3D11View* view){
  if(!recording||!good||!(kinds&1)||!view)return;
  Resource resource;view->GetResource(&resource);
  for(auto& entry:entries)if(entry.source.Get()==resource.Get())return;
  if(entries.size()>=32){good=false;return;}
  Texture texture;
  if(FAILED(resource.As(&texture))){good=false;return;}
  D3D11_TEXTURE2D_DESC d{};texture->GetDesc(&d);
  d.Usage=D3D11_USAGE_DEFAULT;d.BindFlags=0;d.CPUAccessFlags=0;d.MiscFlags=0;
  Microsoft::WRL::ComPtr<ID3D11Device> device;context->GetDevice(&device);
  Texture saved;if(FAILED(device->CreateTexture2D(&d,nullptr,&saved))){good=false;return;}
  context->CopyResource(saved.Get(),resource.Get());
  Resource backup;saved.As(&backup);entries.push_back({resource,backup});++copies;
 }
 void observeBuffer(ID3D11Resource* resource){
  if(!recording||!good||!(kinds&2)||!resource)return;
  Microsoft::WRL::ComPtr<ID3D11Buffer> buffer;
  if(FAILED(resource->QueryInterface(IID_PPV_ARGS(&buffer))))return;
  D3D11_BUFFER_DESC d{};buffer->GetDesc(&d);if(!(d.BindFlags&D3D11_BIND_CONSTANT_BUFFER))return;
  for(auto& entry:entries)if(entry.source.Get()==resource)return;
  if(entries.size()>=32){good=false;return;}
  d.Usage=D3D11_USAGE_DEFAULT;d.BindFlags=0;d.CPUAccessFlags=0;d.MiscFlags=0;d.StructureByteStride=0;
  Microsoft::WRL::ComPtr<ID3D11Device> device;context->GetDevice(&device);
  Microsoft::WRL::ComPtr<ID3D11Buffer> saved;if(FAILED(device->CreateBuffer(&d,nullptr,&saved))){good=false;return;}
  context->CopyResource(saved.Get(),resource);
  Resource source=resource,backup;saved.As(&backup);entries.push_back({source,backup});++copies;
 }
 bool between(unsigned mask=~0u){
  recording=false;
  if(!context||!good)return false;
  for(unsigned i=0;i<entries.size();++i)if(mask&(1u<<i))context->CopyResource(entries[i].source.Get(),entries[i].saved.Get());
  return true;
 }
 unsigned count()const{return copies;}
 bool valid()const{return good;}
 void end(){recording=false;context=nullptr;entries.clear();}
};
