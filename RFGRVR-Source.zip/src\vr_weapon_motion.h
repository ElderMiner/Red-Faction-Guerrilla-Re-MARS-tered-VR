#pragma once
#include "vr_arm_math.h"
#include <cstdint>
#include <algorithm>
namespace vrweapon {
using namespace vrarm;
struct MotionSample {uintptr_t weapon=0;uint32_t handle=0,sample=0;double seconds=0;Pose pose{},body{};float scale=1;bool tracked=false,twoHand=false;Pose physical{};bool physicalValid=false;Pose grip{},physicalGrip{};bool gripValid=false;};
struct Motion {bool valid=false;V linear{},angular{},relativeLinear{},relativeAngular{},gripLinear{},physicalGripLinear{};bool gripValid=false;V gripOffset{},gripAngular{};Pose pose{};bool twoHand=false;V smoothedThrow{},smoothedSpin{};bool throwHistoryValid=false;V inheritedLinear{},smoothedRelativeThrow{};V handThrowVelocity(float scale,float strength)const{return mul(throwHistoryValid?smoothedRelativeThrow:sub(gripValid?gripLinear:linear,inheritedLinear),scale*strength);}V carrierVelocity(float scale)const{return mul(inheritedLinear,scale);}float pointSpeed(V localPoint)const{return length(add(relativeLinear,cross(relativeAngular,world(pose.b,localPoint))));}V throwVelocity()const{return throwHistoryValid?smoothedThrow:gripValid?gripLinear:linear;}V throwSpin()const{return throwHistoryValid?smoothedSpin:gripValid?gripAngular:angular;}V releaseVelocity(V localPoint)const{return add(linear,cross(angular,world(pose.b,localPoint)));}};
// Time-based history, so a slow frame does not count like a high-rate sample.
// Keep release direction at the tracked grip; model pivot offsets cannot add aim.
struct ThrowVelocityWindow {
 struct Segment {double end=0;float dt=0;V velocity{},spin{};};Segment samples[32]{};unsigned write=0,count=0;
 void reset(){write=count=0;}
 void addSample(double now,float dt,V velocity,V spin){samples[write]={now,dt,velocity,spin};write=(write+1)%32;count=(std::min)(32u,count+1);}
 void estimate(double now,V& velocity,V& spin)const{velocity=spin={};float total=0;for(unsigned i=0;i<count;++i){const auto& s=samples[(write+31-i)%32];double age=now-s.end;if(age<0||age>=.12)continue;float duration=(std::min)(s.dt,float(.12-age));float weight=duration*(1.f-.75f*float(age/.12));velocity=add(velocity,mul(s.velocity,weight));spin=add(spin,mul(s.spin,weight));total+=weight;}if(total>0){velocity=mul(velocity,1/total);spin=mul(spin,1/total);}}
};
inline V angularDelta(M previous,M current,float dt){
 M d=compose(current,M{{previous.r.x,previous.u.x,previous.f.x},{previous.r.y,previous.u.y,previous.f.y},{previous.r.z,previous.u.z,previous.f.z}});
 float cosine=(d.r.x+d.u.y+d.f.z-1)*.5f;cosine=(std::max)(-1.f,(std::min)(1.f,cosine));float angle=acosf(cosine);
 V axis{d.u.z-d.f.y,d.f.x-d.r.z,d.r.y-d.u.x};float n=length(axis);if(n<.00001f)return {};return mul(axis,angle/(n*dt));
}
struct MotionEstimator {
 MotionSample previous{};Motion output{};bool ready=false;ThrowVelocityWindow throws,relativeThrows;
 void reset(){ready=false;output={};throws.reset();relativeThrows.reset();}
 Motion update(const MotionSample& current){
  if(current.gripValid&&(!valid(current.grip.b)||!valid(current.physicalGrip.b)||!finite(current.grip.p)||!finite(current.physicalGrip.p))){reset();return {};}
  if(!current.tracked||!current.weapon||!valid(current.pose.b)||!valid(current.body.b)||!finite(current.pose.p)||!finite(current.body.p)||!std::isfinite(current.seconds)||!std::isfinite(current.scale)||current.scale<.1f||current.scale>10||(current.physicalValid&&(!valid(current.physical.b)||!finite(current.physical.p)))){reset();return {};}
  if(ready&&current.sample==previous.sample&&current.weapon==previous.weapon&&current.handle==previous.handle)return output;
  double elapsed=current.seconds-previous.seconds;bool same=ready&&current.weapon==previous.weapon&&current.handle==previous.handle&&current.physicalValid==previous.physicalValid&&current.gripValid==previous.gripValid;
  if(!same||elapsed<.001||elapsed>.1||length(sub(current.pose.p,previous.pose.p))/current.scale>.8f){previous=current;ready=true;output={};throws.reset();relativeThrows.reset();return output;}
  float dt=float(elapsed);V before=local(previous.body.b,sub(previous.pose.p,previous.body.p)),after=local(current.body.b,sub(current.pose.p,current.body.p));
  M oldLocal=relative(previous.body.b,previous.pose.b),newLocal=relative(current.body.b,current.pose.b);
  Motion next;next.valid=true;next.pose=current.pose;next.pose.p=mul(next.pose.p,1/current.scale);next.twoHand=current.twoHand;
  next.linear=mul(sub(current.pose.p,previous.pose.p),1/(dt*current.scale));next.angular=angularDelta(previous.pose.b,current.pose.b,dt);
  next.relativeLinear=world(current.body.b,mul(sub(after,before),1/(dt*current.scale)));next.relativeAngular=world(current.body.b,angularDelta(oldLocal,newLocal,dt));
  if(current.physicalValid&&previous.physicalValid&&valid(current.physical.b)&&valid(previous.physical.b)&&finite(current.physical.p)&&finite(previous.physical.p)){
   M inverse{{current.physical.b.r.x,current.physical.b.u.x,current.physical.b.f.x},{current.physical.b.r.y,current.physical.b.u.y,current.physical.b.f.y},{current.physical.b.r.z,current.physical.b.u.z,current.physical.b.f.z}};M frame=compose(current.pose.b,inverse);
   next.relativeLinear=world(frame,mul(sub(current.physical.p,previous.physical.p),1/dt));next.relativeAngular=world(frame,angularDelta(previous.physical.b,current.physical.b,dt));
  }
  // Carry the previous grip through the body's rigid transform. This is
  // inherited motion at the grip, including translation and rotation.
  V previousPoint=current.gripValid?previous.grip.p:previous.pose.p;
  V carried=add(current.body.p,world(current.body.b,local(previous.body.b,sub(previousPoint,previous.body.p))));
  next.inheritedLinear=mul(sub(carried,previousPoint),1/(dt*current.scale));
  if(!finite(next.inheritedLinear)||length(next.inheritedLinear)>120){previous=current;output={};return output;}
  if(current.gripValid&&previous.gripValid){next.gripValid=true;next.gripLinear=mul(sub(current.grip.p,previous.grip.p),1/(dt*current.scale));M frame=compose(current.grip.b,M{{current.physicalGrip.b.r.x,current.physicalGrip.b.u.x,current.physicalGrip.b.f.x},{current.physicalGrip.b.r.y,current.physicalGrip.b.u.y,current.physicalGrip.b.f.y},{current.physicalGrip.b.r.z,current.physicalGrip.b.u.z,current.physicalGrip.b.f.z}});next.physicalGripLinear=world(frame,mul(sub(current.physicalGrip.p,previous.physicalGrip.p),1/dt));next.gripOffset=mul(sub(current.pose.p,current.grip.p),1/current.scale);next.gripAngular=world(frame,angularDelta(previous.physicalGrip.b,current.physicalGrip.b,dt));if(length(sub(next.gripLinear,next.inheritedLinear))>25||length(next.physicalGripLinear)>20){previous=current;output={};return output;}}
  if(length(sub(next.linear,next.inheritedLinear))>25||length(next.relativeLinear)>20||length(next.angular)>70||length(next.relativeAngular)>70){previous=current;output={};return output;}
  V worldThrow=next.gripValid?next.gripLinear:next.linear;
  relativeThrows.addSample(current.seconds,dt,sub(worldThrow,next.inheritedLinear),next.gripValid?next.gripAngular:next.angular);V unusedSpin{};relativeThrows.estimate(current.seconds,next.smoothedRelativeThrow,unusedSpin);
  throws.addSample(current.seconds,dt,next.gripValid?next.gripLinear:next.linear,next.gripValid?next.gripAngular:next.angular);throws.estimate(current.seconds,next.smoothedThrow,next.smoothedSpin);next.throwHistoryValid=true;
  // Short melee velocity filter only. The visual pose is never delayed.
  if(output.valid){float a=1-expf(-dt*50);next.linear=add(output.linear,mul(sub(next.linear,output.linear),a));next.angular=add(output.angular,mul(sub(next.angular,output.angular),a));next.relativeLinear=add(output.relativeLinear,mul(sub(next.relativeLinear,output.relativeLinear),a));next.relativeAngular=add(output.relativeAngular,mul(sub(next.relativeAngular,output.relativeAngular),a));}
  previous=current;output=next;return output;
 }
};
struct StrikeIntent {
 uintptr_t weapon=0;uint32_t handle=0;double seconds=0;float distance=0;bool ready=false;
 void reset(){*this={};}
 bool update(uintptr_t id,uint32_t serial,double now,float speed,bool allowed,bool sledge){
  if(!allowed||!std::isfinite(now)||!std::isfinite(speed)){reset();return false;}
  if(!ready||weapon!=id||handle!=serial||now<=seconds||now-seconds>.12){weapon=id;handle=serial;seconds=now;distance=0;ready=true;return false;}
  float dt=float(now-seconds);seconds=now;float stop=sledge?1.8f:2.1f;if(speed<stop){distance=0;return false;}
  distance=(std::min)(.5f,distance+speed*dt);return distance>=(sledge?.14f:.16f);
 }
};
struct Strike {
 bool swinging=false;uint32_t targets[32]{};unsigned count=0;uintptr_t weapon=0;uint32_t handle=0;
 void reset(){swinging=false;count=0;weapon=0;handle=0;}
 float update(uintptr_t identity,uint32_t generation,float speed,bool valid,float start=1.4f,float stop=.7f,float full=3.f){
  if(!valid||weapon!=identity||handle!=generation){reset();weapon=identity;handle=generation;return 0;}
  if(speed<stop){swinging=false;count=0;return 0;}if(!swinging&&speed>=start){swinging=true;count=0;}if(!swinging)return 0;
  return (std::max)(0.f,(std::min)(1.f,(speed-stop)/(full-stop)));
 }
 bool contact(uint32_t target){if(!swinging||target==~0u||count>=32)return false;for(unsigned i=0;i<count;++i)if(targets[i]==target)return false;targets[count++]=target;return true;}
 static bool damageAllowed(bool sledge,bool twoHand){return !sledge||twoHand;}
 static int meleeMove(int primary,int secondary,bool sledge,bool twoHand){return sledge&&twoHand&&secondary>=0?secondary:primary;}
};
// Continuous structural hits are separated by position, not rendered frames.
struct ImpactRegions {
 uint32_t object[32]{};V point[32]{};unsigned count=0;
 void reset(){count=0;}
 bool contact(uint32_t handle,V p,float separation){if(handle==~0u||!finite(p)||count>=32)return false;unsigned hits=0;for(unsigned i=0;i<count;++i)if(object[i]==handle){++hits;if(length(sub(point[i],p))<separation)return false;}if(hits>=4)return false;object[count]=handle;point[count++]=p;return true;}
};
  struct ThrowArming {
 uint64_t started=0;unsigned duration=0;bool active=false;
 void begin(uint64_t now,unsigned milliseconds){started=now;duration=milliseconds;active=true;}
 bool release(uint64_t now){bool ready=active&&now>=started&&now-started>=duration;active=false;return ready;}
 void cancel(){active=false;}
};
enum class ThrowEvent {None,Prime,Release,Cancel};
struct ThrowLatch {
 uintptr_t weapon=0;uint32_t handle=0;bool down=false,primed=false,blocked=false;
 ThrowEvent update(uintptr_t identity,uint32_t generation,float trigger,bool allowed){
  bool held=std::isfinite(trigger)&&(down?trigger>.55f:trigger>.65f);bool changed=weapon!=identity||handle!=generation;
  if(changed||!allowed){bool cancel=primed;weapon=identity;handle=generation;primed=false;blocked=held;down=held;return cancel?ThrowEvent::Cancel:ThrowEvent::None;}
  if(blocked){if(!held)blocked=false;down=held;return ThrowEvent::None;}
  bool press=held&&!down,release=!held&&down;down=held;if(press){primed=true;return ThrowEvent::Prime;}if(release&&primed){primed=false;return ThrowEvent::Release;}return ThrowEvent::None;
 }
};
}
