#pragma once
// Included inside RFGRVRWeaponPhysics. Expand only the vehicle wave-bank pool
// at its normal initialization, so the native allocator owns all storage and
// cleanup. Never resize a pool that already contains live audio banks.
namespace VehicleAudioPool {
struct Bucket { unsigned cpu,gpu,count; };
using Init=bool(__thiscall*)(void*,unsigned,unsigned,unsigned,unsigned,const Bucket*,unsigned,const char*);
inline Init original=nullptr;
using Allocate=void(__thiscall*)(void*,unsigned,unsigned,void**,unsigned,unsigned,void**,const char*);
inline Allocate originalAllocate=nullptr;inline bool overflowReady=false;
inline void __fastcall allocate(void* self,void*,unsigned cpu,unsigned cpuAlign,void** cpuOut,unsigned gpu,unsigned gpuAlign,void** gpuOut,const char* name){
 unsigned before=0;void* row=nullptr;if(self==base+0x1240e58){row=(void*)(uintptr_t)word(self,0x18);before=word(row,0xc);}
 originalAllocate(self,cpu,cpuAlign,cpuOut,gpu,gpuAlign,gpuOut,name);
 if(overflowReady&&self==base+0x1240d8c&&cpuOut&&gpuOut&&(!cpu||!*cpuOut)&&(!gpu||!*gpuOut)&&RFGRVRVehicleOverflow::allocate(cpu,cpuAlign,cpuOut,gpu,gpuAlign,gpuOut)){
  char line[220];sprintf_s(line,"Vehicle main-pool overflow allocated: cpu=%u gpu=%u cpuOut=%p gpuOut=%p name=%.80s",cpu,gpu,*cpuOut,*gpuOut,memory(name,81)?name:"unreadable");log(line);
 }

 if(self==base+0x1240e58){char message[300];sprintf_s(message,"Vehicle audio allocation: cpu=%u gpu=%u beforeHeads=%08x afterHeads=%08x cpuOut=%p gpuOut=%p name=%.80s",cpu,gpu,before,word(row,0xc),cpuOut?*cpuOut:nullptr,gpuOut?*gpuOut:nullptr,memory(name,81)?name:"unreadable");log(message);}
}
using Free=void(__thiscall*)(void*,void*,void*);inline Free originalFree=nullptr;
inline void __fastcall freeBuffer(void* self,void*,void* cpu,void* gpu){if(self==base+0x1240d8c&&RFGRVRVehicleOverflow::release(cpu,gpu)){log("Vehicle main-pool overflow released by native resource unload.");return;}originalFree(self,cpu,gpu);}
using Loader=bool(__cdecl*)(uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);
inline Loader originalVehicleLoad=nullptr;
inline bool __cdecl vehicleLoad(uintptr_t name,uintptr_t resource,uintptr_t cpu,uintptr_t cpuBytes,uintptr_t gpu,uintptr_t gpuBytes){bool ok=originalVehicleLoad(name,resource,cpu,cpuBytes,gpu,gpuBytes);if(!ok){char message[220];sprintf_s(message,"Vehicle geometry loader FAILED: name=%.80s cpuBytes=%u gpuBytes=%u header=%08x",memory((void*)name,81)?(const char*)name:"unreadable",(unsigned)cpuBytes,(unsigned)gpuBytes,word((void*)cpu,0));log(message);}return ok;}
inline bool __fastcall initialize(void* self,void*,unsigned cpuAlignment,unsigned cpuFlags,unsigned gpuAlignment,unsigned gpuFlags,const Bucket* buckets,unsigned count,const char* name){
 if(self==base+0x1240e58&&count==1&&memory(buckets,sizeof(Bucket))&&buckets[0].cpu==0x300000&&buckets[0].gpu==0&&buckets[0].count==7){
  Bucket expanded=buckets[0];expanded.count=24;
  bool ok=original(self,cpuAlignment,cpuFlags,gpuAlignment,gpuFlags,&expanded,count,name);
  log(ok?"Vehicle audio pool initialized: 24 native 3-MiB slots (formerly 7).":"Vehicle audio pool expansion failed during native initialization.");return ok;
 }
 return original(self,cpuAlignment,cpuFlags,gpuAlignment,gpuFlags,buckets,count,name);
}
inline void install(){
 const unsigned char sig[]={0x83,0xec,0x50,0xa1};
 if(memcmp(base+0xac900,sig,sizeof(sig)))return;
 if(MH_CreateHook(base+0xac900,(void*)initialize,(void**)&original)==MH_OK){
  if(MH_EnableHook(base+0xac900)==MH_OK)log("Vehicle audio pool initialization hook installed.");
  else MH_RemoveHook(base+0xac900);
 }
 const unsigned char allocSig[]={0x51,0x55,0x56,0x57,0x8b,0xf9};
 if(!memcmp(base+0xaf3e0,allocSig,sizeof(allocSig))&&MH_CreateHook(base+0xaf3e0,(void*)allocate,(void**)&originalAllocate)==MH_OK){if(MH_EnableHook(base+0xaf3e0)!=MH_OK)MH_RemoveHook(base+0xaf3e0);}
 const unsigned char freeSig[]={0x51,0x55,0x57,0x33,0xed,0x8b,0xf9};
 if(!memcmp(base+0xacd60,freeSig,sizeof(freeSig))&&MH_CreateHook(base+0xacd60,(void*)freeBuffer,(void**)&originalFree)==MH_OK){if(MH_EnableHook(base+0xacd60)!=MH_OK)MH_RemoveHook(base+0xacd60);else overflowReady=true;}
 const unsigned char loadSig[]={0x83,0xec,0x14,0x55,0x33,0xed,0x56};
 if(!memcmp(base+0x798e20,loadSig,sizeof(loadSig))&&MH_CreateHook(base+0x798e20,(void*)vehicleLoad,(void**)&originalVehicleLoad)==MH_OK){if(MH_EnableHook(base+0x798e20)!=MH_OK)MH_RemoveHook(base+0x798e20);}
}
}
