param([switch]$SkipNative)
$ErrorActionPreference='Stop'
$project=$PSScriptRoot
Set-Location -LiteralPath $project
& (Join-Path $PSScriptRoot "BUILD-SHADERS.ps1")
$release=Get-Content distribution/release.json -Raw|ConvertFrom-Json
if($release.version -notmatch '^\d+\.\d+\.\d+$'){throw 'Set a numeric release version in distribution/release.json'}
$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$installation=& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
$vc=Join-Path $installation 'VC/Auxiliary/Build/vcvarsall.bat'
if(!(Test-Path $vc)){throw 'Install Visual Studio C++ desktop build tools'}
New-Item -ItemType Directory -Force build-check | Out-Null
if(!$SkipNative){& ./CHECK-BUILD.ps1;if($LASTEXITCODE -ne 0){throw 'Game DLL build failed'}
 $bridge='@echo off'+"`r`n"+'cd /d "'+$project+'"'+"`r`n"+'call "'+$vc+'" x64 >nul'+"`r`n"+'cl /nologo /EHsc /std:c++17 /O2 /Ithird_party\include src\bridge.cpp /Fe:build-check\RFGRVR_OpenXR.exe /Fo:build-check\bridge.obj'+"`r`n"+'exit /b %errorlevel%'
 Set-Content build-check/release-bridge.cmd $bridge;cmd /c build-check\release-bridge.cmd;if($LASTEXITCODE -ne 0){throw 'Companion build failed'}}
$csc=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$refs=@('/r:System.Windows.Forms.dll','/r:System.Drawing.dll','/r:System.Web.Extensions.dll','/r:System.IO.Compression.dll','/r:System.IO.Compression.FileSystem.dll')
& $csc /nologo /target:winexe /out:build-check\Launcher.exe @refs distribution\Common.cs distribution\Launcher.cs distribution\GameAssets.cs
if($LASTEXITCODE -ne 0){throw 'Launcher build failed'}
$work=Join-Path $project ('build-check/package-'+[guid]::NewGuid().ToString('N'));$payload=Join-Path $work 'payload';New-Item -ItemType Directory -Force $payload|Out-Null
$files=@{
 'RFGRVR/RELEASE-NOTES.md'='RELEASE-NOTES-0.13.58.md';'RFGRVR/MODERN-LIGHTING.md'='MODERN-LIGHTING.md';'RFGRVR/LICENSE'='LICENSE';'RFGRVR/README.md'='README.md';'RFGRVR/DLC-TESTING.md'='DLC-TESTING.md';'RFGRVR/MAINTAINING.md'='MAINTAINING.md';'RFGRVR/AGENTS.md'='AGENTS.md';'RFGRVR/CONTROLLER-SUPPORT.md'='CONTROLLER-SUPPORT.md';
 'dinput8.dll'='build-check/dinput8.dll';'RFGRVR/Launcher.exe'='build-check/Launcher.exe';'RFGRVR/release.json'='distribution/release.json';'RFGRVR/README.txt'='distribution/README.txt';'RFGRVR/THIRD-PARTY-NOTICES.txt'='distribution/THIRD-PARTY-NOTICES.txt';'vr-research/project/bin/RFGRVR_OpenXR.exe'='build-check/RFGRVR_OpenXR.exe';'vr-research/project/bin/openxr_loader.dll'='bin/openxr_loader.dll'
}
$records=@();foreach($relative in ($files.Keys|Sort-Object)){$target=Join-Path $payload $relative;New-Item -ItemType Directory -Force (Split-Path $target -Parent)|Out-Null;Copy-Item -LiteralPath $files[$relative] -Destination $target;$records+=@{path=$relative;sha256=(Get-FileHash $target).Hash}}
foreach($default in (Get-ChildItem -LiteralPath distribution/defaults -File)){
 $target=Join-Path $payload $default.Name;Copy-Item -LiteralPath $default.FullName -Destination $target
 $records+=@{path=$default.Name;sha256=(Get-FileHash $target).Hash;seedOnly=$true}
}
$supported=Get-Content distribution/supported-game.json -Raw|ConvertFrom-Json
@{version=$release.version;gameSha256=$supported.sha256;files=$records}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $payload 'manifest.json') -Encoding UTF8
Add-Type -AssemblyName System.IO.Compression.FileSystem
$payloadZip=Join-Path $work 'payload.zip';[IO.Compression.ZipFile]::CreateFromDirectory($payload,$payloadZip)
$setup=Join-Path $work 'RFGRVR-Setup.exe'
& $csc /nologo /target:winexe ('/out:'+$setup) ('/resource:'+$payloadZip+',payload.zip') @refs distribution\Common.cs distribution\Setup.cs distribution\Tests.cs
if($LASTEXITCODE -ne 0){throw 'Setup build failed'}
$public=Join-Path $work 'public';New-Item -ItemType Directory $public|Out-Null;Copy-Item $setup $public;Copy-Item distribution/README.txt $public;Copy-Item distribution/THIRD-PARTY-NOTICES.txt $public;foreach($doc in @('README.md','MAINTAINING.md','AGENTS.md','CONTROLLER-SUPPORT.md','LICENSE','RELEASE-NOTES-0.13.58.md')){Copy-Item -LiteralPath $doc -Destination $public}
$out=Join-Path $project 'release';New-Item -ItemType Directory -Force $out|Out-Null
$archive=Join-Path $out 'RFGRVR-Setup.zip';if(Test-Path $archive){Remove-Item -LiteralPath $archive};[IO.Compression.ZipFile]::CreateFromDirectory($public,$archive)
((Get-FileHash $archive).Hash.ToLower()+'  RFGRVR-Setup.zip')|Set-Content ($archive+'.sha256') -Encoding ASCII
Copy-Item $setup (Join-Path $out 'RFGRVR-Setup.exe') -Force
Write-Output ('Built '+$archive)
Write-Output ('Staging '+$work)

$sourceRoot=Join-Path $work 'source';New-Item -ItemType Directory $sourceRoot|Out-Null
foreach($folder in @('src','tests','vendor','distribution','docs','.github')){Copy-Item -LiteralPath (Join-Path $project $folder) -Destination $sourceRoot -Recurse}
New-Item -ItemType Directory -Force (Join-Path $sourceRoot 'third_party')|Out-Null
Copy-Item -LiteralPath third_party/include -Destination (Join-Path $sourceRoot 'third_party') -Recurse
New-Item -ItemType Directory -Force (Join-Path $sourceRoot 'bin')|Out-Null
Copy-Item -LiteralPath bin/openxr_loader.dll -Destination (Join-Path $sourceRoot 'bin')
foreach($file in @('RELEASE-NOTES-0.13.58.md','MAKE-MATERIAL-LIGHTMAPS.py','MAKE-TERRAIN-HEIGHTS.py','VERIFY-ENGINE-LIGHTING.py','LIGHTING-ROADMAP.md','ENGINE-LIGHTING.md','BUILD-SHADERS.ps1','MODERN-LIGHTING.md','CHECK-BUILD.ps1','BUILD-RELEASE.ps1','BUILD-TESTS.ps1','README.md','MAINTAINING.md','AGENTS.md','LICENSE','.gitignore','CONTROLLER-SUPPORT.md','DLC-TESTING.md')){Copy-Item -LiteralPath $file -Destination $sourceRoot}
$sourceZip=Join-Path $out 'RFGRVR-Source.zip';if(Test-Path $sourceZip){Remove-Item -LiteralPath $sourceZip};[IO.Compression.ZipFile]::CreateFromDirectory($sourceRoot,$sourceZip)
Write-Output ('Editable source bundle '+$sourceZip)


