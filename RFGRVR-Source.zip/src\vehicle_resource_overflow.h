#pragma once
#include <windows.h>
#include <cstdint>
#include <cstring>
// Extra vehicle buffers only; native pool allocations remain preferred.
namespace RFGRVRVehicleOverflow {
struct Block {void* storage=nullptr;void* cpu=nullptr;void* gpu=nullptr;size_t bytes=0;};
inline SRWLOCK lock=SRWLOCK_INIT;inline Block blocks[16]{};inline size_t used=0;
inline constexpr size_t budget=256u*1024u*1024u;
inline bool alignment(unsigned a){return a&&a<=65536&&(a&(a-1))==0;}
inline uintptr_t aligned(uintptr_t p,unsigned a){return (p+a-1)&~uintptr_t(a-1);}
inline bool allocate(unsigned cpu,unsigned ca,void** co,unsigned gpu,unsigned ga,void** go){
 if(!cpu)ca=1;if(!gpu)ga=1;
 if(!co||!go||(!cpu&&!gpu)||!alignment(ca)||!alignment(ga))return false;
 size_t bytes=size_t(cpu)+gpu+ca+ga;if(bytes>128u*1024u*1024u)return false;
 AcquireSRWLockExclusive(&lock);Block* slot=nullptr;for(auto& b:blocks)if(!b.storage){slot=&b;break;}
 if(!slot||bytes>budget-used){ReleaseSRWLockExclusive(&lock);return false;}
 void* storage=VirtualAlloc(nullptr,bytes,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);if(!storage){ReleaseSRWLockExclusive(&lock);return false;}
 uintptr_t cp=aligned((uintptr_t)storage,ca),gp=aligned(cp+cpu,ga);*slot={storage,cpu?(void*)cp:nullptr,gpu?(void*)gp:nullptr,bytes};used+=bytes;*co=slot->cpu;*go=slot->gpu;ReleaseSRWLockExclusive(&lock);return true;
}
inline bool release(void* cpu,void* gpu){
 if(!cpu&&!gpu)return false;AcquireSRWLockExclusive(&lock);
 for(auto& b:blocks)if(b.storage&&((cpu&&cpu==b.cpu)||(!b.cpu&&gpu&&gpu==b.gpu))){bool ok=VirtualFree(b.storage,0,MEM_RELEASE)!=0;if(ok){used-=b.bytes;b={};}ReleaseSRWLockExclusive(&lock);return true;}
 ReleaseSRWLockExclusive(&lock);return false;
}
}

