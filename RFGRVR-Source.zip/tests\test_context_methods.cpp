#include "../src/gpu_pipeline_trace.cpp"
#include <cassert>
extern "C" unsigned RFGRVR_HeadCam_HeadSamples(){return 0;}
extern "C" bool RFGRVR_HeadCam_Recent(){return false;}
extern "C" void RFGRVR_Survey_Capture(bool){}
int main(){
 Microsoft::WRL::ComPtr<ID3D11Device> d;Microsoft::WRL::ComPtr<ID3D11DeviceContext> c;
 D3D_FEATURE_LEVEL level{};
 assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&d,&level,&c)));
 size_t count=RFGRVR_ContextMethods(c.Get());assert(count>=115);
 auto* original=*(void***)c.Get();void* signal=count>147?original[147]:nullptr;
 assert(RFGRVR_GPUCapture_Attach(c.Get()));auto* shadow=*(void***)c.Get();
 for(size_t i=115;i<count;++i)assert(shadow[i]==original[i]&&shadow[i]);
 Microsoft::WRL::ComPtr<ID3D11Device5> d5;Microsoft::WRL::ComPtr<ID3D11DeviceContext4> c4;
 if(SUCCEEDED(d.As(&d5))&&SUCCEEDED(c.As(&c4))&&(void*)c4.Get()==(void*)c.Get()){
  assert(count==149&&shadow[147]==signal);Microsoft::WRL::ComPtr<ID3D11Fence> fence;
  assert(SUCCEEDED(d5->CreateFence(0,D3D11_FENCE_FLAG_NONE,__uuidof(ID3D11Fence),(void**)fence.GetAddressOf())));
  assert(SUCCEEDED(c4->Signal(fence.Get(),1)));
 }
 printf("Preserved %zu context methods, including overlay fence operations.\n",count);
}
