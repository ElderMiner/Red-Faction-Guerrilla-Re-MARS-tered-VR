#pragma once
#include <algorithm>
#include <cstring>
#include "ipc.h"
#include "vr_arm_math.h"
struct RFGRVRWeaponSelector {
 bool active=false,pending=false;unsigned long long pressedAt=0;unsigned selected=0;RFGRPose anchor{},start{};vrarm::M frame{};
 unsigned buttons(unsigned physical)const{return (physical&0xf000u)?physical:(physical|selected);}
 static vrarm::M basis(const RFGRPose& p){float x=p.orientation[0],y=p.orientation[1],z=p.orientation[2],w=p.orientation[3];return {{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};}
 bool update(bool held,bool allowed,const RFGRPose& head,const RFGRPose& hand,unsigned long long now=GetTickCount64(),unsigned delayMs=500){using namespace vrarm;
  if(!held||!allowed||!hand.active||(hand.validFlags&3)!=3||(head.validFlags&3)!=3){active=false;pending=false;pressedAt=0;selected=0;return false;}
  if(!pending){pending=true;pressedAt=now;}
  if(now-pressedAt<delayMs)return false;
  if(!active){frame=basis(head);if(!valid(frame))return false;start=hand;anchor=head;V p=add({hand.position[0],hand.position[1],hand.position[2]},mul(frame.f,-.24f));memcpy(anchor.position,&p,12);anchor.active=1;active=true;selected=0;}
  V delta=local(frame,sub({hand.position[0],hand.position[1],hand.position[2]},{start.position[0],start.position[1],start.position[2]}));
  // Anchor stays fixed for the gesture. Returning to center rearms it.
  M current=basis(hand),initial=basis(start);V aimDelta=local(frame,sub(mul(current.f,-1),mul(initial.f,-1)));delta=add(delta,mul(aimDelta,.20f));
  float x=delta.x,y=delta.y,ax=fabsf(x),ay=fabsf(y),reach=(std::max)(ax,ay);
  if(reach<.035f)selected=0;
  else if(reach>.06f&&((ax>ay*1.15f)||(ay>ax*1.15f)))selected=ax>ay?(x>0?0x2000:0x4000):(y>0?0x8000:0x1000);
  return true;
 }
};
