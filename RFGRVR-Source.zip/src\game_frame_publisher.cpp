#include "game_frame_publisher.h"
using Microsoft::WRL::ComPtr;

void GameFramePublisher::ReleaseTexture() noexcept {
    if(map_) { InterlockedExchange(&map_->ready,0); MemoryBarrier(); }
    mutex_.Reset(); sharedTexture_.Reset(); context_.Reset(); device_.Reset();
    width_=height_=0; format_=DXGI_FORMAT_UNKNOWN;
}
void GameFramePublisher::Shutdown() noexcept {
    ReleaseTexture();
    if(map_) { UnmapViewOfFile(map_); map_=nullptr; }
    if(mapHandle_) { CloseHandle(mapHandle_); mapHandle_=nullptr; }
}
bool GameFramePublisher::Prepare(IDXGISwapChain* swap,ID3D11Texture2D* back) noexcept {
    D3D11_TEXTURE2D_DESC desc{}; back->GetDesc(&desc);
    if(desc.Width==0 || desc.Height==0) return false;
    // Source must have one sample, be a supported 8-bit color format, and run on the same adapter.
    // CopyResource does not perform format conversion or multisample resolve.
    if(desc.SampleDesc.Count!=1 || desc.ArraySize!=1 || desc.MipLevels!=1) return false;
    const DXGI_FORMAT f=desc.Format;
    if(f!=DXGI_FORMAT_B8G8R8A8_UNORM && f!=DXGI_FORMAT_R8G8B8A8_UNORM &&
       f!=DXGI_FORMAT_B8G8R8A8_UNORM_SRGB && f!=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB) return false;
    if(sharedTexture_ && width_==desc.Width && height_==desc.Height && format_==f)return true;
    ReleaseTexture();
    lastError_=swap->GetDevice(__uuidof(ID3D11Device),reinterpret_cast<void**>(device_.ReleaseAndGetAddressOf()));
    if(FAILED(lastError_))return false;
    device_->GetImmediateContext(context_.ReleaseAndGetAddressOf());
    if(!context_)return false;
    D3D11_TEXTURE2D_DESC sd{};
    sd.Width=desc.Width;sd.Height=desc.Height;sd.MipLevels=1;sd.ArraySize=1;
    sd.Format=f;sd.SampleDesc.Count=1;sd.Usage=D3D11_USAGE_DEFAULT;
    sd.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_RENDER_TARGET;
    sd.MiscFlags=D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
    lastError_=device_->CreateTexture2D(&sd,nullptr,sharedTexture_.ReleaseAndGetAddressOf());
    if(FAILED(lastError_))return false;
    lastError_=sharedTexture_.As(&mutex_);if(FAILED(lastError_))return false;
    ComPtr<IDXGIResource> resource;lastError_=sharedTexture_.As(&resource);
    if(FAILED(lastError_))return false;
    HANDLE handle=nullptr;lastError_=resource->GetSharedHandle(&handle);
    if(FAILED(lastError_)||!handle)return false;
    if(!mapHandle_)mapHandle_=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(RFGRGpuShared),RFGR_GPU_MAP);
    if(!mapHandle_)return false;
    if(!map_)map_=static_cast<RFGRGpuShared*>(MapViewOfFile(mapHandle_,FILE_MAP_ALL_ACCESS,0,0,sizeof(RFGRGpuShared)));
    if(!map_)return false;
    // Do not steal a mapping currently owned by the separate test-color producer.
    if(map_->magic==RFGR_GPU_MAGIC && map_->ready && map_->legacyShareHandle!=static_cast<uint64_t>(reinterpret_cast<uintptr_t>(handle)))return false;
    ZeroMemory(map_,sizeof(*map_));
    map_->magic=RFGR_GPU_MAGIC;map_->version=1;map_->width=sd.Width;
    map_->height=sd.Height;map_->format=sd.Format;
    map_->legacyShareHandle=static_cast<uint64_t>(reinterpret_cast<uintptr_t>(handle));
    width_=sd.Width;height_=sd.Height;format_=f;
    MemoryBarrier();InterlockedExchange(&map_->ready,1);
    return true;
}
bool GameFramePublisher::PublishFrame(IDXGISwapChain* swap) noexcept {
    if(!swap)return false;
    ComPtr<ID3D11Texture2D> back;
    lastError_=swap->GetBuffer(0,__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(back.GetAddressOf()));
    if(FAILED(lastError_))return false;
    if(!Prepare(swap,back.Get()))return false;
    // Non-blocking on the game's render thread. A slow VR consumer must never stall gameplay.
    lastError_=mutex_->AcquireSync(0,0);
    if(lastError_!=S_OK)return false;
    context_->CopyResource(sharedTexture_.Get(),back.Get());
    context_->Flush();
    lastError_=mutex_->ReleaseSync(1);
    if(FAILED(lastError_))return false;
    InterlockedIncrement(&map_->frames);++published_;
    return true;
}
