#pragma once
#include "apc_camera_state.h"
#include "ipc.h"
#include <cstdio>
#include <algorithm>
#include "apc_screen_layout.h"
#include "vr_wrist_status.h"
#include "apc_editor_keys.h"
namespace RFGRVRAPC {
using namespace vrarm;
inline SRWLOCK lock=SRWLOCK_INIT;inline RFGRAPCCameras packet{};inline RFGRAPCChannel channel;
inline Pose nativeMounts[4]{};inline V offsets[4]{};inline V screenOffset{0,-.35f,.8f},seat{};inline float tilt=0,scale=1;
struct Monitor {V offset{};float tilt=0,width=1,height=1,lens=0,cameraPitch=0,yaw=0;};
inline Monitor monitors[4]{};inline int selected=-1;inline bool cameraEdit=false;
inline V monitorOffset(unsigned i){V initial=i==1?V{0,.39f,0}:i==2?V{.31f,.39f,0}:i==3?V{-.31f,.39f,0}:V{};return add(initial,monitors[i].offset);}
inline void bounds(unsigned i,float (&angles)[4]){auto m=monitors[i];float wide=1.f+m.lens;float x=m.width*wide,y=(9.f/16.f)*m.height*wide;angles[0]=-atanf(x);angles[1]=atanf(x);angles[2]=atanf(y);angles[3]=-atanf(y);}
inline float assemblyYaw=0;inline bool fixedSeat=false;
inline unsigned renderIndex=0;inline Pose nativeScreens{};inline float assemblyScale=1;
inline char type[96]{},path[MAX_PATH]{};inline unsigned identity=~0u;inline uint64_t texture=0;inline unsigned epoch=0,validFeeds=0;inline DWORD feedTick[4]{};
inline int grabbed[2]={-1,-1};inline V grabStart[2]{},offsetStart[2]{};inline bool gripHeld[2]{};
inline void setOffset(unsigned i,V value){if(i>=4)return;offsets[i]=value;if(i>=2)offsets[i==2?3:2]={-value.x,value.y,value.z};}
inline void save(){if(!path[0]||!type[0])return;char value[160],key[40];if(fixedSeat){sprintf_s(value,"%.9f %.9f %.9f",seat.x,seat.y,seat.z);WritePrivateProfileStringA(type,"Seat",value,path);}sprintf_s(value,"%.6f %.6f %.6f %.6f",screenOffset.x,screenOffset.y,screenOffset.z,tilt);WritePrivateProfileStringA(type,"Screens",value,path);sprintf_s(value,"%.6f",assemblyYaw);WritePrivateProfileStringA(type,"ScreenYaw",value,path);sprintf_s(value,"%.6f",assemblyScale);WritePrivateProfileStringA(type,"ScreenScale",value,path);for(unsigned i=0;i<4;++i){auto m=monitors[i];sprintf_s(key,"Monitor%u",i+1);sprintf_s(value,"%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f",m.offset.x,m.offset.y,m.offset.z,m.tilt,m.width,m.height,m.lens,m.cameraPitch,m.yaw);WritePrivateProfileStringA(type,key,value,path);sprintf_s(key,"Camera%u",i+1);sprintf_s(value,"%.6f %.6f %.6f",offsets[i].y,offsets[i].z,offsets[i].x);WritePrivateProfileStringA(type,key,value,path);}}
inline void load(const char* name){strcpy_s(type,name);if(!path[0]){GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* s=strrchr(path,92))strcpy_s(s+1,MAX_PATH-(s+1-path),"RFGRVR-apc-cameras.ini");}screenOffset={0,-.35f,.8f};tilt=0;assemblyYaw=0;assemblyScale=1;for(auto& m:monitors)m=Monitor{};selected=-1;cameraEdit=false;fixedSeat=false;memset(offsets,0,sizeof(offsets));char value[160],key[40];GetPrivateProfileStringA(type,"Seat","",value,sizeof(value),path);V storedSeat{};if(sscanf_s(value,"%f %f %f",&storedSeat.x,&storedSeat.y,&storedSeat.z)==3&&finite(storedSeat)&&length(storedSeat)<5){seat=storedSeat;fixedSeat=true;}GetPrivateProfileStringA(type,"Screens","",value,sizeof(value),path);V p{};float a=0;if(sscanf_s(value,"%f %f %f %f",&p.x,&p.y,&p.z,&a)==4&&finite(p)&&length(p)<5&&fabsf(a)<1.4f){screenOffset=p;tilt=a;}GetPrivateProfileStringA(type,"ScreenYaw","0",value,sizeof(value),path);float savedYaw=0;if(sscanf_s(value,"%f",&savedYaw)==1&&std::isfinite(savedYaw)&&fabsf(savedYaw)<6.4f)assemblyYaw=savedYaw;GetPrivateProfileStringA(type,"ScreenScale","1",value,sizeof(value),path);float size=1;if(sscanf_s(value,"%f",&size)==1&&std::isfinite(size))assemblyScale=(std::max)(.25f,(std::min)(3.f,size));for(unsigned i=0;i<4;++i){sprintf_s(key,"Camera%u",i+1);GetPrivateProfileStringA(type,key,"",value,sizeof(value),path);float y=0,z=0,x=0;if(sscanf_s(value,"%f %f %f",&y,&z,&x)>=2&&std::isfinite(y)&&std::isfinite(z)&&fabsf(y)<4&&fabsf(z)<4)offsets[i]={std::isfinite(x)&&fabsf(x)<4?x:0,y,z};}offsets[3]={-offsets[2].x,offsets[2].y,offsets[2].z};for(unsigned i=0;i<4;++i){sprintf_s(key,"Monitor%u",i+1);GetPrivateProfileStringA(type,key,"",value,sizeof(value),path);Monitor m{};if(sscanf_s(value,"%f %f %f %f %f %f %f %f %f",&m.offset.x,&m.offset.y,&m.offset.z,&m.tilt,&m.width,&m.height,&m.lens,&m.cameraPitch,&m.yaw)>=7&&finite(m.offset)&&length(m.offset)<10&&std::isfinite(m.tilt)&&fabsf(m.tilt)<1.5f&&m.width>=.2f&&m.width<=4&&m.height>=.2f&&m.height<=4&&m.lens>=0&&m.lens<=1&&std::isfinite(m.cameraPitch)&&fabsf(m.cameraPitch)<1.5f&&std::isfinite(m.yaw)&&fabsf(m.yaw)<6.4f)monitors[i]=m;}}
inline Pose rigidDriverEye(Pose root){root.p=add(root.p,world(root.b,{0,.75f,0}));root.p.y+=.08f;return root;}
inline M trackedBasis(const RFGRPose& p){float x=p.orientation[0],y=p.orientation[1],z=p.orientation[2],w=p.orientation[3];return {{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};}
inline void update(const char* name,unsigned id,const Pose& body,const Pose& eye,const RFGRPose* tracked,float worldScale,bool driver=true){
 AcquireSRWLockExclusive(&lock);bool active=name&&strstr(name,"APC")&&tracked&&valid(body.b)&&valid(eye.b)&&worldScale>.1f;
 packet.active=active?(driver?7u:5u):0u;if(!active){identity=~0u;auto snapshot=packet;ReleaseSRWLockExclusive(&lock);channel.publish(snapshot);return;}
 scale=worldScale;if(id!=identity){identity=id;load(name);if(!fixedSeat){seat=driver?mul(local(body.b,sub(eye.p,body.p)),1/scale):V{-.451930612f,.366235375f,.815292835f};fixedSeat=true;if(driver)save();}grabbed[0]=grabbed[1]=-1;validFeeds=0;}
 M trackedFrame=trackedBasis(*tracked);auto axis=[&](V v){V e=local(eye.b,v);e.z=-e.z;return world(trackedFrame,e);};
 auto point=[&](V v){return add({tracked->position[0],tracked->position[1],tracked->position[2]},axis(mul(sub(v,eye.p),1/scale)));};
 auto stage=[&](Pose p){return Pose{{axis(p.b.r),axis(p.b.u),mul(axis(p.b.f),-1)},point(p.p)};};
 packet.vehicle=id;packet.vehicleStage=stage(body);packet.grabbed=0;
 const V defaults[4]={{0,1.7f,3.9f},{0,1.7f,-3.9f},{1.6f,1.7f,0},{-1.6f,1.7f,0}};
 const float yaw[4]={0,3.14159265f,1.5707963f,-1.5707963f};M unitBasis{{1,0,0},{0,1,0},{0,0,1}};
 for(unsigned i=0;i<4;++i){nativeMounts[i]={compose(body.b,compose(turnAround(unitBasis,{0,1,0},yaw[i]),turnAround(unitBasis,{1,0,0},monitors[i].cameraPitch))),add(body.p,world(body.b,mul(add(defaults[i],offsets[i]),scale)))};packet.mounts[i]=stage(nativeMounts[i]);if(grabbed[0]==int(i)||grabbed[1]==int(i))packet.grabbed|=1u<<i;}
 Pose screens{compose(body.b,compose(turnAround(unitBasis,{0,1,0},assemblyYaw),turnAround(unitBasis,{1,0,0},tilt))),add(body.p,world(body.b,mul(add(seat,screenOffset),scale)))};nativeScreens=screens;packet.screens=stage(screens);
 packet.texture=texture;packet.epoch=epoch;packet.valid=validFeeds;memcpy(packet.feedTick,feedTick,sizeof(feedTick));RFGRAPCCameras snapshot=packet;ReleaseSRWLockExclusive(&lock);channel.publish(snapshot);
}
// Setup is complete. Consume the old APC editing keys without changing profiles.
inline bool input(const RFGRShared*,bool,bool){AcquireSRWLockShared(&lock);bool driver=(packet.active&2)!=0;ReleaseSRWLockShared(&lock);return driver;}
inline bool next(Pose& camera,unsigned& index){static unsigned cursor=0;AcquireSRWLockShared(&lock);bool active=(packet.active&2)&&identity!=~0u;if(active){index=cursor++%4;renderIndex=index;camera=nativeMounts[index];}ReleaseSRWLockShared(&lock);return active;}
inline void captured(uint64_t handle,unsigned generation,unsigned index){AcquireSRWLockExclusive(&lock);texture=handle;epoch=generation;validFeeds|=1u<<index;feedTick[index]=GetTickCount();ReleaseSRWLockExclusive(&lock);}
}
