#pragma once
#include <cstring>
// Engine dynamic vertex pool: mapped context, buffer, byte cursor, capacity.
// Each new deferred command list must begin mapping this resource with DISCARD.
inline bool RFGRVR_VertexPoolReady(void* pool){unsigned v[4]{};memcpy(v,pool,sizeof(v));return !v[0]&&v[1]&&v[3]&&v[2]<=v[3];}
inline void RFGRVR_VertexPoolRestart(void* pool){unsigned zero=0;memcpy((char*)pool+8,&zero,4);}
