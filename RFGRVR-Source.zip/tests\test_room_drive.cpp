#include "../src/vr_room_drive.h"
#include <cassert>
int main(){RFGRVRRoomDrive idle;int16_t ix=0,iy=0;for(unsigned n=1;n<100;++n){idle.request(.02f*sin(float(n)),.02f*cos(float(n)),0,0,n);assert(!idle.input(0,true,n,ix,iy));}idle.request(.08f,0,.08f,0,101);assert(idle.input(0,true,101,ix,iy));idle.request(.04f,0,.04f,0,102);assert(idle.input(0,true,102,ix,iy));idle.request(.02f,0,.02f,0,103);assert(!idle.input(0,true,103,ix,iy));idle.request(.04f,0,.04f,0,104);assert(!idle.input(0,true,104,ix,iy));RFGRVRRoomDrive d;float credit[2];d.observe(0,0,true,100,credit);d.request(.3f,0,.3f,0,100);int16_t x=0,y=0;assert(d.input(0,true,100,x,y)&&x>7000&&y==0);
 d.observe(.05f,0,true,120,credit);assert(fabsf(credit[0]-.05f)<.00001f&&fabsf(credit[1])<.00001f);
 // A blocked move credits no room-origin shift; native collision owns it.
 d.observe(.05f,0,true,140,credit);assert(credit[0]==0&&credit[1]==0);
 // Turning the view changes input coordinates, never physical direction.
 d.request(.3f,0,.3f,0,150);assert(d.input(1.5707963268f,true,150,x,y)&&abs(x)<=1&&y>7000);
 assert(!d.input(0,false,160,x,y));d.observe(.1f,0,true,180,credit);assert(credit[0]==0);
 assert(!d.input(0,true,1000,x,y));
 RFGRVRRoomDrive rotated;rotated.observe(0,0,true,100,credit);rotated.request(0,.6f,.3f,0,100);rotated.input(0,true,100,x,y);rotated.observe(0,.1f,true,120,credit);assert(fabsf(credit[0]-.05f)<.00001f&&fabsf(credit[1])<.00001f);
 // Camera = rendered body + remaining tracking delta, so accepted motion
 // is counted exactly once even if the render body trails simulation.
 RFGRVRRoomDrive follow;float origin=0,body=0;follow.observe(0,0,true,100,credit);
 for(unsigned i=1;i<120;++i){float physical=.005f*i;follow.request(physical-origin,0,physical-origin,0,100+i*16);bool driving=follow.input(0,true,100+i*16,x,y);float step=driving?std::fmin(.004f,physical-body):0;body+=step;follow.observe(body,0,true,100+i*16,credit);origin+=credit[0];assert(fabsf(body+physical-origin-physical)<.00001f);}
}
