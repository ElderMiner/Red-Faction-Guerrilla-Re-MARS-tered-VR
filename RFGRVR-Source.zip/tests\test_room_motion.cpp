#include "../src/vr_room_motion.h"
#include <cassert>
int main(){RFGRVRRoomMotion motion;float neutral[3]={0,.1f,-.08f};motion.reset(neutral);
 for(int i=-150;i<=150;++i){float yaw=i*.01f;float neck[3]={-.08f*std::sin(yaw),.1f,-.08f*std::cos(yaw)},delta[3],out[3];for(int j=0;j<3;++j)delta[j]=neck[j]-neutral[j];motion.displacement(delta,neck,out);assert(fabsf(out[0])+fabsf(out[2])<.00001f);
  delta[0]+=.3f;motion.displacement(delta,neck,out);assert(fabsf(out[0]-.285f)<.00001f&&fabsf(out[2])<.00001f);
 }
 float lean[3]={.01f,0,0},out[3];motion.displacement(lean,neutral,out);assert(out[0]==0&&out[2]==0);
 float step[3]={-.3f,0,.4f};motion.displacement(step,neutral,out);assert(fabsf(out[0]/out[2]+.75f)<.00001f&&out[0]<0&&out[2]>0);
 float origin[3]={0,0,0},position[3]={0,1.7f,0};motion.anchorController(true,position,neutral,origin);position[0]=.2f;motion.anchorController(true,position,neutral,origin);assert(fabsf(origin[0]-.2f)<.00001f);float turnNeck[3]={-.08f,.1f,0};position[0]+=(turnNeck[0]-neutral[0]);position[2]+=(turnNeck[2]-neutral[2]);motion.anchorController(true,position,turnNeck,origin);assert(fabsf(origin[0]-.2f)<.00001f&&fabsf(origin[2])<.00001f);position[0]+=.3f;motion.anchorController(false,position,turnNeck,origin);assert(fabsf(origin[0]-.2f)<.00001f);motion.anchorController(true,position,turnNeck,origin);assert(fabsf(origin[0]-.2f)<.00001f);
}
