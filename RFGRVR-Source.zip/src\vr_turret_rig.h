#pragma once
#include "vr_arm_math.h"
#include <algorithm>
struct RFGRVRTurretRig {
 unsigned identity=~0u;bool ready=false,bodyReady=false,vehicle=false,standingVehicle=false;float orbit=0,radius=.8f,height=0,lever=.55f,roomYaw=0;vrarm::V origin{},bodyOrigin{},roomOffset{},seatLocal{};
 bool entering=true;float entryAge=0,entryQuiet=0;vrarm::V previousSeat{};
 float gunYaw=0,gunPitch=0,entryYaw=0,entryPitch=0;vrarm::Pose body{};
 // Absolute handle constraint: limits clamp the result, never rebase the hand.
 bool aimAtHandle(const vrarm::Pose& pivot,vrarm::V handle,vrarm::V target,float yawMin,float yawMax,float pitchMin,float pitchMax){using namespace vrarm;
  V d=local(pivot.b,sub(target,pivot.p));if(!finite(d)||!finite(handle)||length(d)<.03f||length(handle)<.08f)return false;
  float yaw=std::remainder(atan2f(-d.x,-d.z)-atan2f(-handle.x,-handle.z),6.28318530718f);
  float pitch=atan2f(-d.y,sqrtf(d.x*d.x+d.z*d.z))-atan2f(-handle.y,sqrtf(handle.x*handle.x+handle.z*handle.z));
  if(yawMin>yawMax)std::swap(yawMin,yawMax);if(pitchMin>pitchMax)std::swap(pitchMin,pitchMax);
  gunYaw=(std::max)(yawMin,(std::min)(yawMax,yaw));gunPitch=(std::max)(pitchMin,(std::min)(pitchMax,pitch));return true;
 }
 // A seated player's controller lives in room space. Carry its neutral
 // handle point and displacement WITH the seat, rather than comparing last
 // render's world-space hand against this update's newly rotated assembly.
 bool aimFromSeat(const vrarm::Pose& pivot,vrarm::V handle,vrarm::V physicalHand,vrarm::V physicalZero,float calibrationYaw,float scale,float pitchMin,float pitchMax){using namespace vrarm;
  if(!finite(physicalHand)||!finite(physicalZero)||!std::isfinite(calibrationYaw)||!std::isfinite(scale)||scale<=0)return false;
  V d=sub(physicalHand,physicalZero);float c=cosf(calibrationYaw),s=sinf(calibrationYaw);V motion{(d.x*c-d.z*s)*scale,d.y*scale,(d.x*s+d.z*c)*scale};
  V neutral=turnAround(handle,{1,0,0},-entryPitch);V target=add(pivot.p,world(pivot.b,add(neutral,motion)));
  bool ok=aimAtHandle(pivot,neutral,target,-.75f,.75f,pitchMin-entryPitch,pitchMax-entryPitch);if(ok)gunPitch+=entryPitch;return ok;
 }
 void reset(){*this={};}
 bool update(unsigned id,const vrarm::Pose& base,vrarm::V nativeBody,vrarm::V hand,float physicalForward,float scale,float stick,float dt,float yawMin,float yawMax,float pitchMin,float pitchMax,const vrarm::V* trackedBody=nullptr,bool vehicleMount=false,float initialYaw=0,float initialPitch=0,float handleLever=0,bool standingVehicleMount=false){using namespace vrarm;
  if(!valid(base.b)||!finite(base.p)||!finite(hand)||!finite(nativeBody)||!std::isfinite(physicalForward)||!std::isfinite(scale)||scale<=0)return false;
  if(!ready||identity!=id||vehicle!=vehicleMount||standingVehicle!=standingVehicleMount){reset();identity=id;ready=true;vehicle=vehicleMount;standingVehicle=standingVehicleMount;origin=hand;entryYaw=std::isfinite(initialYaw)?initialYaw:0;entryPitch=std::isfinite(initialPitch)?initialPitch:0;seatLocal=local(base.b,sub(nativeBody,base.p));previousSeat=seatLocal;roomYaw=physicalForward;V d=sub(nativeBody,base.p);radius=sqrtf(d.x*d.x+d.z*d.z);if(radius<.4f||radius>2.f)radius=.8f*scale;height=d.y;lever=radius/scale;if(lever<.2f)lever=.2f;if(lever>1.2f)lever=1.2f;}
  if(!std::isfinite(stick))stick=0;if(!std::isfinite(dt)||dt<0)dt=0;if(dt>.05f)dt=.05f;
  // State3 begins before the native entry translation finishes. Carry both
  // the VR head and avatar through that relocation, then freeze the anchor.
  if(entering){entryAge+=dt;V seat=local(base.b,sub(nativeBody,base.p));entryQuiet=length(sub(seat,previousSeat))<.003f?entryQuiet+dt:0;previousSeat=seat;
   if(fabsf(stick)>.2f)entering=false;
   else{seatLocal=seat;radius=sqrtf(seat.x*seat.x+seat.z*seat.z);height=seat.y;if(entryQuiet>=.2f||entryAge>=1.f)entering=false;}
  }
  float a=fabsf(stick)>.2f?(stick-(stick>0?.2f:-.2f))/.8f:0;
  // A continuous vehicle yaw motor must not receive a 2*pi target jump when
  // the stick passes +/-180 degrees. Only the standing arc is wrapped.
  orbit+=(vehicle?a:-a)*1.57079632679f*dt;if(!vehicle)orbit=std::remainder(orbit,6.28318530718f);
  if(yawMin>yawMax)std::swap(yawMin,yawMax);if(pitchMin>pitchMax)std::swap(pitchMin,pitchMax);
  if(yawMax-yawMin<6.2f)orbit=(std::max)(yawMin,(std::min)(yawMax,orbit));
  float rootYaw=atan2f(base.b.f.x,base.b.f.z),yaw=rootYaw+orbit+(vehicle?entryYaw:atan2f(-seatLocal.x,-seatLocal.z)),c=cosf(yaw),s=sinf(yaw);
  // Position and orientation use the same vehicle frame. Removing bank from
  // only the orientation offsets the eyes from the tilted rotation axis.
  body={M{{c,0,-s},{0,1,0},{s,0,c}},vehicle?add(base.p,world(base.b,standingVehicle?world(turnAround(M{{1,0,0},{0,1,0},{0,0,1}},{0,1,0},orbit),seatLocal):V{0,seatLocal.y,0})):add(base.p,{-s*radius,height,-c*radius})};
  if(vehicle){float angle=entryYaw+orbit,cy=cosf(angle),sy=sinf(angle);body.b=compose(base.b,M{{cy,0,-sy},{0,1,0},{sy,0,cy}});}
  roomOffset={};if(!vehicle&&trackedBody&&finite(*trackedBody)){if(!bodyReady){bodyOrigin=*trackedBody;bodyReady=true;}roomOffset=sub(*trackedBody,bodyOrigin);roomOffset.y=0;float travel=length(roomOffset);constexpr float followRadius=.06f;if(travel<=followRadius)roomOffset={};else roomOffset=mul(roomOffset,(travel-followRadius)/travel);float x=roomOffset.x*cosf(roomYaw)-roomOffset.z*sinf(roomYaw),z=roomOffset.x*sinf(roomYaw)+roomOffset.z*cosf(roomYaw);body.p=add(body.p,world(body.b,{x*scale,0,z*scale}));}
  if(std::isfinite(handleLever)&&handleLever>=.08f&&handleLever<=1.5f)lever=handleLever;
  V d=sub(hand,origin);float side=d.x*cosf(roomYaw)-d.z*sinf(roomYaw),front=d.x*sinf(roomYaw)+d.z*cosf(roomYaw),rear=(std::max)(.05f,lever-front);
  // Solve the actual rear-handle vector, not an arbitrary body-radius gain.
  float by=yaw-rootYaw,cy=cosf(by),sy=sinf(by),angle=entryYaw+orbit;
  V rearHandle{-sinf(angle)*cosf(entryPitch)*lever+side*cy+front*sy,-sinf(entryPitch)*lever+d.y,-cosf(angle)*cosf(entryPitch)*lever-side*sy+front*cy};
  // Both mounts use the same physical rear-handle fulcrum. Mirroring the
  // whole solved angle also reversed coarse stick rotation on seated guns.
  float solvedYaw=atan2f(-rearHandle.x,-rearHandle.z);gunYaw=(std::max)(yawMin,(std::min)(yawMax,solvedYaw));
  gunPitch=(std::max)(pitchMin,(std::min)(pitchMax,atan2f(-rearHandle.y,sqrtf(rearHandle.x*rearHandle.x+rearHandle.z*rearHandle.z))));return true;
 }
};


