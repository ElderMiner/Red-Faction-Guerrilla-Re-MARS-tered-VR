// Read-only investigation of Red Faction's true engine render-pass boundaries.
// No stereo image is claimed: this records what the live renderer actually does.
#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <dxgi.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <mutex>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <string>
namespace {
struct Event {unsigned frame, camera, renderer, tick; double durationUs; float xyz[3]; float transform[16]; unsigned valid;};
constexpr size_t MAX_EVENTS=8192;
std::mutex guard;
Event events[MAX_EVENTS]{};
size_t nextEvent=0, totalEvents=0;
unsigned frame=0, presents=0;
volatile LONG autoState=0; // 0 idle, 1 collecting, 2 saving, 3 saved, 4 failed
volatile LONG autoRun=0;
char autoReport[MAX_PATH]{};
static bool Readable(const void* p,size_t n){
 MEMORY_BASIC_INFORMATION m{}; if(!p || !VirtualQuery(p,&m,sizeof(m)) || m.State!=MEM_COMMIT)return false;
 if(m.Protect&(PAGE_NOACCESS|PAGE_GUARD))return false;
 uintptr_t start=reinterpret_cast<uintptr_t>(p), base=reinterpret_cast<uintptr_t>(m.BaseAddress);
 return start>=base && n<=m.RegionSize && start-base<=m.RegionSize-n;
}
static void Fill(Event& e,void* camera){
 e.camera=static_cast<unsigned>(reinterpret_cast<uintptr_t>(camera));
 if(!Readable(camera,0x140))return;
 memcpy(e.xyz,static_cast<const unsigned char*>(camera)+0x2C,sizeof(e.xyz));
 memcpy(e.transform,static_cast<const unsigned char*>(camera)+0x100,sizeof(e.transform));
 for(float x:e.xyz)if(!std::isfinite(x))return;
 for(float x:e.transform)if(!std::isfinite(x))return;
 if(std::fabs(e.transform[15]-1.0f)>0.1f)return;
 e.valid=1;
}
}
extern "C" void RFGRVR_StereoTrace_CameraBegin(void* camera,void* renderer){
 Event e{};e.tick=GetTickCount(); e.renderer=static_cast<unsigned>(reinterpret_cast<uintptr_t>(renderer));
 Fill(e,camera);
 std::unique_lock<std::mutex> lock(guard,std::try_to_lock);if(!lock.owns_lock())return;
 e.frame=frame;events[nextEvent]=e;nextEvent=(nextEvent+1)%MAX_EVENTS;++totalEvents;
}
extern "C" void RFGRVR_StereoTrace_Present(){
 std::unique_lock<std::mutex> lock(guard,std::try_to_lock);if(!lock.owns_lock())return;
 ++frame;++presents;
}
extern "C" bool RFGRVR_StereoTrace_Export(){
 std::vector<Event> snapshot;unsigned nframes=0,npresents=0;size_t captured=0;
 {
  std::lock_guard<std::mutex> lock(guard);
  captured=(std::min)(totalEvents,MAX_EVENTS);snapshot.reserve(captured);
  size_t first=(totalEvents>=MAX_EVENTS)?nextEvent:0;
  for(size_t i=0;i<captured;++i)snapshot.push_back(events[(first+i)%MAX_EVENTS]);
  nframes=frame;npresents=presents;
 }
 char path[MAX_PATH]={};DWORD n=GetEnvironmentVariableA("LOCALAPPDATA",path,MAX_PATH);
 if(!n || n>=MAX_PATH)return false;
 if(strlen(path)+50>=MAX_PATH)return false;
 strcat_s(path,"\\RFGR-VR");CreateDirectoryA(path,nullptr);
 strcat_s(path,"\\Reports");CreateDirectoryA(path,nullptr);
 char file[MAX_PATH];sprintf_s(file,"%s\\Stereo-Pass-Trace-%lu-%lu.csv",path,GetCurrentProcessId(),GetTickCount());
 FILE* f=nullptr;if(fopen_s(&f,file,"wb") || !f)return false;
 fprintf(f,"# This is engine pass tracing, NOT a working stereo renderer.\n# captured=%zu total_presents=%u total_frames=%u\n",captured,npresents,nframes);
 fprintf(f,"frame,tick,camera,renderer,valid,x,y,z,m00,m01,m02,m03,m10,m11,m12,m13,m20,m21,m22,m23,m30,m31,m32,m33\n");
 for(const auto&e:snapshot){
  fprintf(f,"%u,%u,0x%08X,0x%08X,%u,%.7g,%.7g,%.7g",e.frame,e.tick,e.camera,e.renderer,e.valid,e.xyz[0],e.xyz[1],e.xyz[2]);
  for(float x:e.transform)fprintf(f,",%.9g",x);
  fputc('\n',f);
 }
 bool ok=ferror(f)==0; if(fclose(f)!=0)ok=false;
 if(ok){
  char summary[MAX_PATH]{}; strcpy_s(summary,file);
  char* ext=strrchr(summary,'.'); if(ext)strcpy_s(ext,MAX_PATH-(ext-summary),".txt");
  FILE* sf=nullptr;
  if(fopen_s(&sf,summary,"wb")==0 && sf){
   std::map<unsigned,unsigned> perFrame;
   std::map<unsigned,unsigned> perCamera;
   std::map<unsigned,unsigned> perRenderer;
   unsigned valid=0;
   for(const auto& e:snapshot){++perFrame[e.frame];++perCamera[e.camera];++perRenderer[e.renderer];valid+=e.valid?1:0;}
   unsigned maxCalls=0,multiPassFrames=0;
   for(const auto& kv:perFrame){maxCalls=(std::max)(maxCalls,kv.second);if(kv.second>1)++multiPassFrames;}
   fprintf(sf,"RFGR-VR automatic rendering survey\n");
   fprintf(sf,"Status: OBSERVATIONAL ONLY; no stereo replay function verified.\n");
   fprintf(sf,"PID=%lu\nCapturedCameraCalls=%zu\nPresentCallsSinceLoad=%u\nValidTransforms=%u\nFramesWithCameraCalls=%zu\nFramesWithMultipleCameraCalls=%u\nMaxCameraCallsPerFrame=%u\nUniqueCameraPointers=%zu\nUniqueRendererPointers=%zu\n",GetCurrentProcessId(),snapshot.size(),npresents,valid,perFrame.size(),multiPassFrames,maxCalls,perCamera.size(),perRenderer.size());
   fprintf(sf,"\nTop camera pointers by callback frequency:\n");
   std::vector<std::pair<unsigned,unsigned>> ranked(perCamera.begin(),perCamera.end());
   std::sort(ranked.begin(),ranked.end(),[](const auto&a,const auto&b){return a.second>b.second;});
   for(size_t i=0;i<(std::min)(size_t(20),ranked.size());++i)fprintf(sf,"0x%08X: %u calls\n",ranked[i].first,ranked[i].second);
   fprintf(sf,"\nNote: multiple camera begin calls per Present are not proof of multiple world passes. The instrumented hook is not the full-scene replay entry point.\n");
   fclose(sf);
  }
  strcpy_s(autoReport,file);
 }
 return ok;
}

extern "C" bool RFGRVR_GPUCapture_Start();
extern "C" bool RFGRVR_GPUCapture_Export();
namespace {
DWORD WINAPI SurveyWorker(LPVOID){
 Sleep(15000);
 InterlockedExchange(&autoState,2);
 bool ok=RFGRVR_StereoTrace_Export();
 bool gpuOk=RFGRVR_GPUCapture_Export();
 ok=ok && gpuOk;
 InterlockedExchange(&autoState,ok?3:4);
 return 0;
}
}
extern "C" bool RFGRVR_StereoTrace_AutoStart(){
 if(InterlockedCompareExchange(&autoRun,1,0)!=0)return false;
 InterlockedExchange(&autoState,1);
 if(!RFGRVR_GPUCapture_Start()){InterlockedExchange(&autoState,4);InterlockedExchange(&autoRun,0);return false;}
 HANDLE thread=CreateThread(nullptr,0,SurveyWorker,nullptr,0,nullptr);
 if(!thread){InterlockedExchange(&autoState,4);InterlockedExchange(&autoRun,0);return false;}
 CloseHandle(thread);return true;
}
extern "C" LONG RFGRVR_StereoTrace_AutoState(){return InterlockedCompareExchange(&autoState,0,0);}
