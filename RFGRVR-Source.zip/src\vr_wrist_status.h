#pragma once
#include "vr_mapping.h"
#include <windows.h>
#include <cstring>
#include <cstddef>
struct RFGRWristStatus {unsigned magic=0x57535432;volatile LONG sequence=0;DWORD pid=0,tick=0,hitTick=0,messageTick=0;unsigned twoHand=0,percent=0,hitPercent=0;char message[768]{};char vehicleControls[512]{};};
static constexpr wchar_t RFGR_WRIST_STATUS[]=L"Local\\RFGRVR_WristStatus_v2";
namespace vrstatus {inline SRWLOCK lock=SRWLOCK_INIT;inline RFGRWristStatus value{};inline RFGRWristStatus* shared=nullptr;inline HANDLE mapping=nullptr;
inline void commit(){value.pid=GetCurrentProcessId();value.tick=GetTickCount();
#ifndef RFGR_WRIST_STATUS_TEST
if(!shared){if(!mapping)mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(value),RFGR_WRIST_STATUS);if(mapping)shared=(RFGRWristStatus*)RFGRVR_MapViewOrClose(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(value));}if(shared){InterlockedIncrement(&shared->sequence);MemoryBarrier();memcpy(&shared->pid,&value.pid,sizeof(value)-offsetof(RFGRWristStatus,pid));shared->magic=value.magic;MemoryBarrier();InterlockedIncrement(&shared->sequence);}
#endif
}
inline void hold(bool active){AcquireSRWLockExclusive(&lock);value.twoHand=(value.twoHand&~1u)|(active?1u:0u);commit();ReleaseSRWLockExclusive(&lock);}
inline void focus(bool active){AcquireSRWLockExclusive(&lock);value.twoHand=(value.twoHand&~2u)|(active?2u:0u);commit();ReleaseSRWLockExclusive(&lock);}
inline void force(float strength,bool hit=false){unsigned percent=unsigned((strength<0?0:strength>1?1:strength)*100+.5f);AcquireSRWLockExclusive(&lock);value.percent=percent;if(hit){value.hitPercent=percent;value.hitTick=GetTickCount();}commit();ReleaseSRWLockExclusive(&lock);}
inline void vehicleMenu(const char* text,bool active){AcquireSRWLockExclusive(&lock);value.twoHand=(value.twoHand&~4u)|(active?4u:0u);if(active){strncpy_s(value.message,text,_TRUNCATE);value.messageTick=GetTickCount();}else{value.message[0]=0;value.messageTick=0;}commit();ReleaseSRWLockExclusive(&lock);}
inline void vehicleControls(const char* text){AcquireSRWLockExclusive(&lock);strncpy_s(value.vehicleControls,text,_TRUNCATE);commit();ReleaseSRWLockExclusive(&lock);}
inline void notify(const char* text){AcquireSRWLockExclusive(&lock);strncpy_s(value.message,text,_TRUNCATE);value.messageTick=GetTickCount();commit();ReleaseSRWLockExclusive(&lock);}
}
