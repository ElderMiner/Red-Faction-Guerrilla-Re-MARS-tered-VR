#include "../src/vr_sky_distance.h"
#include <cassert>
int main(){float p[12]={1,0,0,0,1,0,0,0,1,100,2,300};assert(RFGRVR_ExpandSky(p,32));assert(p[0]==32&&p[4]==32&&p[8]==32&&p[9]==100&&p[10]==2&&p[11]==300);assert(!RFGRVR_ExpandSky(p,32));
 // Scaling camera-centred geometry preserves projection while making
 // the same IPD produce 1/32 of its original disparity.
 float x=20,y=50,z=100;assert(fabsf(x/z-(x*32)/(z*32))<.00001f);assert(fabsf(y/z-(y*32)/(z*32))<.00001f);assert(fabsf((.064f/(z*32))/(.064f/z)-1.f/32)<.00001f);
}
