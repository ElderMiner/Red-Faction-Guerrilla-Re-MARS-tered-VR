# Historical development notes - not current instructions

Read the current README.md and MAINTAINING.md at the source root. This archive includes abandoned experiments.

# Maintaining the VR mod

The editable sources are `src/`, tests are `tests/`, and launcher/setup code
is `distribution/`. The game and companion still use the same native sources
as the development build; packaging does not fork or hide them.

## Build a release

Install Visual Studio C++ Desktop build tools and .NET Framework 4.x.
Run `BUILD-RELEASE.ps1` from PowerShell. It builds both architectures, the
launcher, the embedded-payload wizard, `release/RFGRVR-Setup.zip`, and its
SHA-256 companion file. It does not install anything or modify Steam.
Run `BUILD-TESTS.ps1` before packaging. No game files are needed to compile.
`distribution/supported-game.json` records the supported executable hash;
only change it after verifying a new game version against the native hooks.

## Configure GitHub updates

Set `repository` in `distribution/release.json` to `OWNER/REPOSITORY` and
increment `version` (numeric x.y.z). Keep `asset` as `RFGRVR-Setup.zip`.
Publish the ZIP and `RFGRVR-Setup.zip.sha256` to the same non-prerelease
GitHub Release tagged `vX.Y.Z`. Empty repository disables all update requests.
The launcher fetches GitHub's latest-release API only after VR is selected.
It offers an update button, checks HTTPS origin, package size and SHA-256,
then starts the same installer. Installation is not performed mid-game.

The provided `.github/workflows/release.yml` can build/test tagged releases.
It uploads artifacts for review; it does not publish a release automatically.
No GitHub repository, credentials or publishing permissions are needed locally.

## Update safety

The manifest names every payload file and SHA-256. Setup checks the game
version, blocks active game/companion processes, rejects escaping paths,
checks reparse points, stages and validates the entire payload, and backs up
replaced files. Failed copies restore the previous files. Update history
retains the original pre-mod files for uninstall. Personal INIs, calibration,
weapon grips, elbow profiles, APC layouts and game saves are never packaged.
The Steam integration modifies only app 667720's LaunchOptions, while Steam
is closed; the prior value is recorded. If integration is unchecked, launch
`RFGRVR/Launcher.exe` directly or set Steam Launch Options to:
`"FULL GAME PATH\RFGRVR\Launcher.exe" %command%`.

## Current verification limits

Transaction, settings, GPU mirror and rendering regressions are automated.
Quest/Index hardware, Steam launching, the live update download/install path,
and final headset behavior require live checks. Update packages use HTTPS
and SHA-256 from the configured repository, not a separate signing authority.


### Calibration fitting (0.10.15)

The three physical controller poses measure arm segments before fitting. Pose 1 retains its accepted palms-down demonstration. Poses 2/3 and post-calibration mirroring use the corrected palm reference. Verify the actual GPU images; the finger cross product alone is insufficient to identify the visible palm side.

During preview, body 8/5/7 changes torso size and moves the eye anchor with body height. Eyes 9/6 adjust height; 2/3 adjusts forward/back. Arm segments remain physical measured lengths. Confirmation computes the world appearance from fitted eye height, saves FittedWorldPercent, and uses model/fitted-world for local player geometry to avoid doubling scale. Only on-foot trims use these fields. Existing vehicle/mech/turret trims are separate.

GameAssets.PrepareScout extracts EDF Scout LOD0 from the local vehicles archive to RFGRVR/cache/edf-scout-v2.bin. The calibration renderer appends it as a static reference, excludes it from the self-body pass, and uses the same derived scene scale. Assets stay local and are never placed in release archives.


### Calibration correction (0.10.16)

The room now derives wrist orientation from the same bind-pose anatomical grip frame as native_arms.cpp. It no longer captures a T-pose wrist offset or adds a palm inversion when poses finish. Controller grip centres are converted to wrist positions using the native handprop offset. Glove/finger offsets retain their physical size during torso resizing.

Keep sourceShoulder distinct from the reach-adjusted shoulder. Segment helper skinning must use the original source joint for its source axis/radial coordinates; using the shifted shoulder deforms the sleeves. Fixed measured lengths remain hard constraints.

Scout cache v2 assembles each visible native part using its local rotation/translation and parent links (indices in the part table exclude the root body). Indices may share strip-connector vertices across parts, so duplicate/map vertices per part before transforming. Skip wheelhulls/proxy and debris submeshes. The old cache omitted these transforms and piled local wheels/doors at the origin. A front-view GPU render was inspected to verify four wheels and the turret; no assets are redistributed.


### Controller-only arm solver (0.10.17)

Only controller position/orientation is tracked live for each arm. Shoulder and segment sizes come from the avatar/calibration. The live wrist is C + R*offset. Four poses now record T-pose, straight arms with ONLY wrists bent up, elbows bent with forearms up, then arms overhead. The first two poses fit the controller-local wrist offset using regularized least squares; the rotation-axis component is not observable from one bend, so it retains an anatomical prior. Reject large offsets or inconsistent stationary-wrist residuals. Persist under WristPivot in arm-pose-calibration.ini, without changing other personal settings.

Free-hand wrist orientation is the complete tracked orientation through the anatomical grip mapping. Do not reintroduce constrainedWrist in the live hand path: its decomposition could suppress wrist motion. Native skin weights and finger joints remain active; forearm twist helpers do not receive glove roll.

The preview and gameplay share a law-of-cosines two-segment solver, torso-relative downward/outward pole, bounded swivel, minimum shoulder/wrist distance and extension limits. Free hands clamp unreachable wrist positions with a fixed shoulder and fixed lengths. Attached weapon/turret hands retain their authored grip constraints. Wrist orientation is not elbow-position evidence, and no live elbow tracker is assumed. Position-only learned profiles can regularize elbow preference; old orientation-dependent inference is not used.

Tests cover the four-pose flow, fitted fixed wrist under rotation, complete glove orientation, invariant elbow/forearm during isolated wrist motion, both arm lengths, near-shoulder/vertical/cross-body limits, held grips and NPC ownership. Real-asset GPU render of the new wrist-only demonstration was inspected.


### Directional wrist capture and calibration landmarks (0.10.18)

Stage 2 must check direction, not just controller quaternion difference. Capture each hand's outward longitudinal direction in controller-local space from the neutral T-pose/hand span. A wrist-only capture requires both transformed hand directions to point upward (dot world-up >= .65), plus the existing motion/pivot consistency checks. Re-check the averaged pose before committing. Flat wrist poses, including a rolled grip with unchanged longitudinal direction, must not advance.

Landmarks are captured per accepted step: controller/hand centre, fitted wrist pivot, inferred elbow from the forearm-up pose, inferred shoulder from the overhead pose. Accepted flags survive failed later samples and clear on reset. Render white spheres at the captured STAGE points and their geometric mirror. Do not attach them to live moving bones or scale the locked measurements with the body. Apply only the existing eye-preview origin shift. The calibration-owned private DSV is cleared just before the marker pass so internal joint pivots remain visible through the avatar; this does not touch game/APC depth. Marker geometry/VB is bounded to 16 sphere copies and reused, and drawing ends when calibration releases.

Tests cover flat/rolled-grip rejection, correct hands-up acceptance, point capture order/persistence, mirrored point coordinates, resizing invariance and real-GPU white-marker pixels. Diagnostics include wristLiftLeft/Right and landmark count in calibration-scene-state.json.


### Maximum reach and mirrored elbows (0.10.19)

Extended T-pose wrists now constrain total arm reach. The overhead pose provides shoulder X/Z at T-pose height; the elbow pose splits the chain. Forearm length is total measured reach minus upper-arm length, rather than the vertical rise of the bent wrist (which silently shortened arms when upper arms dipped). The head/neck-relative shoulder reference and full landmark capture are persisted under ArmReach with versioning; older profiles retain their legacy path until recaptured. Segment lengths are fixed after capture.

On foot, arm shoulders are retargeted from the calibrated neck-relative reference, keeping arm reach independent of torso resizing. Preview and gameplay use the same physical reference, with eye/body tuning applied as a shared origin shift. Driver/gunner/standing turret attachment paths are excluded. World/root transforms still come from the existing tracking pipeline, and all writes remain scoped to owned local-player meshes.

Both elbows use one canonical right-arm positional heuristic, reflected for the left. Per-side rotation references and learned controller-orientation cues cannot select a different bend branch. Gameplay solves in torso space, not a sometimes-rotated render-root frame. Bone rotations align to the position-derived bend plane as well as the segment axis; wrist roll is not propagated into forearm helpers. A small nonzero extension margin prevents degeneracy while reaching the calibrated maximum to submillimetre test tolerance.

Calibration numpad controls now work while the headset is focused/rendering even if the desktop launcher loses focus. Enter is still desktop-focus gated. Diagnostics include bodyPercent, key event count, last key, headset focus and tuning eligibility. No global typing or gameplay input policy changes outside calibration.

Tests cover a dipped elbow capture preserving total T-pose reach, maximum extension at 60/100/160% body size, shoulder reference/eye-shift consistency, 360 mirrored target poses including mirrored mesh rotations, wrist independence, fixed lengths and legacy authored grips.

### 0.10.20 — character-owned shoulders
Supersedes the 0.10.19 shoulder retarget: native rig shoulder/clavicle transforms follow the character torso only. No head-relative or overhead-controller shoulder translation remains. Calibration fits total reach and segment lengths against the actual preview rig shoulders; the neutral-wrist elbow pose solves the rigid triangle. Overhead capture cannot change shoulder roots or fitted lengths. Wrist pivot, mirrored elbow heuristic, independent arm lengths and room layout remain. Shoulder landmark spheres follow rig joints while resizing. ArmReach version 2 records CharacterRig ownership; old shoulder metadata is diagnostic only. Native player ownership and NPC isolation gates are unchanged. Regression coverage includes body scales, head turns, arbitrary hand movement and deliberately asymmetric overhead capture.

### 0.10.21 — room/gameplay fit and scale reference
Keeps 0.10.20 character-owned shoulders and fixed measured arm lengths. On-foot eyes now use the calibration room centered reference and saved physical eye offsets, excluding legacy vehicle/native forward trim; stance motion applies only its delta. Vehicle camera paths remain separate. Free-hand/arm radial dimensions match room sizing; occupied hands retain authored weapon geometry and attachment frames. Distal forearm helper receives up to 50% wrist roll; elbow root stays unrolled and wrist/finger tracking remains complete. New body-fit/reset default is 110%; existing manual settings are preserved. A static textured Mason scale reference stands beside the Scout; no gameplay NPC changes. Tests cover half-roll, stable elbow, zero extra eye offset, fixed weapon-local wrists across body sizes and GPU reference rendering.

### 0.10.22 — restore confirmed arms
Reverts 0.10.21 free-hand geometry/finger scaling, on-foot eye-reference rewrite, 110% automatic/reset fit and added scale mannequin. Keeps 0.10.20 rig-owned shoulders/arm fitting, and retains the requested 50% glove-cuff roll. Personal eye/body/world tuning files are preserved. Upper-arm and forearm measurements are averaged across both sides after capture and while loading an older valid profile; invalid bilateral profiles use the prior span fallback on both sides. Wrist pivot offsets remain controller-specific. Occupied hands retain exact authored weapon-local grips, with scale regression coverage. No NPC, vehicle or weapon placement changes.

### 0.10.23 — calibrated eyes, shaft grip, native power impact and lens ghosts
Only on-foot eye reference is changed: the room and game share a centered neutral eye with saved physical eye-height/depth offsets. Removes extra native eye X/Z and general vehicle-forward trim from that on-foot reference; crouch/landing adds only animated deltas. No arm/shoulder sizing changes. Tests compare physical camera/body coordinates across scale and height combinations. Shaft support attachment now starts at its saved position/orientation; later controller span/roll changes are relative to acquisition, preserving sliding without rebasing the saved grip. Read-only live capture confirmed substantial slider displacement. A qualifying two-hand right-trigger sledge strike uses the complete native profile (live profile radius0.4, structure damage1500) rather than kinetic-strength reduction. Existing swing-intent gate and NPC/structure contact limits remain; no animation is triggered. Separately identified native lens-ghost renderer13F8C0 is signature-checked and suppressed in VR with exact thiscall/two-argument ABI. Existing sun-sprite/composite guards remain. No bloom, world lighting, NPC skeleton, vehicle seat or saved grip changes. Tests include actual sweep execution/full power at submaximum speed, off-centre shaft acquisition, relative roll, both-eye lens skipping and full eye/menu/native regression.

### 0.10.24 — six-step saved calibration and facing-on-open panels
Includes the pending 0.10.23 eye/grip/power-sledge/lens corrections. T-pose acceptance allows moderate height/hand asymmetry and motion; flat wrists still cannot satisfy wrist-up capture. Bent-forearm fitting uses the full tracked finger direction and is tested with palm-forward axial rotation. Four arm poses are followed by automatic horizontal and vertical head-target sweeps (no triggers). The bounded 40Hz pose recording solves eye-minus-rotated-local-pivot using both rotation axes and per-phase centering; observable fits with <=25mm residual and plausible offset are accepted. Body drift rejects/repeats the sweeps. The measured pivot feeds room body translation, native room-scale translation and mounted-body tracking; idle torso yaw no longer follows head-only turns. Stick turning/movement are retained. All six stages must succeed before a Complete/version6 profile is committed. Later launches perform one T-pose alignment using saved symmetric arm lengths/wrist offsets/head pivot. B/right secondary or F2 selects Advanced T-pose in the room, including after quick alignment. Existing body/eye scale controls and explicit continue/fade remain. Menus/popups/loading/video mode transitions reacquire an upright stage anchor from the current HMD yaw, then remain world anchored. Head sweep ball uses the same eye-tuning coordinate shift as the room camera. Tests cover known-pivot recovery, drift rejection, guided-sweep completion, saved/incomplete profile round trip, palm-forward lengths, head-only torso stability, menu facing changes, native weapon grips and unchanged stereo/NPC ownership.

### 0.10.25 — positional elbow arc and shared cleaned torso/view motion
Elbow fitting uses the equal-radius centre of wrist positions from straight-arm and bent-arm captures, constrained to the first T-pose horizontal arm line. Both positions are projected into the vertical plane through the initial head/left/right axis, excluding forward/back drift and palm orientation from the fit. Fixed character shoulders remain authoritative; segment lengths remain bilateral averages. ArmFitMethod2 requires one corrected arm recapture; the already-valid measured head pivot is retained automatically. Explicit B/F2 Advanced still performs all six stages; subsequent completed profiles use one T-pose.

Live capture found camera and arm scale0.94017 with steady torso joints restored at native scale. Cleaned spine/head joints and the lean pivot now use the same actor scale as shoulders. The camera consumes the actual cleaned torso's head-motion delta, retaining the rendered root and saved eye offsets, instead of independently recreating lean. Physical-crouch eye handling retains its existing path to avoid applying the crouch twice. No native leg gait, NPC ownership, or vehicle-camera rewrite.

Live glove basis matched the room, but its palm centre differed by4–5cm because the native handprop tag was animated. Anatomical palm centre now uses verified mesh bind positions. Sledge/Gutter support sliding preserves saved radial offsets and slides/rolls on the authored Y shaft, with acquisition-relative movement retained. Saved grip files are not changed.

Live inspection confirmed the sprite, lens and composite hooks were active while SunGlare01 was zero. The named DwnsmpldSunShafts resource is self+AAC and bound independently by the final composite. The signature-checked scoped suppression now nulls that source as well as978, restoring both engine-owned pointers after the pass; ordinary bloom/exposure/lighting remain enabled. Tests cover palm/depth-invariant elbow centres, bind-centre stability despite animated tags, radial shaft sliding, scale0.94017 torso fitting, cleaned torso/camera offsets, dual-source suppression/restoration and full stereo/menu/native regressions. Headset results remain pending.
