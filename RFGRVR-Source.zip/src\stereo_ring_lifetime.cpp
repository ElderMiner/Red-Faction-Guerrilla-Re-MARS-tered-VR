#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include "../vendor/MinHook.h"
namespace ringlife {
using Draw=void(__thiscall*)(void*,void*,unsigned,unsigned,unsigned,unsigned,bool);
Draw originalDraw=nullptr;void* originalRetire=nullptr;void* skipRetire=nullptr;unsigned char* module=nullptr;
thread_local bool holdCurrent=false;std::atomic<bool> active{false};SRWLOCK lock=SRWLOCK_INIT;
struct Reservation {void* ring;unsigned start,end,blocks;};Reservation reservations[8192]{};unsigned count=0;std::atomic<unsigned> held{0},duplicates{0};
static bool readable(void* p,size_t n){MEMORY_BASIC_INFORMATION m{};if(!p||!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||m.Protect&(PAGE_GUARD|PAGE_NOACCESS))return false;auto a=(uintptr_t)p,b=(uintptr_t)m.BaseAddress;return a>=b&&n<=m.RegionSize&&a-b<=m.RegionSize-n;}
static bool enqueue(void* ring,unsigned topology,unsigned start,unsigned primitives,unsigned blocks){
 if(!blocks||topology>10||!readable(ring,0x70))return false;
 // Reproduce the engine's jump-table vertex count and stride calculation.
 unsigned selector=module[0x14cb68+topology];if(selector>2)return false;
 unsigned target=*(unsigned*)(module+0x14cb60+selector*4)-(unsigned)(uintptr_t)module;
 unsigned vertices=target==0x14cb00?primitives*2:target==0x14cb06?primitives+2:target==0x14cb09?0:0xffffffffu;
 if(vertices==0xffffffffu)return false;unsigned stride=*(unsigned*)(module+0x10fa34c+topology*4);uint64_t end=(uint64_t)start+(uint64_t)vertices*stride;
 if(end>*(unsigned*)((char*)ring+0x14))return false;
 AcquireSRWLockExclusive(&lock);
 for(unsigned i=0;i<count;++i)if(reservations[i].ring==ring&&reservations[i].start==start&&reservations[i].end==(unsigned)end&&reservations[i].blocks==blocks){ReleaseSRWLockExclusive(&lock);++duplicates;return true;}
 if(count==8192){ReleaseSRWLockExclusive(&lock);return false;}
 reservations[count++]={ring,start,(unsigned)end,blocks};ReleaseSRWLockExclusive(&lock);++held;return true;
}
static bool __cdecl shouldHold(){return holdCurrent;}
__declspec(naked) static void RetirementGate(){__asm {
 pushfd
 pushad
 call shouldHold
 test al,al
 jz ordinary
 popad
 popfd
 jmp dword ptr [skipRetire]
 ordinary:
 popad
 popfd
 jmp dword ptr [originalRetire]
}}
static void __fastcall OnDraw(void* ring,void*,void* renderer,unsigned topology,unsigned start,unsigned primitives,unsigned blocks,bool fromRing){
 bool previous=holdCurrent;holdCurrent=active.load(std::memory_order_acquire)&&fromRing&&enqueue(ring,topology,start,primitives,blocks);
 originalDraw(ring,renderer,topology,start,primitives,blocks,fromRing);holdCurrent=previous;
}
}
extern "C" bool RFGRVR_RingPair_Install(){
 using namespace ringlife;module=(unsigned char*)GetModuleHandleW(nullptr);
 const unsigned char drawSig[]={0x83,0xec,0x38,0xa1},retireSig[]={0x80,0x7c,0x24,0x60,0};
 if(memcmp(module+0x14c9f0,drawSig,sizeof(drawSig))||memcmp(module+0x14cae4,retireSig,sizeof(retireSig)))return false;
 skipRetire=module+0x14cb3d;
 if(MH_CreateHook(module+0x14cae4,(void*)&RetirementGate,&originalRetire)!=MH_OK)return false;
 if(MH_CreateHook(module+0x14c9f0,(void*)&OnDraw,(void**)&originalDraw)!=MH_OK){MH_RemoveHook(module+0x14cae4);return false;}
 if(MH_EnableHook(module+0x14cae4)!=MH_OK)return false;
 if(MH_EnableHook(module+0x14c9f0)!=MH_OK){MH_DisableHook(module+0x14cae4);return false;}return true;
}
extern "C" void RFGRVR_RingPair_Begin(){using namespace ringlife;AcquireSRWLockExclusive(&lock);count=0;held=0;duplicates=0;ReleaseSRWLockExclusive(&lock);active=true;}
extern "C" void RFGRVR_RingPair_End(){
 using namespace ringlife;active=false;AcquireSRWLockExclusive(&lock);
 unsigned released=count;for(unsigned i=0;i<count;++i){auto& r=reservations[i];
 // Same terminal accounting as 14CB16..14CB28, exactly once per reservation.
 InterlockedExchangeAdd((volatile LONG*)((char*)r.ring+0x68),-(LONG)r.blocks);
 InterlockedExchange((volatile LONG*)((char*)r.ring+0x64),(LONG)r.end);
 }count=0;ReleaseSRWLockExclusive(&lock);
 wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,92);if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-Ring-Lifetime.log");FILE* f=nullptr;if(!_wfopen_s(&f,path,L"a")&&f){fprintf(f,"held=%u duplicateUses=%u released=%u\n",held.load(),duplicates.load(),released);fclose(f);}}
}

