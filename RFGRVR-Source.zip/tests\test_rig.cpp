#include "../src/vr_rig_math.h"
#include <cassert>
int main(){
 assert(RFGRVR_SmoothTurn(.19f,.016f)==0);assert(std::fabs(RFGRVR_SmoothTurn(1,.02f)-1.5f)<.00001f);
 assert(RFGRVR_SmoothTurn(-1,.02f)==-RFGRVR_SmoothTurn(1,.02f));assert(RFGRVR_SmoothTurn(1,10)==3.75f);
 float identity[3][3]={{1,0,0},{0,1,0},{0,0,1}},vehicle[3][3]={{0,0,-1},{0,1,0},{1,0,0}},out[3][3];
 RFGRVR_ParentBasis(identity,vehicle,identity,out);for(int i=0;i<3;++i)for(int j=0;j<3;++j)assert(out[i][j]==vehicle[i][j]);
 RFGRVR_ParentBasis(vehicle,vehicle,identity,out);for(int i=0;i<3;++i)for(int j=0;j<3;++j)assert(out[i][j]==identity[i][j]);
}
