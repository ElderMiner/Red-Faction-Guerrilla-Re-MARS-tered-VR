#pragma once
#include <cmath>
#include <cstdint>
#include <algorithm>
struct RFGRVRCoverage {unsigned width=0,height=0;float pixelsPerTangent=0;};
inline bool RFGRVR_CoverageSize(unsigned baseWidth,unsigned baseHeight,float baseVFov,const float eyeFovs[2][4],RFGRVRCoverage* out){
 if(!out||!baseWidth||!baseHeight||!std::isfinite(baseVFov)||baseVFov<30||baseVFov>150)return false;
 const float density=baseHeight/std::tan(baseVFov*3.14159265358979323846f/360.f);
 float tx=0,ty=0;
 for(unsigned eye=0;eye<2;++eye){const float* f=eyeFovs[eye];if(!(f[0]<0&&f[1]>0&&f[2]>0&&f[3]<0))return false;
  for(unsigned i=0;i<4;++i){if(!std::isfinite(f[i])||std::fabs(f[i])>=1.5f)return false;float t=std::fabs(std::tan(f[i]));if(i<2)tx=(std::max)(tx,t);else ty=(std::max)(ty,t);}}
 const auto align=[](float n){return (unsigned(std::ceil(n))+15u)&~15u;};
 const unsigned width=align((std::max)(float(baseWidth),density*tx*1.03f)),height=align((std::max)(float(baseHeight),density*ty*1.03f));
 if(width>8192||height>8192||static_cast<unsigned long long>(width)*height>32000000)return false;
 *out={width,height,density};return true;
}
inline float RFGRVR_MenuAspect(unsigned width,unsigned height){return width&&height?float(width)/height:16.f/9.f;}
struct RFGRVRFitRect {float x,y,width,height;};
inline RFGRVRFitRect RFGRVR_FitImage(unsigned sourceWidth,unsigned sourceHeight,unsigned targetWidth,unsigned targetHeight){
 if(!sourceWidth||!sourceHeight||!targetWidth||!targetHeight)return {};
 const float scale=(std::min)(float(targetWidth)/sourceWidth,float(targetHeight)/sourceHeight);
 const float w=(std::min)(float(targetWidth),sourceWidth*scale),h=(std::min)(float(targetHeight),sourceHeight*scale);
 return {(targetWidth-w)*.5f,(targetHeight-h)*.5f,w,h};
}

// Central pixels per visual degree; preserve the headset's complete ray coverage.
inline bool RFGRVR_PPDSize(int ppd,const float fovs[2][4],unsigned* width,unsigned* height){
 if(!width||!height||ppd<1||ppd>25)return false;float x=0,y=0;
 for(unsigned e=0;e<2;++e){auto* f=fovs[e];if(!(f[0]<0&&f[1]>0&&f[2]>0&&f[3]<0))return false;for(unsigned i=0;i<4;++i){if(!std::isfinite(f[i])||fabsf(f[i])>=1.5f)return false;float v=fabsf(tanf(f[i]));if(i<2)x=(std::max)(x,v);else y=(std::max)(y,v);}}
 float density=ppd*57.295779513f;unsigned w=(unsigned(ceilf(2*x*density))+15u)&~15u,h=(unsigned(ceilf(2*y*density))+15u)&~15u;
 if(w<640||h<360||w>8192||h>8192||uint64_t(w)*h>32000000)return false;*width=w;*height=h;return true;
}
