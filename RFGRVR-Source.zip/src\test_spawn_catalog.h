#pragma once
#include <cstring>
namespace vrtestspawn {
struct Entry {const char* name;const char* label;bool turret;};
inline constexpr Entry entries[]={
 {"Mar_Jetter_1","Marauder Jetter",false},{"Mar_Raider_1","Marauder Raider",false},
 {"turret_machinegun","Standing machine gun",true},{"turret_gauss","Standing Gauss",true},
 {"turret_rocket","Standing rocket launcher",true},{"turret_harpoon","Standing harpoon",true},{"artillery_gun","Standing artillery",true}};
inline const Entry* find(const char* name){if(name)for(auto& e:entries)if(!strcmp(e.name,name))return &e;return nullptr;}
}
