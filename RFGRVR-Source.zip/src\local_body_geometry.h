#pragma once
// Included after the local-player mesh registry. Borrow private mesh headers
// only for one headset scene pass; shared assets and NPC pointers stay intact.
namespace LocalBodyGeometry {
template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
struct Cache {void* original=nullptr;Ptr<ID3D11Buffer> vertex,index,filtered;alignas(16) unsigned char mesh[0x90]{};};
inline Cache cache[PlayerMeshSlots];inline void** fields[PlayerMeshSlots]{};inline void* originals[PlayerMeshSlots]{};
inline bool readBuffer(ID3D11Device* device,ID3D11DeviceContext* context,ID3D11Buffer* source,std::vector<unsigned char>& bytes){D3D11_BUFFER_DESC d{};source->GetDesc(&d);if(!d.ByteWidth||d.ByteWidth>8*1024*1024)return false;d.Usage=D3D11_USAGE_STAGING;d.BindFlags=0;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;d.MiscFlags=d.StructureByteStride=0;Ptr<ID3D11Buffer> staging;if(FAILED(device->CreateBuffer(&d,nullptr,&staging)))return false;context->CopyResource(staging.Get(),source);D3D11_MAPPED_SUBRESOURCE mapped{};if(FAILED(context->Map(staging.Get(),0,D3D11_MAP_READ,0,&mapped)))return false;bytes.assign((unsigned char*)mapped.pData,(unsigned char*)mapped.pData+d.ByteWidth);context->Unmap(staging.Get(),0);return true;}
inline void end(){for(unsigned i=0;i<PlayerMeshSlots;++i){if(fields[i]&&memory(fields[i],4,true)&&*fields[i]==cache[i].mesh)*fields[i]=originals[i];fields[i]=nullptr;originals[i]=nullptr;}}
inline void begin(){
 end();auto config=vrsettings::get();if(!config.value[vrsettings::Body]||cinematicArms||!RFGRVR_HeadCam_Enabled())return;
 HeadMesh meshes[PlayerMeshSlots];AcquireSRWLockShared(&headMeshLock);memcpy(meshes,headMeshes,sizeof(meshes));ReleaseSRWLockShared(&headMeshLock);
 for(unsigned slot=0;slot<PlayerMeshSlots;++slot){const auto& m=meshes[slot];unsigned state=word(m.player,0x2f4);if(!validHeadOwner(m)||(state>=7&&state<=10&&!config.value[vrsettings::Vehicles])||!memory(m.character,0x38)||int(word(m.character,0))!=m.handle||pointer(m.character,0x30)!=m.renderable||!memory(m.renderable,0xf0))continue;
  auto** field=(void**)((char*)m.renderable+0xec);void* mesh=*field;
  if(!memory(mesh,0x90))continue;unsigned topology=word(mesh,0x84);if(topology!=D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST&&topology!=D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP)continue;
  auto* vertex=(ID3D11Buffer*)pointer(mesh,0x64);auto* index=(ID3D11Buffer*)pointer(mesh,0x6c);if(!memory(vertex,4)||!memory(index,4))continue;
  auto& c=cache[slot];if(c.original!=mesh||c.vertex.Get()!=vertex||c.index.Get()!=index||!c.filtered){
   c={};c.original=mesh;c.vertex=vertex;c.index=index;Ptr<ID3D11Device> device;vertex->GetDevice(&device);Ptr<ID3D11DeviceContext> context;device->GetImmediateContext(&context);
   unsigned stride=word(mesh,0x40)&255u,count=word(mesh,0x70),size=word(mesh,0x50)&255u;if(stride!=32||count>1000000)continue;
   vrbody::HandRegion region;auto* bones=(unsigned char*)pointer(m.rig,0x38);auto* map=(signed char*)pointer(m.instance,0x124);if(!memory(bones,m.count*36)||!memory(map,m.count+12))continue;
   for(unsigned i=0;i<m.count;++i)if(m.glove[i]){int physical=map[i+12];if(physical<0||physical>=int(m.count))continue;V bind{};memcpy(&bind,bones+physical*36+4,12);if(finite(bind))region.joint[region.count++]=mul(bind,-1);}
   std::vector<unsigned char> vb,ib,filtered;if(!readBuffer(device.Get(),context.Get(),vertex,vb)||!readBuffer(device.Get(),context.Get(),index,ib))continue;
   std::vector<unsigned> groups;unsigned groupCount=word(mesh,0x50)>>16;void* groupData=pointer(mesh,0x54);if(topology==D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP){if(!groupCount||groupCount>128||!memory(groupData,groupCount*20))continue;for(unsigned g=0;g<groupCount;++g){unsigned start=word(groupData,g*20+4),length=word(groupData,g*20+8);if(start>count||length>count-start){groups.clear();break;}groups.push_back(start);}if(groups.size()!=groupCount)continue;}
   vrbody::completeGloves(vb.data(),unsigned(vb.size()),stride,ib.data(),unsigned(ib.size()),count,size,topology==D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP,region,groups.data(),unsigned(groups.size()));
   unsigned kept=topology==D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP?vrbody::filterStrip(vb.data(),unsigned(vb.size()),stride,ib.data(),unsigned(ib.size()),count,size,region,filtered,groups.data(),unsigned(groups.size())):vrbody::filter(vb.data(),unsigned(vb.size()),stride,ib.data(),unsigned(ib.size()),count,size,region,filtered);if(kept==~0u)continue;
   D3D11_BUFFER_DESC d{};index->GetDesc(&d);d.Usage=D3D11_USAGE_IMMUTABLE;d.BindFlags=D3D11_BIND_INDEX_BUFFER;d.CPUAccessFlags=d.MiscFlags=d.StructureByteStride=0;D3D11_SUBRESOURCE_DATA data{filtered.data(),0,0};if(FAILED(device->CreateBuffer(&d,&data,&c.filtered)))continue;
   char notice[160];sprintf_s(notice,"Gloves geometry: part=%u retained=%u/%u triangles complete_components=%u",slot,kept,count/3,unsigned(region.components.size()));log(notice);
  }
  if(!c.filtered)continue;memcpy(c.mesh,mesh,sizeof(c.mesh));auto* replacement=c.filtered.Get();memcpy(c.mesh+0x6c,&replacement,4);originals[slot]=mesh;fields[slot]=field;*field=c.mesh;
 }
}
}
