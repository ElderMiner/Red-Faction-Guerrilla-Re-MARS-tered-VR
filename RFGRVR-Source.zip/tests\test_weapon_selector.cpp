#define NOMINMAX
#include "../src/vr_weapon_selector.h"
#include <cassert>
#include <cstdio>
int main(){RFGRVRWeaponSelector wheel;RFGRPose head{},hand{};head.orientation[3]=hand.orientation[3]=1;head.validFlags=hand.validFlags=3;hand.active=1;hand.position[1]=1;
 assert(!wheel.update(false,true,head,hand));assert(!wheel.update(true,true,head,hand,100));assert(!wheel.update(true,true,head,hand,599));assert(wheel.update(true,true,head,hand,600)&&!wheel.selected);RFGRPose anchor=wheel.anchor;
 hand.position[0]=.08f;assert(wheel.update(true,true,head,hand)&&wheel.selected==0x2000);assert(!memcmp(anchor.position,wheel.anchor.position,12));
 assert(wheel.buttons(0x200)==0x2200);assert(wheel.buttons(0x8200)==0x8200);assert(wheel.buttons(0x1200)==0x1200);
 hand.position[0]=-.08f;assert(wheel.update(true,true,head,hand)&&wheel.selected==0x4000);
 hand.position[0]=0;hand.position[1]=1.08f;assert(wheel.update(true,true,head,hand)&&wheel.selected==0x8000);
 hand.position[1]=.92f;assert(wheel.update(true,true,head,hand)&&wheel.selected==0x1000);
 hand.position[1]=1;assert(wheel.update(true,true,head,hand)&&!wheel.selected);assert(!wheel.update(false,true,head,hand)&&!wheel.active);
 assert(!wheel.update(true,true,head,hand,1000));assert(wheel.update(true,true,head,hand,1500));hand.orientation[1]=-.25f;hand.orientation[3]=sqrtf(1-.25f*.25f);assert(wheel.update(true,true,head,hand)&&wheel.selected==0x2000);wheel.update(false,true,head,hand);
 assert(!wheel.update(true,false,head,hand));hand.validFlags=0;assert(!wheel.update(true,true,head,hand));
 hand.validFlags=3;RFGRVRWeaponSelector touch;assert(touch.update(true,true,head,hand,2000,0)&&touch.active);assert(!touch.update(false,true,head,hand,2001,0));assert(!touch.update(true,true,head,hand,2100));assert(!touch.update(true,true,head,hand,2599));assert(touch.update(true,true,head,hand,2600));
 puts("PASS: native selector directions, deadzone, stable anchor, release and invalid tracking");}
