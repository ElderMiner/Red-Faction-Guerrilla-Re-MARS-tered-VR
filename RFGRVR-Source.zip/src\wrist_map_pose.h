#pragma once
#include "ipc.h"
#include <cmath>
inline bool RFGRVR_WristPose(const RFGRPose& hand,RFGRPose& out){if((hand.validFlags&3)!=3||!hand.active)return false;float x=hand.orientation[0],y=hand.orientation[1],z=hand.orientation[2],w=hand.orientation[3];float n=std::sqrt(x*x+y*y+z*z+w*w);if(!std::isfinite(n)||n<.1f)return false;x/=n;y/=n;z/=n;w/=n;
 // Inner left wrist: display normal +grip X, top toward the fingers (-Z).
 constexpr float ox=.025f,oy=.10f,oz=0;
 out=hand;out.position[0]+= (1-2*(y*y+z*z))*ox+2*(x*y-z*w)*oy+2*(x*z+y*w)*oz;
 out.position[1]+=2*(x*y+z*w)*ox+(1-2*(x*x+z*z))*oy+2*(y*z-x*w)*oz;
 out.position[2]+=2*(x*z-y*w)*ox+2*(y*z+x*w)*oy+(1-2*(x*x+y*y))*oz;
 out.orientation[0]=-.5f*w+.5f*x-.5f*y-.5f*z;out.orientation[1]=.5f*w+.5f*x+.5f*y-.5f*z;out.orientation[2]=-.5f*w+.5f*x+.5f*y+.5f*z;out.orientation[3]=.5f*w+.5f*x-.5f*y+.5f*z;
 for(float v:out.position)if(!std::isfinite(v))return false;return true;
}
inline bool RFGRVR_VehicleMapPose(const RFGRPose& head,const RFGRPose& left,const RFGRPose& right,RFGRPose& out){
 if((head.validFlags&3)!=3||(left.validFlags&3)!=3||(right.validFlags&3)!=3||!left.active||!right.active)return false;
 const float x=head.orientation[0],y=head.orientation[1],z=head.orientation[2],w=head.orientation[3];
 const float norm=x*x+y*y+z*z+w*w;if(!std::isfinite(norm)||norm<.9f||norm>1.1f)return false;
 float dx=right.position[0]-left.position[0],dz=right.position[2]-left.position[2];
 float yaw=dx*dx+dz*dz>.0064f?std::atan2(-dz,dx):std::atan2(2*(x*z+w*y),1-2*(x*x+y*y));float sy=std::sin(yaw*.5f),cy=std::cos(yaw*.5f);
 out=left;for(int i=0;i<3;++i){out.position[i]=(left.position[i]+right.position[i])*.5f;if(!std::isfinite(out.position[i]))return false;}
 out.position[1]-=.12f;
 // Face the driver and tilt upward, like a small panel on the wheel.
 constexpr float pitch=-.5f,cp=.8660254038f;
 out.orientation[0]=cy*pitch;out.orientation[1]=sy*cp;out.orientation[2]=-sy*pitch;out.orientation[3]=cy*cp;return true;
}
