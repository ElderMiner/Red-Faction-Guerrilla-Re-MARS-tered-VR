#pragma once
#include <algorithm>
#include "vr_arm_math.h"
#include "vr_elbow_profile.h"
// The tracked wrist is a hard constraint. Only the unobserved arm swivel is estimated.
struct RFGRVRElbowEstimator {
 vrarm::V bend{},lastTarget{};bool ready=false;const RFGRVRElbowProfile* profile=nullptr;
 vrarm::V evidenceHand{},evidenceElbow{};vrarm::M evidenceRotation{};float evidenceTime=0;bool evidenceReady=false;unsigned pivot=0;
 vrarm::V update(int positiveSide,vrarm::V shoulder,const vrarm::Pose& hand,float seconds,const vrarm::M* controller=nullptr,float upper=.3f,float lower=.3f,float scale=1){
  using namespace vrarm;
  V delta=sub(hand.p,shoulder),axis=unit(delta,{0,0,1});
  auto project=[&](V v){return sub(v,mul(axis,dot(v,axis)));};
  float outward=positiveSide?1.f:-1.f;
  V desired=unit(project({outward*.15f,-1.f,-.15f}),{outward,0,0});
  V relaxed=desired;
  if(profile&&controller&&profile->infer(positiveSide!=0,axis,length(delta)/scale,*controller,desired)){
   // Regularize ambiguous high/outward swivel toward a relaxed elbow. This
   // changes only the invisible joint preference, never the tracked wrist.
   float agreement=(std::clamp)(dot(desired,relaxed),0.f,1.f),relaxation=.2f+.25f*(1-agreement);
   desired=unit(add(mul(desired,1-relaxation),mul(relaxed,relaxation)),relaxed);
  }
  bool reset=!ready||!std::isfinite(seconds)||seconds<=0||seconds>.2f||length(sub(hand.p,lastTarget))>.6f*scale;
  M rotation=controller?*controller:hand.b;
  // Over a short window, compare the measured displacement against three rigid
  // rotation hypotheses: wrist (no translation), fixed elbow, fixed shoulder.
  // A wrist rotation alone is never evidence for changing the elbow swivel.
  if(reset){evidenceReady=false;evidenceTime=0;pivot=0;}
  if(evidenceReady&&!reset&&valid(rotation)){
   evidenceTime+=seconds;
   auto rotated=[&](V v){return world(rotation,local(evidenceRotation,v));};
   V prediction[3]={evidenceHand,add(evidenceElbow,rotated(sub(evidenceHand,evidenceElbow))),rotated(evidenceHand)};
   float residual[3];unsigned best=0;for(unsigned i=0;i<3;++i){residual[i]=length(sub(delta,prediction[i]))/scale;if(residual[i]<residual[best])best=i;}
   float next=1e9f;for(unsigned i=0;i<3;++i)if(i!=best)next=std::fmin(next,residual[i]);
   float motion=length(sub(delta,evidenceHand))/scale;
   pivot=0;
   if(evidenceTime>=.035f&&motion>.025f&&residual[best]<.015f&&next-residual[best]>.008f&&best!=0){
    V inferred=best==1?evidenceElbow:rotated(evidenceElbow);
    V cue=project(inferred);if(length(cue)>.025f*scale){desired=unit(add(mul(unit(cue),.7f),mul(desired,.3f)),desired);pivot=best;}
   }
  }
  if(reset)bend=desired;
  else {
   V prior=project(bend);if(length(prior)<.05f)prior=desired;prior=unit(prior);
   float speed=length(sub(hand.p,lastTarget))/(seconds*scale);
   float rate=12.f+std::fmin(18.f,speed*8.f),alpha=1-expf(-rate*seconds);
   bend=unit(add(mul(prior,1-alpha),mul(desired,alpha)),desired);
  }
  if(!evidenceReady||evidenceTime>=.075f){
   V e{},w{};if(solveTracked(shoulder,add(shoulder,V{upper,0,0}),add(shoulder,V{upper+lower,0,0}),hand.p,bend,e,w)&&valid(rotation)){
    evidenceHand=delta;evidenceElbow=sub(e,shoulder);evidenceRotation=rotation;evidenceReady=true;evidenceTime=0;
   }
  }
  lastTarget=hand.p;ready=true;return bend;
 }
};
