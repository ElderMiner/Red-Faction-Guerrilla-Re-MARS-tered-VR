#pragma once
#include <cmath>
struct RFGRVRPhysicalJump {
 float previous=0,time=0,dipTime=-10,dipHeld=0,cooldown=0,pulse=0,velocity=0;bool ready=false,armed=false;
 void reset(){*this=RFGRVRPhysicalJump{};}
 bool update(float eye,float standing,float dt,bool valid){
  if(!valid||!std::isfinite(eye)||!std::isfinite(standing)||standing<1||standing>2.4f||eye<0||eye>3||!std::isfinite(dt)||dt<0||dt>.25f){reset();return false;}
  if(!ready){previous=eye;ready=true;return false;}if(dt<=0)return pulse>0;
  time+=dt;cooldown-=dt;pulse-=dt;float speed=(eye-previous)/dt;previous=eye;
  velocity+=(speed-velocity)*(1-std::exp(-dt/.04f));
  if(standing-eye>=.12f){dipHeld+=dt;if(dipHeld>=.06f&&cooldown<=0){armed=true;dipTime=time;}}else dipHeld=0;
  if(armed&&time-dipTime>.85f)armed=false;
  if(armed&&eye>=standing+.035f&&velocity>.35f&&cooldown<=0){armed=false;pulse=.08f;cooldown=.9f;}
  return pulse>0;
 }
};
