#pragma once
#include <atomic>
extern "C" bool RFGRVR_HeadCam_MenuScene();
extern "C" bool RFGRVR_HeadCam_PopupMenu();
namespace RFGRVRMenuLayout {inline std::atomic<bool> active{false},popupActive{false};}
