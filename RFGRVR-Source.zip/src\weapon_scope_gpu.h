#pragma once
#include <vector>
#include "weapon_scope.h"
#include "apc_camera_gpu.h"
// Private, full-resolution per-eye optic images. No monitor-atlas downsampling.
// Opt-in, bounded native-feed evidence. No readback in ordinary gameplay.
inline void RFGRVR_DumpScopeFeed(ID3D11Device* device,ID3D11DeviceContext* context,ID3D11Texture2D* texture,unsigned eye){
 static DWORD checked=0;static bool enabled=false;static unsigned saved=0;DWORD now=GetTickCount();if(!checked||DWORD(now-checked)>1000){checked=now;enabled=GetFileAttributesA("RFGRVR-scope-capture.enable")!=INVALID_FILE_ATTRIBUTES;if(!enabled)saved=0;}if(!enabled||eye>1)return;
 int kind=vrscope::snapshot().kind;if(kind<0||kind>1)return;unsigned bit=1u<<(kind*2+eye);if(saved&bit)return;
 D3D11_TEXTURE2D_DESC desc{};texture->GetDesc(&desc);if(desc.SampleDesc.Count!=1||desc.Width>4096||desc.Height>4096)return;desc.BindFlags=desc.MiscFlags=0;desc.Usage=D3D11_USAGE_STAGING;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;Microsoft::WRL::ComPtr<ID3D11Texture2D> staging;if(FAILED(device->CreateTexture2D(&desc,nullptr,&staging)))return;context->CopyResource(staging.Get(),texture);D3D11_MAPPED_SUBRESOURCE data{};if(FAILED(context->Map(staging.Get(),0,D3D11_MAP_READ,0,&data)))return;
 char path[160];sprintf_s(path,"vr-research/output/native-scope-%d-%s.bmp",kind,eye?"right":"left");FILE* file=nullptr;if(!fopen_s(&file,path,"wb")&&file){BITMAPFILEHEADER header{};BITMAPINFOHEADER info{};header.bfType=0x4d42;header.bfOffBits=sizeof(header)+sizeof(info);header.bfSize=header.bfOffBits+desc.Width*desc.Height*4;info.biSize=sizeof(info);info.biWidth=desc.Width;info.biHeight=-LONG(desc.Height);info.biPlanes=1;info.biBitCount=32;fwrite(&header,sizeof(header),1,file);fwrite(&info,sizeof(info),1,file);bool rgba=desc.Format==DXGI_FORMAT_R8G8B8A8_UNORM||desc.Format==DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;std::vector<unsigned> row(desc.Width);for(unsigned y=0;y<desc.Height;++y){memcpy(row.data(),(char*)data.pData+y*data.RowPitch,desc.Width*4);if(rgba)for(auto& color:row)color=(color&0xff00ff00u)|((color&255)<<16)|((color>>16)&255);fwrite(row.data(),4,desc.Width,file);}fclose(file);saved|=bit;}context->Unmap(staging.Get(),0);
}
struct RFGRScopeFeed {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;Ptr<ID3D11Device> owner;Ptr<ID3D11Texture2D> images[2];Ptr<ID3D11ShaderResourceView> views[2];vrscope::Optics optics[2];bool opticsValid[2]{};
 bool capture(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* src,unsigned eye){if(!src||eye>1)return false;if(owner.Get()!=d){*this={};owner=d;}D3D11_TEXTURE2D_DESC a{},b{};src->GetDesc(&a);if(images[eye])images[eye]->GetDesc(&b);if(!images[eye]||a.Width!=b.Width||a.Height!=b.Height||a.Format!=b.Format){images[eye].Reset();views[eye].Reset();a.BindFlags=D3D11_BIND_SHADER_RESOURCE;a.MiscFlags=a.CPUAccessFlags=0;a.Usage=D3D11_USAGE_DEFAULT;if(FAILED(d->CreateTexture2D(&a,nullptr,&images[eye])))return false;D3D11_SHADER_RESOURCE_VIEW_DESC v{};v.Format=a.Format==DXGI_FORMAT_R8G8B8A8_TYPELESS?DXGI_FORMAT_R8G8B8A8_UNORM:a.Format==DXGI_FORMAT_B8G8R8A8_TYPELESS?DXGI_FORMAT_B8G8R8A8_UNORM:a.Format;v.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2D;v.Texture2D.MipLevels=1;if(FAILED(d->CreateShaderResourceView(images[eye].Get(),&v,&views[eye])))return false;}c->CopyResource(images[eye].Get(),src);RFGRVR_DumpScopeFeed(d,c,images[eye].Get(),eye);return true;}
};
struct RFGRWeaponScopeSurface {
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 Ptr<ID3D11Device> owner;Ptr<ID3D11DeviceContext> deferred;
 Ptr<ID3D11VertexShader> vs;Ptr<ID3D11PixelShader> ps;Ptr<ID3D11InputLayout> layout;Ptr<ID3D11Buffer> buffer;
 Ptr<ID3D11SamplerState> sampler;Ptr<ID3D11RasterizerState> raster;Ptr<ID3D11DepthStencilState> depth,reverseDepth,overlayDepth;Ptr<ID3D11BlendState> blend;
 Ptr<ID3D11Texture2D> output,atlas;Ptr<ID3D11RenderTargetView> target;Ptr<ID3D11ShaderResourceView> image;
 unsigned lastFailure=0;
 struct Vertex{float clip[4],uv[2],radius,alpha,cut,editing,lens[4],reprojection[4];};
 bool init(ID3D11Device* d){if(owner.Get()==d&&buffer)return true;*this={};owner=d;
 const char shader[]=R"(Texture2D image:register(t0);Texture2D nativeScope:register(t1);SamplerState clampLinear:register(s0);
 struct V{float4 p:POSITION;float2 uv:TEXCOORD0;float4 config:TEXCOORD1;float4 lens:TEXCOORD2;float4 reprojection:TEXCOORD3;};
 struct O{float4 p:SV_POSITION;float2 uv:TEXCOORD0;float4 config:TEXCOORD1;float4 lens:TEXCOORD2;float4 reprojection:TEXCOORD3;};
 O VS(V v){O o;o.p=v.p;o.uv=v.uv;o.config=v.config;o.lens=v.lens;o.reprojection=v.reprojection;return o;}
 float4 PS(O i):SV_Target{float2 delta=i.uv-.5;float r=length(delta);float mask=i.config.z>.5?1-smoothstep(i.config.x-.014,i.config.x,r):1;
 float2 curved=.5+delta*(1+i.lens.w*pow(r/max(i.config.x,.06),2));
 float2 sceneUv=.5+(curved-.5)*i.reprojection.x+i.reprojection.yz;
 float3 color=image.Sample(clampLinear,sceneUv).rgb;
 if(any(sceneUv<0)||any(sceneUv>1))color=0;
 float4 optic=nativeScope.Sample(clampLinear,(.5+(curved-.5)/i.reprojection.w)-i.lens.xy);
 color=(color*(1-optic.a)+optic.rgb)*i.lens.z;
 if(i.config.w>.5&&abs(r-i.config.x)<.0025)color=float3(.9,.95,1);
 return float4(color,mask*i.config.y);})";
 Ptr<ID3DBlob> v,p;if(FAILED(D3DCompile(shader,sizeof(shader),nullptr,nullptr,nullptr,"VS","vs_4_0",0,0,&v,nullptr))||FAILED(D3DCompile(shader,sizeof(shader),nullptr,nullptr,nullptr,"PS","ps_4_0",0,0,&p,nullptr)))return false;
 D3D11_INPUT_ELEMENT_DESC fields[]={{"POSITION",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,16,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",1,DXGI_FORMAT_R32G32B32A32_FLOAT,0,24,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",2,DXGI_FORMAT_R32G32B32A32_FLOAT,0,40,D3D11_INPUT_PER_VERTEX_DATA,0},{"TEXCOORD",3,DXGI_FORMAT_R32G32B32A32_FLOAT,0,56,D3D11_INPUT_PER_VERTEX_DATA,0}};
 if(FAILED(d->CreateVertexShader(v->GetBufferPointer(),v->GetBufferSize(),nullptr,&vs))||FAILED(d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,&ps))||FAILED(d->CreateInputLayout(fields,5,v->GetBufferPointer(),v->GetBufferSize(),&layout))||FAILED(d->CreateDeferredContext(0,&deferred)))return false;
 D3D11_BUFFER_DESC b{};b.ByteWidth=6*sizeof(Vertex);b.Usage=D3D11_USAGE_DYNAMIC;b.BindFlags=D3D11_BIND_VERTEX_BUFFER;b.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;
 D3D11_SAMPLER_DESC s{};s.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;s.AddressU=s.AddressV=s.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;s.MaxLOD=D3D11_FLOAT32_MAX;
 D3D11_RASTERIZER_DESC r{};r.FillMode=D3D11_FILL_SOLID;r.CullMode=D3D11_CULL_NONE;r.DepthClipEnable=TRUE;
 D3D11_DEPTH_STENCIL_DESC z{};z.DepthEnable=TRUE;z.DepthWriteMask=D3D11_DEPTH_WRITE_MASK_ZERO;z.DepthFunc=D3D11_COMPARISON_LESS_EQUAL;
 bool ok=SUCCEEDED(d->CreateDepthStencilState(&z,&depth));z.DepthFunc=D3D11_COMPARISON_GREATER_EQUAL;ok=ok&&SUCCEEDED(d->CreateDepthStencilState(&z,&reverseDepth));
 z.DepthEnable=FALSE;ok=ok&&SUCCEEDED(d->CreateDepthStencilState(&z,&overlayDepth));
 D3D11_BLEND_DESC a{};a.RenderTarget[0].BlendEnable=TRUE;a.RenderTarget[0].SrcBlend=D3D11_BLEND_SRC_ALPHA;a.RenderTarget[0].DestBlend=D3D11_BLEND_INV_SRC_ALPHA;a.RenderTarget[0].BlendOp=D3D11_BLEND_OP_ADD;a.RenderTarget[0].SrcBlendAlpha=D3D11_BLEND_ONE;a.RenderTarget[0].DestBlendAlpha=D3D11_BLEND_INV_SRC_ALPHA;a.RenderTarget[0].BlendOpAlpha=D3D11_BLEND_OP_ADD;a.RenderTarget[0].RenderTargetWriteMask=15;
 return ok&&SUCCEEDED(d->CreateBuffer(&b,nullptr,&buffer))&&SUCCEEDED(d->CreateSamplerState(&s,&sampler))&&SUCCEEDED(d->CreateRasterizerState(&r,&raster))&&SUCCEEDED(d->CreateBlendState(&a,&blend));
 }
 void beforeResize(){output.Reset();target.Reset();if(deferred){deferred->ClearState();Ptr<ID3D11CommandList> unused;deferred->FinishCommandList(FALSE,&unused);}}
 bool draw(ID3D11Device* d,ID3D11DeviceContext* c,ID3D11Texture2D* back,ID3D11DepthStencilView* worldDepth,RFGRScopeFeed& feed,const vrarm::Pose& eye,const float projection[16],const vrscope::Frame& f,D3D11_COMPARISON_FUNC compare,float minimum,float maximum,unsigned eyeIndex=0){
 using namespace vrarm;lastFailure=1;if(f.alpha<.005f)return false;lastFailure=2;if(!f.overlay&&!f.editing&&!worldDepth)return false;lastFailure=3;if(eyeIndex>1||!feed.images[eyeIndex]||!feed.views[eyeIndex])return false;lastFailure=4;if(!init(d))return false;lastFailure=5;
 if(output.Get()!=back){output=back;target.Reset();if(FAILED(d->CreateRenderTargetView(back,nullptr,&target)))return false;}
 lastFailure=6;image=feed.views[eyeIndex];
 Ptr<ID3D11ShaderResourceView> native;lastFailure=11;if(vrscope::nativeOverlay)native.Attach(vrscope::nativeOverlay(f.kind));if(!native)return false;
 Pose panel=f.panel;if(f.overlay)panel={eye.b,add(eye.p,mul(eye.b.f,.6f*f.worldScale))};
 lastFailure=7;if(dot(sub(eye.p,panel.p),panel.b.f)>=0)return false;
 auto current=vrscope::optics(f,eye);auto captured=feed.optics[eyeIndex];bool parallax=f.kind==1&&feed.opticsValid[eyeIndex]&&!f.overlay;float ratio=parallax?(std::clamp)(captured.distance/current.distance,.4f,2.5f):1.f;
 Vertex vertices[6]{};const unsigned corners[6]={0,1,2,2,1,3};float width=(f.overlay?.75f:.20f)*f.worldScale;
 for(unsigned i=0;i<6;++i){float u=float(corners[i]&1),v=float(corners[i]>>1);V p=local(eye.b,sub(add(panel.p,world(panel.b,{(u-.5f)*width,(.5f-v)*width,0})),eye.p));float value[4]={p.x,p.y,p.z,1};auto& out=vertices[i];for(unsigned row=0;row<4;++row)for(unsigned col=0;col<4;++col)out.clip[row]+=projection[col*4+row]*value[col];out.uv[0]=u;out.uv[1]=v;out.radius=f.radius;out.alpha=f.alpha;out.cut=f.cut?1.f:0.f;out.editing=f.editing?1.f:0.f;out.lens[0]=parallax?current.shift[0]:0;out.lens[1]=parallax?current.shift[1]:0;out.lens[2]=parallax?current.pupil:1;out.lens[3]=f.kind==1?.10f:0;out.reprojection[3]=f.kind==1?1.18f:1.f;out.reprojection[0]=ratio;out.reprojection[1]=parallax?captured.shift[0]-current.shift[0]*ratio:0;out.reprojection[2]=parallax?captured.shift[1]-current.shift[1]*ratio:0;}
 lastFailure=9;
 D3D11_MAPPED_SUBRESOURCE mapped{};bool ok=SUCCEEDED(deferred->Map(buffer.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&mapped));
 if(ok){memcpy(mapped.pData,vertices,sizeof(vertices));deferred->Unmap(buffer.Get(),0);auto* rt=target.Get();deferred->OMSetRenderTargets(1,&rt,f.overlay||f.editing?nullptr:worldDepth);deferred->OMSetBlendState(blend.Get(),nullptr,~0u);deferred->OMSetDepthStencilState(f.overlay||f.editing?overlayDepth.Get():compare==D3D11_COMPARISON_GREATER_EQUAL?reverseDepth.Get():depth.Get(),0);deferred->RSSetState(raster.Get());D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);D3D11_VIEWPORT vp{0,0,float(desc.Width),float(desc.Height),minimum,maximum};deferred->RSSetViewports(1,&vp);deferred->IASetInputLayout(layout.Get());deferred->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);UINT stride=sizeof(Vertex),offset=0;auto* b=buffer.Get();deferred->IASetVertexBuffers(0,1,&b,&stride,&offset);deferred->VSSetShader(vs.Get(),nullptr,0);deferred->PSSetShader(ps.Get(),nullptr,0);deferred->GSSetShader(nullptr,nullptr,0);deferred->HSSetShader(nullptr,nullptr,0);deferred->DSSetShader(nullptr,nullptr,0);ID3D11ShaderResourceView* view[2]={image.Get(),native.Get()};auto* sample=sampler.Get();deferred->PSSetShaderResources(0,2,view);deferred->PSSetSamplers(0,1,&sample);deferred->Draw(6,0);Ptr<ID3D11CommandList> commands;lastFailure=10;ok=SUCCEEDED(deferred->FinishCommandList(FALSE,&commands));if(ok)c->ExecuteCommandList(commands.Get(),TRUE);}
 if(ok)lastFailure=0;return ok;
 }
};
