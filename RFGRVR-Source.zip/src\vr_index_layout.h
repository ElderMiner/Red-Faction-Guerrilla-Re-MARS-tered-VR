#pragma once
#include <cmath>
#include <cstdint>
#include "ipc.h"
namespace vrindex {
struct Pad {float y=0,force=0;bool touched=false;};
struct Press {
 int zone=0;bool blocked=false;
 int update(Pad p,bool contextChanged){if(!p.touched||!std::isfinite(p.force)||p.force<.22f){zone=0;blocked=false;return 0;}if(contextChanged){blocked=true;zone=0;}if(blocked||!std::isfinite(p.y))return 0;if(!zone&&p.force>=.55f)zone=p.y>=0?1:-1;return zone;}
};
struct Layout {
 Press left;bool ready=false,game=false,settings=false,selectionHeld=false,rightBlocked=false;int oldLeft=0;unsigned pulse=0;uint64_t until=0,rightAt=0,switchUntil=0;bool wasRight=false,rightHoldUsed=false;
 RFGRGamepad update(RFGRGamepad p,Pad l,Pad r,bool gameplay,bool vrSettings,unsigned state,uint64_t now){bool changed=ready&&(game!=gameplay||settings!=vrSettings);ready=true;game=gameplay;settings=vrSettings;
 int a=left.update(l,changed);if(changed){oldLeft=0;pulse=0;until=0;wasRight=false;rightHoldUsed=false;switchUntil=0;if(r.touched)rightBlocked=true;}if(!r.touched)rightBlocked=false;selectionHeld=false;
 if(gameplay){
  unsigned face=p.buttons&0x6000;p.buttons&=~0x6000u;if(face&0x4000)p.buttons|=0x2000;if(face&0x2000)p.buttons|=0x4000;
  bool vehicle=state>=7&&state<=10;unsigned clicks=p.buttons&0xc0;p.buttons&=~0xc0u;
  if(clicks&0x40)p.buttons|=vehicle?0x40:0x100;if(clicks&0x80)p.buttons|=vehicle?0x80:0x40;
  if(p.buttons&0x200){p.buttons&=~0x200u;p.buttons|=0x400;} // Left B: C4-only command.
  selectionHeld=r.touched&&!rightBlocked;
  if(selectionHeld&&!wasRight){rightAt=now;rightHoldUsed=false;}
  if(selectionHeld&&now-rightAt>=500)rightHoldUsed=true;
  if(!selectionHeld&&wasRight&&!rightHoldUsed)switchUntil=now+100;
  wasRight=selectionHeld;if(now<switchUntil)p.buttons|=0x200;
  if(a&&a!=oldLeft){pulse=a>0?0x10:0x20;until=now+100;}if(now<until){p.buttons|=pulse;selectionHeld=false;wasRight=false;switchUntil=0;p.buttons&=~0x200u;}
  // Right grip owns stick height changes in vehicles; it must not accept missions.
  if(!selectionHeld&&p.rightY<-22000&&!(vehicle&&rightHeightGrip)){p.buttons|=8;p.rightY=0;}
 }else if(vrSettings){if(a)p.buttons|=a>0?0x100:0x200;
 }else {if(a)p.buttons|=a>0?1:2;}
 oldLeft=a;return p;
 }
 bool rightHeightGrip=false;
};
}
