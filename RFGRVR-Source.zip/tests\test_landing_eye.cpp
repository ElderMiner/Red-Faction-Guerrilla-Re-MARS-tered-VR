#include "../src/vr_landing_eye.h"
#include <cassert>
int main(){RFGRVRLandingEye e;assert(!e.update(false,true,0,.01f));assert(e.update(true,true,0,.01f));for(int i=0;i<250;++i)assert(e.update(false,true,.2f,.01f));for(int i=0;i<19;++i)assert(e.update(false,true,0,.01f));for(int i=0;i<4;++i)e.update(false,true,0,.01f);assert(!e.active);assert(e.update(true,true,0,.01f));assert(!e.update(false,false,0,.01f));assert(!e.active);}
