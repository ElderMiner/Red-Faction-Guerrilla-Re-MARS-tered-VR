#pragma once
// Included inside RFGRVRWeaponPhysics, after Reload's verified capacity call.
namespace AmmoAudio {
// Native frame order: ammo commit7EBDEE/7EBE98 precedes sound update7EC09C.
// rounds is the remaining count AFTER this shot.
inline float warning(int capacity,int rounds){if(capacity<=0||capacity>10000||rounds<0||rounds>capacity)return 0;if(capacity<=10)return rounds==0?.10f:0;int low=(capacity+4)/5;if(rounds>=low)return 0;return .08f+.17f*float(low-1-rounds)/float((std::max)(1,low-1));}
using Fire=void(__thiscall*)(void*);using Cue=int(__cdecl*)(int,void*,int*);using Params=void(__thiscall*)(void*);
using SetPitch=int(__cdecl*)(int,float);inline SetPitch setPitch=nullptr;
struct Record{void* weapon=nullptr;unsigned handle=~0u;int sound=-1;float basePitch=0,applied=0;};inline Record record;inline SRWLOCK recordLock=SRWLOCK_INIT;
inline Fire fire=nullptr,loop=nullptr;inline Cue cue=nullptr;inline Params params=nullptr;inline thread_local void* firing=nullptr;
inline float amount(void* weapon){Target t{};if(!requested()||!snapshot(t)||weapon!=t.weapon||!owned(t,t.player)||!Reload::capacity)return 0;return warning(Reload::capacity(weapon),int(word(weapon,0x20c)));}
inline int __cdecl onCue(int id,void* native,int* error){Target t{};bool local=firing&&snapshot(t)&&firing==t.weapon&&owned(t,t.player)&&requested();float shift=local?amount(firing):0;void* info=(void*)(uintptr_t)word(firing,0x148);bool match=local&&(int(word(info,0x84))==id||int(word(info,0x88))==id||int(word(info,0x8c))==id);if(!match||!params||(native&&!memory(native,0x134)))return cue(id,native,error);
 alignas(16) unsigned char copy[0x134]{};if(native)memcpy(copy,native,sizeof(copy));else params(copy);float pitch=0;memcpy(&pitch,copy+0x14,4);if(!std::isfinite(pitch))return cue(id,native,error);float modified=(std::max)(-1.f,(std::min)(1.f,pitch+shift));memcpy(copy+0x14,&modified,4);int sound=cue(id,copy,error);if(sound>=0){AcquireSRWLockExclusive(&recordLock);record={firing,t.handle,sound,pitch,modified};ReleaseSRWLockExclusive(&recordLock);}return sound;
}
// Continuous firing audio starts before the warning band. Update only the
// exact owned loop handle created above, through the library's locked setter.
inline void update(const Target& t){if(!setPitch||!owned(t,t.player))return;Record r;AcquireSRWLockShared(&recordLock);r=record;ReleaseSRWLockShared(&recordLock);if(r.weapon!=t.weapon||r.handle!=t.handle||r.sound<0||int(word(t.weapon,0x260))!=r.sound)return;float desired=(std::max)(-1.f,(std::min)(1.f,r.basePitch+amount(t.weapon)));if(fabsf(desired-r.applied)<.0001f)return;if(setPitch(r.sound,desired)!=0)return;AcquireSRWLockExclusive(&recordLock);if(record.weapon==r.weapon&&record.sound==r.sound)record.applied=desired;ReleaseSRWLockExclusive(&recordLock);}
struct Scope{void* previous;Scope(void* weapon):previous(firing){firing=weapon;}~Scope(){firing=previous;}};
inline void __fastcall onFire(void* weapon,void*){Scope scope(weapon);fire(weapon);}
inline void __fastcall onLoop(void* weapon,void*){Scope scope(weapon);loop(weapon);}
inline bool install(){const unsigned char fireSig[]={0x83,0xec,0x30,0x56,0x8b,0xf1};const unsigned char cueSig[]={0x81,0xec,0x68,0x01,0,0};const unsigned char paramSig[]={0x0f,0x57,0xc0,0x33,0xc0};if(memcmp(base+0x7e65a0,fireSig,6)||memcmp(base+0x7e2b50,fireSig,6)||memcmp(base+0x9f120,cueSig,6)||memcmp(base+0x8cde0,paramSig,5))return false;
 if(base[0x91a80]==0xb9&&word(base,0x91a81)==(unsigned)(uintptr_t)(base+0x169d0e4)&&base[0x91a85]==0xe8)setPitch=(SetPitch)(base+0x91a80);
 struct Hook{unsigned rva;void* detour;void** original;};Hook hooks[]={{0x7e65a0,(void*)onFire,(void**)&fire},{0x7e2b50,(void*)onLoop,(void**)&loop},{0x9f120,(void*)onCue,(void**)&cue}};unsigned created=0;for(auto& h:hooks){if(MH_CreateHook(base+h.rva,h.detour,h.original)!=MH_OK){for(unsigned i=0;i<created;++i)MH_RemoveHook(base+hooks[i].rva);return false;}++created;}params=(Params)(base+0x8cde0);for(auto& h:hooks)if(MH_EnableHook(base+h.rva)!=MH_OK){for(auto& undo:hooks){MH_DisableHook(base+undo.rva);MH_RemoveHook(base+undo.rva);}return false;}return true;
}
}
