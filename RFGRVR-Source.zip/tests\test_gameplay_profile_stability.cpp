#define NOMINMAX
#include "../src/render_window_profile.h"
#include "../src/vr_gameplay_signal.h"
#include <cassert>
using namespace RFGRVRRenderWindow;
static RFGRVRGameplaySignal signal;static bool recent=true;static uint64_t now=10000;static unsigned rebuilds=0;
static bool playing(){return signal.update(recent,now);}static bool resize(unsigned,unsigned){++rebuilds;return true;}
int main(){wchar_t path[MAX_PATH]{};assert(profilePath(path,L"RFGRVR-render-size.txt"));assert(GetFileAttributesW(path)==INVALID_FILE_ATTRIBUTES);
 FILE* f=nullptr;assert(!_wfopen_s(&f,path,L"w"));fputs("3328 3472 3840 2160\n",f);fclose(f);
 WNDCLASSW cls{};cls.lpfnWndProc=DefWindowProcW;cls.lpszClassName=L"RFGRGameplayStabilityTest";cls.hInstance=GetModuleHandleW(nullptr);assert(RegisterClassW(&cls));
 auto hwnd=CreateWindowW(cls.lpszClassName,L"",WS_OVERLAPPEDWINDOW,0,0,1280,720,nullptr,nullptr,cls.hInstance,nullptr);assert(hwnd);
 gameplayActive=playing;resizeBuffers=resize;attach(hwnd);SendMessageW(hwnd,requestMessage,requestMagic,0);assert(rebuilds==1&&width==3328);
 recent=false;now=10600;nextPoll=0;poll();assert(width==3328&&!resizePending&&rebuilds==1);
 recent=true;now=10800;nextPoll=0;poll();assert(width==3328&&!resizePending&&rebuilds==1);
 recent=false;now=12400;nextPoll=0;poll();SendMessageW(hwnd,requestMessage,requestMagic,0);assert(width==3840&&height==2160&&rebuilds==2);
 DestroyWindow(hwnd);DeleteFileW(path);
}
