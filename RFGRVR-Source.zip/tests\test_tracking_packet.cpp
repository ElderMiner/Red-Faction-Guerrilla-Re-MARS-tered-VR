#define main RFGRVR_BridgeEntryForTest
#include "../src/bridge.cpp"
#undef main
#include <cassert>
#include <thread>
#include <atomic>
int main(){
 RFGRShared packet{};shm=&packet;std::atomic<bool> done{false},started{false};std::atomic<unsigned> accepted{0};
 std::thread reader([&]{started=true;while(!done.load()){
  LONG pose=packet.poseSequence,stereo=packet.stereoSequence;if((pose|stereo)&1)continue;
  MemoryBarrier();float h=packet.hmd.position[0],l=packet.left.position[0],r=packet.right.position[0],aim=packet.rightAim.position[0],eye=packet.eyes[1].pose.position[0];int64_t time=packet.predictedDisplayTime;
  MemoryBarrier();if(pose!=packet.poseSequence||stereo!=packet.stereoSequence||!pose)continue;
  assert(h==l&&l==r&&r==aim&&aim==eye&&eye==float(time));++accepted;
 }});
 while(!started.load())SwitchToThread();
 for(unsigned sample=1;sample<=50000;++sample){RFGRPose p{};p.position[0]=float(sample);XrView eyes[2]{};for(auto& eye:eyes)eye.pose.position.x=float(sample);writePoses(p,p,p,p,p,eyes,true,sample);if(sample%100==0)SwitchToThread();}
 done=true;reader.join();assert(accepted>0&&packet.poseSamples==50000&&packet.stereoSamples==50000);shm=nullptr;
}
