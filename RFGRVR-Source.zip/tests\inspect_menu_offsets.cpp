#pragma warning(disable:4716)
#define main retained_main
#include "test_camera_input.cpp"
#undef main
int main(){
#define FIELD(x) printf("%s %zu\n",#x,offsetof(decltype(g),x));
FIELD(nativeSourceProjection) FIELD(nativeGameScale) FIELD(nativeGameHead) FIELD(nativeGameFloorEye) FIELD(origin) FIELD(calibration) FIELD(worldBasis) FIELD(previousParentState) FIELD(lastEffective) FIELD(tracking) printf("stateOffset %zu poseOffset %zu stereoOffset %zu\n",offsetof(RFGRShared,openxrState),offsetof(RFGRShared,hmd),offsetof(RFGRShared,stereoValid));FIELD(enabled) FIELD(nativeEnabled) FIELD(nativeContinuous) FIELD(nativeActive) FIELD(nativeFrame) FIELD(nativeSwap) FIELD(ipc) FIELD(nativeProjectionCalls)
}


