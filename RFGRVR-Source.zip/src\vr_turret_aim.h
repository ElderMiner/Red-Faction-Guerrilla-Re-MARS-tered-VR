#pragma once
#include <algorithm>
#include "vr_gamepad_math.h"
// Automatic mount reference. Tracking stays in physical room space;
// only the explicit coarse heading carries the native turret/body around.
struct RFGRVRTurretHandle {
 unsigned identity=~0u;bool ready=false,observed=false;float origin[3]{},aimYaw=0,aimPitch=0,baseYaw=0,basePitch=0,coarseOrigin=0,lever=.55f,previous[2]{},last[2]{},response[2]{1,1};int votes[2]{},confidence[2]{};unsigned long long tick=0;
 void reset(){*this={};}
 bool update(unsigned id,const float hand[3],const float aim[3],float coarse,float yaw,float pitch,unsigned long long now,short* x,short* y,float measuredLever=.55f){
  *x=*y=0;if(id!=identity){reset();identity=id;}float n=0;for(unsigned i=0;i<3;++i){if(!std::isfinite(hand[i])||!std::isfinite(aim[i]))return false;n+=aim[i]*aim[i];}if(n<.8f||n>1.2f||!std::isfinite(coarse)||!std::isfinite(yaw)||!std::isfinite(pitch))return false;
  float currentAimYaw=atan2f(aim[0],aim[2]),currentAimPitch=asinf((std::max)(-1.f,(std::min)(1.f,aim[1]/sqrtf(n))));
  if(!ready){for(unsigned i=0;i<3;++i)origin[i]=hand[i];aimYaw=currentAimYaw;aimPitch=currentAimPitch;baseYaw=yaw;basePitch=pitch;coarseOrigin=coarse;lever=std::isfinite(measuredLever)?(std::max)(.15f,(std::min)(1.5f,measuredLever)):.55f;ready=true;}
  float current[2]={yaw,pitch};if(observed&&now!=tick&&now-tick<100)for(unsigned a=0;a<2;++a){float change=a?current[a]-previous[a]:std::remainder(current[a]-previous[a],6.28318530718f);if(confidence[a]<3&&fabsf(last[a])>.28f&&fabsf(change)>.0005f&&fabsf(change)<.15f){int sign=change*last[a]>0?1:-1;if(votes[a]!=sign){votes[a]=sign;confidence[a]=1;}else ++confidence[a];if(confidence[a]>=3)response[a]=float(sign);}}
  if(now!=tick){for(unsigned a=0;a<2;++a)previous[a]=current[a];tick=now;observed=true;}
  // The hand holds the rear of a lever. Move the rear upward and the
  // barrel points down. Controller wrist orientation does not aim the barrel.
  float dx=hand[0]-origin[0],dy=hand[1]-origin[1],dz=hand[2]-origin[2];
  float side=dx*cosf(aimYaw)-dz*sinf(aimYaw),forward=dx*sinf(aimYaw)+dz*cosf(aimYaw);
  float rear=(std::max)(.05f,lever-forward),flat=sqrtf(side*side+rear*rear);
  float errors[2]={std::remainder(baseYaw+std::remainder(coarse-coarseOrigin,6.28318530718f)+atan2f(-side,rear)-yaw,6.28318530718f),basePitch-atan2f(dy,flat)-pitch};short* output[2]={x,y};for(unsigned a=0;a<2;++a){float e=errors[a];last[a]=fabsf(e)<.006f?0.f:(e<0?-1.f:1.f)*response[a]*(.32f+(std::min)(.60f,fabsf(e)*1.3f));*output[a]=RFGRVR_Axis(last[a]);}return true;
 }
};

// Stick turning moves the mounted VR rig around the swivel, rather than just
// spinning the view at the native seat. Evaluate once and share between eyes.
struct RFGRVRTurretOrbit {
 unsigned identity=~0u;bool ready=false;float offset[3]{},entry=0,facing=0;
 float facingYaw(float heading)const{return facing+std::remainder(heading-entry,6.28318530718f);}
 void reset(){*this={};}
 bool update(unsigned id,const float pivot[3],float heading,float head[3]){
  if(!std::isfinite(heading))return false;
  for(unsigned i=0;i<3;++i)if(!std::isfinite(pivot[i])||!std::isfinite(head[i]))return false;
  if(!ready||id!=identity){identity=id;ready=true;entry=heading;for(unsigned i=0;i<3;++i)offset[i]=head[i]-pivot[i];facing=atan2f(-offset[0],-offset[2]);}
  float angle=std::remainder(heading-entry,6.28318530718f),c=cosf(angle),s=sinf(angle);
  head[0]=pivot[0]+c*offset[0]+s*offset[2];head[1]=pivot[1]+offset[1];head[2]=pivot[2]-s*offset[0]+c*offset[2];return true;
 }
};
