#pragma once
#include "vr_arm_math.h"
#include "ipc.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <vector>
#include <atomic>
namespace vrheadmotion {
using namespace vrarm;
inline M basis(const RFGRPose& p){float x=p.orientation[0],y=p.orientation[1],z=p.orientation[2],w=p.orientation[3];return {{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};}
inline Pose pose(const RFGRPose& p){return {basis(p),{p.position[0],p.position[1],p.position[2]}};}
struct Fit {V offset{0,-.1f,.08f};float error=0;bool valid=false;float referenceEyeY=.1f;};
inline Fit fit(const std::vector<Pose>& samples){Fit result;if(samples.size()<20)return result;const auto& first=samples.front();double a[3][4]{};
 for(const auto& p:samples){V axes[3]={sub(p.b.r,first.b.r),sub(p.b.u,first.b.u),sub(p.b.f,first.b.f)},delta=sub(first.p,p.p);for(int row=0;row<3;++row)for(int col=0;col<3;++col)a[row][col]+=dot(axes[row],axes[col]);for(int row=0;row<3;++row)a[row][3]+=dot(axes[row],delta);}
 for(int col=0;col<3;++col){int pivot=col;for(int row=col+1;row<3;++row)if(fabs(a[row][col])>fabs(a[pivot][col]))pivot=row;if(fabs(a[pivot][col])<.002)return result;for(int k=0;k<4;++k)std::swap(a[pivot][k],a[col][k]);double d=a[col][col];for(int k=col;k<4;++k)a[col][k]/=d;for(int row=0;row<3;++row)if(row!=col){double f=a[row][col];for(int k=col;k<4;++k)a[row][k]-=f*a[col][k];}}
 V offset{float(a[0][3]),float(a[1][3]),float(a[2][3])};if(!finite(offset)||fabsf(offset.x)>.06f||offset.y<-.3f||offset.y>.04f||offset.z<-.12f||offset.z>.25f||length(offset)>.32f)return result;
 V center{};for(auto p:samples)center=add(center,add(p.p,world(p.b,offset)));center=mul(center,1.f/samples.size());float error=0;for(auto p:samples){V d=sub(add(p.p,world(p.b,offset)),center);error+=dot(d,d);}error=sqrtf(error/samples.size());if(error>.025f)return result;result={offset,error,true,world(first.b,mul(offset,-1)).y};return result;
}
inline void profilePath(char (&path)[MAX_PATH]){
#ifdef RFGR_TEST_USER_SETTINGS
 char suffix[120];sprintf_s(suffix,"build-check/head-motion-%lu.ini",GetCurrentProcessId());GetFullPathNameA(suffix,MAX_PATH,path,nullptr);return;
#endif
GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* project=strstr(path,"\\vr-research\\project\\"))*project=0;else if(auto* slash=strrchr(path,'\\'))*slash=0;strcat_s(path,"\\RFGRVR-head-motion.ini");}
inline bool save(const Fit& fit){if(!fit.valid)return false;char path[MAX_PATH],temporary[MAX_PATH];profilePath(path);sprintf_s(temporary,"%s.tmp",path);FILE* file=nullptr;if(fopen_s(&file,temporary,"w")||!file)return false;fprintf(file,"[HeadRotation]\nOffset0=%.8f\nOffset1=%.8f\nOffset2=%.8f\nError=%.8f\nReferenceEyeY=%.8f\n",fit.offset.x,fit.offset.y,fit.offset.z,fit.error,fit.referenceEyeY);bool ok=!ferror(file);if(fclose(file))ok=false;return ok&&MoveFileExA(temporary,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH);}
struct PivotState {V eye{0,.1f,-.08f};float referenceY=.1f;bool valid=false;};
inline SRWLOCK pivotLock=SRWLOCK_INIT;inline PivotState pivotState;inline std::atomic<DWORD> pivotChecked{0};
inline PivotState cachedPivot(){DWORD now=GetTickCount(),previous=pivotChecked.load(std::memory_order_relaxed);if((!previous||DWORD(now-previous)>1000)&&pivotChecked.compare_exchange_strong(previous,now)){char path[MAX_PATH],text[64];profilePath(path);V offset{};bool good=true;for(int i=0;i<3;++i){char key[16];sprintf_s(key,"Offset%d",i);GetPrivateProfileStringA("HeadRotation",key,"",text,sizeof(text),path);good=good&&sscanf_s(text,"%f",(&offset.x)+i)==1;}if(good&&finite(offset)&&fabsf(offset.x)<=.06f&&offset.y>=-.3f&&offset.y<=.04f&&offset.z>=-.12f&&offset.z<=.25f&&length(offset)<=.32f){PivotState updated;updated.eye=mul(offset,-1);updated.referenceY=updated.eye.y;GetPrivateProfileStringA("HeadRotation","ReferenceEyeY","",text,sizeof(text),path);float reference=updated.referenceY;if(sscanf_s(text,"%f",&reference)==1&&std::isfinite(reference)&&fabsf(reference)<.35f)updated.referenceY=reference;updated.valid=true;AcquireSRWLockExclusive(&pivotLock);pivotState=updated;ReleaseSRWLockExclusive(&pivotLock);}}AcquireSRWLockShared(&pivotLock);PivotState result=pivotState;ReleaseSRWLockShared(&pivotLock);return result;}
inline V eyeFromPivot(){return cachedPivot().eye;}
inline float uprightHeight(const RFGRPose& head){auto pivot=cachedPivot();return pivot.valid?head.position[1]-world(basis(head),pivot.eye).y+pivot.referenceY:head.position[1];}
struct Guide {
 bool active=false,done=false,saved=false,persist=true;unsigned phase=0;unsigned long long phaseBegan=0,lastSample=0,reachedAt=0;float yaw=0,pitch=0,dotYaw=0,dotPitch=0;Pose reference{};M flat{};std::vector<Pose> samples;Fit fitted;
 void reset(){*this={};}
 void begin(const RFGRPose& head){reset();reference=pose(head);float angle=atan2f(reference.b.f.x,reference.b.f.z);flat=turnAround(M{{1,0,0},{0,1,0},{0,0,1}},{0,1,0},angle);active=true;samples.reserve(512);samples.push_back(reference);}
 const wchar_t* title()const{static const wchar_t* names[]={L"Look LEFT to move the dot",L"Look RIGHT to move the dot",L"Look UP to move the dot",L"Look DOWN to move the dot"};return names[(std::min)(phase,3u)];}
 float target()const{return phase==0?.65f:phase==1?-.65f:phase==2?.45f:-.45f;}
 void animate(unsigned long long now){if(!phaseBegan)phaseBegan=now;dotYaw=phase<2?(std::clamp)(yaw,-.65f,.65f):0;dotPitch=phase>=2?(std::clamp)(pitch,-.45f,.45f):0;}
 V targetPoint()const{return add(reference.p,world(flat,{-1.5f*tanf(dotYaw),1.5f*tanf(dotPitch),-1.5f}));}
 void update(const RFGRPose& head,unsigned long long now){if(!active||(head.validFlags&3)!=3)return;Pose current=pose(head);if(!finite(current.p)||!valid(current.b))return;M local=relative(flat,current.b);yaw=atan2f(local.f.x,local.f.z);pitch=asinf((std::clamp)(-local.f.y,-1.f,1.f));animate(now);
  if(samples.size()<512&&now-lastSample>=25&&(samples.empty()||length(sub(current.b.f,samples.back().b.f))>.008f)){samples.push_back(current);lastSample=now;}
  float angle=phase<2?yaw:pitch;bool reached=phase==0?angle>=.58f:phase==1?angle<=-.58f:phase==2?angle>=.38f:angle<=-.38f;
  if(!reached)reachedAt=0;else if(!reachedAt)reachedAt=now;else if(now-reachedAt>=180){reachedAt=0;if(++phase==4){fitted=fit(samples);saved=persist&&save(fitted);active=false;done=true;}else phaseBegan=now;}

 }
};
}
