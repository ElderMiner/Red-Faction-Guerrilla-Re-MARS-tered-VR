#pragma once
#include <cmath>
#include "vr_arm_math.h"
inline float RFGRVR_HeightScale(float gameEyeHeight,float calibratedEyeHeight){
 if(!std::isfinite(gameEyeHeight)||!std::isfinite(calibratedEyeHeight)||gameEyeHeight<1||gameEyeHeight>2.4f||calibratedEyeHeight<1||calibratedEyeHeight>2.4f)return 1;
 return gameEyeHeight/calibratedEyeHeight;
}
// For floor-calibrated upright locomotion, camera anchor is standing eye
// height above the character root. This offset maps STAGE y=0 to that root,
// independent of the height at startup or while pressing recenter.
inline float RFGRVR_FloorEyeOffset(float stageEyeY,float standingGameEyeHeight,float scale,float calibratedReference=0){
 return calibratedReference>=1&&calibratedReference<=2.4f?(stageEyeY-calibratedReference)*scale:stageEyeY*scale-standingGameEyeHeight;
}

// Appearance scale changes tracked translations and stereo separation together.
inline float RFGRVR_AdjustedWorldScale(float base,int appearancePercent){if(!std::isfinite(base)||base<=0)return 1;int percent=appearancePercent<60?60:appearancePercent>160?160:appearancePercent;return base*100.f/percent;}

// Optical world sizing is independent of the calibrated player rig. Only the
// local avatar and its held visuals receive this per-eye render translation;
// neither simulation transforms nor shared NPC palettes are edited.
namespace vrworldview {
inline thread_local vrarm::V prepared{},draw{};
inline void shiftPalette(vrarm::Pose* palette,unsigned count,const vrarm::Pose& root){
 if(!palette||count>128||!vrarm::valid(root.b))return;
 auto offset=vrarm::local(root.b,draw);for(unsigned i=0;i<count;++i)palette[i].p=vrarm::add(palette[i].p,offset);
}
}
