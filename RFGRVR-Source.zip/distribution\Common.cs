using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using Microsoft.Win32;
namespace RFGRVR {
 public class FileRecord { public string path; public string sha256; public bool seedOnly; }
 public class ReleaseConfig { public string version; public string repository; public string asset="RFGRVR-Setup.zip"; }
 public class PackageManifest { public string version; public string gameSha256; public FileRecord[] files; }
 public class InstallState { public string version; public string backup; public List<FileRecord> installed=new List<FileRecord>(); public List<string> existed=new List<string>(); public Dictionary<string,string> steamOriginal=new Dictionary<string,string>(); }
 public static class Core {
  public static JavaScriptSerializer Json=new JavaScriptSerializer { MaxJsonLength=4*1024*1024 };
  public static string Hash(string p){using(var s=File.OpenRead(p))using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(s)).Replace("-","");}
  public static string Inside(string root,string relative){if(String.IsNullOrEmpty(relative)||Path.IsPathRooted(relative)||relative.Contains(":"))throw new IOException("Invalid package path");string prefix=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;string target=Path.GetFullPath(Path.Combine(prefix,relative));if(!target.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))throw new IOException("Package path escapes install folder");return target;}
  public static void AtomicText(string file,string value){Directory.CreateDirectory(Path.GetDirectoryName(file));string temp=file+".new";File.WriteAllText(temp,value,new UTF8Encoding(false));if(File.Exists(file))File.Replace(temp,file,null);else File.Move(temp,file);}
  public static string SteamRoot(){using(var key=Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam"))return key==null?null:key.GetValue("SteamPath") as string;}
  public static IEnumerable<string> FindGames(){string steam=SteamRoot();if(String.IsNullOrEmpty(steam))yield break;var roots=new List<string>{steam};string libraries=Path.Combine(steam,@"steamapps\libraryfolders.vdf");if(File.Exists(libraries)){Vdf v=Vdf.Parse(File.ReadAllText(libraries));var folder=v.Child("libraryfolders");if(folder!=null)foreach(var node in folder.Children){var path=node.Child("path");if(path!=null&&path.Value!=null)roots.Add(path.Value);}}foreach(string root in roots.Distinct(StringComparer.OrdinalIgnoreCase)){string path=Path.Combine(root,@"steamapps\common\Red Faction Guerrilla Re-MARS-tered");if(File.Exists(Path.Combine(path,"rfg.exe")))yield return path;}}
  public static bool Running(string name,string root){foreach(var p in Process.GetProcessesByName(name)){try{if(p.MainModule.FileName.StartsWith(Path.GetFullPath(root)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))return true;}catch{ return true; }finally{p.Dispose();}}return false;}
  public static void AssertLinkFree(string root,string target){string current=Path.GetFullPath(target);string bound=Path.GetFullPath(root).TrimEnd('\\');while(current.Length>=bound.Length){if((File.Exists(current)||Directory.Exists(current))&&(File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new IOException("Install paths must not contain symbolic links: "+current);if(current.Equals(bound,StringComparison.OrdinalIgnoreCase))break;current=Path.GetDirectoryName(current);if(current==null)break;}}
 }
 public class Vdf {
  public string Name,Value;public List<Vdf> Children=new List<Vdf>();
  public Vdf Child(string n){return Children.FirstOrDefault(x=>String.Equals(x.Name,n,StringComparison.OrdinalIgnoreCase));}
  public Vdf Ensure(string n){var c=Child(n);if(c==null){c=new Vdf{Name=n};Children.Add(c);}return c;}
  public static Vdf Parse(string text){int at=0;var root=new Vdf();Read(root,text,ref at,false);return root;}
  static string Token(string s,ref int i){while(i<s.Length){if(Char.IsWhiteSpace(s[i])){i++;continue;}if(i+1<s.Length&&s[i]=='/'&&s[i+1]=='/'){while(i<s.Length&&s[i]!='\n')i++;continue;}break;}if(i>=s.Length)return null;if(s[i]=='{'||s[i]=='}')return s[i++].ToString();var b=new StringBuilder();if(s[i]=='"'){i++;while(i<s.Length){char c=s[i++];if(c=='"')return b.ToString();if(c=='\\'&&i<s.Length&&(s[i]=='\\'||s[i]=='"'))c=s[i++];b.Append(c);}throw new IOException("Incomplete Steam configuration");}while(i<s.Length&&!Char.IsWhiteSpace(s[i])&&s[i]!='{'&&s[i]!='}')b.Append(s[i++]);return b.ToString();}
  static void Read(Vdf n,string s,ref int i,bool nested){for(;;){string key=Token(s,ref i);if(key==null){if(nested)throw new IOException("Incomplete Steam configuration");return;}if(key=="}"){if(!nested)throw new IOException("Unexpected Steam configuration delimiter");return;}string value=Token(s,ref i);if(value==null)throw new IOException("Missing Steam configuration value");var c=new Vdf{Name=key};n.Children.Add(c);if(value=="{")Read(c,s,ref i,true);else c.Value=value;}}
  static string Q(string s){return "\""+s.Replace("\\","\\\\").Replace("\"","\\\"")+"\"";}
  public string Serialize(){var b=new StringBuilder();foreach(var c in Children)c.Write(b,0);return b.ToString();}
  void Write(StringBuilder b,int depth){b.Append(new string('\t',depth)).Append(Q(Name));if(Value!=null){b.Append("\t\t").Append(Q(Value)).Append("\r\n");return;}b.Append("\r\n").Append(new string('\t',depth)).Append("{\r\n");foreach(var c in Children)c.Write(b,depth+1);b.Append(new string('\t',depth)).Append("}\r\n");}
 }
}
