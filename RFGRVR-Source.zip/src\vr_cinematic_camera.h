#pragma once
#include <cstdint>
#include <cstring>
inline bool RFGRVR_CinematicEligible(unsigned cameraMode,unsigned gameState){return cameraMode==4&&gameState==1;}

inline bool RFGRVR_MainMenuEligible(unsigned cameraMode,unsigned gameState,unsigned rootState=~0u){bool frontend=gameState==0||(gameState>=7&&gameState<=13)||(rootState==0&&gameState>=7&&gameState<0x38&&gameState!=0x2c&&gameState!=0x2f&&gameState!=0x31);return (cameraMode==0||cameraMode==10)&&frontend;}

// UI overlays over a loaded game use one world-space presentation path.
// Front-end navigation, loading and video playback retain their own paths.
inline bool RFGRVR_PopupMenuEligible(unsigned state,unsigned rootState=1){
 return rootState==1&&(((state>=7&&state<=0x2e)&&state!=0x2c)||(state>=0x32&&state<=0x37)||state==0x3e);
}



// Tutorial/notification pauses can leave the game-state stack at GAMEPLAY.
// Only the native pause counter plus an ordinary loaded-game camera qualifies.
inline bool RFGRVR_BlockingNotificationEligible(unsigned cameraMode,unsigned gameState,unsigned rootState,unsigned pauseDepth){return rootState==1&&gameState==1&&pauseDepth>0&&pauseDepth<=64&&(cameraMode==0||cameraMode==10);}

inline uintptr_t RFGRVR_PauseCounterAddress(const unsigned char* code,uintptr_t base){if(!code||code[0]!=0xa1||memcmp(code+5,"\x85\xc0\x0f\x9f\xc0\xc3",6))return 0;uint32_t address=0;memcpy(&address,code+1,4);return uintptr_t(address)==base+0x2133880?address:0;}
