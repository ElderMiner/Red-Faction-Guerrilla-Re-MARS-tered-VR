#include "../src/wrist_map_geometry.h"
#include <cassert>
int main(){using namespace vrwrist;assert(updateDue(10,0,true));assert(!updateDue(32,10,true));assert(updateDue(43,10,true));assert(updateDue(11,10,false));assert(updateDue(30,0xfffffffa,true));Vertex q[6]{};for(int i=0;i<4;++i){q[i].x=(i&1)?817.f:307.f;q[i].y=(i&2)?1986.f:1476.f;q[i].u=float(i);q[i].color=0xff234567;mark(q[i],7);q[i].x=q[i].x*2.f/3840-1;q[i].y=1-q[i].y*2.f/2160;}
 std::vector<Vertex> tris;triangles(q,0,2,7,tris);assert(tris.size()==6);auto a=project(tris[0],{307,1476,817,1986},3840,2160);assert(fabsf(a.x+1)<.0001f&&fabsf(a.y-1)<.0001f&&a.z==0&&a.color==0xff234567);auto b=project(tris[5],{307,1476,817,1986},3840,2160);assert(fabsf(b.x-1)<.0001f&&fabsf(b.y+1)<.0001f);triangles(q,0,4,7,tris);assert(tris.size()==6);triangles(q,0,2,8,tris);assert(tris.empty());assert(vertexCount(0,2)==4&&vertexCount(3,2)==6&&vertexCount(100,2)==0);
}
