#pragma once
#include <windows.h>
#include <cstdint>
#include <atomic>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include "vr_grip_placement.h"
// All transforms here are rigid, weapon-local poses. Uniform mesh scale never
// enters the camera basis or the controller/hand orientation matrices.
struct ID3D11ShaderResourceView;
namespace vrscope {
inline ID3D11ShaderResourceView* (*nativeOverlay)(int)=nullptr;
inline std::atomic<int> nativeVisualKind{-1};
using namespace vrarm;
inline constexpr M identity{{1,0,0},{0,1,0},{0,0,1}};
struct Settings {float scale=1,radius=.42f;V offset{0,.09f,-.12f};bool cut=false,overlay=false;};
inline int index(const char* name){return name&&!strcmp(name,"sniper_rifle")?0:name&&!strcmp(name,"rail_driver")?1:-1;}
inline const char* names[2]={"sniper_rifle","rail_driver"};
inline float zoom(int i){return i==0?4.f:2.5f;}
inline float halfAngle(int i){return atanf(1.f/zoom(i));}
inline SRWLOCK lock=SRWLOCK_INIT;inline Settings profiles[2];inline char path[MAX_PATH]{};inline bool loaded=false;
inline void load(){if(loaded)return;loaded=true;if(!path[0]){GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* s=strrchr(path,92))strcpy_s(s+1,MAX_PATH-(s+1-path),"RFGRVR-weapon-scopes.ini");}
 for(int i=0;i<2;++i){char value[256];GetPrivateProfileStringA(names[i],"Settings","",value,sizeof(value),path);Settings s;int cut=0;
 if(sscanf_s(value,"%f %f %f %f %f %d",&s.scale,&s.radius,&s.offset.x,&s.offset.y,&s.offset.z,&cut)==6&&std::isfinite(s.scale+s.radius)&&finite(s.offset)&&length(s.offset)<3){s.scale=(std::clamp)(s.scale,.5f,3.f);s.radius=(std::clamp)(s.radius,.06f,.49f);s.cut=cut!=0;s.overlay=GetPrivateProfileIntA(names[i],"Overlay",0,path)!=0;profiles[i]=s;}}
}
inline bool save(int i){if(i<0||i>1)return false;auto s=profiles[i];char value[256];sprintf_s(value,"%.6f %.6f %.6f %.6f %.6f %d",s.scale,s.radius,s.offset.x,s.offset.y,s.offset.z,s.cut?1:0);bool saved=WritePrivateProfileStringA(names[i],"Settings",value,path)!=0;return WritePrivateProfileStringA(names[i],"Overlay",s.overlay?"1":"0",path)!=0&&saved;}
inline Settings settings(int i){AcquireSRWLockExclusive(&lock);load();auto s=i>=0&&i<2?profiles[i]:Settings{};ReleaseSRWLockExclusive(&lock);return s;}
inline float weaponScale(const char* name){int i=index(name);return i<0?1:settings(i).scale;}
struct Frame {Pose panel{},camera{};float radius=.42f,alpha=0,worldScale=1;bool cut=false,editing=false,overlay=false;int kind=-1;uint64_t tick=0;};
struct Optics {Pose camera{};float angles[4]{},shift[2]{},distance=.3f,pupil=1;unsigned pixels=1024;};
inline Optics optics(const Frame& f,const Pose& eye,float pixelsPerRadian=1000){
 // Preserve the working Rail Driver optics. The sniper returns to its stable
 // symmetric native zoom, without distance-driven resizing or pupil distortion.
 if(f.kind==0){Optics o;o.camera=f.camera;float a=halfAngle(f.kind);o.angles[0]=-a;o.angles[1]=a;o.angles[2]=a;o.angles[3]=-a;o.distance=.3f;o.pupil=1;o.pixels=1536;return o;}
 Optics o;o.camera=f.camera;float scale=std::isfinite(f.worldScale)&&f.worldScale>0?f.worldScale:1;V p=mul(local(f.panel.b,sub(eye.p,f.panel.p)),1/scale);float d=(std::clamp)(-p.z,.04f,2.f);o.distance=d;float w=.20f,z=zoom(f.kind);o.shift[0]=(std::clamp)(p.x/w,-.45f,.45f);o.shift[1]=(std::clamp)(-p.y/w,-.45f,.45f);
 float x=o.shift[0]*w,y=-o.shift[1]*w;o.angles[0]=atanf((-.5f*w-x)/(d*z));o.angles[1]=atanf((.5f*w-x)/(d*z));o.angles[2]=atanf((.5f*w-y)/(d*z));o.angles[3]=atanf((-.5f*w-y)/(d*z));o.camera.p=add(f.camera.p,world(f.panel.b,{x*scale/z,y*scale/z,0}));
 float aperture=(std::max)(.008f,w*f.radius),off=sqrtf(p.x*p.x+p.y*p.y)/aperture,t=(std::clamp)((off-.45f)/.75f,0.f,1.f);o.pupil=f.editing?1.f:p.z>=-.025f?0.f:1-t*t*(3-2*t);
 float needed=2*atanf(w/(2*d))*(std::max)(100.f,pixelsPerRadian)*1.6f;o.pixels=(std::clamp)(unsigned(ceilf(needed/128))*128,768u,2048u);return o;
}
inline Frame frame;inline bool editing=false,primaryEditing=false;inline int editKind=-1;inline float fade=0;inline uint64_t fadeTick=0;
inline Frame snapshot(){AcquireSRWLockShared(&lock);auto f=frame;ReleaseSRWLockShared(&lock);if(GetTickCount64()-f.tick>250)f.alpha=0;return f;}
inline bool visible(){return snapshot().alpha>.005f;}
inline void publish(const char* name,Pose weapon,Pose muzzle,float worldScale,bool focus,bool allowed){
 int i=index(name);auto now=GetTickCount64();AcquireSRWLockExclusive(&lock);load();
 if(i!=editKind){editing=false;primaryEditing=false;editKind=i;fade=0;}
 float dt=fadeTick?(std::min)(.1f,float(now-fadeTick)/1000):0;fadeTick=now;
 float target=allowed&&i>=0&&(editing||(profiles[i].cut||profiles[i].overlay)&&focus)?1.f:0.f;
 fade+=((std::clamp)(target-fade,-dt*7.f,dt*7.f));
 Frame f;f.kind=i;f.tick=now;f.alpha=fade;f.worldScale=worldScale;
 if(i>=0){auto s=profiles[i];f.radius=s.radius;f.cut=s.cut;f.editing=editing;f.overlay=s.overlay;
  f.panel={muzzle.b,add(weapon.p,world(muzzle.b,mul(s.offset,worldScale)))};
  f.camera=muzzle;f.camera.p=add(muzzle.p,mul(muzzle.b.f,.06f*worldScale));}
 frame=f;ReleaseSRWLockExclusive(&lock);
}
// Kept separate from the game key router so repeat, mode and persistence can
// be exercised without synthesizing keyboard input into the running game.
inline bool edit(int kind,int key){if(kind<0||kind>1)return false;AcquireSRWLockExclusive(&lock);load();auto& s=profiles[kind];bool changed=true;
 if(key==VK_HOME)s.overlay=!s.overlay;
 else if(key==VK_MULTIPLY)s.scale=(std::min)(3.f,s.scale+.025f);
 else if(key==VK_SUBTRACT)s.scale=(std::max)(.5f,s.scale-.025f);
 else if(key==VK_DIVIDE){editing=!editing;editKind=kind;primaryEditing=false;changed=false;}
 else if(key==VK_OEM_5&&editing)s.cut=true;
 else if(key==VK_INSERT&&editing)s.radius=(std::min)(.49f,s.radius+.01f);
 else if(key==VK_DELETE&&editing)s.radius=(std::max)(.06f,s.radius-.01f);
 else if(editing){V d{};if(key==VK_NUMPAD8)d.y=.005f;else if(key==VK_NUMPAD5)d.y=-.005f;else if(key==VK_NUMPAD4)d.x=-.005f;else if(key==VK_NUMPAD6)d.x=.005f;else if(key==VK_NUMPAD7)d.z=.005f;else if(key==VK_NUMPAD9)d.z=-.005f;else changed=false;
  V p=add(s.offset,d);if(length(p)<3)s.offset=p;}
 else changed=false;
 bool saved=!changed||save(kind);ReleaseSRWLockExclusive(&lock);return saved;
}
inline V scalePoint(V p,float scale){return mul(p,scale);}
inline Pose scaledWrist(Pose wrist,V palmInWrist,float scale){V offset=world(wrist.b,palmInWrist);wrist.p=sub(mul(add(wrist.p,offset),scale),offset);return wrist;}
}
