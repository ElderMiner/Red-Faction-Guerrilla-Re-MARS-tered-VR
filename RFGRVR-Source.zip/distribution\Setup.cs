using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;
using System.Diagnostics;
namespace RFGRVR {
 public static class Installer {
  public static string StatePath(string root){return Path.Combine(root,@"RFGRVR\install-state.json");}
  public static InstallState ReadState(string root){string p=StatePath(root);return File.Exists(p)?Core.Json.Deserialize<InstallState>(File.ReadAllText(p)):null;}
  static void CheckClosed(string root){if(Core.Running("rfg",root)||Core.Running("RFGRVR_OpenXR",root))throw new IOException("Close the game and VR companion before installing or updating.");}
  static List<string> SteamConfigs(){string steam=Core.SteamRoot();string users=steam==null?null:Path.Combine(steam,"userdata");if(users==null||!Directory.Exists(users))return new List<string>();return Directory.GetDirectories(users).Select(x=>Path.Combine(x,@"config\localconfig.vdf")).Where(File.Exists).ToList();}
  static Vdf App(Vdf tree){return tree.Ensure("UserLocalConfigStore").Ensure("Software").Ensure("Valve").Ensure("Steam").Ensure("apps").Ensure("667720");}
  static string LaunchOption(string root){return "\""+Path.Combine(root,@"RFGRVR\Launcher.exe")+"\" %command%";}
  public static InstallState Install(string root,Stream payload,bool steamChoice,bool saveSelf){
   root=Path.GetFullPath(root);CheckClosed(root);Core.AssertLinkFree(root,root);if(steamChoice&&ReadState(root)==null&&Process.GetProcessesByName("steam").Length>0)throw new IOException("Exit Steam using Steam > Exit, then click Install again. This lets the wizard safely add the VR / Standard launch choice.");
   var previous=ReadState(root);var state=new InstallState();string work=Core.Inside(root,@"RFGRVR\staging-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(work);string backup=Core.Inside(root,@"RFGRVR\backups\"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,8));Directory.CreateDirectory(backup);state.backup=backup;if(previous!=null){string prior=Core.Inside(backup,@"RFGRVR\install-state.json");Directory.CreateDirectory(Path.GetDirectoryName(prior));File.Copy(StatePath(root),prior);}
   var modified=new List<string>();var steamRollback=new Dictionary<string,string>();
   try {
    using(var zip=new ZipArchive(payload,ZipArchiveMode.Read,true)){
     var manifestEntry=zip.GetEntry("manifest.json");if(manifestEntry==null||manifestEntry.Length>1024*1024)throw new IOException("Package manifest missing or invalid");PackageManifest manifest;using(var r=new StreamReader(manifestEntry.Open()))manifest=Core.Json.Deserialize<PackageManifest>(r.ReadToEnd());
     if(manifest.files==null||manifest.files.Length>100)throw new IOException("Invalid package manifest");if(!File.Exists(Path.Combine(root,"rfg.exe"))||!String.Equals(Core.Hash(Path.Combine(root,"rfg.exe")),manifest.gameSha256,StringComparison.OrdinalIgnoreCase))throw new IOException("Select a supported Red Faction Guerrilla Re-MARS-tered install. This game executable differs from the version this mod was built against.");
     state.version=manifest.version;var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);long total=0;
     foreach(var f in manifest.files){if(!seen.Add(f.path))throw new IOException("Duplicate package file");string path=Core.Inside(work,f.path),destination=Core.Inside(root,f.path);Core.AssertLinkFree(root,destination);string normalized=f.path.Replace('\\','/');var entry=zip.GetEntry(normalized)??zip.GetEntry(normalized.Replace('/','\\'));if(entry==null||entry.Length>64*1024*1024||(total+=entry.Length)>256*1024*1024)throw new IOException("Invalid or oversized package file");Directory.CreateDirectory(Path.GetDirectoryName(path));using(var source=entry.Open())using(var target=File.Create(path))source.CopyTo(target);if(!String.Equals(Core.Hash(path),f.sha256,StringComparison.OrdinalIgnoreCase))throw new IOException("Package checksum failed: "+f.path);}
     if(saveSelf){string path=Core.Inside(work,@"RFGRVR\Setup.exe");Directory.CreateDirectory(Path.GetDirectoryName(path));File.Copy(Assembly.GetExecutingAssembly().Location,path);manifest.files=manifest.files.Concat(new[]{new FileRecord{path=@"RFGRVR\Setup.exe",sha256=Core.Hash(path)}}).ToArray();}
     foreach(var f in manifest.files){string target=Core.Inside(root,f.path);if(f.seedOnly){if(!File.Exists(target)){Directory.CreateDirectory(Path.GetDirectoryName(target));modified.Add(f.path);File.Copy(Core.Inside(work,f.path),target);}continue;}if(File.Exists(target)){string old=Core.Inside(backup,f.path);Directory.CreateDirectory(Path.GetDirectoryName(old));File.Copy(target,old);state.existed.Add(f.path);}Directory.CreateDirectory(Path.GetDirectoryName(target));modified.Add(f.path);File.Copy(Core.Inside(work,f.path),target,true);state.installed.Add(f);}
     // Calibrated release defaults seed missing files only. Existing player
     // settings are preserved on updates, repair and uninstall.
     string render=Path.Combine(root,"RFGRVR-render-size.txt");if(!File.Exists(render)){File.WriteAllText(render,"3328 3472 3840 2160\r\n");modified.Add("RFGRVR-render-size.txt");}
     if(previous!=null)state.steamOriginal=previous.steamOriginal;
     if(steamChoice&&(previous==null||previous.steamOriginal.Count==0)){if(Process.GetProcessesByName("steam").Length>0)throw new IOException("Exit Steam before configuring its launch choice.");var configs=SteamConfigs();if(configs.Count==0)throw new IOException("No Steam account configuration found. Sign in to Steam once, exit it, and try again, or uncheck Steam integration.");foreach(string file in configs){string original=File.ReadAllText(file);steamRollback[file]=original;var vdf=Vdf.Parse(original);var app=App(vdf);var option=app.Child("LaunchOptions");if(!state.steamOriginal.ContainsKey(file))state.steamOriginal[file]=option==null?null:option.Value;string oldOptions=option==null?null:option.Value;if(!String.IsNullOrEmpty(oldOptions)&&oldOptions.Contains("%command%")&&!oldOptions.StartsWith("\""+Path.Combine(root,@"RFGRVR\Launcher.exe")+"\"",StringComparison.OrdinalIgnoreCase))throw new IOException("This game already uses a Steam launch wrapper. Uncheck Steam integration to preserve it, or remove that wrapper before installing.");app.Ensure("LaunchOptions").Value=LaunchOption(root)+(String.IsNullOrWhiteSpace(oldOptions)||oldOptions.Contains("%command%")?"":" "+oldOptions);Core.AtomicText(file,vdf.Serialize());}}
     Directory.CreateDirectory(Path.Combine(root,@"vr-research\output"));Core.AtomicText(StatePath(root),Core.Json.Serialize(state));
    }
    return state;
   }catch{
    foreach(var pair in steamRollback)Core.AtomicText(pair.Key,pair.Value);
    foreach(string relative in Enumerable.Reverse(modified)){string target=Core.Inside(root,relative),old=Core.Inside(backup,relative);if(File.Exists(old))File.Copy(old,target,true);else if(File.Exists(target))File.Delete(target);}throw;
   }finally{if(Directory.Exists(work))Directory.Delete(work,true);}
  }
  public static void Uninstall(string root){root=Path.GetFullPath(root);CheckClosed(root);var state=ReadState(root);if(state==null)throw new IOException("No installed mod record was found.");if(state.steamOriginal.Count>0&&Process.GetProcessesByName("steam").Length>0)throw new IOException("Exit Steam first so its launch options can be restored safely.");
   foreach(var pair in state.steamOriginal){if(!File.Exists(pair.Key))continue;var tree=Vdf.Parse(File.ReadAllText(pair.Key));var app=App(tree);var option=app.Child("LaunchOptions");if(option!=null&&option.Value.StartsWith(LaunchOption(root),StringComparison.Ordinal)){if(pair.Value==null)app.Children.Remove(option);else option.Value=pair.Value;Core.AtomicText(pair.Key,tree.Serialize());}}
   // Restore the pre-mod files from the first install, walking updates backward.
   var current=state;var visited=new HashSet<string>(StringComparer.OrdinalIgnoreCase);while(current!=null&&visited.Add(current.backup)){
    foreach(var f in current.installed){string target=Core.Inside(root,f.path);Core.AssertLinkFree(root,target);string old=Core.Inside(current.backup,f.path);if(File.Exists(old)){Directory.CreateDirectory(Path.GetDirectoryName(target));File.Copy(old,target,true);}else if(File.Exists(target)&&String.Equals(Core.Hash(target),f.sha256,StringComparison.OrdinalIgnoreCase))File.Delete(target);}
    string prior=Core.Inside(current.backup,@"RFGRVR\install-state.json");current=File.Exists(prior)?Core.Json.Deserialize<InstallState>(File.ReadAllText(prior)):null;
   }File.Delete(StatePath(root));
  }
 }
 public class SetupForm:Form {
  bool automatic;TextBox folder=new TextBox();Label status=new Label();CheckBox integrate=new CheckBox();Button install=new Button(),remove=new Button();string target;
  public SetupForm(string initial,bool autoUpdate=false){automatic=autoUpdate;Text="Red Faction Guerrilla VR Setup";ClientSize=new Size(640,370);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;StartPosition=FormStartPosition.CenterScreen;Font=new Font("Segoe UI",10);
   Controls.Add(new Label{Text="Install or update Red Faction Guerrilla VR",Font=new Font("Segoe UI",17,FontStyle.Bold),Location=new Point(25,22),Size=new Size(590,42)});
   Controls.Add(new Label{Text="Choose the Re-MARS-tered game folder. Updates keep your settings,\ncalibration and weapon / vehicle placements.",Location=new Point(25,78),Size=new Size(590,52)});
   folder.SetBounds(25,143,490,28);folder.Text=initial??Core.FindGames().FirstOrDefault()??"";Controls.Add(folder);var browse=new Button{Text="Browse…",Location=new Point(525,141),Size=new Size(90,30)};browse.Click+=(s,e)=>{using(var d=new FolderBrowserDialog()){d.Description="Choose the folder containing rfg.exe";d.SelectedPath=folder.Text;if(d.ShowDialog()==DialogResult.OK)folder.Text=d.SelectedPath;}};Controls.Add(browse);
   integrate.Text="Show VR / Standard choice when launching from Steam";integrate.Checked=!autoUpdate;integrate.SetBounds(25,190,580,30);Controls.Add(integrate);
   status.Text="Close the game, VR companion and Steam before installing.\nBackups and uninstall information are kept in the game folder.";status.SetBounds(25,235,590,55);Controls.Add(status);
   install.Text="Install / Update";install.SetBounds(390,315,145,35);install.Click+=(s,e)=>Run(false);Controls.Add(install);remove.Text="Uninstall";remove.SetBounds(25,315,110,35);remove.Click+=(s,e)=>Run(true);Controls.Add(remove);var cancel=new Button{Text="Close",Location=new Point(545,315),Size=new Size(70,35)};cancel.Click+=(s,e)=>Close();Controls.Add(cancel);if(autoUpdate)Shown+=(s,e)=>Run(false);
  }
  void Run(bool uninstall){try{target=Path.GetFullPath(folder.Text);if(uninstall){if(MessageBox.Show("Remove the mod files and restore the previous launch settings? Your personal placement files will be kept.",Text,MessageBoxButtons.YesNo)!=DialogResult.Yes)return;Installer.Uninstall(target);status.Text="Uninstalled. Your personal settings and placements were retained.";return;}
    // Back up the previous transaction record as part of the next transaction.
    using(var payload=Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip")){if(payload==null)throw new IOException("Installer payload missing");if(automatic){if(Installer.ReadState(target)==null)throw new IOException("No previous installation was found; use the normal install wizard.");var until=DateTime.UtcNow.AddSeconds(10);while(Core.Running("Launcher",target)&&DateTime.UtcNow<until)System.Threading.Thread.Sleep(100);}
Installer.Install(target,payload,integrate.Checked,true);}status.Text="Installed successfully. Start Steam and press Play.\nChoose VR, then calibrate when prompted.";if(automatic){Process.Start(new ProcessStartInfo(Path.Combine(target,@"RFGRVR\Launcher.exe")){UseShellExecute=true});Close();}else MessageBox.Show(status.Text,Text,MessageBoxButtons.OK,MessageBoxIcon.Information);
   }catch(Exception ex){MessageBox.Show(ex.Message,Text,MessageBoxButtons.OK,MessageBoxIcon.Error);}}
  [STAThread] public static int Main(string[] args){try{string self=Assembly.GetExecutingAssembly().Location;string parent=Path.GetDirectoryName(self);if(String.Equals(Path.GetFileName(parent),"RFGRVR",StringComparison.OrdinalIgnoreCase)&&File.Exists(Path.Combine(Path.GetDirectoryName(parent),"rfg.exe"))){string relocated=Path.Combine(Path.GetTempPath(),"RFGRVR-Setup-"+Guid.NewGuid().ToString("N")+".exe");File.Copy(self,relocated);Process.Start(new ProcessStartInfo(relocated,"--target \""+Path.GetDirectoryName(parent)+"\""){UseShellExecute=true});return 0;}if(args.Length==2&&args[0]=="--self-test")return Tests.Run(args[1]);Application.EnableVisualStyles();string initial=args.Length==2&&(args[0]=="--target"||args[0]=="--update")?args[1]:null;Application.Run(new SetupForm(initial,args.Length==2&&args[0]=="--update"));return 0;}catch(Exception ex){MessageBox.Show(ex.ToString(),"VR Setup");return 1;}}
 }
}
