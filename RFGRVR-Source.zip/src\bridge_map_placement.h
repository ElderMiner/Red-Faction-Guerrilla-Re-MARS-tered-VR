#pragma once
#include "weapon_hud_pose.h"
#include "vr_weapon_selector.h"
struct RFGRMapPlacement {
 RFGRHudAnchor offsets[2]{};RFGRPose fixed{},grab{};bool editing=false,grabbing=false,keyHeld=false,gripHeld=false;int mode=0;float squeeze=0;char path[MAX_PATH]{};
 RFGRMapPlacement(){for(auto& a:offsets){a.hand=0;a.local.b={{1,0,0},{0,1,0},{0,0,1}};}GetModuleFileNameA(nullptr,path,MAX_PATH);if(auto* s=strrchr(path,92))strcpy_s(s+1,MAX_PATH-(s+1-path),"RFGRVR-map-placement.ini");for(int i=0;i<2;++i){char value[300];GetPrivateProfileStringA(i?"Vehicle":"Wrist","Pose","",value,sizeof(value),path);float f[12];if(sscanf_s(value,"%f %f %f %f %f %f %f %f %f %f %f %f",f,f+1,f+2,f+3,f+4,f+5,f+6,f+7,f+8,f+9,f+10,f+11)==12){memcpy(&offsets[i].local,f,sizeof(f));if(!vrarm::valid(offsets[i].local.b)||!vrarm::finite(offsets[i].local.p))offsets[i].local={{{1,0,0},{0,1,0},{0,0,1}},{}};}}}
 static vrarm::Pose pose(const RFGRPose& p){return {RFGRVRWeaponSelector::basis(p),{p.position[0],p.position[1],p.position[2]}};}
 static RFGRHudAnchor relative(const RFGRPose& parent,const RFGRPose& child){using namespace vrarm;auto a=pose(parent),b=pose(child);RFGRHudAnchor out;out.hand=0;out.local={vrarm::relative(a.b,b.b),local(a.b,sub(b.p,a.p))};return out;}
 void save(){char value[300];const float* f=(const float*)&offsets[mode].local;sprintf_s(value,"%.7g %.7g %.7g %.7g %.7g %.7g %.7g %.7g %.7g %.7g %.7g %.7g",f[0],f[1],f[2],f[3],f[4],f[5],f[6],f[7],f[8],f[9],f[10],f[11]);WritePrivateProfileStringA(mode?"Vehicle":"Wrist","Pose",value,path);}
 bool update(bool key,bool allowed,bool vehicle,float grip,const RFGRPose& right,const RFGRPose& base,RFGRPose& out){
  if(key&&!keyHeld&&allowed){editing=!editing;grabbing=false;if(editing){mode=vehicle?1:0;RFGRVR_HudPose(base,offsets[mode],fixed);}printf("Map placement %s\n",editing?"active: right grip moves map; release saves":"finished");}keyHeld=key;
  if(!allowed){editing=grabbing=false;return RFGRVR_HudPose(base,offsets[vehicle?1:0],out);}
  bool held=grip>.65f;
  if(editing){using namespace vrarm;if(held&&!gripHeld&&(right.validFlags&3)==3&&right.active&&length(sub(pose(right).p,pose(fixed).p))<.4f){auto a=relative(right,fixed);grab=right;memcpy(grab.position,&a.local.p,12); // actual offset retained below
    grabOffset=a;grabbing=true;}
   if(grabbing&&held)RFGRVR_HudPose(right,grabOffset,fixed);
   if(grabbing&&!held){offsets[mode]=relative(base,fixed);save();grabbing=false;printf("Map position and orientation saved\n");}
   out=fixed;
  }else RFGRVR_HudPose(base,offsets[vehicle?1:0],out);gripHeld=held;return true;
 }
 RFGRHudAnchor grabOffset{};
};

