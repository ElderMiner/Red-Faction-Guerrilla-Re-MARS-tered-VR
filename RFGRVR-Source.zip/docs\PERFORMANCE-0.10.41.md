# VR performance and presentation review � 0.10.41

Candidate built and tested. In-game performance improvement and headset appearance are not yet verified.

## Evidence
- Reviewed the active body/head, menu capture/presentation, stereo scheduling, graphics diagnostic hooks, effect cache and memory-validation paths, alongside the prior full architecture audit. `source-inventory141.json` inventories 181 source files with hashes and hot-operation sites; this is not a claim that every state or line was runtime-tested.
- Current installed run: presentation hook about 0.31�0.35 ms; outer render about 10�12 ms in the sampled intervals. Eye timings varied around 4.6�7.0 ms left and 3.4�3.7 ms right. Logs are asynchronous rolling samples, not a matched GPU A/B or an unmodified-game baseline.
- Native scene size is 3328 � 3472 per eye: 23.1 million pixels across both eyes before scopes/APC feeds. Desktop mirroring reuses one eye; it is not a third full game view.
- Captured native frame: 6,082 draws, 13,129 constant-buffer binding calls, 13,120 resource writes and 11,306 shader binding calls. 4,934/5,653 VS and 4,932/5,653 PS binding records repeat the preceding shader in their stage. These are observed sequences, not proof that all intervening context changes were absent.
- Open-Map pre-installation baseline over three seconds: 53,582 validation queries and 135,286 cache hits. This must be compared at the same scene/frame rate after installation; no FPS conclusion follows from query counts alone.

## Included corrections
- Popup menus preserve the logical native width/height through a small independent layout channel. Their 1024-square capture texture no longer causes the final panel to be unconditionally stretched into 16:9. Main menu/video layout remains unchanged. Terrain/icons continue using the confirmed Map capture and ordinary scheduled stereo-world rendering.
- A native firing/action timer no longer drops VR ownership of a validated equipped firearm. It must still match the equipped handle and player owner. Ragdoll, unrelated interactions, NPCs and vehicle eligibility remain excluded. Native finger poses are retained; the stable torso/head solver remains the pose owner. This closes an identified handoff/rebinding path; live reproduction must confirm whether additional animation writers remain.
- Validation cache: operation-local 32-entry bound retained; new regions now replace entries round-robin instead of remaining uncached forever after capacity. A recent-region fast path avoids repeatedly scanning the table. Nothing persists beyond the synchronous scope. Tests cover nested scopes, capacity/churn, read-only/no-access protection changes in a later scope and invalid reads. Ten thousand hot reads after filling the cache require one query for the new region.
- Graphics diagnostic idle checks now use acquire loads instead of locked compare-exchange operations. Constant-buffer diagnostic loops and render-target event loops return early when inactive; actual native API calls, auxiliary remapping and diagnostic observation are retained.
- Full frame GPU survey is opt-in via `RFGRVR-gpu-survey.enable`, rather than allocating a large event/payload buffer and exporting automatically every launch. Sparse asynchronous GPU timing remains enabled and never waits for queries.
- Effect caches use mixed pointer hashing to avoid clusters from similarly aligned allocations. Already-seen effect-view entries return before repeated validation; native stamps/handles are still changed only once per view and handles stay intact.

## Rejected engine experiment
A VR-transaction-scoped shader-binding cache was built and tested against a real D3D11 device, including ClearState, ExecuteCommandList with both restore modes, context state swaps and scope shutdown. Correctness checks passed. The fairer final timing comparison showed 200,000 repeated calls at 1.422 ms without the cache versus 2.771 ms with it: its lock/bookkeeping outweighed the driver work. It is removed from production and packaging. Experimental source/test and raw logs are retained only in the research output. Repeated calls in a trace do not by themselves justify a cache.

## Engine-level conclusions
The largest remaining work is native scene rendering, including geometry submissions, lighting, particles and pixel shading at stereo resolution. The first eye already costs more than the second, consistent with some native work being reused; blindly skipping the second eye's passes or copying its depth/visibility would risk the stereo/impact/shadow problems previously fixed. Scope and APC extra views remain visibility-gated and use their existing adaptive target sizes.

A large additional gain would need a verified renderer change such as stereo instancing/multiview, or reconstruction/upscaling at fewer shaded pixels. Those require shader, culling, motion/depth and per-eye validation, not a safe drop-in toggle in this 32-bit D3D11 game. No such gain is claimed here. Foveation remains scrapped after the prior crashes. The patch does not lower effects/shadows, change NPC collision/LOD, alter simulation, or change saved render scale to manufacture improvement.

A truly unmodified flat-screen baseline at matched settings/scene has not been run. Remaining comparisons: same scene without/with incoming fire; same occupied vehicle; APC feeds and scope off/on; frame percentiles and query rates per frame after this patch. Presentation/body corrections need headset testing.

## Validation
Both release builds and 22 native regression executables pass, plus managed installer/updater and desktop settings checks. The active checks cover native Map scheduling, both-eye menus, action-timer/support-grip ownership, NPC rejection, jump/crouch transitions, cache churn/protection, effect stamps, GPU diagnostics, scopes, APC feeds, reloads and saved-setting preservation. Tests establish code behavior, not a measured live FPS gain.
