#pragma once
#include "vr_arm_math.h"
struct RFGRVRFloorScreen {
 unsigned presentation=~0u;bool anchored=false;vrarm::Pose pose{};
 void show(unsigned id){if(presentation!=id){presentation=id;reset();}}
 void reset(){anchored=false;}
 void set(vrarm::V head,vrarm::M basis){if(anchored)return;float yaw=atan2f(basis.f.x,basis.f.z);pose={vrarm::turnAround({{1,0,0},{0,1,0},{0,0,1}},{0,1,0},yaw),{head.x,1.45f,head.z}};anchored=true;}
 vrarm::Pose at(float distance)const{auto p=pose;p.p=vrarm::add(p.p,vrarm::world(p.b,{0,0,-distance}));return p;}
};
