#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <dbghelp.h>
#include <cstdio>
#include <cstdlib>
int wmain(int argc,wchar_t** argv){
 if(argc!=3)return 2;DWORD pid=wcstoul(argv[1],nullptr,10);bool self=pid==0;if(self)pid=GetCurrentProcessId();
 HANDLE process=self?GetCurrentProcess():OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ|PROCESS_DUP_HANDLE,FALSE,pid);
 if(!process){wprintf(L"OpenProcess failed %lu\n",GetLastError());return 3;}
 HANDLE file=CreateFileW(argv[2],GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
 if(file==INVALID_HANDLE_VALUE){if(!self)CloseHandle(process);return 4;}
 MINIDUMP_TYPE flags=(MINIDUMP_TYPE)(MiniDumpNormal|MiniDumpWithThreadInfo|MiniDumpWithFullMemoryInfo);
 BOOL ok=MiniDumpWriteDump(process,pid,file,flags,nullptr,nullptr,nullptr);DWORD error=GetLastError();CloseHandle(file);if(!self)CloseHandle(process);
 wprintf(L"dump pid=%lu success=%d error=%lu\n",pid,ok,ok?0:error);return ok?0:5;
}


