#pragma once
#include <algorithm>
#include "vr_arm_math.h"
inline vrarm::Pose RFGRVR_FreeFinger(vrarm::Pose pose,vrarm::V axis,float curl,bool thumb,bool tip,bool right=false){using namespace vrarm;if(!std::isfinite(curl))curl=0;curl=(std::max)(0.f,(std::min)(1.f,curl));pose.b=turnAround(pose.b,axis,curl*(right?-1.f:1.f)*(thumb?-1.f:1.f)*(thumb?.9f:tip?1.1f:1.4f));return pose;}

inline vrarm::Pose RFGRVR_OpenFingerLocal(vrarm::V inverseParent,vrarm::V inverseBone){return {vrarm::M{{1,0,0},{0,1,0},{0,0,1}},vrarm::sub(inverseParent,inverseBone)};}

inline float RFGRVR_FingerCurl(float value,unsigned finger){if(!std::isfinite(value))return 0;float rest=finger==4?.20f:0.f;return (std::max)(0.f,(std::min)(1.f,(value-rest)/(1-rest)));}
