# Lighting replacement: verified engine boundaries

This is an experimental engineering map for the supported executable. RVAs
are relative to its loaded image, not portable addresses. Verify signatures
before installing hooks. Native disassembly/captures remain private and are
not included in source or installer archives.

## Rendering sequence

1. Native scene/camera preparation builds visibility and directional shadows.
2. Three directional cascades render into a reused 2048 x 2048, R16-typeless
   depth resource. Each completed cascade is projected into the native
   camera-space lighting/shadow buffer before the next cascade overwrites it.
3. Material passes consume normal, diffuse, legacy specular and shadow inputs.
   Local-light passes and base passes have different resource interfaces.
4. Effects/transparency and the native HDR chain follow. Adaptation, bloom
   and tone mapping must remain distinct from radiance and scattering.
5. VR menus/HUD render separately. They must never receive scene fog, exposure
   or a second colour-space conversion.

The sequence above is established from the native call graph and GPU capture.
The precise final volumetric insertion point is still under investigation.

## Directional shadows: verified

| Boundary | RVA / layout | Meaning |
|---|---|---|
| Cascade loop | 0x145e92 through 0x146041 | Three successive cascade draws |
| Cascade preparation | 0x1187b0 | Fits a projection using camera and light |
| Cascade draw/project | 0x12e8d0 | thiscall, thirteen stack arguments, ret 52 |
| Shadow depth scene draw | 0x117d60 | Produces depth before projection |
| Cascade distance parameters | 0x0d0750 | Native cascade range/fade data |
| Shadow projection | 0x0e23a0 | Consumes depth, projects into lighting buffer |
| SceneRenderer +0x374 / +0x378 | width / height | Native shadow dimensions |
| SceneRenderer +0x37c / +0x384 | dynamic texture / render target | Reused shadow source |

The captured arguments to 0x12e8d0 identify argument 4 as the column-major
world-to-clip matrix and argument 5 as world-to-texture. Argument 13 is cascade
index 0, 1, 2; argument 9 carries masks 2, 4, 8. In all three recorded cascades,
texture X = 0.5 * clip X + 0.5 * W, texture Y = -0.5 * clip Y + 0.5 * W.
The texture Z translation contains the native approximately -0.00006 bias.
Preserve this rather than guessing another bias or transposing twice.

`modern_shadow_maps.h` converts the matrix layout and records ordered copies
into three private texture-array layers. It must be called on the context
that recorded the native draw, after its DSV is unbound and before the next
clear. An immediate-context copy issued while a deferred command list is
still being recorded would capture the wrong contents. The cache rejects
bound sources, unsupported layouts, stale frames and incomplete sets.

The volumetric shader selects the first cascade containing a world sample.
These are alternative projections of one directional light, not three lights.
Outside verified coverage, scattering is shadowed rather than leaking through
unrepresented buildings. Local point/spot shadows need their own verified
maps; directional cascades cannot substitute for them.

## Light and HDR interfaces

Native light types at +0xc8: directional 0, point 1, spot 2. Colour +0xcc,
position +0x2c, spot direction +0x20, directional vector +0x104, attenuation
start/end +0xdc/+0xe0, outer/inner spot angles +0xe4/+0xe8. The angles are
radians, confirmed by the native cosine calculation. RVA 0x0c2510 is a separate thiscall geometry-parameter writer (two stack
arguments, return 8). It writes position relative to an input origin at output
+0, spot direction at +0x10, attenuation coefficients at +0x20 and cone data at
+0x30. This is statically verified; collection from that route is not wired
yet. Existing engine upload captures establish the directional route only. Do not fabricate lamp positions from visible sprites.

HDR parameter upload is RVA 0x1259e0. Its verified callers include 0x13b9ba,
0x13c7bf and 0x14acaa. The native HDR colour format observed is
R11G11B10_FLOAT. Parameter upload is not proof that a bound render target is
the final HDR scene; resolve its caller and source ownership before insertion.

`Renderer +0x440` participates in native context access; the 0x0e23a0 path
dereferences its wrappers before issuing OMSetRenderTargets. This call graph
is useful evidence, not permission to cast an arbitrary pointer to COM.
Actual context/device identity and command-stream ordering must be checked.

## Replacement and outstanding work

Implemented offline: material/terrain GGX shader families; bounded light
descriptors; depth-limited Beer-Lambert/Henyey-Greenstein scattering; three
directional shadow projections; private ordered shadow snapshots; reduced
resolution integration and depth-aware HDR composite.

Not finished: engine connection of shadow cache and scattering, complete
local-light collection, shadowed headlight/lamppost transport, coordinated
sky/ambient/reflection radiance and exposure. The last installed material
candidate was reported visually poor. Passing isolated GPU tests does not
change that assessment. No completed modern lighting overhaul is claimed.

Keep the published stable release and approved settings untouched. Do not
install another partial visual experiment just to obtain a screenshot.

## Connected source boundary: 0.11.4

`modern_runtime.h` connects the cascade hook to the pre-bloom hook at
0x13d4c0. SceneRenderer +0x220 is the main RenderTarget pointer, whose first
slot is its colour RTV; +0x2a8 is the main depth TextureData pointer, whose
SRV is +24. These agree with the native structure/call path and captured
layout. Runtime checks require matching single-sample depth/HDR dimensions.
Renderer +0x478 owns state; its +0x74 eye and +0x4c0 world-clip matrix are used
for eye ownership and reconstruction. The bridge rejects other camera views.

RVA 0x0c2510 collection is now connected with a signature-checked thunk that
preserves retained XMM6/7 and forwards both arguments. Main-light radiance
is captured after the night adjustment, so scene and fog do not disagree.

Native `rl_hdr` final shader variants 13/14/15 have distinct encoding/alpha
contracts. Two multiply the scene by8; the other consumes full radiance.
The exact selected hashes have been mapped to original replacement shaders.
All native intermediate luminance/blur passes remain unchanged for now.

The recorded GPU events establish immediate primary geometry/shadows followed
by deferred secondary HDR. The implementation supports this split explicitly;
it must not ExecuteCommandList on the deferred context, nor capture its shadow
source from an unrelated immediate stream. Hardware tests cover this exact
ordering and retain native graphics state and predication.

## Live activation and remaining material boundary

0.11.5 process 2044 reported 199 successful shader replacements, zero creation
failures, and 2,553 transport draws with zero runtime rejections at eye epoch
7,920. Creation counters prove substitution, not actual draw coverage or quality.
The opt-in catalogue retained twelve unmodified generated material identities;
0.11.6 covers six of those (two blended surfaces and four environment variants).
Native captures remain private. Material gloss conversion now distinguishes
GGX alpha from perceptual roughness, and native masks do not become metalness.

RVA 0x0C27E0 source-colour scaling was checked against the executable: native
+CC/+D0/+D4 are multiplied by the second stack argument before output. Transport
normalizes this upload scale without altering the native material-light draw.
0.11.7 seeds the selected scene-root directional source once per pair and fixes
source selection/radiance for the stereo pair; geometric projections remain
per-eye. Do not equate a CPU poll that misses short calls with exact delivery;
use the new per-eye attempt/draw counters after installation.

## Native depth-caster path: static analysis checkpoint

The depth-only function at RVA 0x117D60 returns with `ret 0x30`: twelve stack
arguments. The outer cascade wrapper at 0x12E8D0 returns `ret 0x34`. The inner
call receives renderer, two opaque native scene/view parameters, a pointer to
the native shadow-target slot, width, height, clip matrix, a geometry submission
interface, a visibility mask, a submission array/count, and a mode flag.

The depth function saves renderer state/projection matrices, binds a depth
material, installs the supplied clip matrix, and uses three submission routes:
a SceneRenderer +0x1C interface, the supplied geometry interface, and a masked
array. Array entries test their +0x90 flags against the supplied mask. Exact
class ownership and off-screen visibility generation remain unverified. Do not
reuse a directional cascade's masked array as a complete point/spot caster list.

Correction: the earlier zero-on-disk lookup used the wrong relocation base.
The captured process loaded the game at 0x760000, not its preferred 0x400000.
RTTI and the new read-only runtime comparison agree on these identities:

| Native input | Verified class | Vtable RVA / submission |
| --- | --- | --- |
| Cascade argument 2 | rl_camera | 0xEC1414 |
| Cascade argument 3 | rl_light | 0xEC14FC |
| Cascade argument 8 | rl_batched_pass | 0xEBEEFC; slot +0x10 -> 0x136E20 |
| SceneRenderer +0x1C | rl_terrain_renderer | 0xEC0774; slot +0x14 -> 0x134360 |

`VERIFY-ENGINE-LIGHTING.py rfg.exe` verifies RTTI, method identities and the
batched submission stack-pop boundaries directly from the owned executable.
It uses no external packages and extracts no proprietary assets. Runtime
addresses must always use the actual loaded module base; never store the
capture's absolute pointers in production code.

The batched submission takes four stack arguments (ret 0x10): renderer,
camera, visibility mask, and a mode flag. It consumes 0x30-byte grouped
entries at +0x34 with count +0x30, and individual objects at +0x18 with count
+0x14. Individual objects filter +0x90 flags, then call their +0x10 method.
The separate +0x14 virtual method at 0x120AF0 takes one stack argument and
consumes another grouped submission list; its complete semantics are not yet
established. Neither method is a proven world-visibility builder.

The live scene also identifies +0x18 as rl_scene and +0x50 as a batched pass.
The +0x50 list was empty in the sampled phase. Do not substitute it for a
light's populated pass or retain transient lists across frames. Per-light
visibility construction, alpha/skinned participation and lifetime ownership
still require tracing before invoking these paths for auxiliary cameras.

The GPU local-shadow backend is independent of those unknown interfaces and
accepts a verified caster callback. The owned cube-capture backend similarly
requires a verified auxiliary scene view and validates camera rays and world
origin. This leaves the native adapters explicit rather than silently rendering
incorrect geometry.

Deferred compute/OM preservation follows the documented output-slot and UAV
counter contracts:
https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-omgetrendertargetsandunorderedaccessviews
https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-omsetrendertargetsandunorderedaccessviews

Further static tracing identifies the rl_scene_renderer vtable at 0xEC05A8,
with scene rendering at slot +0x0C / RVA 0x161D20. During this function's
visibility phase, 0x162199 obtains a new batched pass through 0x148DD0 and
stores it at self +0x50. Terrain work is initialized separately, followed by
scene visibility work through 0x161370. This explains why an out-of-phase
read of self +0x50 can be empty. The auxiliary capture adapter uses this native
scene route rather than inventing or retaining a caster array; a future
depth-only optimization still needs the complete visibility lifetime contract.

## 0.12.1 native floating-origin correction

Live 0.12.0 rejected all 120 auxiliary faces at validation, so its new reflection
and probe inputs never activated. The native camera builder at 0x120D70 subtracts
renderer state +0x80 from camera +0x2C before generating its view matrix. Existing
native captures verify +0x74 is the relative eye, while +0x80 is the world origin.

Capture camera placement now adds the origin to obtain an absolute camera pose.
Cube validation and depth reconstruction retain the relative matrix and relative
eye, with an explicit render-origin argument; the published capture position is
absolute. This avoids subtracting large world positions inside the GPU distance
calculation. Real-GPU regressions reproduce the failed unrebased camera and
verify all six faces and world distances at the captured nonzero origin.

Local-light selection now compares absolute source/eye positions, then uploads
relative light positions for the relative volume reconstruction. A GPU regression
requires identical images before/after a horizontal world-origin rebase. The
height medium keeps its base in world coordinates. Diagnostic metering starts
only in gameplay, avoiding its 120-pair budget being consumed by menu frames.
The installed 0.12.0 path has not yet confirmed these corrections live.

The capture producer now allows the engine's deferred context to change between
faces only after the enclosing native renderer has submitted the previous face.
It does not publish until the final GPU event completes. The hardware regression
alternates two real deferred contexts and verifies that an unsubmitted face
blocks the next one. No fence polling occurs before submission, and no GPU wait
is introduced. Validation reason codes distinguish input/origin, inverse matrix,
center ray, edge rays, view shape/format and command recording failures.
