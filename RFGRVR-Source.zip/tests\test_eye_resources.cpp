#define WIN32_LEAN_AND_MEAN
#include "../src/vr_eye_resources.h"
#include "../src/vr_eye_pipeline.h"
#include <cassert>
#include <cstdio>
using Microsoft::WRL::ComPtr;
static unsigned pixel(ID3D11Device* device,ID3D11DeviceContext* c,ID3D11Texture2D* source){
 D3D11_TEXTURE2D_DESC d{};source->GetDesc(&d);d.BindFlags=0;d.Usage=D3D11_USAGE_STAGING;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
 ComPtr<ID3D11Texture2D> read;assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&read)));c->CopyResource(read.Get(),source);
 D3D11_MAPPED_SUBRESOURCE m{};assert(SUCCEEDED(c->Map(read.Get(),0,D3D11_MAP_READ,0,&m)));unsigned value=*(unsigned*)m.pData;c->Unmap(read.Get(),0);return value;
}
int main(){
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> c;D3D_FEATURE_LEVEL level;
 assert(SUCCEEDED(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,&level,&c)));
 D3D11_TEXTURE2D_DESC d{};d.Width=d.Height=8;d.MipLevels=d.ArraySize=1;d.SampleDesc.Count=1;d.Format=DXGI_FORMAT_R8G8B8A8_UNORM;d.BindFlags=D3D11_BIND_RENDER_TARGET;
 ComPtr<ID3D11Texture2D> a,b;ComPtr<ID3D11RenderTargetView> av,bv;
 assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&a)));assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&b)));
 assert(SUCCEEDED(device->CreateRenderTargetView(a.Get(),nullptr,&av)));assert(SUCCEEDED(device->CreateRenderTargetView(b.Get(),nullptr,&bv)));
 const float red[]={1,0,0,1},green[]={0,1,0,1};
 c->ClearRenderTargetView(av.Get(),red);c->ClearRenderTargetView(bv.Get(),red);
 RFGRVREyeResources r;r.begin(c.Get());r.observe(av.Get());r.observe(av.Get());r.observe(bv.Get());assert(r.count()==2);
 c->ClearRenderTargetView(av.Get(),green);c->ClearRenderTargetView(bv.Get(),green);assert(pixel(device.Get(),c.Get(),a.Get())==0xff00ff00);
 assert(r.between(1));assert(pixel(device.Get(),c.Get(),a.Get())==0xff0000ff);assert(pixel(device.Get(),c.Get(),b.Get())==0xff00ff00);
 r.observe(bv.Get());assert(r.count()==2);r.end();assert(!r.between());
 r.begin(c.Get());r.observe(av.Get());c->ClearRenderTargetView(av.Get(),green);assert(r.between());assert(pixel(device.Get(),c.Get(),a.Get())==0xff0000ff);r.end();
 d.Format=DXGI_FORMAT_D24_UNORM_S8_UINT;d.BindFlags=D3D11_BIND_DEPTH_STENCIL;
 ComPtr<ID3D11Texture2D> depth;ComPtr<ID3D11DepthStencilView> dv;
 assert(SUCCEEDED(device->CreateTexture2D(&d,nullptr,&depth)));assert(SUCCEEDED(device->CreateDepthStencilView(depth.Get(),nullptr,&dv)));
 c->ClearDepthStencilView(dv.Get(),D3D11_CLEAR_DEPTH|D3D11_CLEAR_STENCIL,.25f,7);
 unsigned originalDepth=pixel(device.Get(),c.Get(),depth.Get());
 r.begin(c.Get());r.observe(dv.Get());c->ClearDepthStencilView(dv.Get(),D3D11_CLEAR_DEPTH|D3D11_CLEAR_STENCIL,.75f,19);
 assert(pixel(device.Get(),c.Get(),depth.Get())!=originalDepth);assert(r.between());assert(pixel(device.Get(),c.Get(),depth.Get())==originalDepth);r.end();
 D3D11_BUFFER_DESC bd{};bd.ByteWidth=256;bd.BindFlags=D3D11_BIND_CONSTANT_BUFFER;bd.Usage=D3D11_USAGE_DYNAMIC;bd.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;
 ComPtr<ID3D11Buffer> constants;assert(SUCCEEDED(device->CreateBuffer(&bd,nullptr,&constants)));
 D3D11_MAPPED_SUBRESOURCE map{};assert(SUCCEEDED(c->Map(constants.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&map)));memset(map.pData,0x42,256);c->Unmap(constants.Get(),0);
 r.begin(c.Get(),2);r.observe(av.Get());assert(r.count()==0);r.observeBuffer(constants.Get());r.observeBuffer(constants.Get());assert(r.count()==1);
 assert(SUCCEEDED(c->Map(constants.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&map)));memset(map.pData,0x73,256);c->Unmap(constants.Get(),0);assert(r.between());
 bd.BindFlags=0;bd.Usage=D3D11_USAGE_STAGING;bd.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ComPtr<ID3D11Buffer> read;
 assert(SUCCEEDED(device->CreateBuffer(&bd,nullptr,&read)));c->CopyResource(read.Get(),constants.Get());assert(SUCCEEDED(c->Map(read.Get(),0,D3D11_MAP_READ,0,&map)));
 for(unsigned i=0;i<256;++i)assert(((unsigned char*)map.pData)[i]==0x42);c->Unmap(read.Get(),0);r.end();
 ID3D11Buffer* initial=constants.Get();c->VSSetConstantBuffers(3,1,&initial);c->PSSetConstantBuffers(4,1,&initial);
 c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
 {RFGRVREyePipeline pipeline;pipeline.save(c.Get());ID3D11Buffer* empty=nullptr;c->VSSetConstantBuffers(3,1,&empty);c->PSSetConstantBuffers(4,1,&empty);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINELIST);
 pipeline.restore(c.Get());ID3D11Buffer* value=nullptr;c->VSGetConstantBuffers(3,1,&value);assert(value==initial);value->Release();value=nullptr;c->PSGetConstantBuffers(4,1,&value);assert(value==initial);value->Release();
 D3D11_PRIMITIVE_TOPOLOGY topology{};c->IAGetPrimitiveTopology(&topology);assert(topology==D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
 value=nullptr;c->VSSetConstantBuffers(3,1,&value);c->PSSetConstantBuffers(4,1,&value);c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINELIST);pipeline.restore(c.Get(),2);
 c->PSGetConstantBuffers(4,1,&value);assert(value==initial);value->Release();value=nullptr;c->VSGetConstantBuffers(3,1,&value);assert(!value);c->IAGetPrimitiveTopology(&topology);assert(topology==D3D11_PRIMITIVE_TOPOLOGY_LINELIST);}
 puts("PASS: real D3D11 target contents restored, deduplicated, masked, and scoped");
}
