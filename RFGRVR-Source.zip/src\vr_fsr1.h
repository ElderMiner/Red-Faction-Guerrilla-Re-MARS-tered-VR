#pragma once
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <cstdio>
#include "../vendor/fsr/fsr_shader_embedded.h"
namespace vrfsr {
inline uint32_t bits(float x){uint32_t u;memcpy(&u,&x,4);return u;}
struct alignas(16) Constants{uint32_t con[4][4]{},rcas[4]{},size[2]{},padding[2]{};};
inline bool setup(Constants& c,unsigned sw,unsigned sh,unsigned dw,unsigned dh,const float uv[4],float sharpness){
 if(!sw||!sh||!dw||!dh||!uv||!std::isfinite(sharpness))return false;
 for(int i=0;i<4;++i)if(!std::isfinite(uv[i])||uv[i]<0||uv[i]>1)return false;
 float w=(uv[2]-uv[0])*sw,h=(uv[3]-uv[1])*sh;if(w<2||h<2||w>dw||h>dh)return false;
 c={};c.con[0][0]=bits(w/dw);c.con[0][1]=bits(h/dh);c.con[0][2]=bits(.5f*w/dw-.5f+uv[0]*sw);c.con[0][3]=bits(.5f*h/dh-.5f+uv[1]*sh);
 float iw=1.f/sw,ih=1.f/sh;float values[3][4]={{iw,ih,iw,-ih},{-iw,2*ih,iw,2*ih},{0,4*ih,0,0}};for(int a=0;a<3;++a)for(int b=0;b<4;++b)c.con[a+1][b]=bits(values[a][b]);
 sharpness=sharpness<0?0:sharpness>2?2:sharpness;c.rcas[0]=bits(exp2f(-sharpness));c.size[0]=dw;c.size[1]=dh;return true;
}
struct Upscaler{
 using MicrosoftDevice=ID3D11Device;
 template<class T>using Ptr=Microsoft::WRL::ComPtr<T>;
 struct Entry{Ptr<ID3D11Texture2D> source,target,middle;Ptr<ID3D11ShaderResourceView> input,intermediate;Ptr<ID3D11RenderTargetView> scratch,output;};
 Entry cache[2];unsigned next=0,applied=0;bool unavailable=false;Ptr<ID3D11VertexShader> vs;Ptr<ID3D11PixelShader> easu,rcas;Ptr<ID3D11Buffer> buffer;Ptr<ID3D11SamplerState> sampler;Ptr<ID3D11RasterizerState> rasterizer;
 bool init(ID3D11Device* d){if(vs&&easu&&rcas&&buffer&&sampler&&rasterizer)return true;
  Ptr<ID3DBlob> v,p,error;D3D_SHADER_MACRO macros[]={{"EASU_PASS","1"},{nullptr,nullptr}};
  auto compile=[&](const char* entry,const char* model,ID3DBlob** result){error.Reset();HRESULT hr=D3DCompile(RFGRVR_FsrShader().data(),RFGRVR_FsrShader().size(),"AMD_FSR1",macros,nullptr,entry,model,D3DCOMPILE_OPTIMIZATION_LEVEL3,0,result,error.GetAddressOf());if(FAILED(hr))printf("FSR1 %s failed: %s\n",entry,error?(char*)error->GetBufferPointer():"unknown");return SUCCEEDED(hr);};
  if(!compile("VS","vs_5_0",v.GetAddressOf())||FAILED(d->CreateVertexShader(v->GetBufferPointer(),v->GetBufferSize(),nullptr,&vs)))return false;
  if(!compile("PS","ps_5_0",p.GetAddressOf())||FAILED(d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,&easu)))return false;
  p.Reset();macros[0].Definition="0";if(!compile("PS","ps_5_0",p.GetAddressOf())||FAILED(d->CreatePixelShader(p->GetBufferPointer(),p->GetBufferSize(),nullptr,&rcas)))return false;
  D3D11_BUFFER_DESC cb{};cb.ByteWidth=sizeof(Constants);cb.Usage=D3D11_USAGE_DEFAULT;cb.BindFlags=D3D11_BIND_CONSTANT_BUFFER;if(FAILED(d->CreateBuffer(&cb,nullptr,&buffer)))return false;
  D3D11_SAMPLER_DESC s{};s.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;s.AddressU=s.AddressV=s.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;if(FAILED(d->CreateSamplerState(&s,&sampler)))return false;
  D3D11_RASTERIZER_DESC r{};r.FillMode=D3D11_FILL_SOLID;r.CullMode=D3D11_CULL_NONE;r.DepthClipEnable=TRUE;return SUCCEEDED(d->CreateRasterizerState(&r,&rasterizer));
 }
 bool render(ID3D11Device* d,ID3D11DeviceContext* ctx,ID3D11Texture2D* src,ID3D11Texture2D* dst,const float uv[4],float sharpness){
  if(!d||!ctx||!src||!dst||unavailable)return false;D3D11_TEXTURE2D_DESC s{},t{};src->GetDesc(&s);dst->GetDesc(&t);Constants c;if(!setup(c,s.Width,s.Height,t.Width,t.Height,uv,sharpness))return false;if(!init(d)){unavailable=true;printf("FSR1 unavailable; retaining original optics blit\n");return false;}
  Entry* e=nullptr;for(auto& item:cache)if(item.source.Get()==src&&item.target.Get()==dst){e=&item;break;}
  if(!e){auto& item=cache[next++%2];item={};item.source=src;item.target=dst;D3D11_TEXTURE2D_DESC mid=t;mid.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_RENDER_TARGET;mid.MiscFlags=mid.CPUAccessFlags=0;mid.Usage=D3D11_USAGE_DEFAULT;
   if(FAILED(d->CreateTexture2D(&mid,nullptr,&item.middle))||FAILED(d->CreateShaderResourceView(src,nullptr,&item.input))||FAILED(d->CreateShaderResourceView(item.middle.Get(),nullptr,&item.intermediate))||FAILED(d->CreateRenderTargetView(item.middle.Get(),nullptr,&item.scratch))||FAILED(d->CreateRenderTargetView(dst,nullptr,&item.output))){item={};return false;}e=&item;
  }
  ctx->UpdateSubresource(buffer.Get(),0,nullptr,&c,0,0);ID3D11Buffer* cb=buffer.Get();ID3D11SamplerState* sm=sampler.Get();ctx->PSSetConstantBuffers(0,1,&cb);ctx->PSSetSamplers(0,1,&sm);ctx->IASetInputLayout(nullptr);ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);ctx->VSSetShader(vs.Get(),nullptr,0);ctx->RSSetState(rasterizer.Get());ctx->OMSetBlendState(nullptr,nullptr,0xffffffffu);ctx->OMSetDepthStencilState(nullptr,0);D3D11_VIEWPORT vp{0,0,float(t.Width),float(t.Height),0,1};ctx->RSSetViewports(1,&vp);
  ID3D11RenderTargetView* rt=e->scratch.Get();ID3D11ShaderResourceView* input=e->input.Get();ctx->OMSetRenderTargets(1,&rt,nullptr);ctx->PSSetShaderResources(0,1,&input);ctx->PSSetShader(easu.Get(),nullptr,0);ctx->Draw(3,0);
  ID3D11ShaderResourceView* noInput=nullptr;ctx->PSSetShaderResources(0,1,&noInput);rt=e->output.Get();input=e->intermediate.Get();ctx->OMSetRenderTargets(1,&rt,nullptr);ctx->PSSetShaderResources(0,1,&input);ctx->PSSetShader(rcas.Get(),nullptr,0);ctx->Draw(3,0);
  ctx->PSSetShaderResources(0,1,&noInput);ID3D11RenderTargetView* noTarget=nullptr;ctx->OMSetRenderTargets(1,&noTarget,nullptr);cb=nullptr;ctx->PSSetConstantBuffers(0,1,&cb);
  if(++applied==1||applied%600==0)printf("FSR1 eye blit applied=%u source=%ux%u output=%ux%u crop=%.5f,%.5f,%.5f,%.5f\n",applied,s.Width,s.Height,t.Width,t.Height,uv[0],uv[1],uv[2],uv[3]);return true;
 }
};
struct Setting{unsigned mode=0;float sharpness=.8f;};
inline Setting setting(){static ULONGLONG last=0;static Setting value;auto now=GetTickCount64();if(last&&now-last<1000)return value;last=now;wchar_t path[MAX_PATH]{};GetModuleFileNameW(nullptr,path,MAX_PATH);auto* slash=wcsrchr(path,L'\\');if(!slash)return value;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"RFGRVR-upscaler.txt");FILE* f=nullptr;Setting nextValue;if(!_wfopen_s(&f,path,L"r")&&f){unsigned mode=0;float sharp=.8f;int fields=fscanf_s(f,"%u %f",&mode,&sharp);fclose(f);if(fields>=1&&mode<=1&&std::isfinite(sharp)){nextValue.mode=mode;nextValue.sharpness=sharp<0?0:sharp>2?2:sharp;}}
 if(nextValue.mode!=value.mode||nextValue.sharpness!=value.sharpness)printf("Stereo upscaler: mode=%u (0=original,1=FSR1 EASU+RCAS) sharpness=%.2f\n",nextValue.mode,nextValue.sharpness);value=nextValue;return value;}
}

