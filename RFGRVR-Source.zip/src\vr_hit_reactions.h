#pragma once
#include <windows.h>
#include <cstring>
#include "../vendor/MinHook.h"
extern "C" bool RFGRVR_HeadCam_Enabled();
namespace vrhit {
inline void* original=nullptr;inline void** local=nullptr;inline unsigned skipped=0;
inline bool readable(void* p,size_t n){MEMORY_BASIC_INFORMATION m{};return p&&VirtualQuery(p,&m,sizeof(m))&&m.State==MEM_COMMIT&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(uintptr_t)p>=(uintptr_t)m.BaseAddress&&(uintptr_t)p-(uintptr_t)m.BaseAddress<=m.RegionSize&&n<=m.RegionSize-((uintptr_t)p-(uintptr_t)m.BaseAddress);}
inline bool shouldSkip(void* human){if(!RFGRVR_HeadCam_Enabled()||!local||human!=*local||!readable(human,0x300))return false;unsigned state=0;memcpy(&state,(char*)human+0x2f4,4);return state<=2||(state>=7&&state<=10);}
inline int __cdecl block(void* human){bool skip=shouldSkip(human);if(skip)++skipped;return skip;}
// Preserve the original cdecl argument list without guessing how many later
// reaction parameters the caller supplied. Damage handling is a different path.
__declspec(naked) inline void entry(){__asm {
 mov eax, [esp+4]
 pushfd
 pushad
 push eax
 call block
 add esp, 4
 mov [esp+28], eax
 popad
 popfd
 test eax,eax
 jz native
 xor eax,eax
 ret
 native:
 jmp dword ptr [original]
 }}
inline bool install(unsigned char* base){const unsigned char start[]={0x83,0xec,0x10,0x80,0x3d};const unsigned char flagCheck[]={0xf7,0x86,0xc0,0,0,0,0,0,0,0x20};if(memcmp(base+0x67e800,start,sizeof(start))||memcmp(base+0x67e841,flagCheck,sizeof(flagCheck)))return false;local=(void**)(base+0x2c23874);if(MH_CreateHook(base+0x67e800,(void*)entry,&original)!=MH_OK)return false;if(MH_EnableHook(base+0x67e800)==MH_OK)return true;MH_RemoveHook(base+0x67e800);return false;}
}
