#include "../src/gpu_pipeline_trace.cpp"
#include <cassert>
extern "C" unsigned RFGRVR_HeadCam_HeadSamples(){return 0;}
extern "C" bool RFGRVR_HeadCam_Recent(){return false;}
extern "C" void RFGRVR_Survey_Capture(bool){}
static unsigned forwarded=0;
static void STDMETHODCALLTYPE Auto(ID3D11DeviceContext* c){assert(c==(void*)1);++forwarded;}
static void STDMETHODCALLTYPE Indirect(ID3D11DeviceContext* c,ID3D11Buffer* b,UINT offset){assert(c==(void*)1&&b==(void*)2&&offset==20);++forwarded;}
static void STDMETHODCALLTYPE Dispatch(ID3D11DeviceContext* c,UINT x,UINT y,UINT z){assert(c==(void*)1&&x==2&&y==3&&z==4);++forwarded;}
static void STDMETHODCALLTYPE Execute(ID3D11DeviceContext* c,ID3D11CommandList* list,BOOL restore){assert(c==(void*)1&&list==(void*)3&&restore==TRUE);++forwarded;}
int main(){oldAuto=Auto;oldIndexedIndirect=oldInstIndirect=oldDispatchIndirect=Indirect;oldDispatch=Dispatch;oldExecute=Execute;auto* c=(ID3D11DeviceContext*)1;auto* b=(ID3D11Buffer*)2;const auto before=nativeDrawCount;HAuto(c);HIndexedIndirect(c,b,20);HInstIndirect(c,b,20);HDispatch(c,2,3,4);HDispatchIndirect(c,b,20);HExecute(c,(ID3D11CommandList*)3,TRUE);assert(forwarded==6&&nativeDrawCount==before+3);assert(!RFGRVRPixelProbe::active);}
