#pragma once
#include "vr_arm_math.h"
// Carry an animation anchor from simulation space into the character's
// rendered rigid frame. Position and orientation must use the same root.
inline bool RFGRVR_RenderAnchor(const vrarm::Pose& sampledRoot,const vrarm::Pose& renderedRoot,vrarm::Pose& anchor,float maxDistance=2.f){
 using namespace vrarm;
 if(!valid(sampledRoot.b)||!valid(renderedRoot.b)||!valid(anchor.b)||!finite(sampledRoot.p)||!finite(renderedRoot.p)||!finite(anchor.p)||!std::isfinite(maxDistance)||maxDistance<2||maxDistance>32||length(sub(renderedRoot.p,sampledRoot.p))>=maxDistance)return false;
 Pose result{compose(renderedRoot.b,relative(sampledRoot.b,anchor.b)),add(renderedRoot.p,world(renderedRoot.b,local(sampledRoot.b,sub(anchor.p,sampledRoot.p))))};
 if(!valid(result.b)||!finite(result.p))return false;anchor=result;return true;
}
