#include "../src/vr_crouch_eye.h"
#include <cassert>
int main(){RFGRVRCrouchEye c;assert(c.update(true,true,-.5f,.01f)==1);
 for(int i=0;i<40;++i)assert(c.update(true,false,-.4f,.01f)==1);
 float prior=1;for(int i=0;i<25;++i){float w=c.update(true,false,0,.01f);assert(w<=prior&&prior-w<=.051f);prior=w;}assert(c.weight==0);
 c.update(true,true,-.5f,.01f);assert(c.update(false,false,0,.01f)==0);
}
