#pragma once
#include <cmath>
struct RFGRVRLandingEye {bool active=false;float landing=0,settled=0;bool update(bool airborne,bool eligible,float difference,float dt){if(!eligible){*this={};return false;}if(!std::isfinite(dt)||dt<0)dt=0;if(dt>.05f)dt=.05f;if(airborne){active=true;landing=settled=0;return true;}if(!active)return false;landing+=dt;if(std::isfinite(difference)&&fabsf(difference)<.025f)settled+=dt;else settled=0;if(landing>.8f&&settled>.2f)active=false;return active;}};
