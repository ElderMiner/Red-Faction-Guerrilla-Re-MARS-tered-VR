#pragma once
#include <cstdint>
// Stale gameplay frames must not be submitted as live gameplay. Keep their
// owned images, however: the engine's menu signal arrives after its debounce.
inline bool RFGRVR_SubmitCachedScene(bool cached,bool worldMenu,uint64_t now,uint64_t lastPair){
 return cached&&(worldMenu||(now>=lastPair&&now-lastPair<=1500));
}
// Parent-state publication precedes the debounced gameplay-active signal on
// menu exit. Bridge that bounded gap without selecting the flat fallback.
struct RFGRVRSceneTransition {
 uint32_t game=0;bool popup=false;uint64_t exited=0;
 bool update(uint32_t pid,bool menu,bool frontend,bool gameplay,uint64_t now){
  if(pid!=game||!pid||frontend){game=pid;popup=false;exited=0;return false;}
  if(popup&&!menu)exited=now;
  popup=menu;
  if(gameplay)exited=0;
  return menu||(exited&&now>=exited&&now-exited<=2000);
 }
};
