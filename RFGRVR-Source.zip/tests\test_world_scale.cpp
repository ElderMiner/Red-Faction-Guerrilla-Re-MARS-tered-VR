#include "../src/vr_world_scale.h"
#include <cassert>
#include "../src/vr_neutral_pose.h"
#include <initializer_list>
int main(){assert(fabsf(RFGRVR_HeightScale(1.8f,1.5f)-1.2f)<.00001f);assert(fabsf(RFGRVR_HeightScale(1.8f,2.f)-.9f)<.00001f);assert(RFGRVR_HeightScale(1.8f,0)==1);assert(RFGRVR_HeightScale(NAN,1.5f)==1);
 for(float eye:{.5f,1.f,1.5f,1.8f}){float scale=RFGRVR_HeightScale(1.8f,1.5f);float camera=10+1.8f+RFGRVR_FloorEyeOffset(eye,1.8f,scale);
  assert(fabsf(camera-(10+eye*scale))<.00001f);assert(fabsf(camera-eye*scale-10)<.00001f);
 }
 // Neutral legs reproduce the authored vertex exactly, independently of
 // any captured crouch/weapon-idle ankle offsets. Upper-body poses untouched.
 {using namespace vrarm;M id{{1,0,0},{0,1,0},{0,0,1}};V bind{.1f,-.12f,.03f},sole{-.1f,0,.05f};auto leg=RFGRVR_IdleLegBind(bind,id);auto skinned=add(leg.p,world(leg.b,add(sole,bind)));assert(length(sub(skinned,sole))<.000001f);auto facing=turnAround(id,{0,1,0},1.f);leg=RFGRVR_IdleLegBind(bind,facing);skinned=add(leg.p,world(leg.b,add(sole,bind)));assert(length(sub(skinned,world(facing,sole)))<.000001f);assert(fabsf(skinned.y)<.000001f);}
}
