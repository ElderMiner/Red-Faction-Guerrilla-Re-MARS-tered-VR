#pragma once
#include <atomic>
#include <cstdint>
namespace vrinteraction {
inline std::atomic<uint32_t> visibleTick{0};
inline void sample(bool visible,uint32_t now){visibleTick.store(visible?now:0,std::memory_order_relaxed);}
inline bool available(uint32_t now){auto tick=visibleTick.load(std::memory_order_relaxed);return tick&&uint32_t(now-tick)<250;}
}
