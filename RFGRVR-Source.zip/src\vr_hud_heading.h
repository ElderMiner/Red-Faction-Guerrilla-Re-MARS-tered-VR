#pragma once
#include <windows.h>
#include <atomic>
#include <cmath>
#include <cstring>
namespace RFGRVRHudHeading {
inline std::atomic<float> yaw{0};inline std::atomic<ULONGLONG> tick{0};
inline void publish(float value){if(!std::isfinite(value))return;yaw.store(value,std::memory_order_relaxed);tick.store(GetTickCount64(),std::memory_order_release);}
inline bool basis(float out[9]){auto stamp=tick.load(std::memory_order_acquire);float value=yaw.load(std::memory_order_relaxed);if(!stamp||GetTickCount64()-stamp>=250||!std::isfinite(value))return false;float c=cosf(value),s=sinf(value);float m[9]={c,0,-s,0,1,0,s,0,c};memcpy(out,m,sizeof(m));return true;}
using Copy=void*(__thiscall*)(void*,const void*);inline Copy nativeCopy=nullptr;
inline void* __fastcall mapBasis(void* dst,void*,const void* source){float matrix[9];return nativeCopy(dst,basis(matrix)?matrix:source);}
inline bool install(){auto* exe=(unsigned char*)GetModuleHandleW(nullptr);auto* call=exe+0x472a12;nativeCopy=(Copy)(exe+0x1755f0);if(call[0]!=0xe8||call+5+*(int*)(call+1)!=(unsigned char*)nativeCopy)return false;DWORD old=0;if(!VirtualProtect(call,5,PAGE_EXECUTE_READWRITE,&old))return false;InterlockedExchange((volatile LONG*)(call+1),(LONG)((unsigned char*)&mapBasis-call-5));FlushInstructionCache(GetCurrentProcess(),call,5);DWORD ignored=0;VirtualProtect(call,5,old,&ignored);return true;}
}
